@echo off
cd /d "%~dp0"
rem Start with whichever Python is installed: the py launcher, or python on the PATH.
py -c "import sys" >nul 2>nul && (start "" pyw lantern_delve.py & exit /b)
python -c "import sys" >nul 2>nul && (start "" pythonw lantern_delve.py & exit /b)
echo.
echo   Lantern Delve needs Python 3 to run. It's free:
echo.
echo   1. Go to https://www.python.org/downloads/ and download Python.
echo   2. Run the installer. Tick "Add python.exe to PATH" if you see it, then click Install Now.
echo   3. Double-click "Start Lantern Delve" again.
echo.
pause
