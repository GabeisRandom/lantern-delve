// Small helpers shared by every page.
// (X-Lantern: only the app's own pages can send it, so other web pages can't upload or open files.)
export async function api(path, body) {
  const opts = body === undefined ? {} : {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Lantern': 'app' }, body: JSON.stringify(body),
  };
  const r = await fetch(path, opts);
  if (!r.ok) throw new Error(`${path} -> ${r.status}`);
  return r.json();
}

// ---- homework files
export const MAX_UPLOAD = 50 * 1024 * 1024;

export async function uploadFile(file) {
  const r = await fetch(`/api/files/upload?name=${encodeURIComponent(file.name)}`, {
    method: 'POST', headers: { 'Content-Type': 'application/octet-stream', 'X-Lantern': 'app' }, body: file,
  });
  if (!r.ok) throw new Error(`upload -> ${r.status}`);
  return r.json();
}

// The app opens it in its usual program. The browser version hands back a link: PDFs, pictures and text
// open in a new tab, anything else downloads under its own name.
export async function openFile(id) {
  const r = await api('/api/files/open', { id });
  if (r.url) {
    const a = document.createElement('a');
    a.href = r.url;
    if (r.view) a.target = '_blank'; else a.download = r.name || 'file';
    document.body.append(a);
    a.click();
    a.remove();
  }
  return r;
}

export function sizeText(n) {
  return n >= 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round((n || 0) / 1024))} KB`;
}

export function fileIcon(name) {
  const ext = String(name).toLowerCase().split('.').pop();
  if (ext === 'pdf') return '📕';
  if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'heic', 'bmp'].includes(ext)) return '🖼';
  if (['ppt', 'pptx', 'key', 'odp'].includes(ext)) return '📊';
  if (['xls', 'xlsx', 'csv', 'ods'].includes(ext)) return '📈';
  if (['doc', 'docx', 'txt', 'md', 'rtf', 'odt', 'pages'].includes(ext)) return '📝';
  return '📎';
}

// One file as a clickable chip (data-a="open-file"), with an × when it can be removed.
export function fileChip(f, removeAction = '', extra = '') {
  const status = f.state === 'up' ? 'uploading…' : f.state === 'err' ? f.err || "couldn't upload" : sizeText(f.size);
  return `<span class="file ${f.state || ''}"><span class="fname" ${f.id && f.state !== 'up' && f.state !== 'err' ? `data-a="open-file" data-id="${esc(f.id)}" title="Open ${esc(f.name)}"` : ''}>${fileIcon(f.name)} ${esc(f.name)}</span><span class="fsize">${esc(status)}</span>${removeAction ? `<button class="x" data-a="${removeAction}" ${extra} title="Remove">×</button>` : ''}</span>`;
}

export function fmt(secs) {
  secs = Math.max(0, Math.floor(secs || 0));
  const h = Math.floor(secs / 3600), m = Math.floor((secs % 3600) / 60), s = secs % 60;
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${m}:${String(s).padStart(2, '0')}`;
}

export function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
}

export function rewardText(r) {
  const parts = [];
  if (r.light) parts.push(`+${r.light} ✦`);
  if (r.coins) parts.push(`+${r.coins} 🪙`);
  if (r.star_pieces) parts.push(`+${r.star_pieces} ⭐`);
  return parts.join('  ');
}
