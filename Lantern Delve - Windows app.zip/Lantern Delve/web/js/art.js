// Paper-cutout drawing: every character is drawn twice, first as a thick white
// "paper border" silhouette, then in color with a thin ink outline on top.
export const INK = '#2b2235';
export const PAPER = '#fffaf0';
const TAU = Math.PI * 2;

// ---------------------------------------------------------------- path builders
export const ell = (x, y, rx, ry, rot = 0) => c => c.ellipse(x, y, Math.max(0.1, rx), Math.max(0.1, ry), rot, 0, TAU);
export const rrect = (x, y, w, h, r) => c => {
  r = Math.max(0, Math.min(r, w / 2, h / 2));
  c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r);
  c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
};
export const poly = pts => c => {
  c.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) c.lineTo(pts[i][0], pts[i][1]);
  c.closePath();
};
export function starPath(c, x, y, r1, r2, n = 5, rot = -Math.PI / 2) {
  c.moveTo(x + Math.cos(rot) * r1, y + Math.sin(rot) * r1);
  for (let i = 1; i < n * 2; i++) {
    const r = i % 2 ? r2 : r1, a = rot + (i * Math.PI) / n;
    c.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r);
  }
  c.closePath();
}

export function shape(c, pass, path, fill, lw = 2.4) {
  c.beginPath(); path(c);
  if (pass === 0) {
    c.lineWidth = lw + 7; c.strokeStyle = PAPER; c.fillStyle = PAPER; c.stroke(); c.fill();
    return;
  }
  c.fillStyle = fill; c.fill();
  if (lw > 0) { c.lineWidth = lw; c.strokeStyle = INK; c.stroke(); }
}

export function paper(c, draw) {
  c.save(); c.lineJoin = 'round'; c.lineCap = 'round';
  draw(0); draw(1);
  c.restore();
}

export function vgrad(c, y0, y1, a, b) {
  const g = c.createLinearGradient(0, y0, 0, y1);
  g.addColorStop(0, a); g.addColorStop(1, b);
  return g;
}

export function shadow(c, x, y, w, alpha = 0.22) {
  c.save(); c.fillStyle = `rgba(20,10,30,${alpha})`;
  c.beginPath(); c.ellipse(x, y, w, w * 0.28, 0, 0, TAU); c.fill();
  c.restore();
}

// ---------------------------------------------------------------- faces
export function eyes(c, x1, x2, y, h, mood = 'normal', t = 0) {
  const w = h * 0.42;
  const blink = !['sleep', 'happy', 'hurt'].includes(mood) && (t % 3.7) < 0.12;
  c.save(); c.lineCap = 'round'; c.strokeStyle = INK; c.fillStyle = INK; c.lineWidth = 2.2;
  for (const x of [x1, x2]) {
    if (mood === 'happy' || mood === 'proud') {
      c.beginPath(); c.arc(x, y + h * 0.2, w * 0.95, Math.PI * 1.15, Math.PI * 1.85); c.stroke(); continue;
    }
    if (mood === 'sleep' || mood === 'sleepy') {
      c.beginPath(); c.arc(x, y - h * 0.1, w * 0.9, Math.PI * 0.15, Math.PI * 0.85); c.stroke(); continue;
    }
    if (mood === 'hurt') {
      const r = w * 0.75;
      c.beginPath(); c.moveTo(x - r, y - r); c.lineTo(x + r, y + r); c.moveTo(x + r, y - r); c.lineTo(x - r, y + r); c.stroke();
      continue;
    }
    if (blink) { c.beginPath(); c.moveTo(x - w * 0.7, y); c.lineTo(x + w * 0.7, y); c.stroke(); continue; }
    c.beginPath(); c.ellipse(x, y, w * 0.5, h * 0.5, 0, 0, TAU); c.fill();
    c.fillStyle = '#fff';
    c.beginPath(); c.ellipse(x + w * 0.12, y - h * 0.22, w * 0.2, h * 0.15, 0, 0, TAU); c.fill();
    c.fillStyle = INK;
  }
  if (mood === 'worried' || mood === 'angry' || mood === 'determined') {
    const dy = mood === 'angry' ? 1 : mood === 'worried' ? -1 : 0;
    [[x1, -1], [x2, 1]].forEach(([x, side]) => {
      const inner = x - side * w * 0.9, outer = x + side * w * 0.9;
      c.beginPath(); c.moveTo(outer, y - h * 0.78 - dy * 2); c.lineTo(inner, y - h * 0.78 + dy * 3); c.stroke();
    });
  }
  c.restore();
}

export function mouth(c, x, y, w, mood = 'normal') {
  c.save(); c.strokeStyle = INK; c.fillStyle = INK; c.lineWidth = 2; c.lineCap = 'round';
  c.beginPath();
  if (mood === 'happy' || mood === 'proud' || mood === 'relieved') {
    c.arc(x, y - w * 0.3, w * 0.7, 0.15 * Math.PI, 0.85 * Math.PI); c.closePath(); c.fill();
  } else if (mood === 'angry') {
    c.arc(x, y + w * 0.5, w * 0.55, 1.2 * Math.PI, 1.8 * Math.PI); c.stroke();
  } else if (mood === 'worried') {
    c.moveTo(x - w * 0.5, y); c.quadraticCurveTo(x - w * 0.25, y - 2, x, y); c.quadraticCurveTo(x + w * 0.25, y + 2, x + w * 0.5, y); c.stroke();
  } else if (mood === 'hurt' || mood === 'shock') {
    c.ellipse(x, y, w * 0.3, w * 0.4, 0, 0, TAU); c.fill();
  } else if (mood === 'sleep' || mood === 'sleepy') {
    c.ellipse(x, y, w * 0.18, w * 0.2, 0, 0, TAU); c.stroke();
  } else {
    c.arc(x, y - w * 0.25, w * 0.5, 0.2 * Math.PI, 0.8 * Math.PI); c.stroke();
  }
  c.restore();
}

function blush(c, x, y, r = 4) {
  c.save(); c.fillStyle = 'rgba(255,120,150,0.45)';
  c.beginPath(); c.ellipse(x, y, r, r * 0.6, 0, 0, TAU); c.fill(); c.restore();
}

// ---------------------------------------------------------------- effects
export function flame(c, x, y, size, t) {
  const f = 1 + Math.sin(t * 13) * 0.06 + Math.sin(t * 7.3) * 0.05;
  const h = 15 * size * f, w = 7 * size;
  c.save();
  const glow = c.createRadialGradient(x, y - h * 0.4, 1, x, y - h * 0.4, h * 1.7);
  glow.addColorStop(0, 'rgba(255,214,110,0.5)'); glow.addColorStop(1, 'rgba(255,214,110,0)');
  c.fillStyle = glow; c.beginPath(); c.arc(x, y - h * 0.4, h * 1.7, 0, TAU); c.fill();
  const sway = Math.sin(t * 5) * w * 0.25;
  const tear = s => {
    c.beginPath(); c.moveTo(x + sway * s, y - h * s);
    c.bezierCurveTo(x + w * s, y - h * 0.45 * s, x + w * 0.8 * s, y, x, y);
    c.bezierCurveTo(x - w * 0.8 * s, y, x - w * s, y - h * 0.45 * s, x + sway * s, y - h * s);
    c.closePath();
  };
  tear(1); c.fillStyle = '#ff8a3d'; c.fill();
  tear(0.66); c.fillStyle = '#ffd25e'; c.fill();
  tear(0.33); c.fillStyle = '#fff6d0'; c.fill();
  c.restore();
}

export function glowDot(c, x, y, r, color = '255,220,120', a = 0.5) {
  const g = c.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, `rgba(${color},${a})`); g.addColorStop(1, `rgba(${color},0)`);
  c.fillStyle = g; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill();
}

// ---------------------------------------------------------------- Wick (the hero)
function hammerShape(c, p) {
  shape(c, p, rrect(-2.5, -34, 5, 34, 2), '#9a6a45');
  shape(c, p, rrect(-10, -44, 20, 13, 4), vgrad(c, -44, -31, '#d9dce6', '#9ea3b5'));
}

function drawPlane(c, t, mood) {
  const bob = Math.sin(t * 6) * 2;
  c.translate(0, -36 + bob);
  c.rotate(0.08 + Math.sin(t * 3) * 0.04);
  paper(c, p => {
    shape(c, p, poly([[-28, -7], [27, 0], [-28, 9], [-17, 1]]), vgrad(c, -7, 9, '#fffaf0', '#f0deb6'));
    shape(c, p, poly([[-17, 1], [27, 0], [-23, 14]]), '#e2cfa4');
    if (p) { c.strokeStyle = '#3d5a9e'; c.lineWidth = 3; c.beginPath(); c.moveTo(-22, 6); c.lineTo(8, 1); c.stroke(); }
  });
  flame(c, -27, 4, 0.55, t);
  eyes(c, 10, 17, -2, 6, mood, t);
}

export function drawWick(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'normal';
  const state = o.state || 'idle', ph = o.phase || 0;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 18 * s);
  c.scale(s * flip, s);
  if (state === 'glide') { drawPlane(c, t, mood); c.restore(); return; }
  const sq = o.sq || 1;
  if (sq !== 1) c.scale(2 - sq, sq);
  const walk = state === 'walk', air = state === 'jump';
  const bob = walk ? -Math.abs(Math.sin(ph * Math.PI * 2)) * 3 : Math.sin(t * 2.2) * 0.8;
  const tilt = walk ? Math.sin(ph * Math.PI * 2) * 0.06 : (o.tilt || 0);
  c.rotate(tilt); c.translate(0, bob);
  const fL = walk ? Math.max(0, Math.sin(ph * TAU)) * 4 : air ? 5 : 0;
  const fR = walk ? Math.max(0, -Math.sin(ph * TAU)) * 4 : air ? 3 : 0;
  const swing = o.swing;
  const armY = walk ? Math.sin(ph * TAU) * 3 : air ? -7 : (o.writing ? Math.sin(t * 9) * 2 : 0);
  const armX = o.writing ? 13 + Math.sin(t * 4.5) * 3 : 12;
  paper(c, p => {
    const wave = Math.sin(t * 4 + ph * 3) * 2;
    shape(c, p, poly([[-9, -29], [-21 - (walk ? 3 : 0), -7 + wave], [-3, -10]]), '#d9534f');
    if (o.hammer && swing == null) {
      c.save(); c.translate(-8, -26); c.rotate(-0.6); hammerShape(c, p); c.restore();
    }
    shape(c, p, ell(-7, -3 - fL, 6.5, 4.2), '#7a4b2a');
    shape(c, p, ell(7, -3 - fR, 6.5, 4.2), '#7a4b2a');
    shape(c, p, rrect(-12, -30, 24, 25, 9), vgrad(c, -30, -5, '#4f72bf', '#2c437a'));
    if (swing != null) {
      c.save(); c.translate(10, -20); c.rotate(-2.3 + swing * 3.1); hammerShape(c, p); c.restore();
    }
    shape(c, p, ell(armX, -19 + armY, 4.6, 5), '#fbf1d9');
    shape(c, p, rrect(-14, -62, 28, 34, 10), vgrad(c, -62, -28, '#fff8e6', '#f0d8ab'));
    if (p) {
      c.fillStyle = '#fffdf6';
      c.beginPath(); rrect(-10, -62, 6, 12, 3)(c); c.fill();
      c.beginPath(); rrect(5, -62, 5, 8, 2.5)(c); c.fill();
      c.fillStyle = '#f2c14e'; c.fillRect(-11, -14, 22, 3);
    }
  });
  if (o.headband) {   // study battle mode: a red headband with fluttering tails
    const fl = Math.sin(t * 9) * 2;
    paper(c, p => {
      shape(c, p, poly([[-14, -62], [-27, -67 + fl], [-25, -59 + fl], [-14, -57]]), '#e5534b');
      shape(c, p, rrect(-15, -63, 30, 6, 2), '#e5534b');
    });
  }
  c.strokeStyle = INK; c.lineWidth = 2; c.beginPath(); c.moveTo(1, -62); c.lineTo(2, -68); c.stroke();
  flame(c, 2, -68, o.flame ?? 1, t);
  eyes(c, -3, 7, -46, 10, mood, t);
  blush(c, -8, -37); blush(c, 12, -37);
  mouth(c, 3, -37, 6, mood);
  c.restore();
}

// ---------------------------------------------------------------- partners & townsfolk
export function drawMoss(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 18 * s);
  c.scale(s * flip, s);
  const sq = o.state === 'walk' ? Math.sin((o.phase || 0) * TAU) * 0.09 : o.state === 'jump' ? -0.12 : Math.sin(t * 2.5) * 0.04;
  const rx = 20 * (1 + sq), ry = 15 * (1 - sq), top = -ry * 1.65;
  paper(c, p => {
    shape(c, p, cc => { cc.moveTo(-rx, 0); cc.bezierCurveTo(-rx, -ry * 2.2, rx, -ry * 2.2, rx, 0); cc.closePath(); },
      vgrad(c, top, 0, '#93e584', '#4aa857'));
    shape(c, p, cc => { cc.moveTo(1, top); cc.quadraticCurveTo(3, top - 9, 11, top - 10); cc.quadraticCurveTo(8, top - 2, 1, top); }, '#6cc04a', 1.8);
  });
  c.fillStyle = 'rgba(255,255,255,0.5)'; c.beginPath(); c.ellipse(-9, top * 0.68, 5, 3, -0.5, 0, TAU); c.fill();
  eyes(c, -5, 7, top * 0.48, 9, o.mood, t);
  mouth(c, 1, top * 0.22, 6, o.mood);
  c.restore();
}

export function drawHoot(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'normal';
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 16 * s);
  c.scale(s * flip, s);
  const flap = o.state === 'walk' ? Math.sin((o.phase || 0) * TAU) * 0.25 : o.state === 'jump' ? 0.5 : Math.sin(t * 3) * 0.05;
  paper(c, p => {
    shape(c, p, poly([[-14, -34], [-11, -46], [-5, -37]]), '#7a4a30');
    shape(c, p, poly([[14, -34], [11, -46], [5, -37]]), '#7a4a30');
    shape(c, p, ell(-16, -18, 6, 11, 0.3 + flap), '#6e4029');
    shape(c, p, ell(16, -18, 6, 11, -0.3 - flap), '#6e4029');
    shape(c, p, ell(0, -20, 17, 20), vgrad(c, -40, 0, '#a76f48', '#7a4a30'));
    shape(c, p, ell(0, -12, 11, 11), '#f3dfb8');
    shape(c, p, ell(-6, -1, 4, 2.5), '#f2a33a', 1.6);
    shape(c, p, ell(6, -1, 4, 2.5), '#f2a33a', 1.6);
  });
  c.strokeStyle = 'rgba(122,74,48,0.5)'; c.lineWidth = 1.5;
  for (const [vx, vy] of [[-4, -12], [4, -12], [0, -7]]) { c.beginPath(); c.moveTo(vx - 2, vy); c.lineTo(vx, vy + 2); c.lineTo(vx + 2, vy); c.stroke(); }
  if (o.glasses !== false && mood !== 'sleep') {
    for (const ex of [-7, 7]) {
      c.fillStyle = '#fffaf0'; c.beginPath(); c.arc(ex, -27, 6, 0, TAU); c.fill();
      c.fillStyle = INK; c.beginPath(); c.arc(ex + 1, -27, 3, 0, TAU); c.fill();
      c.fillStyle = '#fff'; c.beginPath(); c.arc(ex + 2, -28.5, 1, 0, TAU); c.fill();
    }
    if (o.glasses) {
      c.strokeStyle = INK; c.lineWidth = 2;
      c.beginPath(); c.arc(-7, -27, 7.5, 0, TAU); c.stroke();
      c.beginPath(); c.arc(7, -27, 7.5, 0, TAU); c.stroke();
      c.beginPath(); c.moveTo(-0.5, -27); c.lineTo(0.5, -27); c.stroke();
    }
  } else {
    eyes(c, -7, 7, -27, 8, mood === 'sleep' ? 'sleep' : 'sleepy', t);
  }
  c.fillStyle = '#f2a33a'; c.strokeStyle = INK; c.lineWidth = 1.5;
  c.beginPath(); c.moveTo(-3, -21); c.lineTo(3, -21); c.lineTo(0, -16); c.closePath(); c.fill(); c.stroke();
  c.restore();
}

export function drawPebble(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 22 * s);
  c.scale(s * flip, s);
  const bob = o.state === 'walk' ? -Math.abs(Math.sin((o.phase || 0) * TAU)) * 2 : 0;
  c.translate(0, bob);
  const arm = o.state === 'walk' ? Math.sin((o.phase || 0) * TAU) * 3 : 0;
  paper(c, p => {
    shape(c, p, ell(-23, -14 + arm, 7, 7), '#8a8798');
    shape(c, p, ell(-9, -2, 7, 4), '#6e6b7e');
    shape(c, p, ell(9, -2, 7, 4), '#6e6b7e');
    shape(c, p, rrect(-21, -40, 42, 38, 15), vgrad(c, -40, 0, '#b3b0c0', '#7d7a8e'));
    shape(c, p, ell(23, -14 - arm, 7, 7), '#8a8798');
    shape(c, p, ell(-3, -40, 11, 5), '#7cc46a', 1.8);
  });
  c.strokeStyle = 'rgba(43,34,53,0.45)'; c.lineWidth = 1.5;
  c.beginPath(); c.moveTo(-15, -12); c.lineTo(-10, -8); c.lineTo(-12, -3); c.stroke();
  c.beginPath(); c.moveTo(13, -33); c.lineTo(16, -28); c.stroke();
  eyes(c, -7, 8, -25, 9, o.mood, t);
  mouth(c, 1, -15, 6, o.mood);
  c.restore();
}

export function drawMothwick(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 18 * s);
  c.scale(s * flip, s);
  const fl = Math.sin(t * 2) * 0.06;
  paper(c, p => {
    shape(c, p, ell(-15, -42, 13, 21, -0.5 - fl), '#cdb8ef');
    shape(c, p, ell(15, -42, 13, 21, 0.5 + fl), '#cdb8ef');
    shape(c, p, rrect(16, -64, 4, 64, 2), '#8a5a3c');
    shape(c, p, ell(-5, -2, 5, 3), '#6b5a7a'); shape(c, p, ell(5, -2, 5, 3), '#6b5a7a');
    shape(c, p, ell(0, -24, 13, 19), vgrad(c, -43, -5, '#fbeec5', '#e2c98a'));
    shape(c, p, ell(0, -50, 12, 11), '#fbeec5');
    shape(c, p, rrect(12, -78, 12, 14, 3), '#3b3350');
  });
  c.fillStyle = 'rgba(155,120,200,0.35)';
  c.beginPath(); c.arc(-17, -45, 4, 0, TAU); c.fill(); c.beginPath(); c.arc(17, -45, 4, 0, TAU); c.fill();
  c.strokeStyle = INK; c.lineWidth = 1.8;
  c.beginPath(); c.moveTo(-4, -60); c.quadraticCurveTo(-8, -72, -14, -72); c.stroke();
  c.beginPath(); c.moveTo(4, -60); c.quadraticCurveTo(8, -72, 3, -75); c.stroke();
  glowDot(c, 18, -71, 22);
  flame(c, 18, -66, 0.45, t);
  eyes(c, -4, 5, -51, 7, o.mood, t);
  c.strokeStyle = INK; c.lineWidth = 1.5;
  c.beginPath(); c.arc(-4, -51, 5, 0, TAU); c.stroke(); c.beginPath(); c.arc(5, -51, 5, 0, TAU); c.stroke();
  mouth(c, 0.5, -44, 5, o.mood);
  c.restore();
}

export function drawCrane(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y - 8 + Math.sin(t * 2) * 3);
  if (o.shadow !== false) shadow(c, 0, 8, 16 * s);
  c.scale(s * flip, s);
  const flap = Math.sin(t * 3) * 6;
  paper(c, p => {
    shape(c, p, poly([[-18, -20], [-34, -36], [-24, -17]]), '#fdfdfd');
    shape(c, p, poly([[-4, -26], [-28, -54 - flap], [8, -28]]), '#f6d6e0');
    shape(c, p, poly([[-20, -20], [0, -33], [22, -20], [0, -11]]), vgrad(c, -33, -11, '#ffffff', '#e8e2ef'));
    shape(c, p, poly([[15, -22], [26, -52], [30, -50], [22, -20]]), '#fdfdfd');
    shape(c, p, poly([[26, -52], [39, -48], [29, -46]]), '#fdfdfd');
    shape(c, p, poly([[-2, -26], [18, -50 + flap], [12, -24]]), '#f9e3ea');
  });
  c.fillStyle = INK; c.beginPath(); c.arc(30, -49, 1.6, 0, TAU); c.fill();
  c.restore();
}

export function drawFolk(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  const color = o.color || '#e0604a', lit = o.lit ?? true;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 14 * s);
  c.scale(s * flip, s);
  c.translate(0, Math.sin(t * 2 + (o.seed || 0)) * 0.8);
  paper(c, p => {
    shape(c, p, ell(-5, -2, 5, 3), '#4a3d5c'); shape(c, p, ell(5, -2, 5, 3), '#4a3d5c');
    shape(c, p, rrect(-10, -26, 20, 23, 7), o.body || '#5a4a7a');
    shape(c, p, ell(0, -42, 16, 14), lit ? vgrad(c, -56, -28, '#fff1c9', color) : color);
    shape(c, p, rrect(-8, -58, 16, 5, 2), '#3b3350');
    shape(c, p, rrect(-8, -30, 16, 5, 2), '#3b3350');
  });
  c.strokeStyle = 'rgba(43,34,53,0.3)'; c.lineWidth = 1.4;
  for (const dx of [-9, 9]) { c.beginPath(); c.moveTo(dx * 0.6, -55); c.quadraticCurveTo(dx * 1.4, -42, dx * 0.6, -29); c.stroke(); }
  if (lit) glowDot(c, 0, -42, 30, '255,210,120', 0.25);
  eyes(c, -5, 5, -43, 7, o.mood, t);
  mouth(c, 0, -36, 5, o.mood);
  if (o.specs) {
    c.strokeStyle = INK; c.lineWidth = 1.6;
    c.beginPath(); c.arc(-5, -43, 5, 0, TAU); c.stroke(); c.beginPath(); c.arc(5, -43, 5, 0, TAU); c.stroke();
  }
  if (o.hat === 'straw') {
    paper(c, p => { shape(c, p, ell(0, -57, 25, 5), '#e8c66a', 2); shape(c, p, rrect(-11, -71, 22, 15, 6), '#e8c66a', 2); });
    c.fillStyle = '#c0504a'; c.fillRect(-11, -61, 22, 3);
  } else if (o.hat === 'bucket') {
    paper(c, p => shape(c, p, poly([[-19, -55], [19, -55], [12, -71], [-12, -71]]), '#7a9a5a', 2));
  } else if (o.hat === 'feather') {
    paper(c, p => { shape(c, p, rrect(-13, -67, 26, 11, 5), '#3d6b4a', 2); shape(c, p, ell(13, -75, 4, 11, 0.5), '#e5534b', 1.6); });
  } else if (o.hat === 'crown') {
    paper(c, p => shape(c, p, poly([[-11, -56], [-11, -68], [-5, -62], [0, -71], [5, -62], [11, -68], [11, -56]]), '#ffd23f', 1.8));
  }
  c.restore();
}

export function drawAcorn(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 12 * s);
  c.scale(s * flip, s);
  c.rotate(Math.sin(t * 1.2) * 0.05);
  paper(c, p => {
    shape(c, p, ell(0, -15, 12, 15), vgrad(c, -30, 0, '#d9a066', '#b87a42'));
    shape(c, p, ell(0, -29, 14, 7), '#7a5232');
    shape(c, p, rrect(-1.5, -40, 3, 7, 1.5), '#5a3a22');
  });
  eyes(c, -4, 4, -17, 6, o.mood || 'sleepy', t);
  mouth(c, 0, -10, 4, o.mood || 'sleepy');
  c.restore();
}

// ---------------------------------------------------------------- enemies
export function drawGloomling(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 18 * s);
  c.scale(s * flip, s * (1 + Math.sin(t * 4) * 0.04));
  paper(c, p => {
    shape(c, p, cc => {
      cc.moveTo(-19, 0); cc.lineTo(19, 0); cc.quadraticCurveTo(23, -14, 16, -22);
      for (const [px, py] of [[12, -32], [7, -24], [2, -36], [-4, -25], [-9, -33], [-14, -22]]) cc.lineTo(px, py + Math.sin(t * 5 + px) * 1.5);
      cc.quadraticCurveTo(-23, -14, -19, 0); cc.closePath();
    }, vgrad(c, -36, 0, '#64478f', '#2c1d45'));
  });
  for (const ex of [3, 11]) {
    glowDot(c, ex, -16, 9, '255,224,102', 0.5);
    c.fillStyle = '#ffe066'; c.beginPath(); c.ellipse(ex, -16, 3.2, 4.2, 0, 0, TAU); c.fill();
    c.fillStyle = INK; c.beginPath(); c.ellipse(ex + 0.8, -16, 1, 2.6, 0, 0, TAU); c.fill();
  }
  c.strokeStyle = '#ffe066'; c.lineWidth = 1.8;
  c.beginPath(); c.moveTo(-1, -22); c.lineTo(6, -20); c.moveTo(15, -22); c.lineTo(9, -20); c.stroke();
  c.fillStyle = '#fffaf0';
  c.beginPath(); c.moveTo(-2, -8); for (let i = 0; i < 5; i++) { c.lineTo(i * 3.2, -8 + (i % 2 ? 3.5 : 0)); } c.lineTo(14, -8); c.closePath(); c.fill();
  c.restore();
}

export function drawSpikeshroom(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 20 * s);
  c.scale(s * flip, s);
  c.rotate(Math.sin(t * 3) * 0.04);
  const capY = x0 => -20 - 19.5 * (1 - (x0 / 24) ** 2);
  paper(c, p => {
    shape(c, p, rrect(-11, -24, 22, 24, 8), '#f3e3c3');
    for (const sx of [-16, -8, 0, 8, 16]) {
      const by = capY(sx);
      shape(c, p, poly([[sx - 4.5, by + 3], [sx * 1.2, by - 9], [sx + 4.5, by + 3]]), '#fff4e0', 1.8);
    }
    shape(c, p, cc => { cc.moveTo(-24, -20); cc.bezierCurveTo(-24, -46, 24, -46, 24, -20); cc.closePath(); }, vgrad(c, -40, -20, '#dd6a8c', '#a33a5b'));
  });
  c.fillStyle = 'rgba(255,255,255,0.35)'; c.beginPath(); c.ellipse(-8, -32, 6, 3, -0.3, 0, TAU); c.fill();
  eyes(c, -3, 6, -12, 7, o.mood || 'angry', t);
  c.restore();
}

export function drawBuzzbug(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  c.scale(s * flip, s);
  const flap = 0.4 + Math.abs(Math.sin(t * 28)) * 0.6;
  paper(c, p => {
    shape(c, p, ell(-4, -27, 8, 12 * flap, -0.4), 'rgba(222,240,255,0.9)', 1.6);
    shape(c, p, ell(6, -28, 8, 12 * flap, 0.4), 'rgba(222,240,255,0.9)', 1.6);
    shape(c, p, poly([[-14, -13], [-24, -11], [-14, -8]]), '#2b2235', 1.4);
    shape(c, p, ell(0, -12, 15, 12), '#ffd23f');
  });
  c.save(); c.beginPath(); c.ellipse(0, -12, 15, 12, 0, 0, TAU); c.clip();
  c.fillStyle = '#2b2235'; c.fillRect(-9, -26, 5, 28); c.fillRect(-1, -26, 4, 28);
  c.restore();
  c.strokeStyle = INK; c.lineWidth = 2.4; c.beginPath(); c.ellipse(0, -12, 15, 12, 0, 0, TAU); c.stroke();
  c.lineWidth = 1.6; c.beginPath(); c.moveTo(8, -22); c.quadraticCurveTo(12, -32, 16, -31); c.stroke();
  eyes(c, 6, 12, -14, 7, o.mood || 'angry', t);
  c.restore();
}

export function drawInkblot(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 18 * s);
  c.scale(s * flip, s);
  paper(c, p => {
    shape(c, p, cc => {
      for (let i = 0; i <= 40; i++) {
        const a = (i / 40) * TAU, r = 17 + 3.5 * Math.sin(5 * a + t * 3);
        const px = Math.cos(a) * r, py = -17 + Math.sin(a) * r * 0.92;
        i ? cc.lineTo(px, py) : cc.moveTo(px, py);
      }
      cc.closePath();
    }, '#1f1b33');
    shape(c, p, ell(-9, -1, 3, 4 + Math.sin(t * 2) * 1.5), '#1f1b33', 1.6);
    shape(c, p, ell(8, 0, 2.5, 3), '#1f1b33', 1.6);
  });
  c.strokeStyle = 'rgba(140,160,255,0.35)'; c.lineWidth = 2.5;
  c.beginPath(); c.arc(-4, -21, 9, Math.PI * 1.1, Math.PI * 1.5); c.stroke();
  for (const ex of [-1, 8]) {
    c.fillStyle = '#fff'; c.beginPath(); c.ellipse(ex, -19, 4, 5, 0, 0, TAU); c.fill();
    c.fillStyle = INK; c.beginPath(); c.arc(ex + 1, -18, 2, 0, TAU); c.fill();
  }
  c.restore();
}

export function drawShellcrab(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 22 * s);
  c.scale(s * flip, s);
  const snap = Math.sin(t * 5) * 0.2;
  paper(c, p => {
    for (const lx of [-12, -6, 6, 12]) shape(c, p, rrect(lx - 1.5, -6, 3, 7, 1.5), '#c2553f', 1.4);
    shape(c, p, ell(-22, -18, 7, 6, snap), '#e0735a');
    shape(c, p, ell(22, -18, 7, 6, -snap), '#e0735a');
    shape(c, p, ell(0, -11, 17, 10), vgrad(c, -21, -1, '#ee8a6e', '#c95b44'));
    shape(c, p, poly([[-13, -17], [-5, -35], [6, -37], [14, -19]]), vgrad(c, -37, -17, '#a6f3e8', '#3aa79c'));
    shape(c, p, rrect(-7, -30, 2.6, 12, 1.2), '#c95b44', 1.4);
    shape(c, p, rrect(4, -30, 2.6, 12, 1.2), '#c95b44', 1.4);
  });
  c.strokeStyle = 'rgba(255,255,255,0.7)'; c.lineWidth = 1.5;
  c.beginPath(); c.moveTo(-5, -34); c.lineTo(-1, -19); c.moveTo(6, -36); c.lineTo(4, -19); c.stroke();
  for (const ex of [-6, 5]) {
    c.fillStyle = '#fff'; c.beginPath(); c.arc(ex, -31, 3.5, 0, TAU); c.fill(); c.strokeStyle = INK; c.lineWidth = 1.4; c.stroke();
    c.fillStyle = INK; c.beginPath(); c.arc(ex + 0.8, -31, 1.6, 0, TAU); c.fill();
  }
  c.restore();
}

export function drawGlowbat(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  c.scale(s * flip, s);
  const f = Math.sin(t * 12) * 9;
  paper(c, p => {
    shape(c, p, poly([[-6, -20], [-30, -30 - f], [-24, -16 - f * 0.4], [-28, -8], [-16, -12], [-8, -10]]), '#46386e');
    shape(c, p, poly([[6, -20], [30, -30 - f], [24, -16 - f * 0.4], [28, -8], [16, -12], [8, -10]]), '#46386e');
    shape(c, p, poly([[-8, -24], [-6, -36], [-1, -27]]), '#5b4a8a');
    shape(c, p, poly([[8, -24], [6, -36], [1, -27]]), '#5b4a8a');
    shape(c, p, ell(0, -18, 10, 10), vgrad(c, -28, -8, '#6d5aa3', '#46386e'));
  });
  for (const ex of [-4, 4]) {
    glowDot(c, ex, -20, 8, '156,255,138', 0.6);
    c.fillStyle = '#9cff8a'; c.beginPath(); c.ellipse(ex, -20, 2.4, 3, 0, 0, TAU); c.fill();
  }
  c.fillStyle = '#fff'; c.beginPath(); c.moveTo(-3, -13); c.lineTo(-1.5, -9); c.lineTo(0, -13); c.moveTo(1, -13); c.lineTo(2.5, -9); c.lineTo(4, -13); c.fill();
  c.restore();
}

export function drawGrumblecap(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'angry';
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 30 * s);
  c.scale(s * flip, s);
  const breath = Math.sin(t * (mood === 'sleep' ? 1.5 : 3)) * 0.03;
  c.scale(1 + breath, 1 - breath);
  paper(c, p => {
    shape(c, p, rrect(-21, -38, 42, 38, 14), vgrad(c, -38, 0, '#f6e7c8', '#dcc69c'));
    shape(c, p, ell(-24, -16, 6, 6), '#f0dfbd');
    shape(c, p, rrect(22, -46, 4, 40, 2), '#8a5a3c');
    shape(c, p, ell(24, -48, 6, 6), '#ffd23f');
    shape(c, p, ell(23, -16, 6, 6), '#f0dfbd');
    shape(c, p, cc => {
      cc.moveTo(-15, -14);
      for (let i = 0; i <= 6; i++) cc.quadraticCurveTo(-15 + i * 5 - 2.5, -2 + (i % 2) * 3, -15 + i * 5, -10);
      cc.lineTo(15, -14); cc.closePath();
    }, '#6fae54', 1.8);
    shape(c, p, cc => { cc.moveTo(-34, -34); cc.bezierCurveTo(-36, -76, 36, -76, 34, -34); cc.closePath(); }, vgrad(c, -68, -34, '#cf6a4c', '#a8452e'));
    shape(c, p, poly([[-14, -64], [-10, -78], [-4, -68], [0, -82], [4, -68], [10, -78], [14, -64]]), vgrad(c, -82, -64, '#ffe27a', '#e8a92a'));
  });
  c.fillStyle = '#fbefd5';
  for (const [sx, sy, r] of [[-20, -46, 5], [-4, -58, 4], [14, -50, 6], [24, -40, 3]]) { c.beginPath(); c.arc(sx, sy, r, 0, TAU); c.fill(); }
  eyes(c, -8, 8, -26, 8, mood === 'sleep' ? 'sleep' : 'angry', t);
  if (mood !== 'sleep') {
    c.strokeStyle = INK; c.lineWidth = 3;
    c.beginPath(); c.moveTo(-14, -34); c.lineTo(-3, -31); c.moveTo(14, -34); c.lineTo(3, -31); c.stroke();
  }
  c.restore();
}

export function drawSmudge(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'angry';
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 26 * s, 0.25);
  c.scale(s * flip, s);
  if (o.invisible) c.globalAlpha = 0.25;
  c.translate(0, Math.sin(t * 2) * 2 - 4);
  paper(c, p => {
    shape(c, p, cc => {
      cc.moveTo(-14, -42); cc.lineTo(14, -42); cc.lineTo(26, -4);
      for (let i = 0; i <= 6; i++) { const px = 26 - i * (52 / 6); cc.quadraticCurveTo(px + 4, 4 + (i % 2) * 5 + Math.sin(t * 3 + i) * 2, px, -2); }
      cc.closePath();
    }, vgrad(c, -42, 0, '#3c3766', '#211d3a'));
    shape(c, p, ell(-16, -26, 5, 9, 0.4), '#3c3766');
    shape(c, p, rrect(15, -52, 3.5, 30, 1.5), '#f1ead7');
    shape(c, p, poly([[16.5, -52], [10, -66], [24, -60]]), '#fffaf0', 1.6);
    shape(c, p, ell(0, -52, 13, 13), '#e7defa');
    shape(c, p, ell(0, -62, 23, 5), '#3a2f5e');
    shape(c, p, poly([[-12, -63], [12, -63], [6, -86], [20, -96], [-2, -88]]), vgrad(c, -96, -63, '#4b3f7a', '#2f2650'));
  });
  c.fillStyle = '#1f1b33';
  c.beginPath(); c.ellipse(18, -21 + Math.sin(t * 2) * 2, 2, 3, 0, 0, TAU); c.fill();
  eyes(c, -4, 6, -52, 8, mood, t);
  c.fillStyle = '#b24a8a'; c.beginPath(); c.ellipse(1, -45, 3, 1.6, 0, 0, TAU); c.fill();
  c.restore();
}

export function drawDusk(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  c.scale(s * flip, s);
  c.translate(0, Math.sin(t * 1.5) * 4 - 10);
  paper(c, p => {
    shape(c, p, poly([[-26, 0], [26, 0], [16, -62], [-16, -62]]), vgrad(c, -62, 0, '#2c2350', '#120e22'));
    shape(c, p, poly([[-22, -58], [-30, -76], [-10, -62], [0, -70], [10, -62], [30, -76], [22, -58]]), '#3b2f6a');
    shape(c, p, cc => { cc.arc(0, -80, 16, 0.6, TAU - 0.6); cc.arc(9, -80, 12, TAU - 0.9, 0.9, true); cc.closePath(); }, '#ddd6fb');
  });
  for (const ex of [-6, 2]) { glowDot(c, ex, -82, 8, '255,90,110', 0.7); c.fillStyle = '#ff5a6e'; c.beginPath(); c.arc(ex, -82, 2, 0, TAU); c.fill(); }
  c.restore();
}

// ---------------------------------------------------------------- props
export function drawBlock(c, x, y, o = {}) {
  const t = o.t || 0, used = o.used, sz = o.size || 44;
  y -= o.bump || 0;
  paper(c, p => {
    shape(c, p, rrect(x, y, sz, sz, 6), used ? vgrad(c, y, y + sz, '#bf9b6e', '#8f6b44') : vgrad(c, y, y + sz, '#ffe27a', '#efa62a'));
  });
  if (!used) {
    const pulse = 1 + Math.sin(t * 4) * 0.06;
    c.save(); c.translate(x + sz / 2, y + sz / 2); c.scale(pulse, pulse);
    c.beginPath(); starPath(c, 0, 0, 12, 5.5); c.fillStyle = '#fffaf0'; c.fill(); c.lineWidth = 2; c.strokeStyle = INK; c.stroke();
    c.restore();
  } else {
    c.fillStyle = 'rgba(43,34,53,0.5)';
    for (const [dx, dy] of [[8, 8], [sz - 8, 8], [8, sz - 8], [sz - 8, sz - 8]]) { c.beginPath(); c.arc(x + dx, y + dy, 2.5, 0, TAU); c.fill(); }
  }
}

export function drawChest(c, x, y, o = {}) {
  const open = o.open;
  paper(c, p => {
    shape(c, p, rrect(x - 22, y - 26, 44, 26, 4), vgrad(c, y - 26, y, '#a8693a', '#7a4a26'));
    if (open) shape(c, p, rrect(x - 22, y - 40, 44, 12, 5), '#b97a45');
    else shape(c, p, cc => { cc.moveTo(x - 22, y - 26); cc.quadraticCurveTo(x, y - 46, x + 22, y - 26); cc.closePath(); }, '#b97a45');
  });
  c.fillStyle = '#f2c14e'; c.fillRect(x - 4, y - (open ? 30 : 32), 8, 10);
  if (!open) { c.fillStyle = 'rgba(255,230,120,0.9)'; c.fillRect(x - 23, y - 27, 46, 3); }
}

export function drawLamp(c, x, y, o = {}) {
  const t = o.t || 0, lit = o.lit;
  if (lit) glowDot(c, x, y - 92, 70, '255,210,120', 0.35);
  paper(c, p => {
    shape(c, p, rrect(x - 4, y - 84, 8, 84, 3), '#3b3350');
    shape(c, p, rrect(x - 12, y - 6, 24, 6, 2), '#3b3350');
    shape(c, p, rrect(x - 13, y - 104, 26, 22, 5), lit ? vgrad(c, y - 104, y - 82, '#fff2c4', '#ffc35a') : '#5a5070');
    shape(c, p, poly([[x - 15, y - 104], [x, y - 116], [x + 15, y - 104]]), '#3b3350');
  });
  if (lit) flame(c, x, y - 86, 0.6, t);
}

export function drawSign(c, x, y) {
  paper(c, p => {
    shape(c, p, rrect(x - 3, y - 40, 6, 40, 2), '#8a5a3c');
    shape(c, p, rrect(x - 22, y - 58, 44, 26, 4), vgrad(c, y - 58, y - 32, '#d9a066', '#b07a45'));
  });
  c.strokeStyle = 'rgba(43,34,53,0.5)'; c.lineWidth = 2;
  for (const dy of [-50, -43]) { c.beginPath(); c.moveTo(x - 13, y + dy); c.lineTo(x + 13, y + dy); c.stroke(); }
}

export function drawCrack(c, x, y, w, h, theme = 'grove') {
  const base = theme === 'cave' ? ['#5d4f80', '#3f3460'] : ['#9d97a8', '#6f6a7c'];
  paper(c, p => { shape(c, p, rrect(x, y, w, h, 6), vgrad(c, y, y + h, base[0], base[1])); });
  c.strokeStyle = 'rgba(43,34,53,0.35)'; c.lineWidth = 1.5;
  for (let yy = y + 24; yy < y + h; yy += 24) { c.beginPath(); c.moveTo(x + 3, yy); c.lineTo(x + w - 3, yy); c.stroke(); }
  c.strokeStyle = INK; c.lineWidth = 2.4;
  c.beginPath(); c.moveTo(x + w * 0.5, y + 6); c.lineTo(x + w * 0.35, y + h * 0.3); c.lineTo(x + w * 0.62, y + h * 0.5);
  c.lineTo(x + w * 0.4, y + h * 0.72); c.lineTo(x + w * 0.55, y + h - 6); c.stroke();
}

export function drawDoor(c, x, y, o = {}) {
  if (o.style === 'hole') {
    paper(c, p => shape(c, p, cc => { cc.moveTo(x - 40, y); cc.quadraticCurveTo(x - 30, y - 44, x, y - 46); cc.quadraticCurveTo(x + 30, y - 44, x + 40, y); cc.closePath(); }, vgrad(c, y - 46, y, '#a8794e', '#7a5232')));
    c.fillStyle = '#2a1a12'; c.beginPath(); c.ellipse(x, y - 13, 15, 13, 0, 0, TAU); c.fill();
    c.fillStyle = '#7ccf5e';
    for (const dx of [-18, 2, 20]) { c.beginPath(); c.moveTo(x + dx - 5, y - 40 + Math.abs(dx) * 0.5); c.lineTo(x + dx, y - 50 + Math.abs(dx) * 0.5); c.lineTo(x + dx + 5, y - 40 + Math.abs(dx) * 0.5); c.fill(); }
    return;
  }
  if (o.style === 'log') {
    paper(c, p => {
      shape(c, p, rrect(x - 90, y - 62, 120, 62, 24), vgrad(c, y - 62, y, '#9a6a45', '#6e4529'));
      shape(c, p, ell(x + 28, y - 34, 30, 33), '#c58b55');
    });
    c.strokeStyle = 'rgba(110,69,41,0.6)'; c.lineWidth = 2;
    for (const r of [24, 17]) { c.beginPath(); c.ellipse(x + 28, y - 34, r * 0.9, r, 0, 0, TAU); c.stroke(); }
    c.fillStyle = '#2a1a12'; c.beginPath(); c.ellipse(x + 28, y - 30, 15, 18, 0, 0, TAU); c.fill();
    return;
  }
  if (o.style === 'crawl') {
    c.fillStyle = '#120c1e'; c.beginPath(); c.ellipse(x, y - 8, 22, 16, 0, Math.PI, TAU); c.fill();
    paper(c, p => shape(c, p, cc => {
      cc.moveTo(x - 50, y); cc.lineTo(x - 48, y - 40); cc.quadraticCurveTo(x, y - 74, x + 48, y - 40); cc.lineTo(x + 50, y);
      cc.lineTo(x + 22, y); cc.quadraticCurveTo(x + 22, y - 26, x, y - 26); cc.quadraticCurveTo(x - 22, y - 26, x - 22, y); cc.closePath();
    }, vgrad(c, y - 60, y, '#6d5a99', '#3f3460')));
    return;
  }
  paper(c, p => {
    shape(c, p, cc => { cc.moveTo(x - 30, y); cc.lineTo(x - 30, y - 70); cc.arc(x, y - 70, 30, Math.PI, 0); cc.lineTo(x + 30, y); cc.closePath(); }, o.locked ? '#5a4c6e' : vgrad(c, y - 100, y, '#a8693a', '#6e4224'));
  });
  c.strokeStyle = 'rgba(43,34,53,0.4)'; c.lineWidth = 2;
  for (const dx of [-10, 10]) { c.beginPath(); c.moveTo(x + dx, y - 92); c.lineTo(x + dx, y - 4); c.stroke(); }
  c.fillStyle = '#f2c14e'; c.beginPath(); c.arc(x + 18, y - 40, 3.5, 0, TAU); c.fill();
  if (o.locked) { c.font = 'bold 22px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#fffaf0'; c.fillText('🔒', x, y - 50); }
}

export function drawShrine(c, x, y, o = {}) {
  const t = o.t || 0;
  if (!o.used) glowDot(c, x, y - 70, 70, '170,220,255', 0.35 + Math.sin(t * 2) * 0.1);
  paper(c, p => {
    shape(c, p, rrect(x - 34, y - 14, 68, 14, 4), '#8d88a0');
    shape(c, p, rrect(x - 24, y - 84, 48, 72, 8), vgrad(c, y - 84, y - 12, '#c9c4d8', '#9a94ad'));
    shape(c, p, poly([[x - 32, y - 84], [x, y - 104], [x + 32, y - 84]]), '#7c7692');
  });
  c.save(); c.translate(x, y - 50 + Math.sin(t * 2) * 3);
  c.beginPath(); starPath(c, 0, 0, 13, 6); c.fillStyle = o.used ? '#d9d4e6' : '#bfe6ff'; c.fill(); c.lineWidth = 2; c.strokeStyle = INK; c.stroke();
  c.restore();
}

export function drawCoin(c, x, y, t = 0, r = 9) {
  const sx = Math.abs(Math.cos(t * 4)) * 0.85 + 0.15;
  c.save(); c.translate(x, y); c.scale(sx, 1);
  c.beginPath(); c.arc(0, 0, r, 0, TAU); c.fillStyle = '#ffd23f'; c.fill(); c.lineWidth = 2; c.strokeStyle = INK; c.stroke();
  c.beginPath(); c.arc(0, 0, r * 0.55, 0, TAU); c.strokeStyle = '#e8a92a'; c.stroke();
  c.restore();
}

export function drawStarPiece(c, x, y, t = 0, s = 1) {
  glowDot(c, x, y, 26 * s, '255,230,120', 0.45);
  c.save(); c.translate(x, y); c.rotate(Math.sin(t * 2) * 0.2); c.scale(s, s);
  c.beginPath(); starPath(c, 0, 0, 13, 6); c.fillStyle = '#ffe066'; c.fill(); c.lineWidth = 2.2; c.strokeStyle = INK; c.stroke();
  c.restore();
}

export function drawShard(c, x, y, t = 0, s = 1, color = '#9fe6ff') {
  glowDot(c, x, y, 60 * s, '180,235,255', 0.55);
  c.save(); c.translate(x, y + Math.sin(t * 2) * 4); c.rotate(t * 0.6); c.scale(s, s);
  paper(c, p => {
    shape(c, p, cc => starPath(cc, 0, 0, 22, 10, 4), color);
  });
  c.fillStyle = 'rgba(255,255,255,0.7)'; c.beginPath(); starPath(c, -3, -3, 7, 3, 4); c.fill();
  c.restore();
}

export function drawBrokenLantern(c, x, y, shards, t = 0) {
  if (shards > 0) glowDot(c, x, y - 140, 60 + shards * 30, '255,214,120', 0.2 + shards * 0.1);
  paper(c, p => {
    shape(c, p, rrect(x - 40, y - 30, 80, 30, 6), '#6b6080');
    shape(c, p, rrect(x - 8, y - 120, 16, 92, 4), '#4a4060');
    shape(c, p, rrect(x - 36, y - 190, 72, 76, 14), shards > 0 ? vgrad(c, y - 190, y - 114, '#fff2c4', '#ffb84a') : '#463c5c');
    shape(c, p, poly([[x - 42, y - 190], [x, y - 222], [x + 42, y - 190]]), '#3b3350');
  });
  for (let i = 0; i < 5; i++) {
    const a = -Math.PI / 2 + (i / 5) * TAU, sx = x + Math.cos(a) * 22, sy = y - 152 + Math.sin(a) * 22;
    c.beginPath(); starPath(c, sx, sy, 7, 3, 4);
    c.fillStyle = i < shards ? '#bff0ff' : 'rgba(30,20,50,0.6)'; c.fill(); c.lineWidth = 1.5; c.strokeStyle = INK; c.stroke();
  }
  if (shards > 0) flame(c, x, y - 128, 0.6 + shards * 0.25, t);
}

// ---------------------------------------------------------------- scenery
function ridge(c, W, H, camX, f, base, amp, color, seed, edge = 'rgba(255,250,240,0.75)') {
  const off = camX * f;
  const yAt = x => { const wx = x + off; return base - amp * (0.6 * Math.sin(wx * 0.004 + seed) + 0.4 * Math.sin(wx * 0.011 + seed * 2.3)); };
  c.beginPath(); c.moveTo(0, H);
  for (let x = 0; x <= W + 20; x += 16) c.lineTo(x, yAt(x));
  c.lineTo(W, H); c.closePath(); c.fillStyle = color; c.fill();
  c.beginPath(); for (let x = 0; x <= W + 20; x += 16) x ? c.lineTo(x, yAt(x)) : c.moveTo(x, yAt(x));
  c.lineWidth = 4; c.strokeStyle = edge; c.stroke();
}

function tree(c, x, y, s, col, trunk = '#7a5232') {
  paper(c, p => {
    shape(c, p, rrect(x - 5 * s, y - 40 * s, 10 * s, 40 * s, 3), trunk, 2);
    shape(c, p, ell(x, y - 58 * s, 26 * s, 26 * s), col, 2);
  });
  c.fillStyle = 'rgba(255,255,255,0.18)'; c.beginPath(); c.ellipse(x - 8 * s, y - 66 * s, 9 * s, 6 * s, -0.4, 0, TAU); c.fill();
}

function house(c, x, y, w, h, col, roof, lit, t) {
  paper(c, p => {
    shape(c, p, rrect(x, y - h, w, h, 4), col, 2);
    shape(c, p, poly([[x - 8, y - h], [x + w / 2, y - h - w * 0.5], [x + w + 8, y - h]]), roof, 2);
  });
  c.fillStyle = lit ? '#ffd67a' : '#2a2340';
  c.fillRect(x + w * 0.2, y - h * 0.7, w * 0.22, h * 0.25); c.fillRect(x + w * 0.58, y - h * 0.7, w * 0.22, h * 0.25);
  if (lit) glowDot(c, x + w / 2, y - h * 0.58, w * 0.7, '255,210,120', 0.18);
}

const STARS = Array.from({ length: 60 }, (_, i) => [(i * 137.5) % 960, (i * 59.3) % 260, (i % 3) + 1]);

export function drawBackdrop(c, theme, camX, W, H, t, opts = {}) {
  if (theme === 'night' || theme === 'town') {
    const lit = opts.lit || 0;
    const g = c.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, lit ? '#3b3f86' : '#141432'); g.addColorStop(1, lit ? '#e7a17a' : '#3a2f5e');
    c.fillStyle = g; c.fillRect(0, 0, W, H);
    for (const [sx, sy, r] of STARS) { c.fillStyle = `rgba(255,250,220,${0.4 + 0.4 * Math.sin(t * 2 + sx)})`; c.fillRect((sx - camX * 0.05 + W) % W, sy, r, r); }
    c.fillStyle = '#fff4d6'; c.beginPath(); c.arc(820 - camX * 0.04, 90, 32, 0, TAU); c.fill();
    c.fillStyle = lit ? '#3b3f86' : '#141432'; c.beginPath(); c.arc(806 - camX * 0.04, 82, 28, 0, TAU); c.fill();
    if (opts.horizon) opts.horizon(lit ? 'dusk' : 'night');   // far-off landmarks, behind the hills
    ridge(c, W, H, camX, 0.15, 330, 30, lit ? '#5b5596' : '#2a2550', 1);
    const spacing = 230, off = (camX * 0.35) % spacing;
    for (let i = -1; i < W / spacing + 2; i++) {
      const hx = i * spacing - off, seed = Math.floor((camX * 0.35) / spacing) + i;
      house(c, hx, 400, 70 + (seed % 3) * 14, 60 + (seed % 2) * 20, lit ? '#8a7aa8' : '#3d3560', lit ? '#c45a5a' : '#2d2648', lit > 0 || seed % 4 === 0, t);
    }
    return;
  }
  if (theme === 'grove') {
    const gloom = opts.gloom;
    const g = c.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, gloom ? '#7d86a8' : '#9fd8ea'); g.addColorStop(1, gloom ? '#c9c4d6' : '#eef7d9');
    c.fillStyle = g; c.fillRect(0, 0, W, H);
    for (let i = 0; i < 4; i++) {
      const cx = ((i * 300 - camX * 0.08) % (W + 200) + W + 200) % (W + 200) - 100;
      c.fillStyle = 'rgba(255,255,255,0.85)';
      c.beginPath(); c.ellipse(cx, 70 + i * 22, 50, 16, 0, 0, TAU); c.ellipse(cx + 30, 62 + i * 22, 34, 18, 0, 0, TAU); c.fill();
    }
    if (opts.horizon) opts.horizon('day');
    ridge(c, W, H, camX, 0.12, 300, 40, gloom ? '#8f99a6' : '#a8d79a', 0.5);
    ridge(c, W, H, camX, 0.3, 360, 30, gloom ? '#6f7e86' : '#79bf6c', 2.1);
    const spacing = 170, off = (camX * 0.5) % spacing;
    for (let i = -1; i < W / spacing + 2; i++) {
      const seed = Math.floor((camX * 0.5) / spacing) + i;
      tree(c, i * spacing - off + (seed % 3) * 20, 430, 0.9 + (seed % 2) * 0.25, gloom ? '#5d7a66' : (seed % 2 ? '#4f9a52' : '#5fae5c'));
    }
    if (gloom) { c.fillStyle = 'rgba(60,40,90,0.18)'; c.fillRect(0, 0, W, H); }
    return;
  }
  if (theme === 'cave') {
    const bright = opts.bright;
    const g = c.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, bright ? '#2d2b55' : '#17122a'); g.addColorStop(1, bright ? '#4a3f7a' : '#2e2148');
    c.fillStyle = g; c.fillRect(0, 0, W, H);
    const spacing = 120, off = (camX * 0.3) % spacing;
    for (let i = -1; i < W / spacing + 2; i++) {
      const seed = Math.abs(Math.floor((camX * 0.3) / spacing) + i);
      const sx = i * spacing - off, len = 50 + (seed * 37) % 80;
      c.beginPath(); c.moveTo(sx - 22, 0); c.lineTo(sx, len); c.lineTo(sx + 22, 0); c.closePath();
      c.fillStyle = '#3b2d5c'; c.fill(); c.lineWidth = 3; c.strokeStyle = 'rgba(255,250,240,0.25)'; c.stroke();
      if (seed % 3 === 0) {
        glowDot(c, sx + 40, 300 + (seed % 5) * 20, 30, bright ? '160,240,255' : '110,180,220', 0.5);
        c.beginPath(); starPath(c, sx + 40, 300 + (seed % 5) * 20, 8, 3, 4); c.fillStyle = bright ? '#bff0ff' : '#7fb8d6'; c.fill();
      }
    }
    ridge(c, W, H, camX, 0.25, 380, 25, '#2a2045', 3.3, 'rgba(255,250,240,0.2)');
    return;
  }
  const sky = (a, b) => { const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, a); g.addColorStop(1, b); c.fillStyle = g; c.fillRect(0, 0, W, H); };
  const clouds = (n, alpha = 0.9) => {
    for (let i = 0; i < n; i++) {
      const cx = ((i * 330 - camX * 0.08 + t * 6) % (W + 260) + W + 260) % (W + 260) - 130;
      c.fillStyle = `rgba(255,255,255,${alpha})`;
      c.beginPath(); c.ellipse(cx, 70 + i * 26, 54, 16, 0, 0, TAU); c.ellipse(cx + 32, 61 + i * 26, 36, 18, 0, 0, TAU); c.fill();
    }
  };
  if (theme === 'fields' || theme === 'garden') {
    const garden = theme === 'garden';
    sky(garden ? '#ffd6e8' : '#9fd8f0', garden ? '#fff6e0' : '#fdf3d6');
    clouds(3);
    if (opts.horizon) opts.horizon('day');
    ridge(c, W, H, camX, 0.1, 310, 35, garden ? '#f3c4d8' : '#b9e3a0', 0.8);
    ridge(c, W, H, camX, 0.28, 372, 26, garden ? '#e6a8c4' : '#8fcf74', 2.6);
    const spacing = 90, off = (camX * 0.28) % spacing;
    for (let i = -1; i < W / spacing + 2; i++) {
      const seed = Math.abs(Math.floor((camX * 0.28) / spacing) + i);
      const fx = i * spacing - off + (seed * 23) % 40, fy = 392 + (seed % 3) * 8;
      c.fillStyle = ['#fffaf0', '#ffd23f', '#ff9ab0', '#b49cff'][seed % 4];
      c.beginPath(); starPath(c, fx, fy, 5, 2.5, 5); c.fill();
    }
    if (!garden) {
      const ts = 260, toff = (camX * 0.5) % ts;
      for (let i = -1; i < W / ts + 2; i++) {
        const seed = Math.floor((camX * 0.5) / ts) + i;
        if (seed % 3 === 0) tree(c, i * ts - toff + 40, 432, 1, '#5fae5c');
      }
    }
    return;
  }
  if (theme === 'lake') {
    sky('#9fd0ec', '#eaf6fa');
    clouds(3);
    if (opts.horizon) opts.horizon('day');
    ridge(c, W, H, camX, 0.06, 300, 50, '#9fb8d8', 1.4);
    c.fillStyle = '#6fb3d9'; c.fillRect(0, 352, W, H - 352);
    c.strokeStyle = 'rgba(255,255,255,0.5)'; c.lineWidth = 2;
    for (let i = 0; i < 9; i++) { const wx = ((i * 140 - camX * 0.2 + t * 10) % (W + 100) + W + 100) % (W + 100) - 50; c.beginPath(); c.moveTo(wx, 372 + (i % 3) * 22); c.lineTo(wx + 30, 372 + (i % 3) * 22); c.stroke(); }
    ridge(c, W, H, camX, 0.35, 420, 14, '#86c46e', 3.1);
    return;
  }
  if (theme === 'mountain') {
    sky('#b8c8e8', '#eef0f6');
    clouds(2, 0.7);
    if (opts.horizon) opts.horizon('day');
    const peaks = (f, base, hgt, col, snow, seed) => {
      const sp = 300, off = (camX * f) % sp;
      for (let i = -1; i < W / sp + 2; i++) {
        const k = Math.abs(Math.floor((camX * f) / sp) + i + seed);
        const px = i * sp - off + (k * 37) % 80, ph = hgt + (k * 53) % 60;
        c.fillStyle = col; c.beginPath(); c.moveTo(px - 170, base); c.lineTo(px, base - ph); c.lineTo(px + 170, base); c.closePath(); c.fill();
        c.fillStyle = snow; c.beginPath(); c.moveTo(px - 40, base - ph + 55); c.lineTo(px, base - ph); c.lineTo(px + 40, base - ph + 55); c.quadraticCurveTo(px, base - ph + 40, px - 40, base - ph + 55); c.fill();
      }
    };
    peaks(0.08, 380, 220, '#8f9bb8', '#f4f6ff', 0);
    peaks(0.22, 420, 150, '#6f7a96', '#e6eaf4', 5);
    const ps = 120, poff = (camX * 0.45) % ps;
    for (let i = -1; i < W / ps + 2; i++) {
      const px = i * ps - poff, k = Math.abs(Math.floor((camX * 0.45) / ps) + i);
      if (k % 2) continue;
      c.fillStyle = '#3f6b4a'; c.beginPath(); c.moveTo(px - 22, 440); c.lineTo(px, 360); c.lineTo(px + 22, 440); c.closePath(); c.fill();
    }
    return;
  }
  if (theme === 'maze') {
    sky('#56664f', '#9aae94');
    for (let layer = 0; layer < 2; layer++) {
      const sp = 200, f = layer ? 0.4 : 0.15, off = (camX * f) % sp;
      for (let i = -1; i < W / sp + 2; i++) {
        const hx = i * sp - off, hh = layer ? 170 : 230;
        c.fillStyle = layer ? '#355c30' : '#2f4a2c';
        c.beginPath(); rrect(hx, 450 - hh, 150, hh, 20)(c); c.fill();
        c.strokeStyle = '#1f3320'; c.lineWidth = 2;
        for (let k = 0; k < 5; k++) { c.beginPath(); c.moveTo(hx + 20 + k * 25, 450 - hh + 10); c.lineTo(hx + 30 + k * 25, 450 - hh + 25); c.stroke(); }
      }
    }
    return;
  }
  if (theme === 'library') {
    sky('#1c1626', '#2e2238');
    const sp = 160, off = (camX * 0.3) % sp;
    const cols = ['#7b3b4b', '#3b5a7b', '#6b5a2b', '#3b6b4b', '#5b3b7b'];
    for (let i = -1; i < W / sp + 2; i++) {
      const bx = i * sp - off;
      c.fillStyle = '#3a2a24'; c.fillRect(bx, 90, 130, 330);
      for (let r = 0; r < 5; r++) for (let k = 0; k < 9; k++) { c.fillStyle = cols[Math.abs(i + r + k) % 5]; c.fillRect(bx + 6 + k * 13, 100 + r * 64, 10, 52); }
    }
    return;
  }
  if (theme === 'volcano') {
    const calm = opts.calm;
    sky(calm ? '#ff9f8a' : '#2a1426', calm ? '#ffe2b8' : '#e8643a');
    if (calm) clouds(2, 0.6);
    if (opts.horizon) opts.horizon(calm ? 'dusk' : 'night');
    const vx = 620 - camX * 0.05;
    c.fillStyle = calm ? '#b07272' : '#3a2030';
    c.beginPath(); c.moveTo(vx - 380, 420); c.lineTo(vx - 70, 130); c.lineTo(vx + 70, 130); c.lineTo(vx + 380, 420); c.closePath(); c.fill();
    if (!calm) {
      glowDot(c, vx, 130, 130, '255,120,60', 0.55);
      c.strokeStyle = '#ff7a3d'; c.lineWidth = 5; c.lineJoin = 'round';
      for (const [d, sgn] of [[0, -1], [14, 1]]) {
        c.beginPath(); c.moveTo(vx + d - 20, 134);
        for (let k = 1; k < 6; k++) c.lineTo(vx + d - 20 + sgn * k * 18 + Math.sin(k * 2.3) * 10, 134 + k * 34);
        c.stroke();
      }
    }
    for (let i = 0; i < 8; i++) {
      const k = (t * 0.06 + i / 8) % 1;
      c.fillStyle = calm ? `rgba(255,255,255,${0.5 * (1 - k)})` : `rgba(112,72,140,${0.6 * (1 - k)})`;
      c.beginPath(); c.arc(vx + Math.sin(i * 1.7 + t * 0.3) * 30 * k + k * 70, 118 - k * 170, 18 + k * 52, 0, TAU); c.fill();
    }
    ridge(c, W, H, camX, 0.2, 380, 32, calm ? '#8a5a5e' : '#2e1c28', 1.9, 'rgba(255,170,120,0.35)');
    ridge(c, W, H, camX, 0.38, 420, 18, calm ? '#6e4448' : '#241620', 4.2, 'rgba(255,150,100,0.3)');
    if (!calm) {
      for (let i = 0; i < 26; i++) {
        const ex = (((i * 97 - camX * 0.3 + Math.sin(t + i) * 20) % W) + W) % W;
        const ey = H - ((t * 26 * (1 + (i % 4)) + i * 53) % H);
        c.fillStyle = `rgba(255,${150 + (i % 3) * 30},80,${0.35 + 0.35 * Math.sin(t * 3 + i)})`;
        c.beginPath(); c.arc(ex, ey, 1.5 + (i % 3), 0, TAU); c.fill();
      }
    }
    return;
  }
  if (theme === 'burrow') {
    sky('#4a2e20', '#8a6040');
    const sp = 140, off = (camX * 0.4) % sp;
    c.lineCap = 'round';
    for (let i = -1; i < W / sp + 2; i++) {
      const k = Math.abs(Math.floor((camX * 0.4) / sp) + i), rx = i * sp - off + (k * 31) % 50, len = 70 + (k * 41) % 90;
      c.strokeStyle = '#3a2418'; c.lineWidth = 6;
      c.beginPath(); c.moveTo(rx, 0); c.quadraticCurveTo(rx + 14, len * 0.5, rx - 6, len); c.stroke();
      c.lineWidth = 3; c.beginPath(); c.moveTo(rx + 6, len * 0.4); c.lineTo(rx + 22, len * 0.6); c.stroke();
      if (k % 3 === 0) glowDot(c, rx + 50, 300 + (k % 4) * 25, 22, '255,230,140', 0.35 + 0.15 * Math.sin(t * 2 + k));
    }
    return;
  }
  c.fillStyle = '#222'; c.fillRect(0, 0, W, H);
}

const GROUND_STYLE = {
  night: { body: ['#5b4a7a', '#3a2f55'], top: '#7c6aa0', dots: 'rgba(255,255,255,0.08)' },
  town: { body: ['#7a6a98', '#4f4470'], top: '#a08cc2', dots: 'rgba(255,255,255,0.1)' },
  grove: { body: ['#9a6a45', '#6e4529'], top: '#7ccf5e', dots: 'rgba(60,30,10,0.18)' },
  cave: { body: ['#4a3d6a', '#2c2245'], top: '#6d5a99', dots: 'rgba(160,140,255,0.12)' },
  fields: { body: ['#a8744a', '#7a5032'], top: '#8fdc6a', dots: 'rgba(60,30,10,0.16)' },
  garden: { body: ['#b08a6a', '#8a6a4a'], top: '#b6ee9c', dots: 'rgba(255,150,190,0.3)' },
  lake: { body: ['#d9b77a', '#a8854a'], top: '#f6e2a8', dots: 'rgba(90,60,20,0.15)' },
  mountain: { body: ['#8d867c', '#5f5a52'], top: '#c9c3b8', dots: 'rgba(30,25,20,0.18)' },
  maze: { body: ['#5e4630', '#3d2c1e'], top: '#4f8a47', dots: 'rgba(20,40,20,0.25)' },
  library: { body: ['#6e4224', '#4a2b16'], top: '#a8693a', dots: 'rgba(255,220,160,0.08)' },
  volcano: { body: ['#4e3a44', '#2a1e26'], top: '#8a6a5e', dots: 'rgba(255,130,60,0.22)' },
  burrow: { body: ['#8a6040', '#5a3a24'], top: '#a8794e', dots: 'rgba(40,20,10,0.2)' },
};

export function drawGround(c, x, y, w, h, theme) {
  const st = GROUND_STYLE[theme] || GROUND_STYLE.grove;
  c.save(); c.lineJoin = 'round';
  c.beginPath(); rrect(x, y, w, h, 8)(c);
  c.lineWidth = 9; c.strokeStyle = PAPER; c.stroke();
  c.fillStyle = vgrad(c, y, y + Math.min(h, 160), st.body[0], st.body[1]); c.fill();
  c.lineWidth = 2.4; c.strokeStyle = INK; c.stroke();
  c.save(); c.clip();
  c.fillStyle = st.dots;
  for (let i = Math.floor(x / 40); i < (x + w) / 40; i++) {
    for (let j = 0; j < Math.min(h, 120) / 30; j++) {
      const px = i * 40 + ((i * 7 + j * 13) % 20), py = y + 30 + j * 30 + ((i * 11) % 10);
      if (px > x + 6 && px < x + w - 6) { c.beginPath(); c.arc(px, py, 3, 0, TAU); c.fill(); }
    }
  }
  c.fillStyle = st.top; c.beginPath();
  c.moveTo(x, y + 12);
  for (let px = x; px <= x + w; px += 14) c.quadraticCurveTo(px + 7, y + 20, Math.min(px + 14, x + w), y + 12);
  c.lineTo(x + w, y); c.lineTo(x, y); c.closePath(); c.fill();
  c.restore();
  c.restore();
}

export function drawPlatform(c, x, y, w, theme, hidden = false) {
  c.save();
  if (hidden) c.globalAlpha = 0.85;
  const wood = ['grove', 'fields', 'lake', 'garden', 'burrow'].includes(theme);
  const col = hidden ? ['#9fe6ff', '#4aa7c9'] : theme === 'cave' ? ['#7d6aa8', '#4f427a'] : wood ? ['#c58b55', '#93603a']
    : theme === 'mountain' ? ['#b6b0a6', '#7d766c'] : theme === 'maze' ? ['#5e8a4f', '#3d5c33'] : theme === 'library' ? ['#8a5a3c', '#5e3b24']
      : theme === 'volcano' ? ['#6e5660', '#3e2c36'] : ['#8a7aa8', '#5d4f80'];
  paper(c, p => shape(c, p, rrect(x, y, w, 16, 6), vgrad(c, y, y + 16, col[0], col[1])));
  if (theme === 'grove' || theme === 'fields' || theme === 'garden') { c.fillStyle = '#7ccf5e'; c.fillRect(x + 4, y + 1, w - 8, 4); }
  if (theme === 'volcano' && !hidden) { c.fillStyle = 'rgba(255,140,60,0.75)'; c.fillRect(x + 8, y + 11, w - 16, 2.5); }
  if (hidden) glowDot(c, x + w / 2, y + 8, w * 0.6, '160,235,255', 0.35);
  c.restore();
}

let darkCanvas = null;
export function drawDarkness(c, W, H, lights, alpha = 0.92) {
  if (!darkCanvas) { darkCanvas = document.createElement('canvas'); darkCanvas.width = W; darkCanvas.height = H; }
  const d = darkCanvas.getContext('2d');
  d.globalCompositeOperation = 'source-over';
  d.clearRect(0, 0, W, H);
  d.fillStyle = `rgba(6,4,18,${alpha})`; d.fillRect(0, 0, W, H);
  d.globalCompositeOperation = 'destination-out';
  for (const L of lights) {
    const g = d.createRadialGradient(L.x, L.y, L.r * 0.2, L.x, L.y, L.r);
    g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    d.fillStyle = g; d.beginPath(); d.arc(L.x, L.y, L.r, 0, TAU); d.fill();
  }
  c.drawImage(darkCanvas, 0, 0, W, H);
}

// ---------------------------------------------------------------- more enemies (v3)
export function drawSnailshell(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 22 * s);
  c.scale(s * flip, s);
  if (o.flipped) { c.translate(0, -18); c.rotate(Math.PI + Math.sin(t * 9) * 0.15); c.translate(0, -18); }
  const crawl = Math.sin(t * 3) * 1.5;
  paper(c, p => {
    shape(c, p, cc => {
      cc.moveTo(-20, 0); cc.quadraticCurveTo(-23, -10, -12, -11); cc.lineTo(14, -11);
      cc.quadraticCurveTo(24, -12, 23, -26); cc.quadraticCurveTo(31, -25, 29, -10); cc.quadraticCurveTo(27, 0, 18, 0); cc.closePath();
    }, vgrad(c, -26, 0, '#dfe89a', '#a8b35a'));
    shape(c, p, ell(-3 + crawl * 0.3, -22, 16, 16), vgrad(c, -38, -6, '#f6ae62', '#c4682a'));
  });
  c.strokeStyle = 'rgba(43,34,53,0.65)'; c.lineWidth = 2; c.beginPath();
  for (let a = 0, i = 0; a < Math.PI * 4; a += 0.25, i++) { const r = 1.5 + a * 0.95; const px = -3 + crawl * 0.3 + Math.cos(a) * r, py = -22 + Math.sin(a) * r; i ? c.lineTo(px, py) : c.moveTo(px, py); }
  c.stroke();
  c.strokeStyle = INK; c.lineWidth = 2;
  c.beginPath(); c.moveTo(25, -24); c.lineTo(28, -34); c.moveTo(20, -21); c.lineTo(21, -31); c.stroke();
  for (const [ex, ey] of [[28, -35], [21, -32]]) {
    c.fillStyle = '#fff'; c.beginPath(); c.arc(ex, ey, 3.2, 0, TAU); c.fill(); c.lineWidth = 1.4; c.stroke();
    c.fillStyle = INK; c.beginPath(); c.arc(ex + 0.8, ey, 1.5, 0, TAU); c.fill();
  }
  c.restore();
  if (o.flipped) { c.save(); c.font = 'bold 16px Fredoka, sans-serif'; c.fillStyle = '#ffe066'; c.textAlign = 'center'; c.fillText('✶ ✶', x, y - 46 * s + Math.sin(t * 6) * 3); c.restore(); }
}

export function drawPuddlet(c, x, y, o = {}) {
  const t = o.t || 0, s = (o.scale || 1) * (o.small ? 0.72 : 1), flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 18 * s);
  c.scale(s * flip, s);
  const wob = Math.sin(t * 5) * 0.06;
  c.scale(1 + wob, 1 - wob);
  paper(c, p => shape(c, p, cc => {
    cc.moveTo(0, -40); cc.bezierCurveTo(10, -26, 21, -17, 21, -9); cc.bezierCurveTo(21, 1, 11, 1, 0, 1);
    cc.bezierCurveTo(-11, 1, -21, 1, -21, -9); cc.bezierCurveTo(-21, -17, -10, -26, 0, -40); cc.closePath();
  }, vgrad(c, -40, 0, '#c9eeff', '#4f9fd6')));
  c.fillStyle = 'rgba(255,255,255,0.6)'; c.beginPath(); c.ellipse(-8, -20, 4, 7, 0.4, 0, TAU); c.fill();
  eyes(c, -5, 6, -12, 8, o.mood || 'angry', t);
  mouth(c, 1, -5, 5, o.mood === 'hurt' ? 'hurt' : 'angry');
  c.restore();
}

export function drawMirrorMoth(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  c.scale(s * flip, s);
  const f = Math.sin(t * 9) * 0.25;
  if (o.glow) glowDot(c, 0, -26, 60, '230,240,255', 0.55 + Math.sin(t * 8) * 0.2);
  paper(c, p => {
    shape(c, p, ell(-17, -30, 16, 22, -0.6 - f), vgrad(c, -52, -8, '#f4f6ff', '#9aa6c8'));
    shape(c, p, ell(17, -30, 16, 22, 0.6 + f), vgrad(c, -52, -8, '#f4f6ff', '#9aa6c8'));
    shape(c, p, ell(0, -24, 6, 15), '#4b3f7a');
  });
  c.fillStyle = o.glow ? '#ffffff' : 'rgba(180,190,230,0.8)';
  for (const sx of [-17, 17]) { c.beginPath(); c.ellipse(sx, -32, 6, 9, sx < 0 ? -0.6 : 0.6, 0, TAU); c.fill(); }
  c.strokeStyle = INK; c.lineWidth = 1.6;
  c.beginPath(); c.moveTo(-2, -38); c.quadraticCurveTo(-6, -48, -10, -47); c.moveTo(2, -38); c.quadraticCurveTo(6, -48, 10, -47); c.stroke();
  for (const ex of [-2.5, 2.5]) { c.fillStyle = '#ff7ad9'; c.beginPath(); c.arc(ex, -33, 1.8, 0, TAU); c.fill(); }
  c.restore();
}

export function drawBombshroom(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, fuse = o.fuse ?? 3;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 20 * s);
  c.scale(s * flip, s);
  const shake = fuse <= 1 ? Math.sin(t * 50) * 1.5 : 0;
  c.translate(shake, 0);
  paper(c, p => {
    shape(c, p, rrect(-10, -20, 20, 20, 7), '#efe0c0');
    shape(c, p, cc => { cc.moveTo(-24, -16); cc.bezierCurveTo(-26, -50, 26, -50, 24, -16); cc.closePath(); }, fuse <= 1 && Math.sin(t * 20) > 0 ? '#c0394b' : vgrad(c, -44, -16, '#55496f', '#2f2945'));
  });
  c.fillStyle = 'rgba(255,255,255,0.35)';
  for (const [sx, sy, r] of [[-12, -30, 4], [4, -38, 3], [14, -26, 4]]) { c.beginPath(); c.arc(sx, sy, r, 0, TAU); c.fill(); }
  c.strokeStyle = '#8a6a4a'; c.lineWidth = 3; c.beginPath(); c.moveTo(0, -41); c.quadraticCurveTo(6, -52, 2, -58); c.stroke();
  const sp = fuse <= 1 ? 1.6 : fuse === 2 ? 1.1 : 0.7;
  glowDot(c, 2, -60, 16 * sp, '255,200,90', 0.8);
  c.fillStyle = '#ffe066'; c.beginPath(); starPath(c, 2, -60, 6 * sp + Math.sin(t * 30) * 1.5, 2.5 * sp, 6); c.fill();
  eyes(c, -5, 5, -10, 6, 'angry', t);
  c.restore();
  if (o.fuse != null && o.fuse < 3) { c.save(); c.font = 'bold 18px Fredoka, sans-serif'; c.textAlign = 'center'; c.lineWidth = 4; c.strokeStyle = INK; c.strokeText(String(o.fuse), x, y - 74 * s); c.fillStyle = '#ff9a3d'; c.fillText(String(o.fuse), x, y - 74 * s); c.restore(); }
}

export function drawRaccoon(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 20 * s);
  c.scale(s * flip, s);
  const bob = o.state === 'walk' ? -Math.abs(Math.sin((o.phase || 0) * TAU)) * 3 : Math.sin(t * 3) * 0.8;
  c.translate(0, bob);
  paper(c, p => {
    shape(c, p, cc => { cc.moveTo(-14, -14); cc.quadraticCurveTo(-34, -18, -32, -38); cc.quadraticCurveTo(-26, -28, -12, -22); cc.closePath(); }, '#8d8a9c');
    if (o.loot) shape(c, p, ell(-14, -30, 11, 10), '#a8834f');
    shape(c, p, ell(0, -15, 15, 14), vgrad(c, -29, -1, '#a4a1b3', '#7a7790'));
    shape(c, p, ell(8, -33, 13, 12), '#a4a1b3');
    shape(c, p, poly([[0, -42], [3, -50], [8, -43]]), '#7a7790');
    shape(c, p, poly([[12, -43], [17, -50], [19, -41]]), '#7a7790');
    shape(c, p, ell(-6, -1, 5, 3), '#4a4760'); shape(c, p, ell(6, -1, 5, 3), '#4a4760');
  });
  c.strokeStyle = 'rgba(43,34,53,0.7)'; c.lineWidth = 3;
  for (const k of [0, 1]) { c.beginPath(); c.moveTo(-30 + k * 7, -34 + k * 6); c.lineTo(-25 + k * 7, -31 + k * 6); c.stroke(); }
  c.fillStyle = '#2b2235'; c.beginPath(); rrect(-2, -38, 22, 8, 4)(c); c.fill();
  c.fillStyle = '#fffaf0'; c.beginPath(); c.ellipse(14, -28, 6, 4, 0, 0, TAU); c.fill();
  c.fillStyle = INK; c.beginPath(); c.arc(19, -29, 2, 0, TAU); c.fill();
  for (const ex of [4, 13]) { c.fillStyle = '#fff'; c.beginPath(); c.arc(ex, -34, 2, 0, TAU); c.fill(); }
  c.restore();
}

export function drawThornback(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, up = o.spikes !== false;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 22 * s);
  c.scale(s * flip, s);
  const len = up ? 13 : 4;
  paper(c, p => {
    for (let i = 0; i < 9; i++) {
      const a = Math.PI * (1.05 + i * 0.1), bx = Math.cos(a) * 22, by = -12 + Math.sin(a) * 20;
      const tx = Math.cos(a) * (22 + len), ty = -12 + Math.sin(a) * (20 + len);
      shape(c, p, poly([[bx - 4, by + 1], [tx, ty], [bx + 4, by - 1]]), up ? '#fff4e0' : '#6e5038', 1.6);
    }
    shape(c, p, cc => { cc.moveTo(-24, 0); cc.bezierCurveTo(-26, -40, 20, -40, 24, -6); cc.lineTo(24, 0); cc.closePath(); }, vgrad(c, -32, 0, '#8a6a4a', '#5e4630'));
    shape(c, p, ell(24, -9, 9, 8), '#e8cfae');
  });
  c.fillStyle = INK; c.beginPath(); c.arc(32, -10, 2.5, 0, TAU); c.fill();
  eyes(c, 18, 24, -15, 6, up ? 'angry' : 'normal', t);
  c.restore();
}

export function drawBrambleBeast(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, up = o.spikes !== false;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 34 * s, 0.25);
  c.scale(s * flip, s * (1 + Math.sin(t * 2.5) * 0.02));
  paper(c, p => {
    shape(c, p, ell(-20, -26, 24, 24), '#3f6b3a');
    shape(c, p, ell(20, -28, 24, 26), '#4a7a43');
    shape(c, p, ell(0, -46, 26, 22), '#55894c');
    shape(c, p, ell(0, -20, 30, 20), vgrad(c, -40, 0, '#4f8a47', '#355c30'));
  });
  c.strokeStyle = '#2a3d24'; c.lineWidth = 3;
  for (let i = 0; i < 5; i++) {
    const a = -Math.PI * (0.15 + i * 0.17), r1 = 30, r2 = up ? 48 : 38;
    c.beginPath(); c.moveTo(Math.cos(a) * r1, -28 + Math.sin(a) * r1); c.quadraticCurveTo(Math.cos(a + 0.3) * r2, -28 + Math.sin(a + 0.3) * r2, Math.cos(a) * r2, -28 + Math.sin(a) * r2); c.stroke();
    if (up) { c.fillStyle = '#fff4e0'; c.beginPath(); starPath(c, Math.cos(a) * r2, -28 + Math.sin(a) * r2, 5, 2, 3); c.fill(); }
  }
  for (const ex of [-9, 9]) {
    glowDot(c, ex, -32, 12, '255,224,102', 0.6);
    c.fillStyle = '#ffe066'; c.beginPath(); c.ellipse(ex, -32, 4, 5, 0, 0, TAU); c.fill();
    c.fillStyle = INK; c.beginPath(); c.ellipse(ex + 1, -32, 1.4, 3.5, 0, 0, TAU); c.fill();
  }
  c.strokeStyle = '#ffe066'; c.lineWidth = 2.5; c.beginPath(); c.moveTo(-15, -41); c.lineTo(-4, -37); c.moveTo(15, -41); c.lineTo(4, -37); c.stroke();
  c.fillStyle = '#fff4e0'; c.beginPath(); c.moveTo(-10, -18); for (let i = 0; i <= 6; i++) c.lineTo(-10 + i * 3.4, -18 + (i % 2 ? 5 : 0)); c.lineTo(10, -18); c.closePath(); c.fill();
  c.restore();
}

export function drawWisp(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y - 6 + Math.sin(t * 3) * 4);
  c.scale(s * flip, s);
  glowDot(c, 0, -22, 34, '190,255,200', 0.6);
  const w = Math.sin(t * 16) * 0.4;
  paper(c, p => {
    shape(c, p, ell(-11, -26, 7, 10, -0.5 - w), 'rgba(230,255,240,0.9)', 1.6);
    shape(c, p, ell(11, -26, 7, 10, 0.5 + w), 'rgba(230,255,240,0.9)', 1.6);
    shape(c, p, ell(0, -22, 11, 11), vgrad(c, -33, -11, '#f2fff4', '#9ee6a8'));
  });
  eyes(c, -4, 4, -23, 6, o.mood || 'normal', t);
  c.restore();
}

// ---------------------------------------------------------------- world objects (v3)
export function drawBush(c, x, y, o = {}) {
  const t = o.t || 0, sh = o.shake ? Math.sin(t * 45) * 3 * o.shake : 0;
  paper(c, p => {
    shape(c, p, ell(x - 15 + sh, y - 16, 19, 16), '#4f9a52', 2);
    shape(c, p, ell(x + 15 + sh, y - 17, 20, 17), '#5fae5c', 2);
    shape(c, p, ell(x + sh, y - 29, 19, 16), '#6cc068', 2);
  });
  c.fillStyle = '#e5534b';
  for (const [bx, by] of [[-10, -22], [8, -30], [16, -14]]) { c.beginPath(); c.arc(x + bx + sh, y + by, 2.6, 0, TAU); c.fill(); }
}

export function drawPot(c, x, y) {
  paper(c, p => {
    shape(c, p, cc => { cc.moveTo(x - 10, y - 30); cc.lineTo(x + 10, y - 30); cc.quadraticCurveTo(x + 22, y - 18, x + 14, y); cc.lineTo(x - 14, y); cc.quadraticCurveTo(x - 22, y - 18, x - 10, y - 30); cc.closePath(); }, vgrad(c, y - 30, y, '#d98a5a', '#a85a32'), 2);
    shape(c, p, rrect(x - 12, y - 35, 24, 7, 3), '#c0744a', 2);
  });
  c.strokeStyle = 'rgba(255,255,255,0.4)'; c.lineWidth = 2; c.beginPath(); c.moveTo(x - 12, y - 16); c.lineTo(x + 12, y - 16); c.stroke();
}

export function drawSpring(c, x, y, o = {}) {
  const sq = o.squash || 0;
  paper(c, p => {
    shape(c, p, rrect(x - 8, y - 18, 16, 18, 6), '#f3e3c3', 2);
    shape(c, p, cc => { cc.moveTo(x - 30, y - 16); cc.bezierCurveTo(x - 30, y - 16 - 30 * (1 - sq), x + 30, y - 16 - 30 * (1 - sq), x + 30, y - 16); cc.closePath(); }, vgrad(c, y - 40, y - 16, '#ff7a6e', '#d6455a'), 2);
  });
  c.fillStyle = '#fffaf0';
  for (const [dx, dy, r] of [[-14, -24, 4], [2, -30, 5], [16, -22, 3.5]]) { c.beginPath(); c.arc(x + dx, y + dy * (1 - sq * 0.6), r, 0, TAU); c.fill(); }
}

export function drawBoulder(c, x, y, w, h) {
  paper(c, p => shape(c, p, cc => {
    cc.moveTo(x + 8, y + h); cc.quadraticCurveTo(x - 6, y + h * 0.4, x + w * 0.25, y + 6);
    cc.quadraticCurveTo(x + w * 0.5, y - 8, x + w * 0.8, y + 8); cc.quadraticCurveTo(x + w + 8, y + h * 0.45, x + w - 6, y + h); cc.closePath();
  }, vgrad(c, y, y + h, '#a49e94', '#6f6a62')));
  c.fillStyle = 'rgba(124,196,106,0.85)'; c.beginPath(); c.ellipse(x + w * 0.45, y + 8, w * 0.22, 7, 0, 0, TAU); c.fill();
  c.strokeStyle = 'rgba(43,34,53,0.45)'; c.lineWidth = 2.5;
  c.beginPath(); c.moveTo(x + w * 0.3, y + h * 0.35); c.lineTo(x + w * 0.42, y + h * 0.55); c.lineTo(x + w * 0.36, y + h * 0.75); c.stroke();
  c.beginPath(); c.moveTo(x + w * 0.7, y + h * 0.3); c.lineTo(x + w * 0.62, y + h * 0.5); c.stroke();
}

export function drawSwitch(c, x, y, on) {
  paper(c, p => {
    shape(c, p, rrect(x - 18, y - 14, 36, 14, 4), '#7c7692', 2);
    shape(c, p, rrect(x - 11, y - (on ? 18 : 26), 22, on ? 6 : 13, 5), on ? '#7fd18b' : '#e5534b', 2);
  });
}

export function drawGate(c, x, y, w, h) {
  paper(c, p => shape(c, p, rrect(x, y, w, h, 4), vgrad(c, y, y + h, '#8a5a3c', '#5e3b24')));
  c.strokeStyle = '#3b3350'; c.lineWidth = 4;
  for (let gx = x + 10; gx < x + w - 4; gx += 14) { c.beginPath(); c.moveTo(gx, y + 4); c.lineTo(gx, y + h - 4); c.stroke(); }
  for (const gy of [y + 22, y + h - 22]) { c.beginPath(); c.moveTo(x + 3, gy); c.lineTo(x + w - 3, gy); c.stroke(); }
}

export function drawSeal(c, x, y, w, h, t, prog = 0) {
  c.save();
  const g = c.createLinearGradient(x, y, x + w, y + h);
  g.addColorStop(0, 'rgba(120,80,200,0.75)'); g.addColorStop(1, 'rgba(60,30,110,0.85)');
  c.fillStyle = g; c.beginPath(); rrect(x, y, w, h, 12)(c); c.fill();
  c.lineWidth = 4; c.strokeStyle = 'rgba(255,250,240,0.85)'; c.stroke();
  c.strokeStyle = 'rgba(220,200,255,0.6)'; c.lineWidth = 2;
  for (let i = 0; i < 4; i++) { const yy = y + ((t * 30 + i * h / 4) % h); c.beginPath(); c.moveTo(x + 6, yy); c.quadraticCurveTo(x + w / 2, yy - 10, x + w - 6, yy); c.stroke(); }
  const cx = x + w / 2, cy = y + h / 2;
  c.lineWidth = 6; c.strokeStyle = 'rgba(30,15,60,0.8)'; c.beginPath(); c.arc(cx, cy, 22, 0, TAU); c.stroke();
  c.strokeStyle = '#ffd25e'; c.beginPath(); c.arc(cx, cy, 22, -Math.PI / 2, -Math.PI / 2 + TAU * Math.min(1, prog)); c.stroke();
  c.font = '20px "Segoe UI Emoji", sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillStyle = '#fff'; c.fillText('🔒', cx, cy + 1);
  c.textBaseline = 'alphabetic';
  c.restore();
}

export function drawGoldAcorn(c, x, y, t = 0) {
  const by = y + Math.sin(t * 3 + x) * 4;
  glowDot(c, x, by - 10, 22, '255,220,100', 0.5);
  paper(c, p => {
    shape(c, p, ell(x, by - 8, 7, 9), vgrad(c, by - 17, by + 1, '#ffe27a', '#e8a92a'), 2);
    shape(c, p, ell(x, by - 17, 8, 4), '#a8743a', 2);
  });
}

export function drawBook(c, x, y, t = 0) {
  const by = y + Math.sin(t * 2.5) * 4;
  glowDot(c, x, by - 14, 30, '180,220,255', 0.5);
  paper(c, p => {
    shape(c, p, rrect(x - 14, by - 26, 28, 20, 3), '#5a4fa8', 2);
    shape(c, p, rrect(x - 12, by - 24, 24, 3, 1), '#ffe066', 0);
  });
}

export function drawWater(c, x, y, w, h, t, deep = '#2f6fa8') {
  const g = c.createLinearGradient(0, y, 0, y + h);
  g.addColorStop(0, '#6fc3ec'); g.addColorStop(1, deep);
  c.fillStyle = g;
  c.beginPath(); c.moveTo(x, y + h);
  for (let px = x; px <= x + w; px += 12) c.lineTo(px, y + Math.sin(t * 2 + px * 0.04) * 3);
  c.lineTo(x + w, y + h); c.closePath(); c.fill();
  c.strokeStyle = 'rgba(255,255,255,0.7)'; c.lineWidth = 3;
  c.beginPath(); for (let px = x; px <= x + w; px += 12) px === x ? c.moveTo(px, y + Math.sin(t * 2 + px * 0.04) * 3) : c.lineTo(px, y + Math.sin(t * 2 + px * 0.04) * 3); c.stroke();
}

export function drawBuilding(c, x, y, o = {}) {
  const w = o.w || 170, h = o.h || 140, t = o.t || 0;
  paper(c, p => {
    shape(c, p, rrect(x - w / 2, y - h, w, h, 8), vgrad(c, y - h, y, o.wall || '#b6a3d6', o.wall2 || '#8a76b0'));
    shape(c, p, poly([[x - w / 2 - 16, y - h + 2], [x, y - h - w * 0.42], [x + w / 2 + 16, y - h + 2]]), o.roof || '#c45a5a');
    shape(c, p, cc => { cc.moveTo(x - 22, y); cc.lineTo(x - 22, y - 50); cc.arc(x, y - 50, 22, Math.PI, 0); cc.lineTo(x + 22, y); cc.closePath(); }, o.closed ? '#4a3d5c' : '#6e4224');
  });
  const lit = o.lit;
  c.fillStyle = lit ? '#ffd67a' : '#3a3054';
  c.fillRect(x - w / 2 + 16, y - h + 26, 30, 26); c.fillRect(x + w / 2 - 46, y - h + 26, 30, 26);
  if (lit) { glowDot(c, x - w / 2 + 31, y - h + 39, 40, '255,210,120', 0.25); glowDot(c, x + w / 2 - 31, y - h + 39, 40, '255,210,120', 0.25); }
  if (o.sign) {
    c.font = 'bold 15px Fredoka, sans-serif'; c.textAlign = 'center';
    const sw = c.measureText(o.sign).width + 22;
    paper(c, p => shape(c, p, rrect(x - sw / 2, y - h - 4, sw, 26, 8), '#fffaf0', 2));
    c.fillStyle = INK; c.fillText(o.sign, x, y - h + 14);
  }
  if (o.icon) { c.font = '22px "Segoe UI Emoji", sans-serif'; c.textAlign = 'center'; c.fillText(o.icon, x, y - 62); }
  void t;
}

export function drawQuestBoard(c, x, y, t = 0) {
  paper(c, p => {
    shape(c, p, rrect(x - 4, y - 40, 8, 40, 2), '#8a5a3c', 2);
    shape(c, p, rrect(x - 40, y - 96, 80, 58, 6), vgrad(c, y - 96, y - 38, '#c58b55', '#93603a'));
  });
  const papers = [[-30, -90, '#fffaf0'], [-4, -88, '#fff3c9'], [14, -84, '#e8f6ff'], [-24, -66, '#ffe6f0'], [6, -64, '#fffaf0']];
  for (const [dx, dy, col] of papers) { c.fillStyle = col; c.fillRect(x + dx, y + dy, 18, 20); c.fillStyle = '#e5534b'; c.beginPath(); c.arc(x + dx + 9, y + dy + 2, 2, 0, TAU); c.fill(); }
  c.font = 'bold 22px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#ffe066';
  c.fillText('!', x + 34, y - 100 + Math.sin(t * 4) * 3);
}

export function drawWindmill(c, x, y, t = 0) {
  paper(c, p => {
    shape(c, p, poly([[x - 34, y], [x - 20, y - 170], [x + 20, y - 170], [x + 34, y]]), vgrad(c, y - 170, y, '#f3e3c3', '#c9b48e'));
    shape(c, p, poly([[x - 26, y - 168], [x, y - 200], [x + 26, y - 168]]), '#c45a5a');
  });
  c.save(); c.translate(x, y - 160); c.rotate(t * 0.8);
  for (let i = 0; i < 4; i++) {
    c.rotate(Math.PI / 2);
    paper(c, p => shape(c, p, rrect(-8, -96, 16, 88, 3), '#fffaf0', 2));
  }
  c.restore();
  c.fillStyle = INK; c.beginPath(); c.arc(x, y - 160, 6, 0, TAU); c.fill();
}

export function drawDock(c, x, y, t = 0) {
  paper(c, p => {
    shape(c, p, rrect(x - 60, y - 10, 120, 12, 3), '#a8693a', 2);
    for (const px of [-50, 0, 50]) shape(c, p, rrect(x + px - 4, y, 8, 40, 2), '#7a4a26', 2);
  });
  c.strokeStyle = 'rgba(255,255,255,0.7)'; c.lineWidth = 2;
  const r = 10 + (t * 20) % 30;
  c.globalAlpha = 1 - r / 40; c.beginPath(); c.ellipse(x + 80, y + 30, r, r * 0.3, 0, 0, TAU); c.stroke(); c.globalAlpha = 1;
}

// ---------------------------------------------------------------- Chapter 3: Ember Peak
const EMBER_PAL = {
  ember: ['#ffb347', '#ff5f2e', '#ffe08a'],
  granny: ['#f0703f', '#b8392a', '#ffc27a'],
  annie: ['#ff9a4a', '#e0542c', '#ffe08a'],
};

// Fire spirits: Ember (who can never quite sit still), Granny Hearth, Anvil Annie and the lost little ones.
export function drawEmber(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'normal';
  const pal = EMBER_PAL[o.look] || EMBER_PAL.ember;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 16 * s);
  c.scale(s * flip, s);
  const walk = o.state === 'walk', air = o.state === 'jump';
  const hop = walk ? -Math.abs(Math.sin((o.phase || 0) * TAU)) * 5 : -3 - Math.sin(t * 3) * 2;
  const jit = o.look ? 0 : Math.sin(t * 37) * 0.6;
  c.translate(jit, hop);
  glowDot(c, 0, -20, 44, '255,160,70', 0.35);
  const sway = Math.sin(t * 6) * 3, tip = -46 * (1 + Math.sin(t * 11) * 0.04) * (air ? 1.1 : 1);
  const arm = walk ? Math.sin((o.phase || 0) * TAU) * 3 : Math.sin(t * 5) * 1.5;
  paper(c, p => {
    shape(c, p, ell(-19, -12 + arm, 5, 4, -0.4), pal[1]);
    shape(c, p, ell(19, -12 - arm, 5, 4, 0.4), pal[1]);
    shape(c, p, cc => {
      cc.moveTo(0, 0);
      cc.quadraticCurveTo(19, 0, 19, -15);
      cc.bezierCurveTo(19, -27, 7, -32, sway, tip);
      cc.bezierCurveTo(-3, -36, -6, -33, -8, -31);
      cc.quadraticCurveTo(-11, -34, -14 + sway * 0.6, -39);
      cc.bezierCurveTo(-21, -27, -19, -17, -19, -15);
      cc.quadraticCurveTo(-19, 0, 0, 0);
      cc.closePath();
    }, vgrad(c, tip, 0, pal[0], pal[1]));
    shape(c, p, ell(0, -13, 12, 11), pal[2], 0);
    if (o.look === 'granny') shape(c, p, cc => { cc.moveTo(-20, -15); cc.quadraticCurveTo(0, -3, 20, -15); cc.lineTo(19, -8); cc.quadraticCurveTo(0, 3, -19, -8); cc.closePath(); }, '#7a5a9a', 1.8);
    if (o.look === 'annie') {
      shape(c, p, rrect(-10, -11, 20, 11, 4), '#8a5a3c', 1.8);
      shape(c, p, rrect(-15, -31, 30, 6, 3), '#e5534b', 1.8);
    }
  });
  for (let i = 0; i < 3; i++) {
    const k = (t * 0.9 + i / 3) % 1;
    c.fillStyle = `rgba(255,220,120,${1 - k})`;
    c.beginPath(); c.arc(Math.sin(t * 3 + i * 2) * 10, tip - 4 - k * 22, 2, 0, TAU); c.fill();
  }
  eyes(c, -5, 6, -16, 8, mood, t);
  mouth(c, 1, -8, 5, mood);
  if (o.look === 'granny') {
    c.strokeStyle = INK; c.lineWidth = 1.5;
    c.beginPath(); c.arc(-5, -16, 5, 0, TAU); c.stroke(); c.beginPath(); c.arc(6, -16, 5, 0, TAU); c.stroke();
  }
  c.restore();
}

export function drawLostEmber(c, x, y, t = 0) {
  const by = y + Math.sin(t * 3 + x) * 4;
  glowDot(c, x, by - 14, 30, '255,170,80', 0.55);
  drawEmber(c, x, by, { t: t + x, scale: 0.5, mood: 'worried', shadow: false, look: 'kid' });
}

// Kettle runs the hot springs. Very calm. Slightly steamy.
export function drawKettle(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'sleepy';
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 22 * s);
  c.scale(s * flip, s);
  c.translate(0, Math.sin(t * 2) * 0.8);
  paper(c, p => {
    shape(c, p, cc => { cc.arc(-20, -24, 12, Math.PI * 0.55, Math.PI * 1.45); cc.arc(-20, -24, 6, Math.PI * 1.45, Math.PI * 0.55, true); cc.closePath(); }, '#3f6f86', 2);
    shape(c, p, poly([[16, -26], [33, -40], [37, -36], [20, -14]]), '#4f8aa6', 2);
    shape(c, p, ell(-8, -2, 6, 3), '#3f6f86'); shape(c, p, ell(8, -2, 6, 3), '#3f6f86');
    shape(c, p, ell(0, -22, 22, 20), vgrad(c, -42, -2, '#8fd0e0', '#4f8aa6'));
    shape(c, p, ell(0, -41, 13, 4), '#3f6f86', 2);
    shape(c, p, ell(0, -47, 4, 3), '#ffd23f', 1.8);
  });
  c.fillStyle = 'rgba(255,255,255,0.45)'; c.beginPath(); c.ellipse(-10, -30, 6, 3.5, -0.5, 0, TAU); c.fill();
  for (let i = 0; i < 3; i++) {
    const k = (t * 0.6 + i / 3) % 1;
    c.fillStyle = `rgba(255,255,255,${0.7 * (1 - k)})`;
    c.beginPath(); c.arc(37 + k * 10 + Math.sin(t * 2 + i) * 3, -40 - k * 30, 3 + k * 6, 0, TAU); c.fill();
  }
  eyes(c, -6, 6, -23, 8, mood, t);
  blush(c, -11, -15); blush(c, 11, -15);
  mouth(c, 0, -14, 6, mood);
  c.restore();
}

export function drawCinderling(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, g = Math.min(2, o.grow || 0);
  const pal = [['#ffc04a', '#ff6a2a', '#ffe9a0'], ['#ffa03d', '#e5442a', '#ffd66e'], ['#fff0a0', '#d62e2a', '#ffffff']][g];
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 16 * s);
  c.scale(s * flip, s * (1 + Math.sin(t * 9) * 0.05));
  glowDot(c, 0, -16, 34 + g * 12, '255,140,60', 0.4 + g * 0.12);
  const f = k => Math.sin(t * 8 + k) * 2.5;
  paper(c, p => {
    shape(c, p, cc => {
      cc.moveTo(-16, -2); cc.quadraticCurveTo(0, 4, 16, -2);
      cc.quadraticCurveTo(20, -14, 13, -22); cc.lineTo(12 + f(1), -34);
      cc.lineTo(5, -25); cc.lineTo(1 + f(2), -40);
      cc.lineTo(-5, -26); cc.lineTo(-11 + f(3), -33);
      cc.lineTo(-13, -21); cc.quadraticCurveTo(-20, -12, -16, -2);
      cc.closePath();
    }, vgrad(c, -40, 0, pal[0], pal[1]));
    shape(c, p, ell(1, -11, 9, 8), pal[2], 0);
  });
  if (o.mood === 'hurt') eyes(c, -3, 6, -13, 6, 'hurt', t);
  else {
    for (const ex of [-3, 6]) { c.fillStyle = INK; c.beginPath(); c.ellipse(ex, -13, 2, 3, 0, 0, TAU); c.fill(); }
    c.strokeStyle = INK; c.lineWidth = 1.8;
    c.beginPath(); c.moveTo(-6, -18); c.lineTo(-1, -16); c.moveTo(9, -18); c.lineTo(4, -16); c.stroke();
    c.beginPath(); c.moveTo(-2, -6); c.lineTo(1, -8); c.lineTo(4, -6); c.stroke();
  }
  c.restore();
}

// A blob of lava that hides in its puddle between bites.
export function drawMagmaw(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  c.scale(s * flip, s);
  c.fillStyle = '#ff6a2a'; c.beginPath(); c.ellipse(0, -1, 28, 6, 0, 0, TAU); c.fill();
  c.strokeStyle = '#ffd25e'; c.lineWidth = 2; c.beginPath(); c.ellipse(0, -1, 28, 6, 0, Math.PI, TAU); c.stroke();
  if (o.under) {
    for (let i = 0; i < 3; i++) {
      const k = (t * 1.3 + i / 3) % 1;
      c.fillStyle = `rgba(255,214,110,${1 - k})`; c.beginPath(); c.arc(-14 + i * 14, -4 - k * 16, 3 + k * 3, 0, TAU); c.fill();
    }
    for (const ex of [-6, 6]) { c.fillStyle = '#ffe066'; c.beginPath(); c.ellipse(ex, -6, 3, 2.5, 0, 0, TAU); c.fill(); }
    c.restore();
    return;
  }
  const sq = Math.sin(t * 5) * 0.05;
  c.scale(1 + sq, 1 - sq);
  paper(c, p => {
    shape(c, p, ell(0, -19, 22, 19), vgrad(c, -38, 0, '#ff9a3d', '#c23a24'));
    shape(c, p, ell(-11, -30, 6, 4, -0.4), '#6a2a2a', 0);
    shape(c, p, ell(13, -26, 5, 3.5, 0.4), '#6a2a2a', 0);
    shape(c, p, ell(3, -10, 14, 7), '#3a1014', 1.8);
  });
  c.fillStyle = '#fff4e0';
  for (let i = 0; i < 4; i++) { const tx = -7 + i * 6; c.beginPath(); c.moveTo(tx, -16); c.lineTo(tx + 3, -11); c.lineTo(tx + 6, -16); c.fill(); }
  eyes(c, -4, 9, -24, 7, o.mood || 'angry', t);
  c.restore();
}

export function drawAshcrow(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y - 4);
  c.scale(s * flip, s);
  for (let i = 0; i < 4; i++) {
    const k = (t * 0.8 + i / 4) % 1;
    c.fillStyle = `rgba(90,80,100,${0.45 * (1 - k)})`;
    c.beginPath(); c.arc(-22 - k * 26, -16 + Math.sin(t * 3 + i) * 4, 5 + k * 8, 0, TAU); c.fill();
  }
  const flap = Math.sin(t * 12) * 0.7;
  paper(c, p => {
    shape(c, p, poly([[-14, -18], [-30, -24], [-28, -12]]), '#2b2535');
    shape(c, p, ell(-2, -22, 13, 6, -0.6 - flap), '#3a3346');
    shape(c, p, ell(0, -18, 15, 11), vgrad(c, -29, -7, '#5a5268', '#2e2838'));
    shape(c, p, ell(12, -26, 9, 8), '#4a4458');
    shape(c, p, poly([[19, -29], [29, -26], [19, -23]]), '#f2a33a', 1.8);
    shape(c, p, ell(2, -24, 13, 6, 0.5 + flap), '#463f54');
  });
  if (o.mood === 'hurt') eyes(c, 14, 14, -28, 5, 'hurt', t);
  else { glowDot(c, 14, -28, 8, '255,140,60', 0.8); c.fillStyle = '#ff8a3d'; c.beginPath(); c.arc(14, -28, 2.2, 0, TAU); c.fill(); }
  c.restore();
}

// A fire imp juggling far too many fireballs at once.
export function drawJugglit(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 16 * s);
  c.scale(s * flip, s);
  c.translate(0, Math.sin(t * 10) * 1.5);
  const arm = o.dizzy ? 0.3 : Math.sin(t * 10) * 0.25;
  paper(c, p => {
    shape(c, p, ell(-6, -2, 5, 3), '#7a2430'); shape(c, p, ell(6, -2, 5, 3), '#7a2430');
    shape(c, p, cc => { cc.moveTo(-9, -24); cc.lineTo(-17, -42 - arm * 10); cc.lineTo(-13, -44 - arm * 10); cc.lineTo(-5, -28); cc.closePath(); }, '#d6455a');
    shape(c, p, cc => { cc.moveTo(9, -24); cc.lineTo(17, -42 + arm * 10); cc.lineTo(13, -44 + arm * 10); cc.lineTo(5, -28); cc.closePath(); }, '#d6455a');
    shape(c, p, rrect(-11, -28, 22, 26, 9), vgrad(c, -28, -2, '#ef6a5a', '#a8323e'));
    shape(c, p, ell(0, -34, 12, 11), '#ef6a5a');
    shape(c, p, poly([[-9, -42], [-13, -52], [-4, -44]]), '#ffe066', 1.6);
    shape(c, p, poly([[9, -42], [13, -52], [4, -44]]), '#ffe066', 1.6);
  });
  eyes(c, -4, 5, -35, 6, o.dizzy ? 'hurt' : (o.mood || 'angry'), t);
  c.fillStyle = INK; c.beginPath(); c.arc(1, -28, 2.5, 0, Math.PI); c.fill();
  if (o.dizzy) {
    for (let i = 0; i < 3; i++) { const a = t * 4 + i * 2.1; c.beginPath(); starPath(c, Math.cos(a) * 14, -54 + Math.sin(a) * 4, 4, 2); c.fillStyle = '#ffe066'; c.fill(); }
  } else if (o.juggle !== false) {
    for (let i = 0; i < 3; i++) { const a = t * 5 + i * (TAU / 3); flame(c, Math.cos(a) * 18, -60 + Math.sin(a) * 9 - Math.abs(Math.cos(a)) * 6, 0.45, t + i); }
  }
  c.restore();
}

// Cooled lava, hard as rock. Heat it up and it goes soft (and very hot).
export function drawSlagbrute(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, hot = !!o.molten;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 26 * s);
  c.scale(s * flip, s);
  c.translate(0, o.state === 'walk' ? -Math.abs(Math.sin((o.phase || 0) * TAU)) * 3 : 0);
  if (hot) glowDot(c, 0, -26, 60, '255,120,50', 0.5 + Math.sin(t * 6) * 0.1);
  const body = hot ? ['#e0603a', '#8a2a1e'] : ['#6a5e68', '#33292f'];
  paper(c, p => {
    shape(c, p, ell(-10, -3, 8, 4), body[1]); shape(c, p, ell(10, -3, 8, 4), body[1]);
    shape(c, p, ell(-27, -18, 10, 10), body[0]);
    shape(c, p, cc => { cc.moveTo(-22, -4); cc.lineTo(-24, -34); cc.quadraticCurveTo(-18, -50, 0, -50); cc.quadraticCurveTo(18, -50, 24, -34); cc.lineTo(22, -4); cc.closePath(); }, vgrad(c, -50, -4, body[0], body[1]));
    shape(c, p, ell(27, -18, 10, 10), body[0]);
  });
  c.strokeStyle = hot ? '#ffe066' : 'rgba(20,14,20,0.7)'; c.lineWidth = hot ? 2.6 : 2;
  c.beginPath(); c.moveTo(-14, -42); c.lineTo(-8, -32); c.lineTo(-12, -22); c.moveTo(10, -30); c.lineTo(15, -20); c.lineTo(9, -12); c.moveTo(-2, -14); c.lineTo(3, -8); c.stroke();
  if (o.mood === 'hurt') eyes(c, -7, 7, -36, 6, 'hurt', t);
  else for (const ex of [-7, 7]) { glowDot(c, ex, -36, 7, '255,140,60', 0.8); c.fillStyle = '#ffb347'; c.fillRect(ex - 4, -37, 8, 2.5); }
  c.restore();
}

function taskItem(c, x, y, kind) {
  paper(c, p => {
    if (kind === 'book') shape(c, p, rrect(x - 8, y - 6, 16, 12, 2), '#5a4fa8', 2);
    else if (kind === 'pan') { shape(c, p, rrect(x, y - 2, 14, 4, 2), '#3b3350', 2); shape(c, p, ell(x - 6, y, 9, 5), '#4a4460', 2); }
    else if (kind === 'scroll') shape(c, p, rrect(x - 5, y - 9, 10, 18, 3), '#f6e8c6', 2);
    else { shape(c, p, rrect(x - 1.5, y - 16, 3, 22, 1.5), '#8a5a3c', 1.6); shape(c, p, poly([[x - 7, y + 6], [x + 7, y + 6], [x + 4, y + 14], [x - 4, y + 14]]), '#e8c66a', 1.6); }
  });
}

// Cindermaw: a volcano with a mouth and four busy arms, trying to do every task at once.
export function drawCindermaw(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'angry', hot = !!o.blazing;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 44 * s, 0.3);
  c.scale(s * flip, s);
  glowDot(c, 0, -40, 90, '255,110,50', hot ? 0.55 : 0.35);
  const breathe = Math.sin(t * 2.4) * 0.02;
  c.scale(1 + breathe, 1 - breathe);
  const busy = mood === 'sleep' ? 0.15 : 1;
  const arms = [
    [-30, -36, -2.4 + Math.sin(t * 4) * 0.35 * busy, 'book'], [-34, -18, -2.9 + Math.sin(t * 5 + 1) * 0.3 * busy, 'broom'],
    [30, -36, -0.75 + Math.sin(t * 4.5 + 2) * 0.35 * busy, 'pan'], [34, -18, -0.25 + Math.sin(t * 3.7 + 3) * 0.3 * busy, 'scroll'],
  ];
  c.lineCap = 'round';
  for (const [sx, sy, a, item] of arms) {
    const hx = sx + Math.cos(a) * 30, hy = sy + Math.sin(a) * 30;
    c.strokeStyle = PAPER; c.lineWidth = 12; c.beginPath(); c.moveTo(sx, sy); c.lineTo(hx, hy); c.stroke();
    c.strokeStyle = hot ? '#e0542c' : '#a8382a'; c.lineWidth = 6; c.beginPath(); c.moveTo(sx, sy); c.lineTo(hx, hy); c.stroke();
    taskItem(c, hx, hy, item);
  }
  paper(c, p => {
    shape(c, p, cc => { cc.moveTo(-44, 0); cc.quadraticCurveTo(-46, -50, -26, -70); cc.lineTo(26, -70); cc.quadraticCurveTo(46, -50, 44, 0); cc.closePath(); },
      vgrad(c, -70, 0, hot ? '#8a3a2e' : '#5a3440', hot ? '#4a1a1e' : '#2a1820'));
    shape(c, p, ell(0, -70, 26, 7), '#ff7a2e', 2);
    shape(c, p, cc => { cc.moveTo(-26, -24); cc.quadraticCurveTo(0, -38, 26, -24); cc.quadraticCurveTo(22, -2, 0, -4); cc.quadraticCurveTo(-22, -2, -26, -24); cc.closePath(); }, '#2b0c12', 2);
  });
  c.strokeStyle = hot ? '#ffe066' : '#ff8a3d'; c.lineWidth = 2.5;
  for (const [ax, ay, bx, by] of [[-38, -12, -30, -30], [-30, -30, -36, -48], [36, -10, 30, -34], [30, -34, 36, -50], [-12, -58, -4, -66], [12, -60, 6, -50]]) {
    c.beginPath(); c.moveTo(ax, ay); c.lineTo(bx, by); c.stroke();
  }
  glowDot(c, 0, -18, 26, '255,120,40', 0.7);
  c.fillStyle = '#ff6a2a'; c.beginPath(); c.ellipse(0, -12, 14, 5, 0, 0, TAU); c.fill();
  c.fillStyle = '#fff4e0';
  for (let i = 0; i < 5; i++) { const tx = -22 + i * 9; c.beginPath(); c.moveTo(tx, -29); c.lineTo(tx + 4.5, -21); c.lineTo(tx + 9, -29); c.fill(); }
  for (let i = 0; i < 4; i++) { const tx = -18 + i * 9; c.beginPath(); c.moveTo(tx, -5); c.lineTo(tx + 4.5, -12); c.lineTo(tx + 9, -5); c.fill(); }
  if (mood === 'hurt' || mood === 'sleep') eyes(c, -14, 14, -46, 10, mood, t);
  else {
    for (const ex of [-14, 14]) {
      glowDot(c, ex, -46, 14, '255,224,102', 0.7);
      c.fillStyle = '#ffe066'; c.beginPath(); c.ellipse(ex, -46, 6, 5, 0, 0, TAU); c.fill();
      c.fillStyle = INK; c.beginPath(); c.ellipse(ex + 1, -46, 2, 4, 0, 0, TAU); c.fill();
    }
    c.strokeStyle = INK; c.lineWidth = 4;
    c.beginPath(); c.moveTo(-24, -56); c.lineTo(-6, -50); c.moveTo(24, -56); c.lineTo(6, -50); c.stroke();
  }
  flame(c, 0, -70, hot ? 2.2 : mood === 'sleep' ? 0.8 : 1.6, t);
  for (let i = 0; i < 3 * busy; i++) {
    const k = (t * 0.7 + i / 3) % 1;
    c.fillStyle = `rgba(255,140,60,${1 - k})`;
    c.beginPath(); c.arc((i - 1) * 36 * k, -76 - Math.sin(k * Math.PI) * 40, 4, 0, TAU); c.fill();
  }
  c.restore();
}

// Wick folded into a paper tube (the Roll Fold).
export function drawWickRoll(c, x, y, o = {}) {
  const t = o.t || 0, a = o.angle || 0;
  c.save(); c.translate(x, y);
  shadow(c, 0, 0, 14);
  c.translate(0, -15);
  paper(c, p => shape(c, p, ell(0, 0, 15, 15), vgrad(c, -15, 15, '#fff8e6', '#f0d8ab')));
  c.rotate(a);
  c.strokeStyle = '#4f72bf'; c.lineWidth = 3; c.lineCap = 'round';
  c.beginPath();
  for (let k = 0; k <= 40; k++) {
    const q = k / 40, ang = q * TAU * 2.2, r = 2 + q * 11;
    if (k) c.lineTo(Math.cos(ang) * r, Math.sin(ang) * r); else c.moveTo(Math.cos(ang) * r, Math.sin(ang) * r);
  }
  c.stroke();
  c.fillStyle = '#d9534f'; c.beginPath(); c.arc(Math.cos(TAU * 2.2) * 13, Math.sin(TAU * 2.2) * 13, 3, 0, TAU); c.fill();
  c.restore();
  flame(c, x - (o.dir || 0) * 4, y - 30, 0.6 * (o.flame || 1), t);
}

// A rock wall that stops just short of the floor: only a rolled-up Wick fits through the gap.
export function drawLowRock(c, x, top, w, theme) {
  const col = theme === 'volcano' ? ['#8a7680', '#4e3e48'] : theme === 'cave' ? ['#7d6aa8', '#4f427a'] : ['#a9a3b2', '#6f6a7c'];
  const n = Math.max(3, Math.round(w / 26));
  const path = cc => {
    cc.moveTo(x, -20); cc.lineTo(x + w, -20); cc.lineTo(x + w, top - 6);
    for (let i = n; i >= 0; i--) cc.lineTo(x + (w * i) / n, top - (i % 2 ? 0 : 9));
    cc.closePath();
  };
  c.save(); c.lineJoin = 'round';
  c.beginPath(); path(c); c.lineWidth = 9; c.strokeStyle = PAPER; c.stroke();
  c.fillStyle = vgrad(c, 0, top, col[0], col[1]); c.fill();
  c.lineWidth = 2.4; c.strokeStyle = INK; c.stroke();
  c.beginPath(); path(c); c.clip();
  c.strokeStyle = 'rgba(30,20,30,0.35)'; c.lineWidth = 2;
  for (let yy = 30, row = 0; yy < top - 20; yy += 64, row++) {
    for (let px = x + 18 + (row % 2) * 30; px < x + w - 18; px += 62) {
      c.beginPath(); c.moveTo(px, yy); c.lineTo(px + 14, yy + 10); c.lineTo(px + 8, yy + 24); c.stroke();
    }
  }
  c.fillStyle = 'rgba(255,250,240,0.12)';
  c.fillRect(x + 6, -20, 8, top + 10);
  c.restore();
}

export function drawVent(c, x, y, t, st = 'idle', k = 1) {
  const shake = st === 'warn' ? Math.sin(t * 60) * 1.5 : 0;
  if (st === 'blow') {
    for (let i = 0; i < 9; i++) {
      const q = (t * 1.6 + i / 9) % 1;
      c.fillStyle = `rgba(255,255,255,${0.8 * (1 - q) * Math.min(1, k * 4)})`;
      c.beginPath(); c.arc(x + Math.sin(t * 4 + i) * 8 * q, y - 18 - q * 300, 10 + q * 22, 0, TAU); c.fill();
    }
  } else if (st === 'warn') {
    for (let i = 0; i < 3; i++) {
      const q = (t * 2 + i / 3) % 1;
      c.fillStyle = `rgba(255,255,255,${0.6 * (1 - q)})`;
      c.beginPath(); c.arc(x + Math.sin(t * 9 + i) * 5, y - 20 - q * 40, 5 + q * 6, 0, TAU); c.fill();
    }
  } else {
    const q = (t * 0.5) % 1;
    c.fillStyle = `rgba(255,255,255,${0.25 * (1 - q)})`; c.beginPath(); c.arc(x, y - 22 - q * 30, 4 + q * 5, 0, TAU); c.fill();
  }
  paper(c, p => shape(c, p, cc => {
    cc.moveTo(x - 32 + shake, y); cc.quadraticCurveTo(x - 26 + shake, y - 16, x - 11 + shake, y - 19);
    cc.lineTo(x + 11 + shake, y - 19); cc.quadraticCurveTo(x + 26 + shake, y - 16, x + 32 + shake, y); cc.closePath();
  }, vgrad(c, y - 19, y, '#6e6068', '#43383f')));
  c.fillStyle = '#1e161c'; c.beginPath(); c.ellipse(x + shake, y - 18, 10, 3.2, 0, 0, TAU); c.fill();
  if (st !== 'idle') glowDot(c, x, y - 18, 20, '255,140,60', st === 'blow' ? 0.5 : 0.3);
}

const RUNES = ['', 'I', 'II', 'III', 'IV', 'V'];
export function drawBrazier(c, x, y, o = {}) {
  const t = o.t || 0;
  if (o.lit) glowDot(c, x, y - 76, 80, '255,170,80', 0.4);
  paper(c, p => {
    shape(c, p, rrect(x - 16, y - 8, 32, 8, 3), '#4a3e46');
    shape(c, p, rrect(x - 9, y - 56, 18, 50, 4), vgrad(c, y - 56, y - 6, '#8a7a82', '#54484f'));
    shape(c, p, cc => { cc.moveTo(x - 26, y - 68); cc.lineTo(x + 26, y - 68); cc.quadraticCurveTo(x + 22, y - 52, x, y - 52); cc.quadraticCurveTo(x - 22, y - 52, x - 26, y - 68); cc.closePath(); }, '#5e5058');
  });
  paper(c, p => shape(c, p, rrect(x - 15, y - 44, 30, 22, 6), o.lit ? '#ffe9a8' : '#f6e8c6', 2));
  c.font = 'bold 16px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillStyle = INK;
  c.fillText(RUNES[o.n] || '', x, y - 27);
  if (o.lit) flame(c, x, y - 64, 1.8, t + x);
  else if (o.flash > 0) glowDot(c, x, y - 70, 40, '255,80,60', o.flash * 0.6);
  else {
    const q = (t * 0.4 + x * 0.01) % 1;
    c.fillStyle = `rgba(200,190,210,${0.4 * (1 - q)})`; c.beginPath(); c.arc(x, y - 72 - q * 26, 3 + q * 4, 0, TAU); c.fill();
  }
}

export function drawVines(c, x, y, w, h, t = 0) {
  const n = Math.max(2, Math.round(w / 16));
  c.save(); c.lineCap = 'round';
  for (const pass of [0, 1]) {
    for (let i = 0; i < n; i++) {
      const vx = x + 6 + (i * (w - 12)) / (n - 1), sw = Math.sin(t * 1.5 + i) * 3;
      c.beginPath(); c.moveTo(vx, y);
      c.bezierCurveTo(vx + 10 + sw, y + h * 0.3, vx - 10 - sw, y + h * 0.6, vx + sw, y + h);
      c.lineWidth = pass ? 6 : 13; c.strokeStyle = pass ? (i % 2 ? '#4f7a3a' : '#3f6a34') : PAPER; c.stroke();
    }
  }
  c.fillStyle = '#fff4e0';
  for (let i = 0; i < n * 3; i++) {
    const vx = x + 8 + ((i * 37) % Math.max(1, w - 16)), vy = y + 12 + ((i * 53) % Math.max(1, h - 24));
    c.beginPath(); c.moveTo(vx - 3, vy); c.lineTo(vx, vy - 6); c.lineTo(vx + 3, vy); c.fill();
  }
  c.fillStyle = '#7ccf5e';
  for (let i = 0; i < n * 2; i++) {
    const vx = x + 10 + ((i * 61) % Math.max(1, w - 20)), vy = y + 20 + ((i * 47) % Math.max(1, h - 40));
    c.beginPath(); c.ellipse(vx, vy, 6, 3, (i % 3) - 1, 0, TAU); c.fill();
  }
  c.restore();
}

export function drawLava(c, x, y, w, h, t) {
  const g = c.createLinearGradient(0, y, 0, y + h);
  g.addColorStop(0, '#ffb347'); g.addColorStop(0.35, '#ff5a2a'); g.addColorStop(1, '#a8231e');
  const wave = px => y + Math.sin(t * 1.6 + px * 0.03) * 3;
  c.fillStyle = g;
  c.beginPath(); c.moveTo(x, y + h);
  for (let px = x; px <= x + w; px += 12) c.lineTo(px, wave(px));
  c.lineTo(x + w, y + h); c.closePath(); c.fill();
  c.strokeStyle = '#ffe08a'; c.lineWidth = 3; c.beginPath();
  for (let px = x; px <= x + w; px += 12) { if (px === x) c.moveTo(px, wave(px)); else c.lineTo(px, wave(px)); }
  c.stroke();
  for (let i = 0; i < w / 90; i++) {
    const q = (t * 0.7 + i * 0.37) % 1, bx = x + ((i * 173) % w);
    c.strokeStyle = `rgba(255,230,150,${1 - q})`; c.lineWidth = 2;
    c.beginPath(); c.arc(bx, y + 10 - q * 6, 3 + q * 6, Math.PI, TAU); c.stroke();
  }
}

export function drawHotSpring(c, x, y, t = 0) {
  paper(c, p => shape(c, p, ell(x, y - 4, 110, 18), '#8a7a82'));
  c.fillStyle = '#6fd0d6'; c.beginPath(); c.ellipse(x, y - 6, 96, 12, 0, 0, TAU); c.fill();
  c.strokeStyle = 'rgba(255,255,255,0.7)'; c.lineWidth = 2; c.beginPath(); c.ellipse(x - 20, y - 8, 30, 4, 0, Math.PI, TAU); c.stroke();
  for (let i = 0; i < 6; i++) {
    const q = (t * 0.35 + i / 6) % 1;
    c.fillStyle = `rgba(255,255,255,${0.55 * (1 - q)})`;
    c.beginPath(); c.arc(x - 70 + i * 28 + Math.sin(t + i) * 6, y - 14 - q * 70, 6 + q * 12, 0, TAU); c.fill();
  }
}

// Draw any character by key (used by the field, battles, and cutscenes).
export const DRAW = {
  wick: drawWick, moss: drawMoss, hoot: drawHoot, pebble: drawPebble, mothwick: drawMothwick, crane: drawCrane,
  folk: drawFolk, acorn: drawAcorn, gloomling: drawGloomling, spikeshroom: drawSpikeshroom, buzzbug: drawBuzzbug,
  inkblot: drawInkblot, shellcrab: drawShellcrab, glowbat: drawGlowbat, grumblecap: drawGrumblecap,
  smudge: drawSmudge, dusk: drawDusk, snailshell: drawSnailshell, puddlet: drawPuddlet, mirrormoth: drawMirrorMoth,
  bombshroom: drawBombshroom, raccoon: drawRaccoon, thornback: drawThornback, bramblebeast: drawBrambleBeast, wisp: drawWisp,
  ember: drawEmber, kettle: drawKettle, cinderling: drawCinderling, magmaw: drawMagmaw, ashcrow: drawAshcrow,
  jugglit: drawJugglit, slagbrute: drawSlagbrute, cindermaw: drawCindermaw,
};
