// The paper diorama: real depth (2.5D) for the field and the battle stage, plus the art that came with the
// Lumenfold expansion (interiors and furniture, Old Lumen Castle, the dojo, the bandits and the new folks).
// Characters stay flat paper cutouts, like Paper Mario; the world around them gets depth.
import {
  DRAW, INK, PAPER, paper, shape, rrect, ell, poly, vgrad, glowDot, flame, eyes, mouth, starPath, shadow, drawFolk,
  drawBuilding, drawBlock,
} from './art.js';

const TAU = Math.PI * 2;
const hash = n => { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };

// ---------------------------------------------------------------- the camera
// World x/y on the main path (z = 0) map 1:1 to the screen. Things further back (z > 0) shrink toward a vanishing
// point near the top of the screen, so you look down onto a deep floor you can walk around on; things in front grow.
export const FOCAL = 900;
export const HZ = 60;                  // where the vanishing point sits on the screen
export const GZ0 = -80, GZ1 = 260;     // the floor: from just in front of the main path to far behind it
export const ZMIN = -60, ZMAX = 240;   // how far forward and back you can walk
export const BZ0 = 140;                // where building fronts stand
// the scenery beyond the floor moves up so its horizon meets the floor's far edge
export const BACK_SHIFT = Math.round(HZ + (450 - HZ) * FOCAL / (FOCAL + GZ1) - 403);

// In the big open fields the camera also follows you into the distance (camZ), and the floor reaches back to zb.
export function view(camX, hz = HZ, W = 960, o = {}) {
  const cx = camX + W / 2, camZ = o.camZ || 0;
  const s = z => FOCAL / Math.max(60, FOCAL + z - camZ);
  return { camX, camZ, cx, hz, s, x: (x, z) => cx + (x - cx) * s(z), y: (y, z) => hz + (y - hz) * s(z), zf: GZ0, zb: o.zb ?? GZ1 };
}

// Draw a flat paper cutout standing at (x, y) at depth z; fn draws it around (0, 0) at full size.
export function atDepth(c, V, x, y, z, fn) {
  if (FOCAL + z - V.camZ < 180) return;   // behind the camera
  const k = V.s(z);
  c.save(); c.translate(V.x(x, z), V.y(y, z)); c.scale(k, k); fn(); c.restore();
}

export function face(c, pts, fill, lw = 2) {
  c.beginPath(); c.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) c.lineTo(pts[i][0], pts[i][1]);
  c.closePath(); c.fillStyle = fill; c.fill();
  if (lw) { c.lineWidth = lw; c.strokeStyle = INK; c.stroke(); }
}

// Lighten (k > 0) or darken (k < 0) a #rrggbb color.
export function shade(hex, k) {
  const n = parseInt(hex.slice(1), 16);
  const f = v => Math.round(k < 0 ? v * (1 + k) : v + (255 - v) * k);
  return `rgb(${f((n >> 16) & 255)},${f((n >> 8) & 255)},${f(n & 255)})`;
}

// A solid box: (x, y, w, h) is its outline at z = 0; it runs from depth z0 (front) to z1 (back).
// Only the faces turned toward the camera are drawn. `cut` stops the side faces at a water line.
export function box(c, V, x, y, w, h, z0, z1, col, o = {}) {
  z0 = Math.max(z0, V.camZ - 650);   // never draw the part behind the camera
  if (z1 <= z0) return;
  const P = (xx, yy, z) => [V.x(xx, z), V.y(yy, z)];
  const yb = Math.min(y + h, o.cut ?? Infinity);
  if (yb > y && o.sides !== false) {
    if (x > V.cx) face(c, [P(x, y, z1), P(x, y, z0), P(x, yb, z0), P(x, yb, z1)], col.side);
    if (x + w < V.cx) face(c, [P(x + w, y, z1), P(x + w, y, z0), P(x + w, yb, z0), P(x + w, yb, z1)], col.side);
  }
  if (y > V.hz) face(c, [P(x, y, z1), P(x + w, y, z1), P(x + w, y, z0), P(x, y, z0)], col.top);
  else if (y + h < V.hz) face(c, [P(x, y + h, z1), P(x + w, y + h, z1), P(x + w, y + h, z0), P(x, y + h, z0)], col.side);
  if (o.front === false) return;
  const [ax, ay] = P(x, y, z0), [bx, by] = P(x + w, yb, z0);
  if (by > ay) face(c, [[ax, ay], [bx, ay], [bx, by], [ax, by]], Array.isArray(col.front) ? vgrad(c, ay, by, col.front[0], col.front[1]) : col.front);
}

// ---------------------------------------------------------------- terrain
// top: floor color, front: [top, bottom] of the cut face, side: cliff color, floor: texture, lip: grass edge
export const MAT = {
  night: { top: '#8d7bb0', front: ['#5b4a7a', '#3a2f55'], side: '#45385f', floor: 'tile' },
  town: { top: '#c2afdc', front: ['#7a6a98', '#4f4470'], side: '#5d5080', floor: 'tile' },
  grove: { top: '#86d468', front: ['#9a6a45', '#6e4529'], side: '#7a4f30', floor: 'grass', lip: '#7ccf5e' },
  fields: { top: '#9be276', front: ['#a8744a', '#7a5032'], side: '#86583a', floor: 'grass', lip: '#8fdc6a' },
  hills: { top: '#a6e07e', front: ['#a8744a', '#7a5032'], side: '#86583a', floor: 'grass', lip: '#8fdc6a' },
  plains: { top: '#addf86', front: ['#c49a6a', '#94704a'], side: '#a07a52', floor: 'grass', lip: '#98dc78' },
  garden: { top: '#c2f2aa', front: ['#b08a6a', '#8a6a4a'], side: '#94704f', floor: 'grass', lip: '#b6ee9c' },
  lake: { top: '#f6e2a8', front: ['#d9b77a', '#a8854a'], side: '#b8955c', floor: 'sand' },
  mountain: { top: '#d3cdc2', front: ['#8d867c', '#5f5a52'], side: '#6e685f', floor: 'stone' },
  maze: { top: '#5c9a52', front: ['#5e4630', '#3d2c1e'], side: '#4a3726', floor: 'grass', lip: '#4f8a47' },
  cave: { top: '#7d6aa8', front: ['#4a3d6a', '#2c2245'], side: '#3a2f58', floor: 'stone' },
  library: { top: '#b47a48', front: ['#6e4224', '#4a2b16'], side: '#5a361c', floor: 'plank' },
  volcano: { top: '#957468', front: ['#4e3a44', '#2a1e26'], side: '#3a2a33', floor: 'stone' },
  burrow: { top: '#b8875a', front: ['#8a6040', '#5a3a24'], side: '#6e4a30', floor: 'stone' },
  castle: { top: '#bdb6ca', front: ['#7f7890', '#57506a'], side: '#655e78', floor: 'tile' },
  interior: { top: '#c9925c', front: ['#7a4e2c', '#54331b'], side: '#65401f', floor: 'plank' },
};
export const matFor = (theme, R) => (R && R.style && STYLES[R.style] ? { ...MAT.interior, ...STYLES[R.style].mat } : MAT[theme] || MAT.grove);

// Water, lava, ink or brambles fill the pits, as a surface you look down onto. A plain 'pit' is a dark chasm.
// (ground: the room's floor colors, for the lower land you see past the sides of a big field)
// The top half of a brass cog, standing up out of a surface at (x, y), turned to angle a.
function halfGear(c, x, y, r, a) {
  const n = 10;
  c.save();
  c.beginPath(); c.rect(x - r - 2, y - r - 2, 2 * r + 4, r + 2); c.clip();   // (only what sticks up out of the floor)
  c.beginPath();
  for (let i = 0; i <= n * 2; i++) {
    const ang = a + (i / (n * 2)) * TAU, rr = i % 2 ? r : r * 0.8;
    if (i === 0) c.moveTo(x + Math.cos(ang) * rr, y + Math.sin(ang) * rr); else c.lineTo(x + Math.cos(ang) * rr, y + Math.sin(ang) * rr);
  }
  c.closePath();
  c.fillStyle = '#c49a52'; c.fill();
  c.strokeStyle = 'rgba(43,34,53,0.7)'; c.lineWidth = 1.4; c.stroke();
  c.fillStyle = '#8a6a3a'; c.beginPath(); c.arc(x, y, r * 0.45, 0, TAU); c.fill();
  c.fillStyle = '#e8c87a'; c.beginPath(); c.arc(x, y, r * 0.16, 0, TAU); c.fill();
  c.restore();
}

export function drawHazard3d(c, V, R, t, y = 500, kind = R.hazard, ground = null) {
  // the surface reaches from the front of the floor (or just behind the camera) to the back edge
  const zn = Math.max(V.zf, V.camZ - 300), zb = V.zb;
  const half = 480 / V.s(zb) + 120;
  let x0 = Math.min(V.camX - 60, V.cx - half), x1 = Math.max(V.camX + 1020, V.cx + half);
  const P = (xx, z, yy = y) => [V.x(xx, z), V.y(yy, z)];
  const sheet = (pal, a, b, yy = y) => {
    const [, ty] = P(a, zb, yy), [, by] = P(a, zn, yy), g = c.createLinearGradient(0, ty, 0, by);
    g.addColorStop(0, pal[0]); g.addColorStop(1, pal[1]);
    face(c, [P(a, zb, yy), P(b, zb, yy), P(b, zn, yy), P(a, zn, yy)], g, 0);
    c.fillStyle = vgrad(c, by, 560, pal[1], pal[2]); c.fillRect(P(a, zn, yy)[0], by, P(b, zn, yy)[0] - P(a, zn, yy)[0], 560 - by);
  };
  // past the sides of a big field there's no water or lava: the floor ends in a little cliff down to lower land (well
  // below the floor even where a shallow pond's water comes up nearly level with it)
  const edged = zb > GZ1 + 1;
  if (edged) {
    sheet(ground ? [shade(ground.top, -0.12), shade(ground.top, -0.3), shade(ground.side, -0.35)] : ['#2c2238', '#1a1424', '#0c0912'], x0, x1, Math.max(y, 500));
    x0 = Math.max(x0, 0); x1 = Math.min(x1, R.w);
    if (!kind) return;
  }
  const pal = kind === 'lava' ? ['#ffb347', '#ff5a2a', '#a8231e'] : kind === 'water' ? ['#8fd6f2', '#4f9fd6', '#2f6fa8']
    : kind === 'brambles' ? ['#4f6b40', '#3d5a35', '#24361f'] : kind === 'pit' ? ['#2c2238', '#1a1424', '#0c0912']
      : kind === 'gloom' ? ['#4a2f6e', '#2a1a45', '#140b24'] : kind === 'spikes' ? ['#cfc6e0', '#8f86a8', '#3d3552']
        : kind === 'gears' ? ['#8a6a3a', '#5a4422', '#2a1d0e'] : kind === 'blank' ? ['#fdfbf6', '#eee8da', '#d8d0bf'] : ['#3a3160', '#231c40', '#141030'];
  sheet(pal, x0, x1);
  const fy = P(x0, zn)[1];
  // ripples, bubbles or thorns across the surface (a pit is just dark)
  for (let z = zb - 30, k = 0; z > zn && kind !== 'pit'; z -= kind === 'blank' ? 40 : 55, k++) {
    if (z - V.camZ > 1600) continue;   // too far away to see ripples
    const sy = V.y(y, z), hw = 480 / V.s(z) + 100;
    for (let xx = Math.floor((V.cx - hw) / 90) * 90; xx < V.cx + hw; xx += 90) {
      if (edged && (xx < x0 || xx + 60 > x1)) continue;
      const h = hash(xx * 0.37 + k * 11.3), sx = V.x(xx + h * 60, z), r = (8 + h * 10) * V.s(z);
      if (kind === 'water' || kind === 'ink') {
        c.strokeStyle = kind === 'water' ? 'rgba(255,255,255,0.55)' : 'rgba(150,130,220,0.35)'; c.lineWidth = 2;
        const wob = Math.sin(t * 2 + h * 9) * 3;
        c.beginPath(); c.moveTo(sx - r + wob, sy); c.lineTo(sx + r + wob, sy); c.stroke();
      } else if (kind === 'lava') {
        const q = (t * 0.6 + h) % 1;
        c.strokeStyle = `rgba(255,230,150,${1 - q})`; c.lineWidth = 2;
        c.beginPath(); c.arc(sx, sy - q * 5, 2 + q * r * 0.5, Math.PI, TAU); c.stroke();
      } else if (kind === 'gloom') {
        // Gloom goo: domes that swell and pop, and now and then a pair of eyes peeking out
        const q = (t * 0.45 + h) % 1, rr = r * (0.45 + q * 0.75);
        c.fillStyle = `rgba(110,72,160,${0.9 - q * 0.6})`;
        c.beginPath(); c.ellipse(sx, sy + 1, rr, rr * 0.7, 0, Math.PI, TAU); c.fill();
        c.fillStyle = `rgba(200,170,255,${0.45 * (1 - q)})`;
        c.beginPath(); c.ellipse(sx - rr * 0.35, sy - rr * 0.35, rr * 0.22, rr * 0.14, -0.5, 0, TAU); c.fill();
        if (h > 0.83) {
          const open = Math.max(0.08, Math.abs(Math.sin(t * 0.9 + h * 31)));
          for (const ex of [-1, 1]) {
            c.fillStyle = '#fffaf0'; c.beginPath(); c.ellipse(sx + ex * r * 0.55, sy - r * 0.9, r * 0.32, r * 0.42 * open, 0, 0, TAU); c.fill();
            c.fillStyle = '#140b24'; c.beginPath(); c.ellipse(sx + ex * r * 0.55, sy - r * 0.86, r * 0.14, r * 0.2 * open, 0, 0, TAU); c.fill();
          }
        }
      } else if (kind === 'spikes') {
        // folded-paper spikes: a lit face and a shaded face, with a crease down the middle
        const hh = r * 1.9;
        c.fillStyle = '#f4efff'; c.beginPath(); c.moveTo(sx - r * 0.7, sy + 2); c.lineTo(sx, sy - hh); c.lineTo(sx, sy + 2); c.fill();
        c.fillStyle = '#a89fc4'; c.beginPath(); c.moveTo(sx, sy + 2); c.lineTo(sx, sy - hh); c.lineTo(sx + r * 0.7, sy + 2); c.fill();
        c.strokeStyle = 'rgba(43,34,53,0.6)'; c.lineWidth = 1.2;
        c.beginPath(); c.moveTo(sx - r * 0.7, sy + 2); c.lineTo(sx, sy - hh); c.lineTo(sx + r * 0.7, sy + 2); c.stroke();
      } else if (kind === 'gears') {
        // clock gears half sunk in the floor of the gap, grinding round (neighbours turn opposite ways)
        halfGear(c, sx, sy + 2, r * 1.5, t * 1.4 * (Math.floor(h * 10) % 2 ? 1 : -1) + h * 6);
      } else if (kind === 'blank') {
        // erased paper: faint notebook lines, rubbed-out smudges and eraser crumbs
        c.strokeStyle = 'rgba(120,150,210,0.22)'; c.lineWidth = 1.5;
        c.beginPath(); c.moveTo(sx - r * 2.2, sy); c.lineTo(sx + r * 2.2, sy); c.stroke();
        if (h > 0.55) {
          c.strokeStyle = 'rgba(150,140,160,0.28)'; c.lineWidth = 2;
          c.beginPath(); c.moveTo(sx - r, sy - r * 0.2); c.quadraticCurveTo(sx, sy - r * 0.6, sx + r, sy - r * 0.1); c.stroke();
        }
        if (h > 0.8) { c.fillStyle = 'rgba(255,170,190,0.55)'; c.beginPath(); c.ellipse(sx + r * 0.6, sy - 2, r * 0.25, r * 0.12, 0, 0, TAU); c.fill(); }
      } else {
        c.fillStyle = '#2a3d24';
        c.beginPath(); c.moveTo(sx - r, sy + 2); c.lineTo(sx - r * 0.3, sy - r * 1.4); c.lineTo(sx + r * 0.2, sy + 2); c.fill();
        c.fillStyle = '#fff4e0'; c.beginPath(); c.moveTo(sx - r * 0.45, sy - r * 0.8); c.lineTo(sx - r * 0.3, sy - r * 1.4); c.lineTo(sx - r * 0.15, sy - r * 0.8); c.fill();
      }
    }
  }
  if (kind === 'lava') glowDot(c, V.camX + 480, fy, 600, '255,120,60', 0.18);
}

// The ground is a set of rectangles on the floor plan, { x0, x1, z0, z1, y }: in old rooms one per stretch of floor
// (running from front to back), in the big fields split up around ponds, rivers and pits. Cliff sides and cut faces
// are only drawn where nothing as high covers them. Tops and cut faces go far to near, so nearer floor hides what's behind.
const subtract = (spans, a, b) => spans.flatMap(([p, q]) => (b <= p || a >= q ? [[p, q]] : [[p, a], [b, q]].filter(([u, v]) => v - u > 1)));

export function drawFloor(c, V, R, rects, theme, t, cut) {
  const M = matFor(theme, R);
  const P = (xx, yy, z) => [V.x(xx, z), V.y(yy, z)];
  const yb = cut ?? 700, near = V.camZ - 500;
  const field = V.zb > GZ1 + 1;
  for (const r of rects) {
    for (const [side, x] of [[-1, r.x0], [1, r.x1]]) {
      if (side < 0 ? !(x > V.cx && x > 0) : !(x < V.cx && x < R.w)) continue;
      let spans = [[Math.max(r.z0, near), r.z1]];
      for (const n of rects) if (n !== r && n.y <= r.y && (side < 0 ? n.x1 === x : n.x0 === x)) spans = subtract(spans, n.z0, n.z1);
      for (const [a, b] of spans) face(c, [P(x, r.y, b), P(x, r.y, a), P(x, yb, a), P(x, yb, b)], M.side);
    }
  }
  const order = [...rects].sort((a, b) => b.z0 - a.z0 || b.y - a.y);
  const fronts = [];   // the cut faces along the front of the room, joined up and drawn last
  for (const r of order) {
    if (r.z1 < near) continue;
    const z0 = Math.max(r.z0, near), { x0, x1, y, z1 } = r;
    const hw0 = 480 / V.s(z1) + 80;
    if (x1 < V.cx - hw0 || x0 > V.cx + hw0) continue;   // off to the side
    face(c, [P(x0, y, z1), P(x1, y, z1), P(x1, y, z0), P(x0, y, z0)], M.top, 0);
    // outline only the edges where the floor ends (not where one piece of floor meets the next)
    c.strokeStyle = INK; c.lineWidth = 2;
    let backs = [[x0, x1]];
    if (z1 < V.zb - 0.5) for (const n of rects) if (n !== r && n.y <= y && Math.abs(n.z0 - z1) < 0.5) backs = subtract(backs, n.x0, n.x1);
    for (const [a, b] of backs) { c.beginPath(); c.moveTo(...P(a, y, z1)); c.lineTo(...P(b, y, z1)); c.stroke(); }
    for (const [side, x] of [[-1, x0], [1, x1]]) {
      let spans = [[z0, z1]];
      for (const n of rects) if (n !== r && n.y <= y && (side < 0 ? n.x1 === x : n.x0 === x)) spans = subtract(spans, n.z0, n.z1);
      for (const [a, b] of spans) { c.beginPath(); c.moveTo(...P(x, y, b)); c.lineTo(...P(x, y, a)); c.stroke(); }
    }
    c.save();
    c.beginPath(); c.moveTo(...P(x0, y, z1)); c.lineTo(...P(x1, y, z1)); c.lineTo(...P(x1, y, z0)); c.lineTo(...P(x0, y, z0)); c.closePath(); c.clip();
    if (field) fieldTexture(c, V, M, r, z0);
    else floorTexture(c, V, M, Math.max(x0, V.camX - 80), Math.min(x1, V.camX + 1040), y, t);
    c.restore();
    // a soft shadow along the back edge of the room sells the depth
    if (z1 >= V.zb - 0.5) {
      const [bx0, by] = P(x0, y, z1), [bx1] = P(x1, y, z1);
      c.fillStyle = vgrad(c, by, by + 14, 'rgba(20,10,30,0.18)', 'rgba(20,10,30,0)'); c.fillRect(bx0, by, bx1 - bx0, 14);
    }
    // the cut face at the front: the front of the room (drawn last, joined up), or the far bank of a pond or a river
    if (r.z0 < near) continue;
    if (r.z0 <= V.zf + 0.5) { fronts.push(r); continue; }
    let spans = [[x0, x1]];
    for (const n of rects) if (n !== r && n.y <= r.y && Math.abs(n.z1 - r.z0) < 0.5) spans = subtract(spans, n.x0, n.x1);
    for (const [a, b] of spans) cutFace(c, V, M, a, b, y, r.z0, V.y(yb, r.z0));
  }
  fronts.sort((a, b) => b.y - a.y || a.x0 - b.x0);
  for (let i = 0; i < fronts.length; i++) {
    const r = fronts[i];
    let x1 = r.x1;
    while (i + 1 < fronts.length && fronts[i + 1].y === r.y && Math.abs(fronts[i + 1].x0 - x1) < 0.5) x1 = fronts[++i].x1;
    cutFace(c, V, M, r.x0, x1, r.y, r.z0, 560);
  }
}

function cutFace(c, V, M, x0, x1, y, z, bottom) {
  // (drawing coordinates here are world x shifted by the camera, so the screen runs from camX to camX + 960)
  const ax = V.x(x0, z), bx = V.x(x1, z), ay = V.y(y, z), k = V.s(z);
  if (bx < V.camX - 40 || ax > V.camX + 1000 || bottom <= ay) return;
  const lo = Math.max(ax, V.camX - 80), hi = Math.min(bx, V.camX + 1040);
  c.save(); c.lineJoin = 'round';
  c.beginPath(); c.rect(ax, ay, bx - ax, bottom - ay);
  c.fillStyle = vgrad(c, ay, ay + 70 * k, M.front[0], M.front[1]); c.fill();
  c.lineWidth = 2.4; c.strokeStyle = INK; c.stroke();
  c.clip();
  c.fillStyle = 'rgba(20,10,30,0.15)';
  for (let i = Math.floor(lo / 40); i < hi / 40; i++) {
    const px = i * 40 + (i * 7) % 20;
    c.beginPath(); c.arc(px, ay + (22 + (i * 11) % 18) * k, 3 * k, 0, TAU); c.fill();
  }
  if (M.lip) {
    c.fillStyle = M.lip; c.beginPath(); c.moveTo(ax, ay + 10 * k);
    for (let px = ax; px <= bx; px += 15) c.quadraticCurveTo(px + 7.5, ay + 19 * k, Math.min(px + 15, bx), ay + 10 * k);
    c.lineTo(bx, ay); c.lineTo(ax, ay); c.closePath(); c.fill();
  }
  c.restore();
  c.fillStyle = 'rgba(255,250,240,0.55)'; c.fillRect(ax, ay - 1, bx - ax, 2);
}

// Grass, sand or pebbles across a big field. Every mark has its own fixed spot on the floor, so nothing swims about as
// the camera moves; the further away, the fewer of them show (about as many on screen near and far), each one fading
// in at its own distance as you walk toward it.
function fieldTexture(c, V, M, r, zn) {
  const P = (xx, z) => [V.x(xx, z), V.y(r.y, z)];
  // (start where this floor leaves the bottom of the 540-tall screen: further back for a raised floor)
  const z0 = Math.max(zn, V.camZ + (FOCAL * (r.y - V.hz)) / (540 - V.hz) - FOCAL - 30), z1 = Math.min(r.z1, V.camZ + 1200);
  if (z1 <= z0) return;
  if (M.floor === 'grass') {
    c.fillStyle = 'rgba(255,255,255,0.09)';
    for (let z = Math.floor(z0 / 180) * 180; z < z1; z += 180) {
      const hw = 480 / V.s(z) + 60, xa = Math.max(r.x0, V.cx - hw), xb = Math.min(r.x1, V.cx + hw);
      if (xb <= xa) continue;
      const [ax, ay] = P(xa, z + 80), [bx, by] = P(xb, z);
      c.fillRect(ax, ay, bx - ax, by - ay);
    }
  }
  let alpha = 1;
  for (let iz = Math.ceil(z0 / 40); iz * 40 < z1; iz++) {
    const z = iz * 40, k = V.s(z), keep = k * k;
    const hw = 480 / k + 40, xa = Math.max(r.x0, V.cx - hw), xb = Math.min(r.x1, V.cx + hw);
    for (let ix = Math.ceil(xa / 46); ix * 46 < xb; ix++) {
      const xx = ix * 46, fade = (keep - hash(xx * 0.29 + z * 0.53 + 7.7)) / 0.06;
      if (fade <= 0) continue;
      const h = hash(xx * 0.71 + z * 0.37);
      if (h > 0.6) continue;
      const a = Math.min(1, fade);
      if (a !== alpha) c.globalAlpha = alpha = a;
      const mz = z + h * 30, mk = V.s(mz), [sx, sy] = P(xx + h * 30, mz);
      if (M.floor === 'grass') {
        c.strokeStyle = 'rgba(40,90,30,0.45)'; c.lineWidth = 2 * mk;
        c.beginPath(); c.moveTo(sx - 4 * mk, sy); c.lineTo(sx - 6 * mk, sy - 7 * mk); c.moveTo(sx, sy); c.lineTo(sx, sy - 9 * mk); c.moveTo(sx + 4 * mk, sy); c.lineTo(sx + 6 * mk, sy - 7 * mk); c.stroke();
        if (h > 0.5) { c.fillStyle = ['#fffaf0', '#ffd23f', '#ff9ab0'][Math.floor(h * 30) % 3]; c.beginPath(); c.arc(sx + 8 * mk, sy - 6 * mk, 2.6 * mk, 0, TAU); c.fill(); }
      } else {
        c.fillStyle = M.floor === 'sand' ? 'rgba(120,80,30,0.2)' : 'rgba(20,10,30,0.22)';
        c.beginPath(); c.ellipse(sx, sy, (3 + h * 5) * mk, (1.6 + h * 2) * mk, 0, 0, TAU); c.fill();
      }
    }
  }
  c.globalAlpha = 1;
}

function floorTexture(c, V, M, x0, x1, y, t) {
  const P = (xx, z) => [V.x(xx, z), V.y(y, z)];
  const line = (a, b) => { c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke(); };
  if (M.floor === 'tile' || M.floor === 'plank') {
    c.strokeStyle = M.floor === 'tile' ? 'rgba(43,34,53,0.16)' : 'rgba(60,30,10,0.28)'; c.lineWidth = 1.5;
    const rows = M.floor === 'tile' ? [210, 160, 110, 60, 10, -40] : [230, 195, 160, 125, 90, 55, 20, -15, -50];
    for (const z of rows) line(P(x0, z), P(x1, z));
    if (M.floor === 'tile') {
      for (let xx = Math.ceil(x0 / 64) * 64; xx < x1; xx += 64) line(P(xx, GZ1), P(xx, GZ0));
    } else {
      const zs = [GZ1, ...rows, GZ0];
      for (let r = 0; r < zs.length - 1; r++) {
        for (let xx = Math.ceil(x0 / 150) * 150 + (r % 2) * 75; xx < x1; xx += 150) line(P(xx, zs[r]), P(xx, zs[r + 1]));
      }
    }
    return;
  }
  if (M.floor === 'grass') {
    for (const [z, a] of [[220, 0.12], [140, 0.1], [60, 0.1], [-20, 0.08]]) {
      c.fillStyle = `rgba(255,255,255,${a})`;
      const [ax, ay] = P(x0, z), [bx, by] = P(x1, z - 22);
      c.fillRect(ax, ay, bx - ax, by - ay);
    }
  }
  for (let xx = Math.floor(x0 / 46) * 46; xx < x1; xx += 46) {
    const h = hash(xx), z = GZ1 - 10 - h * (GZ1 - GZ0 - 20), k = V.s(z), [sx, sy] = P(xx + h * 30, z);
    if (M.floor === 'grass') {
      c.strokeStyle = 'rgba(40,90,30,0.45)'; c.lineWidth = 2 * k;
      c.beginPath(); c.moveTo(sx - 4 * k, sy); c.lineTo(sx - 6 * k, sy - 7 * k); c.moveTo(sx, sy); c.lineTo(sx, sy - 9 * k); c.moveTo(sx + 4 * k, sy); c.lineTo(sx + 6 * k, sy - 7 * k); c.stroke();
      if (h > 0.82) { c.fillStyle = ['#fffaf0', '#ffd23f', '#ff9ab0'][Math.floor(h * 30) % 3]; c.beginPath(); c.arc(sx + 8 * k, sy - 6 * k, 2.6 * k, 0, TAU); c.fill(); }
    } else {
      c.fillStyle = M.floor === 'sand' ? 'rgba(120,80,30,0.2)' : 'rgba(20,10,30,0.22)';
      c.beginPath(); c.ellipse(sx, sy, (3 + h * 5) * k, (1.6 + h * 2) * k, 0, 0, TAU); c.fill();
    }
  }
  void t;
}

const PLAT_COL = theme => {
  if (['grove', 'fields', 'lake', 'garden', 'burrow', 'hills', 'plains'].includes(theme)) return { top: '#dca46c', front: ['#c58b55', '#93603a'], side: '#86562f', grass: theme !== 'lake' && theme !== 'burrow' };
  if (theme === 'cave') return { top: '#9a88c6', front: ['#7d6aa8', '#4f427a'], side: '#463a6e' };
  if (theme === 'mountain') return { top: '#d0cac0', front: ['#b6b0a6', '#7d766c'], side: '#6e685f' };
  if (theme === 'maze') return { top: '#79a86a', front: ['#5e8a4f', '#3d5c33'], side: '#3a5530' };
  if (theme === 'library' || theme === 'interior') return { top: '#b47a48', front: ['#8a5a3c', '#5e3b24'], side: '#4e3020' };
  if (theme === 'volcano') return { top: '#8a7280', front: ['#6e5660', '#3e2c36'], side: '#3a2a33', glow: true };
  if (theme === 'castle') return { top: '#c8c2d4', front: ['#a8a1b8', '#77708c'], side: '#655e78' };
  return { top: '#a898c4', front: ['#8a7aa8', '#5d4f80'], side: '#4f426e' };
};

// A floating platform. z0..z1 is how far it reaches into the distance (bridges over pits span the whole floor).
export function drawPlat3d(c, V, x, y, w, theme, hidden = false, z0 = -50, z1 = 90) {
  const col = hidden ? { top: 'rgba(200,245,255,0.8)', front: ['rgba(159,230,255,0.85)', 'rgba(74,167,201,0.85)'], side: 'rgba(90,170,210,0.8)' } : PLAT_COL(theme);
  z0 = Math.max(z0, V.zf); z1 = Math.min(z1, V.zb);
  box(c, V, x, y, w, 16, z0, z1, col);
  if (col.grass) { c.fillStyle = '#7ccf5e'; const [ax, ay] = [V.x(x + 3, z0), V.y(y + 1, z0)]; c.fillRect(ax, ay, V.x(x + w - 3, z0) - ax, 4); }
  if (col.glow) { c.fillStyle = 'rgba(255,140,60,0.75)'; const ax = V.x(x + 8, z0); c.fillRect(ax, V.y(y + 11, z0), V.x(x + w - 8, z0) - ax, 2.5); }
  if (hidden) glowDot(c, V.x(x + w / 2, 0), V.y(y + 8, 0), w * 0.6, '160,235,255', 0.35);
}

// A dark patch on the floor right under something floating, so you can line yourself up with it.
export function drawDropShadow(c, V, x, w, z0, z1, y, a = 0.2) {
  z0 = Math.max(z0, V.zf, V.camZ - 400); z1 = Math.min(z1, V.zb);
  if (z1 <= z0) return;
  const P = (xx, z) => [V.x(xx, z), V.y(y, z)];
  face(c, [P(x + 4, z1 - 4), P(x + w - 4, z1 - 4), P(x + w - 4, z0 + 4), P(x + 4, z0 + 4)], `rgba(20,10,30,${a})`, 0);
}

// A tall hedge you have to walk around (front of it or behind it).
export function drawHedge3d(c, V, x, y, w, h, z0, z1) {
  box(c, V, x, y - h, w, h, z0, z1, { top: '#6cc068', front: ['#4f9a52', '#2f6a34'], side: '#3d7a40' });
  const X = xx => V.x(xx, z0), Y = yy => V.y(yy, z0);
  c.fillStyle = 'rgba(255,255,255,0.18)';
  for (let i = 0; i < w / 18; i++) { c.beginPath(); c.ellipse(X(x + 9 + i * 18), Y(y - h + 14 + (i % 3) * 22), 5, 3, -0.4, 0, TAU); c.fill(); }
  c.fillStyle = '#e5534b';
  for (let i = 0; i < w / 40; i++) { c.beginPath(); c.arc(X(x + 20 + i * 40), Y(y - h * 0.5 + (i % 2) * 14), 3, 0, TAU); c.fill(); }
}

// (walls, cracks, gates and low rocks reach the whole way back unless they're told how far: z0..z1)
export function drawWall3d(c, V, x, y, w, h, theme, R, z0 = GZ0, z1 = V.zb) {
  const M = matFor(theme, R);
  box(c, V, x, y, w, h, z0, z1, { top: M.top, front: M.front, side: M.side });
}

export function drawCrack3d(c, V, x, y, w, h, theme, z0 = GZ0, z1 = V.zb) {
  const base = theme === 'cave' ? ['#5d4f80', '#3f3460', '#4a3d6a', '#7d6aa8'] : ['#9d97a8', '#6f6a7c', '#5f5a6c', '#bdb7c8'];
  box(c, V, x, y, w, h, z0, z1, { top: base[3], front: [base[0], base[1]], side: base[2] });
  if (z0 < V.camZ - 650) return;   // its front is behind the camera
  const s0 = V.s(z0), X = xx => V.x(xx, z0), Y = yy => V.y(yy, z0);
  c.strokeStyle = 'rgba(43,34,53,0.35)'; c.lineWidth = 1.5;
  for (let yy = y + 24; yy < y + h; yy += 24) { c.beginPath(); c.moveTo(X(x + 3), Y(yy)); c.lineTo(X(x + w - 3), Y(yy)); c.stroke(); }
  c.strokeStyle = INK; c.lineWidth = 2.6 * s0;
  c.beginPath(); c.moveTo(X(x + w * 0.5), Y(y + 6)); c.lineTo(X(x + w * 0.35), Y(y + h * 0.3)); c.lineTo(X(x + w * 0.62), Y(y + h * 0.5));
  c.lineTo(X(x + w * 0.4), Y(y + h * 0.72)); c.lineTo(X(x + w * 0.55), Y(y + h - 6)); c.stroke();
}

export function drawGate3d(c, V, x, y, w, h, z0 = GZ0 + 20, z1 = V.zb - 20) {
  box(c, V, x, y, w, h, z0, z1, { top: '#a8794e', front: ['#8a5a3c', '#5e3b24'], side: '#4e3020' });
  if (z0 < V.camZ - 650) return;
  const X = xx => V.x(xx, z0), Y = yy => V.y(yy, z0);
  c.strokeStyle = '#3b3350'; c.lineWidth = 4;
  for (let gx = x + 10; gx < x + w - 4; gx += 14) { c.beginPath(); c.moveTo(X(gx), Y(y + 4)); c.lineTo(X(gx), Y(y + h - 4)); c.stroke(); }
  for (const gy of [y + 22, y + h - 22]) { c.beginPath(); c.moveTo(X(x + 3), Y(gy)); c.lineTo(X(x + w - 3), Y(gy)); c.stroke(); }
}

export function drawLowRock3d(c, V, x, top, w, theme, z0 = GZ0, z1 = V.zb) {
  const col = theme === 'volcano' ? ['#8a7680', '#4e3e48', '#3e2e38', '#a08c96'] : theme === 'cave' ? ['#7d6aa8', '#4f427a', '#3e3466', '#9a88c6'] : ['#a9a3b2', '#6f6a7c', '#5f5a6c', '#c4bfcc'];
  box(c, V, x, -40, w, top + 40, z0, z1, { top: col[3], front: [col[0], col[1]], side: col[2] });
  if (z0 < V.camZ - 650) return;
  // jagged teeth along the bottom of the front face
  const n = Math.max(3, Math.round(w / 26)), X = xx => V.x(xx, z0), Y = yy => V.y(yy, z0);
  c.fillStyle = col[1]; c.strokeStyle = INK; c.lineWidth = 2;
  c.beginPath(); c.moveTo(X(x), Y(top));
  for (let i = 0; i <= n; i++) c.lineTo(X(x + (w * i) / n), Y(top + (i % 2 ? 8 : 0)));
  c.lineTo(X(x + w), Y(top)); c.closePath(); c.fill(); c.stroke();
  c.fillStyle = 'rgba(10,5,15,0.35)';
  const [ax, ay] = [X(x + 4), Y(top + 6)];
  c.fillRect(ax, ay, X(x + w - 4) - ax, Y(top + 40) - ay);
}

export function drawBlock3d(c, V, x, y, o) {
  const used = o.used, by = y - (o.bump || 0), z = o.z || 0;
  box(c, V, x, by, 44, 44, z - 22, z + 22, used ? { top: '#d2b48a', front: '#8f6b44', side: '#7a5a38' } : { top: '#fff0a8', front: '#efa62a', side: '#d48a1c' }, { front: false });
  atDepth(c, V, x, by, z - 22, () => drawBlock(c, 0, 0, { t: o.t, used }));
}

// A path that leads off into the background (to another place), with an arch over it.
// o.z: how far back the arch stands (the far back of the floor unless a room says); o.part: 'floor' or 'arch' to draw half.
export function drawPathDoor(c, V, x, y, o = {}) {
  const P = (xx, z) => [V.x(xx, z), V.y(y, z)];
  const w = 70, az = o.z ?? GZ1, pz = az - GZ1;
  if (o.part !== 'arch') {
    c.fillStyle = o.col || 'rgba(214,180,120,0.75)';
    c.beginPath(); c.moveTo(...P(x - w * 0.42, az)); c.lineTo(...P(x + w * 0.42, az)); c.lineTo(...P(x + w * 0.62, pz + 6)); c.lineTo(...P(x - w * 0.62, pz + 6)); c.closePath(); c.fill();
    c.fillStyle = 'rgba(120,80,40,0.25)';
    for (let z = 120; z > 0; z -= 34) { const [sx, sy] = P(x + Math.sin(z) * 8, pz + z), k = V.s(pz + z); c.beginPath(); c.ellipse(sx, sy, 7 * k, 2.5 * k, 0, 0, TAU); c.fill(); }
  }
  if (o.part === 'floor') return;
  atDepth(c, V, x, y, az - 10, () => {
    const col = o.arch || '#8a5a3c', t = o.t || 0;
    // the doorway: dark inside, with a glow and a few motes of light from the place beyond, so it reads as a way
    // through to somewhere else (not an empty frame you see the field through)
    const g = c.createLinearGradient(0, -146, 0, 0);
    g.addColorStop(0, '#120d1e'); g.addColorStop(1, '#2c2244');
    c.fillStyle = g; c.fillRect(-46, -147, 92, 147);
    const glow = c.createRadialGradient(0, -6, 4, 0, -6, 62);
    glow.addColorStop(0, o.locked ? 'rgba(170,160,200,0.25)' : 'rgba(255,226,150,0.5)'); glow.addColorStop(1, 'rgba(255,226,150,0)');
    c.fillStyle = glow; c.fillRect(-46, -80, 92, 80);
    if (!o.locked) {
      for (let i = 0; i < 4; i++) {
        const q = (t * 0.35 + i * 0.27) % 1;
        c.fillStyle = `rgba(255,236,170,${0.8 * (1 - q)})`;
        c.beginPath(); c.arc(Math.sin(t * 1.3 + i * 2.1) * 22, -8 - q * 120, 2.2, 0, TAU); c.fill();
      }
    }
    paper(c, p => {
      shape(c, p, rrect(-58, -150, 14, 150, 4), col);
      shape(c, p, rrect(44, -150, 14, 150, 4), col);
      shape(c, p, rrect(-70, -170, 140, 24, 8), shade(col, 0.15));
      if (o.locked) {
        shape(c, p, rrect(-48, -96, 96, 14, 3), '#a8794e');
        shape(c, p, rrect(-48, -56, 96, 14, 3), '#a8794e');
      }
    });
    if (o.locked) { c.font = '28px "Segoe UI Emoji", sans-serif'; c.textAlign = 'center'; c.fillText('🔒', 0, -66); }
    if (o.label) {
      c.font = 'bold 16px Fredoka, sans-serif'; c.textAlign = 'center';
      const tw = Math.min(170, c.measureText(o.label).width + 16);
      c.fillStyle = PAPER; c.beginPath(); rrect(-tw / 2, -167, tw, 18, 6)(c); c.fill();
      c.fillStyle = INK; c.fillText(o.label, 0, -152, 160);
    }
  });
}

// A doormat at the front of a room: walk here and press E to go back outside.
export function drawExitMat(c, V, x, y, t) {
  const P = (xx, z) => [V.x(xx, z), V.y(y, z)];
  c.fillStyle = '#b8483e';
  c.beginPath(); c.moveTo(...P(x - 50, 20)); c.lineTo(...P(x + 50, 20)); c.lineTo(...P(x + 54, -70)); c.lineTo(...P(x - 54, -70)); c.closePath(); c.fill();
  c.strokeStyle = '#fffaf0'; c.lineWidth = 2; c.stroke();
  const [ax, ay] = P(x, -48 + Math.sin(t * 4) * 6);
  c.fillStyle = '#ffe066'; c.strokeStyle = INK; c.lineWidth = 2.5;
  c.beginPath(); c.moveTo(ax - 12, ay - 8); c.lineTo(ax + 12, ay - 8); c.lineTo(ax, ay + 6); c.closePath(); c.fill(); c.stroke();
}

// A doorway in an interior's back wall (to another room inside), with a carpet runner leading to it.
// (in a big field it can stand further back, o.z; its carpet is part 'floor' and the doorway part 'arch')
export function drawBackDoor(c, V, x, y, o = {}) {
  const z = o.z ?? GZ1 - 2, P = (xx, zz) => [V.x(xx, zz), V.y(y, zz)];
  if (o.part !== 'arch') {
    c.fillStyle = o.carpet || 'rgba(180,60,70,0.8)';
    c.beginPath(); c.moveTo(...P(x - 34, z)); c.lineTo(...P(x + 34, z)); c.lineTo(...P(x + 40, z - GZ1 + 2)); c.lineTo(...P(x - 40, z - GZ1 + 2)); c.closePath(); c.fill();
  }
  if (o.part === 'floor') return;
  atDepth(c, V, x, y, z, () => {
    paper(c, p => shape(c, p, cc => { cc.moveTo(-42, 0); cc.lineTo(-42, -100); cc.arc(0, -100, 42, Math.PI, 0); cc.lineTo(42, 0); cc.closePath(); }, o.frame || '#6e5a50'));
    c.fillStyle = o.locked ? '#4a3d5c' : '#1c1428';
    c.beginPath(); c.moveTo(-32, 0); c.lineTo(-32, -100); c.arc(0, -100, 32, Math.PI, 0); c.lineTo(32, 0); c.closePath(); c.fill();
    if (o.locked) { c.font = '26px "Segoe UI Emoji", sans-serif'; c.textAlign = 'center'; c.fillText('🔒', 0, -70); }
  });
}

// ---------------------------------------------------------------- buildings with depth
export function drawBuilding3d(c, V, x, y, o) {
  const w = o.w || 170, h = o.h || 140, z0 = o.z ?? BZ0, z1 = o.z != null ? o.z + (o.depth || 130) : GZ1;
  const P = (xx, yy, z) => [V.x(xx, z), V.y(yy, z)];
  const wall = o.wall2 || '#8a76b0';
  // (walking away from a house leaves its front behind the camera: its sides and roof start just behind the camera then)
  const zs = Math.max(z0, V.camZ - 650);
  if (z1 <= zs) return;
  if (x - w / 2 > V.cx) face(c, [P(x - w / 2, y - h, z1), P(x - w / 2, y - h, zs), P(x - w / 2, y, zs), P(x - w / 2, y, z1)], shade(wall, -0.25));
  if (x + w / 2 < V.cx) face(c, [P(x + w / 2, y - h, z1), P(x + w / 2, y - h, zs), P(x + w / 2, y, zs), P(x + w / 2, y, z1)], shade(wall, -0.25));
  const L = x - w / 2 - 16, R = x + w / 2 + 16, ey = y - h + 2, py = y - h - w * 0.42;
  const roof = o.roof || '#c45a5a';
  face(c, [P(L, ey, z1 + 10), P(x, py, z1 + 10), P(x, py, zs), P(L, ey, zs)], shade(roof, -0.12));
  face(c, [P(x, py, z1 + 10), P(R, ey, z1 + 10), P(R, ey, zs), P(x, py, zs)], shade(roof, -0.28));
  if (o.chimney) {
    atDepth(c, V, x + w * 0.25, py + w * 0.18, z1 - 30, () => paper(c, p => shape(c, p, rrect(-12, -50, 24, 50, 3), '#7a5a6a')));
  }
  atDepth(c, V, x, y, z0, () => drawBuilding(c, 0, 0, { ...o, t: o.t }));
}

// A plain house (Mothwick's, the farmhouse...) is a building without a shop sign.
export function drawHouse3d(c, V, x, y, o = {}) {
  drawBuilding3d(c, V, x, y, { w: 180, h: 120, wall: '#8a6a9a', wall2: '#5d4a70', roof: '#c45a5a', chimney: true, ...o });
}

// ---------------------------------------------------------------- scenery in front of and behind the path
export const DECOR = {
  grove: { back: ['tree', 'tree', 'bush'], front: ['tuft', 'flower', 'mushroom', 'fern'] },
  fields: { back: ['tree', 'fence', 'hay', 'fence'], front: ['tuft', 'flower', 'tuft'] },
  hills: { back: ['tree', 'fence', 'flag'], front: ['tuft', 'flower'] },
  plains: { back: ['pinwheel', 'tree', 'hay', 'fence', 'pinwheel'], front: ['tuft', 'flower', 'flower'] },
  garden: { back: ['rosebush', 'tree'], front: ['flower', 'flower', 'tuft'] },
  town: { back: ['planter', 'fence', 'lamp'], front: ['pot', 'crate'] },
  night: { back: ['fence', 'planter'], front: ['crate'] },
  lake: { back: ['reeds', 'tree'], front: ['reeds', 'shell'] },
  mountain: { back: ['pine', 'rock', 'pine'], front: ['rock', 'tuft'] },
  cave: { back: ['crystal', 'stalag'], front: ['crystal', 'pebbles'] },
  volcano: { back: ['rock', 'vent'], front: ['rock', 'pebbles'] },
  maze: { back: ['hedge'], front: ['thorn', 'tuft'] },
  castle: { back: ['pillar', 'banner'], front: ['urn'] },
  burrow: { back: ['root'], front: ['pebbles'] },
};
const decorCache = new WeakMap();

// Scenery is scattered by a seed from the room, skipping spots where something important stands.
export function decorFor(R, id, theme, groundAt) {
  const hit = decorCache.get(R);
  if (hit && hit.theme === theme) return hit.out;
  const set = DECOR[theme] || null;
  const out = { back: [], front: [] };
  if (set && !R.style) {
    const busy = [];
    for (const k of ['doors', 'signs', 'npcs', 'shops', 'boards', 'shrines', 'chests', 'fish', 'braziers', 'seals', 'furniture']) for (const o of R[k] || []) busy.push(o.x);
    for (const p of R.props || []) busy.push(p.x, p.x - 80, p.x + 80);
    for (const x of R.lamps || []) busy.push(x);
    let seed = 0;
    for (const ch of id) seed = (seed * 31 + ch.charCodeAt(0)) % 10007;
    for (const [layer, step, chance] of [['back', 230, 0.8], ['front', 260, 0.55]]) {
      for (let x = 60; x < R.w - 40; x += step) {
        const h = hash(seed + x * 0.013 + (layer === 'front' ? 77 : 0));
        if (h > chance) continue;
        const xx = x + (hash(seed + x) - 0.5) * step * 0.6;
        if (layer === 'back' && busy.some(b => Math.abs(b - xx) < 110)) continue;
        if (groundAt(xx) == null) continue;
        const list = set[layer];
        out[layer].push({ x: xx, kind: list[Math.floor(hash(seed * 3 + x) * list.length)], k: 0.85 + hash(x + seed) * 0.3 });
      }
    }
  }
  decorCache.set(R, { theme, out });
  return out;
}

// ---------------------------------------------------------------- scenery across the big fields
// What grows where ([kind, weight]), how thick it grows, and what lines the far edge of the field.
export const FIELD_DECOR = {
  plains: { dens: 0.5, kinds: [['tree', 3], ['bush', 3], ['flower', 5], ['tuft', 4], ['pinwheel', 2], ['rock', 1], ['hay', 1]], edge: ['tree', 'pinwheel', 'tree', 'bush'] },
  fields: { dens: 0.48, kinds: [['tree', 3], ['bush', 2], ['flower', 4], ['tuft', 4], ['hay', 2]], edge: ['tree', 'tree', 'bush'] },
  hills: { dens: 0.45, kinds: [['tree', 3], ['flower', 3], ['tuft', 3], ['bush', 2], ['rock', 1]], edge: ['tree', 'tree', 'bush'] },
  lake: { dens: 0.42, kinds: [['reeds', 3], ['tree', 2], ['shell', 2], ['tuft', 2], ['rock', 1]], edge: ['tree', 'reeds', 'tree'] },
  grove: { dens: 0.6, kinds: [['tree', 6], ['bush', 3], ['mushroom', 3], ['fern', 3], ['flower', 1]], edge: ['tree', 'tree', 'tree'] },
  mountain: { dens: 0.45, kinds: [['pine', 5], ['rock', 4], ['tuft', 2]], edge: ['pine', 'rock', 'pine'] },
  night: { dens: 0.36, kinds: [['bush', 2], ['tuft', 3], ['rock', 1], ['tree', 2], ['flower', 1]], edge: ['tree', 'bush', 'tree'] },
  town: { dens: 0.26, kinds: [['planter', 3], ['bush', 2], ['flower', 3], ['tree', 2], ['lamp', 1], ['crate', 1], ['pot', 1], ['tuft', 2]], edge: ['tree', 'bush', 'tree', 'lamp'] },
  garden: { dens: 0.5, kinds: [['rosebush', 3], ['flower', 5], ['tree', 2], ['bush', 2], ['tuft', 2]], edge: ['tree', 'rosebush', 'tree'] },
  maze: { dens: 0.5, kinds: [['thorn', 3], ['bush', 3], ['tree', 3], ['tuft', 2], ['mushroom', 1]], edge: ['tree', 'thorn', 'tree'] },
  volcano: { dens: 0.34, kinds: [['rock', 4], ['pebbles', 3], ['crystal', 1]], edge: ['rock', 'rock', 'crystal'] },
  castle: { dens: 0.3, kinds: [['rosebush', 2], ['bush', 2], ['tree', 2], ['flower', 3], ['urn', 1], ['tuft', 2]], edge: ['tree', 'pillar', 'tree', 'bush'] },
};
// the solid ones: [half width, half depth, height] (rocks, planters and bushes are low enough to hop over; flowers,
// grass, reeds, ferns, mushrooms and thorns you just walk through)
export const DECOR_FOOT = {
  tree: [14, 10, 120], pine: [16, 12, 160], rock: [26, 14, 34], hay: [32, 14, 46], fountain: [96, 30, 46], stall: [56, 16, 112], statue: [44, 22, 70],
  bush: [30, 12, 48], rosebush: [28, 12, 42], fence: [50, 5, 50], planter: [34, 12, 26], pot: [14, 10, 30], crate: [22, 16, 40], urn: [18, 14, 50],
  lamp: [6, 6, 108], pinwheel: [5, 5, 96], flag: [5, 5, 120], banner: [5, 5, 230], crystal: [20, 12, 70], stalag: [20, 14, 100],
  hedge: [60, 16, 120], pillar: [26, 20, 214],
};

// Scatter scenery over a big field (cached per room). free(x, z, kind) says whether a spot is clear.
export function fieldDecorFor(R, id, theme, zb, free) {
  const hit = decorCache.get(R);
  if (hit && hit.theme === theme && hit.field) return hit.out;
  const set = FIELD_DECOR[R.decorSet || theme] || FIELD_DECOR.plains;
  let seed = 0;
  for (const ch of id) seed = (seed * 31 + ch.charCodeAt(0)) % 10007;
  const total = set.kinds.reduce((n, [, w]) => n + w, 0);
  const pick = h => { let a = h * total; for (const [k, w] of set.kinds) if ((a -= w) < 0) return k; return set.kinds[0][0]; };
  const out = [];
  const CW = 200, CD = 180;
  for (let x = 80; x < R.w - 60; x += CW) {
    for (let z = GZ0 + 70; z < zb - 70; z += CD) {
      const forest = (R.groves || []).some(g => x >= g[0] && x <= g[1] && z >= g[2] && z <= g[3]);
      const h = hash(seed + x * 0.0131 + z * 0.0173);
      if (h > (forest ? 0.95 : set.dens)) continue;
      const xx = x + (hash(seed + x * 1.7 + z) - 0.5) * CW * 0.8, zz = z + (hash(seed * 2 + z * 1.3 + x) - 0.5) * CD * 0.8;
      const h2 = hash(seed * 3 + x + z * 7);
      // (a set can say what its woods are made of: [mostly, sometimes])
      const woods = set.grove || [theme === 'mountain' ? 'pine' : 'tree', 'bush'];
      const kind = forest ? woods[h2 < 0.72 ? 0 : 1] : pick(h2);
      if (!free(xx, zz, kind)) continue;
      out.push({ x: xx, z: zz, kind, k: 0.85 + hash(x + z + seed) * 0.35 });
    }
  }
  // tall scenery along the far edge and down the sides, so the field ends in trees rather than nothing
  for (let x = 40; x < R.w; x += 120) {
    const h = hash(seed + x * 0.77), kind = set.edge[Math.floor(h * set.edge.length)];
    const xx = x + (h - 0.5) * 40, zz = zb - 18 - h * 26;
    if (free(xx, zz, kind, true)) out.push({ x: xx, z: zz, kind, k: 1.25 + h * 0.5, edge: true });
  }
  for (let z = GZ0 + 320; z < zb - 60; z += 95) {
    for (const xx of [36, R.w - 36]) {
      const h = hash(seed + z * 0.53 + xx), kind = set.edge[Math.floor(h * set.edge.length)];
      if (free(xx, z, kind, true)) out.push({ x: xx, z: z + (h - 0.5) * 50, kind, k: 1.1 + h * 0.4, edge: true });
    }
  }
  decorCache.set(R, { theme, field: true, out });
  return out;
}

// Far-off scenery is drawn from a picture of it made once, at half size (much cheaper than every shape and outline
// again, and nobody can see a far tree sway anyway). Draw it scaled by k / sprite.k, at the bottom center (ox, oy).
const SPRITES = new Map();
export function decorSprite(kind) {
  let s = SPRITES.get(kind);
  if (s) return s;
  const cv = document.createElement('canvas'); cv.width = 170; cv.height = 180;
  const c = cv.getContext('2d');
  c.translate(85, 168); c.scale(0.5, 0.5);
  DECOR_DRAW[kind](c, 0, 0);
  s = { cv, ox: 85, oy: 168, k: 0.5 };
  SPRITES.set(kind, s);
  return s;
}

export function drawDecor(c, V, list, z, groundAt, t) {
  const lo = V.camX - 200, hi = V.camX + 1160;
  for (const d of list) {
    if (d.x < lo || d.x > hi) continue;
    const y = groundAt(d.x);
    if (y == null) continue;
    atDepth(c, V, d.x, y, z, () => { c.scale(d.k, d.k); DECOR_DRAW[d.kind](c, t, d.x); });
  }
}

export const DECOR_DRAW = {
  tree(c, t, x) {
    const sway = Math.sin(t * 0.8 + x) * 0.02;
    c.rotate(sway);
    paper(c, p => {
      shape(c, p, rrect(-9, -110, 18, 110, 5), '#7a5232', 2);
      shape(c, p, ell(-30, -120, 42, 34), '#4f9a52', 2);
      shape(c, p, ell(28, -128, 44, 36), '#5fae5c', 2);
      shape(c, p, ell(0, -160, 46, 36), '#6cc068', 2);
    });
    c.fillStyle = 'rgba(255,255,255,0.2)'; c.beginPath(); c.ellipse(-14, -170, 14, 8, -0.4, 0, TAU); c.fill();
  },
  pine(c) {
    paper(c, p => {
      shape(c, p, rrect(-6, -40, 12, 40, 3), '#6e4a30', 2);
      shape(c, p, poly([[-40, -36], [0, -150], [40, -36]]), '#3f6b4a', 2);
      shape(c, p, poly([[-30, -80], [0, -170], [30, -80]]), '#4f7f58', 2);
    });
    c.fillStyle = '#f4f6ff'; c.beginPath(); c.moveTo(-10, -140); c.lineTo(0, -170); c.lineTo(10, -140); c.fill();
  },
  bush(c) {
    paper(c, p => { shape(c, p, ell(-20, -18, 26, 20), '#4f9a52', 2); shape(c, p, ell(18, -20, 26, 22), '#5fae5c', 2); shape(c, p, ell(0, -34, 24, 20), '#6cc068', 2); });
  },
  rosebush(c) {
    paper(c, p => { shape(c, p, ell(-16, -20, 24, 20), '#5fae5c', 2); shape(c, p, ell(16, -22, 24, 22), '#6cc068', 2); });
    for (const [rx, ry] of [[-18, -28], [4, -36], [20, -20], [-4, -16]]) { c.fillStyle = '#ff7aa8'; c.beginPath(); c.arc(rx, ry, 5, 0, TAU); c.fill(); c.strokeStyle = INK; c.lineWidth = 1.2; c.stroke(); }
  },
  fence(c) {
    paper(c, p => {
      for (const fx of [-40, 0, 40]) shape(c, p, poly([[fx - 6, 0], [fx - 6, -44], [fx, -52], [fx + 6, -44], [fx + 6, 0]]), '#e8d4b0', 2);
      shape(c, p, rrect(-50, -36, 100, 8, 2), '#d9c09a', 2);
      shape(c, p, rrect(-50, -18, 100, 8, 2), '#d9c09a', 2);
    });
  },
  pinwheel(c, t, x) {
    paper(c, p => shape(c, p, rrect(-3, -96, 6, 96, 2), '#e8dcc0', 2));
    c.save(); c.translate(0, -98); c.rotate(t * 1.6 + x);
    for (let b = 0; b < 4; b++) {
      c.rotate(Math.PI / 2);
      paper(c, p => shape(c, p, poly([[0, 0], [30, -8], [26, 14]]), ['#ff9ab0', '#ffe066', '#9fe6ff', '#b49cff'][b], 1.8));
    }
    c.restore();
    c.fillStyle = INK; c.beginPath(); c.arc(0, -98, 3, 0, TAU); c.fill();
  },
  hay(c) {
    paper(c, p => shape(c, p, rrect(-36, -46, 72, 46, 14), vgrad(c, -46, 0, '#f6d77a', '#d9a84a'), 2));
    c.strokeStyle = 'rgba(140,90,30,0.5)'; c.lineWidth = 2;
    for (const yy of [-34, -22, -10]) { c.beginPath(); c.moveTo(-30, yy); c.lineTo(30, yy); c.stroke(); }
  },
  flag(c, t, x) {
    paper(c, p => {
      shape(c, p, rrect(-3, -120, 6, 120, 2), '#8a5a3c', 2);
      shape(c, p, cc => { const w = Math.sin(t * 4 + x) * 5; cc.moveTo(3, -118); cc.quadraticCurveTo(24, -112 + w, 46, -110); cc.lineTo(46, -86); cc.quadraticCurveTo(24, -90 - w, 3, -94); cc.closePath(); }, '#e5534b', 2);
    });
  },
  planter(c) {
    paper(c, p => shape(c, p, rrect(-34, -26, 68, 26, 5), '#8a5a3c', 2));
    for (const [fx, col] of [[-20, '#ff9ab0'], [-4, '#ffd23f'], [12, '#b49cff'], [24, '#ff9ab0']]) {
      c.strokeStyle = '#4f9a52'; c.lineWidth = 2; c.beginPath(); c.moveTo(fx, -26); c.lineTo(fx, -40); c.stroke();
      c.fillStyle = col; c.beginPath(); starPath(c, fx, -42, 6, 3, 5); c.fill();
    }
  },
  lamp(c, t) {
    glowDot(c, 0, -96, 40, '255,210,120', 0.3);
    paper(c, p => { shape(c, p, rrect(-3, -90, 6, 90, 2), '#3b3350', 2); shape(c, p, rrect(-10, -108, 20, 18, 4), '#ffd67a', 2); });
    void t;
  },
  reeds(c, t, x) {
    c.lineCap = 'round';
    for (let i = 0; i < 5; i++) {
      const bx = -16 + i * 8, h = 50 + (i % 3) * 16, sw = Math.sin(t * 1.4 + i + x) * 4;
      c.strokeStyle = PAPER; c.lineWidth = 7; c.beginPath(); c.moveTo(bx, 0); c.quadraticCurveTo(bx, -h / 2, bx + sw, -h); c.stroke();
      c.strokeStyle = '#5f8a4a'; c.lineWidth = 3; c.stroke();
      if (i % 2) { c.fillStyle = '#7a5232'; c.beginPath(); c.ellipse(bx + sw, -h, 3.5, 9, 0, 0, TAU); c.fill(); }
    }
  },
  rock(c) {
    paper(c, p => shape(c, p, cc => { cc.moveTo(-34, 0); cc.quadraticCurveTo(-38, -26, -14, -36); cc.quadraticCurveTo(10, -46, 30, -26); cc.quadraticCurveTo(40, -10, 34, 0); cc.closePath(); }, vgrad(c, -46, 0, '#a49e94', '#6f6a62'), 2));
    c.strokeStyle = 'rgba(43,34,53,0.35)'; c.lineWidth = 2; c.beginPath(); c.moveTo(-8, -30); c.lineTo(0, -18); c.lineTo(-4, -8); c.stroke();
  },
  crystal(c, t, x) {
    glowDot(c, 0, -30, 46, '160,240,255', 0.25 + 0.1 * Math.sin(t * 2 + x));
    paper(c, p => {
      shape(c, p, poly([[-18, 0], [-24, -40], [-12, -58], [-4, -10]]), '#9fe6ff', 2);
      shape(c, p, poly([[-6, 0], [0, -76], [12, -50], [10, 0]]), '#bff0ff', 2);
      shape(c, p, poly([[8, 0], [20, -34], [26, -6]]), '#7fd0f0', 2);
    });
  },
  stalag(c) {
    paper(c, p => shape(c, p, poly([[-22, 0], [-6, -92], [4, -60], [10, -110], [24, 0]]), vgrad(c, -110, 0, '#5d4f80', '#3f3460'), 2));
  },
  vent(c, t, x) {
    const q = (t * 0.4 + hash(x)) % 1;
    c.fillStyle = `rgba(255,255,255,${0.35 * (1 - q)})`; c.beginPath(); c.arc(0, -20 - q * 60, 6 + q * 14, 0, TAU); c.fill();
    paper(c, p => shape(c, p, cc => { cc.moveTo(-30, 0); cc.quadraticCurveTo(-20, -18, 0, -20); cc.quadraticCurveTo(20, -18, 30, 0); cc.closePath(); }, '#5e5058', 2));
  },
  hedge(c) {
    paper(c, p => shape(c, p, rrect(-60, -120, 120, 120, 18), vgrad(c, -120, 0, '#3f6a34', '#2f4a2c'), 2));
    c.strokeStyle = '#1f3320'; c.lineWidth = 2;
    for (let k = 0; k < 4; k++) { c.beginPath(); c.moveTo(-40 + k * 25, -100); c.lineTo(-30 + k * 25, -86); c.stroke(); }
  },
  pillar(c) {
    paper(c, p => {
      shape(c, p, rrect(-26, -16, 52, 16, 3), '#a8a1b8', 2);
      shape(c, p, rrect(-18, -200, 36, 186, 4), vgrad(c, -200, 0, '#d6d0e0', '#9a93ad'), 2);
      shape(c, p, rrect(-28, -214, 56, 16, 3), '#c8c2d4', 2);
    });
    c.strokeStyle = 'rgba(43,34,53,0.2)'; c.lineWidth = 2;
    for (const fx of [-8, 0, 8]) { c.beginPath(); c.moveTo(fx, -196); c.lineTo(fx, -18); c.stroke(); }
  },
  banner(c, t, x) {
    paper(c, p => {
      shape(c, p, rrect(-3, -230, 6, 230, 2), '#5a4e58', 2);
      shape(c, p, cc => { const w = Math.sin(t * 1.5 + x) * 3; cc.moveTo(3, -226); cc.lineTo(46, -226); cc.lineTo(46 + w, -150); cc.lineTo(25, -164); cc.lineTo(3 + w, -150); cc.closePath(); }, '#4f72bf', 2);
    });
    c.fillStyle = '#ffd23f'; c.beginPath(); starPath(c, 25, -200, 9, 4, 5); c.fill();
  },
  root(c) {
    c.strokeStyle = '#3a2418'; c.lineWidth = 7; c.lineCap = 'round';
    c.beginPath(); c.moveTo(-30, 0); c.quadraticCurveTo(-10, -60, 10, -130); c.stroke();
    c.lineWidth = 4; c.beginPath(); c.moveTo(0, -60); c.quadraticCurveTo(20, -70, 34, -60); c.stroke();
  },
  tuft(c, t, x) {
    const sw = Math.sin(t * 2 + x) * 2;
    c.lineCap = 'round';
    for (const pass of [0, 1]) {
      c.strokeStyle = pass ? '#3f7a3a' : PAPER; c.lineWidth = pass ? 3.5 : 8;
      c.beginPath(); c.moveTo(-8, 0); c.lineTo(-14 + sw, -20); c.moveTo(0, 0); c.lineTo(sw, -28); c.moveTo(8, 0); c.lineTo(14 + sw, -18); c.stroke();
    }
  },
  flower(c, t, x) {
    const col = ['#ff9ab0', '#ffd23f', '#b49cff', '#fffaf0'][Math.floor(hash(x) * 4)];
    c.strokeStyle = '#3f7a3a'; c.lineWidth = 3; c.beginPath(); c.moveTo(0, 0); c.lineTo(Math.sin(t * 2 + x) * 3, -30); c.stroke();
    c.save(); c.translate(Math.sin(t * 2 + x) * 3, -32);
    paper(c, p => shape(c, p, cc => starPath(cc, 0, 0, 10, 5, 5), col, 1.6));
    c.fillStyle = '#ffb347'; c.beginPath(); c.arc(0, 0, 3, 0, TAU); c.fill();
    c.restore();
  },
  mushroom(c) {
    paper(c, p => { shape(c, p, rrect(-6, -22, 12, 22, 4), '#fff1d6', 2); shape(c, p, cc => { cc.moveTo(-22, -20); cc.quadraticCurveTo(0, -48, 22, -20); cc.closePath(); }, '#e5534b', 2); });
    c.fillStyle = '#fffaf0'; for (const [mx, my] of [[-10, -28], [6, -34], [12, -24]]) { c.beginPath(); c.arc(mx, my, 3, 0, TAU); c.fill(); }
  },
  fern(c) {
    c.strokeStyle = '#4f8a47'; c.lineWidth = 3; c.lineCap = 'round';
    for (const a of [-0.9, -0.4, 0.1, 0.6]) { c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(Math.sin(a) * 20, -24, Math.sin(a) * 38, -30 + Math.abs(a) * 10); c.stroke(); }
  },
  pot(c) {
    paper(c, p => { shape(c, p, poly([[-14, -26], [14, -26], [10, 0], [-10, 0]]), '#c0744a', 2); shape(c, p, ell(0, -34, 16, 12), '#5fae5c', 2); });
  },
  crate(c) {
    paper(c, p => shape(c, p, rrect(-22, -40, 44, 40, 3), '#c58b55', 2));
    c.strokeStyle = 'rgba(80,40,20,0.5)'; c.lineWidth = 2; c.beginPath(); c.moveTo(-20, -38); c.lineTo(20, -2); c.moveTo(20, -38); c.lineTo(-20, -2); c.stroke();
  },
  shell(c) {
    paper(c, p => shape(c, p, cc => { cc.moveTo(-12, 0); cc.quadraticCurveTo(0, -24, 12, 0); cc.closePath(); }, '#ffd6e0', 1.6));
  },
  pebbles(c) {
    paper(c, p => { shape(c, p, ell(-10, -5, 9, 6), '#8d867c', 1.6); shape(c, p, ell(7, -4, 7, 5), '#a49e94', 1.6); });
  },
  thorn(c) {
    c.fillStyle = '#2a3d24';
    for (const bx of [-16, 0, 14]) { c.beginPath(); c.moveTo(bx - 8, 0); c.lineTo(bx, -30); c.lineTo(bx + 8, 0); c.fill(); }
  },
  urn(c) {
    paper(c, p => { shape(c, p, cc => { cc.moveTo(-10, -50); cc.lineTo(10, -50); cc.quadraticCurveTo(26, -26, 12, 0); cc.lineTo(-12, 0); cc.quadraticCurveTo(-26, -26, -10, -50); cc.closePath(); }, vgrad(c, -50, 0, '#c8c2d4', '#8a84a0'), 2); });
  },
};

// ---------------------------------------------------------------- interiors
// Each interior style: wallpaper colors, trim, a pattern, the floor, and light from the windows.
export const STYLES = {
  inn: { wall: ['#f3dcc0', '#e2c39c'], trim: '#8a5a3c', pattern: 'stripes', pat: 'rgba(196,90,90,0.18)', mat: { top: '#c9925c' } },
  shop: { wall: ['#fff0c4', '#f2d68a'], trim: '#b07a2a', pattern: 'dots', pat: 'rgba(240,160,40,0.25)', mat: { top: '#d9a86a' } },
  bazaar: { wall: ['#e8dcf8', '#cbb8ec'], trim: '#5a4fa8', pattern: 'diamonds', pat: 'rgba(90,79,168,0.15)', mat: { top: '#b78ac9', floor: 'tile' } },
  stars: { wall: ['#2c3a6e', '#1d264d'], trim: '#ffd23f', pattern: 'stars', pat: 'rgba(255,240,180,0.8)', mat: { top: '#6a76b0', floor: 'tile' } },
  library: { wall: ['#e9d6b4', '#cdb48e'], trim: '#5e3b24', pattern: 'stripes', pat: 'rgba(94,59,36,0.12)', mat: { top: '#a86e3e' } },
  dojo: { wall: ['#f6ecd2', '#e4d2a8'], trim: '#3a2a20', pattern: 'shoji', pat: 'rgba(58,42,32,0.35)', mat: { top: '#d8c48a' } },
  cozy: { wall: ['#d6ecd9', '#b5d6bb'], trim: '#6e4a6a', pattern: 'flowers', pat: 'rgba(255,150,180,0.35)', mat: { top: '#c49060' } },
  post: { wall: ['#dbe8f6', '#b8cde6'], trim: '#3b5a7b', pattern: 'stripes', pat: 'rgba(59,90,123,0.15)', mat: { top: '#b98a5a' } },
  mothwick: { wall: ['#e6dcf6', '#c9b8e8'], trim: '#5d4a70', pattern: 'diamonds', pat: 'rgba(160,130,210,0.25)', mat: { top: '#b98a5a' } },
  mill: { wall: ['#e8d8b8', '#c9b48e'], trim: '#7a5232', pattern: 'planks', pat: 'rgba(110,70,30,0.25)', mat: { top: '#c9a26a' } },
  hearth: { wall: ['#f6d2b0', '#e6a880'], trim: '#8a3a2a', pattern: 'stripes', pat: 'rgba(200,90,50,0.15)', mat: { top: '#b8784a' } },
  forge: { wall: ['#6e5a58', '#4a3a3a'], trim: '#2a1e26', pattern: 'bricks', pat: 'rgba(20,10,10,0.3)', mat: { top: '#7a6460', floor: 'stone' } },
  castle: { wall: ['#c8c2d4', '#9a93ad'], trim: '#5a4e68', pattern: 'bricks', pat: 'rgba(43,34,53,0.18)', mat: { top: '#bdb6ca', floor: 'tile' } },
  throne: { wall: ['#8a3a4e', '#5e2436'], trim: '#ffd23f', pattern: 'diamonds', pat: 'rgba(255,210,63,0.2)', mat: { top: '#c8c2d4', floor: 'tile' } },
  den: { wall: ['#6e5038', '#4a3424'], trim: '#2a1a12', pattern: 'planks', pat: 'rgba(20,10,5,0.3)', mat: { top: '#8a6a4a', floor: 'stone' } },
  shrine: { wall: ['#fbf3e0', '#efdcb4'], trim: '#c0392b', pattern: 'shoji', pat: 'rgba(192,57,43,0.22)', mat: { top: '#e2c48e', floor: 'plank' } },
  grotto: { wall: ['#5d4f80', '#3a2f58'], trim: '#2a2142', pattern: 'bricks', pat: 'rgba(10,5,20,0.25)', mat: { top: '#7d6aa8', floor: 'stone' } },
};

// The room box: back wall, ceiling, and the side walls you see near either end.
export function drawInteriorShell(c, V, R, t) {
  const st = STYLES[R.style] || STYLES.inn;
  const P = (xx, yy, z) => [V.x(xx, z), V.y(yy, z)];
  const top = 50, floor = 450, w = R.w;
  const [bx0, by0] = P(0, top, GZ1), [bx1, by1] = P(w, floor, GZ1);
  c.fillStyle = '#1c1428'; c.fillRect(V.camX - 20, -20, 1000, 600);
  // back wall
  c.fillStyle = vgrad(c, by0, by1, st.wall[0], st.wall[1]); c.fillRect(bx0, by0, bx1 - bx0, by1 - by0);
  c.save(); c.beginPath(); c.rect(bx0, by0, bx1 - bx0, by1 - by0); c.clip();
  wallPattern(c, st, bx0, by0, bx1, by1, V.s(GZ1), t);
  // wainscot
  const [, wy] = P(0, 350, GZ1);
  c.fillStyle = shade(st.trim, 0.35); c.globalAlpha = 0.5; c.fillRect(bx0, wy, bx1 - bx0, by1 - wy); c.globalAlpha = 1;
  c.fillStyle = st.trim; c.fillRect(bx0, wy - 3, bx1 - bx0, 5); c.fillRect(bx0, by0, bx1 - bx0, 6);
  c.restore();
  // windows on the back wall
  for (const wx of R.windows || []) {
    atDepth(c, V, wx, 300, GZ1, () => {
      const day = R.night ? ['#2a3266', '#141838'] : ['#9fd8f0', '#e8f6ff'];
      paper(c, p => shape(c, p, rrect(-46, -120, 92, 110, 10), st.trim));
      c.fillStyle = vgrad(c, -112, -18, day[0], day[1]); c.fillRect(-38, -112, 76, 94);
      c.strokeStyle = st.trim; c.lineWidth = 5; c.beginPath(); c.moveTo(0, -112); c.lineTo(0, -18); c.moveTo(-38, -65); c.lineTo(38, -65); c.stroke();
      c.fillStyle = 'rgba(255,255,255,0.3)'; c.beginPath(); c.moveTo(-30, -104); c.lineTo(-12, -104); c.lineTo(-30, -80); c.fill();
    });
    // a soft beam of light down onto the floor
    if (!R.night) {
      const [ax, ay] = P(wx - 40, 290, GZ1), [bx2] = P(wx + 40, 290, GZ1);
      const [cx1, cy1] = P(wx + 10, floor, 30), [dx1] = P(wx + 110, floor, 30);
      c.fillStyle = 'rgba(255,240,190,0.12)';
      c.beginPath(); c.moveTo(ax, ay); c.lineTo(bx2, ay); c.lineTo(dx1, cy1); c.lineTo(cx1, cy1); c.closePath(); c.fill();
    }
  }
  // ceiling (seen from below) and beams
  face(c, [P(0, top, GZ1), P(w, top, GZ1), P(w, top, GZ0), P(0, top, GZ0)], shade(st.trim, -0.2), 0);
  c.strokeStyle = shade(st.trim, -0.45); c.lineWidth = 6;
  for (let xx = 100; xx < w; xx += 260) { c.beginPath(); c.moveTo(...P(xx, top, GZ1)); c.lineTo(...P(xx, top, GZ0)); c.stroke(); }
  // side walls at the ends of the room
  const side = shade(st.wall[1], -0.18);
  if (V.camX < 400) face(c, [P(0, top, GZ1), P(0, top, GZ0), P(0, floor, GZ0), P(0, floor, GZ1)], side);
  if (V.camX + 960 > w - 400) face(c, [P(w, top, GZ1), P(w, top, GZ0), P(w, floor, GZ0), P(w, floor, GZ1)], side);
}

function wallPattern(c, st, x0, y0, x1, y1, k, t) {
  c.fillStyle = st.pat; c.strokeStyle = st.pat;
  const step = 44 * k;
  if (st.pattern === 'stripes') for (let x = x0; x < x1; x += step) c.fillRect(x, y0, step * 0.4, y1 - y0);
  else if (st.pattern === 'dots') { for (let x = x0; x < x1; x += step) for (let y = y0 + 20; y < y1; y += step) { c.beginPath(); c.arc(x + ((y / step) % 2) * step / 2, y, 4 * k, 0, TAU); c.fill(); } }
  else if (st.pattern === 'diamonds') { c.lineWidth = 2; for (let x = x0 - 200; x < x1; x += step) { c.beginPath(); c.moveTo(x, y0); c.lineTo(x + (y1 - y0), y1); c.moveTo(x + (y1 - y0), y0); c.lineTo(x, y1); c.stroke(); } }
  else if (st.pattern === 'stars') { for (let i = 0; i < 70; i++) { const sx = x0 + hash(i) * (x1 - x0), sy = y0 + hash(i + 50) * (y1 - y0) * 0.7; c.globalAlpha = 0.4 + 0.4 * Math.sin(t * 2 + i); c.beginPath(); starPath(c, sx, sy, 4, 1.8, 4); c.fill(); } c.globalAlpha = 1; }
  else if (st.pattern === 'shoji') { c.lineWidth = 3; for (let x = x0; x < x1; x += step * 1.4) { c.beginPath(); c.moveTo(x, y0); c.lineTo(x, y1); c.stroke(); } for (let y = y0; y < y1; y += step) { c.beginPath(); c.moveTo(x0, y); c.lineTo(x1, y); c.stroke(); } }
  else if (st.pattern === 'flowers') { for (let x = x0; x < x1; x += step * 1.3) for (let y = y0 + 24; y < y1; y += step * 1.3) { c.beginPath(); starPath(c, x + ((y / step) % 2) * step * 0.6, y, 6 * k, 3 * k, 5); c.fill(); } }
  else if (st.pattern === 'planks') { c.lineWidth = 2; for (let x = x0; x < x1; x += step * 1.2) { c.beginPath(); c.moveTo(x, y0); c.lineTo(x, y1); c.stroke(); } }
  else if (st.pattern === 'bricks') {
    c.lineWidth = 1.5; const bh = 26 * k, bw = 60 * k;
    for (let y = y0, r = 0; y < y1; y += bh, r++) { c.beginPath(); c.moveTo(x0, y); c.lineTo(x1, y); c.stroke(); for (let x = x0 + (r % 2) * bw / 2; x < x1; x += bw) { c.beginPath(); c.moveTo(x, y); c.lineTo(x, y + bh); c.stroke(); } }
  }
}

// ---------------------------------------------------------------- furniture
// Drawn around (0, 0) = where it stands on the floor. `z` is how far back it usually sits.
export const FURN_Z = {
  bed: 150, bookshelf: 236, table: 110, fireplace: 238, piano: 205, painting: 258, window: 258, plant: 220, clock: 238,
  counter: 55, jars: 250, telescope: 150, dummy: 110, cookiejar: 170, barrel: 190, banner: 258, armor: 234, throne: 222,
  lever: 40, mirror: 240, toybox: 170, mailshelf: 252, scale: 180, oven: 236, anvil: 120, sacks: 220, gears: 258, bench: 100,
  scroll: 258, globe: 200, stove: 232, trophy: 200, crate: 190, chandelier: 120, mat: 0, rug: 0, sign2: 60, pedestal: 140,
  spot: 6,
};
// The solid part of furniture on the floor: [half width, half depth, height]. You can jump on top of the low ones.
export const FURN_FOOT = {
  bed: [60, 28, 52], table: [44, 22, 48], piano: [58, 20, 96], fireplace: [62, 18, 118], bookshelf: [48, 16, 160],
  clock: [22, 14, 150], plant: [18, 14, 70], barrel: [22, 18, 56], crate: [22, 18, 40], toybox: [36, 16, 50],
  cookiejar: [20, 14, 84], dummy: [16, 12, 110], telescope: [22, 16, 80], globe: [26, 16, 90], sacks: [46, 20, 78],
  anvil: [36, 16, 54], oven: [70, 18, 130], stove: [50, 18, 86], scale: [24, 14, 98], throne: [50, 24, 190],
  armor: [24, 14, 140], trophy: [20, 12, 80], pedestal: [22, 14, 60], mirror: [34, 10, 150],
  bench: [48, 14, 30], counter: [80, 18, 64], sign2: [8, 5, 66], lever: [20, 10, 20],
};

export const FURN = {
  bed(c, o) {
    const col = o.color || '#5a7ac4';
    paper(c, p => {
      shape(c, p, rrect(-62, -74, 16, 74, 5), '#8a5a3c');
      shape(c, p, rrect(-58, -34, 116, 26, 6), '#a8693a');
      shape(c, p, rrect(-54, -46, 30, 16, 7), '#fffaf0');
      shape(c, p, rrect(-26, -48, 82, 22, 8), vgrad(c, -48, -26, shade(col, 0.2), col));
      shape(c, p, rrect(-56, -10, 8, 10, 2), '#6e4224'); shape(c, p, rrect(48, -10, 8, 10, 2), '#6e4224');
    });
    if (o.sleeper) { c.font = 'bold 16px Fredoka, sans-serif'; c.fillStyle = '#6b5a8a'; c.fillText('z Z', 0, -60 + Math.sin(o.t * 2) * 3); }
  },
  bookshelf(c, o) {
    paper(c, p => shape(c, p, rrect(-48, -160, 96, 160, 4), vgrad(c, -160, 0, '#8a5a3c', '#5e3b24')));
    const cols = ['#c45a5a', '#4f72bf', '#5fae5c', '#e8a92a', '#7b5fc7', '#3aa79c'];
    for (let r = 0; r < 4; r++) {
      const y = -148 + r * 37;
      c.fillStyle = '#4a2b16'; c.fillRect(-42, y + 30, 84, 4);
      for (let i = 0, x = -40; x < 36; i++) { const bw = 7 + ((i * 7 + r * 3 + (o.seed || 0)) % 6); c.fillStyle = cols[(i + r + (o.seed || 0)) % 6]; c.fillRect(x, y + 6 + (i % 3), bw, 24 - (i % 3)); x += bw + 2; }
    }
  },
  table(c, o) {
    paper(c, p => { shape(c, p, rrect(-44, -46, 88, 10, 4), '#a8693a'); shape(c, p, rrect(-38, -38, 8, 38, 2), '#7a4a26'); shape(c, p, rrect(30, -38, 8, 38, 2), '#7a4a26'); });
    if (o.cup) paper(c, p => shape(c, p, rrect(-20, -60, 14, 14, 3), '#fffaf0', 1.6));
    if (o.candle) { paper(c, p => shape(c, p, rrect(14, -66, 8, 20, 2), '#fff1d6', 1.6)); flame(c, 18, -66, 0.4, o.t); }
    if (o.food) { paper(c, p => shape(c, p, ell(0, -50, 22, 8), '#fffaf0', 1.6)); paper(c, p => shape(c, p, ell(0, -55, 14, 7), '#d9a066', 1.6)); }
  },
  fireplace(c, o) {
    glowDot(c, 0, -40, 90, '255,170,80', 0.35 + 0.08 * Math.sin(o.t * 6));
    paper(c, p => {
      shape(c, p, rrect(-62, -118, 124, 118, 6), vgrad(c, -118, 0, '#b5aab8', '#7f7590'));
      shape(c, p, rrect(-70, -128, 140, 14, 4), '#8a5a3c');
    });
    c.fillStyle = '#1c1020'; c.beginPath(); c.moveTo(-36, 0); c.lineTo(-36, -60); c.arc(0, -60, 36, Math.PI, 0); c.lineTo(36, 0); c.closePath(); c.fill();
    if (!o.cold) { flame(c, -10, -4, 1.4, o.t); flame(c, 12, -4, 1.1, o.t + 2); }
  },
  piano(c) {
    paper(c, p => {
      shape(c, p, rrect(-58, -96, 116, 96, 6), vgrad(c, -96, 0, '#3b3350', '#1c1428'));
      shape(c, p, rrect(-62, -54, 124, 16, 3), '#fffaf0');
    });
    c.fillStyle = INK; for (let i = 0; i < 14; i++) if (i % 7 !== 2 && i % 7 !== 6) c.fillRect(-56 + i * 8.5, -54, 5, 9);
    c.font = '18px "Segoe UI Emoji", sans-serif'; c.textAlign = 'center'; c.fillText('🎵', 0, -70);
  },
  painting(c, o) {
    const y = -170;
    paper(c, p => shape(c, p, rrect(-44, y - 34, 88, 68, 4), o.frame || '#d9a84a'));
    const pic = o.pic || 'landscape';
    c.save(); c.beginPath(); c.rect(-36, y - 26, 72, 52); c.clip();
    if (pic === 'landscape') { c.fillStyle = '#9fd8f0'; c.fillRect(-36, y - 26, 72, 52); c.fillStyle = '#8fcf74'; c.beginPath(); c.ellipse(-10, y + 26, 50, 22, 0, 0, TAU); c.fill(); c.fillStyle = '#fff4d6'; c.beginPath(); c.arc(20, y - 12, 7, 0, TAU); c.fill(); }
    else if (pic === 'moth' || pic === 'queen' || pic === 'knight' || pic === 'jester' || pic === 'king') {
      c.fillStyle = { moth: '#e6dcf6', queen: '#f6d2e0', knight: '#d6dcef', jester: '#fff3c9', king: '#f6e8c6' }[pic]; c.fillRect(-36, y - 26, 72, 52);
      if (pic === 'moth') DRAW.mothwick(c, 0, y + 34, { t: 0, scale: 0.55, shadow: false, mood: 'happy' });
      else if (pic === 'queen') drawQueen(c, 0, y + 30, { scale: 0.5, shadow: false, mood: 'happy' });
      else if (pic === 'knight') drawWaxKnight(c, 0, y + 30, { scale: 0.55, shadow: false, mood: 'determined', proud: true });
      else if (pic === 'king') DRAW.grumblecap(c, 0, y + 30, { scale: 0.35, shadow: false, mood: 'happy' });
      else drawCandle(c, 0, y + 28, { scale: 0.7, shadow: false, mood: 'happy', hat: 'jester' });
    } else if (pic === 'castle') { c.fillStyle = '#ffd6c2'; c.fillRect(-36, y - 26, 72, 52); c.fillStyle = '#7f7890'; c.fillRect(-20, y - 6, 40, 32); c.fillRect(-26, y - 20, 12, 46); c.fillRect(14, y - 20, 12, 46); }
    c.restore();
    if (o.plaque) {
      paper(c, p => shape(c, p, rrect(-22, y + 38, 44, 28, 6), '#f6e8c6', 1.6));
      c.font = '20px "Segoe UI Emoji", sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
      c.fillText(o.plaque, 0, y + 53); c.textBaseline = 'alphabetic';
    }
  },
  window() { /* windows are part of the back wall (R.windows) */ },
  plant(c, o) {
    paper(c, p => {
      shape(c, p, poly([[-18, -34], [18, -34], [13, 0], [-13, 0]]), '#c0744a');
      shape(c, p, ell(-14, -52, 12, 22, -0.6), '#4f9a52'); shape(c, p, ell(14, -52, 12, 22, 0.6), '#5fae5c'); shape(c, p, ell(0, -64, 11, 24), '#6cc068');
    });
    void o;
  },
  clock(c, o) {
    paper(c, p => { shape(c, p, rrect(-22, -150, 44, 150, 6), vgrad(c, -150, 0, '#8a5a3c', '#5e3b24')); shape(c, p, ell(0, -122, 16, 16), '#fffaf0'); });
    const a = o.t * 1.2;
    c.strokeStyle = INK; c.lineWidth = 2; c.beginPath(); c.moveTo(0, -122); c.lineTo(Math.sin(a) * 10, -122 - Math.cos(a) * 10); c.moveTo(0, -122); c.lineTo(6, -126); c.stroke();
    const sw = Math.sin(o.t * 3) * 0.35;
    c.save(); c.translate(0, -92); c.rotate(sw); c.strokeStyle = '#d9a84a'; c.lineWidth = 3; c.beginPath(); c.moveTo(0, 0); c.lineTo(0, 60); c.stroke();
    c.fillStyle = '#ffd23f'; c.beginPath(); c.arc(0, 62, 8, 0, TAU); c.fill(); c.restore();
  },
  counter(c, o) {
    paper(c, p => { shape(c, p, rrect(-74, -56, 148, 56, 5), vgrad(c, -56, 0, o.color || '#c58b55', shade(o.color || '#c58b55', -0.3))); shape(c, p, rrect(-80, -64, 160, 12, 4), shade(o.color || '#c58b55', 0.15)); });
    if (o.bell) { paper(c, p => shape(c, p, cc => { cc.moveTo(30, -64); cc.quadraticCurveTo(38, -84, 46, -64); cc.closePath(); }, '#ffd23f', 1.6)); }
  },
  jars(c, o) {
    const y = -120;
    paper(c, p => { shape(c, p, rrect(-66, y, 132, 10, 3), '#8a5a3c'); shape(c, p, rrect(-66, y + 50, 132, 10, 3), '#8a5a3c'); });
    for (let r = 0; r < 2; r++) for (let i = 0; i < 5; i++) {
      const x = -54 + i * 27, yy = y + r * 50;
      paper(c, p => { shape(c, p, rrect(x - 9, yy - 26, 18, 26, 5), o.color || '#ffc94a', 1.6); shape(c, p, rrect(x - 7, yy - 31, 14, 6, 2), '#c58b55', 1.4); });
    }
  },
  telescope(c, o) {
    c.strokeStyle = '#5a4e58'; c.lineWidth = 4;
    c.beginPath(); c.moveTo(0, -60); c.lineTo(-22, 0); c.moveTo(0, -60); c.lineTo(22, 0); c.moveTo(0, -60); c.lineTo(0, 0); c.stroke();
    c.save(); c.translate(0, -62); c.rotate(-0.6 + Math.sin(o.t * 0.5) * 0.05);
    paper(c, p => { shape(c, p, rrect(-34, -9, 68, 18, 6), '#d9a84a'); shape(c, p, rrect(28, -12, 14, 24, 4), '#b07a2a'); });
    c.restore();
  },
  dummy(c, o) {
    const wob = o.hitT ? Math.sin((o.t - o.hitT) * 30) * Math.max(0, 0.3 - (o.t - o.hitT)) : 0;
    paper(c, p => shape(c, p, rrect(-5, -40, 10, 40, 2), '#8a5a3c'));
    c.save(); c.translate(0, -40); c.rotate(wob);
    paper(c, p => { shape(c, p, rrect(-20, -56, 40, 56, 12), '#e8c66a'); shape(c, p, ell(0, -70, 16, 16), '#e8c66a'); });
    c.fillStyle = '#e5534b'; c.beginPath(); c.arc(0, -30, 10, 0, TAU); c.fill(); c.fillStyle = '#fffaf0'; c.beginPath(); c.arc(0, -30, 5, 0, TAU); c.fill();
    c.strokeStyle = INK; c.lineWidth = 2; c.beginPath(); c.moveTo(-6, -74); c.lineTo(-2, -70); c.moveTo(-2, -74); c.lineTo(-6, -70); c.moveTo(2, -74); c.lineTo(6, -70); c.moveTo(6, -74); c.lineTo(2, -70); c.stroke();
    c.restore();
  },
  cookiejar(c, o) {
    paper(c, p => { shape(c, p, rrect(-20, -40, 40, 40, 5), '#a8693a'); shape(c, p, rrect(-14, -76, 28, 34, 8), 'rgba(220,240,255,0.9)'); shape(c, p, rrect(-12, -84, 24, 8, 3), '#e5534b'); });
    if (!o.empty) for (const [cx, cy] of [[-5, -50], [5, -56], [-3, -64]]) { c.fillStyle = '#d9a066'; c.beginPath(); c.arc(cx, cy, 5, 0, TAU); c.fill(); }
  },
  barrel(c) {
    paper(c, p => shape(c, p, cc => { cc.moveTo(-18, 0); cc.quadraticCurveTo(-26, -28, -18, -56); cc.lineTo(18, -56); cc.quadraticCurveTo(26, -28, 18, 0); cc.closePath(); }, vgrad(c, -56, 0, '#b97a45', '#7a4a26')));
    c.strokeStyle = '#3b3350'; c.lineWidth = 3; for (const yy of [-46, -10]) { c.beginPath(); c.moveTo(-21, yy); c.lineTo(21, yy); c.stroke(); }
  },
  banner(c, o) {
    const col = o.color || '#4f72bf';
    paper(c, p => { shape(c, p, rrect(-46, -282, 92, 8, 3), '#5a4e58'); shape(c, p, poly([[-36, -276], [36, -276], [36, -170], [0, -190], [-36, -170]]), col); });
    c.fillStyle = '#ffd23f'; c.beginPath(); starPath(c, 0, -232, 16, 7, 5); c.fill();
  },
  armor(c) {
    paper(c, p => {
      shape(c, p, rrect(-20, -14, 40, 14, 3), '#5a4e58');
      shape(c, p, rrect(-8, -56, 6, 44, 2), '#9a93ad'); shape(c, p, rrect(2, -56, 6, 44, 2), '#9a93ad');
      shape(c, p, rrect(-20, -104, 40, 52, 10), vgrad(c, -104, -52, '#d6d0e0', '#9a93ad'));
      shape(c, p, rrect(-15, -138, 30, 34, 12), '#c8c2d4');
    });
    c.fillStyle = INK; c.fillRect(-10, -126, 20, 4);
    c.strokeStyle = '#7a7290'; c.lineWidth = 3; c.beginPath(); c.moveTo(26, -140); c.lineTo(26, 0); c.stroke();
  },
  throne(c, o) {
    if (o.glow) glowDot(c, 0, -90, 120, '255,220,120', 0.25);
    paper(c, p => {
      shape(c, p, rrect(-44, -190, 88, 190, 14), vgrad(c, -190, 0, '#ffd23f', '#d9a84a'));
      shape(c, p, rrect(-32, -170, 64, 110, 10), '#a8323e');
      shape(c, p, rrect(-52, -70, 104, 22, 6), '#c58b2a');
      shape(c, p, rrect(-40, -54, 80, 30, 6), '#a8323e');
    });
    c.fillStyle = '#fffaf0'; c.beginPath(); starPath(c, 0, -190, 14, 6, 5); c.fill(); c.strokeStyle = INK; c.lineWidth = 2; c.stroke();
  },
  lever(c, o) {
    const ang = o.on ? 0.7 : -0.7;
    paper(c, p => shape(c, p, rrect(-20, -14, 40, 14, 4), '#5a4e58'));
    c.save(); c.translate(0, -12); c.rotate(ang);
    paper(c, p => { shape(c, p, rrect(-3, -46, 6, 46, 2), '#9a93ad'); shape(c, p, ell(0, -50, 9, 9), o.color || '#e5534b'); });
    c.restore();
    if (o.mark) {
      paper(c, p => shape(c, p, rrect(-16, 4, 32, 28, 7), '#f6e8c6', 1.6));
      c.font = '20px "Segoe UI Emoji", sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
      c.fillText(o.mark, 0, 19); c.textBaseline = 'alphabetic';
    }
  },
  mirror(c, o) {
    paper(c, p => { shape(c, p, rrect(-4, -40, 8, 40, 2), '#d9a84a'); shape(c, p, ell(0, -96, 34, 56), '#d9a84a'); });
    c.fillStyle = vgrad(c, -150, -42, '#e8f6ff', '#9fc8e8'); c.beginPath(); c.ellipse(0, -96, 26, 48, 0, 0, TAU); c.fill();
    c.fillStyle = 'rgba(255,255,255,0.6)'; c.beginPath(); c.ellipse(-8, -112, 6, 18, 0.3, 0, TAU); c.fill();
    void o;
  },
  toybox(c) {
    paper(c, p => { shape(c, p, rrect(-36, -40, 72, 40, 5), '#5aa0d6'); shape(c, p, ell(-14, -46, 10, 10), '#e5534b'); shape(c, p, rrect(4, -58, 18, 18, 3), '#ffd23f'); });
    c.fillStyle = '#fffaf0'; c.font = 'bold 14px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillText('TOYS', 0, -14);
  },
  mailshelf(c) {
    paper(c, p => shape(c, p, rrect(-60, -170, 120, 120, 4), '#8a5a3c'));
    for (let r = 0; r < 3; r++) for (let i = 0; i < 4; i++) {
      c.fillStyle = '#5e3b24'; c.fillRect(-54 + i * 28, -164 + r * 38, 24, 32);
      if ((r + i) % 3) { c.fillStyle = ['#fffaf0', '#fff3c9', '#e8f6ff'][(r + i) % 3]; c.fillRect(-51 + i * 28, -156 + r * 38, 18, 22); }
    }
  },
  scale(c) {
    paper(c, p => { shape(c, p, rrect(-24, -16, 48, 16, 4), '#9a93ad'); shape(c, p, rrect(-4, -70, 8, 56, 2), '#7a7290'); shape(c, p, ell(0, -78, 20, 20), '#fffaf0'); });
    c.strokeStyle = '#e5534b'; c.lineWidth = 2; c.beginPath(); c.moveTo(0, -78); c.lineTo(6, -90); c.stroke();
  },
  oven(c, o) {
    glowDot(c, 0, -40, 70, '255,150,70', 0.3);
    paper(c, p => shape(c, p, cc => { cc.moveTo(-70, 0); cc.lineTo(-70, -80); cc.quadraticCurveTo(0, -150, 70, -80); cc.lineTo(70, 0); cc.closePath(); }, vgrad(c, -130, 0, '#c58b70', '#8a5a4a')));
    c.fillStyle = '#1c1020'; c.beginPath(); c.moveTo(-30, 0); c.lineTo(-30, -40); c.arc(0, -40, 30, Math.PI, 0); c.lineTo(30, 0); c.closePath(); c.fill();
    flame(c, 0, -4, 1.2, o.t);
  },
  stove(c, o) {
    paper(c, p => { shape(c, p, rrect(-50, -60, 100, 60, 5), '#5a4e58'); shape(c, p, rrect(-34, -86, 30, 24, 6), '#9a93ad'); shape(c, p, rrect(6, -80, 30, 18, 4), '#c45a5a'); });
    const q = (o.t * 0.5) % 1; c.fillStyle = `rgba(255,255,255,${0.5 * (1 - q)})`; c.beginPath(); c.arc(-19, -96 - q * 30, 5 + q * 8, 0, TAU); c.fill();
  },
  anvil(c) {
    paper(c, p => { shape(c, p, rrect(-22, -30, 44, 30, 4), '#7a4a26'); shape(c, p, poly([[-36, -54], [30, -54], [44, -46], [20, -40], [10, -30], [-14, -30], [-20, -40], [-36, -44]]), '#5a5466'); });
  },
  sacks(c) {
    paper(c, p => { shape(c, p, rrect(-46, -44, 40, 44, 14), '#f3e3c3'); shape(c, p, rrect(-4, -40, 40, 40, 14), '#e8d4b0'); shape(c, p, rrect(-26, -78, 40, 40, 14), '#f6ecd2'); });
    c.fillStyle = '#b8a07a'; c.font = 'bold 11px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillText('FLOUR', -26, -54);
  },
  gears(c, o) {
    for (const [gx, gy, r, dir] of [[-30, -200, 34, 1], [26, -170, 24, -1.4]]) {
      c.save(); c.translate(gx, gy); c.rotate(o.t * 0.6 * dir);
      c.fillStyle = '#9a7a4a'; c.strokeStyle = INK; c.lineWidth = 2;
      c.beginPath(); for (let i = 0; i < 16; i++) { const a = (i / 16) * TAU, rr = i % 2 ? r : r + 7; c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); } c.closePath(); c.fill(); c.stroke();
      c.fillStyle = '#5e3b24'; c.beginPath(); c.arc(0, 0, r * 0.35, 0, TAU); c.fill();
      c.restore();
    }
  },
  bench(c) {
    paper(c, p => { shape(c, p, rrect(-50, -30, 100, 10, 3), '#c58b55'); shape(c, p, rrect(-50, -54, 100, 8, 3), '#c58b55'); shape(c, p, rrect(-44, -22, 8, 22, 2), '#8a5a3c'); shape(c, p, rrect(36, -22, 8, 22, 2), '#8a5a3c'); });
  },
  scroll(c, o) {
    paper(c, p => { shape(c, p, rrect(-30, -260, 60, 120, 3), '#fffaf0'); shape(c, p, rrect(-36, -266, 72, 8, 3), '#8a5a3c'); shape(c, p, rrect(-36, -142, 72, 8, 3), '#8a5a3c'); });
    c.strokeStyle = INK; c.lineWidth = 5; c.lineCap = 'round';
    c.beginPath();
    if ((o.seed || 0) % 2) { c.moveTo(-12, -240); c.lineTo(12, -232); c.moveTo(0, -244); c.lineTo(-2, -160); c.moveTo(-14, -200); c.lineTo(14, -196); }
    else { c.moveTo(-14, -236); c.quadraticCurveTo(14, -220, -4, -200); c.quadraticCurveTo(-16, -180, 12, -162); c.moveTo(8, -244); c.lineTo(4, -226); }
    c.stroke();
  },
  globe(c, o) {
    paper(c, p => { shape(c, p, rrect(-4, -40, 8, 40, 2), '#8a5a3c'); shape(c, p, ell(0, -64, 26, 26), '#5aa0d6'); });
    c.save(); c.beginPath(); c.ellipse(0, -64, 25, 25, 0, 0, TAU); c.clip();
    const sh = (o.t * 10) % 50; c.fillStyle = '#8fcf74';
    for (const dx of [-50, 0, 50]) { c.beginPath(); c.ellipse(dx + sh - 10, -70, 12, 8, 0.4, 0, TAU); c.fill(); c.beginPath(); c.ellipse(dx + sh + 8, -54, 8, 6, 0, 0, TAU); c.fill(); }
    c.restore();
  },
  trophy(c) {
    paper(c, p => { shape(c, p, rrect(-20, -30, 40, 30, 4), '#8a5a3c'); shape(c, p, cc => { cc.moveTo(-18, -80); cc.lineTo(18, -80); cc.quadraticCurveTo(16, -48, 0, -44); cc.quadraticCurveTo(-16, -48, -18, -80); cc.closePath(); }, '#ffd23f'); shape(c, p, rrect(-5, -46, 10, 16, 2), '#d9a84a'); });
  },
  crate(c) { DECOR_DRAW.crate(c); },
  chandelier(c, o) {
    const y = -330;
    c.strokeStyle = '#5a4e58'; c.lineWidth = 3; c.beginPath(); c.moveTo(0, y - 80); c.lineTo(0, y); c.stroke();
    paper(c, p => shape(c, p, ell(0, y, 60, 10), '#d9a84a'));
    for (const dx of [-48, -16, 16, 48]) { paper(c, p => shape(c, p, rrect(dx - 4, y - 22, 8, 16, 2), '#fff1d6', 1.4)); flame(c, dx, y - 22, 0.45, o.t + dx); }
    glowDot(c, 0, y - 10, 120, '255,220,140', 0.2);
  },
  pedestal(c, o) {
    paper(c, p => shape(c, p, rrect(-22, -60, 44, 60, 4), vgrad(c, -60, 0, '#d6d0e0', '#9a93ad')));
    if (o.gem) { glowDot(c, 0, -76, 34, o.glow || '255,120,140', 0.5); paper(c, p => shape(c, p, poly([[0, -92], [12, -78], [0, -62], [-12, -78]]), o.gem, 1.8)); }
  },
  sign2(c, o) {
    paper(c, p => { shape(c, p, rrect(-3, -40, 6, 40, 2), '#8a5a3c'); shape(c, p, rrect(-34, -66, 68, 30, 5), '#fffaf0'); });
    c.font = 'bold 13px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillStyle = INK; c.fillText(o.text || '', 0, -46, 62);
  },
  spot() { /* an invisible spot you can examine */ },
};

// Rugs and mats lie flat on the floor, so they're drawn in perspective instead of as cutouts.
export function drawRug(c, V, x, y, o) {
  const P = (xx, z) => [V.x(xx, z), V.y(y, z)];
  const w = o.w || 120, z0 = o.z0 ?? -40, z1 = o.z1 ?? 70;
  face(c, [P(x - w / 2, z1), P(x + w / 2, z1), P(x + w / 2, z0), P(x - w / 2, z0)], o.color || '#b8483e', 0);
  c.strokeStyle = o.trim || '#ffd23f'; c.lineWidth = 3;
  const m = 10;
  c.beginPath(); c.moveTo(...P(x - w / 2 + m, z1 - m)); c.lineTo(...P(x + w / 2 - m, z1 - m)); c.lineTo(...P(x + w / 2 - m, z0 + m)); c.lineTo(...P(x - w / 2 + m, z0 + m)); c.closePath(); c.stroke();
}

// ---------------------------------------------------------------- new folks
export function drawCandle(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  const wax = o.wax || '#fff1d6', wax2 = o.wax2 || '#e9cf9e', hgt = o.tall ? 58 : 44;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 15 * s);
  c.scale(s * flip, s);
  c.translate(0, Math.sin(t * 2 + (o.seed || 0)) * 0.8);
  paper(c, p => {
    shape(c, p, ell(-6, -2, 6, 3.5), '#6b5a7a'); shape(c, p, ell(6, -2, 6, 3.5), '#6b5a7a');
    shape(c, p, cc => { cc.moveTo(-14, -4); cc.lineTo(-14, -hgt); cc.quadraticCurveTo(-9, -hgt + 7, -4, -hgt); cc.lineTo(14, -hgt); cc.lineTo(14, -4); cc.quadraticCurveTo(0, 0, -14, -4); cc.closePath(); }, vgrad(c, -hgt, 0, wax, wax2));
    if (o.shawl) shape(c, p, poly([[-16, -24], [16, -24], [12, -12], [0, -6], [-12, -12]]), o.shawl);
    if (o.apron) shape(c, p, rrect(-10, -22, 20, 18, 4), o.apron);
    if (o.bun) shape(c, p, ell(-15, -hgt + 6, 6, 6), '#f4f0f8');
  });
  c.strokeStyle = INK; c.lineWidth = 2; c.beginPath(); c.moveTo(4, -hgt); c.lineTo(4, -hgt - 6); c.stroke();
  if (o.hat === 'jester') paper(c, p => { shape(c, p, poly([[-14, -hgt], [-22, -hgt - 22], [0, -hgt - 6], [22, -hgt - 22], [14, -hgt]]), '#e5534b', 2); });
  else flame(c, 4, -hgt - 6, o.flameSize ?? 0.7, t + (o.seed || 0));
  const ey = -hgt + 12;
  eyes(c, -4, 6, ey, 7, o.mood, t);
  mouth(c, 1, ey + 7, 5, o.mood);
  if (o.specs) { c.strokeStyle = INK; c.lineWidth = 1.5; c.beginPath(); c.arc(-4, ey, 5, 0, TAU); c.stroke(); c.beginPath(); c.arc(6, ey, 5, 0, TAU); c.stroke(); }
  c.restore();
}

export function drawBee(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 16 * s);
  c.scale(s * flip, s);
  c.translate(0, -12 + Math.sin(t * 3) * 3);
  const fl = Math.sin(t * 32) * 0.4;
  c.save(); c.globalAlpha = 0.8;
  paper(c, p => { shape(c, p, ell(-12, -50, 9, 16, -0.6 - fl), '#e8f6ff', 1.6); shape(c, p, ell(12, -50, 9, 16, 0.6 + fl), '#e8f6ff', 1.6); });
  c.restore();
  paper(c, p => shape(c, p, ell(0, -26, 22, 25), vgrad(c, -51, -1, '#ffe066', '#f2b43a')));
  c.save(); c.beginPath(); c.ellipse(0, -26, 22, 25, 0, 0, TAU); c.clip();
  c.fillStyle = INK; for (const yy of [-18, -8]) c.fillRect(-24, yy, 48, 5);
  c.restore();
  c.strokeStyle = INK; c.lineWidth = 2;
  c.beginPath(); c.moveTo(-6, -49); c.quadraticCurveTo(-10, -62, -15, -63); c.moveTo(6, -49); c.quadraticCurveTo(10, -62, 15, -63); c.stroke();
  c.fillStyle = INK; c.beginPath(); c.arc(-15, -63, 2.6, 0, TAU); c.arc(15, -63, 2.6, 0, TAU); c.fill();
  eyes(c, -7, 7, -36, 8, o.mood, t);
  mouth(c, 0, -27, 5, o.mood || 'happy');
  c.restore();
}

export function drawPincushion(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 20 * s);
  c.scale(s * flip, s);
  paper(c, p => {
    shape(c, p, ell(-9, -2, 6, 3.5), '#6b5a7a'); shape(c, p, ell(9, -2, 6, 3.5), '#6b5a7a');
    shape(c, p, ell(0, -26, 26, 22), vgrad(c, -48, -4, '#ff7a6e', '#c43a3a'));
    shape(c, p, poly([[-10, -46], [0, -56], [10, -46], [0, -42]]), '#5fae5c');
  });
  const pins = [[-18, -36, '#ffd23f'], [16, -40, '#4f72bf'], [22, -22, '#fffaf0'], [-24, -18, '#7b5fc7']];
  for (const [px, py, col] of pins) {
    c.strokeStyle = '#9a93ad'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(px * 0.7, py * 0.8); c.lineTo(px, py); c.stroke();
    c.fillStyle = col; c.beginPath(); c.arc(px, py, 3.5, 0, TAU); c.fill(); c.strokeStyle = INK; c.lineWidth = 1; c.stroke();
  }
  c.fillStyle = '#ffd23f'; c.beginPath(); starPath(c, 12, -14, 6, 3, 5); c.fill(); c.strokeStyle = INK; c.lineWidth = 1.2; c.stroke();
  eyes(c, -7, 5, -30, 7, o.mood, t);
  mouth(c, -1, -22, 5, o.mood || 'happy');
  c.restore();
}

export function drawStarFolk(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 16 * s);
  c.scale(s * flip, s);
  c.translate(0, -34 + Math.sin(t * 2) * 4);
  glowDot(c, 0, 0, 48, '255,230,120', 0.35);
  c.save(); c.rotate(Math.sin(t * 1.2) * 0.12);
  paper(c, p => shape(c, p, cc => starPath(cc, 0, 0, 28, 14, 5), vgrad(c, -28, 28, '#fff3a8', '#ffc83a')));
  c.restore();
  for (let i = 0; i < 3; i++) { const a = t * 1.5 + i * 2.1; c.fillStyle = '#fff6d0'; c.beginPath(); starPath(c, Math.cos(a) * 38, Math.sin(a) * 26, 4, 1.6, 4); c.fill(); }
  eyes(c, -6, 6, -3, 7, o.mood, t);
  mouth(c, 0, 6, 5, o.mood || 'happy');
  c.restore();
}

export function drawBookworm(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 22 * s);
  c.scale(s * flip, s);
  paper(c, p => {
    shape(c, p, poly([[-30, 0], [-28, -18], [0, -14], [0, 0]]), '#fffaf0');
    shape(c, p, poly([[30, 0], [28, -18], [0, -14], [0, 0]]), '#f4ecd8');
    shape(c, p, rrect(-32, -4, 64, 6, 2), '#5a4fa8');
  });
  const sway = Math.sin(t * 2) * 3;
  paper(c, p => {
    for (let i = 0; i < 4; i++) shape(c, p, ell(sway * (i / 4), -18 - i * 11, 10 - i * 0.6, 8), i % 2 ? '#8be07a' : '#7cc46a');
    shape(c, p, ell(sway, -66, 14, 13), '#8be07a');
  });
  c.strokeStyle = INK; c.lineWidth = 1.8;
  c.beginPath(); c.arc(sway - 5, -68, 5.5, 0, TAU); c.stroke(); c.beginPath(); c.arc(sway + 6, -68, 5.5, 0, TAU); c.stroke();
  eyes(c, sway - 5, sway + 6, -68, 6, o.mood, t);
  mouth(c, sway, -60, 4, o.mood);
  c.restore();
}

// Sensei Strike: a matchstick martial artist. `lit` sets his head on fire (in battle that means "don't jump on me").
export function drawMatchstick(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'determined';
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 16 * s);
  c.scale(s * flip, s);
  const stance = o.stance === 'counter';
  const bob = o.state === 'walk' ? -Math.abs(Math.sin((o.phase || 0) * TAU)) * 3 : Math.sin(t * 3) * 1.2;
  c.translate(0, bob);
  if (o.lit) glowDot(c, 0, -96, 60, '255,150,60', 0.5);
  paper(c, p => {
    shape(c, p, rrect(-10, -6, 9, 6, 2), '#5a3a22'); shape(c, p, rrect(2, -6, 9, 6, 2), '#5a3a22');
    shape(c, p, rrect(-7, -70, 14, 66, 4), vgrad(c, -70, 0, '#e8c690', '#c49a5e'));
    shape(c, p, rrect(-9, -36, 18, 6, 2), INK);
    if (stance) { shape(c, p, poly([[-22, -58], [20, -46], [18, -40], [-22, -52]]), '#c49a5e'); shape(c, p, poly([[22, -58], [-20, -46], [-18, -40], [22, -52]]), '#d8b07a'); }
    else { shape(c, p, poly([[-6, -56], [-30, -44], [-28, -38], [-6, -48]]), '#c49a5e'); shape(c, p, poly([[6, -58], [30, -68], [32, -62], [6, -50]]), '#d8b07a'); }
    shape(c, p, ell(0, -86, 15, 18), vgrad(c, -104, -68, '#ff6b5a', '#c43a3a'));
  });
  const fl = Math.sin(t * 9) * 2;
  paper(c, p => { shape(c, p, rrect(-16, -92, 32, 6, 2), '#fffaf0', 1.6); shape(c, p, poly([[-15, -91], [-30, -86 + fl], [-28, -80 + fl], [-15, -87]]), '#fffaf0', 1.6); });
  eyes(c, -5, 6, -80, 7, mood, t);
  c.fillStyle = '#fffaf0'; c.strokeStyle = INK; c.lineWidth = 1.4;
  c.beginPath(); c.ellipse(-5, -72, 7, 3, -0.2, 0, TAU); c.fill(); c.stroke(); c.beginPath(); c.ellipse(6, -72, 7, 3, 0.2, 0, TAU); c.fill(); c.stroke();
  if (o.lit) flame(c, 0, -102, 1.6, t);
  c.restore();
}

export function drawPostman(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 16 * s);
  c.scale(s * flip, s);
  c.translate(0, -40 + Math.sin(t * 4) * 3); c.rotate(0.05 + Math.sin(t * 2) * 0.04);
  paper(c, p => {
    shape(c, p, poly([[-30, -7], [30, 0], [-30, 10], [-18, 1]]), vgrad(c, -7, 10, '#fffaf0', '#e8f0ff'));
    shape(c, p, poly([[-18, 1], [30, 0], [-24, 15]]), '#dbe6f6');
    shape(c, p, rrect(-14, 6, 18, 14, 3), '#a8693a');
    shape(c, p, poly([[6, -10], [24, -10], [22, -18], [8, -18]]), '#3b5a7b');
    shape(c, p, rrect(4, -11, 24, 4, 2), '#2a4560');
  });
  c.fillStyle = '#ffd23f'; c.fillRect(-8, 10, 6, 5);
  eyes(c, 12, 20, -3, 6, o.mood, t);
  c.restore();
}

export function drawInkDot(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  const col = o.variant === 'dash' ? '#2a7a72' : '#3a4a9a';
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 12 * s);
  c.scale(s * flip, s);
  c.translate(0, -Math.abs(Math.sin(t * 4 + (o.variant === 'dash' ? 1 : 0))) * 3);
  paper(c, p => {
    shape(c, p, ell(-4, -1, 4, 2.5), INK); shape(c, p, ell(5, -1, 4, 2.5), INK);
    shape(c, p, ell(0, -16, 15, 15), vgrad(c, -31, -1, shade(col, 0.2), col));
    if (o.variant === 'dash') shape(c, p, poly([[-12, -26], [12, -30], [16, -24], [-10, -22]]), '#e5534b', 1.6);
    else shape(c, p, cc => { cc.moveTo(4, -31); cc.lineTo(14, -38); cc.lineTo(14, -28); cc.lineTo(4, -31); cc.lineTo(-6, -38); cc.lineTo(-6, -28); cc.closePath(); }, '#ff9ab0', 1.6);
  });
  for (const ex of [-5, 5]) { c.fillStyle = '#fffaf0'; c.beginPath(); c.arc(ex, -17, 4.5, 0, TAU); c.fill(); c.fillStyle = INK; c.beginPath(); c.arc(ex + 1, -17, 2.2, 0, TAU); c.fill(); }
  mouth(c, 0, -9, 4, o.mood || 'happy');
  c.restore();
}

export function drawCat(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 16 * s);
  c.scale(s * flip, s);
  const tail = Math.sin(t * 2.5) * 0.4;
  c.save(); c.translate(-14, -8); c.rotate(tail);
  c.strokeStyle = PAPER; c.lineWidth = 11; c.lineCap = 'round'; c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(-18, -4, -16, -26); c.stroke();
  c.strokeStyle = '#e8a050'; c.lineWidth = 6; c.stroke();
  c.restore();
  paper(c, p => {
    shape(c, p, ell(0, -14, 18, 14), vgrad(c, -28, 0, '#f6b860', '#e08a3a'));
    shape(c, p, poly([[2, -34], [6, -50], [12, -38]]), '#e08a3a'); shape(c, p, poly([[16, -38], [24, -50], [24, -34]]), '#e08a3a');
    shape(c, p, ell(13, -30, 13, 11), '#f6b860');
  });
  c.strokeStyle = 'rgba(140,70,20,0.55)'; c.lineWidth = 2;
  for (const sx of [-8, -2, 4]) { c.beginPath(); c.moveTo(sx, -26); c.lineTo(sx + 2, -18); c.stroke(); }
  eyes(c, 9, 18, -32, 6, o.mood || 'happy', t);
  c.fillStyle = '#ff9ab0'; c.beginPath(); c.arc(14, -27, 1.8, 0, TAU); c.fill();
  c.strokeStyle = INK; c.lineWidth = 1;
  c.beginPath(); c.moveTo(20, -27); c.lineTo(30, -29); c.moveTo(20, -25); c.lineTo(30, -24); c.stroke();
  if (o.happy) { c.fillStyle = '#ff6b8a'; c.font = 'bold 16px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillText('♥', 14, -54 - Math.sin(t * 4) * 3); }
  c.restore();
}

// Sir Drip: a candle knight who melted a little from worry, waiting at the castle gate.
export function drawWaxKnight(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  const proud = o.proud;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 18 * s);
  c.scale(s * flip, s);
  c.translate(0, Math.sin(t * 1.6) * 0.8);
  const droop = proud ? 0 : 1;
  paper(c, p => {
    shape(c, p, ell(-7, -2, 7, 4), '#8a8298'); shape(c, p, ell(7, -2, 7, 4), '#8a8298');
    shape(c, p, cc => { cc.moveTo(-16, -4); cc.lineTo(-16, -46); cc.quadraticCurveTo(-19, -34 + droop * 6, -21, -30 + droop * 10); cc.quadraticCurveTo(-18, -44, -12, -52); cc.lineTo(14, -52); cc.quadraticCurveTo(20, -40, 18, -26 + droop * 4); cc.quadraticCurveTo(16, -30, 16, -40); cc.lineTo(16, -4); cc.closePath(); }, vgrad(c, -52, 0, '#fffaf0', '#e8dcc6'));
    shape(c, p, rrect(-18, -34, 36, 22, 6), vgrad(c, -34, -12, '#c8c2d4', '#8a84a0'));
    shape(c, p, rrect(-17, -74, 34, 26, 10), vgrad(c, -74, -48, '#d6d0e0', '#9a93ad'));
    shape(c, p, cc => { cc.moveTo(4, -74); cc.quadraticCurveTo(20, -88 + droop * 4, 30, -64 + droop * 18); cc.quadraticCurveTo(18, -76, 8, -70); cc.closePath(); }, '#e5534b');
    shape(c, p, rrect(-30, -40, 14, 26, 5), '#4f72bf');
  });
  c.fillStyle = INK; c.fillRect(-12, -64, 24, 4);
  eyes(c, -5, 6, -58, 6, o.mood || 'worried', t);
  c.restore();
}

export function drawQueen(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  c.globalAlpha = o.ghost ? 0.85 : 1;
  if (o.ghost || o.glow) glowDot(c, 0, -50, 90, '255,230,170', 0.4);
  if (o.shadow !== false) shadow(c, 0, 0, 22 * s);
  c.scale(s * flip, s);
  c.translate(0, Math.sin(t * 1.4) * 1.5);
  paper(c, p => {
    shape(c, p, poly([[-30, 0], [30, 0], [14, -40], [-14, -40]]), vgrad(c, -40, 0, '#a86ad0', '#6a3a9a'));
    shape(c, p, rrect(-13, -76, 26, 40, 8), vgrad(c, -76, -36, '#fffaf0', '#f0dcc0'));
    shape(c, p, poly([[-14, -76], [-14, -92], [-7, -84], [0, -96], [7, -84], [14, -92], [14, -76]]), '#ffd23f', 1.8);
  });
  c.fillStyle = '#ff6b8a'; c.beginPath(); c.arc(0, -88, 2.6, 0, TAU); c.fill();
  c.strokeStyle = INK; c.lineWidth = 2; c.beginPath(); c.moveTo(0, -96); c.lineTo(0, -101); c.stroke();
  flame(c, 0, -101, 0.6, t);
  eyes(c, -5, 5, -62, 7, o.mood || 'happy', t);
  mouth(c, 0, -53, 5, o.mood || 'happy');
  c.restore();
}

export function drawChef(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 18 * s);
  c.scale(s * flip, s);
  c.translate(0, Math.sin(t * 2.2) * 0.8);
  paper(c, p => {
    shape(c, p, ell(-8, -2, 6, 3.5), '#6b4a2a'); shape(c, p, ell(8, -2, 6, 3.5), '#6b4a2a');
    shape(c, p, rrect(-22, -50, 44, 48, 16), vgrad(c, -50, -2, '#f2c27a', '#d08a42'));
    shape(c, p, cc => { cc.moveTo(-22, -34); cc.quadraticCurveTo(-24, -54, 0, -56); cc.quadraticCurveTo(24, -54, 22, -34); cc.quadraticCurveTo(0, -42, -22, -34); cc.closePath(); }, '#a8622a');
    shape(c, p, rrect(-12, -24, 24, 22, 5), '#fffaf0');
    shape(c, p, rrect(-14, -72, 28, 18, 4), '#fffaf0');
    shape(c, p, ell(-9, -76, 9, 9), '#fffaf0'); shape(c, p, ell(9, -76, 9, 9), '#fffaf0'); shape(c, p, ell(0, -82, 10, 10), '#fffaf0');
  });
  eyes(c, -6, 6, -40, 7, o.mood, t);
  c.fillStyle = '#6b3a1a'; c.beginPath(); c.ellipse(-6, -32, 7, 3, -0.3, 0, TAU); c.ellipse(6, -32, 7, 3, 0.3, 0, TAU); c.fill();
  c.restore();
}

export function drawCarto(c, x, y, o = {}) {
  drawFolk(c, x, y, { ...o, color: o.color || '#5ab0a0', body: o.body || '#3a6a8a' });
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y + Math.sin(t * 2 + (o.seed || 0)) * 0.8); c.scale(s * flip, s);
  paper(c, p => { shape(c, p, ell(-2, -58, 18, 6, -0.1), '#c45a5a', 2); shape(c, p, ell(10, -63, 3, 3), '#c45a5a', 1.4); });
  c.save(); c.translate(15, -16); c.rotate(-0.5);
  paper(c, p => { shape(c, p, rrect(-5, -16, 10, 32, 4), '#f6e8c6', 1.6); shape(c, p, ell(0, -16, 5, 3), '#e8d4a6', 1.2); });
  c.restore();
  c.restore();
}

// Hide-and-seek spots: something with a little pair of eyes peeking out.
export function drawHideKid(c, x, y, o = {}) {
  const t = o.t || 0, spot = o.spot || 'bush';
  c.save(); c.translate(x, y);
  const peek = Math.max(0, Math.sin(t * 1.3 + x)) * 4;
  if (spot === 'barrel') FURN.barrel(c, o);
  else if (spot === 'crate') DECOR_DRAW.crate(c);
  else if (spot === 'plant') FURN.plant(c, o);
  if (spot === 'bush') paper(c, p => { shape(c, p, ell(-16, -18, 20, 17), '#4f9a52', 2); shape(c, p, ell(14, -20, 21, 18), '#5fae5c', 2); shape(c, p, ell(0, -32, 19, 16), '#6cc068', 2); });
  const ey = spot === 'barrel' ? -60 - peek : spot === 'crate' ? -44 - peek : spot === 'plant' ? -40 : -28;
  const ex = spot === 'plant' ? 14 : 4;
  for (const dx of [-5, 5]) { c.fillStyle = '#fffaf0'; c.beginPath(); c.arc(ex + dx, ey, 4, 0, TAU); c.fill(); c.strokeStyle = INK; c.lineWidth = 1.2; c.stroke(); c.fillStyle = INK; c.beginPath(); c.arc(ex + dx + 1, ey, 2, 0, TAU); c.fill(); }
  if (spot === 'bed') { c.fillStyle = '#3a4a9a'; c.beginPath(); c.ellipse(30, -6, 10, 6, 0, 0, TAU); c.fill(); }
  c.restore();
}

// ---------------------------------------------------------------- new enemies & mini-bosses
export function drawRocco(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'angry';
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 30 * s);
  c.scale(s * flip, s);
  const walk = o.state === 'walk', bob = walk ? -Math.abs(Math.sin((o.phase || 0) * TAU)) * 3 : Math.sin(t * 2) * 1.5;
  c.translate(0, bob);
  const tw = Math.sin(t * 3) * 0.2;
  c.save(); c.translate(-28, -24); c.rotate(-0.6 + tw);
  paper(c, p => shape(c, p, ell(-20, 0, 26, 11), '#8a8698'));
  c.fillStyle = '#3b3350'; for (const dx of [-34, -22, -10]) c.fillRect(dx, -9, 6, 18);
  c.restore();
  if (o.sack !== false) paper(c, p => { shape(c, p, ell(24, -56, 20, 22), '#d9c09a'); shape(c, p, rrect(18, -80, 12, 8, 3), '#b8a07a'); });
  paper(c, p => {
    shape(c, p, ell(-11, -3, 9, 5), '#3b3350'); shape(c, p, ell(11, -3, 9, 5), '#3b3350');
    shape(c, p, ell(0, -34, 30, 32), vgrad(c, -66, -2, '#a8a4b6', '#76728a'));
    shape(c, p, ell(0, -26, 18, 18), '#d6d2e0');
    shape(c, p, poly([[-22, -60], [-16, -78], [-6, -64]]), '#76728a'); shape(c, p, poly([[22, -60], [16, -78], [6, -64]]), '#76728a');
  });
  c.fillStyle = '#2b2235'; c.beginPath(); c.ellipse(0, -48, 22, 8, 0, 0, TAU); c.fill();
  paper(c, p => shape(c, p, poly([[-20, -36], [20, -36], [14, -28], [0, -22], [-14, -28]]), '#e5534b', 2));
  eyes(c, -8, 8, -48, 8, mood, t);
  c.fillStyle = INK; c.beginPath(); c.ellipse(0, -40, 4, 3, 0, 0, TAU); c.fill();
  c.restore();
}

export function drawGloomKnight(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 30 * s);
  c.scale(s * flip, s);
  c.translate(0, Math.sin(t * 1.8) * 1.5);
  for (let i = 0; i < 4; i++) { const q = (t * 0.5 + i / 4) % 1; c.fillStyle = `rgba(110,70,170,${0.4 * (1 - q)})`; c.beginPath(); c.arc(Math.sin(i * 2 + t) * 20, -40 - q * 70, 8 + q * 14, 0, TAU); c.fill(); }
  const dark = ['#5a5070', '#2e2840'];
  paper(c, p => {
    shape(c, p, rrect(-20, -8, 16, 8, 3), '#2e2840'); shape(c, p, rrect(4, -8, 16, 8, 3), '#2e2840');
    shape(c, p, rrect(-16, -40, 12, 34, 4), dark[1]); shape(c, p, rrect(4, -40, 12, 34, 4), dark[1]);
    shape(c, p, rrect(-26, -86, 52, 50, 14), vgrad(c, -86, -36, dark[0], dark[1]));
    shape(c, p, ell(-30, -80, 13, 10), '#463e5c'); shape(c, p, ell(30, -80, 13, 10), '#463e5c');
    shape(c, p, rrect(-19, -122, 38, 38, 14), vgrad(c, -122, -84, '#6a6080', dark[1]));
  });
  if (o.spikes) { c.fillStyle = '#c8c2d4'; c.strokeStyle = INK; c.lineWidth = 1.5; for (const sx of [-12, 0, 12]) { c.beginPath(); c.moveTo(sx - 5, -120); c.lineTo(sx, -136); c.lineTo(sx + 5, -120); c.closePath(); c.fill(); c.stroke(); } }
  else paper(c, p => shape(c, p, cc => { cc.moveTo(0, -120); cc.quadraticCurveTo(-10, -146, -26, -142); cc.quadraticCurveTo(-12, -132, -6, -118); cc.closePath(); }, '#7a3a9a'));
  c.fillStyle = '#120c1e'; c.fillRect(-13, -108, 26, 6); c.fillRect(-3, -108, 6, 18);
  glowDot(c, -7, -105, 10, '200,120,255', 0.9); glowDot(c, 7, -105, 10, '200,120,255', 0.9);
  for (let i = 0; i < (o.dent || 0); i++) { c.strokeStyle = '#d6d0e0'; c.lineWidth = 2; c.beginPath(); c.moveTo(-12 + i * 14, -78); c.lineTo(-6 + i * 14, -64); c.lineTo(-10 + i * 14, -54); c.stroke(); }
  // lance and shield
  c.save(); c.translate(34, -60); c.rotate(-0.3);
  paper(c, p => { shape(c, p, rrect(-3, -70, 6, 110, 2), '#8a84a0'); shape(c, p, poly([[-9, -70], [0, -104], [9, -70]]), '#c8c2d4'); });
  c.restore();
  if (o.shield !== false) {
    c.save(); c.translate(-36, -54);
    if (o.raised) glowDot(c, 0, 0, 50, '160,120,255', 0.5);
    paper(c, p => shape(c, p, cc => { cc.moveTo(-18, -26); cc.lineTo(18, -26); cc.quadraticCurveTo(20, 10, 0, 28); cc.quadraticCurveTo(-20, 10, -18, -26); cc.closePath(); }, vgrad(c, -26, 28, '#4a4268', '#2a2440')));
    c.fillStyle = '#c8b8ff'; c.beginPath(); c.arc(0, -2, 9, 0.5, TAU - 0.5); c.arc(4, -2, 7, TAU - 0.8, 0.8, true); c.fill();
    c.restore();
  }
  c.restore();
}

export function drawHollowArmor(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 18 * s);
  c.scale(s * flip, s);
  if (o.toppled) { c.translate(0, -12); c.rotate(-1.35); c.translate(0, 12); }
  const walk = o.state === 'walk', bob = walk ? -Math.abs(Math.sin((o.phase || 0) * TAU)) * 2 : 0;
  c.translate(0, bob);
  paper(c, p => {
    shape(c, p, rrect(-12, -8, 10, 8, 2), '#6e6880'); shape(c, p, rrect(2, -8, 10, 8, 2), '#6e6880');
    shape(c, p, rrect(-14, -40, 28, 34, 8), vgrad(c, -40, -6, '#c8c2d4', '#8a84a0'));
    shape(c, p, rrect(-12, -66, 24, 26, 10), vgrad(c, -66, -40, '#d6d0e0', '#9a93ad'));
  });
  c.fillStyle = '#120c1e'; c.fillRect(-9, -56, 18, 5);
  if (!o.toppled) { glowDot(c, -4, -54, 6, '200,120,255', 0.9); glowDot(c, 4, -54, 6, '200,120,255', 0.9); }
  else { c.font = 'bold 13px Fredoka, sans-serif'; c.fillStyle = '#fffaf0'; c.fillText('@', 0, -50); }
  c.save(); c.translate(16, -28); c.rotate(-0.4 + (o.state === 'walk' ? Math.sin((o.phase || 0) * TAU) * 0.2 : 0));
  paper(c, p => { shape(c, p, rrect(-2, -36, 4, 36, 1.5), '#c8c2d4', 1.6); shape(c, p, rrect(-7, -2, 14, 4, 1.5), '#8a5a3c', 1.4); });
  c.restore();
  c.restore();
}

export function drawDustBunny(c, x, y, o = {}) {
  const t = o.t || 0, s = (o.scale || 1) * (o.small ? 0.72 : 1), flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 16 * s);
  c.scale(s * flip, s);
  const hop = o.state === 'walk' ? -Math.abs(Math.sin((o.phase || 0) * TAU * 1.5)) * 6 : -Math.abs(Math.sin(t * 2.5)) * 2;
  c.translate(0, hop);
  const ear = Math.sin(t * 3) * 0.15;
  paper(c, p => {
    shape(c, p, ell(-7, -40, 5, 14, -0.2 - ear), '#b9b4c4'); shape(c, p, ell(7, -40, 5, 14, 0.2 + ear), '#b9b4c4');
    for (const [dx, dy, r] of [[-12, -14, 11], [12, -14, 11], [0, -20, 15], [-8, -26, 10], [8, -26, 10]]) shape(c, p, ell(dx, dy, r, r * 0.9), '#cfcad8', 1.8);
  });
  c.fillStyle = 'rgba(255,255,255,0.4)';
  for (let i = 0; i < 5; i++) { const a = t * 2 + i; c.beginPath(); c.arc(Math.cos(a) * 20, -18 + Math.sin(a * 1.3) * 12, 2, 0, TAU); c.fill(); }
  eyes(c, -5, 5, -22, 6, o.mood || 'angry', t);
  c.fillStyle = '#ff9ab0'; c.beginPath(); c.arc(0, -15, 2.4, 0, TAU); c.fill();
  c.restore();
}

// ---------------------------------------------------------------- pickups
export function drawPage(c, x, y, t = 0) {
  const by = y - 18 + Math.sin(t * 2.4 + x) * 4;
  glowDot(c, x, by, 30, '255,240,190', 0.5);
  c.save(); c.translate(x, by); c.rotate(Math.sin(t * 1.6 + x) * 0.15);
  paper(c, p => shape(c, p, cc => { cc.moveTo(-11, -14); cc.lineTo(7, -14); cc.lineTo(12, -9); cc.lineTo(12, 14); cc.lineTo(-11, 14); cc.closePath(); }, '#fffaf0', 1.8));
  c.strokeStyle = 'rgba(43,34,53,0.45)'; c.lineWidth = 1.4;
  for (const yy of [-7, -2, 3, 8]) { c.beginPath(); c.moveTo(-7, yy); c.lineTo(8, yy); c.stroke(); }
  c.restore();
}

export function drawGem(c, x, y, t = 0, col = '#e5534b') {
  const by = y - 18 + Math.sin(t * 2.4 + x) * 4;
  glowDot(c, x, by, 34, '255,220,220', 0.5);
  paper(c, p => shape(c, p, poly([[x, by - 14], [x + 12, by - 2], [x, by + 14], [x - 12, by - 2]]), col, 1.8));
  c.fillStyle = 'rgba(255,255,255,0.6)'; c.beginPath(); c.moveTo(x - 6, by - 4); c.lineTo(x, by - 10); c.lineTo(x + 2, by - 4); c.fill();
}

// ---------------------------------------------------------------- the guide arrow
// `angle` is where it points: 0 = right, Math.PI = left, -Math.PI / 2 = up (or 'up' for "go in here").
export function drawGuideArrow(c, x, y, angle, t, label) {
  const up = angle === 'up';
  const a = up ? -Math.PI / 2 : angle, bob = Math.sin(t * 5) * 4;
  c.save(); c.translate(x + (up ? 0 : Math.cos(a) * bob), y + (up ? -Math.abs(bob) : Math.sin(a) * bob));
  c.rotate(a);
  c.fillStyle = '#ffe066'; c.strokeStyle = INK; c.lineWidth = 3; c.lineJoin = 'round';
  c.beginPath(); c.moveTo(-14, -6); c.lineTo(2, -6); c.lineTo(2, -14); c.lineTo(18, 0); c.lineTo(2, 14); c.lineTo(2, 6); c.lineTo(-14, 6); c.closePath();
  c.fill(); c.stroke();
  c.restore();
  if (label) {
    c.font = 'bold 13px Fredoka, sans-serif'; c.textAlign = 'center';
    const w = Math.min(220, c.measureText(label).width + 18);
    const lx = x + (up ? 0 : Math.cos(a) * 6), ly = y + (up ? -36 : 26);
    c.fillStyle = 'rgba(20,12,40,0.82)'; c.beginPath(); rrect(lx - w / 2, ly - 12, w, 20, 8)(c); c.fill();
    c.fillStyle = '#ffe9a8'; c.fillText(label, lx, ly + 3, 210);
  }
}

// ---------------------------------------------------------------- backdrops for the new places
// (later chapters add their own skies here: theme -> fn(c, camX, W, H, t, opts))
export const EXTRA_BACKDROPS = {};
export function drawBackdrop2(c, theme, camX, W, H, t, opts = {}) {
  if (EXTRA_BACKDROPS[theme]) { EXTRA_BACKDROPS[theme](c, camX, W, H, t, opts); return true; }
  const sky = (a, b) => { c.fillStyle = vgrad(c, 0, H, a, b); c.fillRect(0, 0, W, H); };
  const hills = (f, base, amp, col, seed) => {
    c.beginPath(); c.moveTo(0, H);
    for (let x = 0; x <= W + 16; x += 16) { const wx = x + camX * f; c.lineTo(x, base - amp * (0.6 * Math.sin(wx * 0.004 + seed) + 0.4 * Math.sin(wx * 0.011 + seed * 2.3))); }
    c.lineTo(W, H); c.closePath(); c.fillStyle = col; c.fill();
    c.strokeStyle = 'rgba(255,250,240,0.7)'; c.lineWidth = 4; c.stroke();
  };
  const castle = (cx, base, k, col, lit) => {
    c.fillStyle = col;
    c.fillRect(cx - 120 * k, base - 120 * k, 240 * k, 120 * k);
    for (const [tx, th] of [[-130, 190], [-60, 150], [0, 230], [60, 150], [130, 190]]) {
      c.fillRect(cx + (tx - 18) * k, base - th * k, 36 * k, th * k);
      c.beginPath(); c.moveTo(cx + (tx - 24) * k, base - th * k); c.lineTo(cx + tx * k, base - (th + 44) * k); c.lineTo(cx + (tx + 24) * k, base - th * k); c.fill();
    }
    if (lit) { c.fillStyle = '#ffd67a'; for (const [wx, wy] of [[-130, 150], [0, 190], [130, 150], [-60, 110], [60, 110]]) c.fillRect(cx + (wx - 5) * k, base - wy * k, 10 * k, 14 * k); }
  };
  if (theme === 'hills') {
    sky('#a8d8f4', '#fdf0d6');
    for (let i = 0; i < 3; i++) {
      const cx = ((i * 330 - camX * 0.08 + t * 6) % (W + 260) + W + 260) % (W + 260) - 130;
      c.fillStyle = 'rgba(255,255,255,0.9)'; c.beginPath(); c.ellipse(cx, 70 + i * 26, 54, 16, 0, 0, TAU); c.ellipse(cx + 32, 61 + i * 26, 36, 18, 0, 0, TAU); c.fill();
    }
    if (opts.horizon) opts.horizon('day');
    hills(0.06, 320, 30, '#c2e3b0', 0.4);
    castle(760 - camX * 0.08, 330, 0.7, '#8a84a8', true);
    hills(0.25, 380, 26, '#9fd38a', 1.7);
    return true;
  }
  if (theme === 'plains') {
    // wide open paper meadows: layers of cut-paper hills, pinwheels turning far away
    sky('#9fd8f4', '#fff4dc');
    for (let i = 0; i < 4; i++) {
      const cx = ((i * 290 - camX * 0.06 + t * 5) % (W + 260) + W + 260) % (W + 260) - 130;
      c.fillStyle = 'rgba(255,255,255,0.92)'; c.beginPath(); c.ellipse(cx, 64 + i * 24, 58, 16, 0, 0, TAU); c.ellipse(cx + 34, 55 + i * 24, 38, 18, 0, 0, TAU); c.fill();
    }
    if (opts.horizon) opts.horizon('day');
    hills(0.05, 318, 26, '#cfe9b8', 2.9);
    const sp = 380, off = (camX * 0.12) % sp;
    for (let i = -1; i < W / sp + 2; i++) {
      const px = i * sp - off + 120, k = 0.55;
      c.fillStyle = '#e8dcc0'; c.fillRect(px - 3 * k, 300, 6 * k, 40);
      c.save(); c.translate(px, 300); c.rotate(t * 0.9 + i);
      for (let b = 0; b < 4; b++) { c.rotate(Math.PI / 2); c.fillStyle = ['#ff9ab0', '#ffe066', '#9fe6ff', '#b49cff'][b]; c.beginPath(); c.moveTo(0, 0); c.lineTo(22 * k, -6 * k); c.lineTo(20 * k, 10 * k); c.closePath(); c.fill(); }
      c.restore();
    }
    hills(0.16, 352, 22, '#b6e09a', 0.7);
    hills(0.3, 390, 18, '#9dd380', 4.4);
    return true;
  }
  if (theme === 'castle') {
    sky('#7d6aa8', '#f6c6a0');
    c.fillStyle = '#fff4d6'; c.beginPath(); c.arc(170 - camX * 0.03, 90, 26, 0, TAU); c.fill();
    if (opts.horizon) opts.horizon('dusk');
    hills(0.05, 340, 20, '#9a8ab8', 2.2);
    // the castle wall runs along behind the courtyard, with towers
    const sp = 260, off = (camX * 0.3) % sp;
    c.fillStyle = '#8a84a0'; c.fillRect(0, 250, W, 200);
    c.strokeStyle = 'rgba(43,34,53,0.18)'; c.lineWidth = 2;
    for (let y = 262; y < 450; y += 24) { c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); }
    for (let i = -1; i < W / sp + 2; i++) {
      const tx = i * sp - off;
      c.fillStyle = '#9a94ad'; c.fillRect(tx - 34, 150, 68, 300);
      c.fillStyle = '#5a4e68'; c.beginPath(); c.moveTo(tx - 42, 152); c.lineTo(tx, 90); c.lineTo(tx + 42, 152); c.fill();
      c.fillStyle = '#ffd67a'; c.fillRect(tx - 7, 196, 14, 22);
      c.fillStyle = '#4f72bf'; c.beginPath(); c.moveTo(tx + 2, 90); c.lineTo(tx + 2, 60); c.lineTo(tx + 28 + Math.sin(t * 3 + i) * 3, 68); c.lineTo(tx + 2, 76); c.fill();
    }
    for (let x = -((camX * 0.3) % 40); x < W; x += 40) { c.fillStyle = '#8a84a0'; c.fillRect(x, 236, 24, 16); }
    return true;
  }
  if (theme === 'interior') { c.fillStyle = '#1c1428'; c.fillRect(0, 0, W, H); return true; }
  return false;
}

// ---------------------------------------------------------------- the battle stage
export function drawStage(c, t, o = {}) {
  const V = view(0, 175), F = o.floor || 452;
  const P = (x, z) => [V.x(x, z), V.y(F, z)];
  const wood = o.wood || ['#d8a066', '#b07a45'];
  face(c, [P(-200, 320), P(1160, 320), P(1160, -120), P(-200, -120)], vgrad(c, V.y(F, 320), V.y(F, -120), wood[1], wood[0]), 0);
  c.strokeStyle = 'rgba(80,40,20,0.35)'; c.lineWidth = 2;
  for (let x = -200; x <= 1160; x += 64) { c.beginPath(); c.moveTo(...P(x, 320)); c.lineTo(...P(x, -120)); c.stroke(); }
  for (const z of [240, 160, 80, 0, -70]) { c.beginPath(); c.moveTo(...P(-200, z)); c.lineTo(...P(1160, z)); c.stroke(); }
  // where the stage meets the scenery
  const [, by] = P(0, 320);
  c.fillStyle = 'rgba(20,10,30,0.25)'; c.fillRect(0, by, 960, 8);
  // the front edge with footlights
  const [, fy] = P(0, -120);
  c.fillStyle = vgrad(c, fy, 540, '#7a4a26', '#4a2a16'); c.fillRect(0, fy, 960, 540 - fy);
  c.fillStyle = PAPER; c.fillRect(0, fy - 2, 960, 4);
  for (let x = 30; x < 960; x += 75) {
    glowDot(c, x, fy + 10, 26, '255,230,150', 0.35 + 0.1 * Math.sin(t * 3 + x));
    c.fillStyle = '#ffe9a8'; c.beginPath(); c.arc(x, fy + 10, 5, Math.PI, TAU); c.fill();
  }
}

export function drawCurtains(c, open, t, W = 960, H = 540) {
  const red = '#a8323e', dark = '#7a1e2a';
  const side = 70 + (1 - open) * (W / 2 - 70);
  for (const dir of [-1, 1]) {
    c.save();
    if (dir > 0) { c.translate(W, 0); c.scale(-1, 1); }
    c.fillStyle = vgrad(c, 0, H, red, dark);
    c.beginPath(); c.moveTo(0, 0); c.lineTo(side, 0);
    c.quadraticCurveTo(side - 30 + Math.sin(t * 1.5) * 3, H * 0.45, side - 10, H); c.lineTo(0, H); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(40,0,10,0.35)'; c.lineWidth = 3;
    for (let k = 1; k < 5; k++) { const fx = (side * k) / 5; c.beginPath(); c.moveTo(fx, 0); c.quadraticCurveTo(fx - 12, H * 0.5, fx - 6, H); c.stroke(); }
    c.restore();
  }
  c.fillStyle = red;
  c.beginPath(); c.moveTo(0, 0); c.lineTo(W, 0); c.lineTo(W, 30);
  for (let x = W; x >= 0; x -= 60) c.quadraticCurveTo(x - 30, 58, x - 60, 30);
  c.closePath(); c.fill();
  c.strokeStyle = '#f2c14e'; c.lineWidth = 3;
  c.beginPath(); c.moveTo(W, 30); for (let x = W; x >= 0; x -= 60) c.quadraticCurveTo(x - 30, 58, x - 60, 30); c.stroke();
}

// A soft spotlight from above on whoever's turn it is.
export function drawSpotlight(c, x, y, a = 1) {
  c.save(); c.globalCompositeOperation = 'lighter';
  const g = c.createLinearGradient(x, 0, x, y);
  g.addColorStop(0, `rgba(255,240,200,${0.0})`); g.addColorStop(1, `rgba(255,240,200,${0.12 * a})`);
  c.fillStyle = g;
  c.beginPath(); c.moveTo(x - 30, 0); c.lineTo(x + 30, 0); c.lineTo(x + 80, y); c.lineTo(x - 80, y); c.closePath(); c.fill();
  const r = c.createRadialGradient(x, y, 4, x, y, 90);
  r.addColorStop(0, `rgba(255,240,200,${0.22 * a})`); r.addColorStop(1, 'rgba(255,240,200,0)');
  c.fillStyle = r; c.beginPath(); c.ellipse(x, y, 90, 26, 0, 0, TAU); c.fill();
  c.restore();
}

// The audience in front of the stage, Paper Mario style: they cheer good timing and gasp when you get hit.
export function makeCrowd(n = 13) {
  const kinds = ['folk', 'moth', 'blob', 'acorn', 'candle', 'folk', 'bee', 'blob'];
  return Array.from({ length: n }, (_, i) => ({ x: 40 + i * (880 / (n - 1)) + (hash(i) - 0.5) * 30, kind: kinds[(i * 5) % kinds.length], k: 0.7 + hash(i + 9) * 0.2, ph: hash(i + 3) * 6 }));
}

export function drawAudience(c, t, crowd, cheer = -9, gasp = -9) {
  const ch = Math.max(0, 1 - (t - cheer) / 0.9), gs = Math.max(0, 1 - (t - gasp) / 0.8);
  for (const m of crowd) {
    const jump = ch > 0 ? Math.abs(Math.sin((t - cheer) * 9 + m.ph)) * 22 * ch : 0;
    const bob = Math.sin(t * 2 + m.ph) * 2;
    c.save(); c.translate(m.x, 568 - jump + bob); c.scale(m.k, m.k);
    if (gs > 0) c.rotate(-0.15 * gs * (m.ph > 3 ? 1 : -1));
    c.fillStyle = '#1d1530'; c.strokeStyle = 'rgba(200,180,255,0.45)'; c.lineWidth = 2;
    c.beginPath();
    if (m.kind === 'blob') { c.moveTo(-28, 0); c.bezierCurveTo(-28, -62, 28, -62, 28, 0); }
    else if (m.kind === 'acorn') { c.ellipse(0, -36, 22, 28, 0, 0, TAU); c.moveTo(-24, -58); c.quadraticCurveTo(0, -80, 24, -58); }
    else if (m.kind === 'bee') { c.ellipse(0, -40, 26, 28, 0, 0, TAU); }
    else { c.rect(-18, -40, 36, 40); c.moveTo(22, -62); c.ellipse(0, -62, 22, 20, 0, 0, TAU); }
    c.fill(); c.stroke();
    if (m.kind === 'moth') { c.beginPath(); c.moveTo(-6, -80); c.quadraticCurveTo(-12, -96, -20, -94); c.moveTo(6, -80); c.quadraticCurveTo(12, -96, 20, -94); c.stroke(); }
    if (m.kind === 'candle') flame(c, 0, -84, 0.5, t + m.ph);
    if (m.kind === 'bee') { c.beginPath(); c.ellipse(-18, -66, 10, 14, -0.6, 0, TAU); c.ellipse(18, -66, 10, 14, 0.6, 0, TAU); c.stroke(); }
    if (ch > 0.2) {
      c.strokeStyle = 'rgba(200,180,255,0.6)'; c.lineWidth = 5; c.lineCap = 'round';
      c.beginPath(); c.moveTo(-16, -34); c.lineTo(-28, -58 - jump * 0.3); c.moveTo(16, -34); c.lineTo(28, -58 - jump * 0.3); c.stroke();
    }
    c.restore();
  }
}

// ---------------------------------------------------------------- battle effects
export function drawImpact(c, x, y, k, big = false) {
  const r = (big ? 52 : 38) * (0.6 + k * 0.6);
  c.save(); c.translate(x, y); c.rotate(k * 0.4);
  c.globalAlpha = Math.max(0, 1 - k);
  c.beginPath(); starPath(c, 0, 0, r, r * 0.45, 8, 0);
  c.fillStyle = big ? '#fffaf0' : '#ffe9a8'; c.fill(); c.lineWidth = 3; c.strokeStyle = INK; c.stroke();
  c.strokeStyle = '#fffaf0'; c.lineWidth = 3;
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * TAU + 0.2, r1 = r * 1.15, r2 = r * (1.4 + k * 0.8);
    c.beginPath(); c.moveTo(Math.cos(a) * r1, Math.sin(a) * r1); c.lineTo(Math.cos(a) * r2, Math.sin(a) * r2); c.stroke();
  }
  c.restore();
}

export function drawSpeedLines(c, x, y, dir, a = 1) {
  c.save(); c.globalAlpha = 0.6 * a; c.strokeStyle = '#fffaf0'; c.lineWidth = 3; c.lineCap = 'round';
  for (let i = 0; i < 4; i++) {
    const yy = y - 20 - i * 16 + (i % 2) * 6, len = 30 + (i * 13) % 26;
    c.beginPath(); c.moveTo(x - dir * (24 + i * 4), yy); c.lineTo(x - dir * (24 + i * 4 + len), yy); c.stroke();
  }
  c.restore();
}

export function drawPoof(c, x, y, k) {
  c.save(); c.globalAlpha = Math.max(0, 1 - k);
  for (let i = 0; i < 7; i++) {
    const a = (i / 7) * TAU, d = 10 + k * 46;
    c.fillStyle = '#fffaf0'; c.strokeStyle = 'rgba(43,34,53,0.35)'; c.lineWidth = 2;
    c.beginPath(); c.arc(x + Math.cos(a) * d, y + Math.sin(a) * d * 0.6, 12 + k * 10, 0, TAU); c.fill(); c.stroke();
  }
  c.restore();
}

// ---------------------------------------------------------------- register the new folks
Object.assign(DRAW, {
  candle: drawCandle, bee: drawBee, pincushion: drawPincushion, starfolk: drawStarFolk, bookworm: drawBookworm,
  matchstick: drawMatchstick, sensei: drawMatchstick, sensei2: drawMatchstick, postman: drawPostman, inkdot: drawInkDot,
  cat: drawCat, waxknight: drawWaxKnight, queen: drawQueen, chef: drawChef, carto: drawCarto, hidekid: drawHideKid,
  rocco: drawRocco, gloomknight: drawGloomKnight, hollowarmor: drawHollowArmor, dustbunny: drawDustBunny,
});
