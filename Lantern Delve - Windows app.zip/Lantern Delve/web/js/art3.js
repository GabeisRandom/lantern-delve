// The Paper Plains update: landmarks on the horizon (from almost anywhere you can see the rest of Lumenfold), the
// things you play with out in the world (stickers, crates, bombs, pressure plates, tears in the paper, folks folded
// up and hidden), and the new folks: Peely, Stitch, Mayor Pennywick, the Snippers and the Gloop Golem.
import { DRAW, INK, PAPER, paper, shape, rrect, ell, poly, vgrad, glowDot, flame, eyes, mouth, starPath, shadow } from './art.js';
import { atDepth, box, face, shade, GZ0, GZ1, DECOR_DRAW } from './art2.js';

const TAU = Math.PI * 2;
const hash = n => { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };
// blend a #rrggbb color toward an [r, g, b] (for distance haze)
const mix = (hex, rgb, k) => {
  const n = parseInt(hex.slice(1), 16), f = (v, s) => Math.round(v + (s - v) * k);
  return `rgb(${f((n >> 16) & 255, rgb[0])},${f((n >> 8) & 255, rgb[1])},${f(n & 255, rgb[2])})`;
};
export const CONF = ['#ff6b6b', '#ffd23f', '#5fc8f0', '#8be07a', '#b49cff', '#ff9ab0'];

// ---------------------------------------------------------------- landmarks on the horizon
// The big places of Lumenfold, at their spots on the world map (the same mx/my as AREAS). From wherever you stand
// you look north (up the map): the further away something is, the smaller and hazier it gets.
export const LANDMARKS = [
  { kind: 'tower', mx: 0.5, my: 0.06, size: 1.2 },
  { kind: 'mountain', mx: 0.66, my: 0.2, size: 1.3 },
  { kind: 'castle', mx: 0.3, my: 0.28, size: 1 },
  { kind: 'volcano', mx: 0.9, my: 0.44, size: 1.15 },
  { kind: 'tree', mx: 0.12, my: 0.42, size: 0.8 },
  { kind: 'lantern', mx: 0.5, my: 0.55, size: 0.6 },
  { kind: 'windmill', mx: 0.36, my: 0.6, size: 0.55 },
  { kind: 'shrine', mx: 0.66, my: 0.93, size: 0.75 },
];

export function drawLandmarks(c, here, camX, t, mood = 'day', st = {}) {
  if (!here || here.mx == null) return;
  const sky = mood === 'night' ? [52, 42, 92] : mood === 'dusk' ? [214, 168, 190] : [214, 234, 246];
  const seen = [];
  for (const L of LANDMARKS) {
    const f = here.my - L.my;
    if (f < 0.05) continue;
    const x = 480 + ((L.mx - here.mx) / (f + 0.1)) * 300 - camX * 0.02;
    if (x < -300 || x > 1260) continue;
    seen.push({ L, f, x, k: Math.min(1.5, Math.max(0.42, 0.3 / (f + 0.1))) * L.size });
  }
  seen.sort((a, b) => b.f - a.f);
  for (const { L, f, x, k } of seen) {
    const haze = Math.min(L.kind === 'tower' ? 0.42 : 0.72, 0.22 + f * 0.75);   // Dusk's tower looms, even from far away
    c.save(); c.translate(x, 338); c.scale(k, k);
    LANDMARK_DRAW[L.kind](c, t, hex => mix(hex, sky, haze), mood !== 'day', st);
    c.restore();
  }
}

const LANDMARK_DRAW = {
  // Count Dusk's Tower, crooked and purple, far to the north
  tower(c, t, tint, lit) {
    glowDot(c, 0, -250, 110, '150,80,220', 0.22 + 0.06 * Math.sin(t * 1.5));
    c.fillStyle = tint('#4a3570');
    c.beginPath(); c.moveTo(-30, 0); c.lineTo(-22, -210); c.lineTo(-36, -214); c.lineTo(-4, -300); c.lineTo(6, -286); c.lineTo(36, -214); c.lineTo(22, -210); c.lineTo(30, 0); c.closePath(); c.fill();
    c.fillStyle = tint('#3a2858');
    c.fillRect(24, -150, 24, 150); c.beginPath(); c.moveTo(20, -150); c.lineTo(36, -190); c.lineTo(52, -150); c.closePath(); c.fill();
    c.fillRect(-50, -110, 22, 110); c.beginPath(); c.moveTo(-54, -110); c.lineTo(-39, -142); c.lineTo(-24, -110); c.closePath(); c.fill();
    c.strokeStyle = tint('#3a2858'); c.lineWidth = 3; c.beginPath(); c.moveTo(-4, -300); c.lineTo(-4, -330); c.stroke();
    c.fillStyle = tint('#7b5fc7'); c.beginPath(); c.moveTo(-4, -330); c.lineTo(18 + Math.sin(t * 3) * 2, -324); c.lineTo(-4, -316); c.closePath(); c.fill();
    c.fillStyle = `rgba(210,150,255,${lit ? 0.95 : 0.6})`;
    for (const [wx, wy] of [[-6, -120], [6, -168], [-4, -226], [32, -110], [-42, -80]]) c.fillRect(wx - 3, wy - 6, 6, 10);
  },
  mountain(c, t, tint) {
    c.fillStyle = tint('#8a92b4');
    c.beginPath(); c.moveTo(-210, 0); c.lineTo(-120, -128); c.lineTo(-70, -92); c.lineTo(0, -196); c.lineTo(66, -112); c.lineTo(112, -146); c.lineTo(210, 0); c.closePath(); c.fill();
    c.fillStyle = tint('#737b9e');
    c.beginPath(); c.moveTo(0, -196); c.lineTo(30, -150); c.lineTo(10, -110); c.lineTo(40, -60); c.lineTo(20, 0); c.lineTo(80, 0); c.lineTo(66, -112); c.closePath(); c.fill();
    c.fillStyle = tint('#fbf8ff');
    c.beginPath(); c.moveTo(-30, -150); c.lineTo(0, -196); c.lineTo(32, -148); c.lineTo(14, -156); c.lineTo(2, -142); c.lineTo(-12, -158); c.closePath(); c.fill();
    c.beginPath(); c.moveTo(-138, -102); c.lineTo(-120, -128); c.lineTo(-100, -104); c.closePath(); c.fill();
    c.beginPath(); c.moveTo(94, -122); c.lineTo(112, -146); c.lineTo(130, -120); c.closePath(); c.fill();
  },
  castle(c, t, tint, lit) {
    const wall = tint('#9a94b4'), roof = tint('#5a4e78');
    c.fillStyle = wall; c.fillRect(-90, -90, 180, 90);
    for (let x = -88; x < 90; x += 16) c.fillRect(x, -100, 9, 10);
    for (const [tx, th] of [[-96, 150], [-44, 120], [0, 190], [44, 120], [96, 150]]) {
      c.fillStyle = wall; c.fillRect(tx - 14, -th, 28, th);
      c.fillStyle = roof; c.beginPath(); c.moveTo(tx - 19, -th); c.lineTo(tx, -th - 36); c.lineTo(tx + 19, -th); c.closePath(); c.fill();
    }
    c.fillStyle = roof; c.beginPath(); c.moveTo(-16, 0); c.lineTo(-16, -30); c.arc(0, -30, 16, Math.PI, 0); c.lineTo(16, 0); c.closePath(); c.fill();
    c.strokeStyle = roof; c.lineWidth = 2; c.beginPath(); c.moveTo(0, -226); c.lineTo(0, -250); c.stroke();
    c.fillStyle = tint('#e5534b'); c.beginPath(); c.moveTo(0, -250); c.lineTo(20 + Math.sin(t * 3) * 2, -244); c.lineTo(0, -238); c.closePath(); c.fill();
    if (lit) { c.fillStyle = '#ffd67a'; for (const [wx, wy] of [[-96, -110], [0, -150], [96, -110], [-44, -86], [44, -86]]) c.fillRect(wx - 4, wy - 6, 8, 11); }
  },
  volcano(c, t, tint, lit, st) {
    for (let i = 0; i < 4; i++) {
      const q = (t * 0.12 + i / 4) % 1;
      c.fillStyle = st.calm ? `rgba(255,250,240,${0.35 * (1 - q)})` : `rgba(90,70,90,${0.45 * (1 - q)})`;
      c.beginPath(); c.arc(-10 + Math.sin(q * 5 + i) * 18 + q * 40, -170 - q * 150, 18 + q * 30, 0, TAU); c.fill();
    }
    c.fillStyle = tint('#8a6a6a');
    c.beginPath(); c.moveTo(-190, 0); c.lineTo(-38, -166); c.lineTo(38, -166); c.lineTo(190, 0); c.closePath(); c.fill();
    c.fillStyle = tint('#6e5258');
    c.beginPath(); c.moveTo(38, -166); c.lineTo(190, 0); c.lineTo(90, 0); c.lineTo(30, -120); c.closePath(); c.fill();
    if (!st.calm) {
      glowDot(c, 0, -166, 60, '255,130,60', 0.45);
      c.fillStyle = '#ff8a3d'; c.beginPath(); c.moveTo(-30, -166); c.lineTo(30, -166); c.lineTo(10, -140); c.lineTo(-6, -150); c.lineTo(-20, -132); c.closePath(); c.fill();
    }
  },
  // the Grumbling Grove's great tree
  tree(c, t, tint) {
    c.fillStyle = tint('#7a5232');
    c.beginPath(); c.moveTo(-26, 0); c.quadraticCurveTo(-14, -90, -18, -170); c.lineTo(18, -170); c.quadraticCurveTo(14, -90, 26, 0); c.closePath(); c.fill();
    c.fillStyle = tint('#4f8a52');
    for (const [bx, by, r] of [[-70, -190, 62], [64, -200, 66], [0, -250, 76], [-30, -150, 50], [40, -150, 48]]) { c.beginPath(); c.arc(bx, by, r, 0, TAU); c.fill(); }
    c.fillStyle = tint('#5fa060'); c.beginPath(); c.arc(-14, -268, 40, 0, TAU); c.fill();
  },
  // the Great Lantern in Lumen Town: it glows brighter with every shard you bring back
  lantern(c, t, tint, lit, st) {
    const n = Math.min(5, st.shards || 0);
    glowDot(c, 0, -205, 90, '255,214,120', 0.2 + n * 0.1);
    c.fillStyle = tint('#3b3350'); c.fillRect(-6, -170, 12, 170);
    c.beginPath(); c.moveTo(-40, -170); c.lineTo(40, -170); c.lineTo(28, -180); c.lineTo(-28, -180); c.closePath(); c.fill();
    c.fillStyle = n > 0 ? '#ffd67a' : tint('#8a7aa8'); c.fillRect(-24, -230, 48, 50);
    c.fillStyle = tint('#3b3350'); c.beginPath(); c.moveTo(-32, -230); c.lineTo(0, -262); c.lineTo(32, -230); c.closePath(); c.fill();
  },
  windmill(c, t, tint) {
    c.fillStyle = tint('#e8dcc0'); c.beginPath(); c.moveTo(-30, 0); c.lineTo(-18, -130); c.lineTo(18, -130); c.lineTo(30, 0); c.closePath(); c.fill();
    c.fillStyle = tint('#c45a5a'); c.beginPath(); c.moveTo(-24, -128); c.lineTo(0, -160); c.lineTo(24, -128); c.closePath(); c.fill();
    c.save(); c.translate(0, -132); c.rotate(t * 0.5);
    c.fillStyle = tint('#fffaf0');
    for (let b = 0; b < 4; b++) { c.rotate(Math.PI / 2); c.fillRect(-7, 6, 14, 84); }
    c.restore();
  },
  // the Sticker Shrine, a little paper pagoda
  shrine(c, t, tint) {
    for (let i = 0; i < 3; i++) {
      const w = 120 - i * 30, y = -i * 62;
      c.fillStyle = tint('#fbf3e0'); c.fillRect(-w / 2 + 14, y - 50, w - 28, 50);
      c.fillStyle = tint('#c0392b'); c.beginPath(); c.moveTo(-w / 2 - 14, y - 46); c.quadraticCurveTo(0, y - 64, w / 2 + 14, y - 46); c.lineTo(w / 2 - 6, y - 62); c.lineTo(-w / 2 + 6, y - 62); c.closePath(); c.fill();
    }
    c.strokeStyle = tint('#c0392b'); c.lineWidth = 4; c.beginPath(); c.moveTo(0, -186); c.lineTo(0, -214); c.stroke();
    c.fillStyle = tint('#ffd23f'); c.beginPath(); starPath(c, 0, -222, 12, 5, 5); c.fill();
  },
};

// ---------------------------------------------------------------- stickers
export const STICKER_COL = { bridge: '#ffd9a8', stairs: '#fff0c0', fan: '#c8f0ff', sprout: '#d4f5c4', key: '#fff1a8', sun: '#ffd6a0' };

// A sticker's picture, drawn around (0, 0) about r across.
export function drawStickerIcon(c, kind, r = 20) {
  c.save(); c.scale(r / 20, r / 20);
  c.lineJoin = 'round'; c.lineCap = 'round'; c.lineWidth = 2; c.strokeStyle = INK;
  const fill = col => { c.fillStyle = col; c.fill(); c.stroke(); };
  if (kind === 'bridge') {
    c.beginPath(); c.arc(0, 16, 20, Math.PI * 1.15, Math.PI * 1.85); c.arc(0, 16, 11, Math.PI * 1.85, Math.PI * 1.15, true); c.closePath(); fill('#c58b55');
    c.beginPath(); for (const a of [1.3, 1.5, 1.7]) { c.moveTo(Math.cos(Math.PI * a) * 11, 16 + Math.sin(Math.PI * a) * 11); c.lineTo(Math.cos(Math.PI * a) * 20, 16 + Math.sin(Math.PI * a) * 20); } c.stroke();
  } else if (kind === 'stairs') {
    c.beginPath(); c.moveTo(-15, 12); c.lineTo(-15, 4); c.lineTo(-5, 4); c.lineTo(-5, -4); c.lineTo(5, -4); c.lineTo(5, -12); c.lineTo(15, -12); c.lineTo(15, 12); c.closePath(); fill('#e2ad72');
  } else if (kind === 'fan') {
    for (let b = 0; b < 3; b++) { c.save(); c.rotate((b * TAU) / 3); c.beginPath(); c.ellipse(0, -8, 6, 10, 0.4, 0, TAU); fill(['#5fc8f0', '#9fe6ff', '#4aa7c9'][b]); c.restore(); }
    c.beginPath(); c.arc(0, 0, 4, 0, TAU); fill('#fffaf0');
  } else if (kind === 'sprout') {
    c.beginPath(); c.moveTo(0, 14); c.lineTo(0, -4); c.stroke();
    c.beginPath(); c.ellipse(-7, -8, 8, 4.5, -0.6, 0, TAU); fill('#7cc46a');
    c.beginPath(); c.ellipse(7, -10, 8, 4.5, 0.6, 0, TAU); fill('#5fae5c');
  } else if (kind === 'key') {
    c.beginPath(); c.arc(-8, 0, 7, 0, TAU); c.moveTo(-1, 0); c.lineTo(14, 0); c.moveTo(9, 0); c.lineTo(9, 6); c.moveTo(14, 0); c.lineTo(14, 6);
    c.lineWidth = 5; c.strokeStyle = INK; c.stroke(); c.lineWidth = 2.6; c.strokeStyle = '#ffd23f'; c.stroke();
  } else if (kind === 'sun') {
    c.beginPath(); for (let i = 0; i < 8; i++) { const a = (i * TAU) / 8; c.moveTo(Math.cos(a) * 11, Math.sin(a) * 11); c.lineTo(Math.cos(a) * 17, Math.sin(a) * 17); } c.lineWidth = 3; c.strokeStyle = '#ff8a3d'; c.stroke();
    c.lineWidth = 2; c.strokeStyle = INK; c.beginPath(); c.arc(0, 0, 9, 0, TAU); fill('#ffd23f');
  }
  c.restore();
}

// A sticker stuck to something in the world, with one corner peeling up (press E to peel it off).
export function drawSticker(c, x, y, o = {}) {
  const t = o.t || 0, kind = o.kind || 'fan', s = o.r || 20;
  c.save(); c.translate(x, y - s - 8 + (o.still ? 0 : Math.sin(t * 2 + x) * 2));
  c.rotate(o.still ? 0 : Math.sin(t * 1.3 + x) * 0.08);
  if (o.glint !== false) glowDot(c, 0, 0, s * 2.2, '255,250,220', 0.35 + 0.1 * Math.sin(t * 3));
  const S = s + 5, L = o.peel === false ? 0 : 9 + Math.sin(t * 3) * 3;
  c.lineJoin = 'round';
  c.beginPath(); c.moveTo(-S + 8, -S); c.lineTo(S - L - (L ? 0 : 8), -S);
  if (L) c.lineTo(S, -S + L); else c.quadraticCurveTo(S, -S, S, -S + 8);
  c.lineTo(S, S - 8); c.quadraticCurveTo(S, S, S - 8, S); c.lineTo(-S + 8, S); c.quadraticCurveTo(-S, S, -S, S - 8); c.lineTo(-S, -S + 8); c.quadraticCurveTo(-S, -S, -S + 8, -S); c.closePath();
  c.fillStyle = PAPER; c.fill(); c.strokeStyle = INK; c.lineWidth = 2; c.stroke();
  c.fillStyle = STICKER_COL[kind] || '#fffaf0'; c.beginPath(); rrect(-s, -s, 2 * s, 2 * s, 6)(c); c.fill();
  drawStickerIcon(c, kind, s * 0.85);
  c.fillStyle = 'rgba(255,255,255,0.45)'; c.beginPath(); c.moveTo(-s + 3, -s + 10); c.lineTo(-s + 10, -s + 3); c.lineTo(-s + 15, -s + 3); c.lineTo(-s + 3, -s + 15); c.closePath(); c.fill();
  if (L) {
    c.fillStyle = 'rgba(20,10,30,0.2)'; c.beginPath(); c.moveTo(S - L, -S + 2); c.lineTo(S - 2, -S + L); c.lineTo(S - L - 2, -S + L + 3); c.closePath(); c.fill();
    c.fillStyle = '#ece2cc'; c.strokeStyle = INK; c.lineWidth = 1.5;
    c.beginPath(); c.moveTo(S - L, -S); c.lineTo(S, -S + L); c.lineTo(S - L, -S + L); c.closePath(); c.fill(); c.stroke();
  }
  c.restore();
}

// A sticker-shaped outline in the world: stick the right sticker here and something happens.
export function drawSlot(c, x, y, o = {}) {
  const t = o.t || 0, s = o.r || 24;
  c.save(); c.translate(x, y);
  shadow(c, 0, 0, 14, 0.15);
  c.translate(0, -s - 18 + Math.sin(t * 2) * 1.5);
  glowDot(c, 0, 0, s * 2.2, '255,255,255', 0.3 + 0.12 * Math.sin(t * 3));
  c.beginPath(); rrect(-s - 5, -s - 5, 2 * s + 10, 2 * s + 10, 10)(c);
  c.fillStyle = 'rgba(255,250,240,0.4)'; c.fill();
  c.setLineDash([7, 6]); c.lineDashOffset = -t * 14; c.strokeStyle = INK; c.lineWidth = 3; c.stroke(); c.setLineDash([]);
  c.globalAlpha = 0.4; drawStickerIcon(c, o.kind, s * 0.85); c.globalAlpha = 1;
  c.restore();
}

// ---------------------------------------------------------------- what stickers turn into
// A big paper fan on a stand: it blows fog away and powers updrafts.
export function drawFan(c, x, y, o = {}) {
  const t = o.t || 0, dir = o.dir || 1;
  c.save(); c.translate(x, y);
  shadow(c, 0, 0, 22);
  paper(c, p => { shape(c, p, rrect(-4, -62, 8, 62, 3), '#8a84a0', 2); shape(c, p, rrect(-20, -7, 40, 9, 3), '#6e6884', 2); });
  c.save(); c.translate(0, -80);
  paper(c, p => shape(c, p, ell(0, 0, 30, 30), '#e8f6ff', 2));
  c.rotate(t * 14);
  for (let b = 0; b < 4; b++) { c.rotate(Math.PI / 2); paper(c, p => shape(c, p, ell(0, -14, 8, 14), ['#9fe6ff', '#ffe066', '#ff9ab0', '#b49cff'][b], 1.6)); }
  c.restore();
  c.fillStyle = INK; c.beginPath(); c.arc(0, -80, 3.5, 0, TAU); c.fill();
  c.strokeStyle = 'rgba(255,255,255,0.85)'; c.lineWidth = 3; c.lineCap = 'round';
  for (let i = 0; i < 3; i++) {
    const q = (t * 1.8 + i / 3) % 1;
    c.globalAlpha = 1 - q;
    c.beginPath(); c.moveTo(dir * (38 + q * 130), -94 + i * 14); c.lineTo(dir * (62 + q * 130), -94 + i * 14 + Math.sin(q * 6) * 3); c.stroke();
  }
  c.globalAlpha = 1;
  c.restore();
}

// A little paper sun that hangs in the air and lights up a dark room.
export function drawSunSticker(c, x, y, t = 0) {
  const by = y - 150 + Math.sin(t * 1.5) * 4;
  glowDot(c, x, by, 140, '255,220,140', 0.4);
  c.save(); c.translate(x, by); c.rotate(t * 0.3);
  c.strokeStyle = '#ff8a3d'; c.lineWidth = 6; c.lineCap = 'round';
  c.beginPath(); for (let i = 0; i < 10; i++) { const a = (i * TAU) / 10; c.moveTo(Math.cos(a) * 30, Math.sin(a) * 30); c.lineTo(Math.cos(a) * 44, Math.sin(a) * 44); } c.stroke();
  c.restore();
  paper(c, p => shape(c, p, ell(x, by, 26, 26), vgrad(c, by - 26, by + 26, '#fff3a8', '#ffc83a')));
  eyes(c, x - 8, x + 8, by - 3, 7, 'happy', t);
  mouth(c, x, by + 9, 6, 'happy');
}

// Plank bridge laid across a gap (x..x+w at height y, reaching z0..z1 into the distance).
export function drawBridge3d(c, V, x, y, w, z0, z1) {
  z0 = Math.max(z0, V.zf); z1 = Math.min(z1, V.zb);
  const n = Math.max(3, Math.round(w / 34)), pw = w / n;
  const order = [...Array(n).keys()].sort((a, b) => Math.abs(x + (b + 0.5) * pw - V.cx) - Math.abs(x + (a + 0.5) * pw - V.cx));
  for (const i of order) box(c, V, x + i * pw + 2, y, pw - 4, 10, z0, z1, { top: i % 2 ? '#d9a066' : '#e2ad72', front: ['#b07a45', '#8a5a32'], side: '#7a4f2c' });
  const P = (xx, yy, z) => [V.x(xx, z), V.y(yy, z)];
  c.strokeStyle = '#8a6a4a'; c.lineWidth = 3; c.lineCap = 'round';
  for (const z of [z1 - 4, z0 + 4]) {
    for (const px of [x, x + w]) { c.beginPath(); c.moveTo(...P(px, y, z)); c.lineTo(...P(px, y - 34, z)); c.stroke(); }
    c.beginPath(); c.moveTo(...P(x, y - 30, z)); c.quadraticCurveTo(...P(x + w / 2, y - 10, z), ...P(x + w, y - 30, z)); c.stroke();
  }
}

// A giant flower grown from a Sprout Sticker: its pad is a platform.
export function drawFlower3d(c, V, x, y, w, z0, z1, floorY, t = 0) {
  const zc = (z0 + z1) / 2, cx = x + w / 2, h = floorY - y;
  atDepth(c, V, cx, floorY, zc, () => {
    c.rotate(Math.sin(t * 1.2) * 0.01);
    paper(c, p => {
      shape(c, p, rrect(-7, -h, 14, h, 6), '#5fae5c', 2);
      shape(c, p, ell(-20, -h * 0.4, 20, 8, -0.5), '#6cc068', 2);
      shape(c, p, ell(20, -h * 0.65, 20, 8, 0.5), '#6cc068', 2);
    });
  });
  box(c, V, x, y, w, 12, z0, z1, { top: '#ffb8cc', front: ['#ff8fb0', '#e5638a'], side: '#d4567c' });
  const k = V.s(z0);
  for (let i = 0; i < 5; i++) {
    const px = V.x(x + (w * (i + 0.5)) / 5, z0), py = V.y(y + 12, z0);
    c.fillStyle = i % 2 ? '#ffa8c0' : '#ff8fb0'; c.strokeStyle = INK; c.lineWidth = 1.6;
    c.beginPath(); c.ellipse(px, py + 4 * k, 10 * k, 7 * k, 0, 0, TAU); c.fill(); c.stroke();
  }
  const fx = V.x(cx, zc), fy = V.y(y, zc), kc = V.s(zc);
  c.fillStyle = '#ffe066'; c.strokeStyle = INK; c.lineWidth = 1.5;
  c.beginPath(); c.ellipse(fx, fy, w * 0.16 * kc, w * 0.06 * kc, 0, 0, TAU); c.fill(); c.stroke();
}

// Pop-up paper stairs from a Stairs Sticker. steps: [{ x, top, w, base, z0, z1 }], drawn farthest from the camera first.
export function drawPopStairs(c, V, steps) {
  const col = { top: '#fffaf0', front: ['#f4ecd8', '#d9cdb4'], side: '#c9bc9e' };
  for (const s of [...steps].sort((a, b) => Math.abs(b.x + b.w / 2 - V.cx) - Math.abs(a.x + a.w / 2 - V.cx))) {
    box(c, V, s.x, s.top, s.w, s.base - s.top, s.z0, s.z1, col);
    const ax = V.x(s.x + 3, s.z0), bx = V.x(s.x + s.w - 3, s.z0), yy = V.y(s.top + 5, s.z0);
    c.strokeStyle = 'rgba(160,140,110,0.6)'; c.lineWidth = 1.4; c.beginPath(); c.moveTo(ax, yy); c.lineTo(bx, yy); c.stroke();
  }
}

// ---------------------------------------------------------------- crates, plates, bombs
// A wooden crate (a cube s wide) standing on the floor at (x, y), centered at depth z. Push it around!
export function drawCrate3d(c, V, x, y, z, o = {}) {
  const s = o.s || 56, x0 = x - s / 2, y0 = y - s, z0 = z - s / 2;
  box(c, V, x0, y0, s, s, z0, z + s / 2, { top: '#e0b47a', front: ['#c88e52', '#a06a3a'], side: '#8e5c32' });
  const P = (xx, yy) => [V.x(xx, z0), V.y(yy, z0)], k = V.s(z0);
  const line = (a, b) => { c.beginPath(); c.moveTo(...P(...a)); c.lineTo(...P(...b)); c.stroke(); };
  c.lineCap = 'round';
  c.strokeStyle = 'rgba(110,66,36,0.6)'; c.lineWidth = 2 * k;
  line([x0 + 4, y0 + 6], [x0 + s - 4, y0 + 6]); line([x0 + 4, y0 + s - 6], [x0 + s - 4, y0 + s - 6]);
  c.strokeStyle = '#6e4224'; c.lineWidth = 3.2 * k;
  line([x0 + 7, y0 + 8], [x0 + s - 7, y0 + s - 8]); line([x0 + s - 7, y0 + 8], [x0 + 7, y0 + s - 8]);
  if (o.glow) glowDot(c, ...P(x, y0 + s / 2), s * 1.1, '255,230,120', 0.3);
}

// A pressure plate on the floor. Blue ones only stay down while something heavy sits on them; gold ones stay down.
export function drawPlate3d(c, V, x, y, z, down, o = {}) {
  const w = o.w || 60, d = o.d || 50, h = down ? 2 : 7;
  const col = o.latch ? ['#ffe066', '#d9a82a'] : ['#9fe6ff', '#4aa7c9'];
  box(c, V, x - w / 2 - 6, y - 2, w + 12, 2, z - d / 2 - 6, z + d / 2 + 6, { top: '#8a7a6a', front: '#6e5e50', side: '#5e4e42' });
  box(c, V, x - w / 2, y - h, w, h, z - d / 2, z + d / 2, { top: down ? shade(col[0], -0.12) : col[0], front: col[1], side: shade(col[1], -0.2) });
  const cx = V.x(x, z), cy = V.y(y - h, z), k = V.s(z);
  c.strokeStyle = 'rgba(43,34,53,0.35)'; c.lineWidth = 2;
  c.beginPath(); c.ellipse(cx, cy, w * 0.22 * k, d * 0.11 * k, 0, 0, TAU); c.stroke();
  if (down) glowDot(c, cx, cy, 44, o.latch ? '255,230,120' : '160,235,255', 0.4);
}

export function drawBomb(c, x, y, o = {}) {
  const t = o.t || 0, fuse = o.fuse ?? 99, k = o.scale || 1;
  const flash = fuse < 1.6 && Math.floor(t * (fuse < 0.6 ? 16 : 8)) % 2 === 0;
  c.save(); c.translate(x, y); c.scale(k, k);
  if (o.shadow !== false) shadow(c, 0, 0, 14);
  paper(c, p => {
    shape(c, p, ell(0, -16, 16, 16), flash ? '#ff6b6b' : vgrad(c, -32, 0, '#5a5470', '#2b2235'));
    shape(c, p, rrect(-6, -36, 12, 6, 2), '#8a84a0', 1.8);
    shape(c, p, ell(-8, -38, 7, 3.5, -0.4), '#5fae5c', 1.4);
  });
  c.fillStyle = 'rgba(255,255,255,0.35)'; c.beginPath(); c.ellipse(-6, -22, 4, 6, -0.5, 0, TAU); c.fill();
  c.strokeStyle = '#c8a26a'; c.lineWidth = 2.5; c.lineCap = 'round';
  c.beginPath(); c.moveTo(0, -36); c.quadraticCurveTo(6, -44, 2, -50); c.stroke();
  if (fuse < 99) {
    glowDot(c, 2, -51, 14, '255,200,90', 0.9);
    c.fillStyle = '#fff6c8'; c.beginPath(); starPath(c, 2, -51, 5 + Math.sin(t * 30) * 1.5, 2, 4, t * 8); c.fill();
  }
  c.restore();
}

// A bomb plant: pick the round bomb berry on top (it grows back in a few seconds).
export function drawBombPlant(c, x, y, o = {}) {
  const t = o.t || 0, ripe = o.ripe ?? 1;
  c.save(); c.translate(x, y);
  shadow(c, 0, 0, 22);
  c.rotate(Math.sin(t * 1.6 + x) * 0.05);
  paper(c, p => {
    shape(c, p, ell(-16, -8, 16, 7, -0.4), '#5fae5c', 2);
    shape(c, p, ell(16, -8, 16, 7, 0.4), '#4f9a52', 2);
    shape(c, p, rrect(-2.5, -32, 5, 26, 2), '#4f9a52', 1.6);
    shape(c, p, ell(-10, -24, 10, 5, -0.6), '#6cc068', 1.6);
  });
  if (ripe >= 1) drawBomb(c, 0, -28, { t, shadow: false, scale: 0.8 });
  else if (ripe > 0.05) paper(c, p => shape(c, p, ell(0, -28 - ripe * 10, 4 + ripe * 9, 4 + ripe * 9), '#5a5470', 1.6));
  c.restore();
}

export function drawBoom(c, x, y, k) {
  const r = 30 + k * 110;
  c.save(); c.globalAlpha = Math.max(0, 1 - k);
  glowDot(c, x, y, r * 1.5, '255,200,90', 0.8);
  c.fillStyle = '#fff6c8'; c.beginPath(); starPath(c, x, y, r, r * 0.55, 10, k * 2); c.fill();
  c.fillStyle = '#ff8a3d'; c.beginPath(); starPath(c, x, y, r * 0.7, r * 0.35, 10, -k * 2); c.fill();
  c.restore();
}

// ---------------------------------------------------------------- barriers
// Gloom fog: a thick purple cloud bank that fills the floor from front to back. A fan blows it away.
export function drawFog3d(c, V, x, y, w, h, t = 0, z0 = GZ0 + 10, z1 = GZ1 - 10) {
  const n = Math.max(4, Math.round(w / 60));   // wide fog banks get more puffs
  for (let z = z1; z >= z0; z -= 38) {
    if (z - V.camZ < -620) break;   // (puffs just behind the camera still billow up into the bottom of the view)
    for (let i = 0; i < n; i++) {
      const hh = hash(x * 0.1 + z * 0.37 + i * 7.1);
      const px = x + w * (0.12 + hh * 0.76) + Math.sin(t * 0.8 + i + z) * 8, py = y - h * (0.12 + (i % 4) * 0.24);
      const r = 34 + hh * 28;
      atDepth(c, V, px, py, z, () => {
        c.fillStyle = i % 2 ? 'rgba(150,132,190,0.9)' : 'rgba(190,178,220,0.9)';
        c.beginPath(); c.arc(0, 0, r, 0, TAU); c.fill();
        c.fillStyle = 'rgba(255,255,255,0.3)'; c.beginPath(); c.arc(-r * 0.3, -r * 0.3, r * 0.4, 0, TAU); c.fill();
        if (i === 1 && hh > 0.7 && Math.sin(t * 0.9 + z) > 0.2) {   // something blinks in there...
          c.fillStyle = '#ffe9a8'; c.beginPath(); c.ellipse(-7, 0, 3, 4, 0, 0, TAU); c.ellipse(7, 0, 3, 4, 0, 0, TAU); c.fill();
        }
      });
    }
  }
}

// Boards nailed over a cave mouth or a nook, drawn around (0, 0) at the bottom. A bomb clears them.
export function drawBoards(c, w = 90, h = 120) {
  paper(c, p => {
    shape(c, p, rrect(-w / 2 + 4, -h, 12, h, 3), '#9a6a40', 2);
    shape(c, p, rrect(w / 2 - 16, -h, 12, h, 3), '#9a6a40', 2);
    for (let i = 0; i < 4; i++) shape(c, p, rrect(-w / 2 - 6, -h + 10 + (i * (h - 30)) / 3, w + 12, 18, 3), i % 2 ? '#c49060' : '#b07a45', 2);
  });
  c.fillStyle = '#5a5470';
  for (let i = 0; i < 4; i++) { const y = -h + 19 + (i * (h - 30)) / 3; for (const x of [-w / 2 + 2, w / 2 - 2]) { c.beginPath(); c.arc(x, y, 2.2, 0, TAU); c.fill(); } }
  drawBombTag(c, 0, -h / 2);
}

// A cracked rock wall across the whole floor, too thick for a hammer. A bomb blasts it.
export function drawRockWall3d(c, V, x, y, w, h, z0 = GZ0, z1 = V.zb) {
  box(c, V, x, y, w, h, z0, z1, { top: '#b9a48a', front: ['#a08a70', '#6e5c48'], side: '#7a6650' });
  if (z0 - V.camZ < -500) return;
  const X = xx => V.x(xx, z0), Y = yy => V.y(yy, z0);
  c.strokeStyle = 'rgba(43,34,53,0.5)'; c.lineWidth = 2.4;
  c.beginPath(); c.moveTo(X(x + w * 0.3), Y(y + 4)); c.lineTo(X(x + w * 0.5), Y(y + h * 0.35)); c.lineTo(X(x + w * 0.35), Y(y + h * 0.6)); c.lineTo(X(x + w * 0.6), Y(y + h - 4));
  c.moveTo(X(x + w * 0.5), Y(y + h * 0.35)); c.lineTo(X(x + w * 0.8), Y(y + h * 0.45)); c.stroke();
  atDepth(c, V, x + w / 2, y + h * 0.5, z0, () => drawBombTag(c, 0, 0));
}

function drawBombTag(c, x, y) {
  c.save(); c.translate(x, y); c.rotate(-0.08);
  c.fillStyle = PAPER; c.strokeStyle = INK; c.lineWidth = 2;
  c.beginPath(); rrect(-16, -14, 32, 28, 6)(c); c.fill(); c.stroke();
  drawBomb(c, 0, 9, { shadow: false, scale: 0.42 });
  c.restore();
}

// Rising wind from a fan: stand in it and float up.
export function drawUpdraft(c, V, x, w, zc, top, floorY, t) {
  atDepth(c, V, x + w / 2, floorY, zc, () => {
    const h = floorY - top;
    c.fillStyle = vgrad(c, -h, 0, 'rgba(200,240,255,0)', 'rgba(200,240,255,0.28)'); c.fillRect(-w / 2, -h, w, h);
    c.strokeStyle = 'rgba(255,255,255,0.75)'; c.lineWidth = 3; c.lineCap = 'round';
    for (let i = 0; i < 8; i++) {
      const q = (t * 0.9 + hash(i)) % 1, px = (hash(i + 3) - 0.5) * w * 0.8;
      c.globalAlpha = Math.sin(q * Math.PI);
      c.beginPath(); c.moveTo(px, -q * h); c.lineTo(px + Math.sin(q * 8 + i) * 4, -q * h - 28); c.stroke();
    }
    c.globalAlpha = 1;
  });
}

// Iron bars across an opening, with a little dial for each plate that has to be pressed. Drawn around (0, 0).
export function drawBars(c, w = 80, h = 150, lit = 0, total = 3) {
  paper(c, p => {
    shape(c, p, rrect(-w / 2 - 8, -h - 12, w + 16, 16, 4), '#5a5470');
    shape(c, p, rrect(-w / 2 - 8, -10, w + 16, 10, 3), '#5a5470');
  });
  c.lineCap = 'round';
  for (let bx = -w / 2 + 8; bx <= w / 2 - 8; bx += 16) {
    c.strokeStyle = INK; c.lineWidth = 7; c.beginPath(); c.moveTo(bx, -h); c.lineTo(bx, -8); c.stroke();
    c.strokeStyle = '#9a93ad'; c.lineWidth = 3.5; c.beginPath(); c.moveTo(bx, -h); c.lineTo(bx, -8); c.stroke();
  }
  for (let i = 0; i < total; i++) {
    const dx = (i - (total - 1) / 2) * 18;
    c.fillStyle = i < lit ? '#ffe066' : '#3b3350'; c.strokeStyle = INK; c.lineWidth = 1.5;
    c.beginPath(); c.arc(dx, -h - 4, 5, 0, TAU); c.fill(); c.stroke();
  }
}

// Other things raised ground can be made of (tr.mat): old stone walls, bare rock, sand dunes, snow.
const TERRAIN_MAT = {
  stone: { top: '#c9c3cf', front: ['#aaa3b4', '#77708a'], side: '#676078', lip: null },
  rock: { top: '#bdb7ab', front: ['#a49e94', '#6f6a62'], side: '#7d776e' },
  sand: { top: '#f6e2a8', front: ['#d9b77a', '#a8854a'], side: '#b8955c', lip: null },
  snow: { top: '#f4f6ff', front: ['#c9cfe0', '#8d93ab'], side: '#9aa0b8', lip: '#ffffff' },
  stump: { top: '#e2b98a', front: ['#9a6a45', '#6e4529'], side: '#7a4f30', lip: '#7ccf5e' },
};

// A raised piece of ground: a hill, a ledge, a cliff or a little island. M is the room's ground material.
export function drawTerrain3d(c, V, tr, room) {
  const M = { ...room, ...(TERRAIN_MAT[tr.mat] || {}) }, base = tr.base ?? 450;
  box(c, V, tr.x0, tr.y, tr.x1 - tr.x0, base - tr.y, tr.z0, tr.z1, { top: tr.top || M.top, front: M.front, side: M.side });
  if (tr.z0 < V.camZ - 650) return;
  const X = xx => V.x(xx, tr.z0), Y = yy => V.y(yy, tr.z0), k = V.s(tr.z0);
  const ax = X(tr.x0), bx = X(tr.x1), ay = Y(tr.y), by = Y(base);
  // layers of paper down the cliff face, then a grassy lip along the top
  c.strokeStyle = 'rgba(43,34,53,0.18)'; c.lineWidth = 1.5;
  for (let yy = tr.y + 34; yy < base - 6; yy += 34) { c.beginPath(); c.moveTo(ax + 3, Y(yy)); c.lineTo(bx - 3, Y(yy)); c.stroke(); }
  if (M.lip && !tr.bare) {
    c.fillStyle = M.lip; c.beginPath(); c.moveTo(ax, ay + 10 * k);
    for (let px = ax; px < bx - 1; px += 15 * k) c.quadraticCurveTo(px + 7.5 * k, ay + 19 * k, Math.min(px + 15 * k, bx), ay + 10 * k);
    c.lineTo(bx, ay); c.lineTo(ax, ay); c.closePath(); c.fill();
  }
  c.fillStyle = 'rgba(255,250,240,0.5)'; c.fillRect(ax, ay - 1, bx - ax, 2);
  void by;
}

// A dirt road across a field, from (x0, z0) to (x1, z1), w wide.
export function drawRoad(c, V, seg, y = 450, col = 'rgba(214,180,120,0.72)') {
  let [x0, z0, x1, z1, w = 90] = seg;
  const near = V.camZ - 380;
  if (z0 < near && z1 < near) return;
  if (z0 < near) { const k = (near - z0) / (z1 - z0); x0 += (x1 - x0) * k; z0 = near; }
  if (z1 < near) { const k = (near - z1) / (z0 - z1); x1 += (x0 - x1) * k; z1 = near; }
  const len = Math.hypot(x1 - x0, z1 - z0) || 1, nx = (-(z1 - z0) / len) * (w / 2), nz = ((x1 - x0) / len) * (w / 2);
  const P = (xx, zz) => [V.x(xx, zz), V.y(y, zz)];
  face(c, [P(x0 + nx, z0 + nz), P(x1 + nx, z1 + nz), P(x1 - nx, z1 - nz), P(x0 - nx, z0 - nz)], col, 0);
  for (const [xx, zz] of [[x0, z0], [x1, z1]]) {
    const [sx, sy] = P(xx, zz), k = V.s(zz);
    c.fillStyle = col; c.beginPath(); c.ellipse(sx, sy, (w / 2) * k, (w / 2) * k * 0.32, 0, 0, TAU); c.fill();
  }
  c.fillStyle = 'rgba(120,80,40,0.22)';
  const n = Math.floor(len / 60);
  for (let i = 1; i < n; i++) {
    const q = i / n, xx = x0 + (x1 - x0) * q + Math.sin(i * 2.3) * w * 0.2, zz = z0 + (z1 - z0) * q;
    if (zz - V.camZ > 1600) continue;
    const [sx, sy] = P(xx, zz), k = V.s(zz);
    c.beginPath(); c.ellipse(sx, sy, 6 * k, 2.2 * k, 0, 0, TAU); c.fill();
  }
}

// a red shrine gate for the Sticker Shrine's grounds (scenery)
DECOR_DRAW.torii = c => {
  paper(c, p => {
    shape(c, p, rrect(-52, -150, 14, 150, 3), '#c0392b');
    shape(c, p, rrect(38, -150, 14, 150, 3), '#c0392b');
    shape(c, p, rrect(-62, -128, 124, 12, 3), '#c0392b');
    shape(c, p, cc => { cc.moveTo(-80, -150); cc.quadraticCurveTo(0, -162, 80, -150); cc.lineTo(74, -168); cc.quadraticCurveTo(0, -178, -74, -168); cc.closePath(); }, '#2b2235');
  });
};

// ---------------------------------------------------------------- town scenery (Lumen Town's back streets)
// a big stone fountain for a square, splashing away
DECOR_DRAW.fountain = (c, t) => {
  paper(c, p => {
    shape(c, p, rrect(-96, -46, 192, 46, 10), vgrad(c, -46, 0, '#d6d0e0', '#9a93ad'), 2);
    shape(c, p, ell(0, -46, 92, 12), '#6fb8e6', 2);
    shape(c, p, rrect(-12, -118, 24, 72, 4), vgrad(c, -118, -46, '#d6d0e0', '#a8a1b8'), 2);
    shape(c, p, cc => { cc.moveTo(-46, -118); cc.quadraticCurveTo(0, -100, 46, -118); cc.lineTo(34, -124); cc.lineTo(-34, -124); cc.closePath(); }, '#c8c2d4', 2);
  });
  // water arcing out of the top bowl into the basin
  c.lineCap = 'round';
  for (let i = 0; i < 4; i++) {
    const side = i % 2 ? 1 : -1, reach = 34 + (i > 1 ? 30 : 0), wob = Math.sin(t * 5 + i) * 3;
    c.strokeStyle = 'rgba(159,230,255,0.75)'; c.lineWidth = 4;
    c.beginPath(); c.moveTo(side * 20, -122); c.quadraticCurveTo(side * (reach * 0.7), -150 + wob, side * reach, -52); c.stroke();
  }
  c.fillStyle = 'rgba(255,255,255,0.7)';
  for (let i = 0; i < 6; i++) { const a = t * 3 + i * 1.7, r = 3 + (i % 3); c.beginPath(); c.arc(Math.sin(a) * 70, -50 - Math.abs(Math.cos(a * 1.3)) * 8, r, 0, TAU); c.fill(); }
};
// a market stall with a striped awning
DECOR_DRAW.stall = (c, t, x) => {
  const cols = [['#e5534b', '#fffaf0'], ['#4f72bf', '#fffaf0'], ['#5fae5c', '#fff3c4'], ['#f2b43a', '#fffaf0']][Math.floor(hash(x) * 4)];
  paper(c, p => {
    shape(c, p, rrect(-50, -112, 6, 112, 2), '#8a5a3c', 2);
    shape(c, p, rrect(44, -112, 6, 112, 2), '#8a5a3c', 2);
    shape(c, p, rrect(-56, -50, 112, 50, 4), vgrad(c, -50, 0, '#c9925c', '#8a5a3c'), 2);
  });
  for (let i = 0; i < 6; i++) {
    c.fillStyle = cols[i % 2]; c.strokeStyle = INK; c.lineWidth = 2;
    c.beginPath(); c.moveTo(-62 + i * 21, -126); c.lineTo(-41 + i * 21, -126); c.lineTo(-41 + i * 21, -104); c.quadraticCurveTo(-51.5 + i * 21, -96, -62 + i * 21, -104); c.closePath(); c.fill(); c.stroke();
  }
  // whatever they're selling today
  for (let i = 0; i < 5; i++) { c.fillStyle = CONF[(i + Math.floor(hash(x + 3) * 6)) % CONF.length]; c.beginPath(); c.arc(-36 + i * 18, -56, 7, 0, TAU); c.fill(); c.strokeStyle = INK; c.lineWidth = 1.5; c.stroke(); }
  void t;
};
// the town's statue of the First Lamplighter, holding up her candle
DECOR_DRAW.statue = (c, t) => {
  glowDot(c, 0, -206, 36, '255,210,120', 0.25 + 0.08 * Math.sin(t * 2));
  paper(c, p => {
    shape(c, p, rrect(-36, -60, 72, 60, 4), vgrad(c, -60, 0, '#c8c2d4', '#8a84a0'), 2);
    shape(c, p, rrect(-44, -70, 88, 14, 3), '#d6d0e0', 2);
    shape(c, p, cc => { cc.moveTo(-22, -70); cc.quadraticCurveTo(-26, -130, -12, -150); cc.lineTo(12, -150); cc.quadraticCurveTo(26, -130, 22, -70); cc.closePath(); }, '#b8b2c6', 2);
    shape(c, p, ell(0, -164, 16, 16), '#c8c2d4', 2);
    shape(c, p, rrect(14, -196, 8, 56, 3), '#b8b2c6', 2);
  });
  flame(c, 18, -197, 0.9, t);
};

// A square of paving stones on the floor: x0..x1 across, z0..z1 deep.
export function drawPlaza(c, V, sq, y = 450) {
  let [x0, x1, z0, z1, col = '#c9c3cf'] = sq;
  z0 = Math.max(z0, V.camZ - 380);
  if (z1 <= z0) return;
  const P = (xx, zz) => [V.x(xx, zz), V.y(y, zz)];
  face(c, [P(x0, z1), P(x1, z1), P(x1, z0), P(x0, z0)], col, 0);
  // the joins between the stones (only up close, where you'd see them)
  c.strokeStyle = 'rgba(43,34,53,0.14)'; c.lineWidth = 1.2;
  const zn = Math.min(z1, V.camZ + 1400);
  for (let zz = Math.ceil(z0 / 60) * 60; zz < zn; zz += 60) { const [ax, ay] = P(x0, zz), [bx] = P(x1, zz); c.beginPath(); c.moveTo(ax, ay); c.lineTo(bx, ay); c.stroke(); }
  for (let xx = Math.ceil(x0 / 80) * 80; xx < x1; xx += 80) { const [ax, ay] = P(xx, z0), [bx, by] = P(xx, zn); c.beginPath(); c.moveTo(ax, ay); c.lineTo(bx, by); c.stroke(); }
  c.strokeStyle = 'rgba(43,34,53,0.3)'; c.lineWidth = 2;
  c.beginPath(); for (const [i, [xx, zz]] of [[x0, z0], [x1, z0], [x1, z1], [x0, z1], [x0, z0]].entries()) { const [sx, sy] = P(xx, zz); if (i) c.lineTo(sx, sy); else c.moveTo(sx, sy); } c.stroke();
}

// ---------------------------------------------------------------- tears in the paper
// A tear in the paper floor: you can see the dark underneath. Fill it with confetti to patch it.
export function drawTear3d(c, V, x, y, z, w, d, t, seed = 0) {
  const P = (xx, zz) => [V.x(xx, zz), V.y(y, zz)];
  const ring = (k, jit) => {
    c.beginPath();
    for (let i = 0; i < 16; i++) {
      const a = (i / 16) * TAU, j = 1 + (hash(seed + i * 3.7) - 0.5) * jit;
      const [sx, sy] = P(x + Math.cos(a) * (w / 2) * k * j, z + Math.sin(a) * (d / 2) * k * j);
      if (i) c.lineTo(sx, sy); else c.moveTo(sx, sy);
    }
    c.closePath();
  };
  ring(1.14, 0.5); c.fillStyle = PAPER; c.fill(); c.strokeStyle = 'rgba(43,34,53,0.45)'; c.lineWidth = 1.5; c.stroke();
  const [, ty] = P(x, z + d / 2), [, by] = P(x, z - d / 2);
  ring(0.92, 0.6); c.fillStyle = vgrad(c, ty, by, '#05030a', '#2c2238'); c.fill(); c.strokeStyle = INK; c.lineWidth = 2; c.stroke();
  const [cx, cy] = P(x, z), k = V.s(z);
  c.fillStyle = `rgba(170,150,230,${0.25 + 0.15 * Math.sin(t * 2 + seed)})`;
  c.beginPath(); c.ellipse(cx, cy, w * 0.14 * k, d * 0.06 * k, 0, 0, TAU); c.fill();
}

export function drawPatch3d(c, V, x, y, z, w, d, seed = 0) {
  const P = (xx, zz) => [V.x(xx, zz), V.y(y, zz)];
  face(c, [P(x - w * 0.56, z + d * 0.55), P(x + w * 0.54, z + d * 0.5), P(x + w * 0.5, z - d * 0.56), P(x - w * 0.52, z - d * 0.5)], '#f6ecd4', 1.5);
  for (let i = 0; i < 12; i++) {
    const [sx, sy] = P(x + (hash(seed + i) - 0.5) * w * 0.9, z + (hash(seed + i + 9) - 0.5) * d * 0.85);
    c.fillStyle = CONF[i % CONF.length]; c.fillRect(sx - 2.5, sy - 1.5, 5, 3);
  }
  face(c, [P(x - w * 0.62, z + 8), P(x + w * 0.62, z + 12), P(x + w * 0.62, z - 2), P(x - w * 0.62, z - 6)], 'rgba(255,240,180,0.7)', 0);
}

// ---------------------------------------------------------------- folded folks
// A townsfolk the Gloom Gale folded into a paper shape and blew away. It wiggles when you're close: E unfolds it.
export function drawFoldedFolk(c, x, y, o = {}) {
  const t = o.t || 0, look = o.look || 'crane', col = o.color || '#e0604a';
  const pale = shade(col, 0.45), dark = shade(col, -0.2);
  c.save(); c.translate(x, y);
  shadow(c, 0, 0, 18);
  c.rotate(o.near ? Math.sin(t * 18) * 0.1 : Math.sin(t * 2 + x) * 0.03);
  let fx = 0, fy = -16;
  paper(c, p => {
    if (look === 'crane') {
      shape(c, p, poly([[-28, -22], [-6, -30], [0, -8], [-14, -6]]), pale);
      shape(c, p, poly([[24, -44], [30, -48], [12, -20], [4, -14]]), pale);
      shape(c, p, poly([[-14, -6], [0, -34], [14, -8], [0, 0]]), col);
      shape(c, p, poly([[0, -26], [-16, -54], [8, -18]]), dark);
      fx = 2; fy = -15;
    } else if (look === 'frog') {
      shape(c, p, poly([[-22, 0], [-30, -6], [-16, -10]]), dark);
      shape(c, p, poly([[22, 0], [30, -6], [16, -10]]), dark);
      shape(c, p, poly([[-22, 0], [-16, -22], [0, -30], [16, -22], [22, 0]]), col);
      shape(c, p, poly([[-14, -24], [-8, -36], [-2, -26]]), pale);
      shape(c, p, poly([[2, -26], [8, -36], [14, -24]]), pale);
      fy = -14;
    } else if (look === 'plane') {
      c.translate(0, -14); c.rotate(0.35);
      shape(c, p, poly([[-30, -10], [26, -2], [-30, 6], [-18, -2]]), pale);
      shape(c, p, poly([[-18, -2], [26, -2], [-24, 12]]), col);
      fx = -6; fy = -2;
    } else if (look === 'boat') {
      shape(c, p, poly([[-10, -14], [0, -42], [10, -14]]), pale);
      shape(c, p, poly([[-28, -14], [28, -14], [17, 0], [-17, 0]]), col);
      fy = -7;
    } else if (look === 'star') {
      shape(c, p, cc => starPath(cc, 0, -22, 23, 11, 5), col);
      fy = -21;
    } else {
      shape(c, p, cc => { for (let i = 0; i < 12; i++) { const a = (i / 12) * TAU, r = 16 + (i % 2 ? 4 : -1) + hash(i + x) * 3; const px = Math.cos(a) * r, py = -18 + Math.sin(a) * r; if (i) cc.lineTo(px, py); else cc.moveTo(px, py); } cc.closePath(); }, pale);
      fy = -18;
    }
  });
  if (look === 'ball') {
    c.strokeStyle = 'rgba(43,34,53,0.35)'; c.lineWidth = 1.4;
    c.beginPath(); c.moveTo(-10, -26); c.lineTo(-2, -20); c.lineTo(8, -28); c.moveTo(-6, -8); c.lineTo(2, -14); c.lineTo(10, -8); c.stroke();
  }
  eyes(c, fx - 4, fx + 4, fy, 6, o.near ? 'worried' : 'sleepy', t);
  c.restore();
  if (o.near) {
    const by = y - 70 + Math.sin(t * 6) * 3;
    c.fillStyle = PAPER; c.strokeStyle = INK; c.lineWidth = 2;
    c.beginPath(); c.ellipse(x, by, 13, 13, 0, 0, TAU); c.fill(); c.stroke();
    c.font = 'bold 18px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#e5534b'; c.fillText('!', x, by + 6);
  }
}

// ---------------------------------------------------------------- confetti and camp things
export function drawConfettiPile(c, x, y, t = 0) {
  c.save(); c.translate(x, y);
  shadow(c, 0, 0, 26, 0.15);
  for (let i = 0; i < 28; i++) {
    const a = hash(i * 2.3), b = hash(i * 5.1);
    c.save(); c.translate((a - 0.5) * 54 * (1 - b * 0.5), -b * 26 * (1 - Math.abs(a - 0.5)));
    c.rotate(a * 6 + Math.sin(t * 2 + i) * 0.2);
    c.fillStyle = CONF[i % 6]; c.fillRect(-4, -2.5, 8, 5);
    c.restore();
  }
  c.globalAlpha = 0.5 + 0.5 * Math.sin(t * 4);
  c.fillStyle = '#fff6c8'; c.beginPath(); starPath(c, 12, -30, 6, 2, 4); c.fill();
  c.globalAlpha = 1;
  c.restore();
}

export function drawTent(c, x, y, o = {}) {
  const col = o.color || '#e5534b';
  c.save(); c.translate(x, y);
  shadow(c, 0, 0, 60, 0.15);
  paper(c, p => {
    shape(c, p, poly([[-72, 0], [0, -98], [72, 0]]), vgrad(c, -98, 0, shade(col, 0.15), col));
    shape(c, p, poly([[-15, 0], [0, -60], [15, 0]]), '#3b2a3a');
    shape(c, p, rrect(-3, -114, 6, 20, 2), '#8a5a3c', 1.6);
  });
  c.strokeStyle = 'rgba(255,255,255,0.5)'; c.lineWidth = 3;
  c.beginPath(); c.moveTo(-36, -49); c.lineTo(0, -98); c.lineTo(36, -49); c.stroke();
  c.fillStyle = '#ffd23f'; c.strokeStyle = INK; c.lineWidth = 1.5;
  c.beginPath(); c.moveTo(3, -114); c.lineTo(24 + Math.sin((o.t || 0) * 4) * 2, -107); c.lineTo(3, -100); c.closePath(); c.fill(); c.stroke();
  c.restore();
}

export function drawCampfire(c, x, y, t = 0) {
  c.save(); c.translate(x, y);
  glowDot(c, 0, -20, 90, '255,170,80', 0.35);
  paper(c, p => {
    shape(c, p, rrect(-26, -8, 52, 9, 4), '#8a5a3c', 2);
    shape(c, p, rrect(-20, -15, 40, 9, 4), '#7a4f30', 2);
    for (let i = 0; i < 5; i++) shape(c, p, ell(-20 + i * 10, -1, 6, 4), '#9a93ad', 1.4);
  });
  flame(c, 0, -12, 1.3, t); flame(c, -9, -9, 0.75, t + 1.3); flame(c, 9, -9, 0.75, t + 2.1);
  c.restore();
}

// Peely's sticker stand: a counter with a striped awning and stickers pinned all over it.
export function drawStall(c, x, y, t = 0) {
  c.save(); c.translate(x, y);
  shadow(c, 0, 0, 70, 0.15);
  paper(c, p => {
    shape(c, p, rrect(-66, -150, 9, 150, 3), '#a8794e');
    shape(c, p, rrect(57, -150, 9, 150, 3), '#a8794e');
    shape(c, p, rrect(-72, -62, 144, 62, 6), vgrad(c, -62, 0, '#f6e3b8', '#d9bf86'));
  });
  c.lineWidth = 2; c.strokeStyle = INK;
  for (let i = 0; i < 7; i++) {
    const ax = -77 + i * 22;
    c.fillStyle = i % 2 ? '#fffaf0' : '#ff7a9a';
    c.beginPath(); c.moveTo(ax, -152); c.lineTo(ax + 22, -152); c.lineTo(ax + 22, -130); c.quadraticCurveTo(ax + 11, -118, ax, -130); c.closePath(); c.fill(); c.stroke();
  }
  ['bridge', 'stairs', 'fan', 'sprout'].forEach((k, i) => {
    c.save(); c.translate(-48 + i * 32, -32); c.rotate(Math.sin(t + i) * 0.06 + (i % 2 ? 0.1 : -0.1));
    c.fillStyle = PAPER; c.strokeStyle = INK; c.lineWidth = 1.5; c.beginPath(); rrect(-12, -12, 24, 24, 5)(c); c.fill(); c.stroke();
    c.fillStyle = STICKER_COL[k]; c.beginPath(); rrect(-9, -9, 18, 18, 4)(c); c.fill();
    drawStickerIcon(c, k, 7.5);
    c.restore();
  });
  c.font = 'bold 15px Fredoka, sans-serif'; c.textAlign = 'center';
  c.fillStyle = PAPER; c.strokeStyle = INK; c.lineWidth = 2; c.beginPath(); rrect(-60, -178, 120, 22, 8)(c); c.fill(); c.stroke();
  c.fillStyle = INK; c.fillText('STICKERS', 0, -162);
  c.restore();
}

// A paper totem with a circling arrow: puts every crate in the room back where it started.
export function drawResetTotem(c, x, y, t = 0) {
  c.save(); c.translate(x, y);
  shadow(c, 0, 0, 14);
  paper(c, p => { shape(c, p, rrect(-9, -66, 18, 66, 5), '#b49cff'); shape(c, p, ell(0, -84, 20, 20), '#fffaf0'); });
  const a0 = t * 1.5, a1 = a0 + Math.PI * 1.6;
  c.strokeStyle = '#5a4fa8'; c.lineWidth = 4; c.lineCap = 'round';
  c.beginPath(); c.arc(0, -84, 11, a0, a1); c.stroke();
  const hx = Math.cos(a1) * 11, hy = -84 + Math.sin(a1) * 11, tx = -Math.sin(a1), ty = Math.cos(a1);
  c.fillStyle = '#5a4fa8';
  c.beginPath(); c.moveTo(hx + tx * 7, hy + ty * 7); c.lineTo(hx + Math.cos(a1) * 6, hy + Math.sin(a1) * 6); c.lineTo(hx - Math.cos(a1) * 6, hy - Math.sin(a1) * 6); c.closePath(); c.fill();
  c.restore();
}

// A path that leads off toward you, out the front of the floor (to somewhere south of here).
export function drawFrontPath(c, V, x, y) {
  const P = (xx, z) => [V.x(xx, z), V.y(y, z)];
  c.fillStyle = 'rgba(214,180,120,0.8)';
  c.beginPath(); c.moveTo(...P(x - 34, 16)); c.lineTo(...P(x + 34, 16)); c.lineTo(...P(x + 62, GZ0)); c.lineTo(...P(x - 62, GZ0)); c.closePath(); c.fill();
  c.fillStyle = 'rgba(120,80,40,0.25)';
  for (let z = 4; z > GZ0; z -= 24) { const [sx, sy] = P(x + Math.sin(z) * 8, z), k = V.s(z); c.beginPath(); c.ellipse(sx, sy, 7 * k, 2.5 * k, 0, 0, TAU); c.fill(); }
}

// The wooden signpost beside a front path, drawn around (0, 0).
export function drawSignpost(c, label, locked, t = 0) {
  paper(c, p => {
    shape(c, p, rrect(-4, -100, 8, 100, 2), '#8a5a3c');
    shape(c, p, poly([[-54, -100], [44, -100], [56, -86], [44, -72], [-54, -72]]), '#d9a066');
  });
  c.font = 'bold 13px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillStyle = INK;
  c.fillText(label || '', -4, -81, 92);
  const by = -58 + Math.sin(t * 4) * 3;
  c.fillStyle = '#ffe066'; c.strokeStyle = INK; c.lineWidth = 2;
  c.beginPath(); c.moveTo(-9, by - 6); c.lineTo(9, by - 6); c.lineTo(0, by + 5); c.closePath(); c.fill(); c.stroke();
  if (locked) { c.font = '22px "Segoe UI Emoji", sans-serif'; c.fillText('🔒', 0, -112); }
}

// ---------------------------------------------------------------- new folks
// Peely: a living sticker who runs the sticker stand. One corner never stays down.
export function drawPeely(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 18 * s);
  c.scale(s * flip, s);
  c.translate(0, -Math.abs(Math.sin(t * 2.4)) * 3);
  paper(c, p => {
    shape(c, p, rrect(-10, -12, 5, 10, 2), '#6b5a7a', 1.6); shape(c, p, rrect(5, -12, 5, 10, 2), '#6b5a7a', 1.6);
    shape(c, p, ell(-8, -2, 6, 3.5), '#6b5a7a'); shape(c, p, ell(8, -2, 6, 3.5), '#6b5a7a');
  });
  const S = 26, L = 10 + Math.sin(t * 3) * 3, top = -64, bot = -10;
  const body = () => {
    c.beginPath(); c.moveTo(-S + 8, top); c.lineTo(S - L, top); c.lineTo(S, top + L); c.lineTo(S, bot - 6); c.quadraticCurveTo(S, bot, S - 6, bot);
    c.lineTo(-S + 6, bot); c.quadraticCurveTo(-S, bot, -S, bot - 6); c.lineTo(-S, top + 8); c.quadraticCurveTo(-S, top, -S + 8, top); c.closePath();
  };
  c.lineJoin = 'round';
  body(); c.lineWidth = 9; c.strokeStyle = PAPER; c.stroke(); c.fillStyle = PAPER; c.fill();
  body(); c.fillStyle = '#fffaf0'; c.fill(); c.lineWidth = 2.4; c.strokeStyle = INK; c.stroke();
  c.fillStyle = vgrad(c, top + 5, bot - 5, '#ffe066', '#ffb347'); c.beginPath(); rrect(-S + 5, top + 5, 2 * S - 10, bot - top - 10, 6)(c); c.fill();
  c.fillStyle = 'rgba(255,255,255,0.6)'; c.beginPath(); starPath(c, -13, top + 14, 7, 3, 5); c.fill();
  c.fillStyle = '#ece2cc'; c.lineWidth = 1.6;
  c.beginPath(); c.moveTo(S - L, top); c.lineTo(S, top + L); c.lineTo(S - L, top + L); c.closePath(); c.fill(); c.stroke();
  const wave = Math.sin(t * 4);
  c.strokeStyle = INK; c.lineWidth = 2.4; c.lineCap = 'round';
  c.beginPath(); c.moveTo(-S, -36); c.lineTo(-S - 11, -28 + wave * 3); c.moveTo(S, -36); c.lineTo(S + 11, -46 - wave * 6); c.stroke();
  eyes(c, -7, 7, -40, 8, o.mood, t);
  mouth(c, 0, -29, 6, o.mood || 'happy');
  c.restore();
}

// Stitch: a sewing needle with a thimble for a hat, trailing red thread. Fixes tears.
export function drawStitch(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 14 * s);
  c.scale(s * flip, s);
  c.translate(0, Math.sin(t * 2) * 1);
  const thread = () => { c.beginPath(); c.moveTo(0, -78); c.bezierCurveTo(-30, -96, -40, -50, -20 + Math.sin(t * 2) * 4, -30); c.bezierCurveTo(-8, -16, -30, -6, -24, 0); };
  c.lineCap = 'round';
  thread(); c.strokeStyle = PAPER; c.lineWidth = 7; c.stroke();
  thread(); c.strokeStyle = '#e5534b'; c.lineWidth = 3; c.stroke();
  paper(c, p => {
    shape(c, p, cc => { cc.moveTo(0, 0); cc.lineTo(-9, -22); cc.lineTo(-9, -80); cc.quadraticCurveTo(0, -94, 9, -80); cc.lineTo(9, -22); cc.closePath(); }, vgrad(c, -92, 0, '#f4f6ff', '#9ea3b5'));
    shape(c, p, rrect(-12, -106, 24, 18, 6), vgrad(c, -106, -88, '#ffd23f', '#e8a92a'));
  });
  c.fillStyle = INK; c.beginPath(); c.ellipse(0, -77, 2.6, 6, 0, 0, TAU); c.fill();
  c.fillStyle = 'rgba(140,90,20,0.45)';
  for (const [dx, dy] of [[-6, -100], [0, -102], [6, -100], [-3, -94], [3, -94]]) { c.beginPath(); c.arc(dx, dy, 1.4, 0, TAU); c.fill(); }
  c.fillStyle = 'rgba(255,255,255,0.7)'; c.fillRect(-6, -68, 2.5, 40);
  eyes(c, -4, 4, -54, 6, o.mood, t);
  mouth(c, 0, -46, 4, o.mood);
  c.restore();
}

// Mayor Pennywick: a very proper candle in a top hat (with a hole in the top for his flame).
export function drawMayor(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, hgt = 56;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 16 * s);
  c.scale(s * flip, s);
  c.translate(0, Math.sin(t * 2) * 0.8);
  paper(c, p => {
    shape(c, p, ell(-6, -2, 6, 3.5), '#6b5a7a'); shape(c, p, ell(6, -2, 6, 3.5), '#6b5a7a');
    shape(c, p, cc => { cc.moveTo(-15, -4); cc.lineTo(-15, -hgt); cc.lineTo(15, -hgt); cc.lineTo(15, -4); cc.quadraticCurveTo(0, 0, -15, -4); cc.closePath(); }, vgrad(c, -hgt, 0, '#f6ecff', '#d9c6ee'));
    shape(c, p, poly([[-15, -36], [-15, -27], [15, -10], [15, -19]]), '#e5534b', 1.8);
    shape(c, p, rrect(-21, -hgt - 4, 42, 6, 2), '#2b2235', 2);
    shape(c, p, rrect(-13, -hgt - 30, 26, 27, 3), '#3b3350', 2);
  });
  c.fillStyle = '#e5534b'; c.fillRect(-13, -hgt - 12, 26, 5);
  c.fillStyle = '#ffd23f'; c.strokeStyle = INK; c.lineWidth = 1; c.beginPath(); starPath(c, 7, -21, 5, 2.4, 5); c.fill(); c.stroke();
  flame(c, 0, -hgt - 30, 0.6, t);
  const ey = -hgt + 16;
  eyes(c, -5, 5, ey, 7, o.mood, t);
  c.fillStyle = INK; c.beginPath(); c.ellipse(-3.5, ey + 6, 4, 1.8, 0.3, 0, TAU); c.ellipse(3.5, ey + 6, 4, 1.8, -0.3, 0, TAU); c.fill();
  mouth(c, 0, ey + 10, 4, o.mood);
  c.strokeStyle = '#ffd23f'; c.lineWidth = 1.8;
  c.beginPath(); c.arc(5, ey, 5.5, 0, TAU); c.stroke();
  c.beginPath(); c.moveTo(10, ey + 3); c.quadraticCurveTo(14, ey + 14, 10, ey + 20); c.stroke();
  c.restore();
}

// Snipper: a pair of scissors that scuttles around snipping at things.
export function drawSnipper(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  const walk = o.state === 'walk', ph = (o.phase || 0) * TAU;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 18 * s);
  c.scale(s * flip, s);
  c.translate(0, walk ? -Math.abs(Math.sin(ph)) * 5 : 0);
  const step = walk ? Math.sin(ph) * 5 : 0;
  c.strokeStyle = INK; c.lineWidth = 2.4; c.lineCap = 'round';
  c.beginPath(); c.moveTo(-10, -18); c.lineTo(-12 + step, 0); c.moveTo(2, -18); c.lineTo(4 - step, 0); c.stroke();
  paper(c, p => { shape(c, p, ell(-13 + step, -1, 5, 3), '#6b5a7a', 1.6); shape(c, p, ell(5 - step, -1, 5, 3), '#6b5a7a', 1.6); });
  const snip = walk ? 0.08 + Math.abs(Math.sin(ph * 2)) * 0.45 : 0.15 + Math.abs(Math.sin(t * 3)) * 0.2;
  for (const side of [1, -1]) {
    c.save(); c.translate(-2, -28); c.rotate(-side * snip);
    paper(c, p => {
      shape(c, p, poly([[0, -3.5], [36, -side * 1.5], [0, 4]]), vgrad(c, -4, 4, '#f4f6ff', '#9ea3b5'), 2);
      shape(c, p, ell(-15, side * 7, 10, 7.5), side > 0 ? '#e5534b' : '#ff7a6e', 2);
    });
    c.fillStyle = '#fffaf0'; c.beginPath(); c.ellipse(-15, side * 7, 4.5, 3, 0, 0, TAU); c.fill();
    c.restore();
  }
  c.fillStyle = '#ffd23f'; c.strokeStyle = INK; c.lineWidth = 1.5; c.beginPath(); c.arc(-2, -28, 4, 0, TAU); c.fill(); c.stroke();
  eyes(c, 8, 16, -36, 6.5, o.mood || 'angry', t);
  c.restore();
}

// The Gloop Golem: a big angry blob of paste wearing a glue-bottle cap. Its little drips are Glue Drops.
export function drawGlueGolem(c, x, y, o = {}) {
  const t = o.t || 0, s = (o.scale || 1) * (o.small ? 0.45 : 1), flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 40 * s);
  c.scale(s * flip, s);
  const wob = Math.sin(t * 3) * 3;
  paper(c, p => shape(c, p, ell(0, -4, 50, 9), '#f4f0f8', 2));
  paper(c, p => shape(c, p, cc => {
    cc.moveTo(-44, -6); cc.quadraticCurveTo(-54 - wob, -60, -26, -90 - wob); cc.quadraticCurveTo(0, -112 - wob, 26, -90 - wob);
    cc.quadraticCurveTo(54 + wob, -60, 44, -6); cc.closePath();
  }, vgrad(c, -110, 0, '#ffffff', '#dcd6ea')));
  paper(c, p => {
    shape(c, p, rrect(-14, -117 - wob, 28, 16, 4), '#ff8a3d', 2);
    shape(c, p, poly([[-6, -117 - wob], [0, -136 - wob], [6, -117 - wob]]), '#ff8a3d', 2);
  });
  c.fillStyle = '#f4f0f8'; c.strokeStyle = INK; c.lineWidth = 1.6;
  for (const [dx, k] of [[-30, 0], [18, 1.3], [36, 2.1]]) {
    const d = 8 + ((t * 0.6 + k) % 1) * 14;
    c.beginPath(); c.moveTo(dx - 4, -40); c.lineTo(dx - 3, -40 + d); c.arc(dx, -40 + d, 3, Math.PI, 0, true); c.lineTo(dx + 4, -40); c.fill(); c.stroke();
  }
  if (!o.small) {
    for (const [px, py, r, col] of [[-24, -62, 0.3, '#9fe6ff'], [26, -38, -0.4, '#ffe066'], [8, -90, 0.2, '#ff9ab0']]) {
      c.save(); c.translate(px, py - (py < -80 ? wob : 0)); c.rotate(r);
      c.fillStyle = col; c.fillRect(-7, -5, 14, 10); c.strokeStyle = INK; c.lineWidth = 1.2; c.strokeRect(-7, -5, 14, 10);
      c.restore();
    }
  }
  c.fillStyle = 'rgba(255,255,255,0.85)'; c.beginPath(); c.ellipse(-20, -78 - wob, 6, 12, -0.4, 0, TAU); c.fill();
  eyes(c, -12, 12, -62 - wob, 12, o.mood || 'angry', t);
  mouth(c, 0, -42 - wob, 12, o.mood === 'hurt' ? 'hurt' : o.mood === 'sleep' ? 'sleep' : 'angry');
  c.restore();
}

Object.assign(DRAW, {
  peely: drawPeely, stitch: drawStitch, mayor: drawMayor, snipper: drawSnipper, gluegolem: drawGlueGolem,
  gluedrop: (c, x, y, o = {}) => drawGlueGolem(c, x, y, { ...o, small: true }),
});
