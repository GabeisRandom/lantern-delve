// Chapter 4 art: Count Dusk's Tower. Tick the alarm clock; the tower's creatures (Notiflies, Snoozers, Scrollbugs and
// Sandglasses); the Scrollwyrm; Count Dusk himself for the final battle; Old Minute and the stopped clocks of the
// Midnight Moor; the moor's sky, the clock tower's rooms, and the stages up there. Importing this file adds them all.
import { DRAW, INK, PAPER, paper, shape, rrect, ell, poly, vgrad, glowDot, eyes, mouth, starPath, shadow } from './art.js';
import { MAT, STYLES, FIELD_DECOR, DECOR_FOOT, DECOR_DRAW, EXTRA_BACKDROPS } from './art2.js';

const TAU = Math.PI * 2;
const hash = n => { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };
const BRASS = ['#f6c45a', '#c98a2a'];

// ---------------------------------------------------------------- Tick, the alarm clock (partner)
export function drawTick(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'happy';
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 16 * s);
  c.scale(s * flip, s);
  const step = o.state === 'walk' ? Math.sin((o.phase || 0) * Math.PI * 2) : 0;
  c.translate(0, Math.sin(t * 3) * 0.8 - Math.abs(step) * 2);
  paper(c, p => {
    shape(c, p, ell(-8 + step * 3, -2.5, 6, 3.5), '#7a4f24');
    shape(c, p, ell(8 - step * 3, -2.5, 6, 3.5), '#7a4f24');
    for (const sx of [-1, 1]) shape(c, p, cc => { cc.arc(sx * 12, -39, 9, Math.PI, 0); cc.closePath(); }, vgrad(c, -48, -39, '#ffe08a', '#e0a832'));
    shape(c, p, ell(0, -23, 19, 18), vgrad(c, -41, -5, BRASS[0], BRASS[1]));
    shape(c, p, ell(0, -23, 14.5, 13.5), PAPER, 1.8);
  });
  // the little hammer between the bells (it rattles like mad when Tick rings)
  const swing = o.ring || o.state === 'ring' ? Math.sin(t * 55) * 0.55 : Math.sin(t * 2.4) * 0.12;
  c.save(); c.translate(0, -41); c.rotate(swing);
  c.strokeStyle = INK; c.lineWidth = 2.2; c.beginPath(); c.moveTo(0, 0); c.lineTo(0, -9); c.stroke();
  c.fillStyle = '#7a4f24'; c.beginPath(); c.arc(0, -10, 3.2, 0, TAU); c.fill(); c.stroke();
  c.restore();
  // hour marks round the face
  c.strokeStyle = 'rgba(43,34,53,0.45)'; c.lineWidth = 1.3;
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * TAU;
    c.beginPath(); c.moveTo(Math.sin(a) * 12.5, -23 - Math.cos(a) * 11.5); c.lineTo(Math.sin(a) * 10.5, -23 - Math.cos(a) * 9.7); c.stroke();
  }
  eyes(c, -5, 5, -26, 6, mood, t);
  mouth(c, 0, -18, 4, mood);
  c.restore();
}

// ---------------------------------------------------------------- the tower's creatures
// A Snoozer: an alarm clock that hit snooze one time too many. Nightcap, droopy eyes, little floating Zs.
export function drawSnoozer(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  const mood = o.mood === 'hurt' ? 'hurt' : 'sleepy';
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 18 * s);
  c.scale(s * flip, s);
  c.translate(0, Math.sin(t * 1.6) * 1.2);
  paper(c, p => {
    shape(c, p, ell(-9, -2.5, 6.5, 3.5), '#3b3a5a');
    shape(c, p, ell(9, -2.5, 6.5, 3.5), '#3b3a5a');
    shape(c, p, cc => { cc.arc(13, -42, 9, Math.PI, 0); cc.closePath(); }, '#c8c2d4');
    shape(c, p, ell(0, -25, 21, 20), vgrad(c, -45, -5, '#9aa6d0', '#5d6a96'));
    shape(c, p, ell(0, -25, 16, 15), PAPER, 1.8);
    // a striped nightcap, flopped over the other bell
    shape(c, p, cc => { cc.moveTo(-22, -38); cc.quadraticCurveTo(-14, -60, 4, -48); cc.quadraticCurveTo(-4, -44, -10, -36); cc.closePath(); }, '#e5534b');
    shape(c, p, ell(5, -48, 4.5, 4.5), PAPER, 1.6);
  });
  c.strokeStyle = 'rgba(255,250,240,0.9)'; c.lineWidth = 3;
  c.beginPath(); c.moveTo(-17, -42); c.lineTo(-11, -48); c.moveTo(-12, -38); c.lineTo(-5, -45); c.stroke();
  eyes(c, -6, 6, -27, 6, mood, t);
  mouth(c, 0, -17, 5, mood === 'hurt' ? 'hurt' : 'sleep');
  if (mood !== 'hurt') {
    c.font = 'bold 12px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillStyle = 'rgba(200,210,255,0.9)';
    for (let i = 0; i < 2; i++) { const k = (t * 0.6 + i * 0.5) % 1; c.globalAlpha = 1 - k; c.fillText('z', 22 + k * 10 + i * 6, -50 - k * 24); }
    c.globalAlpha = 1;
  }
  c.restore();
}

// A Notifly: a little red notification bell on buzzing wings, its badge always showing a number.
export function drawNotifly(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 10 * s, 0.15);
  c.scale(s * flip, s);
  const flap = Math.sin(t * 40) * 0.45;
  c.fillStyle = 'rgba(225,238,255,0.72)'; c.strokeStyle = 'rgba(43,34,53,0.55)'; c.lineWidth = 1.5;
  for (const sx of [-1, 1]) {
    c.save(); c.translate(sx * 9, -27); c.rotate(sx * (0.45 + flap));
    c.beginPath(); c.ellipse(sx * 10, -5, 11, 6, 0, 0, TAU); c.fill(); c.stroke();
    c.restore();
  }
  paper(c, p => {
    shape(c, p, cc => { cc.moveTo(-13, -10); cc.quadraticCurveTo(-13, -34, 0, -34); cc.quadraticCurveTo(13, -34, 13, -10); cc.lineTo(16, -6); cc.lineTo(-16, -6); cc.closePath(); }, vgrad(c, -34, -6, '#ff7a6e', '#d63a3a'));
    shape(c, p, ell(0, -3.5, 4, 3.5), '#ffd23f', 1.8);
    shape(c, p, ell(11, -32, 7, 7), PAPER, 1.6);
  });
  c.fillStyle = '#d63a3a'; c.font = 'bold 10px Fredoka, sans-serif'; c.textAlign = 'center';
  c.fillText(String(3 + (Math.floor(t * 0.7) % 7)), 11, -28.5);
  eyes(c, -5, 3, -20, 5.5, o.mood || 'angry', t);
  c.restore();
}

// A Scrollbug: a paper scroll that crawls like a caterpillar. Its face is a little screen of endless shiny nothing.
export function drawScrollbug(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 22 * s);
  c.scale(s * flip, s);
  paper(c, p => {
    for (let i = 0; i < 3; i++) {
      const bx = -30 + i * 11, by = -9 - Math.abs(Math.sin(t * 6 + i * 1.2)) * 4;
      shape(c, p, ell(bx, by, 9, 9), i % 2 ? '#efe8f6' : '#d9cfea', 1.8);
    }
    shape(c, p, rrect(-2, -40, 28, 36, 6), INK, 2);
  });
  c.save(); c.beginPath(); c.rect(1, -37, 22, 30); c.clip();
  c.fillStyle = vgrad(c, -37, -7, '#7fd6ff', '#b49cff'); c.fillRect(1, -37, 22, 30);
  const off = (t * 34) % 11;
  for (let yy = -37 - off, i = 0; yy < -7; yy += 11, i++) {
    c.fillStyle = ['rgba(255,255,255,0.8)', 'rgba(255,224,102,0.85)', 'rgba(255,154,176,0.85)'][i % 3];
    c.fillRect(4, yy, 16, 5);
  }
  c.restore();
  const look = o.mood === 'hurt' ? 'hurt' : 'normal';
  for (const ex of [7, 17]) {
    if (look === 'hurt') { c.strokeStyle = INK; c.lineWidth = 2; c.beginPath(); c.moveTo(ex - 3, -27); c.lineTo(ex + 3, -21); c.moveTo(ex + 3, -27); c.lineTo(ex - 3, -21); c.stroke(); continue; }
    glowDot(c, ex, -24, 7, '255,255,255', 0.6);
    c.fillStyle = INK; c.beginPath(); c.arc(ex, -24, 2.6, 0, TAU); c.fill();
  }
  c.restore();
}

// A Sandglass: an hourglass with a grudge. The sand on top is how many turns it has left (o.fuse) before TIME'S UP.
export function drawSandglass(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1;
  const k = Math.max(0, Math.min(1, (o.fuse ?? 3) / 3));
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 18 * s);
  c.scale(s * flip, s);
  c.translate(0, Math.sin(t * 2) * 0.8);
  paper(c, p => {
    shape(c, p, cc => { cc.moveTo(-14, -50); cc.lineTo(14, -50); cc.quadraticCurveTo(14, -36, 3, -29); cc.quadraticCurveTo(14, -22, 14, -8); cc.lineTo(-14, -8); cc.quadraticCurveTo(-14, -22, -3, -29); cc.quadraticCurveTo(-14, -36, -14, -50); cc.closePath(); }, 'rgba(214,236,255,0.6)', 1.8);
  });
  // the sand: what's left on top, a thin falling stream, and the pile below
  c.fillStyle = '#f2c14e';
  if (k > 0) {
    const top = -31 - 16 * k;
    c.beginPath(); c.moveTo(-11 * k - 1, top); c.lineTo(11 * k + 1, top); c.lineTo(1.5, -30); c.lineTo(-1.5, -30); c.closePath(); c.fill();
    c.fillRect(-0.8, -30, 1.6, 20);
  }
  const pile = 4 + 12 * (1 - k);
  c.beginPath(); c.moveTo(-13, -9); c.quadraticCurveTo(0, -9 - pile * 2, 13, -9); c.closePath(); c.fill();
  paper(c, p => {
    shape(c, p, rrect(-21, -9, 42, 9, 3), '#8a5a3c');
    shape(c, p, rrect(-21, -58, 42, 9, 3), '#8a5a3c');
    shape(c, p, rrect(-19, -50, 4, 42, 2), '#a8794e', 1.6);
    shape(c, p, rrect(15, -50, 4, 42, 2), '#a8794e', 1.6);
  });
  eyes(c, -5, 5, -41, 5.5, o.mood || 'angry', t);
  if (k <= 0.34) { c.fillStyle = '#ff7a6e'; c.font = 'bold 14px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillText('!', 0, -64 - Math.abs(Math.sin(t * 8)) * 4); }
  c.restore();
}

// ---------------------------------------------------------------- the Scrollwyrm (boss): the endless feed
const THUMBS = [['#ff9ab0', '#ffd23f'], ['#7fd6ff', '#b49cff'], ['#8be07a', '#ffe066'], ['#ffb347', '#ff6b6b'], ['#b49cff', '#7fd6ff']];
export function drawScrollwyrm(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'happy';
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 62 * s);
  c.scale(s * flip, s);
  const N = 7, pts = [];
  for (let i = 0; i < N; i++) {
    const u = i / (N - 1);
    pts.push([Math.sin(u * 3.4 + t * 1.6) * 24 * (1 - u * 0.4) + 8 - u * 14, -14 - u * 104]);
  }
  paper(c, p => {
    shape(c, p, ell(0, -7, 48, 13), '#ece4f6');
    for (let i = 0; i < N - 1; i++) { const [px, py] = pts[i]; shape(c, p, rrect(px - 19, py - 14, 38, 26, 6), i % 2 ? '#3a3158' : '#2b2440', 2); }
    const [hx, hy] = pts[N - 1];
    shape(c, p, rrect(hx - 32, hy - 44, 64, 50, 11), '#2b2440', 2.4);
    shape(c, p, ell(hx + 22, hy - 46, 9, 9), '#e5534b', 2);
  });
  // a pile of scrolled-past paper at the bottom
  c.strokeStyle = 'rgba(43,34,53,0.35)'; c.lineWidth = 1.5;
  for (let i = -3; i <= 3; i++) { c.beginPath(); c.moveTo(i * 12 - 6, -4); c.lineTo(i * 12 + 4, -12); c.stroke(); }
  // every screen glows with a different thumbnail, and they keep changing
  for (let i = 0; i < N - 1; i++) {
    const [px, py] = pts[i], [a, b] = THUMBS[(i + Math.floor(t * 2.5)) % THUMBS.length];
    c.fillStyle = vgrad(c, py - 10, py + 8, a, b); c.fillRect(px - 15, py - 10, 30, 18);
    c.fillStyle = 'rgba(255,255,255,0.85)'; c.beginPath(); c.moveTo(px - 3, py - 5); c.lineTo(px + 5, py - 1); c.lineTo(px - 3, py + 3); c.closePath(); c.fill();
  }
  const [hx, hy] = pts[N - 1];
  c.fillStyle = vgrad(c, hy - 40, hy + 2, '#7fd6ff', '#ff9ab0'); c.fillRect(hx - 28, hy - 40, 56, 42);
  // the play button on its forehead
  c.fillStyle = PAPER; c.beginPath(); c.moveTo(hx + 19, hy - 50); c.lineTo(hx + 27, hy - 46); c.lineTo(hx + 19, hy - 42); c.closePath(); c.fill();
  // hypnotic swirly eyes (X eyes when it gets bonked), and a wide grin
  for (const ex of [hx - 12, hx + 12]) {
    if (mood === 'hurt') { c.strokeStyle = INK; c.lineWidth = 3; c.beginPath(); c.moveTo(ex - 5, hy - 30); c.lineTo(ex + 5, hy - 20); c.moveTo(ex + 5, hy - 30); c.lineTo(ex - 5, hy - 20); c.stroke(); continue; }
    c.fillStyle = PAPER; c.beginPath(); c.arc(ex, hy - 25, 8, 0, TAU); c.fill();
    c.strokeStyle = '#7b5fc7'; c.lineWidth = 2;
    c.beginPath();
    for (let a = 0; a < 10; a += 0.4) { const r = a * 0.7, ang = a + t * 6; const px = ex + Math.cos(ang) * r, py = hy - 25 + Math.sin(ang) * r; a ? c.lineTo(px, py) : c.moveTo(px, py); }
    c.stroke();
  }
  c.fillStyle = INK; c.beginPath(); c.moveTo(hx - 16, hy - 12); c.quadraticCurveTo(hx, hy - 1, hx + 16, hy - 12); c.quadraticCurveTo(hx, hy - 6, hx - 16, hy - 12); c.fill();
  c.restore();
}

// ---------------------------------------------------------------- Count Dusk, for the final battle
// The same crescent-moon head and cloak as in the cutscenes (art.js drawDusk), grown into a sweeping cape with a slice of
// night sky for a lining, white gloves, and a pocket watch stopped at ten to midnight.
export function drawDuskBoss(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'angry';
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 40 * s, 0.26);
  c.scale(s * flip, s);
  c.translate(0, Math.sin(t * 1.5) * 4 - 14);
  const sway = Math.sin(t * 1.2) * 4;
  paper(c, p => {
    shape(c, p, cc => { cc.moveTo(-50 - sway, 2); cc.quadraticCurveTo(-58, -60, -30, -98); cc.lineTo(30, -98); cc.quadraticCurveTo(58, -60, 50 + sway, 2); cc.quadraticCurveTo(0, -10, -50 - sway, 2); cc.closePath(); }, vgrad(c, -98, 0, '#3b2f6a', '#140f26'));
    shape(c, p, cc => { cc.moveTo(-34, -6); cc.quadraticCurveTo(-36, -60, -18, -92); cc.lineTo(18, -92); cc.quadraticCurveTo(36, -60, 34, -6); cc.quadraticCurveTo(0, -16, -34, -6); cc.closePath(); }, vgrad(c, -92, -6, '#2c2350', '#0e0a1c'), 1.6);
    shape(c, p, poly([[-32, -94], [-46, -120], [-15, -102], [0, -112], [15, -102], [46, -120], [32, -94]]), '#4a3a80');
    shape(c, p, ell(-44 + Math.sin(t * 2) * 3, -58, 9, 9), '#ddd6fb');
    shape(c, p, ell(42, -64 + Math.sin(t * 2 + 1) * 3, 9, 9), '#ddd6fb');
    shape(c, p, cc => { cc.arc(0, -126, 22.4, 0.6, TAU - 0.6); cc.arc(12.6, -126, 16.8, TAU - 0.9, 0.9, true); cc.closePath(); }, '#ddd6fb');
  });
  // stars in the lining
  for (let i = 0; i < 7; i++) {
    const sx = -22 + hash(i) * 44, sy = -80 + hash(i + 9) * 66;
    c.globalAlpha = 0.5 + 0.5 * Math.sin(t * 3 + i); c.fillStyle = '#fff6c8';
    c.beginPath(); starPath(c, sx, sy, 3, 1.3, 4); c.fill();
  }
  c.globalAlpha = 1;
  // the pocket watch, swinging from his right glove
  const wa = Math.sin(t * 2.2) * 0.4, wx = 42 + Math.sin(wa) * 26, wy = -64 + Math.cos(wa) * 26;
  c.strokeStyle = '#c89a3c'; c.lineWidth = 2; c.beginPath(); c.moveTo(42, -60); c.lineTo(wx, wy); c.stroke();
  paper(c, p => { shape(c, p, ell(wx, wy + 8, 10, 10), '#f2c14e', 1.8); shape(c, p, ell(wx, wy + 8, 7, 7), PAPER, 1.2); });
  c.strokeStyle = INK; c.lineWidth = 1.4;
  c.beginPath(); c.moveTo(wx, wy + 8); c.lineTo(wx - 1.5, wy + 3); c.moveTo(wx, wy + 8); c.lineTo(wx - 4, wy + 6); c.stroke();
  // the red eyes (narrowed when he's cross, X when he's hit)
  for (const ex of [-8.4, 2.8]) {
    if (mood === 'hurt') { c.strokeStyle = '#ff5a6e'; c.lineWidth = 2.4; c.beginPath(); c.moveTo(ex - 3, -132); c.lineTo(ex + 3, -125); c.moveTo(ex + 3, -132); c.lineTo(ex - 3, -125); c.stroke(); continue; }
    glowDot(c, ex, -128.8, 10, '255,90,110', 0.7);
    c.fillStyle = '#ff5a6e'; c.beginPath(); c.ellipse(ex, -128.8, 2.8, mood === 'angry' ? 1.8 : 2.8, 0, 0, TAU); c.fill();
  }
  c.restore();
}

// ---------------------------------------------------------------- the Midnight Moor's clocks
// A grandfather clock. Stopped clocks are stuck at ten to midnight; a wound one (o.running) ticks and swings.
function grandfather(c, o, face) {
  const t = o.t || 0, run = !!o.running;
  paper(c, p => {
    shape(c, p, rrect(-20, -10, 40, 10, 3), '#5e3b24');
    shape(c, p, rrect(-16, -86, 32, 78, 4), vgrad(c, -86, -8, o.wood || '#a8743a', o.wood2 || '#6e4224'));
    shape(c, p, rrect(-9, -72, 18, 52, 8), '#2b2235', 1.6);
    shape(c, p, cc => { cc.moveTo(-22, -86); cc.lineTo(-22, -110); cc.quadraticCurveTo(0, -132, 22, -110); cc.lineTo(22, -86); cc.closePath(); }, vgrad(c, -128, -86, o.wood || '#b8844a', o.wood2 || '#7a4f2c'));
    shape(c, p, ell(0, -103, 15, 15), PAPER, 1.8);
  });
  // the pendulum behind its little window
  const sw = run ? Math.sin(t * 3.2) * 0.32 : 0.12;
  c.save(); c.beginPath(); c.rect(-8, -71, 16, 50); c.clip();
  c.translate(0, -70); c.rotate(sw);
  c.strokeStyle = '#c89a3c'; c.lineWidth = 2; c.beginPath(); c.moveTo(0, 0); c.lineTo(0, 36); c.stroke();
  c.fillStyle = run ? '#ffd23f' : '#9a8a5a'; c.beginPath(); c.arc(0, 40, 6, 0, TAU); c.fill();
  c.restore();
  if (run) glowDot(c, 0, -103, 30, '255,214,120', 0.25);
  if (face) return;
  // hands: ten to midnight, or ticking round
  const mins = run ? t * 0.8 : -0.5236, hrs = run ? t * 0.067 : -0.087;
  c.strokeStyle = INK; c.lineCap = 'round';
  c.lineWidth = 2.6; c.beginPath(); c.moveTo(0, -103); c.lineTo(Math.sin(hrs) * 7, -103 - Math.cos(hrs) * 7); c.stroke();
  c.lineWidth = 1.8; c.beginPath(); c.moveTo(0, -103); c.lineTo(Math.sin(mins) * 11, -103 - Math.cos(mins) * 11); c.stroke();
  c.fillStyle = INK; c.beginPath(); c.arc(0, -103, 1.8, 0, TAU); c.fill();
}

export function drawGClock(c, x, y, o = {}) {
  const s = o.scale || 1, flip = o.flip ?? 1;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 20 * s);
  c.scale(s * flip, s);
  if (o.tilt) c.rotate(o.tilt);
  grandfather(c, o, false);
  c.restore();
}

// Old Minute: the moor's oldest clock, with a face, droopy eyes and a magnificent white mustache.
export function drawMinute(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'normal';
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 22 * s);
  c.scale(s * flip, s);
  grandfather(c, { ...o, wood: '#8a5a3c', wood2: '#5a3a24' }, true);
  eyes(c, -5, 5, -107, 5.5, mood === 'normal' ? 'sleepy' : mood, t);
  paper(c, p => shape(c, p, cc => { cc.moveTo(0, -99); cc.quadraticCurveTo(-8, -103, -13, -96); cc.quadraticCurveTo(-7, -95, 0, -97); cc.quadraticCurveTo(7, -95, 13, -96); cc.quadraticCurveTo(8, -103, 0, -99); cc.closePath(); }, PAPER, 1.4));
  c.restore();
}

// one of Tick's lost gears, spinning slowly and twinkling
export function drawGear(c, x, y, t = 0) {
  glowDot(c, x, y - 18, 28, '255,214,120', 0.32 + 0.1 * Math.sin(t * 4));
  c.save(); c.translate(x, y - 18 + Math.sin(t * 3) * 3); c.rotate(t * 1.4);
  paper(c, p => shape(c, p, cc => {
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * TAU;
      for (const [r, da] of [[9, -0.3], [12.5, -0.17], [12.5, 0.17], [9, 0.3]]) {
        const px = Math.cos(a + da) * r, py = Math.sin(a + da) * r;
        if (i === 0 && da === -0.3) cc.moveTo(px, py); else cc.lineTo(px, py);
      }
    }
    cc.closePath();
  }, vgrad(c, -12, 12, '#ffe08a', '#d9a030'), 2));
  c.fillStyle = '#8a5a2a'; c.beginPath(); c.arc(0, 0, 3.4, 0, TAU); c.fill();
  c.restore();
}

// A pendulum swinging from (px, py) to its bob at (bx, by). Frozen by Time Stop, it goes pale and still.
export function drawPendulum(c, px, py, bx, by, r = 30, frozen = false) {
  c.lineCap = 'round';
  c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.moveTo(px, py); c.lineTo(bx, by); c.stroke();
  c.strokeStyle = frozen ? '#c8dcff' : '#c89a3c'; c.lineWidth = 4.5; c.beginPath(); c.moveTo(px, py); c.lineTo(bx, by); c.stroke();
  if (frozen) glowDot(c, bx, by, r * 1.8, '180,210,255', 0.45);
  paper(c, p => {
    shape(c, p, ell(bx, by, r, r), frozen ? vgrad(c, by - r, by + r, '#e8f0ff', '#9fb6e0') : vgrad(c, by - r, by + r, '#ffd770', '#b8781e'), 2.6);
    shape(c, p, ell(bx, by, r * 0.62, r * 0.62), frozen ? '#c8dcff' : '#e8a93a', 1.6);
    shape(c, p, ell(px, py, 7, 7), '#5a4e68', 2);
  });
  c.fillStyle = 'rgba(255,255,255,0.5)'; c.beginPath(); c.ellipse(bx - r * 0.35, by - r * 0.4, r * 0.22, r * 0.14, -0.6, 0, TAU); c.fill();
}

// Tick's birdcage, hanging from the ceiling on a chain. Its floor is at (x, y).
export function drawCage(c, x, y, open = false, t = 0) {
  const top = y - 92;
  c.strokeStyle = '#8a7aa8'; c.lineWidth = 3;
  c.beginPath(); c.moveTo(x, top - 18); c.lineTo(x, top - 420); c.stroke();
  paper(c, p => {
    shape(c, p, rrect(x - 40, y - 8, 80, 10, 4), '#c89a3c');
    shape(c, p, cc => { cc.moveTo(x - 36, top + 16); cc.quadraticCurveTo(x - 36, top - 14, x, top - 14); cc.quadraticCurveTo(x + 36, top - 14, x + 36, top + 16); cc.closePath(); }, '#c89a3c');
    shape(c, p, ell(x, top - 18, 6, 6), '#c89a3c');
  });
  c.strokeStyle = INK; c.lineWidth = 2.4;
  for (let i = 0; i <= 6; i++) {
    const bx = x - 33 + i * 11;
    if (open && i >= 4) continue;   // (the door swings out on the right)
    c.beginPath(); c.moveTo(bx, top + 14); c.lineTo(bx, y - 8); c.stroke();
  }
  if (open) {
    // the door, swung out sideways on its hinge (seen edge-on, so its bars bunch up)
    const swing = 8 + Math.sin(t * 2) * 1.5, y0 = top + 14, y1 = y - 8;
    c.strokeStyle = INK;
    for (let i = 1; i <= 3; i++) { c.beginPath(); c.moveTo(x + 33 + i * swing, y0 + i * 3); c.lineTo(x + 33 + i * swing, y1 - i * 3); c.stroke(); }
    c.beginPath(); c.moveTo(x + 33, y0); c.lineTo(x + 33 + 3 * swing, y0 + 9); c.moveTo(x + 33, y1); c.lineTo(x + 33 + 3 * swing, y1 - 9); c.stroke();
  } else {
    paper(c, p => shape(c, p, rrect(x + 26, y - 52, 14, 18, 3), '#ffd23f', 1.8));   // the lock
  }
}

// ---------------------------------------------------------------- scenery on the moor
DECOR_DRAW.deadtree = (c, t, x) => {
  const h = hash(x * 0.37), lean = (h - 0.5) * 0.24;
  c.save(); c.rotate(lean);
  paper(c, p => {
    shape(c, p, cc => { cc.moveTo(-10, 0); cc.quadraticCurveTo(-5, -70, -9, -122); cc.lineTo(-1, -126); cc.quadraticCurveTo(5, -72, 10, 0); cc.closePath(); }, vgrad(c, -126, 0, '#6e6488', '#4a4060'), 2);
    shape(c, p, poly([[-6, -70], [-40, -104], [-36, -110], [-3, -82]]), '#5e5478', 2);
    shape(c, p, poly([[2, -94], [34, -132], [39, -128], [6, -86]]), '#5e5478', 2);
    shape(c, p, poly([[-4, -112], [-22, -150], [-16, -152], [0, -118]]), '#5e5478', 2);
  });
  c.restore();
  void t;
};
DECOR_DRAW.mclock = (c, t, x) => drawGClock(c, 0, 0, { t, shadow: false, tilt: (hash(x * 0.71) - 0.5) * 0.3 });

// ---------------------------------------------------------------- skies and stages
function stars(c, W, top, bottom, t, n = 70) {
  for (let i = 0; i < n; i++) {
    const sx = hash(i * 1.7) * W, sy = top + hash(i * 3.1) * (bottom - top);
    c.globalAlpha = 0.35 + 0.45 * Math.sin(t * 1.6 + i * 2.1) ** 2;
    c.fillStyle = '#fff6dc'; c.beginPath(); starPath(c, sx, sy, 2.4 + (i % 3), 1, 4); c.fill();
  }
  c.globalAlpha = 1;
}

function sky3(c, H, a, b, d) {
  const g = c.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, a); g.addColorStop(0.55, b); g.addColorStop(1, d);
  return g;
}

function moon(c, x, y, r, t) {
  glowDot(c, x, y, r * 3, '230,215,255', 0.28 + 0.04 * Math.sin(t));
  c.fillStyle = '#f1eaff'; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill();
  c.fillStyle = 'rgba(200,185,235,0.6)';
  for (const [dx, dy, rr] of [[-0.3, -0.2, 0.18], [0.25, 0.25, 0.13], [0.1, -0.4, 0.09]]) { c.beginPath(); c.arc(x + dx * r, y + dy * r, rr * r, 0, TAU); c.fill(); }
}

function hillsBand(c, W, H, camX, f, base, amp, col, seed) {
  c.beginPath(); c.moveTo(0, H);
  for (let x = 0; x <= W + 16; x += 16) { const wx = x + camX * f; c.lineTo(x, base - amp * (0.6 * Math.sin(wx * 0.004 + seed) + 0.4 * Math.sin(wx * 0.011 + seed * 2.3))); }
  c.lineTo(W, H); c.closePath(); c.fillStyle = col; c.fill();
  c.strokeStyle = 'rgba(255,240,250,0.45)'; c.lineWidth = 3; c.stroke();
}

// the tower itself, crooked and huge, its clock face glowing at ten to midnight (or, once Dusk is beaten, running)
export function drawBigTower(c, x, base, k, t, freed = false) {
  c.save(); c.translate(x, base); c.scale(k, k);
  glowDot(c, 0, -330, 180, freed ? '255,214,120' : '150,80,220', 0.22 + 0.05 * Math.sin(t * 1.3));
  c.fillStyle = '#2e2150';
  c.beginPath(); c.moveTo(-70, 0); c.lineTo(-52, -260); c.lineTo(-76, -268); c.lineTo(-10, -420); c.lineTo(10, -404); c.lineTo(74, -268); c.lineTo(50, -260); c.lineTo(70, 0); c.closePath(); c.fill();
  c.fillStyle = '#261a44';
  c.fillRect(58, -190, 44, 190); c.beginPath(); c.moveTo(52, -190); c.lineTo(80, -250); c.lineTo(108, -190); c.closePath(); c.fill();
  c.fillRect(-112, -140, 40, 140); c.beginPath(); c.moveTo(-118, -140); c.lineTo(-92, -190); c.lineTo(-66, -140); c.closePath(); c.fill();
  c.strokeStyle = '#261a44'; c.lineWidth = 5; c.beginPath(); c.moveTo(-10, -420); c.lineTo(-12, -470); c.stroke();
  c.fillStyle = '#7b5fc7'; c.beginPath(); c.moveTo(-12, -470); c.lineTo(22 + Math.sin(t * 3) * 3, -462); c.lineTo(-12, -452); c.closePath(); c.fill();
  // the clock face
  const cy = -300;
  glowDot(c, 0, cy, 70, freed ? '255,224,140' : '220,190,255', 0.5);
  c.fillStyle = freed ? '#fff2c4' : '#e8dcff'; c.beginPath(); c.arc(0, cy, 38, 0, TAU); c.fill();
  c.strokeStyle = '#2e2150'; c.lineWidth = 4; c.stroke();
  const mins = freed ? t * 0.5 : -0.5236, hrs = freed ? t * 0.04 : -0.087;
  c.lineCap = 'round';
  c.lineWidth = 5; c.beginPath(); c.moveTo(0, cy); c.lineTo(Math.sin(hrs) * 18, cy - Math.cos(hrs) * 18); c.stroke();
  c.lineWidth = 3; c.beginPath(); c.moveTo(0, cy); c.lineTo(Math.sin(mins) * 30, cy - Math.cos(mins) * 30); c.stroke();
  c.fillStyle = freed ? '#ffd67a' : 'rgba(210,150,255,0.9)';
  for (const [wx, wy] of [[-14, -150], [16, -200], [-8, -240], [78, -130], [-92, -100], [10, -90]]) c.fillRect(wx - 5, wy - 9, 10, 15);
  c.restore();
}

// The Midnight Moor: always ten minutes to night. Indigo sky, a pink band where the sun almost was, a huge moon,
// dead purple hills, mist, and Count Dusk's Tower looming over everything.
// (How much sky shows depends on how far into the moor you are, so the tower and the moon fit whatever is visible.)
function skyTop(c) {
  try { return c.getTransform().inverse().transformPoint(new DOMPoint(0, 0)).y; } catch (e) { return 0; }
}
EXTRA_BACKDROPS.moor = (c, camX, W, H, t, opts) => {
  const top = Math.max(-300, Math.min(260, skyTop(c)));
  c.fillStyle = sky3(c, H, '#1a1236', '#4a2a62', '#c0647a'); c.fillRect(0, Math.min(0, top), W, H - Math.min(0, top));
  stars(c, W, top, 320, t);
  moon(c, 190 - camX * 0.015, Math.min(top + 64, 250), 42, t);
  hillsBand(c, W, H, camX, 0.03, 330, 24, '#3d2b5e', 1.1);
  drawBigTower(c, 690 - camX * 0.05, 340, Math.max(0.26, Math.min(0.8, (338 - top - 24) / 480)), t, opts && opts.freed);
  for (let i = 0; i < 4; i++) {
    const mx = ((i * 310 - camX * 0.08 + t * 8) % (W + 300) + W + 300) % (W + 300) - 150;
    c.fillStyle = 'rgba(230,200,240,0.16)'; c.beginPath(); c.ellipse(mx, 352 + i * 9, 170, 16, 0, 0, TAU); c.fill();
  }
  hillsBand(c, W, H, camX, 0.12, 372, 20, '#4b3870', 3.3);
  hillsBand(c, W, H, camX, 0.25, 400, 14, '#5a4682', 5.1);
};

// Inside the tower, behind a battle: stone, a giant clock face with turning gears, and purple torches.
EXTRA_BACKDROPS.towerstage = (c, camX, W, H, t, opts) => {
  c.fillStyle = vgrad(c, 0, H, '#2a2148', '#140f26'); c.fillRect(0, 0, W, H);
  c.strokeStyle = 'rgba(10,5,25,0.35)'; c.lineWidth = 2;
  for (let y = 20; y < H; y += 34) { c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); for (let x = ((y / 34) % 2) * 40; x < W; x += 80) { c.beginPath(); c.moveTo(x, y); c.lineTo(x, y + 34); c.stroke(); } }
  const cx = W / 2 - camX * 0.02, cy = 210;
  for (const [gx, gy, r, sp] of [[cx - 250, 120, 60, 0.4], [cx + 260, 150, 74, -0.3], [cx - 330, 300, 40, -0.7], [cx + 330, 320, 46, 0.6]]) {
    c.save(); c.translate(gx, gy); c.rotate(t * sp);
    c.fillStyle = 'rgba(200,154,60,0.35)';
    c.beginPath(); for (let i = 0; i < 24; i++) { const a = (i / 24) * TAU, rr = i % 2 ? r : r * 0.82; i ? c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr) : c.moveTo(Math.cos(a) * rr, Math.sin(a) * rr); } c.closePath(); c.fill();
    c.fillStyle = '#1c1530'; c.beginPath(); c.arc(0, 0, r * 0.3, 0, TAU); c.fill();
    c.restore();
  }
  glowDot(c, cx, cy, 240, '170,120,255', 0.18);
  c.fillStyle = '#e8dcff'; c.globalAlpha = 0.85; c.beginPath(); c.arc(cx, cy, 160, 0, TAU); c.fill(); c.globalAlpha = 1;
  c.strokeStyle = '#3b2f6a'; c.lineWidth = 10; c.beginPath(); c.arc(cx, cy, 160, 0, TAU); c.stroke();
  c.fillStyle = '#3b2f6a'; c.font = 'bold 24px Fredoka, sans-serif'; c.textAlign = 'center';
  ['XII', 'III', 'VI', 'IX'].forEach((n, i) => { const a = (i / 4) * TAU; c.fillText(n, cx + Math.sin(a) * 128, cy - Math.cos(a) * 128 + 8); });
  c.lineCap = 'round'; c.strokeStyle = '#3b2f6a';
  const frozen = !(opts && opts.freed), mins = frozen ? -0.5236 : t * 0.4, hrs = frozen ? -0.087 : t * 0.03;
  c.lineWidth = 12; c.beginPath(); c.moveTo(cx, cy); c.lineTo(cx + Math.sin(hrs) * 70, cy - Math.cos(hrs) * 70); c.stroke();
  c.lineWidth = 7; c.beginPath(); c.moveTo(cx, cy); c.lineTo(cx + Math.sin(mins) * 120, cy - Math.cos(mins) * 120); c.stroke();
  for (const tx of [90, W - 90]) {
    c.fillStyle = '#3b3350'; c.fillRect(tx - 6, 250, 12, 60);
    glowDot(c, tx, 236, 60, '190,120,255', 0.45);
    c.fillStyle = '#c49cff'; c.beginPath(); c.moveTo(tx, 212 - Math.abs(Math.sin(t * 7)) * 6); c.quadraticCurveTo(tx + 12, 236, tx, 250); c.quadraticCurveTo(tx - 12, 236, tx, 212); c.fill();
  }
};

// The very top of the tower: open sky, an enormous moon, and the tower's own clock face rising behind the platform.
EXTRA_BACKDROPS.dusktop = (c, camX, W, H, t, opts) => {
  const freed = opts && opts.freed;
  c.fillStyle = freed ? sky3(c, H, '#2a3a7a', '#7a6ab8', '#ffc9a0') : sky3(c, H, '#120c26', '#2e1d52', '#7a3a6e'); c.fillRect(0, 0, W, H);
  stars(c, W, 0, 300, t, 90);
  moon(c, 760 - camX * 0.01, 120, 70, t);
  // Lumenfold far, far below: little lights
  for (let i = 0; i < 40; i++) {
    const lx = ((hash(i * 2.3) * 1600 - camX * 0.05) % W + W) % W, ly = 390 + hash(i * 5.1) * 40;
    c.fillStyle = freed || i % 3 ? 'rgba(255,214,120,0.8)' : 'rgba(180,150,255,0.6)';
    c.beginPath(); c.arc(lx, ly, 1.6 + hash(i) * 1.6, 0, TAU); c.fill();
  }
  const cx = 480 - camX * 0.04, cy = 300;
  glowDot(c, cx, cy, 300, freed ? '255,224,150' : '170,120,255', 0.2);
  c.fillStyle = freed ? 'rgba(255,246,214,0.9)' : 'rgba(232,220,255,0.85)'; c.beginPath(); c.arc(cx, cy, 230, Math.PI, 0); c.fill();
  c.strokeStyle = '#3b2f6a'; c.lineWidth = 12; c.beginPath(); c.arc(cx, cy, 230, Math.PI, 0); c.stroke();
  c.fillStyle = '#3b2f6a'; c.font = 'bold 30px Fredoka, sans-serif'; c.textAlign = 'center';
  ['IX', 'X', 'XI', 'XII', 'I', 'II', 'III'].forEach((n, i) => { const a = -Math.PI / 2 + (i - 3) * (Math.PI / 6); c.fillText(n, cx + Math.sin(a + Math.PI / 2) * 190, cy - Math.cos(a + Math.PI / 2) * 190 + 10); });
  c.lineCap = 'round';
  const mins = freed ? t * 0.4 : -0.5236, hrs = freed ? t * 0.03 : -0.087;
  c.lineWidth = 16; c.beginPath(); c.moveTo(cx, cy); c.lineTo(cx + Math.sin(hrs) * 100, cy - Math.cos(hrs) * 100); c.stroke();
  c.lineWidth = 9; c.beginPath(); c.moveTo(cx, cy); c.lineTo(cx + Math.sin(mins) * 170, cy - Math.cos(mins) * 170); c.stroke();
};

// ---------------------------------------------------------------- floors, rooms and scenery sets
MAT.moor = { top: '#6f6a92', front: ['#4d4770', '#2f2a4a'], side: '#3c3659', floor: 'grass', lip: '#8580ad' };
MAT.dusktop = { top: '#8d86a8', front: ['#5a5378', '#37304f'], side: '#463f62', floor: 'tile' };
MAT.towerstage = MAT.dusktop;
STYLES.clocktower = { wall: ['#5d4f80', '#3b3156'], trim: '#c89a3c', pattern: 'bricks', pat: 'rgba(10,5,25,0.28)', mat: { top: '#8a7fa8', floor: 'tile' } };
FIELD_DECOR.moor = { dens: 0.3, kinds: [['deadtree', 3], ['rock', 3], ['tuft', 3], ['mushroom', 2], ['thorn', 1], ['mclock', 1]], edge: ['deadtree', 'deadtree', 'rock', 'mclock'], grove: ['deadtree', 'thorn'] };
DECOR_FOOT.deadtree = [14, 10, 130];
DECOR_FOOT.mclock = [18, 12, 120];

Object.assign(DRAW, {
  tick: drawTick, snoozer: drawSnoozer, notifly: drawNotifly, scrollbug: drawScrollbug, sandglass: drawSandglass,
  scrollwyrm: drawScrollwyrm, duskboss: drawDuskBoss, gclock: drawGClock, minute: drawMinute,
});
