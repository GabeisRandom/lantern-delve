// Chapter 5 art: The Unfinished Margin, the land past the edge of the world map. Queen Pristine erases anything that
// isn't perfect, so out here everything is still a pencil sketch, waiting to be colored in. Doodle the crayon (partner);
// the Draftees, the Margin's half-drawn folks; Captain Crease and his paper ferry; the Erasebits, Red Pens, Crumples and
// Straightedges; the Wastebasket; Queen Pristine herself; the Color Founts and the crayons you find; the Margin's
// scenery, its skies, the palace's rooms, and the stages. Importing this file adds them all.
import { DRAW, INK, PAPER, paper, shape, rrect, ell, poly, vgrad, glowDot, eyes, mouth, starPath, shadow } from './art.js';
import { MAT, STYLES, FIELD_DECOR, DECOR_FOOT, DECOR_DRAW, EXTRA_BACKDROPS } from './art2.js';

const TAU = Math.PI * 2;
const hash = n => { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };
const GOLD = ['#ffe08a', '#d9a030'];
const ERASER = ['#ffb3c4', '#ee7a96'];
const PENCIL = '#8a8794';                                  // graphite: the Margin's unfinished lines
const lead = a => `rgba(112,108,126,${a})`;                // fainter graphite, for shading and guide lines
const CRAYONS = ['#e5534b', '#ffb347', '#ffd23f', '#5fbf6a', '#5b8def', '#b07fe0', '#ff8ab0'];

// lighten (k > 0) or darken (k < 0) a '#rgb' / '#rrggbb' color
function tone(hex, k) {
  let h = String(hex || '').trim().replace('#', '');
  if (h.length === 3) h = h.split('').map(ch => ch + ch).join('');
  const n = parseInt(h, 16);
  if (h.length !== 6 || Number.isNaN(n)) return hex;
  const f = v => Math.round(k < 0 ? v * (1 + k) : v + (255 - v) * k);
  return `rgb(${f((n >> 16) & 255)},${f((n >> 8) & 255)},${f(n & 255)})`;
}
// '#rrggbb' -> 'r,g,b' (for glowDot)
function rgbOf(hex) {
  let h = String(hex || '').trim().replace('#', '');
  if (h.length === 3) h = h.split('').map(ch => ch + ch).join('');
  const n = parseInt(h, 16);
  if (h.length !== 6 || Number.isNaN(n)) return '255,236,190';
  return `${(n >> 16) & 255},${(n >> 8) & 255},${n & 255}`;
}
function blush(c, x, y, r = 3.5) {
  c.save(); c.fillStyle = 'rgba(255,120,150,0.45)';
  c.beginPath(); c.ellipse(x, y, r, r * 0.6, 0, 0, TAU); c.fill(); c.restore();
}

// ---------------------------------------------------------------- pencil, paper and crayon
// A shape that's still only pencil: the same paper border as an inked one, but a thin graphite outline, gone over twice.
function sketch(c, p, path, fill = PAPER, lw = 1.4) {
  c.beginPath(); path(c);
  if (p === 0) { c.lineWidth = lw + 7; c.strokeStyle = PAPER; c.fillStyle = PAPER; c.stroke(); c.fill(); return; }
  c.fillStyle = fill; c.fill();
  c.lineWidth = lw; c.strokeStyle = PENCIL; c.stroke();
  c.save(); c.translate(0.8, -0.6); c.globalAlpha *= 0.35; c.beginPath(); path(c); c.stroke(); c.restore();
}

// pencil shading: diagonal strokes inside a path, across the box x0..x1, y0..y1 (o.cross: both ways)
function hatch(c, path, x0, y0, x1, y1, o = {}) {
  const gap = o.gap || 4, h = y1 - y0;
  c.save();
  c.beginPath(); path(c); c.clip();
  c.beginPath(); c.rect(x0, y0, x1 - x0, h); c.clip();
  c.strokeStyle = o.color || lead(o.a ?? 0.3); c.lineWidth = o.lw || 1; c.lineCap = 'round';
  c.beginPath();
  for (let x = x0 - h; x < x1; x += gap) { c.moveTo(x, y1); c.lineTo(x + h, y0); }
  if (o.cross) for (let x = x0; x < x1 + h; x += gap * 1.3) { c.moveTo(x, y1); c.lineTo(x - h, y0); }
  c.stroke();
  c.restore();
}

// notebook paper: pale blue lines every `gap`, and (at mx) the red margin line, across x0..x1, y0..y1
function ruled(c, x0, y0, x1, y1, gap, mx = null, a = 1) {
  c.lineWidth = 1;
  c.strokeStyle = `rgba(96,146,222,${0.42 * a})`;
  c.beginPath(); for (let yy = y0 + gap * 0.7; yy < y1; yy += gap) { c.moveTo(x0, yy); c.lineTo(x1, yy); } c.stroke();
  if (mx != null) { c.strokeStyle = `rgba(229,83,75,${0.5 * a})`; c.lineWidth = 1.3; c.beginPath(); c.moveTo(mx, y0); c.lineTo(mx, y1); c.stroke(); }
}

// colored in with a crayon: quick back-and-forth strokes, clipped to a path (across the box x0, y0 to x1, y1)
function crayonFill(c, path, x0, y0, x1, y1, color, a = 0.85, gap = 3.6, seed = 0) {
  c.save(); c.beginPath(); path(c); c.clip();
  c.globalAlpha *= a; c.strokeStyle = color; c.lineWidth = gap * 1.15; c.lineJoin = 'round'; c.lineCap = 'round';
  c.beginPath(); c.moveTo(x0 - 4, y0 - 4);
  for (let yy = y0 - 4, i = 0; yy < y1 + 6; yy += gap, i++) c.lineTo(i % 2 ? x0 - 4 + hash(seed + i * 0.37) * 6 : x1 + 4 - hash(seed + i * 0.37) * 6, yy + gap);
  c.stroke();
  c.restore();
}

// eraser crumbs (pink, or grey with the pencil they rubbed out)
function crumb(c, x, y, r, seed, col = '#f6a6ba') {
  c.fillStyle = col; c.strokeStyle = 'rgba(43,34,53,0.5)'; c.lineWidth = 1;
  c.beginPath();
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * TAU + seed, rr = r * (0.7 + hash(seed * 3.3 + i) * 0.5);
    const px = x + Math.cos(a) * rr, py = y + Math.sin(a) * rr * 0.8;
    if (i) c.lineTo(px, py); else c.moveTo(px, py);
  }
  c.closePath(); c.fill(); c.stroke();
}

// A crumpled-up ball of notebook paper around (x, y), radius r (seed picks its shape, sy squashes it, wob rustles it).
// Every facet catches the light its own way, and its lines run their own way.
function crumpleBall(c, x, y, r, seed, o = {}) {
  const n = 11, sy = o.sy || 1, wob = o.wob || 0, pts = [];
  for (let i = 0; i < n; i++) {
    const a = (i / n) * TAU + seed * 0.7, rr = r * (0.84 + hash(seed * 7.3 + i * 1.91) * 0.26) + (wob ? Math.sin(wob + i * 2.1) * 0.5 : 0);
    pts.push([x + Math.cos(a) * rr, y + Math.sin(a) * rr * sy]);
  }
  const outline = poly(pts);
  paper(c, p => shape(c, p, outline, vgrad(c, y - r, y + r, '#fffdf6', '#e2dbca'), o.lw ?? 2));
  const cx = x + (hash(seed + 2) - 0.5) * r * 0.5, cy = y + (hash(seed + 5) - 0.5) * r * 0.5;
  const cuts = [0, 3, 5, 8, 11];
  c.save(); c.beginPath(); outline(c); c.clip();
  for (let f = 0; f < cuts.length - 1; f++) {
    c.save();
    c.beginPath(); c.moveTo(cx, cy);
    for (let i = cuts[f]; i <= cuts[f + 1]; i++) c.lineTo(pts[i % n][0], pts[i % n][1]);
    c.closePath(); c.clip();
    c.fillStyle = f % 2 ? 'rgba(90,80,120,0.1)' : 'rgba(255,255,255,0.4)'; c.fillRect(x - r * 1.3, y - r * 1.3, r * 2.6, r * 2.6);
    c.translate(cx, cy); c.rotate((hash(seed * 3 + f) - 0.5) * 1.8);
    ruled(c, -r * 1.6, -r * 1.6, r * 1.6, r * 1.6, Math.max(3, r * 0.3), f === 1 ? r * 0.3 : null, 0.85);
    c.restore();
  }
  c.strokeStyle = 'rgba(43,34,53,0.3)'; c.lineWidth = 1.1; c.lineJoin = 'round';
  c.beginPath();
  for (let f = 0; f < cuts.length - 1; f++) {
    const [px, py] = pts[cuts[f]];
    c.moveTo(cx, cy);
    c.lineTo((cx + px) / 2 + (hash(seed + f * 2) - 0.5) * r * 0.25, (cy + py) / 2 + (hash(seed + f * 2 + 1) - 0.5) * r * 0.25);
    c.lineTo(px, py);
  }
  c.stroke();
  c.restore();
  return pts;
}

// ---------------------------------------------------------------- Doodle, the crayon (partner)
// A stubby wax crayon in a paper wrapper, its sharpened tip worn a little flat on top, like a hat. Shy, but bright.
// o.state: 'walk' (with o.phase), 'jump' (stretched right out), 'scribble' (arms going like mad). o.color: other crayons.
export function drawDoodle(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'normal', col = o.color || '#5b8def';
  const st = o.state || 'idle', walk = st === 'walk', air = st === 'jump', scrib = st === 'scribble';
  const step = walk ? Math.sin((o.phase || 0) * TAU) : 0;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 13 * s);
  c.scale(s * flip, s);
  c.rotate(walk ? step * 0.07 : scrib ? Math.sin(t * 19) * 0.05 : 0);
  c.translate(0, walk ? -Math.abs(step) * 2.6 : scrib ? -Math.abs(Math.sin(t * 19)) * 1.2 : Math.sin(t * 2.6) * 0.7);
  if (air) c.scale(0.88, 1.14);   // stretched out, mid-jump
  const fL = walk ? Math.max(0, step) * 3.5 : air ? 4.5 : 0, fR = walk ? Math.max(0, -step) * 3.5 : air ? 2.5 : 0;
  // the little arms (0 = hanging straight down)
  let aL = 0.55 + Math.sin(t * 2.6) * 0.07, aR = -0.55 - Math.sin(t * 2.6 + 1) * 0.07;
  if (walk) { aL = 0.5 - step * 0.45; aR = -0.5 - step * 0.45; }
  if (air) { aL = 2.45; aR = -2.45; }
  if (scrib) { aL = 1.2 + Math.sin(t * 47) * 0.75; aR = -1.35 + Math.sin(t * 41 + 1.3) * 0.9; }
  const hand = (sx, a) => [sx * 11.5 - Math.sin(a) * 6.5, -22 + Math.cos(a) * 6.5];
  const [lx, ly] = hand(-1, aL), [rx, ry] = hand(1, aR);
  const skin = tone(col, 0.18);
  paper(c, p => {
    shape(c, p, ell(-6 + step * 2.5, -2.5 - fL, 5.2, 3.2), tone(col, -0.45));
    shape(c, p, ell(6 - step * 2.5, -2.5 - fR, 5.2, 3.2), tone(col, -0.45));
    shape(c, p, ell(lx, ly, 3.6, 3.9), skin);
    shape(c, p, rrect(-12, -33, 24, 31, 4), vgrad(c, -33, -2, tone(col, 0.22), tone(col, -0.2)));
    shape(c, p, poly([[-12, -31.5], [-2.6, -46], [2.6, -46], [12, -31.5]]), vgrad(c, -46, -31, tone(col, 0.38), col));
    shape(c, p, rrect(-13.2, -15.5, 26.4, 11.5, 2.5), '#fff4dc', 2);
    shape(c, p, ell(rx, ry, 3.6, 3.9), skin);
  });
  // a shine on the wax; the wrapper's zigzags and its little color mark
  c.fillStyle = 'rgba(255,255,255,0.3)';
  c.beginPath(); rrect(-9.5, -30, 3.2, 13, 1.6)(c); c.fill();
  c.beginPath(); c.moveTo(-9, -32.5); c.lineTo(-2.2, -44); c.lineTo(-0.6, -44); c.lineTo(-5.6, -32.5); c.closePath(); c.fill();
  c.strokeStyle = col; c.lineWidth = 1.2; c.lineJoin = 'round'; c.lineCap = 'round';
  c.beginPath();
  for (const zy of [-13.2, -6.6]) for (let i = 0; i <= 9; i++) { const zx = -11.6 + i * 2.58, yy = zy + (i % 2 ? 0.9 : -0.9); if (i) c.lineTo(zx, yy); else c.moveTo(zx, yy); }
  c.stroke();
  c.strokeStyle = tone(col, -0.25); c.lineWidth = 1.5;
  c.beginPath(); c.moveTo(-6, -9.6);
  for (let i = 1; i <= 14; i++) { const a = i * 1.1; c.lineTo(-6 + i * 0.85 + Math.cos(a) * 1.5, -9.9 + Math.sin(a) * 1.2); }
  c.stroke();
  // big shy-but-bright eyes (with an extra glint), pink cheeks
  const ey = -25;
  eyes(c, -4.5, 5, ey, 8.5, mood, t);
  if (!['happy', 'proud', 'sleep', 'sleepy', 'hurt'].includes(mood) && t % 3.7 >= 0.12) {
    c.fillStyle = '#fff';
    for (const ex of [-4.5, 5]) { c.beginPath(); c.arc(ex - 0.7, ey + 2.1, 0.75, 0, TAU); c.fill(); }
  }
  blush(c, -8.6, -19.6, 3); blush(c, 9.2, -19.6, 3);
  mouth(c, 0.4, -19.2, 4.2, mood);
  // scribbles flying off the busy hand
  if (scrib) {
    const a0 = c.globalAlpha;
    c.strokeStyle = col; c.lineWidth = 1.6;
    for (let i = 0; i < 3; i++) {
      const k = (t * 2.6 + i / 3) % 1, sx = rx + 4 + k * 13, sy = ry - 5 - i * 3.5 - k * 5;
      c.globalAlpha = a0 * (1 - k);
      c.beginPath(); c.moveTo(sx, sy);
      for (let j = 1; j <= 6; j++) c.lineTo(sx + j * 1.6, sy + (j % 2 ? -2.2 : 2.2));
      c.stroke();
    }
    c.globalAlpha = a0;
  }
  c.restore();
}

// ---------------------------------------------------------------- the Draftees: folks of the Margin
// Round little paper folks who were never finished: white paper, pencil lines, the construction lines still showing.
// o.colored fills them in like any other folk (o.color: body, o.color2: clothes). o.hat: 'none' | 'beret' | 'cap' |
// 'bow' | 'crown' (o.hatColor changes its color). o.seed staggers their idle bobbing.
export function drawDraftee(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'normal';
  const done = !!o.colored, col = o.color || '#ff9ab0', col2 = o.color2 || '#7fb2e6', hat = o.hat || 'none';
  const walk = o.state === 'walk', step = walk ? Math.sin((o.phase || 0) * TAU) : 0;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 15 * s);
  c.scale(s * flip, s);
  c.translate(0, walk ? -Math.abs(step) * 2.5 : Math.sin(t * 2 + (o.seed || 0)) * 0.8);
  const part = (p, path, fill, lw = 2.2) => (done ? shape(c, p, path, fill, lw) : sketch(c, p, path, PAPER, 1.3));
  const head = ell(0, -41, 15.5, 14.5), body = ell(0, -16, 13, 13.2);
  paper(c, p => {
    part(p, ell(-6 + step * 2.5, -2.6, 5.4, 3.2), tone(col2, -0.4));
    part(p, ell(6 - step * 2.5, -2.6, 5.4, 3.2), tone(col2, -0.4));
    part(p, ell(-14, -15 + step * 2, 4.3, 4.8), col);
    part(p, ell(14, -15 - step * 2, 4.3, 4.8), col);
    part(p, body, vgrad(c, -29, -3, tone(col2, 0.3), col2));
    part(p, ell(-4.8, -26.8, 5.2, 2.8, 0.15), PAPER, 1.8);
    part(p, ell(4.8, -26.8, 5.2, 2.8, -0.15), PAPER, 1.8);
    part(p, head, vgrad(c, -55, -27, tone(col, 0.35), col));
  });
  if (done) {
    c.fillStyle = 'rgba(255,255,255,0.45)'; c.beginPath(); c.ellipse(-6, -48, 4.5, 2.6, -0.5, 0, TAU); c.fill();
    c.fillStyle = PAPER; c.strokeStyle = INK; c.lineWidth = 1.2;
    for (const by of [-19, -11.5]) { c.beginPath(); c.arc(0, by, 1.7, 0, TAU); c.fill(); c.stroke(); }
    blush(c, -9, -35); blush(c, 10, -35);
    eyes(c, -4.5, 5.5, -42, 7.5, mood, t);
    mouth(c, 0.5, -34.5, 5, mood);
  } else {
    // pencil shading, and the guide lines it was drawn with
    hatch(c, head, 3, -56, 16, -26, { gap: 3.4, a: 0.26 });
    hatch(c, body, 2, -30, 14, -2, { gap: 3.4, a: 0.24 });
    c.strokeStyle = lead(0.36); c.lineWidth = 0.9; c.lineCap = 'round';
    c.beginPath();
    c.moveTo(0.8, -59); c.quadraticCurveTo(2.6, -41, 0.6, -24);              // the head's center line
    c.moveTo(15.5, -43.5); c.ellipse(0, -43.5, 15.5, 3.6, 0, 0, Math.PI);    // the line the eyes sit on
    c.moveTo(0, -29); c.lineTo(0.4, 3);                                       // the body's center line
    c.moveTo(-20, 0.6); c.lineTo(20, 0.6);                                    // the ground
    c.stroke();
    c.beginPath(); c.arc(1.6, -40, 18.5, -2.6, 0.45); c.stroke();             // a guide circle, a size too big
    c.save(); c.globalAlpha *= 0.72;
    eyes(c, -4.5, 5.5, -42, 7.5, mood, t);
    mouth(c, 0.5, -34.5, 5, mood);
    c.restore();
  }
  if (hat && hat !== 'none') {
    const hc = o.hatColor || { beret: '#e5534b', cap: '#ffd23f', bow: '#b49cff', crown: '#ffd23f' }[hat] || '#e5534b';
    paper(c, p => {
      if (hat === 'beret') {
        part(p, ell(-1.5, -54, 14.5, 5.4, -0.16), hc);
        part(p, ell(-3, -60.2, 2.2, 2.6), tone(hc, -0.25), 1.8);
      } else if (hat === 'cap') {
        part(p, cc => { cc.moveTo(-13, -50); cc.quadraticCurveTo(-13.5, -64, 0, -64.5); cc.quadraticCurveTo(13.5, -64, 13, -50); cc.closePath(); }, hc);
        part(p, ell(15.5, -50.5, 9, 2.6), tone(hc, -0.25), 2);
      } else if (hat === 'bow') {
        part(p, poly([[5, -54], [-4, -61], [-3, -47.5]]), hc, 2);
        part(p, poly([[5, -54], [14, -62], [14.5, -47]]), hc, 2);
        part(p, ell(5, -54.5, 3, 3), tone(hc, -0.25), 1.8);
      } else if (hat === 'crown') {
        part(p, poly([[-11, -52], [-11.5, -65], [-5, -58.5], [0, -68.5], [5, -58.5], [11.5, -65], [11, -52]]), hc, 2);
      }
    });
  }
  c.restore();
}

// ---------------------------------------------------------------- Captain Crease, the ferryman
// Folded out of a single sheet of notebook paper into a paper boat (the hull for a body, the peak for a head), in a
// captain's cap, with a red neckerchief that never stops flapping in the breeze.
export function drawCrease(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'happy';
  const walk = o.state === 'walk', step = walk ? Math.sin((o.phase || 0) * TAU) : 0;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 24 * s);
  c.scale(s * flip, s);
  c.translate(0, walk ? -Math.abs(step) * 2.5 : 0);
  c.rotate(walk ? step * 0.05 : Math.sin(t * 1.3) * 0.035);   // he sways like a boat at anchor
  const wave = walk ? step * 2 : Math.sin(t * 2.4) * 1.5, flap = Math.sin(t * 6);
  const hull = poly([[-33, -26], [33, -26], [21, -5], [-21, -5]]), peak = poly([[-21, -25], [0, -61], [21, -25]]);
  paper(c, p => {
    shape(c, p, ell(-9 + step * 3, -2.6, 6.5, 3.4), '#2f3e6e');
    shape(c, p, ell(9 - step * 3, -2.6, 6.5, 3.4), '#2f3e6e');
    shape(c, p, peak, vgrad(c, -61, -25, '#fffdf6', '#efe7d6'));
    shape(c, p, hull, vgrad(c, -26, -5, '#fffaf0', '#e6ddc9'));
    shape(c, p, ell(-34, -22 + wave * 0.3, 4.6, 4.6), '#fdf6e6');
    shape(c, p, ell(35, -26 - wave, 4.6, 4.6), '#fdf6e6');
  });
  // the notebook paper he's folded from, and his folds
  for (const [path, y0, y1, mx] of [[peak, -61, -25, null], [hull, -26, -5, -25]]) {
    c.save(); c.beginPath(); path(c); c.clip(); ruled(c, -34, y0, 34, y1, 5.2, mx, 0.8); c.restore();
  }
  c.strokeStyle = 'rgba(43,34,53,0.28)'; c.lineWidth = 1.2; c.lineCap = 'round';
  c.beginPath(); c.moveTo(-21, -25.5); c.lineTo(-11, -5.5); c.moveTo(21, -25.5); c.lineTo(11, -5.5); c.stroke();
  // the neckerchief
  paper(c, p => {
    shape(c, p, poly([[1, -27], [-3 + flap, -16], [4, -18.5]]), '#e5534b', 1.8);
    shape(c, p, poly([[6, -27], [12 + flap * 1.5, -17.5], [14, -22.5]]), '#d8443c', 1.8);
    shape(c, p, ell(4, -26.5, 4, 3), '#e5534b', 1.8);
  });
  eyes(c, -4, 6, -39, 7.5, mood, t);
  blush(c, -8.5, -32); blush(c, 11, -32);
  mouth(c, 1, -32, 6.5, mood);
  // the captain's cap
  paper(c, p => {
    shape(c, p, cc => { cc.moveTo(-10, -57); cc.quadraticCurveTo(-13, -68.5, 0, -69.5); cc.quadraticCurveTo(13, -68.5, 10, -57); cc.closePath(); }, '#fffdf8', 2);
    shape(c, p, rrect(-10.5, -61, 21, 4, 1.5), '#2f3e6e', 1.6);
    shape(c, p, ell(3, -56.5, 12.5, 2.6), '#1f2a4e', 1.8);
  });
  c.fillStyle = '#ffd23f'; c.strokeStyle = INK; c.lineWidth = 1;
  c.beginPath(); starPath(c, 0, -64.8, 3.1, 1.4, 5); c.fill(); c.stroke();
  c.restore();
}

// ---------------------------------------------------------------- the Margin's troublemakers
// An Erasebit: a grumpy pink rubber eraser that scuttles about on stubby legs, rubbing out whatever it finds and
// shedding crumbs wherever it goes.
export function drawErasebit(c, x, y, o = {}) {
  const t = o.t || 0, s = (o.scale || 1) * (o.small ? 0.72 : 1), flip = o.flip ?? 1, mood = o.mood || 'angry';
  const walk = o.state === 'walk', sc = walk ? Math.sin((o.phase || 0) * TAU * 2) : 0;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 22 * s);
  c.scale(s * flip, s);
  // the crumbs it leaves behind (and a couple more falling off its back end)
  for (let i = 0; i < 4; i++) crumb(c, -25 - i * 5.5 - hash(i) * 3, -1.2 - hash(i + 4) * 1.2, 1.7 + hash(i + 8) * 1.1, i * 1.7, i % 3 ? '#f6a6ba' : '#bcb6c8');
  const a0 = c.globalAlpha;
  for (let i = 0; i < 2; i++) {
    const k = (t * (walk ? 2.2 : 0.7) + i * 0.5) % 1;
    c.globalAlpha = a0 * Math.min(1, (1 - k) * 3);
    crumb(c, -21 - k * 5, -9 + k * 8, 1.5, i + 3);
  }
  c.globalAlpha = a0;
  c.translate(0, walk ? -Math.abs(sc) * 2 : Math.sin(t * 3) * 0.5);
  c.rotate(walk ? sc * 0.03 : 0);
  paper(c, p => {
    for (const [lx, k] of [[-15, 1], [-6, -1], [5, 1], [14, -1]]) {
      const lift = walk ? Math.max(0, sc * k) * 2.4 : 0;
      shape(c, p, rrect(lx - 2.6 + sc * k * 1.6, -10, 5.2, 10 - lift, 2.4), '#c95a74', 1.8);
    }
    shape(c, p, rrect(-21, -31, 42, 23, 7), vgrad(c, -31, -8, ERASER[0], ERASER[1]));
    shape(c, p, rrect(-14, -32.6, 15, 26.2, 2), vgrad(c, -33, -6, '#5d8fe6', '#3b6cc4'), 2);
  });
  // the sleeve's white stripe and its little print; the worn front; the pencil it has rubbed out
  c.fillStyle = '#fffaf0'; c.fillRect(-13, -23.2, 13, 6.4);
  c.fillStyle = '#3b6cc4'; for (let k = 0; k < 4; k++) c.fillRect(-11.6 + k * 3.1, -21, 2, 1.8);
  c.fillStyle = 'rgba(255,255,255,0.4)'; c.beginPath(); c.ellipse(13, -27, 5, 2.2, -0.2, 0, TAU); c.fill();
  c.fillStyle = 'rgba(80,76,96,0.22)'; c.beginPath(); c.ellipse(9, -11.5, 9, 2, 0, 0, TAU); c.fill();
  // feelers
  const wv = Math.sin(t * 5) * 1.2;
  c.strokeStyle = INK; c.lineWidth = 1.6; c.lineCap = 'round';
  c.beginPath(); c.moveTo(9, -30.5); c.quadraticCurveTo(9.5, -35.5, 13.5 + wv, -36.5); c.moveTo(14.5, -30.5); c.quadraticCurveTo(16.5, -34.5, 20.5 + wv, -34); c.stroke();
  c.fillStyle = '#6b6680';
  for (const [fx, fy] of [[13.5 + wv, -36.5], [20.5 + wv, -34]]) { c.beginPath(); c.arc(fx, fy, 1.8, 0, TAU); c.fill(); }
  eyes(c, 7, 14.5, -20.5, 6.5, mood, t);
  mouth(c, 11, -13.5, 4, ['hurt', 'sleep', 'sleepy', 'happy'].includes(mood) ? mood : 'angry');
  c.restore();
}

// A Red Pen: a ballpoint soldier standing to attention on its nib. Its cap is a helmet (the clip makes a fine plume),
// there's a big red ✗ on its chest, and it hops about on that nib marking everything wrong.
export function drawRedpen(c, x, y, o = {}) {
  const t = o.t || 0, s = (o.scale || 1) * (o.small ? 0.72 : 1), flip = o.flip ?? 1, mood = o.mood || 'angry';
  const walk = o.state === 'walk', ph = (o.phase || 0) * TAU, hop = walk ? Math.abs(Math.sin(ph)) * 8 : 0;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 12 * s * (1 - hop / 24));
  c.scale(s * flip, s);
  if (walk) {   // red dots where it has landed
    c.fillStyle = 'rgba(214,58,58,0.5)';
    for (let i = 1; i <= 3; i++) { c.beginPath(); c.ellipse(-i * 9, 0.4, 2.4 - i * 0.45, 1, 0, 0, TAU); c.fill(); }
  }
  c.translate(0, -hop);
  c.rotate(walk ? Math.cos(ph) * 0.06 : Math.sin(t * 2.2) * 0.02);
  const arm = walk ? Math.sin(ph) * 2 : Math.sin(t * 3) * 0.6;
  paper(c, p => {
    shape(c, p, poly([[-1.8, -2.2], [1.8, -2.2], [6, -12.5], [-6, -12.5]]), vgrad(c, -12.5, -2, '#eceaf2', '#9ea3b5'), 1.8);
    shape(c, p, ell(0, -1.8, 1.9, 1.9), '#c03030', 1.4);
    shape(c, p, ell(-11.5, -22 + arm, 3.4, 4), '#e5534b');
    shape(c, p, ell(11.5, -22 - arm, 3.4, 4), '#e5534b');
    shape(c, p, rrect(-8.5, -45, 17, 34, 5), vgrad(c, -45, -11, '#fffdf8', '#dcd6ca'));
    shape(c, p, cc => { cc.moveTo(-2.5, -55); cc.quadraticCurveTo(-4.5, -63.5, -13, -65.5); cc.quadraticCurveTo(-9.5, -60, -7, -55); cc.closePath(); }, '#c83a34', 1.8);
    shape(c, p, rrect(-10, -57, 20, 15.5, 6), vgrad(c, -57, -41.5, '#ff7a6e', '#d63a3a'));
    shape(c, p, rrect(-10.6, -45, 21.2, 4, 2), '#a82a2a', 1.8);
  });
  // the barrel's facets and grip, a shine on the helmet
  c.strokeStyle = 'rgba(43,34,53,0.13)'; c.lineWidth = 1.2;
  c.beginPath(); c.moveTo(-4.2, -40); c.lineTo(-4.2, -12); c.moveTo(4.2, -40); c.lineTo(4.2, -12); c.stroke();
  c.strokeStyle = 'rgba(43,34,53,0.3)';
  c.beginPath(); c.moveTo(-8, -15); c.lineTo(8, -15); c.moveTo(-8, -13); c.lineTo(8, -13); c.stroke();
  c.fillStyle = 'rgba(255,255,255,0.45)'; c.beginPath(); c.ellipse(-5, -52, 2.4, 1.4, -0.4, 0, TAU); c.fill();
  // the big red ✗
  c.lineCap = 'round'; c.strokeStyle = '#d63a3a'; c.lineWidth = 3.4;
  c.beginPath(); c.moveTo(-5, -27.5); c.lineTo(5, -16.5); c.moveTo(5, -27.5); c.lineTo(-5, -16.5); c.stroke();
  eyes(c, -3.5, 4.5, -36.5, 6, mood, t);
  mouth(c, 0.5, -31, 3.8, mood);
  c.restore();
}

// A Crumple: a sheet of notebook paper that got scrunched up and thrown away, and is still cross about it. Its eyes
// peek out from between the folds. Smoothed out (o.smooth) it's a much flatter, calmer sheet.
export function drawCrumple(c, x, y, o = {}) {
  const t = o.t || 0, s = (o.scale || 1) * (o.small ? 0.72 : 1), flip = o.flip ?? 1, mood = o.mood || 'angry';
  const walk = o.state === 'walk', ph = (o.phase || 0) * TAU, smooth = !!o.smooth;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, (smooth ? 23 : 18) * s);
  c.scale(s * flip, s);
  c.translate(0, walk ? -Math.abs(Math.sin(ph)) * (smooth ? 4 : 6) : 0);
  if (smooth) {
    c.rotate(walk ? Math.sin(ph) * 0.08 : 0);
    const pts = [];
    for (let i = 0; i < 16; i++) {
      const a = (i / 16) * TAU, k = 1 + (hash(i * 3.1 + 0.5) - 0.5) * 0.09;
      pts.push([Math.cos(a) * 22 * k, -13.5 + Math.sin(a) * 13 * k + Math.sin(t * (walk ? 9 : 2) + i) * 0.4]);
    }
    const sheet = poly(pts);
    paper(c, p => shape(c, p, sheet, vgrad(c, -27, 0, '#fffdf6', '#e9e3d4')));
    c.save(); c.beginPath(); sheet(c); c.clip();
    ruled(c, -24, -27, 24, 0, 4.4, -13);
    c.strokeStyle = 'rgba(43,34,53,0.16)'; c.lineWidth = 1.2;
    c.beginPath(); c.moveTo(-3, -27); c.lineTo(-1, 0); c.moveTo(-23, -15); c.lineTo(23, -12); c.stroke();
    c.restore();
    eyes(c, 1, 10, -16, 7, mood, t);
    mouth(c, 5.5, -9, 5, mood);
    c.restore();
    return;
  }
  c.translate(0, -19); c.rotate(walk ? Math.sin(ph) * 0.35 : Math.sin(t * 1.5) * 0.05); c.translate(0, 19);
  crumpleBall(c, 0, -19, 18.5, 3.7, { wob: t * 3 });
  // the gap between its folds, and the eyes peeking out of it
  const gap = poly([[-3.5, -24.5], [3.5, -28.4], [14, -26.6], [17, -18.4], [10.5, -12.6], [-1, -14.6]]);
  c.fillStyle = '#3a3046'; c.beginPath(); gap(c); c.fill();
  c.strokeStyle = INK; c.lineWidth = 1.6; c.lineJoin = 'round'; c.stroke();
  const shut = ['sleep', 'sleepy', 'happy', 'hurt'].includes(mood) || t % 3.7 < 0.12;
  c.lineCap = 'round';
  for (const ex of [3.6, 10.6]) {
    c.strokeStyle = '#fffaf0'; c.lineWidth = 1.8;
    if (mood === 'hurt') { c.beginPath(); c.moveTo(ex - 2.2, -22.2); c.lineTo(ex + 2.2, -17.8); c.moveTo(ex + 2.2, -22.2); c.lineTo(ex - 2.2, -17.8); c.stroke(); }
    else if (mood === 'happy') { c.beginPath(); c.arc(ex, -18.6, 2.4, Math.PI * 1.15, Math.PI * 1.85); c.stroke(); }
    else if (shut) { c.beginPath(); c.moveTo(ex - 2.4, -20); c.lineTo(ex + 2.4, -20); c.stroke(); }
    else {
      c.fillStyle = '#fffaf0'; c.beginPath(); c.ellipse(ex, -20, 2.8, 3.4, 0, 0, TAU); c.fill();
      c.fillStyle = INK; c.beginPath(); c.ellipse(ex + 0.7, -19.6, 1.5, 2, 0, 0, TAU); c.fill();
      c.fillStyle = '#fff'; c.beginPath(); c.arc(ex + 1.1, -20.6, 0.6, 0, TAU); c.fill();
    }
  }
  // and a fold of paper comes down over them like a brow
  if (!shut || mood === 'hurt') {
    const side = mood === 'worried' ? -21.2 : -23.2, mid = mood === 'angry' ? -20.4 : mood === 'worried' ? -24.4 : -23.2;
    const flapPts = [[-4, -25.2], [3.5, -29.4], [14.6, -27.4], [17.6, side], [7.2, mid], [-2.2, side - 0.2]];
    c.fillStyle = '#f2ede0'; c.beginPath(); poly(flapPts)(c); c.fill();
    c.strokeStyle = INK; c.lineWidth = 1.5; c.lineJoin = 'round';
    c.beginPath(); c.moveTo(17.6, side); c.lineTo(7.2, mid); c.lineTo(-2.2, side - 0.2); c.stroke();
  }
  c.restore();
}

// A Straightedge: a wooden ruler who has never once been bent. Inch marks down his side, a monocle, a mustache he
// drew with himself, and a sharpened pencil carried like a lance. Very, very upright.
export function drawStraightedge(c, x, y, o = {}) {
  const t = o.t || 0, s = (o.scale || 1) * (o.small ? 0.72 : 1), flip = o.flip ?? 1, mood = o.mood || 'angry';
  const walk = o.state === 'walk', step = walk ? Math.sin((o.phase || 0) * TAU) : 0;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 17 * s);
  c.scale(s * flip, s);
  c.translate(0, walk ? -Math.abs(step) * 3 : 0);   // marching: straight up and down, never a wobble
  const couch = walk ? Math.abs(step) * 0.08 : Math.sin(t * 1.6) * 0.04;
  paper(c, p => {
    shape(c, p, rrect(-10, -6 - Math.max(0, step) * 3.5, 9, 6, 2.5), '#3b3350');
    shape(c, p, rrect(1, -6 - Math.max(0, -step) * 3.5, 9, 6, 2.5), '#3b3350');
    shape(c, p, ell(-12.5, -33 + step * 1.5, 3.6, 4.2), '#e2b46c');
    shape(c, p, rrect(-10, -71, 20, 66, 2.5), vgrad(c, -71, -5, '#f4d495', '#d29d55'));
  });
  // the metal edge, the grain, the inch marks and the hole to hang him up by
  c.fillStyle = '#cdd0db'; c.fillRect(7.2, -70, 2.6, 64);
  c.strokeStyle = 'rgba(43,34,53,0.35)'; c.lineWidth = 1; c.beginPath(); c.moveTo(7.2, -70); c.lineTo(7.2, -6); c.stroke();
  c.strokeStyle = 'rgba(150,95,40,0.25)'; c.lineWidth = 1;
  c.beginPath(); c.moveTo(-3, -68); c.quadraticCurveTo(-1, -40, -3.5, -8); c.moveTo(3.5, -66); c.quadraticCurveTo(5, -36, 2.5, -10); c.stroke();
  c.strokeStyle = 'rgba(43,34,53,0.72)'; c.lineWidth = 1.1; c.lineCap = 'butt';
  c.beginPath();
  for (let i = 0; i <= 15; i++) { const yy = -9 - i * 3.8, len = i % 4 === 0 ? 6 : i % 2 === 0 ? 4 : 2.4; c.moveTo(-10, yy); c.lineTo(-10 + len, yy); }
  c.stroke();
  c.fillStyle = '#7a5232'; c.beginPath(); c.arc(1.5, -66, 2.2, 0, TAU); c.fill();
  // face: one eye behind a monocle, and a mustache ruled perfectly straight
  eyes(c, 0.5, 6.5, -53, 6, mood, t);
  c.strokeStyle = '#d9a030'; c.lineWidth = 1.8; c.beginPath(); c.arc(6.5, -53, 4.6, 0, TAU); c.stroke();
  c.fillStyle = 'rgba(220,240,255,0.25)'; c.beginPath(); c.arc(6.5, -53, 3.8, 0, TAU); c.fill();
  c.strokeStyle = '#d9a030'; c.lineWidth = 1; c.lineCap = 'round';
  c.beginPath(); c.moveTo(10.2, -50.5); c.quadraticCurveTo(14, -43, 10.5, -35); c.stroke();
  c.fillStyle = INK; c.beginPath(); rrect(-2, -47.6, 11.5, 2.3, 1.1)(c); c.fill();
  mouth(c, 3.8, -43.2, 3.4, mood);
  // the arm with the lance: a pencil, sharpened to a point
  c.save(); c.translate(12.5, -33); c.rotate(-0.32 - couch);
  paper(c, p => {
    shape(c, p, rrect(-17, -3.1, 6.5, 6.2, 2.4), ERASER[1], 1.8);
    shape(c, p, rrect(-11.5, -3.4, 5.5, 6.8, 1), '#c9cdd8', 1.8);
    shape(c, p, rrect(-6.5, -3, 37, 6, 1), vgrad(c, -3, 3, '#ffe066', '#e9a92a'), 1.8);
    shape(c, p, poly([[30.5, -3], [39.5, 0], [30.5, 3]]), '#f3d3a0', 1.8);
    shape(c, p, ell(0, 0.4, 3.9, 4.3), '#e2b46c', 1.8);
  });
  c.fillStyle = '#3b3350'; c.beginPath(); c.moveTo(36.4, -1.1); c.lineTo(39.5, 0); c.lineTo(36.4, 1.1); c.closePath(); c.fill();
  c.restore();
  c.restore();
}

// ---------------------------------------------------------------- the Wastebasket (mid-boss)
// Every draft Queen Pristine ever threw away ends up in here: a big wire-mesh wastebasket stuffed full of crumpled
// paper, eyes glowing in the dark inside, its dented lid tipped like a hat. Beaten (o.mood 'happy'), it turns out to
// be a big softie.
export function drawWastebasket(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'angry', happy = mood === 'happy';
  const walk = o.state === 'walk', step = walk ? Math.sin((o.phase || 0) * TAU) : 0;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 50 * s, 0.26);
  c.scale(s * flip, s);
  c.translate(0, walk ? -Math.abs(step) * 4 : 0);
  c.rotate(walk ? step * 0.04 : 0);
  const br = Math.sin(t * 1.8) * 0.015;
  c.scale(1 + br, 1 - br);
  const B = poly([[-35, -8], [-46, -98], [46, -98], [35, -8]]);
  paper(c, p => {
    shape(c, p, rrect(-30, -9 - Math.max(0, step) * 4, 22, 9, 4), '#4a4458');
    shape(c, p, rrect(8, -9 - Math.max(0, -step) * 4, 22, 9, 4), '#4a4458');
    shape(c, p, B, happy ? vgrad(c, -98, -8, '#4a3a60', '#2a2238') : vgrad(c, -98, -8, '#2e2642', '#141020'));
  });
  // deep inside, in the dark: its eyes and its grin
  const ey = -62, dark = happy ? '#3a2e4e' : '#1e1830';
  c.lineCap = 'round';
  if (mood === 'hurt') {
    c.strokeStyle = '#ffe066'; c.lineWidth = 3.4;
    for (const sx of [-1, 1]) {
      glowDot(c, sx * 16, ey, 18, '255,214,90', 0.45);
      c.beginPath(); c.moveTo(sx * 16 - 5, ey - 5); c.lineTo(sx * 16 + 5, ey + 5); c.moveTo(sx * 16 + 5, ey - 5); c.lineTo(sx * 16 - 5, ey + 5); c.stroke();
    }
    c.fillStyle = '#ffb347'; c.beginPath(); c.ellipse(0, -38, 7, 8, 0, 0, TAU); c.fill();
  } else if (happy || mood === 'sleep' || mood === 'sleepy') {
    c.strokeStyle = '#ffe066'; c.lineWidth = 3.4;
    for (const sx of [-1, 1]) {
      glowDot(c, sx * 16, ey, 20, '255,214,90', 0.5);
      c.beginPath();
      if (happy) c.arc(sx * 16, ey + 3, 6, Math.PI * 1.15, Math.PI * 1.85); else c.arc(sx * 16, ey - 1, 6, Math.PI * 0.15, Math.PI * 0.85);
      c.stroke();
    }
    if (happy) { glowDot(c, 0, -42, 30, '255,180,80', 0.4); c.fillStyle = '#ffb347'; c.beginPath(); c.arc(0, -48, 15, 0.15 * Math.PI, 0.85 * Math.PI); c.closePath(); c.fill(); }
    else { c.strokeStyle = '#ffb347'; c.lineWidth = 2.6; c.beginPath(); c.ellipse(0, -40, 4, 3, 0, 0, TAU); c.stroke(); }
  } else {
    for (const sx of [-1, 1]) {
      glowDot(c, sx * 16, ey, 24, '255,214,90', 0.55 + 0.1 * Math.sin(t * 3));
      c.fillStyle = '#ffe066'; c.beginPath(); c.ellipse(sx * 16, ey, 7.5, 6.5, 0, 0, TAU); c.fill();
      c.fillStyle = dark; c.beginPath(); c.ellipse(sx * 17.2, ey + 0.6, 1.9, 4.2, 0, 0, TAU); c.fill();
      // a scowl: the dark cuts in over each eye, lowest in the middle
      c.beginPath(); c.moveTo(sx * 6, ey - 10); c.lineTo(sx * 6, ey - 1.5); c.lineTo(sx * 27, ey - 8.5); c.lineTo(sx * 27, ey - 12); c.closePath(); c.fill();
    }
    glowDot(c, 0, -38, 32, '255,170,70', 0.4);
    c.fillStyle = '#ffb347';
    c.beginPath(); c.moveTo(-22, -44);
    for (let i = 1; i <= 8; i++) c.lineTo(-22 + i * 5.5, -44 + (i % 2 ? 5 : 0));
    c.quadraticCurveTo(0, -22, -22, -44); c.fill();
  }
  // the wire mesh, over the dark (and over its face)
  c.save(); c.beginPath(); B(c); c.clip();
  for (const pass of [0, 1]) {
    c.strokeStyle = pass ? '#cfcbdc' : 'rgba(20,14,30,0.9)'; c.lineWidth = pass ? 1.6 : 3.4;
    c.beginPath();
    for (let k = -170; k < 170; k += 11) { c.moveTo(k, -8); c.lineTo(k + 90, -98); c.moveTo(k, -8); c.lineTo(k - 90, -98); }
    c.stroke();
  }
  c.restore();
  c.strokeStyle = INK; c.lineWidth = 2.4; c.lineJoin = 'round'; c.beginPath(); B(c); c.stroke();
  // the drafts it's stuffed with, poking out of the top
  for (const [bx, by, r, sd] of [[-30, -102, 12, 1.3], [26, -101, 12, 4.1], [-12, -109, 14, 2.2], [9, -106, 13, 3.3], [-1, -100, 10, 5.9]]) {
    crumpleBall(c, bx + Math.sin(t * 2.2 + sd) * 0.8, by + Math.sin(t * 2.6 + sd * 2) * 0.8, r, sd);
  }
  paper(c, p => {
    shape(c, p, rrect(-50, -104, 100, 9, 4), vgrad(c, -104, -95, '#f0eef6', '#9d98b0'));
    shape(c, p, rrect(-38.5, -13, 77, 7, 3), vgrad(c, -13, -6, '#e4e1ec', '#8f8aa3'));
  });
  // one draft hanging over the edge, and one that has fallen out
  crumpleBall(c, -47, -95, 9, 7.7);
  crumpleBall(c, 52, -8.5, 8.5, 8.8);
  if (happy) {   // someone has stuck a crayon flower in it
    c.strokeStyle = '#4f9a52'; c.lineWidth = 3; c.lineCap = 'round';
    c.beginPath(); c.moveTo(22, -106); c.quadraticCurveTo(27, -120, 25, -130); c.stroke();
    paper(c, p => shape(c, p, cc => starPath(cc, 25, -133, 8.5, 4.2, 5), '#ff8ab0', 1.8));
    c.fillStyle = '#ffd23f'; c.beginPath(); c.arc(25, -133, 2.8, 0, TAU); c.fill();
  }
  // the dented lid, worn like a hat
  c.save(); c.translate(happy ? -8 : 9, -114); c.rotate(happy ? -0.3 : 0.2 + Math.sin(t * 2) * 0.03);
  paper(c, p => {
    shape(c, p, rrect(-6, -19, 12, 7, 3), '#8f8aa3', 2);
    shape(c, p, cc => { cc.moveTo(-36, 0); cc.quadraticCurveTo(-33, -13, -6, -14.5); cc.lineTo(8, -14.5); cc.lineTo(12, -9.5); cc.lineTo(17, -13.5); cc.quadraticCurveTo(33, -12, 36, 0); cc.closePath(); }, vgrad(c, -15, 0, '#eeecf4', '#a29db4'));
    shape(c, p, rrect(-38, -1.5, 76, 5, 2.5), '#b8b3c8', 2);
  });
  c.strokeStyle = 'rgba(43,34,53,0.35)'; c.lineWidth = 1.3;
  c.beginPath(); c.moveTo(12, -9.5); c.lineTo(9, -3); c.moveTo(12, -9.5); c.lineTo(17, -4); c.stroke();
  c.fillStyle = 'rgba(255,255,255,0.5)'; c.beginPath(); c.ellipse(-16, -9, 9, 2.4, -0.15, 0, TAU); c.fill();
  c.restore();
  c.restore();
}

// ---------------------------------------------------------------- Queen Pristine (final boss)
// Tall, crisp white paper and gold trim, every fold exactly even, every line perfectly matched left and right, and a
// scepter topped with a big pink eraser. She looks down her nose at everything. Won over at last (o.mood 'happy'), she
// smiles, and her crown has slipped crooked. She doesn't mind.
export function drawPristine(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'normal', happy = mood === 'happy';
  const walk = o.state === 'walk', ph = (o.phase || 0) * TAU;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 46 * s, 0.24);
  c.scale(s * flip, s);
  glowDot(c, 0, -100, 140, happy ? '255,226,160' : '236,240,255', 0.3);
  c.translate(0, Math.sin(t * 1.3) * 1.2);
  const sw = walk ? Math.sin(ph) * 4 : Math.sin(t * 1.1) * 1.2;   // the hem swishes as she glides
  const SKIN = '#fffaf3';
  const gown = cc => { cc.moveTo(-13, -95); cc.quadraticCurveTo(-17, -46, -50 - sw, -3); cc.quadraticCurveTo(0, 5, 50 - sw, -3); cc.quadraticCurveTo(17, -46, 13, -95); cc.closePath(); };
  const hem = cc => { cc.moveTo(-50 - sw, -3); cc.quadraticCurveTo(0, 5, 50 - sw, -3); };
  // her tall collar, the gown, the sleeves and the bodice
  paper(c, p => {
    shape(c, p, cc => { cc.moveTo(-7, -116); cc.quadraticCurveTo(-24, -126, -22, -152); cc.quadraticCurveTo(0, -160, 22, -152); cc.quadraticCurveTo(24, -126, 7, -116); cc.closePath(); }, vgrad(c, -158, -116, '#ffffff', '#ece8f2'));
    shape(c, p, gown, vgrad(c, -95, 0, '#fffefb', '#e2deea'));
    for (const sx of [-1, 1]) shape(c, p, poly([[sx * 13, -117], [sx * 20, -116], [sx * 31, -85], [sx * 25, -81]]), vgrad(c, -117, -81, '#fffefb', '#e6e2ee'));
    shape(c, p, poly([[-13, -95], [-17.5, -118], [17.5, -118], [13, -95]]), vgrad(c, -118, -95, '#ffffff', '#efebf4'));
    for (const sx of [-1, 1]) shape(c, p, poly([[sx * 25, -81], [sx * 31, -85], [sx * 33.5, -80.5], [sx * 27.5, -76.5]]), GOLD[1], 1.8);
    shape(c, p, ell(-30.5, -75, 4.3, 4.6), SKIN, 2);
  });
  // the gown: pleats all exactly even, a gold hem, and a gold seam straight down the middle
  c.save(); c.beginPath(); gown(c); c.clip();
  c.strokeStyle = 'rgba(150,140,190,0.28)'; c.lineWidth = 1.3;
  c.beginPath(); for (const k of [-2, -1, 1, 2]) { c.moveTo(k * 4.5, -93); c.quadraticCurveTo(k * 9.5, -46, k * 19 - sw * 0.6, 3); } c.stroke();
  c.strokeStyle = GOLD[1]; c.lineWidth = 11; c.beginPath(); hem(c); c.stroke();
  c.translate(0, -2.6); c.strokeStyle = '#fff0b8'; c.lineWidth = 1.4; c.beginPath(); hem(c); c.stroke();
  c.translate(0, -3); c.strokeStyle = 'rgba(43,34,53,0.45)'; c.lineWidth = 1; c.beginPath(); hem(c); c.stroke();
  c.restore();
  c.strokeStyle = GOLD[1]; c.lineWidth = 2; c.lineCap = 'round';
  c.beginPath(); c.moveTo(0, -94); c.quadraticCurveTo(0, -46, -sw * 0.5, 0); c.stroke();
  c.fillStyle = GOLD[0]; c.strokeStyle = INK; c.lineWidth = 1;
  for (let i = 0; i < 5; i++) {
    const yy = -82 + i * 16, u = (yy + 94) / 94, xx = -sw * 0.5 * u * u;
    c.beginPath(); c.moveTo(xx, yy - 3.4); c.lineTo(xx + 2.6, yy); c.lineTo(xx, yy + 3.4); c.lineTo(xx - 2.6, yy); c.closePath(); c.fill(); c.stroke();
  }
  paper(c, p => shape(c, p, rrect(-14.5, -98, 29, 5, 2.5), vgrad(c, -98, -93, GOLD[0], GOLD[1]), 1.8));
  c.strokeStyle = GOLD[1]; c.lineWidth = 2; c.lineJoin = 'round';
  c.beginPath(); c.moveTo(-15.5, -117); c.lineTo(0, -100.5); c.lineTo(15.5, -117); c.stroke();
  c.strokeStyle = GOLD[1]; c.lineWidth = 3;
  c.beginPath(); c.moveTo(-21.5, -151); c.quadraticCurveTo(0, -158.5, 21.5, -151); c.stroke();
  c.strokeStyle = 'rgba(150,140,190,0.3)'; c.lineWidth = 1.1;
  c.beginPath(); for (const a of [-0.9, -0.45, 0.45, 0.9]) { c.moveTo(Math.sin(a) * 6, -119); c.lineTo(Math.sin(a) * 23, -119 - Math.cos(a) * 33); } c.stroke();
  // neck, head, and her silver hair, parted dead center
  paper(c, p => {
    shape(c, p, rrect(-4, -124, 8, 9, 3), SKIN, 2);
    shape(c, p, ell(0, -132, 11.5, 13), vgrad(c, -145, -119, '#ffffff', SKIN));
    shape(c, p, cc => { cc.moveTo(-12.6, -127); cc.quadraticCurveTo(-14.5, -148, 0, -148.5); cc.quadraticCurveTo(14.5, -148, 12.6, -127); cc.quadraticCurveTo(10.5, -139, 0, -140.5); cc.quadraticCurveTo(-10.5, -139, -12.6, -127); cc.closePath(); }, vgrad(c, -148, -127, '#eeebf5', '#cfc9de'));
  });
  c.strokeStyle = 'rgba(43,34,53,0.5)'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(0, -148); c.lineTo(0, -141); c.stroke();
  // the crown (crooked, once she's happy)
  c.save();
  if (happy) { c.translate(0, -146); c.rotate(0.21); c.translate(3.5, 146); }
  else if (mood === 'hurt') { c.translate(0, -146); c.rotate(-0.08); c.translate(0, 146); }
  paper(c, p => shape(c, p, poly([[-10.5, -144], [-12, -159], [-5.5, -151.5], [0, -170], [5.5, -151.5], [12, -159], [10.5, -144]]), vgrad(c, -170, -144, GOLD[0], GOLD[1]), 2));
  c.fillStyle = ERASER[1]; c.strokeStyle = INK; c.lineWidth = 1.2; c.beginPath(); c.ellipse(0, -149.5, 2.6, 3.2, 0, 0, TAU); c.fill(); c.stroke();
  c.fillStyle = '#fff6d0'; for (const [bx, by] of [[-12, -159], [12, -159], [0, -170]]) { c.beginPath(); c.arc(bx, by, 1.8, 0, TAU); c.fill(); }
  c.restore();
  // the face
  const ey = -132;
  if (happy) {
    eyes(c, -4.6, 4.6, ey, 6.5, 'happy', t);
    blush(c, -7.6, -126.5, 3); blush(c, 7.6, -126.5, 3);
    mouth(c, 0, -125, 5, 'happy');
  } else if (['hurt', 'angry', 'worried', 'sleep', 'sleepy', 'shock', 'determined'].includes(mood)) {
    eyes(c, -4.6, 4.6, ey, 6.5, mood, t);
    mouth(c, 0, -124.5, 4.4, mood === 'determined' ? 'angry' : mood);
  } else {
    // cold and disapproving: lids half down, brows raised, looking down her nose at you
    eyes(c, -4.6, 4.6, ey, 6.5, 'normal', t);
    c.fillStyle = SKIN; c.strokeStyle = INK; c.lineCap = 'round';
    for (const sx of [-1, 1]) {
      const ex = sx * 4.6;
      c.fillRect(ex - 2.2, ey - 4.2, 4.4, 3.6);
      c.lineWidth = 1.9; c.beginPath(); c.moveTo(ex - 2.3, ey - 0.6); c.quadraticCurveTo(ex, ey - 1.4, ex + 2.3, ey - 0.6); c.stroke();
      c.lineWidth = 1.3; c.beginPath(); c.moveTo(sx * 8.2, ey - 5.2); c.quadraticCurveTo(sx * 5, ey - 7.4, sx * 1.8, ey - 6.6); c.stroke();
    }
    c.lineWidth = 1.6; c.beginPath(); c.moveTo(-2.8, -124); c.quadraticCurveTo(0, -125.6, 2.8, -124); c.stroke();
  }
  // the scepter: a golden rod with a big pink eraser on top, and her hand round it
  paper(c, p => {
    shape(c, p, rrect(30, -134, 4.8, 106, 2.4), vgrad(c, -134, -28, GOLD[0], GOLD[1]), 2);
    shape(c, p, ell(32.4, -27, 3.6, 3.6), GOLD[1], 1.8);
    shape(c, p, rrect(26.9, -142, 11, 10, 2), vgrad(c, -142, -132, '#fff0b8', '#c9902a'), 2);
    shape(c, p, rrect(22.9, -165, 19, 24, 6), vgrad(c, -165, -141, ERASER[0], ERASER[1]), 2.2);
    shape(c, p, ell(30.5, -75, 4.3, 4.6), SKIN, 2);
  });
  c.strokeStyle = 'rgba(43,34,53,0.35)'; c.lineWidth = 1;
  c.beginPath(); c.moveTo(27.5, -138.5); c.lineTo(37.3, -138.5); c.moveTo(27.5, -135.5); c.lineTo(37.3, -135.5); c.stroke();
  c.fillStyle = 'rgba(255,255,255,0.45)'; c.beginPath(); c.ellipse(28, -159, 2.6, 4, -0.2, 0, TAU); c.fill();
  // a gleam here and there: everything about her is spotless
  const a0 = c.globalAlpha;
  for (let i = 0; i < 4; i++) {
    const k = Math.sin(t * 2.2 + i * 1.9);
    if (k <= 0) continue;
    const px = (hash(i * 3.3) - 0.5) * 96, py = -24 - hash(i * 5.7) * 140;
    c.globalAlpha = a0 * k; c.fillStyle = happy ? '#ffe9a8' : '#fff6d0';
    c.beginPath(); starPath(c, px, py, 4.5 * k + 1, 1.2, 4); c.fill();
  }
  c.globalAlpha = a0;
  c.restore();
}

// ---------------------------------------------------------------- the Color Founts
// A round stone fountain where the Margin's color comes from: ink of one color (o.color) jets from a golden pen nib on
// top into the basin. Queen Pristine has jammed a huge eraser into each one (o.capped): the basin's run dry and the
// stone has cracked. Pull it out and the ink flows again (o.flowing). Neither: a still pool of ink.
export function drawFount(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, col = o.color || '#5b8def';
  const cap = !!o.capped, flow = !cap && !!o.flowing, rgb = rgbOf(col);
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 62 * s, 0.2);
  c.scale(s * flip, s);
  if (flow) glowDot(c, 0, -66, 125, rgb, 0.2 + 0.05 * Math.sin(t * 2.2));
  const stone = (a, b) => vgrad(c, a, b, '#e4deec', '#a69fba');
  const basin = cc => { cc.moveTo(-60, -44); cc.lineTo(60, -44); cc.quadraticCurveTo(61, -9, 44, -2); cc.lineTo(-44, -2); cc.quadraticCurveTo(-61, -9, -60, -44); cc.closePath(); };
  paper(c, p => {
    shape(c, p, basin, stone(-44, -2));
    shape(c, p, ell(0, -44, 62, 9.5), stone(-54, -34));
    shape(c, p, ell(0, -44.5, 54, 6.6), cap ? vgrad(c, -51, -38, '#a49cb6', '#cbc4d8') : vgrad(c, -51, -38, tone(col, 0.25), tone(col, -0.15)), 2);
    shape(c, p, rrect(-12, -90, 24, 48, 5), stone(-90, -42));
    shape(c, p, cc => { cc.moveTo(-35, -97); cc.quadraticCurveTo(-27, -80, 0, -80); cc.quadraticCurveTo(27, -80, 35, -97); cc.closePath(); }, stone(-97, -80));
    shape(c, p, ell(0, -97, 35, 5.2), stone(-102, -92), 2);
    shape(c, p, ell(0, -97.4, 29, 3.4), cap ? '#b9b2c8' : tone(col, 0.1), 1.6);
    if (!cap) shape(c, p, poly([[-7, -98], [7, -98], [5.5, -107], [0, -117], [-5.5, -107]]), vgrad(c, -117, -98, GOLD[0], GOLD[1]), 2);
    shape(c, p, ell(0, -66, 6.5, 8), cap ? vgrad(c, -74, -58, '#c4bed2', '#8f88a3') : vgrad(c, -74, -58, tone(col, 0.35), tone(col, -0.2)), 2);
  });
  // stone joints, a shine on the color stone
  c.strokeStyle = 'rgba(43,34,53,0.18)'; c.lineWidth = 1.3;
  c.beginPath(); c.moveTo(-58, -26); c.quadraticCurveTo(0, -20, 58, -26); c.moveTo(-20, -42); c.lineTo(-22, -24); c.moveTo(22, -42); c.lineTo(24, -24); c.stroke();
  c.fillStyle = 'rgba(255,255,255,0.6)'; c.beginPath(); c.ellipse(-2, -69, 1.8, 2.6, -0.3, 0, TAU); c.fill();
  if (!cap) {   // the nib's slit and breather hole
    c.strokeStyle = INK; c.lineWidth = 1.3; c.beginPath(); c.moveTo(0, -116); c.lineTo(0, -104); c.stroke();
    c.fillStyle = INK; c.beginPath(); c.arc(0, -103, 1.6, 0, TAU); c.fill();
    c.fillStyle = 'rgba(255,255,255,0.5)'; c.beginPath(); c.moveTo(-4.5, -99); c.lineTo(-1.5, -112); c.lineTo(-1, -99); c.closePath(); c.fill();
  }
  if (cap) {
    // cracked, dry (just a ring where the ink used to be), and an eraser jammed in the top
    c.strokeStyle = INK; c.lineWidth = 1.6; c.lineJoin = 'round'; c.lineCap = 'round';
    c.beginPath(); c.moveTo(-7, -89); c.lineTo(-3, -82); c.lineTo(-8, -77); c.lineTo(-4, -71); c.moveTo(30, -38); c.lineTo(35, -30); c.lineTo(31, -23); c.stroke();
    c.strokeStyle = `rgba(${rgb},0.4)`; c.lineWidth = 2; c.beginPath(); c.ellipse(0, -44.2, 40, 4.4, 0, 0, TAU); c.stroke();
    c.strokeStyle = 'rgba(43,34,53,0.3)'; c.lineWidth = 1.1;
    c.beginPath(); c.moveTo(-30, -45); c.lineTo(-22, -43); c.lineTo(-16, -46); c.moveTo(14, -43); c.lineTo(22, -45.5); c.stroke();
    c.save(); c.translate(3, -108); c.rotate(-0.2);
    paper(c, p => {
      shape(c, p, rrect(-30, -19, 60, 33, 8), vgrad(c, -19, 14, ERASER[0], ERASER[1]), 2.4);
      shape(c, p, rrect(-9, -20.5, 19, 36, 2), vgrad(c, -20, 15, '#5d8fe6', '#3b6cc4'), 2);
    });
    c.fillStyle = '#fffaf0'; c.fillRect(-8, -6, 17, 8);
    c.fillStyle = 'rgba(255,255,255,0.4)'; c.beginPath(); c.ellipse(-20, -12, 6, 2.4, -0.2, 0, TAU); c.fill();
    c.restore();
    for (let i = 0; i < 5; i++) crumb(c, -26 + i * 13 + hash(i) * 4, -96 - hash(i + 3) * 3, 1.6 + hash(i + 5), i * 1.3, i % 2 ? '#f6a6ba' : '#bcb6c8');
  } else if (flow) {
    // ink jetting from the nib in four arcs, rings spreading where it lands, sparkles
    const tip = [0, -116];
    c.lineCap = 'round';
    for (let i = 0; i < 4; i++) {
      const side = i % 2 ? 1 : -1, far = i > 1, wob = Math.sin(t * 5 + i * 1.7) * 3;
      const end = [side * (far ? 50 : 38), -46], ctl = [side * (far ? 46 : 30), -152 - (far ? 6 : 0) + wob];
      const arc = () => { c.beginPath(); c.moveTo(tip[0], tip[1]); c.quadraticCurveTo(ctl[0], ctl[1], end[0], end[1]); };
      arc(); c.strokeStyle = INK; c.lineWidth = 6.4; c.stroke();
      arc(); c.strokeStyle = col; c.lineWidth = 4.2; c.stroke();
      arc(); c.strokeStyle = 'rgba(255,255,255,0.45)'; c.lineWidth = 1.3; c.stroke();
      for (let k = 0; k < 2; k++) {
        const u = (t * 0.8 + k * 0.5 + i * 0.21) % 1, v = 1 - u;
        const px = v * v * tip[0] + 2 * v * u * ctl[0] + u * u * end[0], py = v * v * tip[1] + 2 * v * u * ctl[1] + u * u * end[1];
        c.fillStyle = tone(col, 0.55); c.beginPath(); c.arc(px, py, 1.6, 0, TAU); c.fill();
      }
      const q = (t * 1.3 + i * 0.37) % 1;
      c.strokeStyle = `rgba(255,255,255,${0.75 * (1 - q)})`; c.lineWidth = 1.5;
      c.beginPath(); c.ellipse(end[0] * 0.92, end[1] + 1, 3 + q * 11, (3 + q * 11) * 0.26, 0, 0, TAU); c.stroke();
    }
    const a0 = c.globalAlpha;
    for (let i = 0; i < 6; i++) {
      const k = Math.sin(t * 3 + i * 2.3);
      if (k <= 0) continue;
      const sx = (hash(i * 2.7) - 0.5) * 130, sy = -40 - hash(i * 4.9) * 95;
      c.globalAlpha = a0 * k;
      glowDot(c, sx, sy, 10, rgb, 0.5);
      c.fillStyle = '#fffbe8'; c.beginPath(); starPath(c, sx, sy, 4.5 * k + 1, 1.2, 4); c.fill();
    }
    c.globalAlpha = a0;
  } else {
    // still: a slow shine across the ink
    c.fillStyle = 'rgba(255,255,255,0.35)'; c.beginPath(); c.ellipse(-18 + Math.sin(t * 0.8) * 6, -46, 12, 1.6, 0, 0, TAU); c.fill();
  }
  c.restore();
}

// ---------------------------------------------------------------- crayons and the ferry
// A crayon to collect: floating, bobbing and glowing, centered on (x, y).
export function drawCrayon(c, x, y, t = 0, color = '#ff6b6b') {
  const by = y + Math.sin(t * 2.6 + x * 0.05) * 3, tilt = -0.55 + Math.sin(t * 1.8 + x * 0.03) * 0.16;
  glowDot(c, x, by, 32, rgbOf(color), 0.42 + 0.1 * Math.sin(t * 3.4));
  c.save(); c.translate(x, by); c.rotate(tilt);
  paper(c, p => {
    shape(c, p, rrect(-15, -4.6, 24, 9.2, 2.5), vgrad(c, -4.6, 4.6, tone(color, 0.3), tone(color, -0.18)), 2);
    shape(c, p, poly([[8, -4.6], [15, -1.5], [15, 1.5], [8, 4.6]]), tone(color, 0.12), 2);
    shape(c, p, rrect(-11, -5.3, 14, 10.6, 1.5), '#fff4dc', 1.8);
  });
  c.strokeStyle = color; c.lineWidth = 1.1; c.lineJoin = 'round';
  c.beginPath();
  for (const zy of [-3, 3]) for (let i = 0; i <= 6; i++) { const zx = -10 + i * 2, yy = zy + (i % 2 ? 0.8 : -0.8); if (i) c.lineTo(zx, yy); else c.moveTo(zx, yy); }
  c.stroke();
  c.fillStyle = 'rgba(255,255,255,0.45)'; c.fillRect(4, -3.4, 4.5, 1.6);
  c.restore();
  const k = Math.sin(t * 3 + x);
  if (k > 0) {
    const a0 = c.globalAlpha;
    c.globalAlpha = a0 * k; c.fillStyle = '#fffbe8';
    c.beginPath(); starPath(c, x + 12, by - 12, 4.5 * k + 1, 1.3, 4); c.fill();
    c.globalAlpha = a0;
  }
}

// Captain Crease's ferry: a paper boat folded from one enormous sheet of notebook paper, bobbing at the waterline
// (x, y). About 224 px long; its deck (the top of the hull) is about 48 px above the waterline.
export function drawPaperBoat(c, x, y, t = 0) {
  const bob = Math.sin(t * 1.6) * 3, roll = Math.sin(t * 1.1) * 0.025;
  c.save(); c.translate(x, y);
  // little waves at the waterline, either side
  const a0 = c.globalAlpha;
  c.strokeStyle = '#ffffff'; c.lineWidth = 2.2; c.lineCap = 'round';
  for (let i = 0; i < 4; i++) {
    const side = i % 2 ? 1 : -1, k = (t * 0.5 + i * 0.27) % 1, rx = 94 + k * 40;
    c.globalAlpha = a0 * 0.7 * (1 - k);
    c.beginPath(); c.moveTo(side * rx, 4 + i); c.lineTo(side * (rx + 18), 4 + i); c.stroke();
  }
  c.globalAlpha = a0;
  c.save(); c.translate(0, bob); c.rotate(roll);
  // the pennant on top
  c.strokeStyle = INK; c.lineWidth = 2.4; c.beginPath(); c.moveTo(0, -148); c.lineTo(0, -172); c.stroke();
  paper(c, p => shape(c, p, cc => { const w = Math.sin(t * 4) * 3; cc.moveTo(1, -172); cc.quadraticCurveTo(12, -169 + w, 24, -166 + w); cc.lineTo(1, -159); cc.closePath(); }, '#e5534b', 2));
  const sail = poly([[-56, -46], [0, -150], [56, -46]]), hull = poly([[-112, -48], [112, -48], [76, 10], [-76, 10]]);
  paper(c, p => {
    shape(c, p, sail, vgrad(c, -150, -46, '#fffdf7', '#eee6d4'), 2.6);
    shape(c, p, hull, vgrad(c, -48, 10, '#fffaf0', '#e2d8c2'), 2.6);
  });
  for (const [path, y0, y1, mx] of [[sail, -150, -46, null], [hull, -48, 10, -84]]) {
    c.save(); c.beginPath(); path(c); c.clip(); ruled(c, -114, y0, 114, y1, 9, mx);
    if (path === hull) { c.fillStyle = 'rgba(70,120,190,0.14)'; c.fillRect(-114, -5, 228, 16); }
    c.restore();
  }
  // its folds
  c.strokeStyle = 'rgba(43,34,53,0.3)'; c.lineWidth = 1.6; c.lineCap = 'round';
  c.beginPath(); c.moveTo(-56, -47); c.lineTo(-24, 9); c.moveTo(56, -47); c.lineTo(24, 9); c.moveTo(0, -148); c.lineTo(0, -50); c.stroke();
  // portholes (inked on by the captain himself)
  for (const px of [-74, 74]) {
    c.fillStyle = vgrad(c, -32, -14, '#cfeeff', '#8fc8ea'); c.strokeStyle = INK; c.lineWidth = 2.2;
    c.beginPath(); c.arc(px, -23, 8, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = 'rgba(255,255,255,0.7)'; c.beginPath(); c.ellipse(px - 2.5, -26, 2.4, 1.6, -0.5, 0, TAU); c.fill();
  }
  // the lifebuoy hanging on the sail
  c.save(); c.translate(24, -82);
  c.fillStyle = '#fffaf0'; c.strokeStyle = INK; c.lineWidth = 2;
  c.beginPath(); c.arc(0, 0, 10, 0, TAU); c.arc(0, 0, 5, 0, TAU, true); c.fill('evenodd'); c.stroke();
  c.fillStyle = '#e5534b';
  for (let q = 0; q < 4; q += 2) { c.beginPath(); c.arc(0, 0, 10, q * Math.PI / 2 + 0.3, (q + 1) * Math.PI / 2 + 0.3); c.arc(0, 0, 5, (q + 1) * Math.PI / 2 + 0.3, q * Math.PI / 2 + 0.3, true); c.closePath(); c.fill(); }
  c.beginPath(); c.arc(0, 0, 10, 0, TAU); c.stroke(); c.beginPath(); c.arc(0, 0, 5, 0, TAU); c.stroke();
  c.restore();
  c.restore();
  c.restore();
}

// ---------------------------------------------------------------- scenery in the Margin
// (each one is drawn around (0, 0), its foot on the ground; x varies them)

// a treetop: a bumpy cloud of a shape around (x, y), rx by ry, with n bumps (seeded)
function bumpy(x, y, rx, ry, n, seed) {
  return cc => {
    const pt = i => { const a = (i / n) * TAU - Math.PI / 2, k = 0.92 + hash(seed + i * 1.7) * 0.14; return [x + Math.cos(a) * rx * k, y + Math.sin(a) * ry * k]; };
    const [px, py] = pt(0);
    cc.moveTo(px, py);
    for (let i = 1; i <= n; i++) {
      const [qx, qy] = pt(i % n), am = ((i - 0.5) / n) * TAU - Math.PI / 2;
      cc.quadraticCurveTo(x + Math.cos(am) * rx * 1.28, y + Math.sin(am) * ry * 1.28, qx, qy);
    }
    cc.closePath();
  };
}

// a tree that's only been sketched in pencil: outline, cross-hatched shade, the branches showing through
DECOR_DRAW.sketchtree = (c, t, x) => {
  const h = hash(x * 0.37), h2 = hash(x * 0.71 + 3.1), k = 0.9 + h2 * 0.22;
  c.save(); c.rotate((h - 0.5) * 0.1 + Math.sin(t * 0.8 + x) * 0.012); c.scale(k, k);
  const top = bumpy(0, -146, 62 + h * 10, 50 + h2 * 8, 9, Math.floor(h * 50));
  const trunk = cc => { cc.moveTo(-12, 0); cc.quadraticCurveTo(-6, -48, -9, -104); cc.lineTo(9, -104); cc.quadraticCurveTo(6, -48, 13, 0); cc.closePath(); };
  paper(c, p => { sketch(c, p, trunk, PAPER, 1.7); sketch(c, p, top, PAPER, 1.7); });
  hatch(c, trunk, 2, -104, 14, 0, { gap: 3.6, a: 0.3 });
  hatch(c, top, -8, -150, 80, -88, { gap: 4.4, a: 0.22, cross: true });
  c.lineCap = 'round';
  // a hint of green colored pencil (only just started)
  c.strokeStyle = 'rgba(110,190,110,0.3)'; c.lineWidth = 2.4; c.lineJoin = 'round';
  c.beginPath(); c.moveTo(-44, -150);
  for (let i = 1; i <= 7; i++) c.lineTo(-44 + i * 5, -150 + (i % 2 ? -14 : 0) - i * 1.5);
  c.stroke();
  // the branches, bark, a few loops of leaves, and the ground it stands on
  c.strokeStyle = lead(0.5); c.lineWidth = 1.4;
  c.beginPath();
  c.moveTo(-1, -100); c.quadraticCurveTo(-6, -122, -24, -138);
  c.moveTo(1, -104); c.quadraticCurveTo(10, -130, 24, -152);
  c.moveTo(0, -112); c.lineTo(-2, -168);
  c.moveTo(-4, -20); c.lineTo(-3, -36); c.moveTo(3, -56); c.lineTo(4, -72); c.moveTo(-2, -80); c.lineTo(-3, -92);
  c.moveTo(-34, 0.5); c.lineTo(36, 0.5);
  c.stroke();
  c.strokeStyle = lead(0.38); c.lineWidth = 1.2;
  for (let i = 0; i < 5; i++) {
    const lx = (hash(x + i * 3.3) - 0.5) * 80, ly = -146 + (hash(x + i * 5.1) - 0.5) * 56;
    c.beginPath(); c.arc(lx, ly, 3.5, Math.PI * 0.9, Math.PI * 2.1); c.arc(lx + 7, ly, 3.5, Math.PI * 0.9, Math.PI * 2.1); c.stroke();
  }
  if (h2 > 0.62) {   // an apple, sketched in, with a touch of red
    c.strokeStyle = PENCIL; c.lineWidth = 1.3;
    c.beginPath(); c.arc(30, -122, 6, 0, TAU); c.moveTo(30, -128); c.lineTo(32, -133); c.stroke();
    c.fillStyle = 'rgba(229,83,75,0.28)'; c.beginPath(); c.arc(30, -122, 4.5, 0, TAU); c.fill();
  }
  c.restore();
};

// a giant yellow pencil, stuck point-first in the ground
DECOR_DRAW.pencil = (c, t, x) => {
  const h = hash(x * 0.53), len = 98 + h * 18;
  c.save(); c.rotate((h - 0.5) * 0.3);
  c.fillStyle = 'rgba(60,45,30,0.25)'; c.beginPath(); c.ellipse(0, 0, 16, 3.8, 0, 0, TAU); c.fill();
  const faces = c.createLinearGradient(-13, 0, 13, 0);
  for (const [k, cl] of [[0, '#e9a92a'], [0.34, '#e9a92a'], [0.34, '#ffd84a'], [0.66, '#ffd84a'], [0.66, '#f4bf33'], [1, '#f4bf33']]) faces.addColorStop(k, cl);
  const T = -16 - len;
  const body = cc => {
    cc.moveTo(-13, -16); cc.lineTo(-13, T); cc.lineTo(13, T); cc.lineTo(13, -16);
    for (let i = 0; i < 4; i++) cc.quadraticCurveTo(9.75 - i * 6.5, -11, 6.5 - i * 6.5, -16);
    cc.closePath();
  };
  paper(c, p => {
    shape(c, p, poly([[-13, -17], [13, -17], [5.5, 0.5], [-5.5, 0.5]]), vgrad(c, -17, 0, '#f6d8a8', '#d9a86a'), 2);
    shape(c, p, body, faces, 2.2);
    shape(c, p, rrect(-13.8, T - 13, 27.6, 14, 2), vgrad(c, T - 13, T + 1, '#eceaf2', '#9ea3b5'), 2);
    shape(c, p, rrect(-12.6, T - 28, 25.2, 17, 6), vgrad(c, T - 28, T - 11, ERASER[0], ERASER[1]), 2.2);
  });
  c.strokeStyle = 'rgba(150,100,20,0.35)'; c.lineWidth = 1.2;
  c.beginPath(); c.moveTo(-4.2, T + 2); c.lineTo(-4.2, -16); c.moveTo(4.2, T + 2); c.lineTo(4.2, -16); c.stroke();
  c.strokeStyle = 'rgba(43,34,53,0.35)'; c.lineWidth = 1.1;
  c.beginPath(); c.moveTo(-13, T - 8.5); c.lineTo(13, T - 8.5); c.moveTo(-13, T - 4); c.lineTo(13, T - 4); c.stroke();
  c.fillStyle = 'rgba(255,255,255,0.35)'; c.fillRect(-1.5, T + 4, 3, len - 24);
  c.strokeStyle = lead(0.4); c.lineWidth = 1.3; c.lineCap = 'round';
  c.beginPath(); c.moveTo(-14, 1); c.lineTo(-24, 3); c.moveTo(14, 1); c.lineTo(23, 4); c.moveTo(8, 2); c.lineTo(12, 6); c.stroke();
  c.restore();
  void t;
};

// a crumpled-up ball of paper, thrown away
DECOR_DRAW.paperball = (c, t, x) => {
  const h = hash(x * 0.43), r = 12 + h * 4;
  c.fillStyle = 'rgba(20,10,30,0.14)'; c.beginPath(); c.ellipse(0, -1, r * 1.05, r * 0.28, 0, 0, TAU); c.fill();
  crumpleBall(c, 0, -r + 1, r, 1 + h * 9, { lw: 1.8 });
  void t;
};

// a big pink eraser lying on the ground, worn round at one end
DECOR_DRAW.eraserblock = (c, t, x) => {
  const h = hash(x * 0.29), w = 84 + h * 14, hh = 44 + h * 6, L = -w / 2, R = w / 2;
  c.save(); c.rotate((hash(x * 0.9) - 0.5) * 0.08);
  const body = cc => { cc.moveTo(L + 8, 0); cc.arcTo(L, 0, L, -hh, 8); cc.arcTo(L, -hh, R, -hh, 8); cc.arcTo(R, -hh, R, 0, 20); cc.arcTo(R, 0, L, 0, 8); cc.closePath(); };
  paper(c, p => shape(c, p, body, vgrad(c, -hh, 0, ERASER[0], ERASER[1]), 2.2));
  c.save(); c.beginPath(); body(c); c.clip();
  c.fillStyle = 'rgba(255,255,255,0.3)'; c.fillRect(L, -hh, w, hh * 0.22);
  c.strokeStyle = 'rgba(43,34,53,0.2)'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(L, -hh * 0.78); c.lineTo(R, -hh * 0.78); c.stroke();
  c.fillStyle = 'rgba(90,86,104,0.2)';
  c.beginPath(); c.ellipse(R - 14, -hh * 0.35, 12, 3.4, -0.3, 0, TAU); c.fill();
  c.beginPath(); c.ellipse(L + 22, -hh * 0.2, 9, 2.4, 0.2, 0, TAU); c.fill();
  if (h > 0.4) {   // still in its paper sleeve
    const sx = L + w * 0.3;
    c.fillStyle = vgrad(c, -hh, 0, '#5d8fe6', '#3b6cc4'); c.fillRect(sx, -hh - 2, w * 0.3, hh + 4);
    c.fillStyle = '#fffaf0'; c.fillRect(sx, -hh * 0.62, w * 0.3, hh * 0.24);
    c.strokeStyle = INK; c.lineWidth = 2; c.beginPath(); c.moveTo(sx, -hh - 2); c.lineTo(sx, 2); c.moveTo(sx + w * 0.3, -hh - 2); c.lineTo(sx + w * 0.3, 2); c.stroke();
  }
  c.restore();
  c.strokeStyle = INK; c.lineWidth = 2.2; c.beginPath(); body(c); c.stroke();
  for (let i = 0; i < 4; i++) crumb(c, R + 4 + i * 6 + hash(x + i) * 3, -1.5 - hash(x + i + 2) * 1.5, 1.8 + hash(x + i + 4) * 1.2, i * 2.1, i % 2 ? '#bcb6c8' : '#f6a6ba');
  c.restore();
  void t;
};

// a wooden ruler stuck upright in the ground, like a fence post
DECOR_DRAW.ruler = (c, t, x) => {
  const h = hash(x * 0.61), len = 104 + h * 12;
  c.save(); c.rotate((h - 0.5) * 0.16);
  c.fillStyle = 'rgba(60,45,30,0.22)'; c.beginPath(); c.ellipse(0, 0, 16, 3.6, 0, 0, TAU); c.fill();
  paper(c, p => shape(c, p, rrect(-10, -len, 20, len + 1, 2.5), vgrad(c, -len, 0, '#f4d495', '#cf9a52'), 2));
  c.fillStyle = '#cdd0db'; c.fillRect(7, -len + 1.5, 2.4, len - 2);
  c.strokeStyle = 'rgba(150,95,40,0.25)'; c.lineWidth = 1;
  c.beginPath(); c.moveTo(-2, -len + 4); c.quadraticCurveTo(0, -len / 2, -3, -4); c.moveTo(4, -len + 10); c.quadraticCurveTo(5.5, -len / 2, 3, -6); c.stroke();
  c.strokeStyle = 'rgba(43,34,53,0.72)'; c.lineWidth = 1.1;
  c.beginPath();
  for (let i = 0; i * 4 < len - 10; i++) { const yy = -6 - i * 4, l = i % 4 === 0 ? 7 : i % 2 === 0 ? 4.5 : 2.6; c.moveTo(-10, yy); c.lineTo(-10 + l, yy); }
  c.stroke();
  c.fillStyle = 'rgba(60,40,20,0.75)'; c.font = 'bold 7px Fredoka, sans-serif'; c.textAlign = 'center';
  for (let n = 1; n * 16 < len - 12; n++) c.fillText(String(n), 1, -6 - n * 16 + 2.5);
  c.fillStyle = '#7a5232'; c.beginPath(); c.arc(1, -len + 7, 2.3, 0, TAU); c.fill();
  c.restore();
  void t;
};

// ---------------------------------------------------------------- skies and stages
// (How much sky shows depends on how far into a big field you are, so what's up there fits whatever is visible.)
function skyTop(c) {
  try { return c.getTransform().inverse().transformPoint(new DOMPoint(0, 0)).y; } catch (e) { return 0; }
}

// a cloud sketched in pencil (or, colored in, a plain white one)
function sketchCloud(c, x, y, k, colored) {
  const P = (dx, dy) => [x + dx * k, y + dy * k];
  const path = cc => {
    cc.moveTo(...P(-50, 10));
    cc.quadraticCurveTo(...P(-62, -6), ...P(-38, -10));
    cc.quadraticCurveTo(...P(-32, -32), ...P(-8, -24));
    cc.quadraticCurveTo(...P(8, -40), ...P(28, -20));
    cc.quadraticCurveTo(...P(54, -24), ...P(50, 2));
    cc.quadraticCurveTo(...P(58, 14), ...P(38, 12));
    cc.closePath();
  };
  c.beginPath(); path(c);
  c.fillStyle = colored ? 'rgba(255,255,255,0.94)' : '#fffdf8'; c.fill();
  if (colored) return;
  c.strokeStyle = lead(0.55); c.lineWidth = 1.6; c.lineJoin = 'round'; c.stroke();
  hatch(c, path, x - 50 * k, y + 2 * k, x + 50 * k, y + 13 * k, { gap: 4, a: 0.22 });
}

// a sun: drawn, but never colored in (or, colored, a big crayon sun)
function sketchSun(c, x, y, r, t, colored) {
  c.save(); c.lineCap = 'round';
  if (colored) {
    glowDot(c, x, y, r * 2.8, '255,214,90', 0.35);
    c.strokeStyle = '#ffc83a'; c.lineWidth = 5;
    c.beginPath();
    for (let i = 0; i < 10; i++) { const a = (i / 10) * TAU + t * 0.15; c.moveTo(x + Math.cos(a) * (r + 8), y + Math.sin(a) * (r + 8)); c.lineTo(x + Math.cos(a) * (r + 20), y + Math.sin(a) * (r + 20)); }
    c.stroke();
    c.fillStyle = '#ffd23f'; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill();
    crayonFill(c, ell(x, y, r, r), x - r, y - r, x + r, y + r, '#ffb347', 0.3, 5, 7);
    c.strokeStyle = 'rgba(214,140,30,0.7)'; c.lineWidth = 2.2; c.beginPath(); c.arc(x, y, r, 0, TAU); c.stroke();
  } else {
    c.strokeStyle = lead(0.5); c.lineWidth = 1.7;
    c.beginPath(); c.arc(x, y, r, 0, TAU); c.stroke();
    c.beginPath();
    for (let i = 0; i < 10; i++) { const a = (i / 10) * TAU + 0.2; c.moveTo(x + Math.cos(a) * (r + 7), y + Math.sin(a) * (r + 7)); c.lineTo(x + Math.cos(a) * (r + 16), y + Math.sin(a) * (r + 16)); }
    c.stroke();
    c.strokeStyle = lead(0.22); c.lineWidth = 1;
    c.beginPath(); c.arc(x + 2, y - 1.5, r + 3, 0.5, 5.4);
    c.moveTo(x - r - 10, y); c.lineTo(x + r + 10, y); c.moveTo(x, y - r - 10); c.lineTo(x, y + r + 10);
    c.stroke();
  }
  c.restore();
}

// a band of hills: fill, then the line along the top (ink), with quick pencil shading under it (shadeA)
function sketchHills(c, W, H, camX, f, base, amp, seed, fill, ink, shadeA = 0) {
  const off = camX * f;
  const yAt = xx => base - amp * (0.6 * Math.sin((xx + off) * 0.004 + seed) + 0.4 * Math.sin((xx + off) * 0.011 + seed * 2.3));
  c.beginPath(); c.moveTo(0, H); for (let xx = 0; xx <= W + 16; xx += 16) c.lineTo(xx, yAt(xx)); c.lineTo(W, H); c.closePath();
  c.fillStyle = fill; c.fill();
  c.beginPath(); for (let xx = 0; xx <= W + 16; xx += 16) { if (xx) c.lineTo(xx, yAt(xx)); else c.moveTo(xx, yAt(xx)); }
  c.strokeStyle = ink; c.lineWidth = 2; c.lineJoin = 'round'; c.stroke();
  if (shadeA > 0) {
    c.strokeStyle = lead(shadeA); c.lineWidth = 1.1; c.lineCap = 'round';
    c.beginPath();
    for (let xx = -(((off % 10) + 10) % 10); xx < W + 10; xx += 10) { const yy = yAt(xx); c.moveTo(xx + 1, yy + 4); c.lineTo(xx + 7, yy + 13); }
    c.stroke();
  }
  return yAt;
}

// a little tree far off on the hills (pencil, or colored in)
function farTree(c, x, y, k, colored) {
  c.lineCap = 'round';
  c.strokeStyle = colored ? '#7a5232' : lead(0.5); c.lineWidth = 3 * k;
  c.beginPath(); c.moveTo(x, y); c.lineTo(x, y - 18 * k); c.stroke();
  c.beginPath(); c.arc(x, y - 28 * k, 13 * k, 0, TAU);
  c.fillStyle = colored ? '#5fae5c' : '#fdfbf5'; c.fill();
  c.strokeStyle = colored ? 'rgba(40,90,40,0.6)' : lead(0.5); c.lineWidth = 1.5; c.stroke();
  if (!colored) hatch(c, ell(x, y - 28 * k, 13 * k, 13 * k), x, y - 41 * k, x + 14 * k, y - 15 * k, { gap: 3.2, a: 0.25 });
}

// Queen Pristine's palace, far off on the horizon: faint pencil, or (colored) white and gold with pink flags
function farPalace(c, x, base, k, t, colored) {
  c.save(); c.translate(x, base); c.scale(k, k);
  c.lineJoin = 'round'; c.lineCap = 'round';
  if (colored) glowDot(c, 0, -190, 250, '255,240,200', 0.3);
  const ink = colored ? 'rgba(110,100,140,0.7)' : lead(0.42), lw = 1.7 / k;
  const body = colored ? '#fbf9ff' : 'rgba(253,251,246,0.72)';
  const towers = [[-172, 128, 34], [-104, 196, 40], [0, 296, 56], [104, 196, 40], [172, 128, 34]];
  c.strokeStyle = ink; c.lineWidth = lw;
  c.fillStyle = body; c.beginPath(); c.rect(-186, -104, 372, 104); c.fill(); c.stroke();
  for (let xx = -186; xx < 186; xx += 22) { c.beginPath(); c.rect(xx, -116, 12, 12); c.fill(); c.stroke(); }
  for (const [tx, th, tw] of towers) {
    c.fillStyle = body; c.beginPath(); c.rect(tx - tw / 2, -th, tw, th); c.fill(); c.stroke();
    c.fillStyle = colored ? (tx ? '#ff9ab0' : '#f2c14e') : body;
    c.beginPath(); c.moveTo(tx - tw / 2 - 7, -th); c.lineTo(tx, -th - tw * 1.9); c.lineTo(tx + tw / 2 + 7, -th); c.closePath(); c.fill(); c.stroke();
    const fy = -th - tw * 1.9;
    c.beginPath(); c.moveTo(tx, fy); c.lineTo(tx, fy - 26); c.stroke();
    c.fillStyle = colored ? '#e5534b' : body;
    c.beginPath(); c.moveTo(tx, fy - 26); c.lineTo(tx + 20 + Math.sin(t * 3 + tx) * 3, fy - 21); c.lineTo(tx, fy - 15); c.closePath(); c.fill(); c.stroke();
    c.fillStyle = colored ? '#9fd8f0' : 'rgba(0,0,0,0)';
    for (let wy = -th + 26; wy < -40; wy += 44) { c.beginPath(); c.rect(tx - 6, wy, 12, 18); c.fill(); c.stroke(); }
  }
  c.fillStyle = colored ? '#c9a2e8' : body;
  c.beginPath(); c.moveTo(-26, 0); c.lineTo(-26, -40); c.arc(0, -40, 26, Math.PI, 0); c.lineTo(26, 0); c.fill(); c.stroke();
  if (!colored) {
    c.strokeStyle = lead(0.22); c.lineWidth = 1.2 / k; c.beginPath();
    for (const [tx, th, tw] of towers) for (let yy = -th + 8; yy < -8; yy += 9) { c.moveTo(tx + tw * 0.12, yy + 6); c.lineTo(tx + tw * 0.48, yy); }
    c.stroke();
  }
  c.restore();
}

// The Unfinished Margin: a sky that's still a blank notebook page (blue lines, the red margin line), pencil hills and
// clouds, a sun nobody colored in, and Queen Pristine's palace sketched on the horizon. opts.freed: all colored in.
EXTRA_BACKDROPS.margin = (c, camX, W, H, t, opts) => {
  const freed = !!(opts && opts.freed);
  const top = Math.max(-300, Math.min(260, skyTop(c))), y0 = Math.min(0, top);
  c.fillStyle = freed ? vgrad(c, top, 400, '#8fd0f2', '#fdf2d8') : vgrad(c, top, 400, '#fcfaf4', '#ebe5d6');
  c.fillRect(0, y0, W, H - y0);
  c.strokeStyle = freed ? 'rgba(255,255,255,0.22)' : 'rgba(110,150,215,0.24)'; c.lineWidth = 1.2;
  c.beginPath(); for (let ly = Math.floor(y0 / 30) * 30 + 12; ly < 410; ly += 30) { c.moveTo(0, ly); c.lineTo(W, ly); } c.stroke();
  const mx = 86 - camX * 0.01;
  c.strokeStyle = freed ? 'rgba(229,83,75,0.3)' : 'rgba(229,83,75,0.42)'; c.lineWidth = 1.6;
  c.beginPath(); c.moveTo(mx, y0); c.lineTo(mx, 410); c.moveTo(mx + 5, y0); c.lineTo(mx + 5, 410); c.stroke();
  sketchSun(c, 790 - camX * 0.012, Math.min(top + 74, 235), 34, t, freed);
  for (let i = 0; i < 4; i++) {
    const cx = ((i * 310 - camX * 0.06 + t * 5) % (W + 320) + W + 320) % (W + 320) - 160;
    sketchCloud(c, cx, Math.min(top + 50 + i * 26, 285 - i * 12), 0.8 + hash(i) * 0.4, freed);
  }
  farPalace(c, 650 - camX * 0.04, 342, Math.max(0.2, Math.min(0.85, (338 - top - 30) / 400)), t, freed);
  sketchHills(c, W, H, camX, 0.04, 332, 22, 1.3, freed ? '#c4e6ae' : '#f4efe3', freed ? 'rgba(255,250,240,0.8)' : lead(0.5), freed ? 0 : 0.22);
  const yMid = sketchHills(c, W, H, camX, 0.12, 364, 18, 3.4, freed ? '#a3d68c' : '#eee8db', freed ? 'rgba(255,250,240,0.8)' : lead(0.55), freed ? 0 : 0.25);
  const sp = 170, off = ((camX * 0.12) % sp + sp) % sp;
  for (let i = -1; i < W / sp + 2; i++) {
    const seed = Math.floor((camX * 0.12) / sp) + i;
    if (hash(seed * 1.3) < 0.45) continue;
    const tx = i * sp - off + hash(seed) * 60;
    farTree(c, tx, yMid(tx) + 3, 0.8 + hash(seed + 2) * 0.4, freed);
  }
  sketchHills(c, W, H, camX, 0.25, 394, 13, 5.2, freed ? '#88c972' : '#e7e0d0', freed ? 'rgba(255,250,240,0.8)' : lead(0.6), freed ? 0 : 0.28);
};

// the sketchbook's spiral binding, along the top of a page
function binding(c, W) {
  c.fillStyle = '#4a4458'; c.fillRect(0, 0, W, 16);
  c.fillStyle = 'rgba(20,10,30,0.12)'; c.fillRect(0, 16, W, 5);
  c.lineCap = 'round';
  for (let rx = 20; rx < W; rx += 32) {
    c.fillStyle = '#3a3346'; c.beginPath(); c.ellipse(rx, 31, 4.2, 4.2, 0, 0, TAU); c.fill();
    c.beginPath(); c.moveTo(rx - 1, 31); c.bezierCurveTo(rx - 10, 18, rx - 8, 2, rx + 4, 2);
    c.strokeStyle = INK; c.lineWidth = 5.4; c.stroke();
    c.strokeStyle = '#dcd9e6'; c.lineWidth = 2.8; c.stroke();
  }
}

// a childlike crayon picture filling the box (x, y, w, h): sky, a hill, the sun, and friends standing on it
function crayonPicture(c, x, y, w, h, seed = 0) {
  c.save(); c.beginPath(); c.rect(x, y, w, h); c.clip();
  crayonFill(c, cc => cc.rect(x, y, w, h * 0.62), x, y, x + w, y + h * 0.62, '#8fc8f0', 0.55, Math.max(3, h * 0.05), seed);
  const hill = cc => { cc.moveTo(x, y + h * 0.72); cc.quadraticCurveTo(x + w * 0.5, y + h * 0.48, x + w, y + h * 0.7); cc.lineTo(x + w, y + h); cc.lineTo(x, y + h); cc.closePath(); };
  crayonFill(c, hill, x, y + h * 0.48, x + w, y + h, '#6cc25a', 0.85, Math.max(3, h * 0.05), seed + 3);
  const r = Math.min(w, h) * 0.12, sx = x + w * (seed % 2 ? 0.2 : 0.8), sy = y + h * 0.2;
  c.lineCap = 'round'; c.lineJoin = 'round';
  c.strokeStyle = '#ffc83a'; c.lineWidth = Math.max(2, r * 0.22);
  c.beginPath(); for (let i = 0; i < 8; i++) { const a = (i / 8) * TAU; c.moveTo(sx + Math.cos(a) * r * 1.3, sy + Math.sin(a) * r * 1.3); c.lineTo(sx + Math.cos(a) * r * 1.9, sy + Math.sin(a) * r * 1.9); } c.stroke();
  crayonFill(c, ell(sx, sy, r, r), sx - r, sy - r, sx + r, sy + r, '#ffd23f', 0.95, Math.max(2.5, r * 0.3), seed + 5);
  // friends: a candle with a flame, a little blue crayon, a green blob (drawn the way a kid draws them)
  const u = Math.min(w, h) / 100, gy = y + h * 0.8;
  const lw = Math.max(1.6, 2.6 * u);
  const fx = x + w * (seed % 2 ? 0.62 : 0.36);
  c.lineWidth = lw;
  c.strokeStyle = '#4f72bf'; c.fillStyle = '#fff6dc';
  c.beginPath(); c.rect(fx - 6 * u, gy - 26 * u, 12 * u, 22 * u); c.fill(); c.stroke();
  c.strokeStyle = '#ff8a3d'; c.beginPath(); c.moveTo(fx, gy - 27 * u); c.quadraticCurveTo(fx + 5 * u, gy - 34 * u, fx, gy - 40 * u); c.quadraticCurveTo(fx - 5 * u, gy - 34 * u, fx, gy - 27 * u); c.stroke();
  c.strokeStyle = '#5b8def'; c.lineWidth = lw * 1.3;
  c.beginPath(); c.moveTo(fx + 16 * u, gy - 4 * u); c.lineTo(fx + 16 * u, gy - 18 * u); c.lineTo(fx + 19 * u, gy - 24 * u); c.lineTo(fx + 22 * u, gy - 18 * u); c.lineTo(fx + 22 * u, gy - 4 * u); c.stroke();
  c.strokeStyle = '#4fae52'; c.lineWidth = lw;
  c.beginPath(); c.moveTo(fx - 26 * u, gy - 4 * u); c.quadraticCurveTo(fx - 20 * u, gy - 22 * u, fx - 14 * u, gy - 4 * u); c.closePath(); c.stroke();
  c.fillStyle = INK;
  for (const [ex, eyy] of [[fx - 2 * u, gy - 18 * u], [fx + 2.5 * u, gy - 18 * u], [fx - 22 * u, gy - 10 * u], [fx - 17 * u, gy - 10 * u]]) { c.beginPath(); c.arc(ex, eyy, Math.max(0.9, 1.2 * u), 0, TAU); c.fill(); }
  // and a heart, because of course
  c.fillStyle = '#ff6b8a'; const hx = x + w * (seed % 2 ? 0.86 : 0.12), hy = y + h * 0.5, hr = 5 * u;
  c.beginPath(); c.moveTo(hx, hy + hr); c.bezierCurveTo(hx - hr * 2, hy - hr * 0.4, hx - hr * 0.6, hy - hr * 1.8, hx, hy - hr * 0.5); c.bezierCurveTo(hx + hr * 0.6, hy - hr * 1.8, hx + hr * 2, hy - hr * 0.4, hx, hy + hr); c.fill();
  c.restore();
}

// an ornate gold picture frame (x, y = its top left). Empty, or (freed) with a crayon picture in it.
function goldFrame(c, x, y, w, h, freed, seed = 0) {
  paper(c, p => shape(c, p, rrect(x, y, w, h, 6), vgrad(c, y, y + h, GOLD[0], GOLD[1]), 2.4));
  const b = Math.max(9, Math.min(w, h) * 0.12);
  c.strokeStyle = 'rgba(140,90,20,0.55)'; c.lineWidth = 1.5; c.strokeRect(x + b * 0.45, y + b * 0.45, w - b * 0.9, h - b * 0.9);
  const ix = x + b, iy = y + b, iw = w - 2 * b, ih = h - 2 * b;
  c.fillStyle = '#fffefa'; c.fillRect(ix, iy, iw, ih);
  if (freed) crayonPicture(c, ix, iy, iw, ih, seed);
  else {   // where the picture was: a pale ghost of it, and the smudge where it was rubbed out
    c.fillStyle = 'rgba(160,150,190,0.12)'; c.fillRect(ix + iw * 0.1, iy + ih * 0.1, iw * 0.8, ih * 0.8);
    c.fillStyle = 'rgba(190,180,210,0.35)'; c.beginPath(); c.ellipse(ix + iw * 0.55, iy + ih * 0.56, iw * 0.24, ih * 0.1, -0.3, 0, TAU); c.fill();
  }
  c.strokeStyle = INK; c.lineWidth = 2; c.strokeRect(ix, iy, iw, ih);
  c.fillStyle = '#fff1b8'; c.strokeStyle = INK; c.lineWidth = 1.4;
  for (const [cx, cy] of [[x, y], [x + w, y], [x, y + h], [x + w, y + h]]) { c.beginPath(); c.arc(cx, cy, b * 0.55, 0, TAU); c.fill(); c.stroke(); }
  c.beginPath(); c.moveTo(x + w / 2 - b * 1.6, y + 1); c.quadraticCurveTo(x + w / 2, y - b * 1.6, x + w / 2 + b * 1.6, y + 1); c.closePath(); c.fill(); c.stroke();
}

// a white marble column, gold at the top and the foot, from y0 (top) to y1 (floor)
function column(c, x, y0, y1, w, freed = false, seed = 0) {
  paper(c, p => {
    shape(c, p, rrect(x - w * 0.5, y0 + 18, w, y1 - y0 - 36, 2), vgrad(c, y0, y1, '#ffffff', '#e2ddea'), 2.2);
    shape(c, p, rrect(x - w * 0.68, y1 - 22, w * 1.36, 22, 3), vgrad(c, y1 - 22, y1, '#fbfaff', '#cfc8dc'), 2.2);
    shape(c, p, rrect(x - w * 0.62, y1 - 30, w * 1.24, 10, 3), vgrad(c, y1 - 30, y1 - 20, GOLD[0], GOLD[1]), 2);
    shape(c, p, rrect(x - w * 0.72, y0, w * 1.44, 20, 4), vgrad(c, y0, y0 + 20, GOLD[0], GOLD[1]), 2.2);
    shape(c, p, ell(x - w * 0.66, y0 + 16, 6, 6), GOLD[0], 1.8);
    shape(c, p, ell(x + w * 0.66, y0 + 16, 6, 6), GOLD[0], 1.8);
  });
  c.strokeStyle = 'rgba(150,140,185,0.28)'; c.lineWidth = 1.6;
  c.beginPath(); for (let k = -2; k <= 2; k++) { c.moveTo(x + k * w * 0.18, y0 + 24); c.lineTo(x + k * w * 0.18, y1 - 34); } c.stroke();
  c.strokeStyle = 'rgba(140,90,20,0.6)'; c.lineWidth = 1.2;
  for (const sx of [-1, 1]) { c.beginPath(); c.arc(x + sx * w * 0.66, y0 + 16, 2.6, 0, TAU * 0.8); c.stroke(); }
  if (freed) {   // somebody's wound crayon ribbons round it, like a candy cane
    c.save(); c.beginPath(); c.rect(x - w * 0.5, y0 + 20, w, y1 - y0 - 50); c.clip();
    c.lineWidth = 6; c.lineCap = 'round'; c.globalAlpha *= 0.75;
    for (let yy = y0 + 10, i = 0; yy < y1; yy += 34, i++) {
      c.strokeStyle = CRAYONS[(i + seed) % CRAYONS.length];
      c.beginPath(); c.moveTo(x - w * 0.6, yy + 12); c.lineTo(x + w * 0.6, yy - 12); c.stroke();
    }
    c.restore();
  }
}

// A sketchbook page as big as the sky, behind a battle in the Margin: pencil sun, clouds and hills, an easel with a
// blank canvas, a giant pencil leaning on the page. opts.freed: the sketches are colored in with crayon.
EXTRA_BACKDROPS.marginstage = (c, camX, W, H, t, opts) => {
  const freed = !!(opts && opts.freed);
  c.fillStyle = vgrad(c, 0, H, '#fbf7ee', '#e7e0cf'); c.fillRect(0, 0, W, H);
  c.strokeStyle = 'rgba(110,150,215,0.26)'; c.lineWidth = 1.2;
  c.beginPath(); for (let ly = 78; ly < H; ly += 30) { c.moveTo(0, ly); c.lineTo(W, ly); } c.stroke();
  c.strokeStyle = 'rgba(229,83,75,0.42)'; c.lineWidth = 1.6;
  c.beginPath(); c.moveTo(60, 24); c.lineTo(60, H); c.moveTo(65, 24); c.lineTo(65, H); c.stroke();
  // what's been sketched on the page
  sketchSun(c, 790, 120, 38, t, freed);
  sketchCloud(c, 340, 116, 1.15, freed);
  sketchCloud(c, 600, 172, 0.85, freed);
  c.lineCap = 'round';
  c.strokeStyle = lead(0.45); c.lineWidth = 1.3;
  for (const [sx, sy, r] of [[470, 70, 7], [520, 98, 5], [900, 230, 6]]) { c.beginPath(); starPath(c, sx, sy, r, r * 0.45, 5); c.stroke(); }
  c.beginPath(); for (let a = 0; a < 16; a += 0.3) { const rr = a * 0.9; const px = 410 + Math.cos(a) * rr, py = 230 + Math.sin(a) * rr; if (a) c.lineTo(px, py); else c.moveTo(px, py); } c.stroke();
  const yA = sketchHills(c, W, H, 0, 0, 316, 30, 1.7, freed ? '#bfe6a8' : '#fbf8f0', freed ? '#6aa860' : lead(0.6), freed ? 0 : 0.3);
  if (freed) crayonFill(c, cc => { cc.moveTo(0, H); for (let xx = 0; xx <= W + 16; xx += 16) cc.lineTo(xx, yA(xx)); cc.lineTo(W, H); cc.closePath(); }, 0, 280, W, 400, '#7fd06a', 0.5, 5, 2);
  for (const [tx, k] of [[330, 1.6], [640, 1.25], [700, 1]]) farTree(c, tx, yA(tx) + 4, k, freed);
  sketchHills(c, W, H, 0, 0, 356, 16, 4.1, freed ? '#94d27e' : '#f6f2e8', freed ? '#4f8f48' : lead(0.6), freed ? 0 : 0.3);
  // the easel, with a canvas waiting on it
  const ex = 170, eb = 396;
  paper(c, p => {
    shape(c, p, poly([[ex - 3, eb - 250], [ex + 3, eb - 250], [ex + 7, eb], [ex - 1, eb]]), '#9a6a40', 2);
    shape(c, p, poly([[ex - 6, eb - 262], [ex + 2, eb - 262], [ex - 56, eb], [ex - 67, eb]]), vgrad(c, eb - 262, eb, '#c9925c', '#8a5a3c'), 2);
    shape(c, p, poly([[ex - 2, eb - 262], [ex + 6, eb - 262], [ex + 67, eb], [ex + 56, eb]]), vgrad(c, eb - 262, eb, '#c9925c', '#8a5a3c'), 2);
    shape(c, p, rrect(ex - 80, eb - 238, 160, 124, 3), '#fffefa', 2.4);
    shape(c, p, rrect(ex - 86, eb - 117, 172, 9, 3), '#b07a45', 2);
    shape(c, p, rrect(ex - 14, eb - 248, 28, 12, 3), '#b07a45', 2);
  });
  if (freed) crayonPicture(c, ex - 76, eb - 234, 152, 116, 1);
  else {   // nothing on it yet but guide lines
    c.strokeStyle = lead(0.4); c.lineWidth = 1.2;
    c.beginPath(); c.arc(ex - 8, eb - 178, 30, 0, TAU); c.moveTo(ex - 58, eb - 178); c.lineTo(ex + 50, eb - 178); c.moveTo(ex - 8, eb - 226); c.lineTo(ex - 8, eb - 126); c.stroke();
    c.strokeStyle = lead(0.2); c.beginPath(); c.arc(ex - 6, eb - 176, 34, 0.6, 5.2); c.stroke();
  }
  // crayons resting on the easel's tray
  for (const [i, colr] of [[0, '#e5534b'], [1, '#5b8def'], [2, '#ffd23f']]) {
    c.save(); c.translate(ex - 48 + i * 26, eb - 121); c.rotate(-0.08 + i * 0.05);
    paper(c, p => { shape(c, p, rrect(-10, -3.5, 17, 7, 2), colr, 1.6); shape(c, p, poly([[7, -3.5], [12, -1], [12, 1], [7, 3.5]]), tone(colr, 0.15), 1.6); });
    c.restore();
  }
  // a giant pencil leaning on the page, and its shavings
  c.save(); c.translate(818, 392); c.rotate(0.42);
  paper(c, p => {
    shape(c, p, poly([[-14, -34], [14, -34], [0, 0]]), vgrad(c, -34, 0, '#f6d8a8', '#d9a86a'), 2.2);
    shape(c, p, rrect(-14, -300, 28, 268, 2), vgrad(c, -300, -34, '#ffe066', '#f2b43a'), 2.4);
    shape(c, p, rrect(-15, -318, 30, 20, 2), vgrad(c, -318, -298, '#eceaf2', '#9ea3b5'), 2.2);
    shape(c, p, rrect(-14, -342, 28, 26, 7), vgrad(c, -342, -316, ERASER[0], ERASER[1]), 2.2);
  });
  c.fillStyle = '#3b3350'; c.beginPath(); c.moveTo(-5, -11); c.lineTo(5, -11); c.lineTo(0, 0); c.closePath(); c.fill();
  c.strokeStyle = 'rgba(150,100,20,0.35)'; c.lineWidth = 1.4; c.beginPath(); c.moveTo(-4.6, -298); c.lineTo(-4.6, -36); c.moveTo(4.6, -298); c.lineTo(4.6, -36); c.stroke();
  c.restore();
  for (const [sx, sy, r, a] of [[700, 384, 11, 0.3], [740, 390, 8, 2.2], [905, 386, 10, 4.1]]) {
    c.save(); c.translate(sx, sy); c.rotate(a);
    c.fillStyle = '#f6d8a8'; c.strokeStyle = INK; c.lineWidth = 1.6;
    c.beginPath(); c.arc(0, 0, r, 0.2, Math.PI * 1.7); c.arc(r * 0.2, r * 0.1, r * 0.45, Math.PI * 1.7, 0.2, true); c.closePath(); c.fill(); c.stroke();
    c.strokeStyle = '#f2b43a'; c.lineWidth = 2.4; c.beginPath(); c.arc(0, 0, r - 1.5, 0.3, Math.PI * 1.6); c.stroke();
    c.restore();
  }
  binding(c, W);
};

// Inside the palace, behind a battle: white marble, gold trim, columns, and picture frames with nothing in them
// (Queen Pristine took every picture down: none was perfect). opts.freed: crayon pictures hang in them now.
EXTRA_BACKDROPS.palacestage = (c, camX, W, H, t, opts) => {
  const freed = !!(opts && opts.freed);
  c.fillStyle = vgrad(c, 0, H, '#ffffff', '#dcd6e8'); c.fillRect(0, 0, W, H);
  c.strokeStyle = 'rgba(160,150,195,0.18)'; c.lineWidth = 1.3; c.lineCap = 'round';
  for (let i = 0; i < 10; i++) {
    const vx = hash(i * 4.1) * W, vy = 70 + hash(i * 2.7) * 240;
    c.beginPath(); c.moveTo(vx, vy); c.bezierCurveTo(vx + 30, vy + 20, vx + 50, vy - 10, vx + 90, vy + 14); c.stroke();
  }
  // a gold frieze along the top, and a gold rail lower down
  c.fillStyle = vgrad(c, 22, 46, GOLD[0], GOLD[1]); c.fillRect(0, 22, W, 24);
  c.fillStyle = '#fff1b8'; for (let dx = 8; dx < W; dx += 22) c.fillRect(dx, 48, 11, 7);
  c.strokeStyle = INK; c.lineWidth = 2;
  c.beginPath(); c.moveTo(0, 22); c.lineTo(W, 22); c.moveTo(0, 46); c.lineTo(W, 46); c.stroke();
  c.fillStyle = vgrad(c, 300, 310, GOLD[0], GOLD[1]); c.fillRect(0, 300, W, 10);
  c.beginPath(); c.moveTo(0, 300); c.lineTo(W, 300); c.moveTo(0, 310); c.lineTo(W, 310); c.stroke();
  c.strokeStyle = 'rgba(150,140,185,0.3)'; c.lineWidth = 1.5;
  for (let px = 20; px < W; px += 120) c.strokeRect(px, 322, 96, 54);
  // the frames between the columns
  goldFrame(c, 160, 104, 140, 168, freed, 1);
  goldFrame(c, 390, 76, 180, 206, freed, 2);
  goldFrame(c, 660, 104, 140, 168, freed, 3);
  for (const [i, cx] of [110, 350, 610, 850].entries()) column(c, cx, 56, 392, 46, freed, i);
  // soft light from the high windows
  c.save(); c.globalCompositeOperation = 'lighter'; c.fillStyle = 'rgba(255,250,235,0.05)';
  for (const bx of [200, 520]) { c.beginPath(); c.moveTo(bx, 0); c.lineTo(bx + 90, 0); c.lineTo(bx + 260, H); c.lineTo(bx + 110, H); c.closePath(); c.fill(); }
  c.restore();
  void t;
};

// a crayon flower (stem, a leaf, five waxy petals), growing up from (x, y)
function crayonFlower(c, x, y, h, col, t, seed) {
  const sw = Math.sin(t * 1.6 + seed) * 2.5;
  c.save(); c.lineCap = 'round'; c.lineJoin = 'round';
  c.strokeStyle = '#4fae52'; c.lineWidth = 3.4;
  c.beginPath(); c.moveTo(x, y); c.quadraticCurveTo(x - 3, y - h * 0.5, x + sw, y - h); c.stroke();
  c.fillStyle = '#5fbf6a'; c.beginPath(); c.ellipse(x - 5, y - h * 0.4, 6.5, 2.6, -0.6, 0, TAU); c.fill();
  const bx = x + sw, by = y - h;
  c.fillStyle = col; c.beginPath(); starPath(c, bx, by, 11, 6, 5, seed); c.fill();
  c.strokeStyle = tone(col, -0.3); c.lineWidth = 1.6; c.stroke();
  c.strokeStyle = 'rgba(255,255,255,0.4)'; c.lineWidth = 1.2;
  c.beginPath(); c.moveTo(bx - 6, by - 2); c.lineTo(bx - 2, by - 6); c.lineTo(bx + 1, by - 2); c.lineTo(bx + 5, by - 6); c.stroke();
  c.fillStyle = '#ffd23f'; c.beginPath(); c.arc(bx, by, 3.4, 0, TAU); c.fill();
  c.restore();
}

// Queen Pristine's great white throne on its dais, standing at (x, base), scaled by k
function bigThrone(c, x, base, k, t, freed) {
  c.save(); c.translate(x, base); c.scale(k, k);
  const back = cc => { cc.moveTo(-70, -60); cc.lineTo(-70, -230); cc.quadraticCurveTo(-70, -290, 0, -330); cc.quadraticCurveTo(70, -290, 70, -230); cc.lineTo(70, -60); cc.closePath(); };
  paper(c, p => {
    shape(c, p, rrect(-150, -18, 300, 18, 3), vgrad(c, -18, 0, '#ffffff', '#d9d3e4'), 2.4);
    shape(c, p, rrect(-118, -36, 236, 20, 3), vgrad(c, -36, -16, '#ffffff', '#dcd6e6'), 2.4);
    shape(c, p, back, vgrad(c, -330, -60, '#ffffff', '#e6e1ee'), 2.6);
    shape(c, p, rrect(-80, -72, 16, 38, 4), '#ece8f2', 2.2);
    shape(c, p, rrect(64, -72, 16, 38, 4), '#ece8f2', 2.2);
    shape(c, p, rrect(-84, -98, 168, 28, 7), vgrad(c, -98, -70, '#ffffff', '#e2ddea'), 2.4);
    shape(c, p, rrect(-100, -136, 26, 72, 9), vgrad(c, -136, -64, '#ffffff', '#e2ddea'), 2.4);
    shape(c, p, rrect(74, -136, 26, 72, 9), vgrad(c, -136, -64, '#ffffff', '#e2ddea'), 2.4);
    shape(c, p, ell(-87, -138, 10, 10), GOLD[0], 2);
    shape(c, p, ell(87, -138, 10, 10), GOLD[0], 2);
    shape(c, p, poly([[-14, -326], [-16, -346], [-7, -338], [0, -360], [7, -338], [16, -346], [14, -326]]), vgrad(c, -360, -326, GOLD[0], GOLD[1]), 2.2);
  });
  // gold trim: inside the back, along the steps
  c.strokeStyle = GOLD[1]; c.lineWidth = 4; c.lineJoin = 'round';
  c.beginPath(); c.moveTo(-56, -102); c.lineTo(-56, -226); c.quadraticCurveTo(-56, -276, 0, -310); c.quadraticCurveTo(56, -276, 56, -226); c.lineTo(56, -102); c.stroke();
  c.lineWidth = 3; c.beginPath(); c.moveTo(-147, -15); c.lineTo(147, -15); c.moveTo(-115, -33); c.lineTo(115, -33); c.stroke();
  if (freed) {
    // a red velvet cushion, a crayon heart on the back, and gems in every color
    const pad = cc => { cc.moveTo(-46, -110); cc.lineTo(-46, -220); cc.quadraticCurveTo(-46, -262, 0, -292); cc.quadraticCurveTo(46, -262, 46, -220); cc.lineTo(46, -110); cc.closePath(); };
    crayonFill(c, pad, -50, -296, 50, -106, '#e5534b', 0.75, 6, 4);
    c.fillStyle = '#ff9ab0'; c.strokeStyle = INK; c.lineWidth = 2;
    c.beginPath(); c.moveTo(0, -150); c.bezierCurveTo(-36, -176, -18, -214, 0, -196); c.bezierCurveTo(18, -214, 36, -176, 0, -150); c.fill(); c.stroke();
    crayonFill(c, rrect(-82, -96, 164, 24, 7), -84, -98, 84, -70, '#ff6b6b', 0.7, 5, 9);
    for (const [gx, gy, gc] of [[-87, -138, '#5b8def'], [87, -138, '#5fbf6a'], [0, -340, '#ff8ab0']]) { c.fillStyle = gc; c.beginPath(); c.arc(gx, gy, 5.5, 0, TAU); c.fill(); c.stroke(); }
  } else {
    c.fillStyle = 'rgba(180,170,205,0.18)'; c.beginPath(); c.ellipse(0, -200, 26, 60, 0, 0, TAU); c.fill();
  }
  c.restore();
  void t;
}

// The Blank Throne: Queen Pristine's throne room. A vast white hall, white columns, the huge white throne, and over it
// the biggest frame of all, still empty. opts.freed: colorful, crayon flowers along the walls, a picture in the frame.
// (The throne sits at x = 480 - (camX - 400) * 0.22, so it's centered behind a battle.)
EXTRA_BACKDROPS.blankthrone = (c, camX, W, H, t, opts) => {
  const freed = !!(opts && opts.freed);
  const top = Math.max(-300, Math.min(300, skyTop(c))), y0 = Math.min(0, top), floorY = 403;
  c.fillStyle = freed ? vgrad(c, Math.max(top, 0), floorY, '#fff6ee', '#f4e2f2') : vgrad(c, Math.max(top, 0), floorY, '#ffffff', '#e3dfeb');
  c.fillRect(0, y0, W, H - y0);
  if (freed) {   // a soft crayon wash over the walls
    c.save(); c.lineWidth = 14; c.lineCap = 'round'; c.globalAlpha *= 0.12;
    for (let i = 0; i < 14; i++) {
      const sx = hash(i * 3.7) * W - camX * 0.1 % 200, sy = top + 30 + hash(i * 1.9) * (floorY - top - 60);
      c.strokeStyle = CRAYONS[i % CRAYONS.length];
      c.beginPath(); c.moveTo(sx, sy); c.lineTo(sx + 60, sy - 24); c.lineTo(sx + 30, sy + 4); c.lineTo(sx + 90, sy - 20); c.stroke();
    }
    c.restore();
  }
  c.strokeStyle = 'rgba(160,150,190,0.16)'; c.lineWidth = 1.4;
  c.beginPath(); for (let yy = floorY - 70; yy > y0; yy -= 70) { c.moveTo(0, yy); c.lineTo(W, yy); } c.stroke();
  const ctop = Math.max(top, -60) + 10;
  const sp = 250, off = ((camX * 0.3) % sp + sp) % sp;
  for (let i = -1; i < W / sp + 2; i++) {
    const seed = Math.floor((camX * 0.3) / sp) + i;
    column(c, i * sp - off + 40, ctop, floorY - 2, 46, freed, Math.abs(seed));
    if (freed) {   // and a banner in a different color between each pair of columns
      const bx = i * sp - off + 165, col = CRAYONS[Math.abs(seed) % CRAYONS.length];
      paper(c, p => shape(c, p, poly([[bx - 22, ctop + 34], [bx + 22, ctop + 34], [bx + 22, ctop + 150], [bx, ctop + 132], [bx - 22, ctop + 150]]), col, 2));
      c.fillStyle = '#fffaf0'; c.beginPath(); starPath(c, bx, ctop + 76, 10, 4.5, 5); c.fill();
    }
  }
  c.fillStyle = vgrad(c, floorY - 14, floorY, GOLD[0], GOLD[1]); c.fillRect(0, floorY - 14, W, 14);
  c.strokeStyle = INK; c.lineWidth = 2; c.beginPath(); c.moveTo(0, floorY - 14); c.lineTo(W, floorY - 14); c.stroke();
  // the great frame, and the throne in front of it
  const k = Math.max(0.42, Math.min(1, (floorY - Math.max(top, 0) - 16) / 360));
  const tx = 480 - (camX - 400) * 0.22;
  goldFrame(c, tx - 200 * k, floorY - 362 * k, 400 * k, 290 * k, freed, 2);
  bigThrone(c, tx, floorY, k * 0.82, t, freed);
  if (freed) {
    const fs = 46, foff = ((camX * 0.3) % fs + fs) % fs;
    for (let i = -1; i < W / fs + 2; i++) {
      const fx = i * fs - foff, seed = Math.abs(Math.floor((camX * 0.3) / fs) + i);
      if (Math.abs(fx - tx) < 130 * k) continue;   // (not in front of the throne's steps)
      crayonFlower(c, fx + hash(seed) * 18, floorY - 2, 22 + hash(seed + 1) * 20, CRAYONS[seed % CRAYONS.length], t, seed);
    }
  }
};

// ---------------------------------------------------------------- floors, rooms and scenery sets
MAT.margin = { top: '#f3efe4', front: ['#d9d3c4', '#b6ae9c'], side: '#c7bfae', floor: 'sand' };
MAT.marginstage = MAT.margin;
MAT.palacestage = { top: '#f4f1f8', front: ['#e0dae8', '#b8b0c8'], side: '#cbc4d8', floor: 'tile' };
MAT.blankthrone = MAT.palacestage;
STYLES.palace = { wall: ['#fbf9ff', '#e4dfee'], trim: '#e0b450', pattern: 'bricks', pat: 'rgba(150,140,185,0.2)', mat: { top: '#f1edf6', front: ['#ddd7e6', '#b9b1c9'], side: '#cbc4d8', floor: 'tile' } };
FIELD_DECOR.margin = {
  dens: 0.3,
  // (flowers too: in the pencil-sketch Margin they only show their color in Wick's light)
  kinds: [['sketchtree', 4], ['paperball', 3], ['pencil', 2], ['ruler', 2], ['eraserblock', 1], ['tuft', 2], ['rock', 1], ['flower', 3]],
  edge: ['sketchtree', 'sketchtree', 'pencil', 'sketchtree', 'ruler'],
  grove: ['sketchtree', 'paperball'],
};
// Once a Color Fount flows, that part of the Margin is colored in for good: crayon-green ground, the colored sky, and
// real leafy trees and flowers among the sketches (the rooms switch theme: see margin.js)
MAT.marginfree = { top: '#cde9a8', front: ['#a9d184', '#82ad62'], side: '#95bf74', floor: 'grass', lip: '#e2f4c8' };
EXTRA_BACKDROPS.marginfree = (c, camX, W, H, t, opts) => EXTRA_BACKDROPS.margin(c, camX, W, H, t, { ...(opts || {}), freed: true });
FIELD_DECOR.marginfree = {
  dens: 0.32,
  kinds: [['tree', 3], ['sketchtree', 1], ['flower', 5], ['pencil', 1], ['ruler', 1], ['tuft', 3], ['bush', 1]],
  edge: ['tree', 'tree', 'sketchtree', 'tree', 'pencil'],
  grove: ['tree', 'tree', 'sketchtree'],
};
DECOR_FOOT.sketchtree = [14, 10, 140];
DECOR_FOOT.pencil = [14, 10, 150];
DECOR_FOOT.eraserblock = [46, 16, 48];
DECOR_FOOT.ruler = [10, 6, 110];

Object.assign(DRAW, {
  doodle: drawDoodle, draftee: drawDraftee, crease: drawCrease, erasebit: drawErasebit, redpen: drawRedpen,
  crumple: drawCrumple, straightedge: drawStraightedge, wastebasket: drawWastebasket, pristine: drawPristine, fount: drawFount,
});
