// Art for the side areas (extras.js): the bookend twins Pairsley and Twain (the Study Bridges), Nonna Pomodoro and her
// grandson Timo (the Pomodoro Mill), Maestra Quartz and the geode kids (the Crystal Choir), Chip the stonecutter (the
// Chunky Quarry), Woolly the cloud sheep and her dream lambs (the Drowsy Downs), and the things their places are made
// of: buddy pads, the mill's tomato timer, singing crystals and nap pillows. Same drawing rule as everything else: flat
// paper cutouts with a white paper edge and an ink line (paper/shape from art.js). Importing this file adds them all.
import { DRAW, INK, PAPER, paper, shape, rrect, ell, poly, vgrad, glowDot, eyes, mouth, starPath, shadow } from './art.js';

const TAU = Math.PI * 2;

// lighten (k > 0) or darken (k < 0) a '#rrggbb' color
function tone(hex, k) {
  let h = String(hex || '').trim().replace('#', '');
  if (h.length === 3) h = h.split('').map(ch => ch + ch).join('');
  const n = parseInt(h, 16);
  if (h.length !== 6 || Number.isNaN(n)) return hex;
  const f = v => Math.round(k < 0 ? v * (1 + k) : v + (255 - v) * k);
  return `rgb(${f((n >> 16) & 255)},${f((n >> 8) & 255)},${f(n & 255)})`;
}
function rgbOf(hex) {
  let h = String(hex || '').trim().replace('#', '');
  if (h.length === 3) h = h.split('').map(ch => ch + ch).join('');
  const n = parseInt(h, 16) || 0;
  return `${(n >> 16) & 255},${(n >> 8) & 255},${n & 255}`;
}
function blush(c, x, y, r = 3.5) {
  c.save(); c.fillStyle = 'rgba(255,120,150,0.45)';
  c.beginPath(); c.ellipse(x, y, r, r * 0.6, 0, 0, TAU); c.fill(); c.restore();
}
function zzz(c, x, y, t, k = 1) {
  c.save(); c.fillStyle = 'rgba(255,250,240,0.9)'; c.strokeStyle = INK; c.lineWidth = 2.5 * k;
  c.font = `bold ${Math.round(13 * k)}px Fredoka, sans-serif`; c.textAlign = 'center';
  for (let i = 0; i < 3; i++) {
    const q = (t * 0.45 + i / 3) % 1, a = Math.sin(q * Math.PI);
    c.globalAlpha = a;
    c.strokeText('z', x + q * 16 * k + i * 3, y - q * 30 * k);
    c.fillText('z', x + q * 16 * k + i * 3, y - q * 30 * k);
  }
  c.restore();
}
function spectacles(c, x1, x2, y, r = 4.6) {
  c.save(); c.strokeStyle = INK; c.lineWidth = 1.6; c.fillStyle = 'rgba(220,240,255,0.35)';
  for (const x of [x1, x2]) { c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill(); c.stroke(); }
  c.beginPath(); c.moveTo(x1 + r, y - 1); c.quadraticCurveTo((x1 + x2) / 2, y - 3.5, x2 - r, y - 1); c.stroke();
  c.restore();
}

// ---------------------------------------------------------------- the Study Bridges
// A bookend with a face. Pairsley (purple) is tidy, with round glasses and a ribbon bookmark; Twain (orange) is a
// scruffy one with a dog-eared page sticking up like a cowlick.
export function drawBookend(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, twain = o.who === 'twain';
  const col = o.color || (twain ? '#f0a050' : '#8f7ad6'), mood = o.mood || 'normal';
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 20 * s);
  c.scale(s * flip, s);
  c.translate(0, Math.sin(t * 2.1 + (twain ? 1.3 : 0)) * 0.8);
  paper(c, p => {
    // the book it holds up, leaning on its back
    shape(c, p, cc => { cc.save(); cc.translate(-17, -2); cc.rotate(twain ? -0.32 : -0.12); rrect(-8, -46, 12, 46, 2)(cc); cc.restore(); }, twain ? '#5b8def' : '#5fbf6a', 2);
    shape(c, p, rrect(-21, -7, 42, 7, 2.5), tone(col, -0.3));                 // the base plate
    shape(c, p, rrect(-13, -66, 26, 61, 6), vgrad(c, -66, -5, tone(col, 0.25), col));
    shape(c, p, ell(-15, -30, 4.2, 5), tone(col, -0.12), 2);                  // arms
    shape(c, p, ell(15, -30, 4.2, 5), tone(col, -0.12), 2);
    if (twain) shape(c, p, poly([[-3, -64], [6, -78], [9, -64]]), PAPER, 1.8);  // the dog-eared page
    else shape(c, p, poly([[5, -66], [5, -80], [9, -76], [13, -80], [13, -66]]), '#e5534b', 1.8);   // the ribbon
  });
  c.fillStyle = 'rgba(255,255,255,0.3)'; c.fillRect(-9, -62, 4, 50);
  eyes(c, -5, 5, -45, 7.5, mood, t);
  if (!twain) spectacles(c, -5, 5, -45);
  blush(c, -8.5, -36); blush(c, 8.5, -36);
  mouth(c, 0, -34, 5, mood);
  c.restore();
}

// A buddy pad: an open book lying on the floor. Ask your partner to wait on one and whatever it's tied to stays up.
export function drawBuddyPad(c, x, y, o = {}) {
  const t = o.t || 0, on = !!o.on;
  c.save(); c.translate(x, y);
  if (on) glowDot(c, 0, -6, 46, '255,214,120', 0.45 + 0.1 * Math.sin(t * 4));
  paper(c, p => {
    shape(c, p, poly([[-30, -2], [-3, -9], [-1, 2], [-28, 8]]), on ? '#fff3c4' : PAPER, 2);
    shape(c, p, poly([[30, -2], [3, -9], [1, 2], [28, 8]]), on ? '#fff3c4' : PAPER, 2);
    shape(c, p, rrect(-3, -10, 6, 13, 2), '#8f7ad6', 1.6);
  });
  c.strokeStyle = 'rgba(43,34,53,0.35)'; c.lineWidth = 1;
  for (let i = 0; i < 3; i++) {
    c.beginPath(); c.moveTo(-24 + i * 2, -1 + i * 2.6); c.lineTo(-7, -5 + i * 2.6); c.stroke();
    c.beginPath(); c.moveTo(24 - i * 2, -1 + i * 2.6); c.lineTo(7, -5 + i * 2.6); c.stroke();
  }
  // a little heart-and-hands sign: "study together here"
  c.fillStyle = on ? '#e5534b' : 'rgba(229,83,75,0.55)';
  c.beginPath(); c.moveTo(0, -14); c.bezierCurveTo(-7, -21, -2, -27, 0, -22); c.bezierCurveTo(2, -27, 7, -21, 0, -14); c.fill();
  if (on) {
    for (let i = 0; i < 2; i++) {
      const q = (t * 0.7 + i * 0.5) % 1;
      c.globalAlpha = Math.sin(q * Math.PI);
      c.fillStyle = '#ff8ab0';
      const hx = -10 + i * 20, hy = -24 - q * 34;
      c.beginPath(); c.moveTo(hx, hy); c.bezierCurveTo(hx - 5, hy - 5, hx - 1, hy - 9, hx, hy - 5.5); c.bezierCurveTo(hx + 1, hy - 9, hx + 5, hy - 5, hx, hy); c.fill();
    }
    c.globalAlpha = 1;
  }
  c.restore();
}

// ---------------------------------------------------------------- the Pomodoro Mill
// Nonna Pomodoro: a round tomato granny with a kitchen-timer dial on her apron, spectacles and a wooden spoon.
// With o.kid it's her grandson Timo instead: smaller, a leaf cap on backwards, no spoon.
export function drawNonna(c, x, y, o = {}) {
  const t = o.t || 0, kid = !!o.kid, s = (o.scale || 1) * (kid ? 0.66 : 1), flip = o.flip ?? 1;
  const mood = o.mood || (kid ? 'normal' : 'happy');
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 24 * s);
  c.scale(s * flip, s);
  c.translate(0, Math.sin(t * 2.4 + (kid ? 2 : 0)) * 0.9);
  const red = '#ef5a4a';
  paper(c, p => {
    shape(c, p, ell(-10, -3, 7, 4), '#3f8a3a');                               // shoes
    shape(c, p, ell(10, -3, 7, 4), '#3f8a3a');
    shape(c, p, ell(-29, -30, 5.5, 6.5), tone(red, -0.1), 2);                 // arms
    if (!kid) {
      shape(c, p, cc => { cc.save(); cc.translate(31, -36); cc.rotate(0.35); rrect(-2, -26, 4, 30, 2)(cc); cc.restore(); }, '#c0905a', 1.8);
      shape(c, p, cc => { cc.save(); cc.translate(31, -36); cc.rotate(0.35); ell(0, -30, 6, 8)(cc); cc.restore(); }, '#d9a86a', 1.8);
    }
    shape(c, p, ell(29, -30, 5.5, 6.5), tone(red, -0.1), 2);
    shape(c, p, ell(0, -31, 31, 28), vgrad(c, -59, -3, '#ff8a76', '#d63a32'));
    // her apron: a kitchen timer's dial
    shape(c, p, ell(0, -20, kid ? 11 : 13.5, kid ? 11 : 13.5), PAPER, 2);
    // the leafy cap (Timo wears his backwards, like a ball cap)
    const leaves = [];
    for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + (i * Math.PI) / 5, r = i % 2 ? 6 : 15; leaves.push([Math.cos(a) * r + (kid ? -4 : 0), -58 + Math.sin(a) * r * 0.45]); }
    shape(c, p, poly(leaves), '#5fbf6a', 1.8);
    shape(c, p, rrect(-2.5, -70, 5, 10, 2), '#3f8a3a', 1.6);
  });
  c.fillStyle = 'rgba(255,255,255,0.4)'; c.beginPath(); c.ellipse(-14, -45, 8, 4.5, -0.5, 0, TAU); c.fill();
  // the dial: ticks and a hand that creeps round
  const dr = kid ? 11 : 13.5;
  c.strokeStyle = INK; c.lineWidth = 1.2;
  for (let i = 0; i < 12; i++) { const a = (i / 12) * TAU; c.beginPath(); c.moveTo(Math.cos(a) * dr * 0.72, -20 + Math.sin(a) * dr * 0.72); c.lineTo(Math.cos(a) * dr * 0.88, -20 + Math.sin(a) * dr * 0.88); c.stroke(); }
  const ha = -Math.PI / 2 + (o.dial ?? (t * 0.4)) * TAU;
  c.lineWidth = 2; c.strokeStyle = '#e5534b'; c.beginPath(); c.moveTo(0, -20); c.lineTo(Math.cos(ha) * dr * 0.7, -20 + Math.sin(ha) * dr * 0.7); c.stroke();
  c.fillStyle = INK; c.beginPath(); c.arc(0, -20, 1.8, 0, TAU); c.fill();
  eyes(c, -9, 9, -40, 7.5, mood, t);
  if (!kid) spectacles(c, -9, 9, -40, 5.2);
  blush(c, -18, -33); blush(c, 18, -33);
  mouth(c, 0, -33, 6, mood);
  if (mood === 'sleep' || mood === 'sleepy') zzz(c, 22, -60, t);
  c.restore();
}

// The mill's big tomato timer on the wall. phase 'focus' (red) or 'break' (green); k: how far through it (0..1).
export function drawPomoDial(c, x, y, o = {}) {
  const k = o.k || 0, focus = o.phase !== 'break', warn = !!o.warn, t = o.t || 0;
  c.save(); c.translate(x, y);
  paper(c, p => {
    shape(c, p, ell(0, 0, 50, 46), vgrad(c, -46, 46, '#ff8a76', '#d63a32'));
    const leaves = [];
    for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + (i * Math.PI) / 5, r = i % 2 ? 7 : 20; leaves.push([Math.cos(a) * r, -46 + Math.sin(a) * r * 0.5]); }
    shape(c, p, poly(leaves), '#5fbf6a', 2);
    shape(c, p, ell(0, 2, 33, 33), PAPER, 2.2);
  });
  // what's left of this phase, as a colored wedge
  c.fillStyle = focus ? 'rgba(229,83,75,0.85)' : 'rgba(95,191,106,0.9)';
  c.beginPath(); c.moveTo(0, 2); c.arc(0, 2, 30, -Math.PI / 2 + k * TAU, -Math.PI / 2 + TAU); c.closePath(); c.fill();
  c.strokeStyle = INK; c.lineWidth = 1.4;
  for (let i = 0; i < 12; i++) { const a = (i / 12) * TAU; c.beginPath(); c.moveTo(Math.cos(a) * 26, 2 + Math.sin(a) * 26); c.lineTo(Math.cos(a) * 31, 2 + Math.sin(a) * 31); c.stroke(); }
  const ha = -Math.PI / 2 + k * TAU;
  c.lineWidth = 3; c.beginPath(); c.moveTo(0, 2); c.lineTo(Math.cos(ha) * 24, 2 + Math.sin(ha) * 24); c.stroke();
  c.fillStyle = INK; c.beginPath(); c.arc(0, 2, 3, 0, TAU); c.fill();
  // the word under it
  const label = focus ? 'FOCUS' : 'BREAK';
  c.font = 'bold 15px Fredoka, sans-serif'; c.textAlign = 'center';
  const blink = warn && Math.sin(t * 18) > 0;
  c.fillStyle = blink ? '#ffe066' : focus ? '#e5534b' : '#3f8a3a'; c.strokeStyle = INK; c.lineWidth = 2;
  c.beginPath(); rrect(-34, 50, 68, 22, 11)(c); c.fill(); c.stroke();
  c.fillStyle = blink ? INK : PAPER; c.fillText(label, 0, 66);
  c.restore();
}

// ---------------------------------------------------------------- the Crystal Choir
// Maestra Quartz: a tall pink crystal in a concert gown, with pince-nez and a baton.
export function drawQuartz(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'normal';
  const wave = o.conduct ? Math.sin(t * 7) * 0.5 : Math.sin(t * 1.6) * 0.12;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 22 * s);
  c.scale(s * flip, s);
  paper(c, p => {
    shape(c, p, cc => { cc.moveTo(-22, 0); cc.quadraticCurveTo(-18, -24, -10, -34); cc.lineTo(10, -34); cc.quadraticCurveTo(18, -24, 22, 0); cc.closePath(); }, vgrad(c, -34, 0, '#6a4a9a', '#3e2a66'));
    shape(c, p, cc => { cc.save(); cc.translate(15, -50); cc.rotate(-0.9 + wave); rrect(-1.6, -30, 3.2, 30, 1.5)(cc); cc.restore(); }, PAPER, 1.6);   // baton
    shape(c, p, ell(15, -50, 4.4, 4.8), '#f2b8d8', 2);
    shape(c, p, poly([[-15, -34], [-17, -66], [0, -86], [17, -66], [15, -34], [0, -28]]), vgrad(c, -86, -28, '#ffd6ec', '#d98ac0'));
    shape(c, p, poly([[-8, -86], [-12, -98], [-3, -88]]), '#ffc2e2', 1.6);    // crystal hair
    shape(c, p, poly([[6, -86], [10, -100], [12, -84]]), '#ffc2e2', 1.6);
  });
  // facets
  c.fillStyle = 'rgba(255,255,255,0.35)'; c.beginPath(); c.moveTo(-17, -66); c.lineTo(0, -86); c.lineTo(-4, -60); c.lineTo(-15, -36); c.closePath(); c.fill();
  c.fillStyle = 'rgba(120,40,100,0.15)'; c.beginPath(); c.moveTo(17, -66); c.lineTo(15, -34); c.lineTo(4, -46); c.closePath(); c.fill();
  // the baton's sparkle
  const bx = 15 + Math.sin(-0.9 + wave) * 30, by = -50 - Math.cos(-0.9 + wave) * 30;
  c.fillStyle = '#fff6c8'; c.beginPath(); starPath(c, bx, by, 5, 2, 4); c.fill();
  eyes(c, -5.5, 5.5, -60, 7, mood, t);
  c.strokeStyle = INK; c.lineWidth = 1.4; c.fillStyle = 'rgba(220,240,255,0.35)';
  for (const ex of [-5.5, 5.5]) { c.beginPath(); c.ellipse(ex, -60, 4.6, 4, 0, 0, TAU); c.fill(); c.stroke(); }
  c.beginPath(); c.moveTo(10, -60); c.quadraticCurveTo(16, -52, 13, -44); c.stroke();          // the pince-nez's chain
  blush(c, -9, -52); blush(c, 9, -52);
  mouth(c, 0, -50, 5, mood);
  c.restore();
}

// A geode kid: a round rock, cracked open in front to show the sparkling crystal inside (each a different color).
export function drawGeode(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'normal', col = o.color || '#7fb2e6';
  const hop = o.sing ? Math.abs(Math.sin(t * 6)) * 3 : 0;
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 16 * s);
  c.scale(s * flip, s);
  c.translate(0, -hop);
  paper(c, p => {
    shape(c, p, ell(-7, -2, 5, 3), '#6e685f');
    shape(c, p, ell(7, -2, 5, 3), '#6e685f');
    shape(c, p, cc => { const n = 14; for (let i = 0; i <= n; i++) { const a = (i / n) * TAU, r = 19 + (i % 2 ? -1.5 : 1.2); const px = Math.cos(a) * r, py = -19 + Math.sin(a) * r * 0.95; if (i) cc.lineTo(px, py); else cc.moveTo(px, py); } cc.closePath(); }, vgrad(c, -38, 0, '#a59f95', '#7a736a'));
    shape(c, p, ell(0, -19, 12.5, 12), tone(col, -0.25), 2);
  });
  // the crystals inside
  c.save(); c.beginPath(); c.ellipse(0, -19, 12, 11.5, 0, 0, TAU); c.clip();
  for (let i = 0; i < 9; i++) {
    const a = (i / 9) * TAU, r = 10;
    c.fillStyle = i % 2 ? tone(col, 0.35) : col;
    c.beginPath(); c.moveTo(Math.cos(a) * r, -19 + Math.sin(a) * r); c.lineTo(Math.cos(a + 0.4) * 3, -19 + Math.sin(a + 0.4) * 3); c.lineTo(Math.cos(a + 0.7) * r, -19 + Math.sin(a + 0.7) * r); c.fill();
  }
  c.restore();
  if (o.sing) glowDot(c, 0, -19, 26, rgbOf(col), 0.35);
  eyes(c, -4, 4, -21, 5.5, mood, t);
  mouth(c, 0, -14, o.sing ? 5 : 4, o.sing ? 'shock' : mood);
  if (mood === 'worried') { c.fillStyle = '#9fe6ff'; c.strokeStyle = INK; c.lineWidth = 1; c.beginPath(); c.moveTo(13, -33); c.quadraticCurveTo(17, -27, 13, -25); c.quadraticCurveTo(9, -27, 13, -33); c.fill(); c.stroke(); }
  if (o.sing) {
    c.fillStyle = INK; c.font = 'bold 14px "Segoe UI Emoji", sans-serif'; c.textAlign = 'center';
    c.globalAlpha = 0.5 + 0.5 * Math.sin(t * 5); c.fillText('♪', 14, -40 - Math.sin(t * 3) * 3); c.globalAlpha = 1;
  }
  c.restore();
}

// A singing crystal: a cluster of three shards. Whack it (X) and it rings out its note. glow (0..1) when it sings.
export const NOTE_COLORS = ['#ff8a8a', '#ffc35a', '#ffe066', '#7cdc8a', '#7fb2ff', '#c39bff'];
export function drawCrystal(c, x, y, o = {}) {
  const col = o.color || NOTE_COLORS[(o.note || 0) % NOTE_COLORS.length], g = o.glow || 0, t = o.t || 0;
  c.save(); c.translate(x, y);
  if (g > 0) glowDot(c, 0, -34, 60 + 30 * g, rgbOf(col), 0.3 + 0.45 * g);
  const sway = Math.sin(t * 1.3 + (o.note || 0)) * 0.6 + g * Math.sin(t * 40) * 1.5;
  paper(c, p => {
    shape(c, p, poly([[-26, 0], [-30, -30], [-20, -44], [-12, -28], [-10, 0]]), vgrad(c, -44, 0, tone(col, 0.3 + 0.4 * g), tone(col, -0.2)), 2);
    shape(c, p, poly([[10, 0], [12, -26], [22, -40], [30, -28], [24, 0]]), vgrad(c, -40, 0, tone(col, 0.3 + 0.4 * g), tone(col, -0.2)), 2);
    shape(c, p, poly([[-12, 0], [-14 + sway, -50], [0 + sway, -70], [14 + sway, -50], [12, 0]]), vgrad(c, -70, 0, tone(col, 0.45 + 0.5 * g), col), 2.2);
  });
  c.fillStyle = `rgba(255,255,255,${0.35 + 0.4 * g})`;
  c.beginPath(); c.moveTo(-8 + sway, -48); c.lineTo(0 + sway, -64); c.lineTo(-3 + sway, -20); c.closePath(); c.fill();
  if (g > 0.05) {
    c.globalAlpha = g; c.fillStyle = INK; c.font = 'bold 18px "Segoe UI Emoji", sans-serif'; c.textAlign = 'center';
    c.fillText('♪', 20, -78 - (1 - g) * 14); c.globalAlpha = 1;
  }
  c.restore();
}

// ---------------------------------------------------------------- the Chunky Quarry
// Chip the stonecutter: a small block of a stone golem with safety goggles up on his forehead and a chisel for a hand.
export function drawChip(c, x, y, o = {}) {
  const t = o.t || 0, s = o.scale || 1, flip = o.flip ?? 1, mood = o.mood || 'normal';
  const shake = mood === 'worried' ? Math.sin(t * 30) * 0.6 : 0;
  c.save(); c.translate(x + shake, y);
  if (o.shadow !== false) shadow(c, 0, 0, 18 * s);
  c.scale(s * flip, s);
  c.translate(0, Math.sin(t * 2.2) * 0.6);
  const stone = '#b9b1a5';
  paper(c, p => {
    shape(c, p, rrect(-12, -9, 9, 9, 2), tone(stone, -0.3));
    shape(c, p, rrect(3, -9, 9, 9, 2), tone(stone, -0.3));
    shape(c, p, ell(-19, -27, 5, 6.5), tone(stone, -0.15), 2);
    shape(c, p, rrect(-15, -42, 30, 34, 7), vgrad(c, -42, -8, tone(stone, 0.12), tone(stone, -0.18)));
    shape(c, p, cc => { cc.save(); cc.translate(19, -27); cc.rotate(0.6 + (o.carve ? Math.sin(t * 14) * 0.5 : 0)); rrect(-3.5, -5, 7, 13, 2)(cc); cc.restore(); }, tone(stone, -0.15), 2);
    shape(c, p, cc => { cc.save(); cc.translate(19, -27); cc.rotate(0.6 + (o.carve ? Math.sin(t * 14) * 0.5 : 0)); cc.moveTo(-4, 8); cc.lineTo(4, 8); cc.lineTo(1.5, 20); cc.lineTo(-1.5, 20); cc.closePath(); cc.restore(); }, '#b8c4d8', 1.8);
    shape(c, p, rrect(-14, -64, 28, 24, 7), vgrad(c, -64, -40, tone(stone, 0.22), stone));
    shape(c, p, rrect(-15, -61, 30, 6, 3), '#4a3d6a', 1.6);                   // the goggles' strap
    shape(c, p, ell(-6, -58, 5, 4), '#9fe6ff', 1.6);
    shape(c, p, ell(6, -58, 5, 4), '#9fe6ff', 1.6);
  });
  c.strokeStyle = 'rgba(43,34,53,0.4)'; c.lineWidth = 1.2;
  c.beginPath(); c.moveTo(-8, -36); c.lineTo(-3, -28); c.lineTo(-6, -20); c.moveTo(7, -22); c.lineTo(10, -16); c.stroke();
  eyes(c, -5, 5, -49, 6.5, mood, t);
  mouth(c, 0, -44, 4.5, mood);
  if (mood === 'worried') { c.fillStyle = '#9fe6ff'; c.strokeStyle = INK; c.lineWidth = 1; c.beginPath(); c.moveTo(-17, -60); c.quadraticCurveTo(-13, -54, -17, -52); c.quadraticCurveTo(-21, -54, -17, -60); c.fill(); c.stroke(); }
  c.restore();
}

// Chip's statue in Lumen Town: Wick, hammer held high, and a round little friend at his feet, carved in stone on a
// pedestal with a plaque. (A statue doesn't turn to look at you: no flip.)
export function drawChipStatue(c, x, y, o = {}) {
  const s = o.scale || 1, dk = '#9a9286';
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 46 * s);
  c.scale(s, s);
  paper(c, p => {
    shape(c, p, rrect(-46, -40, 92, 40, 6), vgrad(c, -40, 0, '#d8d1c5', '#a8a094'));                       // pedestal
    shape(c, p, rrect(-52, -50, 104, 12, 4), '#e2dbcf');                                                   // its top slab
    shape(c, p, rrect(-14, -114, 28, 64, 9), vgrad(c, -114, -50, '#ddd6ca', dk));                          // stone Wick
    shape(c, p, cc => { cc.moveTo(0, -140); cc.quadraticCurveTo(13, -125, 6, -114); cc.lineTo(-6, -114); cc.quadraticCurveTo(-13, -125, 0, -140); cc.closePath(); }, '#e8e2d6');
    shape(c, p, cc => { cc.save(); cc.translate(16, -94); cc.rotate(-0.5); rrect(-2.5, -32, 5, 36, 2)(cc); cc.restore(); }, dk, 2);   // the hammer
    shape(c, p, cc => { cc.save(); cc.translate(16, -94); cc.rotate(-0.5); rrect(-11, -44, 22, 14, 3)(cc); cc.restore(); }, '#c9c2b6', 2);
    shape(c, p, ell(-31, -63, 13, 12), vgrad(c, -75, -51, '#ddd6ca', dk));                                 // a round friend
  });
  // carved faces
  c.strokeStyle = 'rgba(43,34,53,0.55)'; c.lineWidth = 1.6; c.lineCap = 'round';
  for (const ex of [-5, 5]) { c.beginPath(); c.moveTo(ex, -94); c.lineTo(ex, -88); c.stroke(); }
  c.beginPath(); c.arc(0, -82, 4, 0.15 * Math.PI, 0.85 * Math.PI); c.stroke();
  for (const ex of [-35, -27]) { c.beginPath(); c.moveTo(ex, -66); c.lineTo(ex, -62); c.stroke(); }
  // the plaque
  c.fillStyle = '#d9b45a'; c.strokeStyle = INK; c.lineWidth = 1.5;
  c.beginPath(); rrect(-34, -33, 68, 19, 3)(c); c.fill(); c.stroke();
  c.fillStyle = INK; c.font = 'bold 7.5px Fredoka, sans-serif'; c.textAlign = 'center';
  c.fillText('ONE CHUNK AT A TIME', 0, -20.5);
  c.restore();
}

// ---------------------------------------------------------------- the Drowsy Downs
// Woolly: a cloud of a sheep with a dark face, little crescent-moon horns and a crook made of moonlight. She floats.
// With o.lamb it's one of her dream lambs instead: small, with a star on its forehead.
export function drawWoolly(c, x, y, o = {}) {
  const t = o.t || 0, lamb = !!o.lamb, s = (o.scale || 1) * (lamb ? 0.55 : 1), flip = o.flip ?? 1;
  const mood = o.mood || (lamb ? 'happy' : 'sleepy');
  c.save(); c.translate(x, y);
  if (o.shadow !== false) shadow(c, 0, 0, 20 * s, 0.14);
  c.scale(s * flip, s);
  c.translate(0, -10 + Math.sin(t * 1.8 + (o.seed || 0)) * 3);
  if (o.dreamy || lamb) glowDot(c, 0, -30, 60, '190,200,255', 0.35);
  paper(c, p => {
    for (const lx of [-14, -5, 6, 14]) shape(c, p, rrect(lx - 2, -14, 4, 14, 2), '#3a3460', 1.6);   // legs
    if (!lamb) {
      shape(c, p, rrect(-34, -76, 3.5, 70, 1.7), '#fff3b0', 1.6);                                     // the crook
      shape(c, p, cc => { cc.arc(-26, -76, 8, Math.PI, TAU); cc.arc(-26, -76, 4.5, TAU, Math.PI, true); cc.closePath(); }, '#fff3b0', 1.6);
    }
    shape(c, p, cc => {
      const puffs = [[-18, -30, 12], [-6, -38, 14], [8, -37, 13], [19, -29, 11], [10, -22, 12], [-8, -21, 12]];
      for (const [px, py, r] of puffs) { cc.moveTo(px + r, py); cc.arc(px, py, r, 0, TAU); }
    }, vgrad(c, -52, -10, '#ffffff', '#d8d4f6'), 2);
    shape(c, p, ell(22, -40, 9, 11, 0.2), '#3a3460', 2);                     // her face
    shape(c, p, cc => { cc.arc(17, -50, 5, 0.6, TAU - 0.6); cc.arc(19, -50, 3, TAU - 0.8, 0.8, true); cc.closePath(); }, '#ffe9a8', 1.4);
    shape(c, p, cc => { cc.arc(28, -50, 5, Math.PI + 0.6, Math.PI - 0.6 + TAU); cc.closePath(); }, '#ffe9a8', 1.4);
  });
  c.save(); c.strokeStyle = PAPER; c.fillStyle = PAPER; c.lineWidth = 2; c.lineCap = 'round';
  if (mood === 'sleepy' || mood === 'sleep') {
    for (const ex of [19, 26]) { c.beginPath(); c.arc(ex, -42, 2.6, 0.15 * Math.PI, 0.85 * Math.PI); c.stroke(); }
  } else if (mood === 'happy') {
    for (const ex of [19, 26]) { c.beginPath(); c.arc(ex, -40, 2.6, 1.15 * Math.PI, 1.85 * Math.PI); c.stroke(); }
  } else {
    for (const ex of [19, 26]) { c.beginPath(); c.arc(ex, -42, 1.8, 0, TAU); c.fill(); }
  }
  c.beginPath(); c.arc(23, -36, 2.2, 0.2 * Math.PI, 0.8 * Math.PI); c.stroke();
  c.restore();
  if (lamb) { c.fillStyle = '#ffe066'; c.strokeStyle = INK; c.lineWidth = 1.2; c.beginPath(); starPath(c, 22, -52, 5, 2.2); c.fill(); c.stroke(); }
  if (mood === 'sleep') zzz(c, 30, -60, t);
  c.restore();
}

// A nap pillow lying on the ground: E to nap (and dream), E again to wake up.
export function drawPillow(c, x, y, o = {}) {
  const t = o.t || 0, dream = !!o.dream;
  c.save(); c.translate(x, y);
  if (dream) glowDot(c, 0, -12, 54, '190,200,255', 0.45);
  paper(c, p => {
    shape(c, p, cc => {
      cc.moveTo(-34, -4); cc.quadraticCurveTo(-40, -14, -32, -24); cc.quadraticCurveTo(0, -30, 32, -24);
      cc.quadraticCurveTo(40, -14, 34, -4); cc.quadraticCurveTo(0, 2, -34, -4); cc.closePath();
    }, vgrad(c, -28, 0, dream ? '#e8e4ff' : '#fffaf0', dream ? '#b8b0ee' : '#e8dcc8'));
  });
  c.strokeStyle = dream ? 'rgba(120,110,200,0.6)' : 'rgba(180,156,255,0.7)'; c.lineWidth = 3;
  for (const sx of [-14, 14]) { c.beginPath(); c.moveTo(sx, -26); c.quadraticCurveTo(sx + 2, -14, sx, -2); c.stroke(); }
  if (!dream) zzz(c, 10, -34, t, 0.85);
  c.restore();
}

Object.assign(DRAW, {
  bookend: drawBookend, nonna: drawNonna, quartz: drawQuartz, geode: drawGeode, chip: drawChip, woolly: drawWoolly, chipstatue: drawChipStatue,
});
