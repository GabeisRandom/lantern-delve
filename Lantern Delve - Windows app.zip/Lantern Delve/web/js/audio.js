// Tiny synthesized sound effects (no audio files needed).
let ac = null;
let enabled = true;

export function setSound(on) { enabled = on; }

function ctx() {
  if (!ac) ac = new (window.AudioContext || window.webkitAudioContext)();
  if (ac.state === 'suspended') ac.resume();
  return ac;
}

function tone(freq, start, dur, type = 'square', vol = 0.08, slideTo = null) {
  const a = ctx();
  const o = a.createOscillator(), g = a.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, a.currentTime + start);
  if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, a.currentTime + start + dur);
  g.gain.setValueAtTime(0.0001, a.currentTime + start);
  g.gain.exponentialRampToValueAtTime(vol, a.currentTime + start + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, a.currentTime + start + dur);
  o.connect(g).connect(a.destination);
  o.start(a.currentTime + start);
  o.stop(a.currentTime + start + dur + 0.02);
}

function noise(start, dur, vol = 0.12) {
  const a = ctx();
  const buf = a.createBuffer(1, Math.floor(a.sampleRate * dur), a.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length);
  const s = a.createBufferSource(), g = a.createGain();
  s.buffer = buf; g.gain.value = vol;
  s.connect(g).connect(a.destination);
  s.start(a.currentTime + start);
}

const SFX = {
  jump: () => tone(380, 0, 0.12, 'square', 0.05, 760),
  coin: () => { tone(988, 0, 0.07, 'square', 0.05); tone(1319, 0.07, 0.18, 'square', 0.05); },
  hit: () => { noise(0, 0.12, 0.15); tone(160, 0, 0.12, 'triangle', 0.1, 70); },
  nice: () => { tone(784, 0, 0.08, 'triangle', 0.08); tone(1175, 0.06, 0.14, 'triangle', 0.08); },
  hurt: () => tone(300, 0, 0.25, 'sawtooth', 0.06, 90),
  block: () => { tone(523, 0, 0.06, 'square', 0.06); tone(784, 0.05, 0.1, 'square', 0.06); },
  guard: () => { tone(660, 0, 0.06, 'triangle', 0.08); tone(990, 0.05, 0.12, 'triangle', 0.08); },
  crunch: () => { noise(0, 0.25, 0.2); tone(110, 0, 0.25, 'triangle', 0.08, 50); },
  talk: () => tone(520 + Math.random() * 80, 0, 0.03, 'square', 0.02),
  select: () => tone(880, 0, 0.05, 'square', 0.03),
  menu: () => tone(660, 0, 0.05, 'triangle', 0.05),
  chime: () => { tone(880, 0, 0.18, 'sine', 0.1); tone(1320, 0.12, 0.3, 'sine', 0.09); },
  start: () => { tone(523, 0, 0.12, 'sine', 0.08); tone(659, 0.1, 0.12, 'sine', 0.08); tone(784, 0.2, 0.25, 'sine', 0.08); },
  alert: () => { tone(740, 0, 0.12, 'square', 0.07); tone(554, 0.14, 0.12, 'square', 0.07); tone(740, 0.28, 0.12, 'square', 0.07); },
  tick: () => tone(1200, 0, 0.04, 'square', 0.03),
  fanfare: () => [523, 659, 784, 1047, 784, 1047].forEach((f, i) => tone(f, i * 0.11, i === 5 ? 0.5 : 0.12, 'square', 0.06)),
  levelup: () => [392, 523, 659, 784, 1047].forEach((f, i) => tone(f, i * 0.09, 0.2, 'triangle', 0.08)),
  flare: () => tone(300, 0, 0.4, 'sine', 0.08, 1200),
  door: () => { tone(220, 0, 0.1, 'triangle', 0.08); tone(330, 0.08, 0.15, 'triangle', 0.08); },
  save: () => [659, 880, 1175].forEach((f, i) => tone(f, i * 0.08, 0.2, 'sine', 0.07)),
  lose: () => [392, 330, 262, 196].forEach((f, i) => tone(f, i * 0.18, 0.25, 'triangle', 0.08)),
  piano: () => { const s = [523, 587, 659, 784, 880, 1047]; for (let i = 0; i < 4; i++) tone(s[Math.floor(Math.random() * s.length)], i * 0.16, 0.3, 'triangle', 0.07); },
  meow: () => { tone(620, 0, 0.12, 'sine', 0.07, 900); tone(900, 0.12, 0.25, 'sine', 0.06, 520); },
  swish: () => noise(0, 0.14, 0.08),
  poof: () => { noise(0, 0.2, 0.1); tone(500, 0, 0.18, 'sine', 0.05, 1200); },
  cheer: () => { noise(0, 0.35, 0.05); [660, 880, 990].forEach((f, i) => tone(f, i * 0.05, 0.18, 'triangle', 0.04)); },
  gasp: () => tone(500, 0, 0.22, 'sine', 0.04, 320),
  thwack: () => { noise(0, 0.08, 0.14); tone(220, 0, 0.1, 'square', 0.05, 120); },
  // an enemy spots you: "!"
  spot: () => { tone(700, 0, 0.1, 'triangle', 0.08, 1400); tone(1400, 0.09, 0.08, 'square', 0.035); },
  // battle timing: a PERFECT press rings out; a mistimed one goes "bwop"
  perfect: () => { [1047, 1319, 1568].forEach((f, i) => tone(f, i * 0.045, 0.12, 'triangle', 0.07)); tone(2093, 0.13, 0.32, 'sine', 0.06); },
  whiff: () => tone(420, 0, 0.15, 'triangle', 0.045, 230),
  // the Paper Plains: stickers, crates, bombs, patching tears, unfolding folks
  peel: () => { noise(0, 0.16, 0.06); tone(700, 0, 0.14, 'sine', 0.05, 1500); },
  push: () => { noise(0, 0.12, 0.05); tone(90, 0, 0.12, 'triangle', 0.05, 70); },
  thud: () => { noise(0, 0.1, 0.12); tone(120, 0, 0.16, 'triangle', 0.1, 55); },
  tock: () => tone(420, 0, 0.05, 'triangle', 0.05, 300),
  boom: () => { noise(0, 0.6, 0.3); tone(140, 0, 0.5, 'triangle', 0.12, 40); tone(70, 0.05, 0.6, 'sine', 0.12, 35); },
  fall: () => tone(700, 0, 0.55, 'sine', 0.06, 120),
  splash: () => { noise(0, 0.28, 0.08); tone(950, 0, 0.16, 'sine', 0.04, 320); },
  patch: () => { noise(0, 0.2, 0.05); [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.08 + i * 0.06, 0.14, 'triangle', 0.06)); },
  unfold: () => { noise(0, 0.18, 0.06); [392, 523, 659, 880].forEach((f, i) => tone(f, i * 0.07, 0.16, 'sine', 0.07)); },
};

export function sfx(name) {
  if (!enabled || !SFX[name]) return;
  try { SFX[name](); } catch (e) { /* audio not available */ }
}
