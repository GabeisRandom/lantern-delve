// The always-on-top study buddy window shown during a focus session.
import { api, fmt, esc, openFile, fileIcon } from './api.js';
import { DRAW, drawWick, glowDot, paper, shape, rrect, ell, vgrad, INK, starPath, drawGloomling } from './art.js';
import './art4.js';   // (Tick the alarm clock, so he can study with you too)
import('./art5.js').catch(() => {});   // (and Doodle the crayon)
import { sfx, setSound } from './audio.js';
import { music } from './music.js';
import { PARTNERS, BOND_LEVELS, bondLevel } from './game/data.js';

// study music plays from this window during focus, even while it's tucked away or minimized
music.stayOn = true;
const STUDY = ['lofi', 'piano', 'rain', 'funk', 'off'];
const STUDY_NAME = { lofi: 'Lo-fi beats', piano: 'Calm piano', rain: 'Rain sounds', funk: 'Game funk 🎸', off: 'Off' };
// the intense style used to be "battle" and then "phonk"
const studyStyle = st => (['battle', 'phonk'].includes(st.study_music) ? 'funk' : st.study_music || 'lofi');

const cv = document.getElementById('scene');
const ctx = cv.getContext('2d');
const panel = document.getElementById('panel');

let S = null;
let lastSpeechId = null;
let speech = { text: '', mood: 'happy' };
let moodUntil = 0;
let layoutKey = '';
let showReason = false;
let lastGrace = null;
let partner = null;
let lastLight = 0;
let sparkles = [];
let sent = false;

function loadPartner() {
  api('/api/adventure').then(r => {
    const d = r.data;
    partner = d && d.partner ? d.partner : null;
  }).catch(() => {});
}
loadPartner();
setInterval(loadPartner, 20000);

async function poll() {
  try {
    S = await api('/api/state');
    setSound(S.settings.sound !== false);
    onState();
  } catch (e) { /* server restarting */ }
  setTimeout(poll, 500);
}

function onState() {
  const al = S.session && S.session.alert;
  if (!(al && al.big)) showReason = false;   // (a new alert starts with the excuse box closed)
  const sp = S.speech;
  if (sp && sp.id !== lastSpeechId) {
    if (lastSpeechId !== null && sp.sound) sfx(sp.sound);
    lastSpeechId = sp.id;
    speech = { text: sp.text, mood: sp.mood };
    moodUntil = performance.now() + 6000;
  }
  const s = S.session;
  if (s && s.light_earned > lastLight) {
    for (let i = 0; i < 6; i++) sparkles.push({ x: Math.random(), y: 0, life: 1, vx: (Math.random() - 0.5) * 0.3 });
  }
  lastLight = s ? s.light_earned : 0;
  syncMusic();
  render();
}

// Study music while you focus; it goes muffled ("underwater") while something needs your attention,
// and stops for breaks (the Adventure has its own music).
function syncMusic() {
  const st = S.settings || {}, s = S.session;
  music.applySettings(st, 'study');
  music.energy = s ? s.combo - 1 : 0;   // game funk builds up as your combo grows (x1 → x2)
  const style = studyStyle(st);
  music.want(s && s.mode === 'focus' && style !== 'off' ? 'study_' + style : null);
  music.duck(!!(s && s.alert));
}

// Whatever size the window is, everything has to fit. The panel (text, buttons and all) is zoomed and
// the little scene gets the rest, in this order of priority: text at normal size, then a decent-sized
// scene (Wick studying with you), then bigger text. When space is really tight, the text shrinks
// before the scene steps aside completely.
const SCENE_MIN = 70;
let needFit = true;
function fit() {
  if (window.innerHeight < 60 || window.innerWidth < 60) return;   // minimized: wait for a real size
  needFit = false;
  const room = window.innerHeight - 6;
  const heightAt = z => { panel.style.zoom = z; return panel.getBoundingClientRect().height; };
  const largest = reserve => {
    let lo = 0.4, hi = 1.3, best = lo;
    for (let i = 0; i < 8; i++) {
      const mid = (lo + hi) / 2;
      if (heightAt(mid) <= room - reserve) { best = mid; lo = mid; } else hi = mid;
    }
    return best;
  };
  const roomy = largest(Math.max(SCENE_MIN, Math.min(220, room * 0.36)));
  let z = roomy >= 1 ? Math.min(roomy, 1.15) : Math.min(1, largest(SCENE_MIN)), scene = true;
  if (z < 0.75) {
    const z2 = largest(0);
    if (z2 > z + 0.05) { z = Math.min(1, z2); scene = false; }
  }
  const h = heightAt(z);
  cv.classList.toggle('gone', !scene || room - h < 40);
}
window.addEventListener('resize', () => { needFit = true; render(); });
if (document.fonts) document.fonts.ready.then(() => { needFit = true; if (S) render(); });

function key() {
  const s = S.session;
  if (!s) return 'none';
  const a = s.alert;
  if (a && a.big) return `alert:${a.kind}:${a.checking ? 1 : 0}:${showReason ? 1 : 0}:${a.tries_left}:${a.verdict_text || ''}`;
  return `${s.mode}:${a ? a.kind : ''}`;
}

function render() {
  if (!S) return;
  const k = key();
  if (k !== layoutKey) {
    layoutKey = k;
    build();
    needFit = true;
  }
  update();
  if (needFit) fit();
}

function stepHtml(s) {
  if (!s.quest) return '<b>Free session</b> · work on anything. Hit ✓ when you finish a thing.';
  if (s.quest.step_text == null) return `<b>${esc(s.quest.title)}</b> · all steps done! 🎉 Keep focusing, or end the session.`;
  return `<b>Step ${s.quest.step_index + 1}/${s.quest.steps_total}</b> · ${esc(s.quest.step_text)}`;
}

function build() {
  const s = S.session;
  document.body.classList.toggle('big', !!(s && s.alert && s.alert.big));
  if (!s) {
    panel.innerHTML = '<div class="ended">Session ended. Nice work! 🌟</div>';
    return;
  }
  const a = s.alert;
  if (a && a.big) {
    const what = s.quest ? s.quest.title : 'schoolwork';
    // the excuse box: your reason gets judged (by Claude when it's connected), and you only get a couple of tries
    const excuse = (prompt, openLabel) => `
      ${a.verdict_text ? `<div class="ai">❌ Not accepted: ${esc(a.verdict_text)}</div>` : ''}
      ${a.checking ? '<div class="ai">Judging your reason… 🤔</div>' : a.tries_left <= 0 ? `
        <div class="note"><b>No more excuses for this one.</b> Close it and get back to ${esc(what)}!</div>` : showReason ? `
        <textarea id="reason" placeholder="${esc(prompt)}"></textarea>
        <div class="actions"><button class="btn gold" data-a="reason-send">Send reason</button>
        <button class="btn ghost" data-a="reason-cancel">Never mind</button></div>
        <div class="note">I'll judge it. A real schoolwork reason clears this; an excuse gets you nothing. (${a.tries_left} ${a.tries_left === 1 ? 'try' : 'tries'} left)</div>` : openLabel}`;
    if (a.kind === 'blocked') {
      panel.innerHTML = `<div class="alert">
        <h1 class="red">🚫 That's ${esc(a.label)}!</h1>
        <div class="sub" id="sub"></div>
        <div class="count" id="count"></div>
        <div class="lostbig" id="lost"></div>
        ${excuse(`Why do you need ${a.label} right now, for ${what}? Be specific.`,
          `<div class="actions"><button class="btn ghost" data-a="reason-open">${a.verdict_text ? 'Try one more reason…' : 'I have a good reason…'}</button></div>`)}
      </div>`;
      const ta = panel.querySelector('#reason');
      if (ta) ta.focus();
    } else if (a.kind === 'offtask') {
      panel.innerHTML = `<div class="alert">
        <h1>🤔 Is this for your assignment?</h1>
        <div class="sub">“${esc(a.title)}” doesn't look like <b>${esc(what)}</b>.</div>
        ${a.reason ? `<div class="ai">${esc(a.reason)}</div>` : ''}
        <div class="count" id="count"></div>
        <div class="lostbig" id="lost"></div>
        ${excuse(`How is this for ${what}? Be specific.`,
          `<div class="actions"><button class="btn green" data-a="reason-open">${a.verdict_text ? 'Explain once more…' : "It's for this! (explain)"}</button>
          <button class="btn" data-a="ot-back">Oops, going back</button></div>`)}
        ${showReason || a.checking || a.tries_left <= 0 ? '<div class="actions"><button class="btn" data-a="ot-back">Oops, going back</button></div>' : ''}
      </div>`;
      const ta = panel.querySelector('#reason');
      if (ta) ta.focus();
    } else if (a.kind === 'idle') {
      panel.innerHTML = `<div class="alert">
        <h1>${a.paper ? "✍️ Haven't heard from you in a while" : `👀 It's been quiet for ${a.minutes || 3} min`}</h1>
        <div class="sub">Just thinking? That's okay! Or did something pull you away? Be honest, I won't be mad (much).</div>
        <div class="choices">
          <button class="btn" data-a="idle" data-v="thinking">🤔 Just thinking it through</button>
          <button class="btn" data-a="idle" data-v="reading">📖 Reading / watching for this</button>
          <button class="btn" data-a="idle" data-v="phone">📱 Phone / got distracted</button>
          <button class="btn" data-a="idle" data-v="break">☕ Taking a break</button>
          <button class="btn" data-a="idle" data-v="away">🚶 I stepped away</button>
        </div>
        <div class="lostbig" id="lost"></div>
      </div>`;
    } else if (a.kind === 'breakover') {
      panel.innerHTML = `<div class="alert">
        <h1>⏰ Break's over!</h1>
        <div class="sub">${s.quest && s.quest.step_text ? `Next up: <b>${esc(s.quest.step_text)}</b>` : "Let's get back to it."}</div>
        <div class="actions"><button class="btn green big" data-a="resume">▶ Back to work</button>
        <button class="btn" data-a="extend">+5 min break (costs 5 ✦)</button></div>
        <div class="lostbig" id="lost"></div>
      </div>`;
    }
    return;
  }
  if (s.mode === 'break') {
    panel.innerHTML = `
      <div class="stats"><span>☕ Break</span><span class="light">left <b id="bk"></b></span><span>focused <b id="t"></b></span></div>
      <div class="speech" id="speech"></div>
      <div class="row"><button class="btn green grow" data-a="resume">▶ Back to work</button>
      <button class="btn purple" data-a="play">🎮 Play</button></div>
      <div class="row"><button class="btn small ghost" data-a="end">⏹ End session</button></div>`;
    return;
  }
  // the one-file copy can't see other windows, so its check-ins just ask if you're still at it
  const [ask, yes] = !a ? [] : a.web ? ['👋 Still working?', '👍 Yep, still at it']
    : a.paper ? ['✍️ Still writing?', '✍️ Yep, writing'] : ['🤔 Just thinking?', '🤔 Yep, thinking'];
  const checkin = a && a.kind === 'checkin' ? `<div class="checkin">
      <div class="q">${ask}</div>
      <div class="row"><button class="btn small green" data-a="idle" data-v="still">${yes}</button>
        <button class="btn small" data-a="idle" data-v="distracted">😅 I got distracted</button></div>
    </div>` : '';
  panel.innerHTML = `
    <div class="stats"><span>⏱ <b id="t"></b></span><span class="light">✦ +<b id="le"></b></span>
      <span>x<b id="cb"></b></span><span title="Break time banked">☕ <b id="bank"></b></span></div>
    <div class="bondline" id="bondline"></div>
    <div id="ban" class="banner hidden"></div>
    ${checkin}
    <div class="step paper" id="step"></div>
    <div class="files" id="cfiles"></div>
    <div class="speech" id="speech"></div>
    <div class="row"><button class="btn green grow" data-a="step">✓ Step done</button>
      <button class="btn" data-a="break">☕ Break</button>
      <button class="btn small ghost" data-a="music" title="Study music (click to change)">🎵</button>
      <button class="btn small ghost" data-a="end" title="End the session">⏹</button></div>`;
}

function setText(id, v) { const el = panel.querySelector('#' + id); if (el && el.textContent !== String(v)) el.textContent = v; }

function update() {
  const s = S.session;
  if (!s) return;
  setText('t', fmt(s.focus_s));
  setText('le', s.light_earned);
  setText('cb', s.combo.toFixed(1));
  setText('bank', fmt(s.break_bank));
  setText('bk', fmt(s.break_bank));
  const bl = panel.querySelector('#bondline');
  if (bl) {
    const text = partner && PARTNERS[partner] ? (() => {
      const sec = (S.bond || {})[partner] || 0, lv = bondLevel(sec), next = BOND_LEVELS[lv];
      return `📚 ${PARTNERS[partner].name} is studying with you · 💛 Bond ${lv}` + (next ? ` · ${Math.max(1, Math.ceil((next - sec) / 60))} min to Bond ${lv + 1}` : ' · max!');
    })() : '';
    if (bl.textContent !== text) { bl.textContent = text; bl.style.display = text ? '' : 'none'; needFit = true; }
  }
  const stepEl = panel.querySelector('#step');
  if (stepEl) { const h = stepHtml(s); if (stepEl.innerHTML !== h) { stepEl.innerHTML = h; needFit = true; } }
  const fl = panel.querySelector('#cfiles');
  if (fl) {   // the assignment's files, one click away
    const q = s.quest && (S.quests || []).find(x => x.id === s.quest.id);
    const files = (q && q.files) || [];
    const h = files.slice(0, 3).map(f => `<span class="file" data-a="open-file" data-id="${esc(f.id)}" title="Open ${esc(f.name)}">${fileIcon(f.name)} ${esc(f.name)}</span>`).join('')
      + (files.length > 3 ? `<span class="more">+${files.length - 3} more in the Homework tab</span>` : '');
    if (fl.innerHTML !== h) { fl.innerHTML = h; fl.style.display = h ? '' : 'none'; needFit = true; }
  }
  const stepBtn = panel.querySelector('[data-a="step"]');
  if (stepBtn) stepBtn.disabled = !!(s.quest && s.quest.step_text == null);   // a finished assignment has no steps left
  const sp = panel.querySelector('#speech');
  if (sp) {
    const h = `<b>Wick:</b> ${esc(speech.text)}`;
    if (sp.innerHTML !== h) { sp.innerHTML = h; needFit = true; }
    sp.className = `speech mood-${speech.mood}`;
  }
  const a = s.alert;
  const ban = panel.querySelector('#ban');
  if (ban) {
    const show = !!(a && !a.big && a.kind !== 'checkin');
    if (show !== !ban.classList.contains('hidden')) needFit = true;
    if (show) {
      ban.classList.remove('hidden');
      const text = a.kind === 'blocked'
        ? `⚠ ${a.label} pass: ${fmt(a.pass_left)} left · still losing Light (−${a.lost || 0} so far)`
        : a.kind === 'offtask' ? `⚠ Head back to your assignment (−${a.lost || 0} ✦ so far)` : '⚠ Something needs attention';
      if (ban.textContent !== text) ban.textContent = text;
    } else ban.classList.add('hidden');
  }
  if (a) {
    const lost = panel.querySelector('#lost');
    if (lost) lost.textContent = a.lost ? `−${a.lost} ✦ lost to the Gloom` : '';
    const count = panel.querySelector('#count');
    const sub = panel.querySelector('#sub');
    if (count) {
      count.style.display = a.grace_left > 0 ? '' : 'none';
      count.textContent = a.grace_left;
    }
    if (sub && a.kind === 'blocked') {
      sub.innerHTML = a.minimized ? 'I minimized it. Stay off it, please.'
        : a.grace_left > 0 ? `Close it now. In <b>${a.grace_left}s</b> the Gloom starts eating your Light.`
        : 'The Gloom is eating your Light every 10 seconds. Close it!';
    }
    if (a.kind === 'blocked' && a.grace_left > 0 && a.grace_left !== lastGrace) sfx('tick');
    lastGrace = a.grace_left;
  }
}

panel.addEventListener('click', async e => {
  const b = e.target.closest('[data-a]');
  if (!b || sent) return;
  const act = b.dataset.a;
  if (act === 'open-file') {
    const r = await openFile(b.dataset.id).catch(() => ({}));
    if (!r.ok) { speech = { text: r.error || "Hmm, I couldn't open that file.", mood: 'worried' }; moodUntil = performance.now() + 6000; render(); }
    return;
  }
  const go = async (path, body = {}) => { sent = true; try { await api(path, body); } finally { sent = false; } };
  if (act === 'step') { sfx('chime'); await go('/api/session/step'); }
  else if (act === 'break') await go('/api/session/break');
  else if (act === 'resume') await go('/api/session/resume');
  else if (act === 'extend') await go('/api/session/extend');
  else if (act === 'end') { if (confirm('End this focus session?')) await go('/api/session/end'); }
  else if (act === 'play') await go('/api/show', { tab: 'adventure' });
  else if (act === 'music') {
    const cur = studyStyle(S.settings || {});
    const next = STUDY[(STUDY.indexOf(cur) + 1) % STUDY.length];
    await go('/api/settings', { study_music: next });
    speech = next === 'funk'
      ? { text: "🎸 Game funk! Let's lock in. It builds up the longer you stay focused.", mood: 'determined' }
      : { text: `🎵 Study music: ${STUDY_NAME[next]}${next === 'off' ? '' : ' (click 🎵 again to change it)'}`, mood: 'happy' };
    moodUntil = performance.now() + 6000;
  }
  else if (act === 'idle') await go('/api/session/idle', { answer: b.dataset.v });
  else if (act === 'ot-back') { showReason = false; await go('/api/session/offtask', { answer: 'going_back' }); }
  else if (act === 'reason-open') { showReason = true; layoutKey = ''; render(); }
  else if (act === 'reason-cancel') { showReason = false; layoutKey = ''; render(); }
  else if (act === 'reason-send') {
    const text = (panel.querySelector('#reason') || {}).value || '';
    const r = await api('/api/session/reason', { text });
    if (!r.ok) { alert(r.error || 'That reason was too short.'); return; }
    showReason = false; layoutKey = '';
  }
  S = await api('/api/state');
  onState();
});

// ---------------------------------------------------------------- the little study scene
// requestAnimationFrame pauses when the window can't paint; a slow timer keeps the scene alive.
let gen = 0;
function schedule() {
  const my = ++gen;
  const go = () => { if (my === gen) frame(performance.now()); };
  requestAnimationFrame(go);
  setTimeout(go, 250);
}

function frame(now) {
  const t = now / 1000;
  const dpr = window.devicePixelRatio || 1;
  const w = cv.clientWidth, h = cv.clientHeight;
  if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) {
    cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr);
  }
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  drawScene(t, w, h);
  schedule();
}

function drawScene(t, w, h) {
  if (h < 30 || w < 30) return;   // the scene stepped aside to make room
  const s = S && S.session;
  const a = s && s.alert;
  const k = Math.max(0.4, Math.min(1.35, h / 150, w / 380));   // everything scales with the room it gets
  const wall = ctx.createLinearGradient(0, 0, 0, h);
  wall.addColorStop(0, '#3a2f63'); wall.addColorStop(1, '#2a2148');
  ctx.fillStyle = wall; ctx.fillRect(0, 0, w, h);
  // window with night sky
  const wx = 18, wy = 16, ww = 70 * k, wh = 58 * k;
  ctx.fillStyle = '#141432'; ctx.fillRect(wx, wy, ww, wh);
  for (let i = 0; i < 12; i++) {
    ctx.fillStyle = `rgba(255,250,220,${0.5 + 0.4 * Math.sin(t * 2 + i)})`;
    ctx.fillRect(wx + ((i * 37) % ww), wy + ((i * 23) % wh), 2, 2);
  }
  ctx.strokeStyle = '#fffaf0'; ctx.lineWidth = 4; ctx.strokeRect(wx, wy, ww, wh);
  ctx.beginPath(); ctx.moveTo(wx + ww / 2, wy); ctx.lineTo(wx + ww / 2, wy + wh); ctx.moveTo(wx, wy + wh / 2); ctx.lineTo(wx + ww, wy + wh / 2); ctx.stroke();
  // shelf with books
  const sx = w - 110 * k, sy = 30 * k;
  ctx.fillStyle = '#6e4529'; ctx.fillRect(sx, sy + 34 * k, 96 * k, 6);
  const cols = ['#e5534b', '#4f72bf', '#f2c14e', '#4fae5a', '#7b5fc7', '#ff9a3d'];
  for (let i = 0; i < 6; i++) { ctx.fillStyle = cols[i]; ctx.fillRect(sx + 6 + i * 14 * k, sy + (i % 2 ? 6 : 0) * k, 11 * k, (34 - (i % 2 ? 6 : 0)) * k); }
  // warm lamp glow
  glowDot(ctx, w * 0.5, h * 0.55, 160 * k, '255,200,120', s && s.mode === 'focus' && !a ? 0.22 : 0.1);

  const deskY = h - 30 * k;
  const cx = w * 0.5;
  // companion mood
  let mood = 'normal';
  let state = 'idle';
  if (performance.now() < moodUntil) mood = speech.mood === 'relieved' ? 'happy' : speech.mood;
  if (s) {
    if (s.mode === 'break') mood = 'sleep';
    if (a && a.kind === 'blocked') mood = 'angry';
    else if (a && (a.kind === 'offtask' || a.kind === 'idle' || a.kind === 'checkin')) mood = 'worried';
  }
  const writing = s && s.mode === 'focus' && !a;
  const flameSize = s ? 0.7 + (s.combo - 1) * 1.1 : 0.8;
  // lock-in music: headband on, game face on
  const battle = writing && S.settings && studyStyle(S.settings) === 'funk';
  if (battle && mood === 'normal') mood = 'determined';
  // partner studying too
  if (partner && DRAW[partner]) {
    DRAW[partner](ctx, cx - 95 * k, deskY + 6, { t, scale: 0.9 * k, flip: 1, mood: mood === 'angry' ? 'worried' : mood, glasses: true, shadow: false });
  }
  drawWick(ctx, cx, deskY + 14 * k, { t, scale: 1.25 * k, mood: mood === 'sleep' ? 'sleep' : mood, writing, flame: flameSize, shadow: false, hammer: false, headband: battle });
  // desk
  paper(ctx, p => shape(ctx, p, rrect(14, deskY, w - 28, 40 * k, 8), vgrad(ctx, deskY, deskY + 40, '#b9814e', '#7a4a26')));
  // papers + mug
  ctx.save(); ctx.translate(cx - 28 * k, deskY - 4); ctx.rotate(-0.05);
  ctx.fillStyle = '#fffaf0'; ctx.fillRect(0, 0, 50 * k, 8); ctx.strokeStyle = INK; ctx.lineWidth = 1.5; ctx.strokeRect(0, 0, 50 * k, 8);
  ctx.restore();
  const mx = cx + 70 * k;
  paper(ctx, p => shape(ctx, p, rrect(mx, deskY - 18 * k, 16 * k, 18 * k, 4), '#e5534b'));
  if (s && s.mode === 'break') {
    for (let i = 0; i < 3; i++) {
      ctx.strokeStyle = `rgba(255,255,255,${0.35 - i * 0.08})`; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(mx + 8 * k, deskY - 22 * k - i * 8); ctx.quadraticCurveTo(mx + 14 * k + Math.sin(t * 2 + i) * 5, deskY - 30 * k - i * 8, mx + 8 * k, deskY - 38 * k - i * 8); ctx.stroke();
    }
    ctx.fillStyle = '#fffaf0'; ctx.font = `bold ${14 * k}px Fredoka, sans-serif`;
    ctx.fillText('z', cx + 26 * k, deskY - 92 * k + Math.sin(t * 2) * 3);
    ctx.fillText('Z', cx + 36 * k, deskY - 106 * k + Math.sin(t * 2 + 1) * 3);
  }
  // light jar
  const jy = deskY - 36 * k;
  const fill = s ? ((s.light_earned % 20) / 20) : 0;
  const jw = 26 * k, jh = 34 * k, jarX = w - 60 * k;
  ctx.save();
  ctx.fillStyle = 'rgba(200,230,255,0.25)'; ctx.strokeStyle = '#fffaf0'; ctx.lineWidth = 3;
  ctx.beginPath(); rrect(jarX, jy, jw, jh, 6)(ctx); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#ffd25e'; ctx.fillRect(jarX + 3, jy + jh - 3 - (jh - 6) * fill, jw - 6, (jh - 6) * fill);
  glowDot(ctx, jarX + jw / 2, jy + jh * 0.7, 30 * k, '255,210,94', 0.2 + fill * 0.4);
  ctx.fillStyle = '#8a5a3c'; ctx.fillRect(jarX - 2, jy - 6, jw + 4, 7);
  ctx.restore();
  sparkles = sparkles.filter(p => p.life > 0);
  for (const p of sparkles) {
    p.life -= 0.012; p.y += 0.012;
    ctx.fillStyle = `rgba(255,220,110,${p.life})`;
    ctx.beginPath(); starPath(ctx, jarX + jw / 2 + p.x * 30 - 15 + p.vx * 40 * p.y, jy - p.y * 90, 5, 2, 4); ctx.fill();
  }
  // the Gloom creeping in during distractions
  if (a && (a.kind === 'blocked' || a.kind === 'offtask')) {
    const strength = Math.min(1, 0.45 + (a.lost || 0) / 20);
    const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.2, w / 2, h / 2, Math.max(w, h) * 0.75);
    g.addColorStop(0, 'rgba(30,10,50,0)'); g.addColorStop(1, `rgba(30,10,50,${0.9 * strength})`);
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    drawGloomling(ctx, 40 + Math.sin(t * 2) * 6, h - 4, { t, scale: 0.9 * k, flip: 1, shadow: false });
    drawGloomling(ctx, w - 40 + Math.sin(t * 2 + 1) * 6, h - 4, { t: t + 1, scale: 0.9 * k, flip: -1, shadow: false });
  }
  if (a && (a.kind === 'idle' || a.kind === 'checkin')) {
    ctx.fillStyle = '#fffaf0'; ctx.font = `bold ${28 * k}px Fredoka, sans-serif`; ctx.textAlign = 'center';
    ctx.fillText('?', cx + 34 * k, Math.max(30 * k, deskY - 100 * k) + Math.sin(t * 3) * 4);
    ctx.textAlign = 'left';
  }
}

schedule();
poll();
