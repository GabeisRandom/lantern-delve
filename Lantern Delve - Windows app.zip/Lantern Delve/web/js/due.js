// Due dates for homework. An assignment's due date is due_at: "YYYY-MM-DDTHH:MM" in local time, or null for no due
// date. Assignments from before real due dates have only the old free text in `due` ("Mon 7pm"), and no due_at at
// all: those get a best guess at the real date, which you confirm with one click (the old text never said which
// week, so it's never trusted on its own).
const pad = n => String(n).padStart(2, '0');
const DAY = 86400000;

export function toAt(d) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`; }

export function parseAt(s) {
  const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/.exec(String(s || ''));
  if (!m) return null;
  const d = new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5]);
  return isNaN(d) ? null : d;
}

const startOfDay = d => new Date(d.getFullYear(), d.getMonth(), d.getDate());
export const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const dayDiff = (a, b) => Math.round((startOfDay(a) - startOfDay(b)) / DAY);

export function timeText(d, short = false) {
  const t = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  return short ? t.replace(':00', '') : t;
}
const weekday = d => d.toLocaleDateString([], { weekday: 'short' });
const monthDay = d => d.toLocaleDateString([], { month: 'short', day: 'numeric' });

// ---------------------------------------------------------------- reading the old free-text due dates
const DAYS = { sun: 0, sunday: 0, mon: 1, monday: 1, tue: 2, tues: 2, tuesday: 2, wed: 3, weds: 3, wednesday: 3, thu: 4, thur: 4, thurs: 4,
  thursday: 4, fri: 5, friday: 5, sat: 6, saturday: 6 };
const MONTHS = { jan: 0, january: 0, feb: 1, february: 1, mar: 2, march: 2, apr: 3, april: 3, may: 4, jun: 5, june: 5, jul: 6, july: 6,
  aug: 7, august: 7, sep: 8, sept: 8, september: 8, oct: 9, october: 9, nov: 10, november: 10, dec: 11, december: 11 };

// "Mon 7pm", "Thur 10:30am", "Today 1pm", "6pm", "11/7", "Nov 7 noon"... -> "YYYY-MM-DDTHH:MM", or null.
// (A weekday means the next one, today included; a bare time means today; no time means 11:59 PM.)
export function guessDue(text, now = new Date()) {
  const s = String(text || '').toLowerCase().trim();
  if (!s) return null;
  let hh = 23, mm = 59, hasTime = false;
  const tm = /(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?|a|p)(?![a-z])/.exec(s) || /\b(\d{1,2}):(\d{2})\b/.exec(s);
  if (tm) {
    let h = +tm[1];
    const m = tm[2] ? +tm[2] : 0, ap = tm[3];
    if (ap) { if (ap[0] === 'p' && h < 12) h += 12; if (ap[0] === 'a' && h === 12) h = 0; }
    if (h <= 23 && m <= 59) { hh = h; mm = m; hasTime = true; }
  }
  if (/\bnoon\b/.test(s)) { hh = 12; mm = 0; hasTime = true; }
  if (/\bmidnight\b/.test(s)) { hh = 23; mm = 59; hasTime = true; }
  const today = startOfDay(now), words = s.split(/[^a-z]+/).filter(Boolean);
  let day = null;
  if (words.some(w => w === 'today' || w === 'tonight')) day = today;
  else if (words.some(w => w === 'tomorrow' || w === 'tmrw' || w === 'tmr' || w === 'tomorow')) day = addDays(today, 1);
  if (!day) {
    const md = /\b(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?\b/.exec(s);
    if (md) {
      const y = md[3] ? (md[3].length === 2 ? 2000 + +md[3] : +md[3]) : now.getFullYear();
      const d = new Date(y, +md[1] - 1, +md[2]);
      if (!isNaN(d) && d.getMonth() === +md[1] - 1) day = !md[3] && d < addDays(today, -60) ? new Date(y + 1, +md[1] - 1, +md[2]) : d;
    }
  }
  if (!day) {
    const mn = /\b([a-z]+)\.?\s+(\d{1,2})(?:st|nd|rd|th)?\b/.exec(s), nm = /\b(\d{1,2})(?:st|nd|rd|th)?\s+([a-z]+)\b/.exec(s);
    const hit = mn && MONTHS[mn[1]] != null ? [MONTHS[mn[1]], +mn[2]] : nm && MONTHS[nm[2]] != null ? [MONTHS[nm[2]], +nm[1]] : null;
    if (hit && hit[1] >= 1 && hit[1] <= 31) {
      let d = new Date(now.getFullYear(), hit[0], hit[1]);
      if (d < addDays(today, -60)) d = new Date(now.getFullYear() + 1, hit[0], hit[1]);
      day = d;
    }
  }
  if (!day) {
    const w = words.find(x => DAYS[x] != null);
    if (w != null) day = addDays(today, (DAYS[w] - today.getDay() + 7) % 7);
  }
  if (!day && hasTime) day = today;
  if (!day) return null;
  const d = new Date(day);
  d.setHours(hh, mm, 0, 0);
  return toAt(d);
}

// ---------------------------------------------------------------- how a due date reads, and where it sorts
// group: 'overdue' | 'old' | 'today' | 'tomorrow' | 'week' | 'later' | 'none'
export const DUE_GROUPS = [
  ['overdue', '⚠️ Overdue'], ['old', '📅 Pick the real due date'], ['today', '🔥 Due today'], ['tomorrow', '⏰ Due tomorrow'],
  ['week', '📆 Within a week'], ['later', '🗓️ Coming up later'], ['none', '🌙 No due date'],
];
const ORDER = Object.fromEntries(DUE_GROUPS.map(([g], i) => [g, i]));

function soon(at, now) {
  const min = Math.round((at - now) / 60000);
  if (min < 60) return `in ${Math.max(1, min)} min`;
  const h = Math.round(min / 60);
  if (h < 24) return `in ${h} hr${h > 1 ? 's' : ''}`;
  const d = dayDiff(at, now);
  return `in ${d} day${d > 1 ? 's' : ''}`;
}

export function dueInfo(q, now = new Date()) {
  const at = parseAt(q.due_at);
  if (!at) {
    const old = !('due_at' in q) && String(q.due || '').trim();
    if (old) {
      const guess = guessDue(q.due, now), g = parseAt(guess);
      return { group: 'old', old, guess, guessText: g ? whenText(g, now) : null, ts: g ? g.getTime() : Infinity,
        short: `“${old}”`, label: `Old due date: “${old}”`, icon: '📅', cls: 'old' };
    }
    return { group: 'none', ts: Infinity, short: 'No due date', label: 'No due date', icon: '🌙', cls: 'none' };
  }
  const days = dayDiff(at, now), t = timeText(at), ts = at.getTime();
  if (at < now) {
    const ago = days === 0 ? `today at ${t}` : days === -1 ? `yesterday at ${t}` : days > -7 ? `${weekday(at)} at ${t}` : `${monthDay(at)} at ${t}`;
    const hrs = (now - at) / 3600000, h = Math.round(hrs), dd = Math.floor(hrs / 24);
    const late = hrs < 1 ? `${Math.max(1, Math.round(hrs * 60))} min late` : hrs < 24 ? `${h} hr${h > 1 ? 's' : ''} late` : `${dd} day${dd > 1 ? 's' : ''} late`;
    return { group: 'overdue', at, ts, short: `Overdue · ${late}`, label: `Overdue · was due ${ago}`, icon: '⚠️', cls: 'over' };
  }
  if (days === 0) return { group: 'today', at, ts, short: `Today ${timeText(at, true)}`, label: `Due today at ${t} · ${soon(at, now)}`, icon: '🔥', cls: 'today' };
  if (days === 1) return { group: 'tomorrow', at, ts, short: `Tomorrow ${timeText(at, true)}`, label: `Due tomorrow at ${t}`, icon: '⏰', cls: 'tomorrow' };
  if (days <= 6) return { group: 'week', at, ts, short: `${weekday(at)} ${timeText(at, true)}`, label: `Due ${weekday(at)} at ${t} · ${soon(at, now)}`, icon: '📆', cls: 'week' };
  return { group: 'later', at, ts, short: monthDay(at), label: `Due ${weekday(at)}, ${monthDay(at)} at ${t} · ${soon(at, now)}`, icon: '🗓️', cls: 'later' };
}

// "Mon, Nov 9 at 7:00 PM" (for confirming a guess, and the editor's preview)
export function whenText(d, now = new Date()) {
  const days = dayDiff(d, now);
  const day = days === 0 ? 'today' : days === 1 ? 'tomorrow' : days === -1 ? 'yesterday' : `${weekday(d)}, ${monthDay(d)}`;
  return `${day} at ${timeText(d)}`;
}

// Soonest first (overdue at the top), then the old ones to check, then no due date (oldest first).
export function byDue(now = new Date()) {
  return (a, b) => {
    const A = dueInfo(a, now), B = dueInfo(b, now);
    return (ORDER[A.group] - ORDER[B.group]) || (A.ts - B.ts) || (a.id - b.id);
  };
}
