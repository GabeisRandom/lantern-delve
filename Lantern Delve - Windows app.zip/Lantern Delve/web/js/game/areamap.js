// The detailed map of the place you're in (TAB opens it; TAB again shows all of Lumenfold). A big field is drawn as
// a plan seen from above, an old narrow room (a cave, a house inside) from the side, with everything on it: the
// ground, water and lava, hills, roads, houses, trees, doors and ways out, lampposts, chests, folks (with a red ! when
// they have something new to say), enemies, things still to find, Wick, and the gold star of what to do next.
// Zoom with the mouse wheel, + and -, or SPACE and X; drag it or use the arrow keys to look around; E goes back to
// Wick; [ and ] (or the arrows at the top) flip through the other places in this area you've been to.
// The user asked for "a more detailed map where you can actually see stuff that you can zoom into".
import { ROOMS, AREAS } from './data.js';
import { DRAW, INK, PAPER, paper, shape, rrect, glowDot, starPath } from '../art.js';
import { GZ0, GZ1, BZ0, matFor, STYLES, shade, FURN, FURN_FOOT } from '../art2.js';
import { sfx } from '../audio.js';
import { maskOf, seenAt, paintFog, fogRect, exploredPct } from './explore.js';

const W = 960, H = 540, TAU = Math.PI * 2;
const PX = 16, PY = 60, PW = 716, PH = 436;     // the map itself
const SX = 744, SY = 60, SW = 200, SH = 436;    // the panel beside it
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const hash = n => { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };
const Z_DEFAULT = { sign: 70, lamp: 40, board: 110, shrine: 120, shop: 60 };
export const HAZARD = { water: '#6fb8e6', lava: '#ff7a3a', ink: '#3a3160', gloom: '#5a3d80', spikes: '#bdb3d6', brambles: '#3d5a35',
  gears: '#8a6a3a', blank: '#fbf8f0', pit: '#2a2238' };
export const TERRAIN = { stone: '#c9c3cf', rock: '#bdb7ab', sand: '#f6e2a8', snow: '#f4f6ff', stump: '#e2b98a' };
const FLOWERS = ['#ff9ab0', '#ffe066', '#b49cff', '#9fe6ff', '#fffaf0', '#ffb347'];
// how scenery shows from above: [shape, size (world units), fill, outline] (the minimap uses these too)
export const DECOR = {
  tree: ['canopy', 30, '#62b650', '#3f8a3a'], bigtree: ['canopy', 50, '#62b650', '#3f8a3a'], pine: ['canopy', 22, '#3f8a5a', '#2c6644'],
  deadtree: ['canopy', 20, '#7d7392', '#4a4060'], sketchtree: ['canopy', 28, '#f6f2e8', '#8a8794'],
  bush: ['blob', 16, '#6cbf5a', '#3f8a3a'], rosebush: ['blob', 14, '#e86a8a', '#3f8a3a'], hedge: ['blob', 18, '#4f8a47', '#2f5a2c'],
  rock: ['blob', 14, '#b3adb8', '#6e6878'], crystal: ['blob', 10, '#9fe6ff', '#4a8ab0'], stalag: ['blob', 10, '#8a7aa8', '#4a3d6a'],
  thorn: ['blob', 10, '#6a5a4a', '#3a2e24'], hay: ['blob', 14, '#f2c14e', '#a87a2a'], planter: ['blob', 10, '#b8875a', '#7a4f30'],
  pillar: ['blob', 10, '#d9d4e3', '#8a849a'], statue: ['blob', 14, '#c9c3cf', '#77708a'], fountain: ['blob', 44, '#8fd0f0', '#4a8ab0'],
  mclock: ['blob', 12, '#f2c14e', '#a87a2a'], pencil: ['blob', 8, '#ffd23f', '#a87a2a'], urn: ['blob', 7, '#bdb6ca', '#77708a'],
  crate: ['square', 12, '#c49a6a', '#7a5a38'], stall: ['square', 30, '#f2c14e', '#a87a2a'], eraserblock: ['square', 22, '#ff9ab0', '#c06a80'],
  fence: ['bar', 30, '#b8875a'], ruler: ['bar', 12, '#e0b870'], torii: ['bar', 50, '#c0392b'],
  flower: ['dot', 4, null], tuft: ['dot', 3, '#7ac85e'], fern: ['dot', 5, '#4f9a4a'], mushroom: ['dot', 5, '#e5534b'], shell: ['dot', 3, '#fbe3d0'],
  pebbles: ['dot', 3, '#a59fae'], reeds: ['dot', 6, '#7a9a4e'], pinwheel: ['dot', 6, '#ff9ab0'], flag: ['dot', 5, '#e5534b'],
  banner: ['dot', 5, '#e5534b'], lamp: ['dot', 6, '#ffd23f'], pot: ['dot', 6, '#c8763a'], paperball: ['dot', 6, '#fbf8f0'],
};
const TINY = { flower: 1, tuft: 1, fern: 1, shell: 1, pebbles: 1, mushroom: 1 };

// The places in an area you know about (the one you're in first, then the rest in walking order).
function placesIn(A, area, here) {
  const ids = Object.keys(ROOMS).filter(id => ROOMS[id].area === area && (id === here || (A.s.visited || {})[id]));
  ids.sort((a, b) => (a === here ? -1 : b === here ? 1 : (ROOMS[a].interior ? 1 : 0) - (ROOMS[b].interior ? 1 : 0)));
  return ids;
}

export class AreaMap {
  constructor(A) { this.A = A; this.views = {}; this.drag = null; this.lastT = null; }

  open() {
    const A = this.A;
    this.here = A.roomId;
    this.list = A.room.area ? placesIn(A, A.room.area, this.here) : [this.here];
    this.i = 0;
    this.views = {};   // (every time it opens, it starts on Wick)
    this.msg = '';
  }

  get id() { return this.list[this.i] || this.here; }
  get R() { return ROOMS[this.id]; }
  isField(R = this.R) { return (R.z1 ?? GZ1) > GZ1 + 1; }
  zb(R = this.R) { return R.z1 ?? GZ1; }

  // How the map looks at a place: centre (cx, cy: depth for a field, height for a side view) and zoom (px per unit).
  view() {
    const id = this.id;
    if (this.views[id]) return this.views[id];
    const R = this.R, A = this.A, field = this.isField(R), here = id === this.here;
    let fit, cx, cy, zoom, minZ;
    if (field) {
      fit = Math.min(PW / (R.w + 160), PH / (this.zb(R) - GZ0 + 160));
      minZ = fit * 0.92;
      zoom = clamp(PW / 1350, minZ, 1.6);
      cx = here ? A.p.x : R.w / 2; cy = here ? A.p.z : (GZ0 + this.zb(R)) / 2;
    } else {
      // (from the side: most of what matters is between the high ledges and the floor, so it starts there)
      fit = Math.min(PW / (R.w + 120), PH / 640);
      minZ = fit * 0.92;
      zoom = clamp(PH / 470, minZ, 2);
      cx = here ? A.p.x : R.w / 2; cy = 305;
    }
    return (this.views[id] = this.keepIn({ cx, cy, zoom, minZ, maxZ: field ? 1.6 : 2.2, home: { cx, cy, zoom } }));
  }

  // (the place stays on the map: you can't scroll it right off)
  keepIn(v) {
    const R = this.R;
    v.zoom = clamp(v.zoom, v.minZ, v.maxZ);
    const hw = PW / 2 / v.zoom, hh = PH / 2 / v.zoom;
    const fit = (c, lo, hi, half) => (hi - lo < half * 2 ? (lo + hi) / 2 : clamp(c, lo + half - 60 / v.zoom, hi - half + 60 / v.zoom));
    v.cx = fit(v.cx, 0, R.w, hw);
    v.cy = this.isField(R) ? fit(v.cy, GZ0, this.zb(R), hh) : fit(v.cy, -80, 560, hh);
    return v;
  }

  zoomBy(f, ax = PX + PW / 2, ay = PY + PH / 2) {
    const v = this.view(), field = this.isField();
    // (the spot under the mouse stays put)
    const wx = v.cx + (ax - (PX + PW / 2)) / v.zoom, wy = field ? v.cy - (ay - (PY + PH / 2)) / v.zoom : v.cy + (ay - (PY + PH / 2)) / v.zoom;
    const z = clamp(v.zoom * f, v.minZ, v.maxZ);
    if (z === v.zoom) return;
    v.zoom = z;
    v.cx = wx - (ax - (PX + PW / 2)) / z;
    v.cy = field ? wy + (ay - (PY + PH / 2)) / z : wy - (ay - (PY + PH / 2)) / z;
    this.keepIn(v);
  }

  pan(dx, dy) {   // in screen pixels
    const v = this.view();
    v.cx -= dx / v.zoom;
    v.cy += (this.isField() ? dy : -dy) / v.zoom;
    this.keepIn(v);
  }

  flip(d) {
    if (this.list.length < 2) { this.msg = this.list.length ? "That's the only place you've found around here so far." : ''; return; }
    this.i = (this.i + d + this.list.length) % this.list.length;
    this.msg = '';
    sfx('select');
  }

  key(act) {
    if (act === 'jump' || act === 'zoomin') { this.zoomBy(1.3); sfx('select'); }
    else if (act === 'hammer' || act === 'zoomout') { this.zoomBy(1 / 1.3); sfx('select'); }
    else if (act === 'act') {   // back to Wick
      if (this.id !== this.here) this.i = 0;
      const v = this.view();
      Object.assign(v, v.home);
      if (this.id === this.here) { v.cx = this.A.p.x; v.cy = this.isField() ? this.A.p.z : 305; }
      this.keepIn(v);
      sfx('select');
    } else if (act === 'prevroom') this.flip(-1);
    else if (act === 'nextroom') this.flip(1);
    else if (act === 'left' || act === 'right' || act === 'up' || act === 'down') {
      const d = { left: [30, 0], right: [-30, 0], up: [0, 30], down: [0, -30] }[act];   // (holding it glides on: see draw)
      this.pan(d[0], d[1]);
    }
  }

  wheel(x, y, dy) {
    if (x < PX || x > PX + PW || y < PY || y > PY + PH) return;
    this.zoomBy(Math.exp(-clamp(dy, -300, 300) * 0.0016), x, y);
  }

  pointer(kind, x, y) {
    if (kind === 'down') {
      if (x >= PX && x <= PX + PW && y >= PY && y <= PY + PH) this.drag = { x, y, moved: 0 };
      return;
    }
    if (!this.drag) return;
    if (kind === 'move') {
      const dx = x - this.drag.x, dy = y - this.drag.y;
      this.drag.moved += Math.abs(dx) + Math.abs(dy);
      this.drag.x = x; this.drag.y = y;
      this.pan(dx, dy);
    } else { this.dragEnd = this.drag.moved; this.drag = null; }
  }

  click(x, y) {
    if (this.dragEnd > 6) { this.dragEnd = 0; return; }   // (that was the end of a drag)
    for (const b of this.buttons || []) if (x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) { b.fn(); return; }
  }

  // ---------------------------------------------------------------- drawing
  draw(c, t) {
    const A = this.A, R = this.R, here = this.id === this.here;
    const dt = this.lastT == null ? 0 : Math.min(0.05, t - this.lastT);
    this.lastT = t;
    // (arrow keys held down glide the map along)
    const k = A.keys, sp = 520 * dt;
    if (k.has('left')) this.pan(sp, 0);
    if (k.has('right')) this.pan(-sp, 0);
    if (k.has('up')) this.pan(0, sp);
    if (k.has('down')) this.pan(0, -sp);
    const v = this.view();
    this.buttons = [];
    // the map
    paper(c, p => shape(c, p, rrect(PX - 4, PY - 4, PW + 8, PH + 8, 14), '#2a2240'));
    c.save();
    c.beginPath(); rrect(PX, PY, PW, PH, 11)(c); c.clip();
    if (this.isField(R)) this.drawPlan(c, t, R, v, here); else this.drawSide(c, t, R, v, here);
    c.restore();
    c.strokeStyle = INK; c.lineWidth = 3; c.beginPath(); rrect(PX, PY, PW, PH, 11)(c); c.stroke();
    this.drawZoomBar(c, v);
    this.drawSidePanel(c, t, R, here);
    this.drawRoomSwitcher(c);
  }

  // ---- a big field, from above (x across, depth up the map: the far back of the field is at the top)
  drawPlan(c, t, R, v, here) {
    const A = this.A, id = this.id, zoom = v.zoom;
    const X = x => PX + PW / 2 + (x - v.cx) * zoom, Y = z => PY + PH / 2 - (z - v.cy) * zoom;
    const rect = (x0, x1, z0, z1) => c.fillRect(X(x0), Y(z1), (x1 - x0) * zoom, (z1 - z0) * zoom);
    const vis = (x, z, pad = 40) => { const sx = X(x), sy = Y(z); return sx > PX - pad && sx < PX + PW + pad && sy > PY - pad && sy < PY + PH + pad; };
    const theme = typeof R.theme === 'function' ? R.theme(A) : R.theme, M = matFor(theme, R), zb = this.zb(R);
    // beyond the edges of the place
    c.fillStyle = shade(M.side || '#3a2f55', -0.35); c.fillRect(PX, PY, PW, PH);
    // the gaps (water, lava, thorns...) under everything, then the ground over them
    const hz = R.hazard || ((R.holes || []).length ? 'pit' : null);
    if (hz) { c.fillStyle = HAZARD[hz] || HAZARD.pit; rect(0, R.w, GZ0, zb); }
    if (here) {
      for (const r of A.rects) { c.fillStyle = r.water ? '#9ed8f2' : r.y < 449 ? shade(M.top, 0.12) : r.y > 451 ? shade(M.top, -0.12) : M.top; rect(r.x0, r.x1, r.z0, r.z1); }
    } else {
      c.fillStyle = M.top;
      for (const [x0, x1] of R.ground) rect(x0, x1, GZ0, zb);
      for (const h of R.holes || []) { c.fillStyle = R.wade && R.hazard === 'water' && h[4] !== 'deep' ? '#9ed8f2' : HAZARD[R.hazard] || HAZARD.pit; rect(h[0], h[1], h[2], h[3]); }
    }
    if (R.wade) { c.fillStyle = 'rgba(16,40,96,0.3)'; for (const h of R.holes || []) if (h[4] === 'deep') rect(h[0], h[1], h[2], h[3]); }
    // a faint grid, 200 apart, so you can judge distances
    if (zoom > 0.25) {
      c.strokeStyle = 'rgba(43,34,53,0.07)'; c.lineWidth = 1;
      for (let x = 0; x <= R.w; x += 200) { c.beginPath(); c.moveTo(X(x), Y(GZ0)); c.lineTo(X(x), Y(zb)); c.stroke(); }
      for (let z = 0; z <= zb; z += 200) { c.beginPath(); c.moveTo(X(0), Y(z)); c.lineTo(X(R.w), Y(z)); c.stroke(); }
    }
    // paved squares and roads
    for (const q of R.plazas || []) { c.fillStyle = q[4] || 'rgba(214,206,226,0.95)'; rect(q[0], q[1], q[2], q[3]); }
    c.lineCap = 'round';
    for (const [x0, z0, x1, z1, w = 90] of R.roads || []) {
      c.strokeStyle = R.roadColor || 'rgba(214,180,120,0.9)'; c.lineWidth = Math.max(2, w * zoom);
      c.beginPath(); c.moveTo(X(x0), Y(z0)); c.lineTo(X(x1), Y(z1)); c.stroke();
    }
    // woods (other places: just the patches; where you are, every tree is drawn below)
    if (!here) for (const g of R.groves || []) { c.fillStyle = 'rgba(40,90,50,0.35)'; rect(g[0], g[1], g[2], g[3]); }
    // hills and ledges (higher ones lighter), with a shadowed front so they look raised
    const boxes = here ? A.terrainBoxes : (R.terrain || []).flatMap(tr => tr.steps || [tr]);
    for (const b of [...boxes].sort((a, b2) => b2.y - a.y)) {
      if (!vis((b.x0 + b.x1) / 2, (b.z0 + b.z1) / 2, (b.x1 - b.x0 + b.z1 - b.z0) * zoom)) continue;
      const col = TERRAIN[b.mat] || shade(M.top, clamp((450 - b.y) / 500, -0.2, 0.35));
      const lift = Math.max(2, ((b.base ?? 450) - b.y) * zoom * 0.12);
      c.fillStyle = shade(col, -0.35); rect(b.x0, b.x1, b.z0 - lift / zoom, b.z0);
      c.fillStyle = col; rect(b.x0, b.x1, b.z0, b.z1);
      c.strokeStyle = 'rgba(43,34,53,0.45)'; c.lineWidth = 1.2; c.strokeRect(X(b.x0), Y(b.z1), (b.x1 - b.x0) * zoom, (b.z1 - b.z0) * zoom);
    }
    for (const hg of R.hedges || []) { c.fillStyle = '#4f8a47'; rect(hg.x, hg.x + hg.w, hg.z0, hg.z1); }
    // walls, ridges and bridges
    if (here) {
      for (const s of A.solids) if (s.wall3d && s.z0 != null) { c.fillStyle = s.under ? '#8a7f70' : '#6d6680'; rect(s.x, s.x + s.w, s.z0, s.z1); }
      for (const p of A.staticPlats) if (!p.full) { c.fillStyle = '#b8a07a'; rect(p.x, p.x + p.w, p.z0, p.z1); c.strokeStyle = 'rgba(43,34,53,0.5)'; c.strokeRect(X(p.x), Y(p.z1), p.w * zoom, (p.z1 - p.z0) * zoom); }
    } else for (const p of R.plats || []) if (p[3] != null) { c.fillStyle = '#b8a07a'; rect(p[0], p[0] + p[2], p[3], p[4]); }
    // benches, telescopes and other furniture standing out in the field (seen from above: their footprint)
    if (zoom > 0.45) for (const f of R.furniture || []) {
      const ft = FURN_FOOT[f.kind], fz = f.z ?? 60;
      if (!ft || !vis(f.x, fz)) continue;
      c.fillStyle = '#a8794e'; c.fillRect(X(f.x - ft[0]), Y(fz + ft[1]), ft[0] * 2 * zoom, ft[1] * 2 * zoom);
      c.strokeStyle = 'rgba(43,34,53,0.6)'; c.lineWidth = 1; c.strokeRect(X(f.x - ft[0]), Y(fz + ft[1]), ft[0] * 2 * zoom, ft[1] * 2 * zoom);
    }
    // trees, rocks and flowers
    const decor = [...(here ? A.decor || [] : []), ...(R.decor || []).map(d => ({ ...d, k: d.k || 1, z: d.z ?? 0 }))];
    for (const d of decor) {
      const spec = DECOR[d.kind] || (d.kind.startsWith('booth') ? ['square', 40, '#ff9ab0', '#a84a6a'] : ['dot', 6, '#9a93ad']);
      const [kind, size, fill, edge] = spec;
      if (kind === 'dot' && (zoom < 0.42 || (TINY[d.kind] && zoom < 0.75))) continue;
      const r = Math.max(kind === 'dot' ? 1.4 : 1.8, size * (d.k || 1) * zoom);
      if (!vis(d.x, d.z, r + 4)) continue;
      const x = X(d.x), y = Y(d.z);
      if (kind === 'canopy') {
        c.fillStyle = fill; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill();
        if (r > 3) { c.strokeStyle = edge; c.lineWidth = Math.min(2, r * 0.18); c.stroke(); c.fillStyle = 'rgba(255,255,255,0.18)'; c.beginPath(); c.arc(x - r * 0.3, y - r * 0.3, r * 0.4, 0, TAU); c.fill(); }
      } else if (kind === 'blob') {
        c.fillStyle = fill; c.beginPath(); c.ellipse(x, y, r, r * 0.8, 0, 0, TAU); c.fill();
        if (r > 3) { c.strokeStyle = edge; c.lineWidth = 1; c.stroke(); }
      } else if (kind === 'square') {
        c.fillStyle = fill; c.fillRect(x - r, y - r * 0.7, r * 2, r * 1.4);
        if (r > 3) { c.strokeStyle = edge; c.lineWidth = 1; c.strokeRect(x - r, y - r * 0.7, r * 2, r * 1.4); }
      } else if (kind === 'bar') {
        c.strokeStyle = fill; c.lineWidth = Math.max(1.5, 6 * zoom); c.beginPath(); c.moveTo(x - r, y); c.lineTo(x + r, y); c.stroke();
      } else {
        c.fillStyle = fill || FLOWERS[Math.floor(hash(d.x * 0.13 + d.z * 0.71) * FLOWERS.length)];
        c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill();
      }
    }
    // houses (their roofs, seen from above) and other big things
    for (const pr of R.props || []) {
      const px = X(pr.x);
      if (pr.kind === 'house' || pr.kind === 'building') {
        const hw = (pr.w || (pr.kind === 'house' ? 180 : 170)) / 2, z0 = pr.z ?? BZ0, z1 = pr.z != null ? z0 + (pr.depth || 130) : GZ1 + 40;
        if (!vis(pr.x, (z0 + z1) / 2, (hw * 2 + 140) * zoom)) continue;
        const roof = pr.roof || '#c45a5a', y0 = Y(z1), y1 = Y(z0), ym = (y0 + y1) / 2;
        c.fillStyle = shade(roof, -0.22); c.fillRect(px - hw * zoom, y0, hw * 2 * zoom, ym - y0);
        c.fillStyle = roof; c.fillRect(px - hw * zoom, ym, hw * 2 * zoom, y1 - ym);
        c.strokeStyle = INK; c.lineWidth = Math.max(1, Math.min(2.5, 3 * zoom)); c.strokeRect(px - hw * zoom, y0, hw * 2 * zoom, y1 - y0);
        c.beginPath(); c.moveTo(px - hw * zoom, ym); c.lineTo(px + hw * zoom, ym); c.stroke();
        const door = (R.doors || []).find(d => d.style === 'none' && Math.abs(d.x - pr.x) < 70);
        if (door) { c.fillStyle = '#5a3a24'; c.fillRect(X(door.x) - Math.max(3, 14 * zoom), y1 - Math.max(2, 5 * zoom), Math.max(6, 28 * zoom), Math.max(3, 6 * zoom)); }
        const name = pr.sign || (door && door.label);
        if (name && zoom > 0.3) this.label(c, name, px, ym + 4, clamp(15 * zoom + 4, 9, 14), '#fffaf0');
      } else if (pr.kind === 'windmill') {
        const y = Y(pr.z ?? 200), r = Math.max(5, 60 * zoom);
        c.fillStyle = '#f3e6c8'; c.beginPath(); c.arc(px, y, r * 0.45, 0, TAU); c.fill(); c.strokeStyle = INK; c.lineWidth = 1.5; c.stroke();
        c.strokeStyle = '#a87a4a'; c.lineWidth = Math.max(2, 10 * zoom);
        for (let i = 0; i < 4; i++) { const a = t * 0.6 + (i * Math.PI) / 2; c.beginPath(); c.moveTo(px, y); c.lineTo(px + Math.cos(a) * r, y + Math.sin(a) * r); c.stroke(); }
      } else if (pr.kind === 'lantern') {
        const y = Y(pr.z ?? 170);
        glowDot(c, px, y, Math.max(16, 120 * zoom), '255,214,120', 0.6);
        c.fillStyle = '#ffd23f'; c.strokeStyle = INK; c.lineWidth = 2; c.beginPath(); c.arc(px, y, Math.max(5, 34 * zoom), 0, TAU); c.fill(); c.stroke();
        if (zoom > 0.25) this.label(c, 'Great Lantern', px, y + Math.max(5, 34 * zoom) + 13, 12, '#fff3c4');
      } else if (pr.kind === 'bigtree') {
        const y = Y(pr.z ?? 180), r = Math.max(6, 70 * zoom);
        c.fillStyle = '#5aa84a'; c.beginPath(); c.arc(px, y, r, 0, TAU); c.fill(); c.strokeStyle = '#3f8a3a'; c.lineWidth = 2; c.stroke();
      } else if (pr.kind === 'hotspring') {
        c.fillStyle = '#9fdcf2'; c.beginPath(); c.ellipse(px, Y(pr.z ?? 60), Math.max(5, 90 * zoom), Math.max(3, 50 * zoom), 0, 0, TAU); c.fill();
        c.strokeStyle = '#6a8ab0'; c.lineWidth = 1.5; c.stroke();
      } else if (pr.kind === 'dock') {
        c.fillStyle = '#b8875a'; c.fillRect(px - 50 * zoom, Y(60), 100 * zoom, 120 * zoom);
      }
    }
    // the parts not explored yet: still blank paper (and nothing on them shows)
    const m = maskOf(A.s, id), seen = (x, z) => !m || seenAt(m, R, x, z);
    if (m) this.drawFog(c, m, R, X, Y);
    // things you can use or talk to
    const icon = Math.max(0.65, Math.min(1.15, 0.55 + zoom * 0.6));
    const doorZ = d => A.doorZ(d, R);
    const lit = l => A.s.opened[`lamp_${id}_${l.x}`];
    const lamps = (R.lamps || []).map(l => (typeof l === 'number' ? { x: l, z: Z_DEFAULT.lamp } : { x: l.x, z: l.z ?? Z_DEFAULT.lamp }));
    for (const s of R.signs || []) if (zoom > 0.35 && vis(s.x, s.z ?? Z_DEFAULT.sign) && seen(s.x, s.z ?? Z_DEFAULT.sign)) this.iconSign(c, X(s.x), Y(s.z ?? Z_DEFAULT.sign), icon);
    for (const b of R.blocks || []) {
      if ((b.hidden && !A.s.revealed[b.id]) || zoom < 0.4) continue;
      const bz = b.z ?? 0;
      if (vis(b.x + 22, bz) && seen(b.x + 22, bz)) this.iconBlock(c, X(b.x + 22), Y(bz), icon, !!A.s.opened[b.id]);
    }
    for (const it of R.collect || []) if (!A.s.collected[it.id] && vis(it.x, it.z ?? 0) && seen(it.x, it.z ?? 0)) this.iconSparkle(c, X(it.x), Y(it.z ?? 0), icon, t);
    for (const ch of R.chests || []) {
      if (ch.needBroken && !A.broken(ch.needBroken)) continue;
      if (vis(ch.x, ch.z ?? 0) && seen(ch.x, ch.z ?? 0)) this.iconChest(c, X(ch.x), Y(ch.z ?? 0), icon, !!A.s.opened[ch.id]);
    }
    for (const l of lamps) if (vis(l.x, l.z) && seen(l.x, l.z)) this.iconLamp(c, X(l.x), Y(l.z), icon, lit(l), t);
    for (const s of [...(R.shops || []), ...(R.boards || []), ...(R.shrines || [])]) {
      const z = s.z ?? Z_DEFAULT.shop;
      if (vis(s.x, z) && seen(s.x, z)) this.iconBubble(c, X(s.x), Y(z), icon, (R.shops || []).includes(s) ? '🛍️' : (R.boards || []).includes(s) ? '📋' : '⛩️');
    }
    // the ways out: doors and paths, and the roads off the sides
    const g = A.guide || {}, goal = g.goal, step = here && g.path && g.path[0];
    for (const d of R.doors || []) {
      const z = doorZ(d);
      // (the door the guide wants you to take shows even when you haven't been near it yet)
      if (!vis(d.x, z, 120) || (!seen(d.x, z) && !(step && step.via === 'door' && step.door === d))) continue;
      const locked = !!(d.need && !A.flag(d.need)), next = step && step.via === 'door' && step.door === d;
      if (next) this.ring(c, X(d.x), Y(z), 22 * icon, t);
      this.iconDoor(c, X(d.x), Y(z), icon, locked);
      // (a shop's or house's door: its name is already on the roof)
      const onHouse = d.style === 'none' && (R.props || []).some(pr => (pr.kind === 'house' || pr.kind === 'building') && Math.abs(pr.x - d.x) < 70 && (pr.sign || d.label));
      if (zoom > 0.16 && (!onHouse || next)) this.label(c, d.label || ROOMS[d.to].name, X(d.x), Y(z) + 22 * icon, 12, next ? '#ffe066' : '#fffaf0');
    }
    for (const side of ['left', 'right']) {
      const e = R.exits && R.exits[side];
      if (!e || !ROOMS[e.to]) continue;
      const z = e.z0 != null ? (e.z0 + Math.min(e.z1, e.z0 + 400)) / 2 : (GZ0 + zb) / 2, x = side === 'left' ? 0 : R.w;
      const next = step && step.via === side;
      if (!next && !seen(side === 'left' ? 0 : R.w - 1, z)) continue;
      this.exitMark(c, X(x), Y(z), side, ROOMS[e.to].name, next, icon, t);
    }
    // folks (and a red ! over anyone with something new to say)
    const spr = clamp(zoom * 0.75, 0.2, 0.62);
    for (const n of R.npcs || []) {
      if (n.show && !n.show(A)) continue;
      const nz = n.z ?? 0;
      if (!vis(n.x, nz, 60) || !seen(n.x, nz)) continue;
      const x = X(n.x), y = Y(nz) + 10 * spr;
      if (zoom >= 0.3 && DRAW[n.kind]) {
        c.save(); try { DRAW[n.kind](c, x, y, { ...(n.opts || {}), t, scale: spr * ((n.opts && n.opts.scale) || 1), flip: n.flip || 1, shadow: false }); } catch (e) { /* (some folks need more than this) */ } c.restore();
      } else { c.fillStyle = '#b49cff'; c.strokeStyle = INK; c.lineWidth = 1.5; c.beginPath(); c.arc(x, y - 4, 4.5, 0, TAU); c.fill(); c.stroke(); }
      if (n.talk && A.npcHasNews(n)) this.newsMark(c, x, y - Math.max(16, 80 * spr), t);
      if (zoom >= 0.7 && n.name) this.label(c, n.name, x, y + 14, 11, '#fffaf0');
    }
    if (here) {
      for (const e of A.enemies || []) {
        if (e.dead || !vis(e.x, e.z, 50) || !seen(e.x, e.z)) continue;
        const x = X(e.x), y = Y(e.z) + 8 * spr;
        c.strokeStyle = 'rgba(229,83,75,0.85)'; c.lineWidth = 2; c.beginPath(); c.ellipse(x, y, 14 * icon, 5 * icon, 0, 0, TAU); c.stroke();
        if (zoom >= 0.3 && DRAW[e.kind]) { c.save(); try { DRAW[e.kind](c, x, y, { t, scale: spr * 0.85, flip: -1, shadow: false }); } catch (err) { /* */ } c.restore(); }
        else { c.fillStyle = '#e5534b'; c.beginPath(); c.arc(x, y - 4, 4, 0, TAU); c.fill(); }
      }
    }
    // the goal, if it's here
    if (goal && goal.room === id && goal.x != null) {
      // (with no depth given: whatever you can use at that spot, the nearest to Wick, as the gold arrow does)
      let gz = goal.z;
      if (gz == null) {
        const near = here ? A.interactables().filter(i => Math.abs(i.x - goal.x) < 40).sort((a, b) => Math.abs(a.z - A.p.z) - Math.abs(b.z - A.p.z)) : [];
        gz = near.length ? near[0].z : 0;
      }
      this.goalStar(c, X(goal.x), Y(gz) - 18, t, goal.quest);
    }
    // Wick, and his partner
    if (here) {
      const P = A.p, pp = A.partnerPos, x = X(P.x), y = Y(P.z);
      if (A.s.partner && DRAW[A.s.partner] && pp) { c.save(); DRAW[A.s.partner](c, X(pp.x), Y(pp.z) + 8, { t, scale: Math.max(0.26, spr * 0.9), flip: P.facing, shadow: false, glasses: true }); c.restore(); }
      this.youAreHere(c, x, y, t, Math.max(0.3, spr * 1.05), P.facing);
    }
    // which way is which
    this.label(c, '↑ further back', PX + PW / 2, PY + 15, 11, 'rgba(255,250,240,0.9)');
    this.label(c, '↓ the way in (the front)', PX + PW / 2, PY + PH - 7, 11, 'rgba(255,250,240,0.9)');
  }

  // ---- an old narrow room, from the side (a cave, a castle hall, a house inside)
  drawSide(c, t, R, v, here) {
    const A = this.A, id = this.id, zoom = v.zoom;
    const X = x => PX + PW / 2 + (x - v.cx) * zoom, Y = y => PY + PH / 2 + (y - v.cy) * zoom;
    const theme = typeof R.theme === 'function' ? R.theme(A) : R.theme, M = matFor(theme, R);
    const st = R.style && STYLES[R.style];
    const g = c.createLinearGradient(0, PY, 0, PY + PH);
    // (darker than the ground, so the floor and the ledges stand out)
    const wall = st ? st.wall : [shade(M.side || '#45385f', -0.3), shade(M.side || '#45385f', -0.62)];
    g.addColorStop(0, wall[0]); g.addColorStop(1, wall[1] || wall[0]);
    c.fillStyle = g; c.fillRect(PX, PY, PW, PH);
    const surf = x => { let best = null; for (const [a, b, y] of R.ground) if (x >= a && x <= b) best = best == null ? y : Math.min(best, y); return best; };
    const vis = (x, pad = 60) => X(x) > PX - pad && X(x) < PX + PW + pad;
    // gaps, then the ground
    const hz = R.hazard || 'pit';
    c.fillStyle = HAZARD[hz] || HAZARD.pit; c.fillRect(X(0), Y(500), R.w * zoom, Y(620) - Y(500));
    for (const [x0, x1, y] of R.ground) {
      c.fillStyle = M.front ? M.front[0] : shade(M.top, -0.3); c.fillRect(X(x0), Y(y), (x1 - x0) * zoom, Y(620) - Y(y));
      c.fillStyle = M.top; c.fillRect(X(x0), Y(y), (x1 - x0) * zoom, Math.max(3, 12 * zoom));
      c.strokeStyle = INK; c.lineWidth = 2; c.beginPath(); c.moveTo(X(x0), Y(620)); c.lineTo(X(x0), Y(y)); c.lineTo(X(x1), Y(y)); c.lineTo(X(x1), Y(620)); c.stroke();
    }
    // platforms, walls and puzzle walls
    const plats = here ? A.staticPlats.map(p => [p.x, p.y, p.w]) : (R.plats || []).map(p => [p[0], p[1], p[2]]);
    for (const [x, y, w] of plats) { c.fillStyle = M.top; c.fillRect(X(x), Y(y), w * zoom, Math.max(4, 14 * zoom)); c.strokeStyle = INK; c.lineWidth = 1.5; c.strokeRect(X(x), Y(y), w * zoom, Math.max(4, 14 * zoom)); }
    (R.movers || []).forEach((m, i) => {
      const mp = here && A.moverPos[i] ? A.moverPos[i] : { x: m.x, y: m.y };
      c.setLineDash([6, 5]); c.strokeStyle = 'rgba(255,250,240,0.5)'; c.lineWidth = 1.5;
      c.strokeRect(X(m.x), Y(m.y), (m.w + (m.dx || 0)) * zoom, Math.max(4, 14 * zoom)); c.setLineDash([]);
      c.fillStyle = '#b8a07a'; c.fillRect(X(mp.x), Y(mp.y), m.w * zoom, Math.max(4, 14 * zoom));
    });
    for (const w of R.walls || []) if (w[4] == null) { c.fillStyle = shade(M.side || '#45385f', -0.15); c.fillRect(X(w[0]), Y(w[1]), w[2] * zoom, w[3] * zoom); }
    for (const [x, w] of R.low || []) { const y = (surf(x + w / 2) ?? 450) - 40; c.fillStyle = '#8a7f70'; c.fillRect(X(x), Y(-60), w * zoom, Y(y) - Y(-60)); this.label(c, 'roll under', X(x + w / 2), Y(y) - 6, 10, '#fff3c4'); }
    for (const k of R.cracks || []) if (!A.broken(k.id)) { c.fillStyle = '#9d97a8'; c.fillRect(X(k.x), Y(k.y), k.w * zoom, k.h * zoom); c.strokeStyle = INK; c.lineWidth = 1.5; c.beginPath(); c.moveTo(X(k.x + k.w * 0.3), Y(k.y)); c.lineTo(X(k.x + k.w * 0.6), Y(k.y + k.h * 0.4)); c.lineTo(X(k.x + k.w * 0.35), Y(k.y + k.h)); c.stroke(); }
    for (const b of R.boulders || []) if (!A.broken(b.id)) { const y = (surf(b.x) ?? 450) - 70; c.fillStyle = '#a49e94'; c.strokeStyle = INK; c.lineWidth = 2; c.beginPath(); c.arc(X(b.x), Y(y), 70 * zoom, 0, TAU); c.fill(); c.stroke(); }
    for (const gt of R.gates || []) if (!A.flag(gt.flag)) { c.strokeStyle = '#3a3448'; c.lineWidth = Math.max(2, 6 * zoom); for (let x = gt.x; x <= gt.x + gt.w; x += 14) { c.beginPath(); c.moveTo(X(x), Y(gt.top)); c.lineTo(X(x), Y(surf(gt.x) ?? 450)); c.stroke(); } }
    for (const vn of R.vines || []) if (!A.broken(vn.id)) { c.fillStyle = 'rgba(80,150,70,0.85)'; c.fillRect(X(vn.x), Y(vn.y), vn.w * zoom, vn.h * zoom); }
    // furniture, drawn as itself (beds, bookshelves, tables, the counter...)
    for (const f of R.furniture || []) {
      if (!FURN[f.kind] || f.kind === 'rug' || f.kind === 'spot' || f.kind === 'mat' || !vis(f.x, 120)) continue;
      const fy = f.y ?? surf(f.x) ?? 450;
      c.save(); c.translate(X(f.x), Y(fy)); c.scale(zoom * 0.92, zoom * 0.92);
      try { FURN[f.kind](c, { ...f, t }); } catch (e) { /* */ }
      c.restore();
    }
    // the parts not explored yet: still blank paper (and nothing on them shows)
    const m = maskOf(A.s, id), seen = x => !m || seenAt(m, R, x, 0);
    if (m) this.drawFog(c, m, R, X, Y);
    for (const s of R.springs || []) if (vis(s.x) && seen(s.x)) this.iconBubble(c, X(s.x), Y(surf(s.x) ?? 450) - 10, 0.9, '🌀');
    for (const s of R.vents || []) if (vis(s.x) && seen(s.x)) this.iconBubble(c, X(s.x), Y(surf(s.x) ?? 450) - 10, 0.9, '💨');
    // things to use or talk to
    const icon = clamp(0.6 + zoom * 0.4, 0.75, 1.2);
    const lamps = (R.lamps || []).map(l => (typeof l === 'number' ? l : l.x));
    const show = x => vis(x) && seen(x);
    for (const s of R.signs || []) if (show(s.x)) this.iconSign(c, X(s.x), Y(s.y ?? surf(s.x) ?? 450), icon);
    for (const b of R.blocks || []) if (!(b.hidden && !A.s.revealed[b.id]) && show(b.x)) this.iconBlock(c, X(b.x + 22), Y(b.y + 22), icon, !!A.s.opened[b.id]);
    for (const it of R.collect || []) if (!A.s.collected[it.id] && show(it.x)) this.iconSparkle(c, X(it.x), Y(it.y ?? (surf(it.x) ?? 450) - 30), icon, t);
    for (const ch of R.chests || []) if (!(ch.needBroken && !A.broken(ch.needBroken)) && show(ch.x)) this.iconChest(c, X(ch.x), Y(ch.y ?? surf(ch.x) ?? 450) - 6, icon, !!A.s.opened[ch.id]);
    for (const lx of lamps) if (show(lx)) this.iconLamp(c, X(lx), Y(surf(lx) ?? 450) - 14, icon, A.s.opened[`lamp_${id}_${lx}`], t);
    for (const s of [...(R.shops || []), ...(R.boards || []), ...(R.shrines || [])]) if (show(s.x)) this.iconBubble(c, X(s.x), Y(surf(s.x) ?? 450) - 40, icon, (R.shops || []).includes(s) ? '🛍️' : (R.boards || []).includes(s) ? '📋' : '⛩️');
    const gd = A.guide || {}, goal = gd.goal, step = here && gd.path && gd.path[0];
    for (const d of R.doors || []) {
      if (!vis(d.x, 140) || (!seen(d.x) && !(step && step.via === 'door' && step.door === d))) continue;
      const y = Y(surf(d.x) ?? 450), locked = !!(d.need && !A.flag(d.need)), next = step && step.via === 'door' && step.door === d;
      if (next) this.ring(c, X(d.x), y - 20, 24 * icon, t);
      this.iconDoor(c, X(d.x), y - 18 * icon, icon, locked);
      this.label(c, d.label || ROOMS[d.to].name, X(d.x), y - 44 * icon, 12, next ? '#ffe066' : '#fffaf0');
    }
    for (const side of ['left', 'right']) {
      const e = R.exits && R.exits[side];
      if (!e || !ROOMS[e.to]) continue;
      const x = side === 'left' ? 0 : R.w, next = step && step.via === side;
      if (!next && !seen(side === 'left' ? 0 : R.w - 1)) continue;
      this.exitMark(c, X(x), Y((surf(side === 'left' ? 20 : R.w - 20) ?? 450) - 60), side, ROOMS[e.to].name, next, icon, t);
    }
    const spr = clamp(zoom * 0.62, 0.3, 0.9);
    for (const n of R.npcs || []) {
      if ((n.show && !n.show(A)) || !show(n.x)) continue;
      const y = Y(n.y ?? surf(n.x) ?? 450);
      if (DRAW[n.kind]) { c.save(); try { DRAW[n.kind](c, X(n.x), y, { ...(n.opts || {}), t, scale: spr * ((n.opts && n.opts.scale) || 1), flip: n.flip || 1, shadow: false }); } catch (e) { /* */ } c.restore(); }
      if (n.talk && A.npcHasNews(n)) this.newsMark(c, X(n.x), y - 90 * spr, t);
      if (zoom > 0.55 && n.name) this.label(c, n.name, X(n.x), y + 14, 11, '#fffaf0');
    }
    if (here) for (const e of A.enemies || []) {
      if (e.dead || !show(e.x)) continue;
      if (DRAW[e.kind]) { c.save(); try { DRAW[e.kind](c, X(e.x), Y(e.y), { t, scale: spr * 0.9, flip: -1, shadow: false }); } catch (err) { /* */ } c.restore(); }
      c.strokeStyle = 'rgba(229,83,75,0.85)'; c.lineWidth = 2; c.beginPath(); c.ellipse(X(e.x), Y(e.y) + 2, 16 * icon, 5 * icon, 0, 0, TAU); c.stroke();
    }
    if (goal && goal.room === id && goal.x != null) this.goalStar(c, X(goal.x), Y((surf(goal.x) ?? 450) - 120), t, goal.quest);
    if (here) {
      const P = A.p;
      this.youAreHere(c, X(P.x), Y(P.y), t, spr, P.facing);
    }
  }

  // The parts of a place not explored yet (explore.js): blank paper laid over the map, with a soft shadow along its
  // edge. Drawn fresh each frame into a picture the size of the map (it moves and zooms with it).
  drawFog(c, m, R, X, Y) {
    const k = clamp(this.A.scale || 1, 1, 3), cv = this.fogCv || (this.fogCv = document.createElement('canvas'));
    const w = Math.ceil(PW * k), h = Math.ceil(PH * k);
    if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
    const f = cv.getContext('2d');
    f.setTransform(k, 0, 0, k, 0, 0);
    const { mask, clip } = fogRect(m, R, x => X(x) - PX, y => Y(y) - PY, 0, PH);
    paintFog(f, PW, PH, m, mask, clip, [X(0) - PX, Y(0) - PY]);
    c.save();
    c.shadowColor = 'rgba(45,28,12,0.45)'; c.shadowBlur = 9 * k; c.shadowOffsetY = 2.5 * k;
    c.drawImage(cv, PX, PY, PW, PH);
    c.restore();
  }

  // ---------------------------------------------------------------- the panel beside the map
  drawSidePanel(c, t, R, here) {
    const A = this.A, id = this.id;
    paper(c, p => shape(c, p, rrect(SX, SY, SW, SH, 14), PAPER));
    const area = AREAS[R.area];
    c.textAlign = 'left'; c.fillStyle = '#6b5a8a'; c.font = '12px Fredoka, sans-serif';
    c.fillText(`${area ? area.icon + ' ' + area.name : ''}`, SX + 12, SY + 20, SW - 24);
    c.fillStyle = INK; c.font = 'bold 17px Fredoka, sans-serif';
    this.wrap(c, R.name, SX + 12, SY + 42, SW - 24, 19, 2);
    let y = SY + 74;
    const line = (txt, col = INK) => { c.fillStyle = col; c.font = '13px "Segoe UI Emoji", Fredoka, sans-serif'; c.fillText(txt, SX + 12, y, SW - 24); y += 19; };
    if (!here) line('📍 You are somewhere else.', '#9a8fb3');
    const pct = exploredPct(A.s, id);
    if (pct != null) line(pct >= 100 ? '🗺️ Explored: all of it!' : `🗺️ Explored: ${pct}%`, pct >= 100 ? '#3f8a3a' : INK);
    const chests = (R.chests || []).filter(ch => !(ch.needBroken && !A.broken(ch.needBroken)));
    const open = chests.filter(ch => A.s.opened[ch.id]).length;
    if (chests.length) line(`🎁 Chests: ${open} of ${chests.length} opened`);
    const lamps = (R.lamps || []).length;
    if (lamps) line(`🏮 Lampposts: ${(R.lamps || []).filter(l => A.s.opened[`lamp_${id}_${typeof l === 'number' ? l : l.x}`]).length} of ${lamps} lit`);
    const news = (R.npcs || []).filter(n => (!n.show || n.show(A)) && n.talk && A.npcHasNews(n)).length;
    const folks = (R.npcs || []).filter(n => !n.show || n.show(A)).length;
    if (folks) line(`🙂 Folks: ${folks}${news ? `  (❗ ${news} with news)` : ''}`);
    const find = (R.collect || []).filter(it => !A.s.collected[it.id]).length;
    if (find) line(`✨ Still to find: ${find}`);
    if (here) { const foes = (A.enemies || []).filter(e => !e.dead).length; if (foes) line(`👾 Enemies about: ${foes}`); }
    const ways = (R.doors || []).length + ['left', 'right'].filter(s => R.exits && R.exits[s]).length;
    line(`🚪 Ways in and out: ${ways}`);
    // the goal
    const goal = A.guide && A.guide.goal;
    y += 6;
    c.strokeStyle = '#e4d8bd'; c.setLineDash([5, 5]); c.lineWidth = 2; c.beginPath(); c.moveTo(SX + 10, y - 8); c.lineTo(SX + SW - 10, y - 8); c.stroke(); c.setLineDash([]);
    c.fillStyle = INK; c.font = 'bold 13px Fredoka, sans-serif';
    c.fillText(goal ? `${goal.quest ? '📜' : '⭐'} Next:` : '⭐ Next:', SX + 12, y + 6);
    c.font = '12.5px Fredoka, sans-serif'; c.fillStyle = '#4a3d6a';
    const where = goal ? (goal.room === id ? ' (here: look for the star!)' : ` (in ${ROOMS[goal.room] ? ROOMS[goal.room].name : '???'})`) : '';
    y = this.wrap(c, goal ? goal.text + where : 'Explore, and try some side quests!', SX + 12, y + 24, SW - 24, 15, 5);
    // a key to the symbols
    const ky = SY + SH - 112;
    c.fillStyle = '#6b5a8a'; c.font = 'bold 11px Fredoka, sans-serif'; c.fillText('KEY', SX + 12, ky);
    const items = [['you', 'You'], ['star', 'Goal'], ['door', 'Door / path'], ['lamp', 'Lamppost'], ['chest', 'Chest'], ['news', 'Has news'], ['sparkle', 'To find'], ['foe', 'Enemy']];
    items.forEach(([k, label], i) => {
      const x = SX + 22 + (i % 2) * 92, yy = ky + 18 + Math.floor(i / 2) * 22;
      if (k === 'you') { c.fillStyle = '#ff6b6b'; c.strokeStyle = INK; c.lineWidth = 1.5; c.beginPath(); c.arc(x, yy - 4, 5, 0, TAU); c.fill(); c.stroke(); }
      else if (k === 'star') { c.beginPath(); starPath(c, x, yy - 4, 7, 3.2); c.fillStyle = '#ffe066'; c.fill(); c.strokeStyle = INK; c.lineWidth = 1.5; c.stroke(); }
      else if (k === 'door') this.iconDoor(c, x, yy - 4, 0.62, false);
      else if (k === 'lamp') this.iconLamp(c, x, yy - 2, 0.62, true, t);
      else if (k === 'chest') this.iconChest(c, x, yy - 3, 0.62, false);
      else if (k === 'news') this.newsMark(c, x, yy - 6, 0, 0.8);
      else if (k === 'sparkle') this.iconSparkle(c, x, yy - 4, 0.75, t);
      else { c.strokeStyle = '#e5534b'; c.lineWidth = 2; c.beginPath(); c.ellipse(x, yy - 3, 8, 3, 0, 0, TAU); c.stroke(); }
      c.fillStyle = INK; c.font = '11.5px Fredoka, sans-serif'; c.fillText(label, x + 12, yy, 72);
    });
  }

  drawRoomSwitcher(c) {
    if (this.list.length < 1) return;
    const n = this.list.length, x1 = W - 16, y = 12, h = 30;
    const name = `${this.R.name}`, label = n > 1 ? `${name}  ·  ${this.i + 1} of ${n}` : name;
    c.font = 'bold 13px Fredoka, sans-serif';
    const tw = Math.min(330, c.measureText(label).width + 20), x0 = x1 - tw - (n > 1 ? 64 : 0);
    if (n > 1) {
      this.button(c, x0, y, 28, h, '◀', () => this.flip(-1));
      this.button(c, x1 - 28, y, 28, h, '▶', () => this.flip(1));
    }
    const bx = n > 1 ? x0 + 32 : x1 - tw;
    c.fillStyle = 'rgba(255,250,240,0.12)'; c.beginPath(); rrect(bx, y, tw, h, 9)(c); c.fill();
    c.fillStyle = '#fffaf0'; c.textAlign = 'center'; c.fillText(label, bx + tw / 2, y + 20, tw - 12);
    if (this.msg) { c.font = '12px Fredoka, sans-serif'; c.fillStyle = '#ffd0a0'; c.textAlign = 'right'; c.fillText(this.msg, x1, y + 44); }
  }

  drawZoomBar(c, v) {
    const x = PX + PW - 34, y = PY + 30, h = 120;
    c.fillStyle = 'rgba(20,14,40,0.55)'; c.beginPath(); rrect(x - 6, y - 26, 32, h + 52, 10)(c); c.fill();
    const q = Math.log(v.zoom / v.minZ) / Math.log(v.maxZ / v.minZ);
    c.fillStyle = 'rgba(255,250,240,0.25)'; c.fillRect(x + 8, y, 4, h);
    c.fillStyle = '#ffe066'; c.strokeStyle = INK; c.lineWidth = 2; c.beginPath(); c.arc(x + 10, y + h - q * h, 7, 0, TAU); c.fill(); c.stroke();
    this.button(c, x - 3, y - 23, 26, 20, '+', () => this.zoomBy(1.3));
    this.button(c, x - 3, y + h + 3, 26, 20, '−', () => this.zoomBy(1 / 1.3));
  }

  // ---------------------------------------------------------------- little pictures
  button(c, x, y, w, h, text, fn) {
    c.fillStyle = 'rgba(255,250,240,0.16)'; c.beginPath(); rrect(x, y, w, h, 7)(c); c.fill();
    c.fillStyle = '#fffaf0'; c.font = 'bold 14px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillText(text, x + w / 2, y + h / 2 + 5);
    this.buttons.push({ x, y, w, h, fn });
  }

  label(c, text, x, y, size, color, align = 'center') {
    c.font = `bold ${size}px Fredoka, sans-serif`; c.textAlign = align;
    c.lineWidth = 3.5; c.strokeStyle = 'rgba(30,20,45,0.85)'; c.strokeText(text, x, y, 170); c.fillStyle = color; c.fillText(text, x, y, 170);
  }

  wrap(c, s, x, y, w, lh, maxLines) {
    const words = String(s).split(' ');
    let line = '', n = 0;
    for (const wd of words) {
      const test = line ? `${line} ${wd}` : wd;
      if (c.measureText(test).width > w && line) { c.fillText(line, x, y); line = wd; y += lh; if (++n >= maxLines - 1) break; }
      else line = test;
    }
    if (line) { c.fillText(line, x, y); y += lh; }
    return y;
  }

  ring(c, x, y, r, t) {
    const k = (t * 1.6) % 1;
    c.strokeStyle = `rgba(255,224,102,${1 - k})`; c.lineWidth = 3;
    c.beginPath(); c.arc(x, y, r + k * 14, 0, TAU); c.stroke();
  }

  iconDoor(c, x, y, s, locked) {
    c.save(); c.translate(x, y); c.scale(s, s);
    c.fillStyle = '#2c2244'; c.strokeStyle = INK; c.lineWidth = 2;
    c.beginPath(); c.moveTo(-9, 9); c.lineTo(-9, -3); c.arc(0, -3, 9, Math.PI, 0); c.lineTo(9, 9); c.closePath(); c.fill();
    c.strokeStyle = '#a87a4a'; c.lineWidth = 4; c.beginPath(); c.moveTo(-10, 10); c.lineTo(-10, -3); c.arc(0, -3, 10, Math.PI, 0); c.lineTo(10, 10); c.stroke();
    c.strokeStyle = INK; c.lineWidth = 1.5; c.beginPath(); c.moveTo(-12, 10); c.lineTo(-12, -3); c.arc(0, -3, 12, Math.PI, 0); c.lineTo(12, 10); c.stroke();
    if (locked) { c.font = '11px "Segoe UI Emoji", sans-serif'; c.textAlign = 'center'; c.fillText('🔒', 0, 6); }
    else { c.fillStyle = 'rgba(255,226,150,0.7)'; c.beginPath(); c.arc(0, 4, 3, 0, TAU); c.fill(); }
    c.restore();
  }

  // A way out of the side of a place: an arrow at the edge with the next place's name. When that edge is off the
  // map, a tab hugging the side of the map points the way instead (so it doesn't look like it's right there).
  exitMark(c, sx, sy, side, name, next, icon, t) {
    const dir = side === 'left' ? -1 : 1;
    const y = clamp(sy, PY + 24, PY + PH - 24);
    if (sx >= PX + 20 && sx <= PX + PW - 20) {
      if (next) this.ring(c, sx, y, 24, t);
      this.iconExit(c, sx, y, dir, icon);
      this.label(c, name, sx - dir * 30, y + 4, 12, next ? '#ffe066' : '#fffaf0', side === 'left' ? 'left' : 'right');
      return;
    }
    if ((side === 'left') !== (sx < PX)) return;   // (that edge is on the other side of what's showing)
    c.font = 'bold 11.5px Fredoka, sans-serif';
    const txt = `${name}`, w = Math.min(170, c.measureText(txt).width + 34), x = side === 'left' ? PX + 4 : PX + PW - 4 - w;
    c.fillStyle = next ? 'rgba(90,70,20,0.85)' : 'rgba(20,14,40,0.72)'; c.beginPath(); rrect(x, y - 12, w, 24, 12)(c); c.fill();
    if (next) { c.strokeStyle = '#ffe066'; c.lineWidth = 2; c.stroke(); }
    c.fillStyle = next ? '#ffe066' : '#fffaf0'; c.textAlign = 'center';
    c.fillText(side === 'left' ? `◀ ${txt}` : `${txt} ▶`, x + w / 2, y + 4, w - 10);
  }

  iconExit(c, x, y, dir, s) {
    c.save(); c.translate(x, y); c.scale(s * dir, s);
    c.fillStyle = '#ffe066'; c.strokeStyle = INK; c.lineWidth = 2;
    c.beginPath(); c.moveTo(-14, -7); c.lineTo(2, -7); c.lineTo(2, -14); c.lineTo(16, 0); c.lineTo(2, 14); c.lineTo(2, 7); c.lineTo(-14, 7); c.closePath(); c.fill(); c.stroke();
    c.restore();
  }

  iconLamp(c, x, y, s, lit, t) {
    c.save(); c.translate(x, y); c.scale(s, s);
    if (lit) glowDot(c, 0, -8, 18, '255,214,120', 0.5 + 0.1 * Math.sin(t * 3));
    c.fillStyle = '#3b3350'; c.fillRect(-1.5, -4, 3, 12);
    c.fillStyle = lit ? '#ffd23f' : '#8a84a0'; c.strokeStyle = INK; c.lineWidth = 1.6;
    c.beginPath(); c.moveTo(-6, -15); c.lineTo(6, -15); c.lineTo(4, -4); c.lineTo(-4, -4); c.closePath(); c.fill(); c.stroke();
    c.restore();
  }

  iconChest(c, x, y, s, open) {
    c.save(); c.translate(x, y); c.scale(s, s);
    c.globalAlpha *= open ? 0.45 : 1;
    c.fillStyle = '#c47a3a'; c.strokeStyle = INK; c.lineWidth = 1.8;
    c.beginPath(); rrect(-9, -6, 18, 12, 2)(c); c.fill(); c.stroke();
    c.fillStyle = open ? '#6e4a2a' : '#e8a54e'; c.beginPath(); rrect(-9, -11, 18, 6, 3)(c); c.fill(); c.stroke();
    c.fillStyle = '#ffd23f'; c.fillRect(-2, -5, 4, 4);
    c.restore();
  }

  iconSign(c, x, y, s) {
    c.save(); c.translate(x, y); c.scale(s, s);
    c.fillStyle = '#7a4f30'; c.fillRect(-1.5, -4, 3, 10);
    c.fillStyle = '#e8b97a'; c.strokeStyle = INK; c.lineWidth = 1.4; c.beginPath(); rrect(-8, -12, 16, 9, 2)(c); c.fill(); c.stroke();
    c.restore();
  }

  iconBlock(c, x, y, s, used) {
    c.save(); c.translate(x, y); c.scale(s * 0.8, s * 0.8);
    c.fillStyle = used ? '#a98a64' : '#f2b134'; c.strokeStyle = INK; c.lineWidth = 1.8;
    c.beginPath(); rrect(-8, -8, 16, 16, 3)(c); c.fill(); c.stroke();
    if (!used) { c.fillStyle = '#fffaf0'; c.font = 'bold 11px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillText('?', 0, 4); }
    c.restore();
  }

  iconSparkle(c, x, y, s, t) {
    c.save(); c.translate(x, y); c.scale(s, s); c.rotate(t * 1.4);
    glowDot(c, 0, 0, 14, '255,236,170', 0.55);
    c.fillStyle = '#fff3a0'; c.strokeStyle = INK; c.lineWidth = 1.2; c.beginPath(); starPath(c, 0, 0, 7, 2.6, 4); c.fill(); c.stroke();
    c.restore();
  }

  iconBubble(c, x, y, s, emoji) {
    c.save(); c.translate(x, y); c.scale(s, s);
    c.fillStyle = PAPER; c.strokeStyle = INK; c.lineWidth = 1.6; c.beginPath(); c.arc(0, 0, 11, 0, TAU); c.fill(); c.stroke();
    c.font = '13px "Segoe UI Emoji", sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(emoji, 0, 1); c.textBaseline = 'alphabetic';
    c.restore();
  }

  newsMark(c, x, y, t, s = 1) {
    c.save(); c.translate(x, y + Math.sin(t * 4) * 2); c.scale(s, s);
    c.fillStyle = '#e5534b'; c.strokeStyle = INK; c.lineWidth = 1.8; c.beginPath(); c.arc(0, 0, 8, 0, TAU); c.fill(); c.stroke();
    c.fillStyle = '#fffaf0'; c.font = 'bold 12px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillText('!', 0, 4.5);
    c.restore();
  }

  goalStar(c, x, y, t, quest) {
    glowDot(c, x, y, 34, quest ? '159,230,255' : '255,224,102', 0.55);
    c.save(); c.translate(x, y + Math.sin(t * 4) * 3);
    c.beginPath(); starPath(c, 0, 0, 13, 6); c.fillStyle = quest ? '#9fe6ff' : '#ffe066'; c.fill(); c.lineWidth = 2.5; c.strokeStyle = INK; c.stroke();
    c.restore();
  }

  youAreHere(c, x, y, t, scale, facing) {
    const k = (t * 1.2) % 1;
    c.strokeStyle = `rgba(255,107,107,${0.9 * (1 - k)})`; c.lineWidth = 3; c.beginPath(); c.ellipse(x, y, 16 + k * 22, (16 + k * 22) * 0.55, 0, 0, TAU); c.stroke();
    c.save(); try { DRAW.wick(c, x, y + 4, { t, scale, flip: facing, shadow: false, mood: 'happy' }); } catch (e) { /* */ } c.restore();
    this.label(c, 'You', x, y + 18, 11, '#ffb0b0');
  }
}
