// Turn-based battles on a little paper stage, with timed "action commands" and partner Team Attacks.
// The stage has depth, a camera that leans into the action, and an audience that cheers your good timing.
import { DRAW, drawBackdrop, glowDot, starPath, INK, PAPER, rrect, paper, shape, ell, vgrad, flame } from '../art.js';
import { drawBackdrop2, drawStage, drawCurtains, drawSpotlight, makeCrowd, drawAudience, drawImpact, drawSpeedLines, drawPoof } from '../art2.js';
import { sfx } from '../audio.js';
import { music } from '../music.js';
import { ENEMIES, PARTNERS, ITEMS } from './data.js';
import { TOWER_BATTLE } from './tower_play.js';
import { MARGIN_BATTLE } from './margin_play.js';

const W = 960, H = 540, FLOOR = 452;
const lerp = (a, b, p) => a + (b - a) * p;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const ease = p => (p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2);
const RATINGS = ['Nice!', 'Good!', 'Great!', 'Wonderful!', 'Excellent!'];
// Timed presses, in seconds around the moment an attack lands: inside EARLY/LATE it hits, and within
// PERFECT of dead on it's a PERFECT (+1 damage). Hold moves have a sweet spot of PERFECT_FILL around a full meter.
const EARLY = 0.16, LATE = 0.075, PERFECT = 0.05, PERFECT_FILL = 0.055;
// ✦ Light in battle: the Lantern Beam (learned at the Great Lantern) costs BEAM_COST a use, and when Wick's flame goes
// out, REKINDLE Light gets him back up (once a battle).
const BEAM_COST = 8, REKINDLE = 15;
const rand = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
const CONFETTI = ['#ffe066', '#ff9ab0', '#9fe6ff', '#b49cff', '#8be07a', '#fffaf0'];

// PERFECT!: a quick ring of gold rays bursting out from whoever nailed it
function drawPerfectBurst(c, x, y, k) {
  c.save();
  c.globalAlpha = 1 - k;
  c.strokeStyle = '#fff3a0'; c.lineCap = 'round'; c.lineWidth = 5 * (1 - k) + 1.5;
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2 + 0.13, r0 = 24 + k * 56, r1 = r0 + 14 + 22 * (1 - k);
    c.beginPath(); c.moveTo(x + Math.cos(a) * r0, y + Math.sin(a) * r0); c.lineTo(x + Math.cos(a) * r1, y + Math.sin(a) * r1); c.stroke();
  }
  c.restore();
}

export class Battle {
  constructor(A, el) {
    this.A = A;
    this.el = el;
    this.active = false;
    this.t = 0;
    this.frameAt = performance.now();
  }

  start(kinds, opts = {}) {
    return new Promise(resolve => {
      this.resolve = resolve;
      this.setup(kinds, opts);
      this.run().catch(err => {
        console.error(err);
        this.end('win');
      });
    });
  }

  // ---------------------------------------------------------------- setup
  setup(kinds, opts) {
    const s = this.A.s;
    this.active = true;
    this.opts = opts;
    this.theme = opts.theme || 'grove';
    this.t = 0;
    this.anims = [];
    this.timers = [];
    this.floaters = [];
    this.parts = [];
    this.shots = [];
    this.geysers = [];
    this.msg = '';
    this.msgUntil = 0;
    this.cue = null;
    this.hold = null;
    this.target = null;
    this.presses = [];
    this.armT = 0;
    this.lastDown = -1;
    this.lastGrade = null;
    this.lateWatch = null;
    this.xp = 0;
    this.coins = 0;
    this.killed = [];
    this.fled = false;
    this.outcome = null;
    this.round = 0;
    this.stop = 0;
    this.shake = 0;
    // camera, stage and crowd
    this.cam = { x: 480, y: 270, z: 1 };
    this.camT = { x: 480, y: 270, z: 1 };
    this.punch = 0;
    this.curtain = 0;
    this.crowd = this.crowd || makeCrowd();
    this.cheerT = -9;
    this.gaspT = -9;
    this.fx = [];
    this.spot = null;
    this.results = null;
    this.skipReq = false;
    this.shieldUsed = false;
    this.starUsed = false;
    // (Chapter 4: Rewind, Countdown's clock, Count Dusk's darkness and the Lumen Beam)
    this.lostHp = null; this.bigClock = null; this.duskOrb = null; this.darkness = 0; this.glory = 0; this.beam = null;
    this.rekindled = false;
    this.hero = { kind: 'wick', name: 'Wick', x: 300, hx: 300, y: FLOOR, flip: 1, hp: s.hero.hp, maxHp: s.hero.maxHp,
      status: {}, state: 'idle', mood: 'determined', hurtT: 0, swing: null, alive: true, phase: 0 };
    const pid = s.partner;
    this.partner = pid && s.partners[pid] ? { kind: pid, name: PARTNERS[pid].name, x: 190, hx: 190, y: FLOOR, flip: 1,
      hp: s.partners[pid].hp, maxHp: s.partners[pid].max, status: {}, state: 'idle', mood: 'determined', hurtT: 0,
      alive: s.partners[pid].hp > 0, phase: 0, bond: this.A.bondLv(pid) } : null;
    this.enemies = [];
    for (const k of kinds) this.addEnemy(k);
    this.layout();
    for (const e of this.enemies) e.x = W + 120;
    this.el.classList.remove('hidden');
    this.el.innerHTML = '<div class="bmenu"></div>';
    this.menuEl = this.el.querySelector('.bmenu');
  }

  addEnemy(kind) {
    const d = ENEMIES[kind];
    const e = { ...d, kind, maxHp: d.hp, hp: d.hp, status: {}, flip: -1, alive: true, dying: 0, hurtT: 0, phase: 0,
      fly: !!d.flying, x: W + 120, y: FLOOR, hx: 700, born: this.round || 0, growth: 0 };
    if (e.thorns) e.status.spikes = true;
    if (e.bomb) e.fuse = 3;
    e.baseY = e.fly ? FLOOR - 105 : FLOOR;
    e.y = e.baseY;
    this.enemies.push(e);
    return e;
  }

  layout() {
    const alive = this.enemies.filter(e => e.alive);
    const boss = alive.find(e => e.boss);
    const minions = alive.filter(e => !e.boss);
    const wide = boss && boss.kind === 'cindermaw';
    if (boss) boss.hx = wide ? 815 : 800;
    const gap = wide ? 86 : boss ? 95 : minions.length > 3 ? 95 : 120;
    const start = wide ? 492 : boss ? 545 : alive.length === 1 ? 680 : 590;
    minions.forEach((e, i) => { e.hx = start + i * gap; });
  }

  // ---------------------------------------------------------------- timing helpers
  now() { return this.t + (performance.now() - this.frameAt) / 1000; }
  wait(sec) { return new Promise(r => this.timers.push({ at: this.t + sec, r })); }
  anim(dur, fn) { return new Promise(r => this.anims.push({ t0: this.t, dur, fn, r })); }
  badge(id) { return this.A.s.badges.equipped.includes(id); }
  tutor() { return this.badge('timing_tutor'); }
  say(text, secs = 1.8) { this.msg = text; this.msgUntil = this.t + secs; }
  widen() { return (this.badge('perfectly_imperfect') ? 1.4 : 1) * (this.badge('time_keeper') ? 1.25 : 1); }
  // inked (Smudge) or distracted (a Scrollbug's feed): action commands get harder to time
  bleary() { return this.hero.status.inked > 0 || this.hero.status.distracted > 0; }

  async moveTo(a, x, dur, dy = 0) {
    const x0 = a.x, y0 = a.y;
    a.flip = x < x0 ? -1 : 1;
    a.state = 'walk';
    await this.anim(dur, p => { a.x = lerp(x0, x, ease(p)); if (dy) a.y = y0 + dy * Math.sin(p * Math.PI); });
    a.state = 'idle';
  }

  async goHome(a) {
    await this.moveTo(a, a.hx, 0.4);
    a.flip = a === this.hero || a === this.partner ? 1 : -1;
    a.y = a.baseY ?? FLOOR;
  }

  arm(at, type, key = 'space', actor = null) { this.armT = this.now(); this.presses = []; this.lateWatch = null; this.cue = { at, type, key, actor }; }
  firstPress() { const p = this.presses.find(x => x.t >= this.armT); this.presses = []; return p || null; }
  timingK() { return this.widen() * (this.bleary() ? 0.55 : 1); }
  // (the PERFECT part of the window: half again as wide with the Crystal Choir's Perfect Pitch badge)
  perfK() { return this.timingK() * (this.badge('perfect_pitch') ? 1.5 : 1); }

  // How a timed press went: 'perfect', 'good', 'early', 'late', 'wrong' (the other button) or 'none'.
  // A press a hair after the landing still counts, so the landing pose holds (like a hit-stop) for that sliver.
  async grade(impact, key = 'space') {
    const k = this.timingK(), who = (this.cue && this.cue.actor) || this.hero;
    while (!this.presses.some(x => x.t >= this.armT) && this.now() < impact + LATE * k) await this.wait(0);
    const p = this.firstPress();
    this.cue = null;
    const d = p ? p.t - impact : 0;
    const g = !p ? 'none' : p.key !== key ? 'wrong' : d < -EARLY * k ? 'early' : d > LATE * k ? 'late' : Math.abs(d) <= PERFECT * this.perfK() ? 'perfect' : 'good';
    this.lastGrade = g;
    if (g === 'perfect' && this.badge('crayon_heart')) this.crayonHeart();
    if (g === 'none') this.lateWatch = { until: this.now() + 0.3, who };
    else if (g === 'early' || g === 'late' || g === 'wrong') this.missed(g === 'early' ? 'Too early!' : g === 'late' ? 'Too late!' : 'Wrong button!', who);
    return g;
  }
  async judge(impact, key = 'space') { const g = await this.grade(impact, key); return g === 'perfect' || g === 'good'; }
  perfectBonus() { return this.lastGrade === 'perfect' ? 1 : 0; }
  perfectFill() { return PERFECT_FILL * this.perfK(); }
  missed(text, who) { this.popTiming(text, who, '#cfc6e6'); sfx('whiff'); }
  // A timing pop-up over whoever pressed. It replaces the last one there, so a combo's pop-ups never pile up.
  popTiming(text, who, color, big = false) {
    const x = who.x + 40;
    this.floaters = this.floaters.filter(f => !(f.timing && Math.abs(f.x - x) < 120));
    this.floaters.push({ type: 'text', text, x, y: who.y - 95, t0: this.t, color, big, timing: true });
  }

  async beat(actor, key, dur, fn) {
    const impact = this.now() + dur;
    this.arm(impact, 'team', key, actor);
    await this.anim(dur, fn);
    return this.judge(impact, key);
  }

  holdCommand(actor, orb = null) {
    this.lastGrade = null; this.lateWatch = null;
    return new Promise(resolve => { this.hold = { actor, orb, started: false, fill: 0, since: this.now(), resolve }; });
  }

  // A fireball arcs from one actor to a target; returns whether SPACE was timed as it landed.
  async fireShot(from, t, dur, size = 0.8) {
    const shot = { x: from.x + 14, y: from.y - 44, size };
    this.shots.push(shot);
    const impact = this.now() + dur;
    this.arm(impact, 'press', 'space', from);
    const x0 = shot.x, y0 = shot.y, ty = t.y - this.eh(t) * 0.5;
    sfx('flare');
    await this.anim(dur, p => { shot.x = lerp(x0, t.x, p); shot.y = lerp(y0, ty, p) - Math.sin(p * Math.PI) * 70; });
    this.shots.splice(this.shots.indexOf(shot), 1);
    return this.judge(impact);
  }

  hotNow(e) { return !!(e.blazing || e.status.molten > 0 || e.status.lit > 0); }
  // What hurts Wick if he jumps on this enemy right now: 'spikes', 'hot', or nothing.
  ouch(e) {
    if (this.spikyNow(e) && !this.badge('spike_shield')) return 'spikes';
    if (this.hotNow(e) && !this.badge('ember_ward')) return 'hot';
    return null;
  }
  hotHammer() { return this.badge('hot_hammer') ? { fire: true, burn: true } : {}; }

  burn(e) {
    if (!e.alive) return;
    if (e.fire) { this.float('Fireproof!', e.x, e.y - this.eh(e) - 34, '#ffd0a0'); return; }
    e.status.burn = Math.max(e.status.burn || 0, 2);
    this.float('Burned!', e.x, e.y - this.eh(e) - 34, '#ff9a3d');
  }

  burnHero(T) {
    if (!T || !T.alive) return;
    if (this.badge('ember_ward')) { this.float('Fireproof!', T.x, T.y - 130, '#ffd0a0'); return; }
    T.status.burn = Math.max(T.status.burn || 0, 2);
    this.float('Burned!', T.x, T.y - 130, '#ff9a3d');
  }

  // The pop-up after a good press ("Nice!", "Good!"...), or PERFECT! when the press that just landed was dead on.
  rate(n, who = this.hero) {
    const perfect = this.lastGrade === 'perfect';
    this.popTiming(perfect ? 'PERFECT!' : RATINGS[Math.min(n - 1, RATINGS.length - 1)], who, perfect ? '#fff3a0' : '#ffe066', perfect);
    for (let i = 0; i < (perfect ? 14 : 6); i++) this.parts.push({ x: who.x, y: who.y - 60, vx: (Math.random() - 0.5) * (perfect ? 460 : 300), vy: -150 - Math.random() * 200, life: 0.6, c: perfect && i % 2 ? '#fffaf0' : '#ffe066', star: true });
    if (perfect) {
      this.fx.push({ kind: 'perfect', x: who.x, y: who.y - 60, t0: this.t });
      sfx('perfect');
      if (!this.A.s.flags.perfect_tip) { this.A.s.flags.perfect_tip = true; this.say('PERFECT! Pressing dead on adds +1 damage.', 2.6); }
    } else sfx('nice');
    this.cheer();
  }

  burst(x, y, n, hurt = false) { this.floaters.push({ type: 'burst', x, y, n, t0: this.t, hurt }); }
  float(text, x, y, color = '#fffaf0') { this.floaters.push({ type: 'text', text, x, y, t0: this.t, color }); }

  // ---------------------------------------------------------------- camera, crowd and effects
  focus(x, y, z = 1.1) { this.camT = { x: clamp(x, 420, 540), y: clamp(y, 240, 310), z }; }
  unfocus() { this.camT = { x: 480, y: 270, z: 1 }; }
  cheer() { if (this.t - this.cheerT > 0.5) { this.cheerT = this.t; sfx('cheer'); } }
  gasp() { if (this.t - this.gaspT > 0.5) { this.gaspT = this.t; sfx('gasp'); } }
  impact(x, y, big = false) { this.fx.push({ kind: 'impact', x, y, t0: this.t, big }); }
  confetti(x, y, n = 18, spread = 500) {
    for (let i = 0; i < n; i++) {
      this.parts.push({ x, y, vx: (Math.random() - 0.5) * spread, vy: -200 - Math.random() * 320, life: 1.4, c: CONFETTI[i % CONFETTI.length],
        paper: true, rot: Math.random() * 6, vr: (Math.random() - 0.5) * 18, g: 520 });
    }
  }

  // ---------------------------------------------------------------- input (from the adventure)
  onPress(key = 'space') {
    const n = this.now();
    if (key === 'space') this.lastDown = n;
    if (this.results) this.skipReq = true;
    // just after a timing window closed with no press: this one came too late
    const L = this.lateWatch;
    if (L && n <= L.until) { this.lateWatch = null; this.missed('Too late!', L.who); return; }
    this.presses.push({ t: n, key });
  }

  onKey(act) {
    if (this.results) { if (act === 'confirm') this.skipReq = true; return true; }
    if (!this.target) return false;
    const T = this.target;
    if (act === 'left' || act === 'up') { T.i = (T.i + T.list.length - 1) % T.list.length; sfx('select'); }
    else if (act === 'right' || act === 'down') { T.i = (T.i + 1) % T.list.length; sfx('select'); }
    else if (act === 'confirm') { const e = T.list[T.i]; this.target = null; T.resolve(e); }
    else if (act === 'back') { this.target = null; T.resolve(null); }
    return true;
  }

  onClick(x) {
    if (!this.target) return;
    let best = null, bd = 1e9;
    for (const e of this.target.list) { const d = Math.abs(e.x - x); if (d < bd) { bd = d; best = e; } }
    if (best && bd < 80) { const T = this.target; this.target = null; T.resolve(best); }
  }

  pickTarget(filter, label = 'Pick a target') {
    const list = this.enemies.filter(e => e.alive && !(e.status.under > 0) && filter(e)).sort((a, b) => a.x - b.x);
    if (!list.length) return Promise.resolve(undefined);
    this.say(`${label}: ← → then SPACE (ESC to go back)`, 99);
    return new Promise(resolve => { this.target = { list, i: 0, resolve }; }).then(e => { this.msg = ''; return e; });
  }

  menu(title, items) {
    return this.A.menu(this.menuEl, title, items, { cancel: false, battle: true });
  }

  // ---------------------------------------------------------------- the fight
  over() {
    return this.fled || this.hero.hp <= 0 || !this.enemies.some(e => e.alive);
  }

  // Is the fight over? If Wick's flame just went out, he can first Rekindle it with ✦ Light (once a battle, and not
  // when sparring).
  async finished() {
    const H = this.hero;
    if (H.hp <= 0 && !this.fled && !this.rekindled && !this.opts.spar && this.enemies.some(e => e.alive) && this.A.light >= REKINDLE) {
      this.rekindled = true;
      H.mood = 'hurt';
      this.gasp();
      const v = await this.menu(`💫 Wick's flame is going out!  ✦ ${this.A.light}`, [
        { label: '🔥 Rekindle!', right: `${REKINDLE} ✦`, value: 'yes',
          desc: `Pour ${REKINDLE} ✦ Light into Wick's wick: he gets back up with half his HP and keeps fighting.` },
        { label: '💤 Let it go out', value: 'no', desc: 'Lose this battle. (You keep your items, coins and XP, and try again from the last lamppost.)' },
      ]);
      if (v === 'yes' && (await this.A.payLight(REKINDLE))) {
        H.hp = Math.ceil(H.maxHp / 2);
        H.mood = 'determined';
        sfx('flare'); sfx('levelup');
        this.float(`REKINDLED! ♥ ${H.hp}`, H.x, H.y - 130, '#ffe066');
        for (let i = 0; i < 16; i++) this.parts.push({ x: H.x, y: H.y - 50, vx: (Math.random() - 0.5) * 300, vy: -100 - Math.random() * 300, life: 0.9, c: i % 2 ? '#ffe066' : '#ff9a3d', star: true });
        this.cheer();
        await this.anim(0.8, p => { this.glory = 1 - p; H.sq = 1 + Math.sin(p * Math.PI) * 0.25; });
        this.glory = 0;
      }
    }
    return this.over();
  }

  async run() {
    // curtains up: the party runs on from the left while the enemies drop onto the stage
    const party = [this.hero, this.partner].filter(Boolean);
    for (const a of party) { a.x = a === this.hero ? -60 : -150; a.state = 'walk'; }
    for (const e of this.enemies) { e.x = e.hx; e.y = e.fly ? -80 : -140; }
    await this.anim(1.0, p => {
      this.curtain = ease(clamp((p - 0.2) / 0.8, 0, 1));
      for (const a of party) a.x = lerp(a === this.hero ? -60 : -150, a.hx, ease(clamp(p * 1.25, 0, 1)));
      const q = clamp((p - 0.3) / 0.6, 0, 1);
      for (const e of this.enemies) e.y = e.fly ? lerp(-80, e.baseY, ease(q)) : lerp(-140, e.baseY, q * q);
    });
    for (const a of party) { a.state = 'idle'; a.x = a.hx; }
    for (const e of this.enemies) { e.y = e.baseY; if (!e.fly) { e.sq = 0.7; this.dustAt(e.x); } }
    if (this.enemies.some(e => !e.fly)) sfx('block');
    const sh = this.A.s.hero;
    if (this.badge('second_wind') && sh.fp < sh.maxFp) {
      sh.fp = Math.min(sh.maxFp, sh.fp + 2);
      this.float('+2 ✿ Second Wind', this.hero.x + 20, this.hero.y - 130, '#9fe6ff');
    }
    if (!this.opts.firstStrike && !this.opts.ambush && !this.opts.boss && !this.opts.scripted && !this.opts.spar && this.badge('early_bird') && this.A.has('hammer')) {
      this.opts.firstStrike = 'hammer';
      this.float('Early Bird!', this.hero.x, this.hero.y - 130, '#ffe066');
    }
    if (this.opts.firstStrike) await this.firstStrike();
    if (this.opts.ambush) {
      this.say('Ambush! They caught you from behind!', 2);
      sfx('alert');
      await this.wait(0.8);
      await this.enemyPhase();
      this.endRound();
    }
    if (this.A.s.battlesWon === 0 && this.tutor()) this.say('Your turn! Pick a move. Watch for the ⭐ cue to press SPACE.', 4);
    while (!(await this.finished())) {
      this.round++;
      await this.heroTurn();
      if (await this.finished()) break;
      if (this.partner && this.partner.alive) {
        await this.partnerTurn();
        if (await this.finished()) break;
      }
      // (what the enemies take this turn, for Tick's Rewind)
      const before = { hero: this.hero.hp, partner: this.partner ? this.partner.hp : 0 };
      await this.enemyPhase();
      this.lostHp = { hero: Math.max(0, before.hero - this.hero.hp), partner: this.partner ? Math.max(0, before.partner - this.partner.hp) : 0 };
      if (await this.finished()) break;
      this.endRound();
    }
    let result = 'win';
    this.spot = null;
    this.unfocus();
    if (this.fled) result = 'run';
    else if (this.hero.hp <= 0) {
      result = 'lose';
      this.outcome = 'lose';
      sfx('lose');
      this.hero.mood = 'hurt';
      this.say(this.opts.spar ? 'Sensei wins this round! (Sparring never costs you anything.)' : "Wick's flame flickered out...", 3);
      await this.anim(1.2, p => { this.curtain = 1 - ease(clamp((p - 0.4) / 0.6, 0, 1)) * 0.6; });
      await this.wait(0.8);
    } else {
      this.outcome = 'win';
      if (!music.stinger('victory')) sfx('fanfare');
      if (this.badge('coin_magnet')) this.coins = Math.ceil(this.coins * 1.5);
      if (this.badge('bookworm')) this.xp = Math.round(this.xp * 1.25);
      this.hero.mood = 'happy';
      if (this.partner && this.partner.alive) this.partner.mood = 'happy';
      this.cheer();
      this.confetti(480, -20, 30, 900);
      for (let i = 0; i < 16; i++) this.parts.push({ x: 640, y: 380, vx: (Math.random() - 0.5) * 500, vy: -300 - Math.random() * 300, life: 1.2, c: '#ffd23f', coin: true });
      // a little victory spin and hop
      const H0 = this.hero;
      await this.anim(1.1, p => {
        H0.y = FLOOR - Math.abs(Math.sin(p * Math.PI * 2)) * 46;
        H0.flip = Math.cos(p * Math.PI * 4);
        if (this.partner && this.partner.alive) this.partner.y = FLOOR - Math.abs(Math.sin(p * Math.PI * 2 + 1)) * 32;
      });
      H0.flip = 1; H0.y = FLOOR;
      if (this.partner) this.partner.y = FLOOR;
      // the results card stays up while the fanfare plays (SPACE skips it)
      const sh2 = this.A.s.hero;
      this.results = { t0: this.t, xp: this.xp, coins: this.coins, from: sh2.xp, lvl: sh2.lvl };
      this.skipReq = false;
      while (this.t - this.results.t0 < 3.6 && !(this.skipReq && this.t - this.results.t0 > 0.9)) await this.wait(0.05);
    }
    this.end(result);
  }

  end(result) {
    const s = this.A.s;
    s.hero.hp = Math.max(0, Math.min(this.hero.maxHp, this.hero.hp));
    if (this.partner) s.partners[this.partner.kind].hp = Math.max(1, this.partner.hp);
    for (const e of this.enemies) if (e.thief && e.loot && !e.fledWithLoot && !e.alive) s.items[e.loot] = (s.items[e.loot] || 0) + 1;
    // Rocco hands back everything he swiped (win or lose: losing your stuff on top of losing is no fun)
    for (const e of this.enemies) for (const k of e.stash || []) s.items[k] = (s.items[k] || 0) + 1;
    // the victory fanfare stops here, so it never keeps playing back in the field
    music.endStinger(0.6);
    this.results = null;
    this.active = false;
    this.target = null;
    this.hold = null;
    this.el.classList.add('hidden');
    this.el.innerHTML = '';
    this.resolve({ result, xp: this.xp, coins: this.coins, killed: this.killed });
  }

  async firstStrike() {
    const e = this.enemies.find(x => x.alive);
    if (!e) return;
    this.say('First Strike!', 1.5);
    const H = this.hero;
    if (this.opts.firstStrike === 'ember' && this.partner && this.partner.kind === 'ember') {
      await this.fireShot(this.partner, e, 0.5, 0.9);
      this.cue = null;
      this.hit(e, 1, { by: 'partner', fire: true, burn: true });
      await this.wait(0.3);
      this.layout();
      return;
    }
    if (this.opts.firstStrike !== 'jump') {
      await this.moveTo(H, e.x - 75, 0.35);
      H.swing = 0;
      await this.anim(0.15, p => { H.swing = p; });
      this.hit(e, 1, { by: 'hero', kind: 'hammer', ...this.hotHammer() });
      await this.wait(0.2);
      H.swing = null;
    } else {
      const x0 = H.x;
      H.state = 'jump';
      await this.anim(0.5, p => { H.x = lerp(x0, e.x, p); H.y = lerp(FLOOR, e.y - this.eh(e), p) - Math.sin(p * Math.PI) * 120; });
      const ouch = this.ouch(e);
      if (ouch) { this.damage(H, 1); this.say(ouch === 'hot' ? 'Yowch! Too hot to jump on!' : 'Ouch, spikes!'); }
      else this.hit(e, 1, { by: 'hero', kind: 'jump' });
    }
    H.state = 'jump';
    const xs = H.x, ys = H.y;
    await this.anim(0.45, p => { H.x = lerp(xs, H.hx, p); H.y = lerp(ys, FLOOR, p) - Math.sin(p * Math.PI) * 60; });
    H.state = 'idle'; H.flip = 1; H.y = FLOOR;
    this.layout();
  }

  eh(e) { return e.h * (e.scale || 1) * (e.small ? 0.72 : 1); }
  spikyNow(e) { return !!(e.spiky || (e.thorns && e.status.spikes)); }

  // Damage dealt BY the party to an enemy.
  hit(e, power, o = {}) {
    if (!e.alive) return 0;
    if (e.status.under > 0) { this.float('Hiding in the lava!', e.x, e.y - 40, '#ffd0a0'); return 0; }
    if (e.mirror && e.status.glow > 0 && !o.item) {
      const who = o.by === 'partner' && this.partner ? this.partner : this.hero;
      this.float('REFLECTED!', e.x, e.y - this.eh(e) - 20, '#e8f0ff');
      sfx('guard');
      this.damage(who, Math.max(1, power), { noThorns: true });
      return 0;
    }
    if (e.status.invisible > 0 && !o.reveal && Math.random() < 0.5) {
      this.float('MISS!', e.x, e.y - this.eh(e) - 10, '#d9d4f0');
      return 0;
    }
    if (e.shell && !(e.status.flipped > 0) && !o.item) {
      e.status.flipped = 2;
      e.hurtT = 0.3;
      this.float('FLIPPED!', e.x, e.y - this.eh(e) - 20, '#ffe066');
      sfx('guard');
      this.stop = 0.06;
      return 0;
    }
    // Sensei's Counter Stance: touch him and he strikes right back
    const contact = !o.item && !o.fire && !o.ranged && o.by !== 'thorns';
    if (e.status.counter > 0 && contact) {
      e.status.counter = 0;
      const who = o.by === 'partner' && this.partner ? this.partner : this.hero;
      this.float('COUNTER!', e.x, e.y - this.eh(e) - 20, '#ffb347');
      sfx('guard');
      this.impact(who.x, who.y - 40, true);
      this.shake = 6;
      this.damage(who, 2, { noThorns: true });
      return 0;
    }
    // the Gloom Knight's raised shield: only a hammer gets through, and it knocks the shield aside
    if (e.status.guard > 0 && !o.item) {
      if (o.kind !== 'hammer') {
        this.float('BLOCKED!', e.x, e.y - this.eh(e) - 20, '#c8b8ff');
        sfx('guard');
        this.impact(e.x - 30, e.y - this.eh(e) * 0.5);
        return 0;
      }
      e.status.guard = 0;
      this.float('SHIELD BASH!', e.x, e.y - this.eh(e) - 34, '#ffe066');
    }
    // hollow armor: a hammer knocks it flat, and flat it has no defense at all
    if (e.knight && o.kind === 'hammer' && !(e.status.toppled > 0)) { e.status.toppled = 2; this.float('TOPPLED!', e.x, e.y - 60, '#ffe066'); }
    if (e.dents && o.kind === 'hammer' && e.def > 0) { e.def--; e.dent = (e.dent || 0) + 1; this.float(`DENTED! DEF ${e.def}`, e.x, e.y - this.eh(e) - 46, '#ffe066'); }
    const s = this.A.s;
    let bonus = 0;
    if (o.by === 'hero') {
      bonus += this.A.heroAtk ? this.A.heroAtk() : s.hero.atk || 0;   // Dojo training, and the Lumen Shards
      if (this.badge('sticker_star') && !this.starUsed) { this.starUsed = true; bonus += 2; this.float('STICKER STAR! +2', e.x, e.y - this.eh(e) - 60, '#ffe066'); }
      if (this.badge('black_belt')) bonus++;
      if (this.badge('marathon')) bonus++;
      if (this.badge('hero_heart') && this.hero.hp >= this.hero.maxHp) bonus++;
      if (this.badge('lumen_crown')) bonus++;
      if (this.badge('chip_off') && o.kind === 'hammer') bonus++;   // (the Chunky Quarry's badge)
    }
    if (o.by === 'partner') {
      bonus += s.palAtk || 0;
      if (this.badge('royal_crown')) bonus++;
      if (this.badge('study_buddy')) bonus++;   // (the Study Bridges' badge)
      if (this.partner && this.partner.bond >= 3) bonus++;
      if (this.badge('kindling')) bonus++;
    }
    // Doodle's Outline: every hit on an outlined enemy does 1 more; Rough Draft: so does a GOOD (not PERFECT) press
    if (e.status.outlined > 0) bonus++;
    if ((o.by === 'hero' || o.by === 'partner') && this.badge('rough_draft') && this.lastGrade === 'good') bonus++;
    if (o.fire && e.armor && !(e.status.molten > 0)) { this.float('MELTED! No more armor!', e.x, e.y - this.eh(e) - 40, '#ffb347'); }
    if (o.fire && e.armor) e.status.molten = 2;
    const soft = (e.shell && e.status.flipped > 0) || (e.armor && e.status.molten > 0) || e.status.toppled > 0;
    const def = soft ? 0 : (e.def || 0);
    const d = Math.max(0, power + bonus - (o.pierce ? 0 : def));
    e.hp = Math.max(0, e.hp - d);
    this.burst(e.x, e.y - this.eh(e) - 12, d);
    e.hurtT = 0.35;
    e.kb = 1;
    this.impact(e.x - 12, e.y - this.eh(e) * 0.55, d >= 3);
    this.punch = Math.min(0.12, this.punch + (d >= 3 ? 0.06 : 0.025));
    this.stop = d >= 3 ? 0.1 : 0.06;
    if (d >= 3) { this.shake = 7; this.cheer(); }
    sfx(d > 0 ? 'hit' : 'guard');
    for (let i = 0; i < 6; i++) this.parts.push({ x: e.x, y: e.y - this.eh(e) / 2, vx: (Math.random() - 0.5) * 300, vy: -Math.random() * 300, life: 0.6, c: '#fffaf0' });
    if (e.hp <= 0) this.kill(e);
    else if (e.splits && !e.small && d > 0 && e.hp >= 2) this.split(e);
    if (o.burn && e.alive) this.burn(e);
    return d;
  }

  split(e) {
    const total = e.hp;
    const a = Math.ceil(total / 2), b = Math.floor(total / 2);
    e.small = true; e.splits = false; e.hp = e.maxHp = a;
    const m = this.addEnemy(e.kind);
    m.small = true; m.splits = false; m.hp = m.maxHp = b; m.x = e.x; m.xp = Math.ceil(e.xp / 2);
    this.float('SPLIT!', e.x, e.y - 70, '#bfe8ff');
    this.layout();
    this.anim(0.4, p => { for (const x of [e, m]) x.x = lerp(x.x, x.hx, p); });
  }

  kill(e) {
    e.alive = false;
    e.dying = 1;
    this.killed.push(e.kind);
    const lvl = this.A.s.hero.lvl;
    this.xp += Math.round(e.xp * Math.max(0.3, 1 - 0.15 * Math.max(0, lvl - e.lvl)));
    this.coins += rand(e.coins[0], e.coins[1]) + (this.badge('koi_charm') ? 1 : 0);
    for (let i = 0; i < 8; i++) this.parts.push({ x: e.x, y: e.y - this.eh(e) / 2, vx: (Math.random() - 0.5) * 260, vy: -100 - Math.random() * 260, life: 0.8, c: '#ffe066', star: true });
    // poof! into paper scraps
    this.fx.push({ kind: 'poof', x: e.x, y: e.y - this.eh(e) / 2, t0: this.t });
    this.confetti(e.x, e.y - this.eh(e) / 2, 10, 320);
    sfx('poof');
    this.cheer();
    if (e.thief && e.loot) this.float(`Got your ${ITEMS[e.loot].name} back!`, e.x, e.y - 90, '#8be07a');
  }

  dustAt(x, y = FLOOR) {
    for (let i = 0; i < 6; i++) {
      this.parts.push({ x: x + (Math.random() - 0.5) * 40, y: y - 4, vx: (Math.random() - 0.5) * 160, vy: -40 - Math.random() * 60, life: 0.5, puff: true, r: 5 + Math.random() * 5, g: -60 });
    }
  }

  // Damage dealt TO the party.
  damage(T, d, o = {}) {
    if (d > 0 && T.status.marked > 0 && !o.pure) d++;   // marked WRONG by a Red Pen
    if (T === this.hero && T.status.shield) { d = 0; this.float('Shielded!', T.x, T.y - 100, '#bfe6ff'); }
    if (T.status.defend) d = Math.max(0, d - 1);
    if (T === this.hero && this.badge('acorn_armor')) d = Math.max(0, d - 1);
    if (T === this.hero && this.badge('lumen_crown')) d = Math.max(0, d - 1);
    // Dojo guard training (burns and other status damage ignore it)
    if (T === this.hero && d > 0 && !o.pure) d = Math.max(0, d - (this.A.s.hero.def || 0) - (this.badge('black_belt') ? 1 : 0));
    if (T === this.partner && d > 0 && this.badge('royal_crown')) d = Math.max(0, d - 1);
    if (T === this.hero && d > 0 && this.badge('story_shield') && !this.shieldUsed) {
      this.shieldUsed = true; d = 0;
      this.float('Story Shield!', T.x, T.y - 120, '#fff3c9');
    }
    T.hp = Math.max(0, T.hp - d);
    this.burst(T.x, T.y - 80, d, true);
    if (d > 0) {
      T.hurtT = 0.45; T.kb = 1;
      sfx('hurt');
      this.shake = Math.max(this.shake, 3);
      this.impact(T.x + 14, T.y - 50, d >= 3);
      if (d >= 2) this.gasp();
    }
    if (T === this.hero && T.hp <= 0 && (this.A.s.items.feather || 0) > 0) {
      this.A.s.items.feather--;
      T.hp = Math.ceil(T.maxHp / 2);
      this.say('The Revive Feather flutters... Wick is back up!', 2.5);
      sfx('levelup');
    }
    if (T === this.partner && T.hp <= 0 && T.alive) { T.alive = false; this.say(`${T.name} is knocked out!`); }
    return d;
  }

  // ---------------------------------------------------------------- Wick's turn
  heroSpecials() {
    const out = [];
    if (this.badge('power_jump')) out.push({ id: 'power_jump', name: 'Power Jump', fp: 2, desc: 'One mighty jump for 3 damage.' });
    if (this.badge('quake_hammer') && this.A.has('hammer')) out.push({ id: 'quake_hammer', name: 'Quake Hammer', fp: 2, desc: 'Hits every ground enemy.' });
    return out;
  }

  teamCost() {
    if (!this.partner) return 99;
    return Math.max(1, PARTNERS[this.partner.kind].team.fp - (this.badge('clean_flame') ? 1 : 0));
  }

  async heroTurn() {
    const H = this.hero;
    this.spot = H;
    this.unfocus();
    H.status.defend = 0;
    H.status.shield = 0;
    // glued feet (the Gloop Golem's Glue Spit) last for one turn
    const glued = H.status.stuck > 0;
    if (glued) H.status.stuck--;
    // well rested (the Drowsy Downs' Sweet Dreams badge): no dozing off, and a little FP back every turn
    if (this.badge('sweet_dreams')) {
      H.status.sleep = 0;
      const sh = this.A.s.hero;
      if (sh.fp < sh.maxFp) { sh.fp++; this.float('+1 ✿', H.x, H.y - 120, '#9fe6ff'); }
    }
    if (H.status.sleep > 0) {
      H.status.sleep--;
      this.say('Wick is fast asleep... zzz');
      await this.wait(1.1);
      return;
    }
    // Count Dusk's LATER! spell
    if (H.status.later > 0) {
      H.status.later--;
      this.say("Wick's turn is postponed... Count Dusk wins this round of LATER.", 2);
      await this.wait(1.2);
      return;
    }
    for (;;) {
      const s = this.A.s;
      const items = this.A.battleItems();
      const specials = this.heroSpecials();
      const P = this.partner;
      const team = P ? PARTNERS[P.kind].team : null;
      const tc = this.teamCost();
      const up = this.enemies.filter(e => e.alive && !(e.status.under > 0));
      const ground = up.some(e => !e.fly);
      const noBowl = P && P.kind === 'pebble' && !this.enemies.some(e => e.alive && !e.fly);
      const hiding = !up.length;
      const light = this.A.light, beamLv = this.A.lanternLv('beam');
      const choice = await this.menu(`Wick  ♥ ${H.hp}/${H.maxHp}  ✿ ${s.hero.fp}/${s.hero.maxFp}  ✦ ${light}`, [
        { label: '👟 Jump', value: 'jump', disabled: hiding || glued,
          desc: glued ? "Wick's feet are glued to the floor! No jumping this turn. Try the hammer." : hiding ? "Everything is hiding in the lava! Defend, or use an item." : 'Jump on an enemy. Press SPACE right as you land to hit twice. Dead-on timing is a PERFECT: +1 damage!' },
        this.A.has('hammer') && { label: '🔨 Hammer', value: 'hammer', disabled: !ground, desc: ground ? "Hold SPACE, let go when the star lights up. Let go between the two marks for a PERFECT (+1)! Can't reach flyers." : hiding ? 'Everything is hiding in the lava!' : "Only flyers left: the hammer can't reach them." },
        team && { label: `🤝 ${team.name}`, right: `${tc} FP`, value: 'team', disabled: !P.alive || s.hero.fp < tc || noBowl,
          desc: !P.alive ? `${P.name} is knocked out.` : noBowl ? 'Only flyers left: nothing to bowl over!' : `Team Attack with ${P.name} (Bond ${P.bond}). ${team.desc} SPACE = Wick, X = ${P.name}!` },
        beamLv > 0 && { label: '✦ Lantern Beam', right: `${BEAM_COST} ✦`, value: 'beam', disabled: hiding || light < BEAM_COST,
          desc: hiding ? 'Everything is hiding in the lava!' : light < BEAM_COST ? `Needs ${BEAM_COST} ✦ Light (you have ${light}).`
            : `Pour ${BEAM_COST} ✦ Light into a beam that sweeps over EVERY enemy. It pierces armor and reaches flyers. Hold SPACE, let go at the ⭐.` },
        specials.length && { label: '✨ Special', value: 'special', desc: 'Badge moves that cost FP.' },
        { label: '🎒 Items', value: 'item', disabled: !items.length, desc: items.length ? 'Use an item.' : 'No items. Buy some in town!' },
        { label: '🛡️ Defend', value: 'defend', desc: 'Take 1 less damage until your next turn.' },
        { label: '🏃 Run', value: 'run', disabled: !!(this.opts.boss || this.opts.scripted), desc: this.opts.boss || this.opts.scripted ? "Can't run from this one!" : 'Try to escape.' },
      ].filter(Boolean));
      const done = await this.heroAction(choice);
      if (done !== false) return;
    }
  }

  async heroAction(choice) {
    const s = this.A.s;
    if (choice === 'jump') {
      const t = await this.pickTarget(() => true, 'Jump on');
      if (t === undefined) { this.say('Nothing to jump on right now!'); return false; }
      if (!t) return false;
      await this.heroJump(t, 1, false);
    } else if (choice === 'hammer') {
      const t = await this.pickTarget(e => !e.fly, 'Hammer');
      if (t === undefined) { this.say("Your hammer can't reach anyone right now!"); return false; }
      if (!t) return false;
      await this.heroHammer(t);
    } else if (choice === 'team') {
      return this.teamAttack();
    } else if (choice === 'beam') {
      if (!(await this.A.payLight(BEAM_COST))) { this.say('Not enough ✦ Light!'); return false; }
      await this.lanternBeam();
    } else if (choice === 'special') {
      const sp = this.heroSpecials();
      const id = await this.A.menu(this.menuEl, 'Special', sp.map(m => ({ label: `${m.name} (${m.fp} FP)`, value: m.id, disabled: s.hero.fp < m.fp, desc: m.desc })), { cancel: true, battle: true });
      if (!id) return false;
      if (id === 'power_jump') {
        const t = await this.pickTarget(() => true, 'Power Jump');
        if (!t) return false;
        s.hero.fp -= 2;
        await this.heroJump(t, 2, true);
      } else {
        s.hero.fp -= 2;
        await this.quakeHammer();
      }
    } else if (choice === 'item') {
      return this.useItem();
    } else if (choice === 'defend') {
      this.hero.status.defend = 1;
      this.say('Wick braces for impact!');
      await this.wait(0.7);
    } else if (choice === 'run') {
      const H = this.hero;
      this.say('Wick tries to run...');
      await this.anim(0.5, p => { H.x = H.hx - Math.sin(p * Math.PI * 6) * 6; });
      if (Math.random() < 0.6) {
        H.flip = -1;
        await this.moveTo(H, -80, 0.5);
        this.fled = true;
      } else {
        this.say("Couldn't get away!");
        H.x = H.hx;
        await this.wait(0.8);
      }
    }
    return true;
  }

  async heroJump(t, power, special) {
    const H = this.hero;
    this.focus((H.x + t.x) / 2, 320, 1.1);
    await this.moveTo(H, t.x - 90, 0.45);
    // crouch... and spring
    await this.anim(0.08, p => { H.sq = 1 - 0.25 * p; });
    H.state = 'jump';
    sfx('jump');
    const top = t.y - this.eh(t) * 0.92;
    let x0 = H.x, y0 = H.y, hits = 0;
    const max = special ? 1 : 2;
    for (let i = 0; i < max; i++) {
      const dur = i === 0 ? 0.55 : 0.48;
      const impact = this.now() + dur;
      this.arm(impact, 'press');
      const xa = x0, ya = y0;
      H.sq = 1.18;
      await this.anim(dur, p => { H.x = lerp(xa, t.x - 2, p); H.y = lerp(ya, top, p) - Math.sin(p * Math.PI) * (i ? 105 : 135); });
      H.sq = 0.78;
      t.sq = 0.7;
      const ok = await this.judge(impact);
      const ouch = this.ouch(t);
      if (ouch) {
        this.say(ouch === 'hot' ? 'Yowch! Way too hot to jump on!' : 'Ouch! Those spikes hurt!');
        this.damage(H, 1);
        break;
      }
      if (!t.alive) break;
      this.hit(t, power + (special && ok ? 1 : 0) + this.perfectBonus(), { by: 'hero', kind: 'jump' });
      hits++;
      if (ok) this.rate(hits);
      if (!ok || !t.alive || i === max - 1 || t.shell) break;
      x0 = H.x; y0 = H.y;
    }
    const xs = H.x, ys = H.y;
    this.unfocus();
    await this.anim(0.45, p => { H.x = lerp(xs, H.hx, p); H.y = lerp(ys, FLOOR, p) - Math.sin(p * Math.PI) * 70; });
    H.x = H.hx; H.y = FLOOR; H.state = 'idle'; H.flip = 1;
    H.sq = 0.8;
    this.dustAt(H.x);
    this.layout();
  }

  async heroHammer(t) {
    const H = this.hero;
    this.focus(t.x - 40, 330, 1.12);
    await this.moveTo(H, t.x - 78, 0.4);
    H.flip = 1;
    H.swing = 0;
    const res = await this.holdCommand(H);
    sfx('swish');
    await this.anim(0.13, p => { H.swing = p; });
    this.fx.push({ kind: 'ring', x: t.x - 24, y: FLOOR, t0: this.t });
    this.dustAt(t.x - 24);
    this.hit(t, (res === 'ok' ? 2 : 1) + this.perfectBonus(), { by: 'hero', kind: 'hammer', ...this.hotHammer() });
    if (res === 'ok') this.rate(1);
    await this.wait(0.3);
    H.swing = null;
    this.unfocus();
    await this.goHome(H);
    this.layout();
  }

  // ✦ Lantern Beam: a hold command, then a beam of Light sweeps over every enemy, left to right.
  async lanternBeam() {
    const H = this.hero;
    this.say('Lantern Beam! Hold SPACE, let go at the ⭐!', 99);
    const res = await this.holdCommand(H);
    this.msg = '';
    const power = 2 + (res === 'ok' ? 1 : 0) + this.perfectBonus() + (this.A.lanternLv('beam') >= 2 ? 1 : 0);
    if (res === 'ok') this.rate(1);
    sfx('flare');
    this.glory = 0.5;
    for (const e of this.enemies.filter(x => x.alive).sort((a, b) => a.x - b.x)) {
      this.beam = { t0: this.t, to: e, w: 0.45 };
      await this.wait(0.24);
      this.hit(e, power, { by: 'hero', kind: 'beam', pierce: true, reveal: true, ranged: true });
    }
    await this.wait(0.3);
    this.beam = null; this.glory = 0;
    this.layout();
  }

  async quakeHammer() {
    const H = this.hero;
    H.swing = 0;
    this.say('Quake Hammer!');
    const res = await this.holdCommand(H);
    await this.anim(0.13, p => { H.swing = p; });
    sfx('crunch');
    this.shake = 8;
    for (const e of this.enemies) if (e.alive && !e.fly) this.hit(e, (res === 'ok' ? 2 : 1) + this.perfectBonus(), { by: 'hero', kind: 'hammer', ...this.hotHammer() });
    if (res === 'ok') this.rate(1);
    await this.wait(0.4);
    H.swing = null;
    this.layout();
  }

  // ---------------------------------------------------------------- Team Attacks
  async teamAttack() {
    const P = this.partner;
    const cost = this.teamCost();
    const team = PARTNERS[P.kind].team;
    this.A.s.hero.fp -= cost;
    this.say(`${team.name}!  SPACE = Wick · X = ${P.name}`, 2.5);
    sfx('start');
    await this.wait(0.6);
    let r;
    if (P.kind === 'moss') r = await this.slimeSpring(P.bond);
    else if (P.kind === 'hoot') r = await this.owlExpress(P.bond);
    else if (P.kind === 'ember') r = await this.flameRally(P.bond);
    else if (P.kind === 'tick') r = await this.countdown(P.bond);
    else if (P.kind === 'doodle') r = await this.masterpiece(P.bond);
    else r = await this.boulderBowl(P.bond);
    if (r === false) { this.A.s.hero.fp += cost; return false; }
    for (const a of [this.hero, P]) { a.x = a.hx; a.y = FLOOR; a.state = 'idle'; a.flip = 1; a.curl = 0; a.sq = 1; }
    this.layout();
    return true;
  }

  async fizzle(text = 'The combo fizzled!') {
    this.float(text, 480, 200, '#ffb0a0');
    sfx('hurt');
    await this.wait(0.5);
  }

  async slimeSpring(lv) {
    const H = this.hero, P = this.partner;
    const t = await this.pickTarget(() => true, 'Slime Spring on');
    if (!t) return false;
    await this.moveTo(P, t.x - 150, 0.4);
    P.flip = 1;
    // Wick hops onto Moss
    const x0 = H.x;
    let ok = await this.beat(H, 'space', 0.5, p => { H.state = 'jump'; H.x = lerp(x0, P.x, p); H.y = lerp(FLOOR, FLOOR - 26, p) - Math.sin(p * Math.PI) * 120; });
    if (!ok) { await this.fizzle('Wick slipped off Moss!'); await this.goHome(P); return true; }
    // Moss squishes and launches
    ok = await this.beat(P, 'x', 0.32, p => { P.sq = 1 - 0.35 * p; H.y = FLOOR - 26 + 10 * p; });
    P.sq = 1.3;
    if (!ok) { await this.fizzle('Moss sneezed instead!'); return true; }
    sfx('jump');
    const stomps = 2 + lv;
    let top = -40;
    await this.anim(0.35, p => { H.x = lerp(P.x, t.x, p); H.y = lerp(FLOOR - 16, top, p); });
    for (let i = 0; i < stomps && t.alive; i++) {
      const last = i === stomps - 1;
      const yStart = H.y;
      ok = await this.beat(H, 'space', last ? 0.5 : 0.42, p => { H.y = lerp(yStart, t.y - this.eh(t), p * p); H.x = t.x - 2; });
      if (!ok) { this.hit(t, 1, { by: 'hero', kind: 'team' }); break; }
      this.hit(t, (last ? 3 : 1) + this.perfectBonus(), { by: 'hero', kind: 'team' });
      this.rate(i + 1);
      if (last || !t.alive) break;
      // bounce up while Moss scoots underneath to catch the next one
      const yb = H.y;
      ok = await this.beat(P, 'x', 0.4, p => { H.y = yb - Math.sin(p * Math.PI * 0.5) * 230; P.x = lerp(P.x, t.x - 60, 0.15); P.sq = 1 - 0.2 * Math.sin(p * Math.PI); });
      if (!ok) break;
      sfx('jump');
    }
    const xs = H.x, ys = H.y;
    await this.anim(0.5, p => { H.x = lerp(xs, H.hx, p); H.y = lerp(ys, FLOOR, p) - Math.sin(p * Math.PI) * 80; });
    await this.goHome(P);
    return true;
  }

  async owlExpress(lv) {
    const H = this.hero, P = this.partner;
    const x0 = P.x;
    let ok = await this.beat(P, 'x', 0.5, p => { P.state = 'jump'; P.x = lerp(x0, H.x, p); P.y = lerp(FLOOR, H.y - 66, p) - Math.sin(p * Math.PI) * 40; });
    if (!ok) { await this.fizzle('Hoot missed the grab!'); await this.goHome(P); return true; }
    sfx('jump');
    await this.anim(0.45, p => { H.y = lerp(FLOOR, FLOOR - 230, p); P.y = H.y - 66; H.x = P.x = lerp(H.hx, 420, p); });
    const passes = lv >= 3 ? 2 : 1;
    const dmg = lv >= 2 ? 2 : 1;
    let combo = 0;
    outer: for (let pass = 0; pass < passes; pass++) {
      const targets = this.enemies.filter(e => e.alive).sort((a, b) => a.x - b.x);
      for (const t of targets) {
        if (!t.alive) continue;
        const xa = H.x;
        await this.anim(0.22, p => { H.x = P.x = lerp(xa, t.x, p); H.y = FLOOR - 230; P.y = H.y - 66; });
        const yTop = H.y;
        ok = await this.beat(H, 'space', 0.34, p => { H.y = lerp(yTop, t.y - this.eh(t), p * p); });
        if (!ok) { this.hit(t, 1, { by: 'hero', kind: 'team' }); break outer; }
        this.hit(t, dmg + this.perfectBonus(), { by: 'hero', kind: 'team' });
        this.rate(++combo);
        const yb = H.y;
        ok = await this.beat(P, 'x', 0.34, p => { H.y = lerp(yb, FLOOR - 230, p); P.y = H.y - 66; });
        if (!ok) { await this.fizzle('Hoot lost his grip!'); break outer; }
      }
    }
    const xs = H.x, ys = H.y, pxs = P.x, pys = P.y;
    await this.anim(0.55, p => {
      H.x = lerp(xs, H.hx, p); H.y = lerp(ys, FLOOR, p) - Math.sin(p * Math.PI) * 50;
      P.x = lerp(pxs, P.hx, p); P.y = lerp(pys, FLOOR, p);
    });
    return true;
  }

  async boulderBowl(lv) {
    const H = this.hero, P = this.partner;
    const ground = () => this.enemies.filter(e => e.alive && !e.fly).sort((a, b) => a.x - b.x);
    if (!ground().length) { this.say('There are no ground enemies to bowl over!'); return false; }
    const x0 = P.x;
    let ok = await this.beat(P, 'x', 0.45, p => { P.x = lerp(x0, H.x + 48, p); P.curl = p; });
    if (!ok) { P.curl = 0; await this.fizzle("Pebble couldn't curl up!"); await this.goHome(P); return true; }
    H.swing = 0;
    const res = await this.holdCommand(H);
    await this.anim(0.12, p => { H.swing = p; });
    sfx('crunch');
    const power = 2 + (res === 'ok' ? 1 : 0) + this.perfectBonus() + (lv >= 3 ? 1 : 0);
    if (res === 'ok') this.rate(1);
    const hitSet = new Set();
    const xs = P.x;
    await this.anim(0.7, p => {
      P.x = lerp(xs, W + 60, p);
      P.roll = (P.roll || 0) + 0.4;
      for (const e of ground()) if (!hitSet.has(e) && P.x >= e.x - 10) { hitSet.add(e); this.hit(e, power, { by: 'partner', kind: 'team', pierce: true }); }
    });
    H.swing = null;
    if (lv >= 2 && ground().length) {
      ok = await this.beat(P, 'x', 0.35, p => { P.x = W + 60 - p * 30; });
      if (ok) {
        this.rate(2, P);
        const back = new Set();
        await this.anim(0.7, p => {
          P.x = lerp(W + 30, -60, p);
          P.roll = (P.roll || 0) - 0.4;
          for (const e of ground()) if (!back.has(e) && P.x <= e.x + 10) { back.add(e); this.hit(e, lv >= 4 ? 2 : 1, { by: 'partner', kind: 'team', pierce: true }); }
        });
      }
    }
    P.curl = 0;
    P.x = -60;
    await this.moveTo(P, P.hx, 0.4);
    return true;
  }

  // Wick and Ember bat a fireball back and forth (SPACE, X, SPACE...). It grows with every hit, speeds up,
  // then slams into one enemy. Higher Bond = a longer rally.
  async flameRally(lv) {
    const H = this.hero, P = this.partner;
    const t = await this.pickTarget(() => true, 'Flame Rally at');
    if (t === undefined) { this.say('Nothing to aim at right now!'); return false; }
    if (!t) return false;
    await Promise.all([this.moveTo(H, 400, 0.35), this.moveTo(P, 165, 0.35)]);
    H.flip = -1; P.flip = 1;
    const ball = { x: P.x + 18, y: P.y - 52, size: 0.6 };
    this.shots.push(ball);
    sfx('flare');
    const maxHits = 3 + lv;
    let hits = 0, perfects = 0, dur = 0.62, to = H, last = P;
    for (;;) {
      const key = to === H ? 'space' : 'x';
      const x0 = ball.x, y0 = ball.y, x1 = to.x + (to === H ? -20 : 20), y1 = to.y - 52;
      const ok = await this.beat(to, key, dur, p => { ball.x = lerp(x0, x1, p); ball.y = lerp(y0, y1, p) - Math.sin(p * Math.PI) * 60; });
      if (!ok) break;
      hits++;
      perfects += this.perfectBonus();
      last = to;
      ball.size = 0.6 + hits * 0.22;
      this.rate(hits, to);
      sfx('hit');
      if (to === H) { H.swing = 0; this.anim(0.12, p => { H.swing = p; }).then(() => { H.swing = null; }); } else P.sq = 0.75;
      if (hits >= maxHits) break;
      to = to === H ? P : H;
      dur = Math.max(0.32, dur - 0.05);
    }
    if (!hits) {
      this.shots.splice(this.shots.indexOf(ball), 1);
      await this.fizzle('Wick missed the fireball!');
    } else {
      // whoever hit it last sends it flying at the target
      this.float(hits >= maxHits ? 'MAX RALLY!' : `${hits}-hit rally!`, 300, 200, '#ffb347');
      const x0 = ball.x, y0 = ball.y, ty = t.y - this.eh(t) * 0.5;
      await this.anim(0.32, p => { ball.x = lerp(x0, t.x, p); ball.y = lerp(y0, ty, p) - Math.sin(p * Math.PI) * 30; });
      this.shots.splice(this.shots.indexOf(ball), 1);
      this.shake = 6 + hits;
      sfx('crunch');
      for (let i = 0; i < 18; i++) this.parts.push({ x: t.x, y: ty, vx: (Math.random() - 0.5) * 500, vy: -Math.random() * 400, life: 0.8, c: i % 2 ? '#ff8a3d' : '#ffe066' });
      this.hit(t, 1 + hits + perfects, { by: last === H ? 'hero' : 'partner', kind: 'team', fire: true, burn: true });
      await this.wait(0.4);
    }
    H.swing = null;
    await Promise.all([this.moveTo(H, H.hx, 0.35), this.moveTo(P, P.hx, 0.35)]);
    return true;
  }

  async useItem() {
    const s = this.A.s;
    const list = this.A.battleItems();
    const id = await this.A.menu(this.menuEl, 'Items', list.map(([k, n]) => ({ label: `${ITEMS[k].icon} ${ITEMS[k].name} ×${n}`, value: k, desc: ITEMS[k].desc, disabled: ITEMS[k].auto })), { cancel: true, battle: true });
    if (!id) return false;
    const it = ITEMS[id];
    let who = this.hero;
    if (it.hp && this.partner) {
      const pick = await this.A.menu(this.menuEl, 'Use on…', [
        { label: `Wick ♥ ${this.hero.hp}/${this.hero.maxHp}`, value: 'hero' },
        { label: `${this.partner.name} ♥ ${this.partner.hp}/${this.partner.maxHp}`, value: 'partner' },
      ], { cancel: true, battle: true });
      if (!pick) return false;
      who = pick === 'partner' ? this.partner : this.hero;
    }
    s.items[id]--;
    if (s.items[id] <= 0) delete s.items[id];
    sfx('coin');
    if (it.hp) {
      who.hp = Math.min(who.maxHp, who.hp + it.hp);
      if (who === this.partner && who.hp > 0) who.alive = true;
      this.float(`+${it.hp} ♥`, who.x, who.y - 100, '#ff9ab0');
    }
    if (it.fp) { s.hero.fp = Math.min(s.hero.maxFp, s.hero.fp + it.fp); this.float(`+${it.fp} ✿`, this.hero.x, this.hero.y - 120, '#9fe6ff'); }
    if (it.dmgAll) {
      this.say('Fire Seed! FWOOSH!');
      await this.wait(0.3);
      for (const e of this.enemies) if (e.alive) this.hit(e, it.dmgAll, { pierce: true, reveal: true, item: true, fire: true });
    }
    if (it.sleepAll) {
      this.say('Sleepy Dust! Everyone feels very... drowsy...');
      for (const e of this.enemies) if (e.alive) e.status.sleep = it.sleepAll;
    }
    await this.wait(0.8);
    this.layout();
    return true;
  }

  // ---------------------------------------------------------------- partner's turn
  async partnerTurn() {
    const P = this.partner, s = this.A.s;
    this.spot = P;
    this.unfocus();
    for (;;) {
      const def = PARTNERS[P.kind];
      const items = this.A.battleItems();
      const alive = this.enemies.filter(e => e.alive);
      const up = alive.filter(e => !(e.status.under > 0));
      const noTarget = m => (m.id === 'slam' && !up.some(e => !e.fly)) || (m.id === 'bounce' && !up.some(e => !this.spikyNow(e) && !this.hotNow(e)))
        || (['peck', 'toss', 'focus', 'ring', 'scribble', 'outline'].includes(m.id) && !up.length) || (m.id === 'rewind' && !this.canRewind());
      const why = m => (m.id === 'slam' ? "Pebble can't reach anyone right now." : m.id === 'bounce' ? 'Every enemy is spiky or too hot right now!'
        : m.id === 'rewind' ? "Nothing to rewind: nobody lost any HP on the enemies' last turn." : 'Nothing to aim at right now!');
      const opts = def.moves.map(m => ({ label: `${m.name}${m.fp ? ` (${m.fp} FP)` : ''}`, value: m.id, disabled: s.hero.fp < m.fp || noTarget(m),
        desc: noTarget(m) ? why(m) : m.desc }));
      opts.push({ label: '🎒 Items', value: 'item', disabled: !items.length, desc: 'Use an item.' });
      opts.push({ label: '🛡️ Defend', value: 'defend', desc: `${P.name} takes 1 less damage.` });
      const v = await this.menu(`${def.name}  ♥ ${P.hp}/${P.maxHp}  💛${P.bond}`, opts);
      const done = await this.partnerAction(v);
      if (done !== false) return;
    }
  }

  async partnerAction(v) {
    const P = this.partner, s = this.A.s;
    const cost = (PARTNERS[P.kind].moves.find(m => m.id === v) || {}).fp || 0;
    if (v === 'item') return this.useItem();
    if (v === 'defend') { P.status.defend = 1; this.say(`${P.name} braces!`); await this.wait(0.6); return true; }
    if (this.isTickMove(v)) return this.tickAction(v);
    if (this.isDoodleMove(v)) return this.doodleAction(v);
    if (v === 'bounce' || v === 'peck') {
      const t = await this.pickTarget(e => v === 'peck' || (!this.spikyNow(e) && !this.hotNow(e)), v === 'peck' ? 'Peck' : 'Bounce on');
      if (t === undefined) { this.say(v === 'peck' ? 'Nothing to peck right now!' : 'Moss would get poked (or toasted)!'); return false; }
      if (!t) return false;
      await this.partnerHits(P, t);
    } else if (v === 'toss') {
      const t = await this.pickTarget(() => true, 'Fire Toss');
      if (t === undefined) { this.say('Nothing to aim at right now!'); return false; }
      if (!t) return false;
      P.state = 'jump';
      const ok = await this.fireShot(P, t, 0.55, 0.8);
      P.state = 'idle';
      this.hit(t, 1 + this.perfectBonus(), { by: 'partner', fire: true, burn: ok });
      if (ok) this.rate(1, P);
      await this.wait(0.35);
    } else if (v === 'focus') {
      const t = await this.pickTarget(() => true, 'Focus Flame');
      if (t === undefined) { this.say('Nothing to aim at right now!'); return false; }
      if (!t) return false;
      s.hero.fp -= cost;
      this.say('Focus Flame! All the heat on ONE thing...', 2.2);
      const orb = { x: P.x + 8, y: P.y - 86, size: 0.35 };
      this.shots.push(orb);
      const res = await this.holdCommand(P, orb);
      const x0 = orb.x, y0 = orb.y, ty = t.y - this.eh(t) * 0.5;
      sfx('flare');
      await this.anim(0.3, p => { orb.x = lerp(x0, t.x, p); orb.y = lerp(y0, ty, p); });
      this.shots.splice(this.shots.indexOf(orb), 1);
      this.shake = res === 'ok' ? 8 : 3;
      this.hit(t, (res === 'ok' ? 4 : 2) + this.perfectBonus(), { by: 'partner', fire: true, pierce: true });
      if (res === 'ok') this.rate(1, P);
      await this.wait(0.35);
    } else if (v === 'wildfire') {
      s.hero.fp -= cost;
      const impact = this.now() + 0.55;
      this.arm(impact, 'press', 'space', P);
      this.say('Wildfire!');
      sfx('flare');
      await this.anim(0.55, p => { P.y = FLOOR - Math.sin(p * Math.PI) * 40; P.sq = 1 + Math.sin(p * Math.PI * 4) * 0.12; });
      P.sq = 1;
      const ok = await this.judge(impact);
      if (ok) this.rate(1, P);
      for (const e of [...this.enemies]) {
        if (!e.alive) continue;
        for (let i = 0; i < 8; i++) this.parts.push({ x: e.x, y: e.y - 10, vx: (Math.random() - 0.5) * 120, vy: -150 - Math.random() * 200, life: 0.7, c: i % 2 ? '#ff8a3d' : '#ffe066', g: 300 });
        this.hit(e, 1 + this.perfectBonus(), { by: 'partner', fire: true, burn: ok });
      }
      await this.wait(0.6);
    } else if (v === 'tattle') {
      const t = await this.pickTarget(() => true, 'Tattle on');
      if (!t) return false;
      t.tattled = true;
      this.A.noteTattle(t.kind);
      for (const e of this.enemies) if (e.kind === t.kind) e.tattled = true;
      if (t.status.invisible) { t.status.invisible = 0; this.say('Hoot spots her! No more hiding!'); }
      await this.A.say('Hoot', t.tattle);
    } else if (v === 'gloop' || v === 'gust') {
      s.hero.fp -= cost;
      const impact = this.now() + 0.5;
      this.arm(impact, 'press', 'space', P);
      this.say(v === 'gloop' ? 'Gloop Shot!' : 'Gust!');
      await this.anim(0.5, p => { P.y = FLOOR - Math.sin(p * Math.PI) * 30; });
      const ok = await this.judge(impact);
      if (ok) this.rate(1, P);
      for (const e of [...this.enemies]) {
        if (!e.alive) continue;
        this.hit(e, 1 + this.perfectBonus(), { by: 'partner', ranged: true });
        if (v === 'gloop' && e.alive && (ok || Math.random() < 0.5)) { e.status.stuck = 1; this.float('Stuck!', e.x, e.y - this.eh(e) - 30, '#8be07a'); }
        if (v === 'gust' && e.fly && e.alive) { e.fly = false; e.status.grounded = 2; e.baseY = FLOOR; e.y = FLOOR; this.float('Grounded!', e.x, e.y - 60, '#bfe6ff'); }
      }
      await this.wait(0.6);
    } else if (v === 'slam') {
      const t = await this.pickTarget(e => !e.fly, 'Rock Slam');
      if (t === undefined) { this.say("Pebble can't reach flyers!"); return false; }
      if (!t) return false;
      await this.moveTo(P, t.x - 85, 0.45);
      P.flip = 1;
      const res = await this.holdCommand(P);
      await this.anim(0.2, p => { P.x = lerp(t.x - 85, t.x - 35, p); });
      this.hit(t, (res === 'ok' ? 3 : 2) + this.perfectBonus(), { by: 'partner', pierce: true });
      if (res === 'ok') this.rate(1, P);
      await this.wait(0.25);
      await this.goHome(P);
    } else if (v === 'shield') {
      s.hero.fp -= cost;
      this.hero.status.shield = 1;
      this.say('Pebble shields Wick! No damage until your next turn.');
      await this.wait(0.9);
    }
    this.layout();
    return true;
  }

  async partnerHits(P, t) {
    await this.moveTo(P, t.x - 90, 0.45);
    const top = t.y - this.eh(t) * 0.9;
    let x0 = P.x, y0 = P.y;
    for (let i = 0; i < 2; i++) {
      const dur = i ? 0.45 : 0.5;
      const impact = this.now() + dur;
      this.arm(impact, 'press', 'space', P);
      const xa = x0, ya = y0;
      P.state = 'jump';
      await this.anim(dur, p => { P.x = lerp(xa, t.x - 4, p); P.y = lerp(ya, top, p) - Math.sin(p * Math.PI) * (i ? 90 : 120); });
      const ok = await this.judge(impact);
      if (!t.alive) break;
      this.hit(t, 1 + this.perfectBonus(), { by: 'partner' });
      if (ok) this.rate(i + 1, P);
      if (!ok || !t.alive || i === 1 || t.shell) break;
      x0 = P.x; y0 = P.y;
    }
    const xs = P.x, ys = P.y;
    await this.anim(0.45, p => { P.x = lerp(xs, P.hx, p); P.y = lerp(ys, FLOOR, p) - Math.sin(p * Math.PI) * 60; });
    P.x = P.hx; P.y = FLOOR; P.state = 'idle'; P.flip = 1;
  }

  // ---------------------------------------------------------------- enemies' turn
  pickVictim() {
    if (this.partner && this.partner.alive && Math.random() < 0.3) return this.partner;
    return this.hero;
  }

  async enemyPhase() {
    for (const e of [...this.enemies]) {
      if (!e.alive) continue;
      if (this.hero.hp <= 0) return;
      this.spot = e;
      if (e.status.sleep > 0) { e.status.sleep--; this.say(`${e.name} is snoozing...`); await this.wait(0.7); continue; }
      if (e.status.stuck > 0) { e.status.stuck--; this.say(`${e.name} is stuck in goo!`); await this.wait(0.7); continue; }
      if (e.status.dazed > 0) { e.status.dazed--; this.say(`${e.name} is too startled to move!`); await this.wait(0.7); continue; }
      if (e.shell && e.status.flipped > 0) { this.say(`${e.name} is stuck on its back, wiggling!`); await this.anim(0.6, p => { e.x = e.hx + Math.sin(p * 30) * 3; }); continue; }
      if (e.status.toppled > 0) {
        e.status.toppled--;
        this.say(e.status.toppled > 0 ? `${e.name} is flat on its back, clanking around!` : `${e.name} clatters back onto its feet!`);
        await this.anim(0.6, p => { e.x = e.hx + Math.sin(p * 30) * 3; });
        continue;
      }
      if (e.kind === 'sensei' || e.kind === 'sensei2') await this.sensei(e);
      else if (e.kind === 'rocco') await this.rocco(e);
      else if (e.kind === 'gloomknight') await this.gloomKnight(e);
      else if (e.kind === 'grumblecap') await this.grumblecap(e);
      else if (e.kind === 'smudge') await this.smudge(e);
      else if (e.kind === 'bramblebeast') await this.brambleBeast(e);
      else if (e.kind === 'cindermaw') await this.cindermaw(e);
      else if (e.kind === 'gluegolem') await this.glueGolem(e);
      else if (e.turn && this[e.turn]) await this[e.turn](e);   // Chapter 4's creatures and bosses (tower_play.js)
      else if (e.dives) await this.diveTurn(e);
      else if (e.kind === 'cinderling') await this.cinderTurn(e);
      else if (e.juggles) await this.juggleTurn(e);
      else if (e.smoke && !(this.hero.status.smoke > 0) && Math.random() < 0.45) await this.smokeTurn(e);
      else if (e.bomb) await this.bombTurn(e);
      else if (e.mirror) await this.mirrorTurn(e);
      else if (e.healer && await this.healTurn(e)) { /* healed someone */ }
      else if (e.thief) await this.thiefTurn(e);
      else if (e.splash && Math.random() < 0.35) {
        this.say(`${e.name} flings ink!`);
        const v = this.pickVictim();
        await this.attack(e, v, 1);
        if (v === this.hero) { this.hero.status.inked = 2; this.say('Wick got inked! Timing is harder for a bit.'); await this.wait(0.6); }
      } else {
        await this.attack(e, this.pickVictim(), e.atk + (e.status.atkUp > 0 ? 1 : 0), { drain: e.drain, burn: !!e.blazing });
      }
    }
  }

  // Magmaw: dives into its lava puddle (can't be hit), then either leaps out to bite or, from down there, makes the
  // floor under someone bubble... and ERUPT as a lava geyser (guard when it blows; the wait isn't always the same).
  async diveTurn(e) {
    if (!(e.status.under > 0)) {
      e.status.under = 1;
      this.say(`${e.name} ducks into its lava puddle!`, 1.6);
      sfx('jump');
      await this.wait(0.8);
      return;
    }
    if (Math.random() < 0.4) {
      e.status.under = 0;
      this.say(`${e.name} leaps out of the lava!`, 1.4);
      await this.attack(e, this.pickVictim(), e.atk);
      return;
    }
    const T = this.pickVictim();
    this.say(`The floor under ${T.name} starts to bubble... Guard when it blows!`, 2.2);
    const g = { x: T.x, k: 0, h: 0 };
    this.geysers.push(g);
    sfx('splash');
    const warn = 0.85 + Math.random() * 0.45;
    const impact = this.now() + warn;
    this.arm(impact, 'guard');
    await this.anim(warn, p => { g.k = p; });
    g.h = 1;
    sfx('boom');
    this.shake = 8;
    for (let i = 0; i < 12; i++) this.parts.push({ x: T.x + (Math.random() - 0.5) * 40, y: FLOOR - 60 - Math.random() * 160, vx: (Math.random() - 0.5) * 260, vy: -200 - Math.random() * 200, life: 0.8, c: i % 2 ? '#ff8a3d' : '#ffd166' });
    await this.resolveGuard(e, T, e.atk, impact, { noContact: true, burn: true });
    this.say('LAVA GEYSER!', 1.2);
    await this.anim(0.5, p => { g.h = 1 - p; g.k = 1 - p; });
    this.geysers.splice(this.geysers.indexOf(g), 1);
    // ...and up it pops, out of its puddle
    e.status.under = 0;
    sfx('jump');
    await this.anim(0.3, p => { e.y = e.baseY - Math.sin(p * Math.PI) * 30; });
    e.y = e.baseY;
  }

  // Cinderling: it spits embers, more of them the bigger it has grown, and once it's BLAZING it FLARES UP: a wave
  // of fire rolls along the floor through everyone (guard as it reaches each of you).
  async cinderTurn(e) {
    if (e.growth >= 2) return this.flareWave(e);
    if (Math.random() < 0.2) return this.attack(e, this.pickVictim(), e.atk);   // (a plain tackle now and then)
    const n = e.growth >= 1 ? 2 : 1;
    this.say(n > 1 ? `${e.name} spits two embers! Guard each one!` : `${e.name} spits an ember!`, 1.8);
    await this.anim(0.3, p => { e.sq = 1 - 0.22 * Math.sin(p * Math.PI); });   // (it puffs up first)
    e.sq = 1;
    for (let i = 0; i < n; i++) {
      if (this.hero.hp <= 0 || !e.alive) break;
      const T = this.pickVictim(), dur = 0.56 - i * 0.08;
      const impact = this.now() + dur;
      this.arm(impact, 'guard');
      const shot = { x: e.x - 14, y: e.y - this.eh(e) * 0.6, size: 0.85 };
      this.shots.push(shot);
      const x0 = shot.x, y0 = shot.y;
      sfx('flare');
      await this.anim(dur, p => { shot.x = lerp(x0, T.x, p); shot.y = lerp(y0, T.y - 45, p) - Math.sin(p * Math.PI) * 60; });
      this.shots.splice(this.shots.indexOf(shot), 1);
      await this.resolveGuard(e, T, 1, impact, { noContact: true });
      await this.wait(0.15);
    }
  }

  async flareWave(e) {
    this.say(`${e.name} FLARES UP! A wave of fire rolls along the floor! Guard as it reaches you!`, 2.4);
    sfx('flare');
    await this.anim(0.55, p => { e.sq = 1 + 0.25 * Math.sin(p * Math.PI); this.flash = Math.sin(p * Math.PI) * 0.2; });
    e.sq = 1;
    const wave = { x: e.x - 30, y: FLOOR + 4, size: 1.6, row: 4, fs: 4.4 };
    this.shots.push(wave);
    sfx('swish');
    let x = wave.x;
    // (it reaches whoever is nearest first)
    for (const T of [this.hero, this.partner].filter(a => a && a.alive).sort((a, b) => b.x - a.x)) {
      if (this.hero.hp <= 0) break;
      const dur = Math.max(0.28, (x - T.x) / 560), impact = this.now() + dur, xs = x;
      this.arm(impact, 'guard');
      await this.anim(dur, p => { wave.x = lerp(xs, T.x, p); });
      x = T.x;
      await this.resolveGuard(e, T, e.atk + 1, impact, { noContact: true, burn: true });
    }
    await this.anim(0.35, p => { wave.x = lerp(x, -60, p); wave.size = 1.6 * (1 - p * 0.8); wave.fs = 4.4 * (1 - p * 0.8); });
    this.shots.splice(this.shots.indexOf(wave), 1);
  }

  // Jugglit: throws three fireballs in a row. Guard all three and it gets dizzy.
  async juggleTurn(e) {
    if (e.status.dizzy > 0) {
      e.status.dizzy--;
      this.say(`${e.name} is too dizzy to juggle!`);
      await this.anim(0.7, p => { e.x = e.hx + Math.sin(p * 20) * 4; });
      e.x = e.hx;
      return;
    }
    this.say(`${e.name} throws EVERYTHING at once! Guard each one!`, 2);
    let blocked = 0, thrown = 0;
    for (let i = 0; i < 3; i++) {
      if (this.hero.hp <= 0 || !e.alive) break;
      const T = this.pickVictim();
      const dur = 0.62 - i * 0.08;
      const impact = this.now() + dur;
      this.arm(impact, 'guard');
      const shot = { x: e.x, y: e.y - this.eh(e) - 10, size: 0.7 };
      this.shots.push(shot);
      const x0 = shot.x, y0 = shot.y;
      sfx('flare');
      await this.anim(dur, p => { shot.x = lerp(x0, T.x, p); shot.y = lerp(y0, T.y - 50, p) - Math.sin(p * Math.PI) * 90; });
      this.shots.splice(this.shots.indexOf(shot), 1);
      const r = await this.resolveGuard(e, T, 1, impact, { noContact: true });
      thrown++;
      if (r === 'guard' || r === 'super' || r === 'miss') blocked++;
      await this.wait(0.12);
    }
    if (thrown === 3 && blocked === 3 && e.alive) {
      e.status.dizzy = 1;
      this.say(`${e.name} dropped everything! It's dizzy!`, 2);
      sfx('nice');
      await this.wait(0.8);
    }
  }

  // Ashcrow: soot in your face hides the timing cues for a while.
  async smokeTurn(e) {
    this.say(`${e.name} flaps a cloud of soot! You can't see the timing cues. Go by feel!`, 2.6);
    sfx('guard');
    for (let i = 0; i < 22; i++) this.parts.push({ x: this.hero.x + (Math.random() - 0.5) * 120, y: this.hero.y - 50 - Math.random() * 90, vx: (Math.random() - 0.5) * 60, vy: -20, life: 1.4, c: 'rgba(70,64,80,0.85)', g: 0 });
    this.hero.status.smoke = 2;
    await this.wait(1.1);
  }

  // Cindermaw tries to do every task at once: it piles up Cinderlings and hits harder for each one left standing.
  async cindermaw(e) {
    e.ai = e.ai || { n: 0, boiled: false };
    const n = ++e.ai.n;
    const tasks = this.enemies.filter(x => x.alive && !x.boss);
    if (e.hp <= e.maxHp / 2 && !e.ai.boiled) {
      e.ai.boiled = true;
      e.blazing = true;
      this.say('Cindermaw BOILS OVER! Now it is way too hot to jump on!', 2.8);
      this.shake = 10;
      sfx('crunch');
      await this.anim(1, p => { this.flash = (1 - p) * 0.8; e.x = e.hx + Math.sin(p * 50) * 5; });
      e.x = e.hx;
      return;
    }
    if (tasks.length >= 3) {
      const dmg = 1 + tasks.length;
      this.say(`OVERWHELM! ${tasks.length} unfinished tasks crash down on everyone! (${dmg} damage each)`, 2.8);
      await this.wait(0.6);
      for (const T of [this.hero, this.partner]) {
        if (!T || !T.alive || this.hero.hp <= 0) continue;
        const impact = this.now() + 0.75;
        this.arm(impact, 'guard');
        for (let i = 0; i < 14; i++) this.parts.push({ x: T.x + (Math.random() - 0.5) * 90, y: T.y - 260 - Math.random() * 60, vx: 0, vy: 330, life: 0.8, c: i % 2 ? '#ff8a3d' : '#5a3440', g: 0 });
        await this.wait(0.75);
        this.shake = 9;
        await this.resolveGuard(e, T, dmg, impact, { noContact: true, burn: true });
        await this.wait(0.3);
      }
      return;
    }
    if (n % 3 === 1 && tasks.length <= 1) {
      await this.summon(e, 'cinderling', 2, 'Cindermaw: MORE TASKS! ALL OF THEM! RIGHT NOW!');
      return;
    }
    if (n % 3 === 2) {
      this.say('Cindermaw: MAGMA RAIN! Guard every drop!', 2);
      const drops = e.ai.boiled ? 4 : 3;
      for (let i = 0; i < drops; i++) {
        if (this.hero.hp <= 0) break;
        const T = this.pickVictim();
        const dur = 0.56 - i * 0.04;
        const impact = this.now() + dur;
        this.arm(impact, 'guard');
        const rock = { x: T.x + (Math.random() - 0.5) * 30, y: -30, size: 1 };
        this.shots.push(rock);
        await this.anim(dur, p => { rock.y = lerp(-30, T.y - 40, p * p); });
        this.shots.splice(this.shots.indexOf(rock), 1);
        this.shake = 4;
        await this.resolveGuard(e, T, 1, impact, { noContact: true });
        await this.wait(0.1);
      }
      return;
    }
    this.say('Cindermaw: CHOMP!');
    await this.attack(e, this.pickVictim(), e.atk);
  }

  async attack(e, T, dmg, o = {}) {
    const y0 = e.y;
    const standX = T.x + (e.boss ? 120 : 82);
    this.spot = e;
    this.focus((e.x + T.x) / 2, 320, 1.06);
    await this.moveTo(e, standX, 0.45);
    e.flip = -1;
    // wind-up: lean back and squash... then dash
    await this.anim(0.24, p => { const s = Math.sin(p * Math.PI); e.y = y0 - s * 10; e.rot = -0.2 * s; e.sq = 1 - 0.14 * s; });
    e.rot = 0;
    const impact = this.now() + 0.3;
    this.arm(impact, 'guard');
    const hitY = e.fly ? T.y - 30 : y0;
    e.dash = true;
    sfx('swish');
    await this.anim(0.3, p => { e.x = lerp(standX, T.x + (e.boss ? 60 : 30), p * p); e.y = lerp(y0, hitY, p); });
    e.dash = false;
    const r = await this.resolveGuard(e, T, dmg, impact, o);
    await this.anim(0.35, p => { e.x = lerp(T.x + 30, e.hx, ease(p)); e.y = lerp(hitY, e.baseY, p); });
    e.x = e.hx; e.y = e.baseY; e.flip = -1;
    this.unfocus();
    return r;
  }

  async resolveGuard(e, T, dmg, impact, o = {}) {
    const p = this.firstPress();
    this.cue = null;
    if (T === this.hero && this.badge('lucky_star') && Math.random() < 0.15) { this.float('Lucky! Missed!', T.x, T.y - 110, '#ffe066'); return 'miss'; }
    const k = this.widen();
    const sg = !!p && p.key === 'space' && p.t >= impact - 0.085 * k && p.t <= impact + 0.035 * k;
    let g = !!p && p.key === 'space' && p.t >= impact - 0.2 * k && p.t <= impact + 0.06 * k;
    // a Straightedge's Strict Swing: "only PERFECT counts", so a normal guard does nothing
    if (o.strict && g && !sg) { g = false; this.float('Only PERFECT counts!', T.x, T.y - 120, '#ff9a8f'); }
    if (sg) {
      this.float('SUPERGUARD!', T.x, T.y - 120, '#9fe6ff');
      sfx('guard');
      this.impact(T.x + 30, T.y - 50);
      this.cheer();
      if (e && e.alive && !o.noContact) this.hit(e, this.badge('counter_strike') ? 2 : 1, { by: 'hero', ranged: true });
      return 'super';
    }
    let d = dmg;
    if (g) { d = Math.max(0, d - (this.badge('iron_guard') ? 2 : 1)); this.float('GUARD!', T.x, T.y - 120, '#bfe6ff'); sfx('guard'); }
    const dealt = this.damage(T, d, o);
    if (o.burn && dealt > 0) this.burnHero(T);
    if (o.drain && dealt > 0 && e) { e.hp = Math.min(e.maxHp, e.hp + 1); this.float('+1', e.x, e.y - this.eh(e) - 20, '#9cff8a'); }
    if (T === this.hero && dealt > 0 && e && e.alive && !o.noContact && this.badge('thorn_crown')) { this.float('Thorns!', e.x, e.y - 60, '#8be07a'); this.hit(e, 1, { by: 'thorns', pierce: true }); }
    return g ? 'guard' : dealt > 0 ? 'hit' : 'none';
  }

  async bombTurn(e) {
    e.fuse--;
    if (e.fuse > 0) {
      this.say(`${e.name}'s fuse is burning... ${e.fuse}!`, 1.6);
      sfx('tick');
      await this.anim(0.6, p => { e.x = e.hx + Math.sin(p * 40) * (4 - e.fuse); });
      e.x = e.hx;
      return;
    }
    this.say(`${e.name} EXPLODES!`, 2);
    sfx('crunch');
    this.shake = 12;
    for (let i = 0; i < 30; i++) this.parts.push({ x: e.x, y: e.y - 30, vx: (Math.random() - 0.5) * 800, vy: -Math.random() * 600, life: 0.9, c: i % 2 ? '#ff9a3d' : '#ffe066' });
    e.alive = false; e.dying = 1; e.exploded = true;
    for (const T of [this.hero, this.partner]) {
      if (!T || !T.alive || this.hero.hp <= 0) continue;
      const impact = this.now() + 0.45;
      this.arm(impact, 'guard');
      await this.wait(0.45);
      await this.resolveGuard(e, T, 4, impact, { noContact: true });
      await this.wait(0.2);
    }
    this.layout();
  }

  async mirrorTurn(e) {
    if (!(e.status.glow > 0)) {
      e.status.glow = 1;
      this.say(`${e.name}'s wings shimmer! Attacks will bounce right back.`, 2.2);
      sfx('guard');
      await this.wait(0.9);
      return;
    }
    e.status.glow = 0;
    await this.attack(e, this.pickVictim(), e.atk);
  }

  async healTurn(e) {
    const hurt = this.enemies.filter(x => x.alive && x !== e && x.hp < x.maxHp).sort((a, b) => a.hp / a.maxHp - b.hp / b.maxHp)[0];
    if (!hurt) return false;
    this.say(`${e.name} sprinkles healing light on ${hurt.name}!`);
    await this.anim(0.6, p => { e.y = e.baseY - Math.sin(p * Math.PI) * 20; });
    hurt.hp = Math.min(hurt.maxHp, hurt.hp + 2);
    this.float('+2', hurt.x, hurt.y - this.eh(hurt) - 20, '#9cff8a');
    sfx('chime');
    return true;
  }

  async thiefTurn(e) {
    if (e.loot) {
      e.fleeIn--;
      if (e.fleeIn <= 0) {
        this.say(`${e.name} ran off with your ${ITEMS[e.loot].name}!`, 2.4);
        e.fledWithLoot = true;
        e.flip = 1;
        await this.anim(0.7, p => { e.x = lerp(e.hx, W + 100, p); });
        e.alive = false;
        this.layout();
        return;
      }
      this.say(`${e.name} is getting ready to run! (${e.fleeIn} turn${e.fleeIn > 1 ? 's' : ''} left)`, 2);
      await this.attack(e, this.pickVictim(), e.atk);
      return;
    }
    const r = await this.attack(e, this.hero, e.atk);
    const stealable = Object.entries(this.A.s.items).filter(([k, n]) => n > 0 && ITEMS[k]);
    if (r !== 'super' && r !== 'guard' && stealable.length && e.alive) {
      const [id] = stealable[Math.floor(Math.random() * stealable.length)];
      this.A.s.items[id]--;
      e.loot = id;
      e.fleeIn = 2;
      this.say(`${e.name} swiped your ${ITEMS[id].name}! Beat it to get it back!`, 2.6);
      sfx('coin');
      await this.wait(0.8);
    }
  }

  // The Gloop Golem (the Sticker Shrine): Glue Spit sticks Wick's feet down, it drips Glue Drops, and goes runny at half HP.
  async glueGolem(e) {
    e.ai = e.ai || { n: 0, runny: false };
    const n = ++e.ai.n;
    if (e.hp <= e.maxHp / 2 && !e.ai.runny) {
      e.ai.runny = true;
      e.atk += 1;
      this.say('The Gloop Golem goes all runny! GLOOOOOP! (Its Attack went up!)', 2.4);
      sfx('poof');
      await this.anim(0.8, p => { e.x = e.hx + Math.sin(p * 40) * 4; });
      e.x = e.hx;
      return;
    }
    const drops = this.enemies.filter(x => x.alive && !x.boss).length;
    const step = n % 3;
    if (step === 1) {
      this.say('Gloop Golem: GLUE SPIT! (Guard it, or your feet get stuck!)', 2.2);
      const r = await this.attack(e, this.hero, e.atk);
      if ((r === 'hit' || r === 'none') && this.hero.hp > 0) {
        this.hero.status.stuck = 1;
        this.say("Wick's feet are glued to the floor! No jumping next turn. (The hammer still works!)", 2.6);
        await this.wait(0.9);
      }
      return;
    }
    if (step === 2 && drops < 2) { await this.summon(e, 'gluedrop', 2 - drops, 'Gloop Golem: DRIP... DRIP... GLUE DROPS, GET HIM!'); return; }
    this.say('Gloop Golem: BELLY BOUNCE!');
    await this.stomp(e, this.pickVictim(), e.atk + 1);
  }

  async summon(boss, kind, n, line) {
    this.say(line, 2);
    await this.wait(0.6);
    for (let i = 0; i < n; i++) { const m = this.addEnemy(kind); m.x = boss.x; }
    this.layout();
    await this.anim(0.5, p => { for (const m of this.enemies) if (m.alive && !m.boss) m.x = lerp(m.x, m.hx, p); });
  }

  async grumblecap(e) {
    e.ai = e.ai || { n: 0, yawned: false };
    const n = ++e.ai.n;
    const minions = this.enemies.filter(x => x.alive && !x.boss).length;
    if (e.hp <= 10 && !e.ai.yawned) {
      e.ai.yawned = true;
      this.say('King Grumblecap: Five... more... minutes... zzz', 2.4);
      e.status.sleep = 1;
      await this.wait(1.4);
      return;
    }
    if (n % 3 === 1 && minions < 2) { await this.summon(e, 'spikeshroom', minions ? 1 : 2, 'King Grumblecap: GUARDS! Do my job for me!'); return; }
    if (n % 4 === 3) {
      this.say('King Grumblecap: SPORE SNOOZE! Have a little nap...', 2.2);
      const T = this.hero;
      const impact = this.now() + 0.9;
      this.arm(impact, 'guard');
      for (let i = 0; i < 18; i++) this.parts.push({ x: T.x + (Math.random() - 0.5) * 90, y: T.y - 220 - Math.random() * 60, vx: 0, vy: 260, life: 0.9, c: '#e8d0ff', g: 0 });
      await this.wait(0.9);
      const r = await this.resolveGuard(e, T, 1, impact, { noContact: true });
      if (r === 'hit') this.sleepHero(T); else this.say('You shook off the spores!');
      await this.wait(0.7);
      return;
    }
    if (n % 5 === 0) {
      e.status.atkUp = 2;
      this.say('King Grumblecap grumbles loudly... his Attack went up!', 2);
      await this.anim(0.8, p => { e.x = e.hx + Math.sin(p * 40) * 4; });
      return;
    }
    this.say('King Grumblecap: ROYAL STOMP!');
    await this.stomp(e, this.pickVictim(), e.atk + (e.status.atkUp > 0 ? 1 : 0));
  }

  async stomp(e, T, dmg) {
    const x0 = e.x;
    this.spot = e;
    this.focus((e.x + T.x) / 2, 300, 1.04);
    await this.anim(0.12, p => { e.sq = 1 - 0.2 * p; });
    const impact = this.now() + 0.75;
    this.arm(impact, 'guard');
    e.sq = 1.15;
    await this.anim(0.75, p => { e.x = lerp(x0, T.x + 40, p); e.y = FLOOR - Math.sin(p * Math.PI) * 170; });
    this.shake = 8;
    e.sq = 0.75;
    this.dustAt(T.x + 40);
    this.fx.push({ kind: 'ring', x: T.x + 40, y: FLOOR, t0: this.t });
    sfx('crunch');
    await this.resolveGuard(e, T, dmg, impact);
    await this.anim(0.6, p => { e.x = lerp(T.x + 40, e.hx, p); e.y = FLOOR - Math.sin(p * Math.PI) * 80; });
    e.x = e.hx; e.y = FLOOR;
    this.unfocus();
  }

  // ---------------------------------------------------------------- mini-bosses
  // Sensei Strike (the dojo): a flurry you guard hit by hit, setting his own head on fire, and a counter stance.
  async sensei(e) {
    const two = e.kind === 'sensei2';
    e.ai = e.ai || { n: 0, healed: false };
    e.status.counter = 0;
    const n = ++e.ai.n;
    if (e.hp <= e.maxHp / 2 && !e.ai.healed) {
      e.ai.healed = true;
      const amt = two ? 6 : 4;
      e.hp = Math.min(e.maxHp, e.hp + amt);
      this.say(`Sensei Strike: Breathe in... SECOND WIND! (+${amt} HP)`, 2.2);
      this.float(`+${amt}`, e.x, e.y - this.eh(e) - 20, '#9cff8a');
      sfx('chime');
      await this.anim(0.8, p => { e.sq = 1 + Math.sin(p * Math.PI) * 0.12; });
      return;
    }
    if (two && n % 5 === 0) {
      this.say('Sensei Strike: WILDFIRE KATA! Guard it!', 2);
      e.status.lit = 2;
      for (const T of [this.hero, this.partner]) {
        if (!T || !T.alive || this.hero.hp <= 0) continue;
        const impact = this.now() + 0.6;
        this.arm(impact, 'guard');
        for (let i = 0; i < 10; i++) this.parts.push({ x: T.x + (Math.random() - 0.5) * 80, y: T.y - 10, vx: (Math.random() - 0.5) * 60, vy: -200 - Math.random() * 150, life: 0.7, c: i % 2 ? '#ff8a3d' : '#ffe066', g: 200 });
        await this.wait(0.6);
        await this.resolveGuard(e, T, 2, impact, { noContact: true, burn: true });
        await this.wait(0.2);
      }
      return;
    }
    const step = n % 4;
    if (step === 1) {
      const hits = two ? 4 : 3;
      this.say(`Sensei Strike: MATCHSTICK FLURRY! (${hits} hits: guard each one!)`, 2.2);
      const T = this.pickVictim();
      this.focus((e.x + T.x) / 2, 320, 1.08);
      await this.moveTo(e, T.x + 70, 0.35);
      e.flip = -1;
      for (let i = 0; i < hits && T.alive !== false && this.hero.hp > 0; i++) {
        const dur = 0.42 - i * 0.04;
        const impact = this.now() + dur;
        this.arm(impact, 'guard');
        e.dash = true;
        await this.anim(dur, p => { e.x = T.x + 70 - Math.sin(p * Math.PI * 0.5) * 32; e.rot = -0.25 * Math.sin(p * Math.PI); });
        e.dash = false; e.rot = 0;
        await this.resolveGuard(e, T, 1, impact, { burn: e.status.lit > 0 });
        await this.anim(0.08, p => { e.x = T.x + 38 + p * 32; });
      }
      this.unfocus();
      await this.goHome(e);
      return;
    }
    if (step === 2) {
      e.status.lit = 2;
      this.say("Sensei Strike strikes his own head... FWOOSH! He's ON FIRE! (Too hot to jump on, and his hits burn.)", 2.8);
      sfx('flare');
      for (let i = 0; i < 12; i++) this.parts.push({ x: e.x, y: e.y - this.eh(e), vx: (Math.random() - 0.5) * 200, vy: -100 - Math.random() * 200, life: 0.7, c: i % 2 ? '#ff8a3d' : '#ffe066', g: 300 });
      await this.wait(1.1);
      return;
    }
    if (step === 3) {
      e.status.counter = 1;
      this.say('Sensei Strike takes a COUNTER STANCE! Touch him and he hits back. (Defend, use an item, or throw fire!)', 3.2);
      sfx('guard');
      await this.wait(1.2);
      return;
    }
    this.say('Sensei Strike: IAI STRIKE!');
    await this.attack(e, this.pickVictim(), e.atk + 1, { burn: e.status.lit > 0 });
  }

  // Rocco (the Bandit Den): swipes your items, hides in smoke and calls his gang.
  async rocco(e) {
    e.ai = e.ai || { n: 0 };
    e.stash = e.stash || [];
    const n = ++e.ai.n;
    const gang = this.enemies.filter(x => x.alive && !x.boss).length;
    const step = n % 4;
    if (step === 1) {
      this.say("Rocco: SWIPE! Ooh, what's this?");
      const r = await this.attack(e, this.hero, e.atk);
      const stealable = Object.entries(this.A.s.items).filter(([k, c]) => c > 0 && ITEMS[k]);
      if (r !== 'super' && r !== 'guard' && stealable.length && e.alive) {
        const [id] = stealable[Math.floor(Math.random() * stealable.length)];
        this.A.s.items[id]--;
        e.stash.push(id);
        this.say(`Rocco swiped your ${ITEMS[id].name}! (Beat him to get it back.)`, 2.4);
        sfx('coin');
        await this.wait(0.8);
      }
      return;
    }
    if (step === 2 && gang < 2) { await this.summon(e, 'raccoon', 2 - gang, "Rocco: Sticky Paws Gang! GET 'EM!"); return; }
    if (step === 3 && !(e.status.invisible > 0)) {
      e.status.invisible = 2;
      this.say(this.partner && this.partner.kind === 'hoot' ? "Rocco throws a smoke bomb! (Hoot's Tattle can spot him.)" : 'Rocco throws a smoke bomb! Your attacks might miss.', 2.4);
      for (let i = 0; i < 24; i++) this.parts.push({ x: e.x + (Math.random() - 0.5) * 120, y: e.y - Math.random() * 120, vx: (Math.random() - 0.5) * 80, vy: -30, life: 1.2, c: 'rgba(200,196,210,0.85)', g: 0 });
      sfx('poof');
      await this.wait(1);
      return;
    }
    this.say('Rocco: BELLY FLOP!');
    await this.stomp(e, this.pickVictim(), e.atk + 1);
  }

  // The Gloom Knight (Old Lumen Castle): shield up, lance, and a wave that hits everyone. Hammers dent its armor.
  async gloomKnight(e) {
    e.ai = e.ai || { n: 0, called: false };
    e.status.guard = 0;
    const n = ++e.ai.n;
    if (e.hp <= e.maxHp / 2 && !e.ai.called) {
      e.ai.called = true;
      await this.summon(e, 'hollowarmor', 2, 'Gloom Knight: GUARDS! ...Hollow ones will do.');
      return;
    }
    const step = n % 3;
    if (step === 1) {
      e.status.guard = 1;
      this.say("Gloom Knight raises its shield: 'NOT IN THE MOOD.' Everything bounces off... except a HAMMER!", 2.8);
      sfx('guard');
      await this.wait(1.1);
      return;
    }
    if (step === 2) {
      this.say("Gloom Knight: LANCE OF 'LATER'! (Guard it!)", 2);
      await this.attack(e, this.pickVictim(), e.atk + 1);
      return;
    }
    this.say("Gloom Knight: WAVE OF 'WHY BOTHER'! It hits everyone!", 2.2);
    for (const T of [this.hero, this.partner]) {
      if (!T || !T.alive || this.hero.hp <= 0) continue;
      const impact = this.now() + 0.6;
      this.arm(impact, 'guard');
      for (let i = 0; i < 14; i++) this.parts.push({ x: e.x - (e.x - T.x) * Math.random(), y: T.y - 40 + (Math.random() - 0.5) * 60, vx: -260, vy: 0, life: 0.6, c: '#6a4a9a', g: 0 });
      await this.wait(0.6);
      await this.resolveGuard(e, T, 2, impact, { noContact: true });
      await this.wait(0.2);
    }
  }

  async brambleBeast(e) {
    e.ai = e.ai || { n: 0 };
    const n = ++e.ai.n;
    const minions = this.enemies.filter(x => x.alive && !x.boss).length;
    if (n % 3 === 1 && minions < 2) { await this.summon(e, 'thornback', 1, 'The Bramble Beast shakes loose a Thornback!'); return; }
    if (n % 4 === 2) {
      this.say('Vine Lash! Thorny vines whip at everyone!', 2);
      for (const T of [this.hero, this.partner]) {
        if (!T || !T.alive || this.hero.hp <= 0) continue;
        const impact = this.now() + 0.55;
        this.arm(impact, 'guard');
        await this.anim(0.55, p => { e.x = e.hx - Math.sin(p * Math.PI) * 30; });
        await this.resolveGuard(e, T, 2, impact, { noContact: true });
        await this.wait(0.25);
      }
      return;
    }
    this.say('The Bramble Beast tramples forward!');
    await this.stomp(e, this.pickVictim(), e.atk + 1);
  }

  async smudge(e) {
    e.ai = e.ai || { n: 0, perfect: false };
    const n = ++e.ai.n;
    const inks = this.enemies.filter(x => x.alive && x.kind === 'inkblot').length;
    if (e.hp <= 14 && !e.ai.perfect) {
      e.ai.perfect = true;
      e.atk += 1;
      this.say('Smudge: FINE. PERFECTION MODE! (Her Attack went up!)', 2.4);
      await this.anim(0.9, p => { this.flash = 1 - p; });
      return;
    }
    if (n % 5 === 2 && inks < 2) { await this.summon(e, 'inkblot', 2 - inks, 'Smudge: Rough drafts... ATTACK!'); return; }
    if (n % 3 === 0 && !(e.status.invisible > 0)) {
      e.status.invisible = 2;
      this.say(this.partner && this.partner.kind === 'hoot' ? 'Smudge vanishes into the ink! (Hoot can Tattle to spot her.)' : 'Smudge vanishes into the ink! Attacks might miss.', 2.6);
      await this.wait(1);
      return;
    }
    if (n % 4 === 1 && n > 1) {
      this.say('Smudge: INK RAIN!', 2);
      for (const T of [this.hero, this.partner]) {
        if (!T || !T.alive || this.hero.hp <= 0) continue;
        const impact = this.now() + 0.8;
        this.arm(impact, 'guard');
        for (let i = 0; i < 14; i++) this.parts.push({ x: T.x + (Math.random() - 0.5) * 80, y: T.y - 240 - Math.random() * 50, vx: 0, vy: 300, life: 0.85, c: '#1f1b33', g: 0 });
        await this.wait(0.8);
        await this.resolveGuard(e, T, 2, impact, { noContact: true });
        await this.wait(0.3);
      }
      return;
    }
    this.say('Smudge: Quill Jab!');
    await this.attack(e, this.pickVictim(), e.atk);
  }

  endRound() {
    for (const a of [this.hero, this.partner, ...this.enemies]) {
      if (!a) continue;
      for (const k of ['atkUp', 'invisible', 'inked', 'smoke', 'molten', 'lit', 'distracted', 'dazzled', 'alarmed', 'marked', 'outlined']) if (a.status[k] > 0) a.status[k]--;
      if (a.status.grounded > 0 && --a.status.grounded === 0 && a.flying) { a.fly = true; a.baseY = FLOOR - 105; a.y = a.baseY; }
      if (a.shell && a.status.flipped > 0 && --a.status.flipped === 0 && a.alive) this.float('Flipped back!', a.x, a.y - 60, '#ffb0a0');
      if (a.thorns && a.alive) a.status.spikes = !a.status.spikes;
      // fire ticks
      if (a.status.burn > 0) {
        a.status.burn--;
        const foe = this.enemies.includes(a);
        if (foe && a.alive) {
          a.hp = Math.max(0, a.hp - 1);
          this.burst(a.x, a.y - this.eh(a) - 12, 1);
          a.hurtT = 0.3;
          if (a.hp <= 0) this.kill(a);
        } else if (!foe && a.alive !== false && a.hp > 0) this.damage(a, 1, { pure: true });
      }
      // ignored Cinderlings grow (the turn after they show up)
      if (a.grows && a.alive && a.growth < 2 && this.round > a.born) {
        a.growth++;
        a.atk++; a.hp++; a.maxHp++;
        a.scale = 1 + 0.22 * a.growth;
        if (a.growth >= 2) a.blazing = true;
        this.float(a.growth >= 2 ? 'BLAZING! Too hot to jump on!' : 'It GREW!', a.x, a.y - this.eh(a) - 26, '#ffb347');
      }
    }
    if (this.badge('happy_heart') && this.hero.hp > 0 && this.hero.hp < this.hero.maxHp) { this.hero.hp++; this.float('+1 ♥', this.hero.x, this.hero.y - 100, '#ff9ab0'); }
    const s = this.A.s;
    if (this.badge('first_light') && s.hero.fp < s.hero.maxFp) { s.hero.fp++; this.float('+1 ✿', this.hero.x + 30, this.hero.y - 120, '#9fe6ff'); }
  }

  // ---------------------------------------------------------------- per-frame
  update(dt) {
    this.frameAt = performance.now();
    if (this.stop > 0) { this.stop -= dt; return; }
    this.t += dt;
    for (const a of [...this.anims]) {
      const p = Math.min(1, (this.t - a.t0) / a.dur);
      a.fn(p);
      if (p >= 1) { this.anims.splice(this.anims.indexOf(a), 1); a.r(); }
    }
    for (const tm of [...this.timers]) if (this.t >= tm.at) { this.timers.splice(this.timers.indexOf(tm), 1); tm.r(); }
    if (this.hold) {
      const h = this.hold, down = this.A.isDown('jump');
      if (!h.started) {
        if (down && this.lastDown >= h.since) h.started = true;
        else if (this.t - h.since > 3.5) { this.hold = null; this.lastGrade = 'none'; h.resolve('none'); }
      } else if (down) {
        h.fill += dt / 0.9;
        if (h.orb) h.orb.size = 0.35 + Math.min(1.3, h.fill) * 0.85;
        if (h.fill > 1.3) { this.hold = null; this.lastGrade = 'late'; h.resolve('over'); this.float('Too long!', h.actor.x, h.actor.y - 120, '#ffb0a0'); }
      } else {
        this.hold = null;
        const w = this.widen();
        const lo = (this.bleary() ? 0.9 : 0.82) - (w - 1) * 0.2, hi = 1.14 + (w - 1) * 0.1;
        this.lastGrade = h.fill < lo ? 'early' : h.fill > hi ? 'late' : Math.abs(h.fill - 1) <= this.perfectFill() ? 'perfect' : 'good';
        if (h.fill < lo || h.fill > hi) this.missed(h.fill < lo ? 'Too early!' : 'Too late!', h.actor);
        h.resolve(h.fill >= lo && h.fill <= hi ? 'ok' : 'early');
      }
    }
    for (const a of [this.hero, this.partner, ...this.enemies]) {
      if (!a) continue;
      if (a.hurtT > 0) a.hurtT -= dt;
      if (a.state === 'walk') a.phase += dt * 2.2;
      if (a.dying > 0) a.dying = Math.max(0, a.dying - dt * 1.4);
      if (a.sq && a.sq !== 1) a.sq += (1 - a.sq) * Math.min(1, dt * 10);
      if (a.kb > 0) a.kb = Math.max(0, a.kb - dt * 5);
    }
    for (const p of this.parts) { p.x += p.vx * dt; p.y += p.vy * dt; p.vy += (p.g ?? 600) * dt; p.life -= dt; if (p.vr) p.rot += p.vr * dt; }
    this.parts = this.parts.filter(p => p.life > 0);
    this.floaters = this.floaters.filter(f => this.t - f.t0 < 1.1);
    this.fx = this.fx.filter(f => this.t - f.t0 < 0.7);
    if (this.shake) this.shake = Math.max(0, this.shake - dt * 30);
    if (this.flash) this.flash = Math.max(0, this.flash - dt);
    // the camera glides toward whatever it was told to look at
    const k = Math.min(1, dt * 4.5), C = this.cam, T = this.camT;
    C.x += (T.x - C.x) * k; C.y += (T.y - C.y) * k; C.z += (T.z - C.z) * k;
    this.punch = Math.max(0, this.punch - dt * 0.5);
  }

  draw(c, t) {
    const cam = this.cam, z = cam.z + this.punch;
    c.save();
    if (this.shake) c.translate((Math.random() - 0.5) * this.shake, (Math.random() - 0.5) * this.shake);
    // the scenery behind the stage drifts a little with the camera
    c.save();
    const zb = 1.08 + (z - 1) * 0.4;
    c.translate(480, 270); c.scale(zb, zb); c.translate(-480 - (cam.x - 480) * 0.25, -270 - (cam.y - 270) * 0.25);
    const R = this.A.room, freed = R && R.faded ? this.A.marginColored(R) : this.A.flag('ch4_done');
    if (!drawBackdrop2(c, this.theme, 400, W, H, t, { freed })) drawBackdrop(c, this.theme, 400, W, H, t, { lit: this.A.s.shards + 1, bright: true, calm: this.A.flag('ch3_done') });
    c.restore();
    // the stage and everyone on it, through the camera
    c.save();
    c.translate(480, 270); c.scale(z, z); c.translate(-cam.x, -cam.y);
    drawStage(c, t, { floor: FLOOR });
    if (this.spot && this.spot.alive !== false && !this.results) drawSpotlight(c, this.spot.x, FLOOR, 1);
    for (const f of this.fx) {
      if (f.kind !== 'ring') continue;
      const k = (this.t - f.t0) / 0.5;
      if (k > 1) continue;
      c.strokeStyle = `rgba(255,250,240,${1 - k})`; c.lineWidth = 4 * (1 - k) + 1;
      c.beginPath(); c.ellipse(f.x, f.y, 20 + k * 90, 6 + k * 22, 0, 0, Math.PI * 2); c.stroke();
    }
    const actors = [this.partner, this.hero, ...this.enemies].filter(a => a && (a.alive || a.dying > 0 || a === this.hero || a === this.partner));
    for (const a of actors) this.drawActor(c, a, t);
    for (const s of this.shots) {
      glowDot(c, s.row ? s.x + 40 : s.x, s.row ? s.y - 30 : s.y, 34 * s.size + 10, '255,160,70', 0.6);
      if (s.row) for (let i = s.row - 1; i >= 0; i--) flame(c, s.x + i * 30, s.y, s.fs * (1 - i * 0.16), t * 1.5 + i * 1.7);   // a wave of fire
      else flame(c, s.x, s.y + 9 * s.size, s.size, t * 1.5);
    }
    // a Magmaw's lava geyser: the floor bubbles (k), then a column of lava shoots up (h)
    for (const g of this.geysers || []) {
      const r = 22 + g.k * 18;
      c.fillStyle = '#e0441e'; c.strokeStyle = INK; c.lineWidth = 2;
      c.beginPath(); c.ellipse(g.x, FLOOR + 4, r, r * 0.3, 0, 0, Math.PI * 2); c.fill(); c.stroke();
      c.fillStyle = '#ff9a3d'; c.beginPath(); c.ellipse(g.x, FLOOR + 3, r * 0.7, r * 0.18, 0, 0, Math.PI * 2); c.fill();
      for (let i = 0; i < 4; i++) {
        const a = t * 7 + i * 1.9, bx = g.x + Math.cos(i * 2.4 + t) * r * 0.55, by = FLOOR + 2 - Math.abs(Math.sin(a)) * 12 * g.k;
        c.fillStyle = '#ffd166'; c.beginPath(); c.arc(bx, by, 2.5 + 2.5 * g.k, 0, Math.PI * 2); c.fill();
      }
      if (g.h > 0) {
        const top = FLOOR - 250 * g.h, wob = Math.sin(t * 30) * 4;
        glowDot(c, g.x, FLOOR - 110 * g.h, 120, '255,140,60', 0.5 * g.h);
        const lg = c.createLinearGradient(0, top, 0, FLOOR);
        lg.addColorStop(0, '#ffe066'); lg.addColorStop(0.45, '#ff9a3d'); lg.addColorStop(1, '#e0441e');
        c.fillStyle = lg; c.strokeStyle = INK; c.lineWidth = 2.5;
        c.beginPath(); c.moveTo(g.x - 22, FLOOR + 2);
        c.quadraticCurveTo(g.x - 34 + wob, top + 50, g.x, top); c.quadraticCurveTo(g.x + 34 - wob, top + 50, g.x + 22, FLOOR + 2);
        c.closePath(); c.fill(); c.stroke();
      }
    }
    this.drawExtras(c, t);
    this.drawMarginExtras(c, t);
    for (const f of this.fx) {
      const k = (this.t - f.t0) / (f.kind === 'poof' ? 0.6 : 0.3);
      if (k > 1) continue;
      if (f.kind === 'impact') drawImpact(c, f.x, f.y, k, f.big);
      else if (f.kind === 'poof') drawPoof(c, f.x, f.y, k);
      else if (f.kind === 'perfect') drawPerfectBurst(c, f.x, f.y, k);
    }
    if (this.target) {
      const e = this.target.list[this.target.i];
      const y = e.y - this.eh(e) - 34 + Math.sin(t * 8) * 6;
      c.fillStyle = '#ffe066'; c.strokeStyle = INK; c.lineWidth = 2.5;
      c.beginPath(); c.moveTo(e.x - 14, y - 18); c.lineTo(e.x + 14, y - 18); c.lineTo(e.x, y); c.closePath(); c.fill(); c.stroke();
      const note = e.status.glow > 0 ? ' (shimmering!)' : e.status.guard > 0 ? ' (shield up: hammer it!)' : e.status.counter > 0 ? ' (counter stance!)'
        : this.spikyNow(e) ? ' (spiky!)' : this.hotNow(e) ? ' (too hot to jump on!)' : e.status.toppled > 0 ? ' (toppled: wide open!)'
          : (e.armor && !(e.status.molten > 0)) || (e.knight && e.def) ? ' (armored)' : '';
      this.label(c, e.name + note, e.x, y - 34);
    } else if ((this.spot === this.hero || this.spot === this.partner) && this.menuEl && this.menuEl.innerHTML && !this.results) {
      // whose turn it is
      const a = this.spot, y = a.y - (a === this.hero ? 104 : 84) - Math.abs(Math.sin(t * 5)) * 8;
      c.fillStyle = '#ffe066'; c.strokeStyle = INK; c.lineWidth = 2.5;
      c.beginPath(); c.moveTo(a.x - 11, y - 14); c.lineTo(a.x + 11, y - 14); c.lineTo(a.x, y); c.closePath(); c.fill(); c.stroke();
    }
    if (this.cue) this.drawCue(c);
    if (this.hold) {
      const a = this.hold.actor, f = Math.min(1.3, this.hold.fill);
      const x = a.x - 50, y = a.y - 140;
      c.fillStyle = PAPER; c.strokeStyle = INK; c.lineWidth = 3;
      c.beginPath(); rrect(x, y, 100, 16, 8)(c); c.fill(); c.stroke();
      c.fillStyle = f > 1.14 ? '#e5534b' : '#ffb84a'; c.beginPath(); rrect(x + 3, y + 3, Math.min(94, 94 * (f / 1.14)), 10, 5)(c); c.fill();
      // the PERFECT notch: let go while the fill is between these two marks
      const pf = this.perfectFill(), n0 = x + 3 + 94 * ((1 - pf) / 1.14), n1 = x + 3 + 94 * ((1 + pf) / 1.14);
      const ready = f >= 0.82 && f <= 1.14, sweet = Math.abs(f - 1) <= pf;
      c.fillStyle = sweet ? 'rgba(255,255,255,0.75)' : 'rgba(255,240,170,0.45)'; c.fillRect(n0, y + 3, n1 - n0, 10);
      c.lineWidth = 2.5;
      for (const nx of [n0, n1]) { c.beginPath(); c.moveTo(nx, y - 3); c.lineTo(nx, y + 19); c.stroke(); }
      c.lineWidth = 3;
      c.beginPath(); starPath(c, x + 112, y + 8, sweet ? 19 : ready ? 15 : 10, sweet ? 9 : ready ? 7 : 4.5); c.fillStyle = sweet ? '#fffbe0' : ready ? '#ffe066' : '#777'; c.fill(); c.stroke();
      if (ready) glowDot(c, x + 112, y + 8, sweet ? 46 : 30, '255,230,120', sweet ? 0.95 : 0.7);
      c.font = 'bold 13px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#fffaf0';
      c.fillText(this.hold.started ? 'let go at the ⭐!' : 'HOLD SPACE', a.x, y - 8);
      // the hammer head glints while you hold
      if (this.hold.started && a === this.hero) glowDot(c, a.x + 18, a.y - 70, 18 + f * 14, '255,250,220', 0.4 + f * 0.3);
    }
    for (const p of this.parts) {
      c.globalAlpha = Math.max(0, Math.min(1, p.life * 2));
      if (p.paper) {
        c.save(); c.translate(p.x, p.y); c.rotate(p.rot); c.scale(Math.cos(p.rot * 1.7), 1);
        c.fillStyle = p.c; c.fillRect(-5, -3, 10, 6); c.restore();
        continue;
      }
      if (p.puff) {
        c.fillStyle = `rgba(255,250,240,${Math.max(0, Math.min(1, p.life * 1.6))})`;
        c.beginPath(); c.arc(p.x, p.y, p.r * (1.5 - p.life), 0, Math.PI * 2); c.fill();
        continue;
      }
      c.fillStyle = p.c;
      c.beginPath();
      if (p.star) starPath(c, p.x, p.y, 9, 4, 4);
      else if (p.coin) c.ellipse(p.x, p.y, 6 * Math.abs(Math.cos(p.life * 12)) + 1, 6, 0, 0, Math.PI * 2);
      else c.arc(p.x, p.y, 4, 0, Math.PI * 2);
      c.fill();
    }
    c.globalAlpha = 1;
    for (const f of this.floaters) {
      const age = this.t - f.t0;
      if (f.type === 'burst') {
        const sc = age < 0.15 ? age / 0.15 * 1.3 : age < 0.25 ? 1.3 - (age - 0.15) * 3 : 1;
        c.save(); c.translate(f.x, f.y - age * 20); c.scale(sc, sc); c.rotate(Math.sin(age * 20) * 0.08 * Math.max(0, 1 - age * 3));
        c.globalAlpha = age > 0.85 ? Math.max(0, 1 - (age - 0.85) * 4) : 1;
        c.beginPath(); starPath(c, 0, 0, 26, 17, 10, 0);
        c.fillStyle = f.hurt ? '#ff6b6b' : '#ffd23f'; c.fill(); c.lineWidth = 3; c.strokeStyle = INK; c.stroke();
        c.font = 'bold 22px Fredoka, sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
        c.lineWidth = 4; c.strokeStyle = INK; c.strokeText(String(f.n), 0, 1); c.fillStyle = '#fff'; c.fillText(String(f.n), 0, 1);
        c.restore();
      } else {
        c.save(); c.globalAlpha = Math.max(0, 1 - age);
        const pop = age < 0.12 ? 0.6 + age / 0.12 * 0.5 : 1.1 - Math.min(0.1, (age - 0.12));
        c.translate(f.x, f.y - age * 30); c.scale(pop, pop);
        if (f.big) glowDot(c, 0, -9, 70, '255,230,120', 0.55);
        c.font = `bold ${f.big ? 32 : 24}px Fredoka, sans-serif`; c.textAlign = 'center';
        c.lineWidth = 5; c.strokeStyle = INK; c.strokeText(f.text, 0, 0);
        c.fillStyle = f.color; c.fillText(f.text, 0, 0);
        c.restore();
      }
    }
    c.restore();
    // in front of the stage: the audience, then the curtains
    drawAudience(c, t, this.crowd, this.cheerT, this.gaspT);
    drawCurtains(c, this.curtain, t);
    this.hud(c);
    if (this.msg && this.t < this.msgUntil) this.banner(c, this.msg);
    this.drawResults(c, t);
    if (this.flash) { c.fillStyle = `rgba(255,255,255,${this.flash * 0.6})`; c.fillRect(0, 0, W, H); }
    if (this.t < 0.45) {
      const p = this.t / 0.45;
      c.fillStyle = '#0c0818';
      c.beginPath(); c.rect(0, 0, W, H); c.arc(W / 2, H / 2, Math.max(1, p * 650), 0, Math.PI * 2, true); c.fill('evenodd');
    }
    c.restore();
  }

  // The victory card: XP and coins count up while the fanfare plays.
  drawResults(c, t) {
    const r = this.results;
    if (!r) return;
    const age = this.t - r.t0, k = clamp(age / 0.3, 0, 1);
    const pop = k < 1 ? 0.6 + 0.4 * ease(k) + Math.sin(k * Math.PI) * 0.12 : 1;
    c.save(); c.translate(480, 178); c.scale(pop, pop); c.globalAlpha = k;
    paper(c, p => shape(c, p, rrect(-200, -86, 400, 176, 18), PAPER));
    c.font = 'bold 38px Fredoka, sans-serif'; c.textAlign = 'center'; c.lineWidth = 7; c.strokeStyle = INK; c.lineJoin = 'round';
    c.strokeText('VICTORY!', 0, -38); c.fillStyle = '#ffd23f'; c.fillText('VICTORY!', 0, -38);
    for (const sx of [-140, 140]) {
      c.save(); c.translate(sx, -50); c.rotate(t * 2 * Math.sign(sx));
      c.beginPath(); starPath(c, 0, 0, 15, 6.5); c.fillStyle = '#ffe066'; c.fill(); c.lineWidth = 2.5; c.strokeStyle = INK; c.stroke();
      c.restore();
    }
    const q = clamp((age - 0.3) / 0.8, 0, 1);
    c.font = 'bold 21px Fredoka, sans-serif'; c.fillStyle = INK;
    c.textAlign = 'left'; c.fillText(`XP  +${Math.round(r.xp * q)}`, -160, 6);
    c.textAlign = 'right'; c.fillText(`🪙  +${Math.round(r.coins * q)}`, 160, 6);
    const to = r.from + r.xp * q;
    c.fillStyle = 'rgba(43,34,53,0.15)'; c.beginPath(); rrect(-160, 22, 320, 18, 9)(c); c.fill();
    c.fillStyle = '#7fd18b'; c.beginPath(); rrect(-160, 22, Math.max(18, 320 * Math.min(1, to / 100)), 18, 9)(c); c.fill();
    c.strokeStyle = INK; c.lineWidth = 2; c.beginPath(); rrect(-160, 22, 320, 18, 9)(c); c.stroke();
    c.font = 'bold 13px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillStyle = INK;
    c.fillText(to >= 100 ? `⬆ LEVEL UP! (Lv ${r.lvl + 1})` : `${Math.floor(to)} / 100 XP to Lv ${r.lvl + 1}`, 0, 36);
    if (age > 0.9) {
      c.globalAlpha = k * (0.55 + 0.45 * Math.sin(t * 5));
      c.font = '15px Fredoka, sans-serif'; c.fillStyle = '#6b5a8a'; c.fillText('SPACE to continue', 0, 72);
    }
    c.restore();
  }

  drawCue(c) {
    const cue = this.cue;
    const team = cue.type === 'team';
    if (this.hero.status.smoke > 0 || this.hero.status.dazzled > 0) return;
    if (!team && !this.tutor()) return;
    const who = team ? cue.actor : this.hero;
    if (!who) return;
    const until = cue.at - this.now();
    const k = this.widen();
    const lit = (team ? this.tutor() : true) && until <= (cue.type === 'guard' ? 0.2 : 0.16) * k && until > -0.08 * k;
    // the PERFECT instant flashes white (attacks only: guards have their own Superguard)
    const dead = lit && cue.type !== 'guard' && Math.abs(until) <= PERFECT * this.perfK();
    const x = who.x, y = who.y - (who === this.hero ? 150 : 120);
    const keyName = cue.key === 'x' ? 'X' : 'SPACE';
    const col = cue.key === 'x' ? (PARTNERS[this.partner ? this.partner.kind : 'moss'] || {}).color || '#6cc04a' : '#4f72bf';
    if (lit) glowDot(c, x, y, dead ? 62 : 44, '255,230,120', dead ? 1 : 0.8);
    c.font = 'bold 16px Fredoka, sans-serif'; c.textAlign = 'center';
    const w = c.measureText(keyName).width + 22;
    c.fillStyle = dead ? '#fffbe0' : lit ? '#ffe066' : col; c.strokeStyle = INK; c.lineWidth = 3;
    c.beginPath(); rrect(x - w / 2, y - 16, w, 30, 9)(c); c.fill(); c.stroke();
    c.fillStyle = lit ? INK : '#fffaf0'; c.fillText(keyName, x, y + 5);
    if (cue.type === 'guard') { c.font = 'bold 12px Fredoka, sans-serif'; c.fillStyle = '#fffaf0'; c.fillText('GUARD', x, y + 30); }
  }

  drawActor(c, a, t) {
    const fn = DRAW[a.kind];
    if (!fn) return;
    const hurt = a.hurtT > 0;
    let mood = hurt ? 'hurt' : a.status && a.status.sleep > 0 ? 'sleep' : a.mood || (a === this.hero || a === this.partner ? 'determined' : 'angry');
    if (a === this.partner && !a.alive) mood = 'hurt';
    const foe = this.enemies.includes(a);
    const x = a.x + (hurt ? Math.sin(t * 70) * 3 : 0) + (a.kb || 0) * 16 * (foe ? 1 : -1);
    const bob = a.fly ? Math.sin(t * 3 + a.hx) * 6 : 0;
    if (a.dash) drawSpeedLines(c, x, a.y + bob, a.flip || -1, 1);
    if (a.dying > 0 && !a.alive) {
      if (a.fledWithLoot) return;
      const k = 1 - a.dying;
      c.save();
      c.globalAlpha = Math.min(1, a.dying * 1.5);
      c.translate(x, a.y - k * 90);
      c.scale(Math.max(0.02, Math.cos(k * Math.PI / 2)), 1);
      c.rotate(k * 0.6);
      fn(c, 0, 0, { t, flip: a.flip, scale: (a.scale || 1) * (a.small ? 0.72 : 1), mood: 'hurt', shadow: false, small: false, flipped: a.status.flipped > 0 });
      c.restore();
      return;
    }
    c.save();
    if (a === this.partner && !a.alive) c.globalAlpha = 0.5;
    if (a.curl > 0.5) {
      this.drawCurl(c, x, a.y, a.roll || 0, t);
    } else {
      if (a.rot) { c.translate(x, a.y); c.rotate(a.rot * -(a.flip || 1)); c.translate(-x, -a.y); }
      if (a.sq && a.sq !== 1) { c.translate(x, a.y); c.scale(2 - a.sq, a.sq); c.translate(-x, -a.y); }
      const st = a.status || {};
      fn(c, x, a.y + bob, {
        t, flip: a.flip, scale: a.scale || 1, mood, state: a.state, phase: a.phase, swing: a.swing,
        hammer: a === this.hero && this.A.has('hammer'), glasses: true, invisible: st.invisible > 0,
        flame: a === this.hero ? 1 + Math.min(1, (this.A.light || 0) / 100) * 0.4 : undefined,
        small: a.small, flipped: st.flipped > 0, fuse: a.bomb ? a.fuse : undefined,
        spikes: a.thorns ? !!st.spikes : undefined, glow: st.glow > 0, loot: !!a.loot,
        under: st.under > 0, dizzy: st.dizzy > 0, molten: st.molten > 0,
        blazing: a.blazing, grow: a.growth, smooth: a.smooth,
        lit: st.lit > 0, stance: st.counter > 0 ? 'counter' : undefined, toppled: st.toppled > 0, dent: a.dent, raised: st.guard > 0,
        sack: a.kind === 'rocco' ? true : undefined,
      });
    }
    c.restore();
    // a quick white flash when something gets hit
    if (a.hurtT > 0.28 && a.alive !== false) {
      c.save(); c.globalCompositeOperation = 'lighter';
      glowDot(c, x, a.y - (a.h ? this.eh(a) : 70) * 0.5, 46, '255,255,255', 0.55 * (a.hurtT - 0.28) / 0.17);
      c.restore();
    }
    if (a.status) {
      c.font = 'bold 18px Fredoka, sans-serif'; c.textAlign = 'center';
      const top = a.y + bob - (a.h ? this.eh(a) : 80) - 20;
      if (a.status.sleep > 0) { c.fillStyle = '#fffaf0'; c.fillText('z Z', x + 26, top + Math.sin(t * 2) * 4); }
      if (a.status.stuck > 0) { c.fillStyle = '#8be07a'; c.fillText('goo', x, a.y + 20); }
      if (a === this.hero && a.status.inked > 0) { c.fillStyle = '#9fa0ff'; c.fillText('inked', x, a.y + 22); }
      if (a === this.hero && a.status.smoke > 0) { c.fillStyle = '#c8c0d8'; c.fillText('sooty: no cues!', x, a.y + 42); }
      if (a === this.hero && a.status.distracted > 0) { c.fillStyle = '#9fe6ff'; c.fillText('distracted', x, a.y + 22); }
      if (a === this.hero && a.status.dazzled > 0 && !(a.status.smoke > 0)) { c.fillStyle = '#ffd0f0'; c.fillText('dazzled: no cues!', x, a.y + 42); }
      if (a.status.burn > 0 && (a.alive !== false)) { flame(c, x - 24, a.y - 6, 0.55, t * 1.4 + x); }
      if (a.status.atkUp > 0) { c.fillStyle = '#ff9a8f'; c.fillText('ATK↑', x + 30, top + 18); }
      if (a.loot) { c.font = 'bold 14px Fredoka, sans-serif'; c.fillStyle = '#ffe066'; c.fillText(`has your ${ITEMS[a.loot].name}! (${a.fleeIn})`, x, a.y + 40); }
    }
    if (this.enemies.includes(a) && a.alive) {
      const bw = 54, bx = x - bw / 2, by = a.y + bob + 14;
      c.fillStyle = 'rgba(20,10,30,0.6)'; c.beginPath(); rrect(bx, by, bw, 9, 4)(c); c.fill();
      c.fillStyle = '#ff6b6b'; c.beginPath(); rrect(bx + 1.5, by + 1.5, (bw - 3) * (a.hp / a.maxHp), 6, 3)(c); c.fill();
      if (a.tattled || this.badge('field_monocle')) { c.font = 'bold 13px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#fffaf0'; c.fillText(`${a.hp}/${a.maxHp}`, x, by + 24); }
    }
  }

  drawCurl(c, x, y, roll, t) {
    c.save();
    c.translate(x, y - 22);
    c.rotate(roll);
    paper(c, p => shape(c, p, ell(0, 0, 22, 22), vgrad(c, -22, 22, '#b3b0c0', '#7d7a8e')));
    c.strokeStyle = 'rgba(43,34,53,0.5)'; c.lineWidth = 2;
    c.beginPath(); c.moveTo(-12, -6); c.lineTo(-4, 2); c.lineTo(-8, 10); c.stroke();
    c.fillStyle = '#7cc46a'; c.beginPath(); c.ellipse(4, -18, 9, 4, 0, 0, Math.PI * 2); c.fill();
    c.restore();
    void t;
  }

  label(c, text, x, y) {
    c.font = 'bold 15px Fredoka, sans-serif'; c.textAlign = 'center';
    const w = c.measureText(text).width + 18;
    c.fillStyle = PAPER; c.strokeStyle = INK; c.lineWidth = 2.5;
    c.beginPath(); rrect(x - w / 2, y - 16, w, 24, 10)(c); c.fill(); c.stroke();
    c.fillStyle = INK; c.fillText(text, x, y + 1);
  }

  banner(c, text) {
    c.font = 'bold 19px Fredoka, sans-serif'; c.textAlign = 'center';
    const w = Math.min(W - 330, c.measureText(text).width + 40);
    c.fillStyle = PAPER; c.strokeStyle = INK; c.lineWidth = 3;
    c.beginPath(); rrect(W / 2 - w / 2 + 60, 70, w, 40, 14)(c); c.fill(); c.stroke();
    c.fillStyle = INK; c.fillText(text, W / 2 + 60, 97, W - 350);
  }

  hud(c) {
    const s = this.A.s, atk = s.hero.atk || 0, def = s.hero.def || 0;
    const tall = atk || def;
    c.fillStyle = 'rgba(255,250,240,0.95)'; c.strokeStyle = INK; c.lineWidth = 3;
    c.beginPath(); rrect(84, 66, 170, tall ? 80 : 62, 12)(c); c.fill(); c.stroke();
    c.font = 'bold 15px Fredoka, sans-serif'; c.textAlign = 'left';
    c.fillStyle = INK; c.fillText('Wick', 96, 84);
    // low HP: the heart line pulses
    const low = this.hero.hp > 0 && this.hero.hp <= Math.max(2, this.hero.maxHp * 0.25);
    c.fillStyle = low && Math.sin(this.t * 8) > 0 ? '#ff2a4a' : '#d6455a'; c.fillText(`♥ ${this.hero.hp} / ${this.hero.maxHp}${low ? '  !' : ''}`, 96, 104);
    c.fillStyle = '#3b7fc4'; c.fillText(`✿ ${s.hero.fp} / ${s.hero.maxFp}`, 96, 122);
    if (tall) { c.fillStyle = '#6b5a8a'; c.fillText(`⚔ ATK ${atk}   🛡 DEF ${def}`, 96, 140); }
    if (this.partner) {
      const py = tall ? 154 : 136;
      c.fillStyle = 'rgba(255,250,240,0.95)'; c.strokeStyle = INK; c.lineWidth = 3;
      c.beginPath(); rrect(84, py, 170, 30, 12)(c); c.fill(); c.stroke();
      c.fillStyle = '#d6455a';
      c.fillText(`${this.partner.name} ♥ ${this.partner.hp} / ${this.partner.maxHp}`, 96, py + 21);
    }
  }
}
// Chapter 4: Tick's moves, the tower's creatures, the Scrollwyrm and Count Dusk
Object.assign(Battle.prototype, TOWER_BATTLE, MARGIN_BATTLE);
