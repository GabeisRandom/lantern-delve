// The old outdoor places, made big: Lumen Town and every outdoor place around Lumenfold (the fields, the lake, the
// grove, Ember Peak, the castle grounds and the secret gardens) now stretch far into the distance, with new places,
// folks, puzzles and treasure back there. Everything that was already in them stays where it was, along the front;
// the old puzzle walls still block the way there, with a ridge behind them (see Adventure.puzzleSpans).
// data.js runs deepenRooms() last.
import { MINI_SPEAKERS, MINI_SPEAKER_OPTS } from './minigames.js';

const FRONT = -80;
const BAND = { z0: -60, z1: 420 };   // walking off a side edge only leads away along the old road at the front

const T = (x0, x1, z0, z1, y, more = {}) => ({ x0, x1, z0, z1, y, ...more });
const HEDGE = (x0, x1, z0, z1, h = 130) => ({ x: x0, w: x1 - x0, z0, z1, h });
// natural steps up onto raised ground, each 22 or less so you just walk up them; dir is the way they climb
export function ramp(x0, x1, z0, z1, yBase, yTop, dir, mat) {
  const n = Math.max(2, Math.ceil((yBase - yTop) / 22)), rise = (yBase - yTop) / n, steps = [];
  for (let i = 0; i < n; i++) {
    const a = i / n, b = (i + 1) / n, y = yBase - (i + 1) * rise, s = { y, mat, base: yBase };
    if (dir === 'east') steps.push({ ...s, x0: x0 + (x1 - x0) * a, x1: x0 + (x1 - x0) * b, z0, z1 });
    else if (dir === 'west') steps.push({ ...s, x0: x1 - (x1 - x0) * b, x1: x1 - (x1 - x0) * a, z0, z1 });
    else if (dir === 'north') steps.push({ ...s, x0, x1, z0: z0 + (z1 - z0) * a, z1: z0 + (z1 - z0) * b });
    else steps.push({ ...s, x0, x1, z0: z1 - (z1 - z0) * b, z1: z1 - (z1 - z0) * a });
  }
  return { x0, x1, z0, z1, y: yTop, mat, steps };
}
// a row of the same scenery (fences, crops...) from (x0, z0) to (x1, z1)
const row = (kind, x0, z0, x1, z1, n, k = 1) => Array.from({ length: n }, (_, i) => ({ kind, k, x: x0 + ((x1 - x0) * i) / Math.max(1, n - 1), z: z0 + ((z1 - z0) * i) / Math.max(1, n - 1) }));
// a ring of scenery around (x, z)
const ring = (kind, x, z, r, n, k = 1) => Array.from({ length: n }, (_, i) => ({ kind, k, x: x + Math.cos((i / n) * Math.PI * 2) * r, z: z + Math.sin((i / n) * Math.PI * 2) * r * 0.7 }));
const add = (R, key, list) => { R[key] = [...(R[key] || []), ...list]; };
const deep = (R, z1) => {
  R.z1 = z1;
  for (const side of ['left', 'right']) if (R.exits && R.exits[side]) Object.assign(R.exits[side], BAND);
};

export function deepenRooms(ROOMS) {
  // ======================= LUMEN FIELDS: Farmer Rye's farm, a fishing pond, Lookout Hill
  {
    const R = ROOMS.fields_1;
    deep(R, 2800);
    R.hazard = 'water';
    R.wade = true;      // a pond you can wade through (the water comes up to Wick's knees)
    R.hazardY = 456;
    add(R, 'holes', [[500, 1100, 1500, 1850]]);
    add(R, 'terrain', [ramp(700, 900, 2000, 2200, 450, 300, 'north'), T(300, 900, 2200, 2650, 300)]);
    R.groves = [[0, 450, 450, 1400], [1950, 3000, 1950, 2750]];
    add(R, 'roads', [[1000, 270, 1100, 1300], [1100, 1300, 2050, 1400], [1100, 1300, 800, 2000, 70]]);
    add(R, 'props', [{ kind: 'house', x: 2650, z: 1350, roof: '#c45a5a', wall: '#f0d6b0', wall2: '#c9a070' }]);
    add(R, 'decor', [
      ...row('fence', 2100, 720, 2500, 720, 5), ...row('fence', 2100, 1250, 2500, 1250, 5),
      ...row('hay', 2150, 800, 2450, 800, 3),
      ...[950, 1050, 1150].flatMap(z => row('flower', 2130, z, 2470, z, 7, 0.9)),
    ]);
    add(R, 'furniture', [{ kind: 'telescope', x: 760, z: 2500, label: 'Look', say: "Through the telescope: the Paper Plains, way to the south, and Lantern Hill's castle to the north. Somewhere out there, folded-up folks are waiting." }]);
    add(R, 'plats', [[760, 450, 80, 1440, 1540]]);   // a little fishing jetty
    add(R, 'fish', [{ x: 810, z: 1525 }]);
    add(R, 'lamps', [{ x: 2150, z: 1500 }]);
    add(R, 'npcs', [{ id: 'rye', x: 2350, z: 1330, kind: 'folk', name: 'Farmer Rye', talk: 'rye', opts: { color: '#e8b070', body: '#8a5a3c', hat: 'straw' } }]);
    add(R, 'chests', [
      { id: 'f_look', x: 500, z: 2450, give: { starPiece: 1 } },
      { id: 'f_farm', x: 2820, z: 900, give: { coins: 15 } },
      { id: 'f_woods', x: 2700, z: 2500, give: { item: 'honeybun', n: 2 } },
    ]);
    add(R, 'blocks', [
      { id: 'f1d_b1', x: 1500, y: 330, z: 1600, give: { coins: 5 } },
      { id: 'f1d_h1', x: 2200, y: 300, z: 1750, hidden: true, give: { starPiece: 1 } },
    ]);
    add(R, 'bushes', [{ id: 'bush_f1d1', x: 1300, z: 700 }, { id: 'bush_f1d2', x: 1750, z: 2200 }, { id: 'bush_f1d3', x: 300, z: 1900 },
      { id: 'bush_f1d4', x: 2900, z: 1600 }, { id: 'bush_f1d5', x: 1000, z: 2600 }]);
    add(R, 'piles', [{ id: 'pile_f1', x: 2700, z: 2100 }, { id: 'pile_f2', x: 300, z: 1750 }]);
    add(R, 'signs', [{ x: 1060, z: 330, text: "North: Farmer Rye's farm, the fishing pond and Lookout Hill. (Your little map in the corner shows the whole field.)" }]);
    add(R, 'enemies', [
      { id: 'f1d1', x: 1500, z: 900, kind: 'gloomling', group: ['gloomling', 'gloomling'] },
      { id: 'f1d2', x: 2700, z: 1800, kind: 'snailshell', group: ['snailshell', 'snailshell'], calm: true },
      { id: 'f1d3', x: 1200, z: 2300, kind: 'buzzbug', group: ['buzzbug'], y: 330 },
      { id: 'f1d4', x: 400, z: 1250, kind: 'gloomling', group: ['gloomling', 'snailshell'] },
    ]);
  }

  // ======================= MIRROR LAKE: a beach, a big lake with islands, a hidden cove on the far shore
  {
    const R = ROOMS.lake_1;
    deep(R, 2600);
    // the old stepping stones and the dock stay along the front
    R.plats = R.plats.map(p => (p.length === 3 && [[900, 1160], [1600, 1800]].some(([a, b]) => p[0] + p[2] / 2 > a && p[0] + p[2] / 2 < b) ? [...p, FRONT + 10, 250] : p));
    add(R, 'holes', [[0, 2600, 1400, 2300]]);
    add(R, 'terrain', [
      T(600, 800, 1650, 1800, 440, { base: 520, mat: 'sand' }),     // Turtle Island
      T(1300, 1500, 1800, 2000, 440, { base: 520, mat: 'sand' }),   // Reed Island
      T(1980, 2140, 1620, 1740, 300, { base: 520, mat: 'rock' }),   // Gull Rock
    ]);
    add(R, 'plats', [
      [890, 450, 280, 800, 880], [1590, 450, 220, 1000, 1080],                            // boardwalks over the old streams
      [665, 450, 70, 1445, 1505], [680, 450, 70, 1550, 1610],                            // stepping stones out to Turtle Island
      [850, 450, 70, 1755, 1815], [975, 450, 70, 1775, 1835], [1100, 450, 70, 1795, 1855], [1215, 450, 60, 1815, 1875],   // on to Reed Island
      [1560, 390, 60, 1750, 1810], [1800, 340, 60, 1700, 1760],                          // up toward Gull Rock
      [1365, 450, 70, 2030, 2090], [1380, 450, 70, 2120, 2180], [1370, 450, 70, 2210, 2270],   // across to the far shore
      [2300, 450, 70, 1380, 1620],                                                       // the fishing pier
    ]);
    add(R, 'slots', [{ id: 'lakebridge', kind: 'bridge', x: 1440, z: 1340 }]);
    add(R, 'xplats', [{ look: 'bridge', x: 1360, y: 450, w: 80, z0: 1395, z1: 1805, when: 'slot_lakebridge' }]);
    add(R, 'fish', [{ x: 2345, z: 1600 }]);
    add(R, 'props', [{ kind: 'house', x: 420, z: 900, roof: '#4f9fd6', wall: '#f6e2a8', wall2: '#d9b77a' }]);
    add(R, 'npcs', [{ id: 'sandy', x: 600, z: 820, kind: 'folk', name: 'Sandy', talk: 'sandy', opts: { color: '#ffb347', body: '#3b5a7b', hat: 'straw' } }]);
    add(R, 'chests', [
      { id: 'l_turtle', x: 700, z: 1720, give: { coins: 15 } },
      { id: 'l_gull', x: 2060, z: 1680, give: { starPiece: 1 } },
      { id: 'l_cove', x: 1800, z: 2450, give: { item: 'feather' } },
      { id: 'l_beach', x: 2500, z: 700, give: { item: 'honeybun' } },
    ]);
    add(R, 'bushes', [{ id: 'bush_l1d1', x: 1300, z: 600 }, { id: 'bush_l1d2', x: 2200, z: 1100 }, { id: 'bush_l1d3', x: 600, z: 2450 }]);
    add(R, 'piles', [{ id: 'pile_l1', x: 300, z: 1200 }, { id: 'pile_l2', x: 1500, z: 2500 }]);
    add(R, 'signs', [{ x: 1250, z: 330, text: 'The islands! Hop the stepping stones out to Turtle Island and on from there. (A Bridge Sticker would reach Reed Island in one go.)' }]);
    add(R, 'enemies', [
      { id: 'l1d1', x: 1300, z: 1100, kind: 'shellcrab', group: ['shellcrab'] },
      { id: 'l1d2', x: 2200, z: 600, kind: 'shellcrab', group: ['shellcrab', 'puddlet'] },
      { id: 'l1d3', x: 400, z: 2480, kind: 'puddlet', group: ['puddlet', 'puddlet'] },
    ]);
  }

  // ======================= THE OUTSKIRTS PATH: the old Lantern Garden on a hill, a ruined cottage, a ravine
  {
    const R = ROOMS.pro_2;
    deep(R, 2400);
    add(R, 'terrain', [ramp(1000, 1200, 1500, 1700, 450, 330, 'north'), T(880, 1550, 1700, 2100, 330)]);
    R.groves = [[1700, 2300, 1200, 2350]];
    add(R, 'plats', [[750, 450, 140, 1400, 1460]]);   // a log across the ravine
    add(R, 'roads', [[1300, 270, 1100, 1500, 70]]);
    add(R, 'lamps', [{ x: 1300, z: 1950 }, { x: 500, z: 1300 }, { x: 2000, z: 900 }]);
    add(R, 'props', [{ kind: 'house', x: 450, z: 1800, roof: '#5d4a70' }]);
    add(R, 'npcs', [{ id: 'gus', x: 620, z: 1650, kind: 'candle', name: 'Gaslight Gus', talk: 'gus', opts: { wax: '#e8f0ff', wax2: '#b9c4e0', tall: true, specs: true } }]);
    add(R, 'chests', [{ id: 'o_hill', x: 1100, z: 2050, give: { starPiece: 1 } }, { id: 'o_cottage', x: 450, z: 1990, give: { coins: 15 } }]);
    add(R, 'blocks', [{ id: 'o_b1', x: 1700, y: 300, z: 700, give: { item: 'honeybun' } }]);
    add(R, 'bushes', [{ id: 'bush_o1', x: 300, z: 900 }, { id: 'bush_o2', x: 1300, z: 1200 }, { id: 'bush_o3', x: 2100, z: 1700 }]);
    add(R, 'piles', [{ id: 'pile_o1', x: 1900, z: 2250 }]);
    add(R, 'signs', [{ x: 1250, z: 320, text: "North of the path: the old Lantern Garden. Nobody's lit those lamps in years." }]);
    add(R, 'enemies', [
      { id: 'o_e1', x: 500, z: 1000, kind: 'gloomling', group: ['gloomling', 'gloomling'] },
      { id: 'o_e2', x: 1900, z: 1500, kind: 'wisp', group: ['wisp'], y: 330 },
      { id: 'o_e3', x: 1200, z: 2250, kind: 'gloomling', group: ['gloomling'] },
    ]);
  }

  // ======================= THE GROVE GATE: deep woods, the Great Stump, a mushroom ring, a log over the ravine
  {
    const R = ROOMS.grove_1;
    deep(R, 2600);
    R.groves = [[0, 860, 500, 2550], [1080, 2050, 1500, 2550]];
    add(R, 'plats', [[890, 450, 160, 1800, 1860]]);
    add(R, 'terrain', [T(400, 580, 1000, 1140, 370, { mat: 'stump' })]);
    add(R, 'decor', ring('mushroom', 1500, 1000, 130, 10, 1.1));
    add(R, 'npcs', [{ id: 'grandacorn', x: 1500, z: 1000, kind: 'acorn', name: 'Grandpa Acorn', talk: 'grandacorn' }]);
    add(R, 'chests', [{ id: 'g_stump', x: 490, z: 1070, give: { starPiece: 1 } }, { id: 'g_deep', x: 1800, z: 2300, give: { coins: 20 } }]);
    add(R, 'bushes', [{ id: 'bush_g1d', x: 700, z: 1700 }, { id: 'bush_g1e', x: 1300, z: 600 }, { id: 'bush_g1f', x: 1800, z: 1200 }]);
    add(R, 'piles', [{ id: 'pile_g1', x: 300, z: 2300 }]);
    add(R, 'signs', [{ x: 600, z: 330, text: 'Deeper in the Grove: the Great Stump, the mushroom ring, and a ravine you can cross on a fallen log.' }]);
    add(R, 'enemies', [
      { id: 'g1d1', x: 1600, z: 1800, kind: 'spikeshroom', group: ['spikeshroom', 'gloomling'] },
      { id: 'g1d2', x: 500, z: 2000, kind: 'gloomling', group: ['gloomling', 'gloomling'] },
      { id: 'g1d3', x: 1200, z: 2250, kind: 'buzzbug', group: ['buzzbug'], y: 330 },
    ]);
  }

  // ======================= LANTERN HILL ROAD: hedgerows, a picnic, the Old Watchtower
  {
    const R = ROOMS.castle_road;
    deep(R, 2600);
    add(R, 'terrain', [T(1800, 2000, 1500, 1700, 200, { mat: 'stone', base: 402 }), ramp(1600, 1800, 1520, 1680, 402, 200, 'east', 'stone')]);
    add(R, 'hedges', [HEDGE(300, 700, 1000, 1040), HEDGE(800, 1380, 1000, 1040), HEDGE(1420, 2100, 2000, 2040)]);
    add(R, 'furniture', [
      { kind: 'rug', x: 1100, z0: 1300, z1: 1420, w: 160, color: '#e5534b', trim: '#fffaf0' },
      { kind: 'telescope', x: 1950, z: 1660, label: 'Look', say: "From the top of the Old Watchtower: the castle up the hill, Lumen Town's Great Lantern, and the whole Paper Plains far to the south." },
    ]);
    add(R, 'decor', [...row('flag', 1700, 1450, 2100, 1450, 3)]);
    add(R, 'npcs', [{ id: 'pam', x: 1150, z: 1360, kind: 'folk', name: 'Picnic Pam', talk: 'pam', opts: { color: '#ff9ab0', body: '#5fae5c' } }]);
    add(R, 'pots', [{ id: 'pot_cr1', x: 1060, z: 1350 }]);
    add(R, 'chests', [{ id: 'c_tower', x: 1880, z: 1560, give: { starPiece: 1 } }, { id: 'c_hedge', x: 1250, z: 1150, give: { item: 'bighoney' } },
      { id: 'c_far', x: 2400, z: 2300, give: { coins: 20 } }]);
    add(R, 'bushes', [{ id: 'bush_cr3', x: 500, z: 1500 }, { id: 'bush_cr4', x: 2300, z: 1000 }, { id: 'bush_cr5', x: 900, z: 2200 }]);
    add(R, 'piles', [{ id: 'pile_cr1', x: 2300, z: 1250 }]);
    add(R, 'signs', [{ x: 400, z: 330, text: "Off the road to the north: the Old Watchtower. Nobody's kept watch for years, but the view is still free." }]);
    add(R, 'enemies', [
      { id: 'cr_d1', x: 600, z: 1300, kind: 'gloomling', group: ['gloomling', 'gloomling'] },
      { id: 'cr_d2', x: 1500, z: 1200, kind: 'buzzbug', group: ['buzzbug', 'buzzbug'], y: 330 },
      { id: 'cr_d3', x: 2200, z: 2250, kind: 'dustbunny', group: ['dustbunny'] },
    ]);
  }

  // ======================= THE NORTH TRAIL: Glass Lake, the hermit's hut, the Snowcap
  {
    const R = ROOMS.mtn_1;
    deep(R, 2600);
    R.hazard = 'water';
    R.wade = true;
    R.hazardY = 432;    // (the lake is on the trail's 426-high stretch)
    add(R, 'holes', [[900, 1400, 1300, 1700]]);
    add(R, 'terrain', [
      ramp(1650, 1850, 1850, 2050, 402, 222, 'north', 'snow'), T(1550, 2150, 2050, 2550, 222, { mat: 'snow', base: 402 }),   // the Snowcap
      T(2250, 2750, 2300, 2550, 250, { mat: 'rock', base: 426 }),                                                        // a rocky bluff
    ]);
    R.groves = [[0, 800, 1800, 2550], [2200, 2800, 900, 2000]];
    add(R, 'props', [{ kind: 'house', x: 500, z: 1500, roof: '#6e4a30', wall: '#d9c6a8', wall2: '#a8906a' }]);
    add(R, 'npcs', [{ id: 'crag', x: 650, z: 1400, kind: 'folk', name: 'Hermit Crag', talk: 'crag', opts: { color: '#c8c2d4', body: '#5f5a52', hat: 'bucket' } }]);
    add(R, 'chests', [{ id: 'm_peak', x: 1800, z: 2400, give: { starPiece: 1 } }, { id: 'm_hut', x: 380, z: 1700, give: { item: 'embertea' } },
      { id: 'm_lake', x: 1150, z: 1250, give: { coins: 15 } }]);
    add(R, 'bushes', [{ id: 'bush_mt2', x: 1200, z: 800 }, { id: 'bush_mt3', x: 2500, z: 1900 }]);
    add(R, 'piles', [{ id: 'pile_mt1', x: 2400, z: 1400 }]);
    add(R, 'signs', [{ x: 700, z: 330, text: "Up here: Glass Lake, the hermit's hut, and the Snowcap. Bring a scarf." }]);
    add(R, 'enemies', [
      { id: 'mt_d1', x: 1000, z: 900, kind: 'bombshroom', group: ['bombshroom'] },
      { id: 'mt_d2', x: 2400, z: 1100, kind: 'raccoon', group: ['raccoon', 'raccoon'] },
      { id: 'mt_d3', x: 600, z: 2200, kind: 'gloomling', group: ['gloomling', 'gloomling'] },
    ]);
  }

  // ======================= LUMEN TOWN: Lantern Square, the canal, Old Town, Lumen Park, Observatory Hill, the North Gate
  {
    const R = ROOMS.pro_1;
    deep(R, 3000);
    R.hazard = 'water';
    R.wade = true;     // the canal and the park pond are shallow: wade right in
    R.hazardY = 456;
    R.gentle = true;
    R.decorSet = 'town';
    R.roadColor = 'rgba(196,188,212,0.82)';
    R.clear = [[0, R.w, -80, 330]];   // Main Street stays just as it was
    // the canal runs right across town (four bridges, a fishing jetty, a raft nobody owns); the park has a pond
    add(R, 'holes', [[0, R.w, 1260, 1400], [300, 800, 2050, 2450]]);
    add(R, 'plats', [
      ...[565, 1450, 2380, 3050].map(x => [x - 65, 450, 130, 1240, 1420]),
      [840, 450, 80, 1240, 1330], [1680, 450, 90, 1300, 1360], [520, 450, 60, 2090, 2140],
    ]);
    add(R, 'fish', [{ x: 880, z: 1310 }]);
    add(R, 'terrain', [
      T(470, 630, 2180, 2320, 440, { base: 456, mat: 'sand' }),                                                         // the pond's island
      ramp(2950, 3150, 1850, 2050, 450, 330, 'north', 'stone'), T(2650, 3350, 2050, 2900, 330, { mat: 'stone' }),   // Observatory Hill
      T(3150, 3350, 960, 1100, 280, { mat: 'stone' }),                                                                  // the Tinker's loading dock
    ]);
    add(R, 'plazas', [[960, 1940, 470, 1130], [2120, 2640, 2560, 2940]]);
    add(R, 'roads', [
      [80, 400, 3320, 400, 80],                                               // Back Lane, behind the shops
      [80, 1200, 3320, 1200, 70], [80, 1470, 3320, 1470, 70],                // along both banks of the canal
      [565, 400, 565, 1240, 70], [2380, 300, 2380, 1240, 90], [3050, 400, 3050, 1240, 70], [1450, 1130, 1450, 1240, 110],
      [1450, 1420, 1450, 2250, 100], [2380, 1420, 2380, 2560, 100], [3050, 1420, 3050, 1850, 70],
      [1100, 1820, 2700, 1820, 80], [60, 790, 940, 790, 70],                 // Old Town's lane and Lantern Row
      [565, 1470, 565, 2040, 60], [300, 2000, 820, 2000, 60],                // the park paths
    ]);
    R.groves = [[0, 280, 1500, 2950], [0, 1100, 2700, 2950]];
    // the houses: Lantern Row (south-west), Old Town (north of the canal), the Tinker's workshop, the greenhouse, the Observatory
    const HOUSE = (x, z, roof, wall = '#f3e6d0', wall2 = '#cdb898') => ({ kind: 'house', x, z, roof, wall, wall2 });
    const homes = [
      HOUSE(160, 560, '#4f72bf'), HOUSE(380, 560, '#e5534b', '#f6e3b8', '#d9bf86'), HOUSE(760, 560, '#5fae5c'),
      HOUSE(160, 880, '#f2b43a', '#e3d9f6', '#bba9e0'), HOUSE(380, 880, '#7b5fc7'), HOUSE(760, 880, '#3aa79c', '#f6e3b8', '#d9bf86'),
      HOUSE(1200, 1560, '#c45a5a'), HOUSE(1700, 1560, '#4f9fd6', '#e3d9f6', '#bba9e0'), HOUSE(1950, 1560, '#f2b43a'),
      HOUSE(2200, 1560, '#7b5fc7', '#f6e3b8', '#d9bf86'), HOUSE(2560, 1560, '#5fae5c'),
      HOUSE(1200, 1900, '#3aa79c'), HOUSE(1700, 1900, '#e5534b'), HOUSE(1950, 1900, '#5d4a70', '#e3d9f6', '#bba9e0'),
      HOUSE(2200, 1900, '#c45a5a', '#f6e3b8', '#d9bf86'), HOUSE(2560, 1900, '#4f72bf'),
    ];
    add(R, 'props', [
      ...homes,
      HOUSE(2150, 900, '#7ccf5e', '#e8f6e0', '#b8d8a8'),
      { kind: 'building', x: 2750, z: 620, sign: "Tinker's Workshop", roof: '#5a4e58', wall: '#e0c4a8', wall2: '#b8967a', icon: '🔧' },
      { kind: 'building', x: 3050, z: 2550, w: 200, h: 170, sign: 'Observatory', roof: '#2c3a6e', wall: '#e3d9f6', wall2: '#bba9e0', icon: '🔭' },
    ]);
    // knock on any door and see who answers
    const KNOCKS = [
      "A voice from inside: 'We already have a candle, thank you!'",
      "'Who is it?' ... 'Wick? THE Wick? Hang on, I'm in my pajamas!' ...Nobody comes out. Maybe they're still choosing pajamas.",
      'Nobody answers. Through the window, a paper cat stares at you, deeply unimpressed.',
      "'If it's the mail, tell Flap the letter can wait. It's been waiting a year already.'",
      "You hear snoring. Very loud snoring. The kind of snoring you don't interrupt.",
      "'If you're selling cookies: YES. If you're not: also yes, but sadder.'",
      "A tiny voice: 'My mom says I can't open the door to strangers. Are you strange?' ... 'You look a little strange.'",
      "'Go away, I'm napping!' ... 'It's a VERY important nap.'",
      "Somebody inside is practicing the trumpet. Badly. They don't hear you knock. Probably for the best.",
      "'Thank you for lighting the town back up! Here, have a hug through the door.' ...It's a strange feeling, but a nice one.",
      "'Wick! Did you hear? Somebody's been finding folded-up folks all over Lumenfold!' ... 'Oh. That's you. Carry on!'",
      "The door says: 'GONE FISHING. (In the canal. Wave if you see me.)'",
      "A voice: 'Is that the hero? Mom! MOM! The hero is at the DOOR!' ...Lots of thumping. Nobody opens it.",
      "'We're having soup! Paper soup! ...You can't have any. It's mostly paper.'",
      "Somebody inside is singing in the bath. You decide to come back later. Much later.",
      "'Did you wipe your feet? ...You have no feet. Hm. Come in anyway.' The door stays shut. It's locked.",
    ];
    add(R, 'furniture', [
      ...homes.map((h, i) => ({ kind: 'spot', x: h.x, z: h.z - 14, label: 'Knock', say: KNOCKS[i % KNOCKS.length] })),
      { kind: 'spot', x: 2150, z: 886, label: 'Knock', say: "The greenhouse is warm and steamy. All the plants lean toward you, like they're curious who's visiting." },
      { kind: 'spot', x: 2750, z: 606, label: 'Knock', say: "A sign on the door: 'BACK IN FIVE MINUTES. (Since last Tuesday.)' ...Tinker Tess is out in her yard." },
      { kind: 'spot', x: 3050, z: 2536, label: 'Knock', say: "A note on the door: 'Observing. Do not disturb. Unless you are a comet.' — Prof. Twinkle" },
      ...[[1250, 640], [1650, 640], [420, 1900], [700, 1900], [1300, 2250], [1600, 2250]].map(([x, z]) => ({ kind: 'bench', x, z })),
      { kind: 'telescope', x: 2800, z: 2300, label: 'Look', say: "Through the telescope: Count Dusk's Tower, poking into the clouds far to the north. A cold little light blinks at the very top." },
      { kind: 'rug', x: 2850, z0: 1600, z1: 1700, w: 160, color: '#4f72bf', trim: '#fffaf0' },
      { kind: 'barrel', x: 2580, z: 600 }, { kind: 'barrel', x: 2620, z: 650 }, { kind: 'sacks', x: 2930, z: 640 },
    ]);
    add(R, 'decor', [
      { kind: 'fountain', x: 1450, z: 820 }, { kind: 'statue', x: 1450, z: 2300 },
      // the carnival booths (their games are in minigames.js)
      ...[['whack', 1080], ['memory', 1230], ['beat', 1670], ['plane', 1820]].map(([g, x]) => ({ kind: `booth_${g}`, x, z: 1060 })),
      { kind: 'planter', x: 1000, z: 520 }, { kind: 'planter', x: 1900, z: 520 },
      ...row('fence', 1980, 470, 2290, 470, 4), ...[540, 620, 700].flatMap(z => row('flower', 1990, z, 2290, z, 6, 0.9)),
      ...row('flower', 320, 2030, 780, 2030, 8, 0.9), ...row('flower', 320, 2470, 780, 2470, 8, 0.9),
      ...[300, 1100, 2000, 2800].map(x => ({ kind: 'reeds', x, z: 1248 })), ...[400, 1250, 2600].map(x => ({ kind: 'reeds', x, z: 1412 })),
      { kind: 'flag', x: 2250, z: 2900 }, { kind: 'flag', x: 2510, z: 2900 },
    ]);
    // the North Gate moves to the far north end of town, where a north gate belongs
    R.doors.find(d => d.to === 'mtn_1').z = 2880;
    add(R, 'lamps', [{ x: 980, z: 480 }, { x: 900, z: 1600 }, { x: 2600, z: 2700 }, { x: 3250, z: 2200 }]);
    const town = A => A.flag('prologue_done');
    add(R, 'npcs', [
      { id: 'bun', x: 1150, z: 1005, kind: 'folk', name: 'Baker Bun', talk: 'bun', opts: { color: '#f6d6a8', body: '#e8a92a' }, show: town },
      { id: 'scoop', x: 1300, z: 720, kind: 'folk', name: 'Paperboy Scoop', talk: 'scoop', opts: { color: '#ffd23f', body: '#4f72bf', hat: 'bucket' }, show: town },
      { id: 'sal', x: 960, z: 1215, kind: 'folk', name: 'Old Sal', talk: 'sal', opts: { color: '#4f9fd6', body: '#3b5a7b', hat: 'bucket' }, flip: -1, show: town },
      { id: 'wix', x: 430, z: 1870, kind: 'candle', name: 'Grandma Wix', talk: 'wix', opts: { wax: '#fff0e0', wax2: '#e0c8b0', specs: true }, show: town },
      { id: 'lu', x: 1330, z: 1760, kind: 'candle', name: 'Lamplighter Lu', talk: 'lu', opts: { wax: '#ffe6a8', wax2: '#e8c070', tall: true }, show: town },
      { id: 'tess', x: 2900, z: 780, kind: 'folk', name: 'Tinker Tess', talk: 'tess', opts: { color: '#c8c2d4', body: '#5a4e58', specs: true }, show: town },
      { id: 'twinkle', x: 2930, z: 2360, kind: 'folk', name: 'Professor Twinkle', talk: 'twinkle', opts: { color: '#b49cff', body: '#2c3a6e', specs: true }, show: town },
      { id: 'bolt', x: 2250, z: 2780, kind: 'folk', name: 'Gatekeeper Bolt', talk: 'bolt', opts: { color: '#9a93ad', body: '#5a4e68', hat: 'bucket' } },
      // the carnival folks, each behind their booth
      ...[['whack', 1080, 'Bonk'], ['memory', 1230, 'Madame Shuffle'], ['beat', 1670, 'DJ Flicker'], ['plane', 1820, 'Pilot Pleat']].map(([g, x, name]) => ({
        id: `mg_${g}`, x, z: 1092, kind: MINI_SPEAKERS[name], name, talk: `mg_${g}`, label: 'Play', opts: MINI_SPEAKER_OPTS[name], show: town,
        newsY: 180,   // (a booth you haven't played shows its "!" up over the sign, where the awning can't hide it)
      })),
    ]);
    // the Tinker's crate: push it over to her loading dock to climb up
    add(R, 'crates', [{ id: 'cr_tinker', x: 2950, z: 1030 }]);
    add(R, 'resets', [{ x: 2560, z: 980 }]);
    add(R, 'chests', [
      { id: 't_island', x: 550, z: 2250, give: { starPiece: 1 } },
      { id: 't_dock', x: 3270, z: 1030, give: { item: 'bighoney', n: 2 } },
      { id: 't_obs', x: 3220, z: 2830, give: { coins: 20 } },
      { id: 't_alley', x: 60, z: 1100, give: { item: 'honeybun', n: 2 } },
    ]);
    add(R, 'blocks', [
      { id: 't_b1', x: 1290, y: 320, z: 900, give: { coins: 5 } }, { id: 't_b2', x: 1566, y: 320, z: 900, give: { item: 'honeybun' } },
      { id: 't_h1', x: 2358, y: 300, z: 2150, hidden: true, give: { starPiece: 1 } },
    ]);
    add(R, 'bushes', [{ id: 'bush_t1', x: 920, z: 2620 }, { id: 'bush_t2', x: 200, z: 1560 }, { id: 'bush_t3', x: 2760, z: 1560 },
      { id: 'bush_t4', x: 3300, z: 700 }, { id: 'bush_t5', x: 2050, z: 2450 }]);
    add(R, 'pots', [{ id: 'pot_t1', x: 2660, z: 760 }, { id: 'pot_t2', x: 1825, z: 1520 }]);
    add(R, 'piles', [{ id: 'pile_t1', x: 3300, z: 2500 }, { id: 'pile_t2', x: 150, z: 2400 }]);
    add(R, 'signs', [
      { x: 1000, z: 430, text: 'LUMEN TOWN. Up behind the shops: Lantern Square. Over the canal: Old Town, and Lumen Park to the west. Observatory Hill is east. The North Gate is at the far north end.' },
      { x: 2440, z: 330, text: 'North Gate: straight up this street, over the canal, all the way to the end.' },
    ]);
    // the folks you rescue spread out all over town, not just along Main Street
    const SPOTS = [
      [340, 60], [450, 110], [650, 20], [790, 130], [1270, 100], [1580, 40], [2150, 60], [2460, 40], [2880, 40], [3140, 30],
      [1060, 600], [1180, 920], [1330, 1010], [1600, 990], [1760, 880], [1860, 620], [1110, 760], [1790, 740], [1360, 560], [1560, 560],
      [300, 1180], [760, 1170], [1220, 1180], [1900, 1170], [2650, 1180], [3250, 1170],
      [1350, 1700], [1560, 1760], [2060, 1780], [1300, 2150], [1660, 2180], [2100, 2260],
      [300, 1650], [720, 1760], [880, 1960], [250, 2560], [880, 2480],
      [2760, 2160], [3200, 2420], [2800, 1760], [2200, 2660], [2550, 2850], [2470, 2620],
      [480, 700], [250, 760], [700, 1060], [2060, 760], [2620, 830], [3200, 640],
    ];
    R.npcs.filter(n => n.id.startsWith('rf_')).forEach((n, i) => { [n.x, n.z] = SPOTS[i % SPOTS.length]; });
  }

  // ======================= MOTHWICK'S SHED: the moth garden out back, and a lookout over the Ember Road canyon
  {
    const R = ROOMS.pro_3;
    deep(R, 2400);
    R.hazard = 'water';
    R.wade = true;
    R.hazardY = 456;
    R.gentle = true;
    add(R, 'holes', [[180, 620, 1250, 1550]]);
    add(R, 'plats', [[560, 450, 140, 1380, 1440]]);   // a plank over the end of the pond
    add(R, 'terrain', [T(280, 420, 1900, 2020, 360, { mat: 'stump' })]);
    R.groves = [[0, 260, 600, 2350], [1260, 1600, 1500, 2350]];
    add(R, 'roads', [[620, 300, 620, 1200, 60], [620, 1200, 900, 1900, 60], [1420, 300, 1420, 2150, 60]]);
    add(R, 'props', [{ kind: 'house', x: 900, z: 1950, roof: '#8a76b0', wall: '#e3d9f6', wall2: '#bba9e0' }]);
    add(R, 'decor', [
      ...[650, 720, 790].flatMap(z => row('flower', 760, z, 1080, z, 6, 0.9)), ...row('fence', 740, 600, 1100, 600, 4),
      ...ring('flower', 400, 1700, 160, 10, 1), { kind: 'lamp', x: 1000, z: 1300 },
    ]);
    add(R, 'furniture', [
      { kind: 'spot', x: 900, z: 1936, label: 'Knock', say: "Mothwick's tool shed. Inside: a hundred jars of moth food, all labeled 'NOT FOR WICK'. Fair enough." },
      { kind: 'telescope', x: 1450, z: 2200, label: 'Look', say: "Through the telescope: Ember Peak, puffing smoke on the horizon. The Ember Road winds off toward it, over the canyon." },
      { kind: 'bench', x: 520, z: 1680 },
    ]);
    add(R, 'lamps', [{ x: 760, z: 1180 }]);
    add(R, 'npcs', [{ id: 'petal', x: 940, z: 840, kind: 'folk', name: 'Gardener Petal', talk: 'petal', opts: { color: '#ff9ab0', body: '#5fae5c', hat: 'straw' }, show: A => A.flag('prologue_done') }]);
    add(R, 'chests', [{ id: 's_stump', x: 350, z: 1960, give: { starPiece: 1 } }, { id: 's_look', x: 1520, z: 2250, give: { coins: 15 } },
      { id: 's_shed', x: 1080, z: 2100, give: { item: 'honeybun', n: 2 } }]);
    add(R, 'bushes', [{ id: 'bush_s3a', x: 150, z: 2100 }, { id: 'bush_s3b', x: 1100, z: 1500 }, { id: 'bush_s3c', x: 1500, z: 1200 }]);
    add(R, 'piles', [{ id: 'pile_s3', x: 760, z: 2250 }]);
    add(R, 'signs', [{ x: 560, z: 330, text: "Mothwick's moth garden is out back. Please don't step on the glowing flowers. (They're for the moths.)" }]);
    add(R, 'enemies', [{ id: 's3d1', x: 300, z: 1000, kind: 'gloomling', group: ['gloomling'], calm: true }]);
  }

  // ======================= THE SECRET GARDEN: a walled rose courtyard with a fountain, and a lily pond behind it
  {
    const R = ROOMS.seal_1;
    deep(R, 2000);
    R.hazard = 'water';
    R.wade = true;
    R.hazardY = 456;
    R.gentle = true;
    add(R, 'hedges', [HEDGE(160, 560, 900, 940), HEDGE(740, 1140, 900, 940), HEDGE(160, 200, 940, 1560), HEDGE(1100, 1140, 940, 1560), HEDGE(160, 1140, 1560, 1600)]);
    add(R, 'holes', [[300, 1000, 1700, 1860]]);
    add(R, 'plats', [[420, 450, 60, 1740, 1800], [560, 450, 60, 1760, 1820], [700, 450, 60, 1740, 1800], [840, 450, 60, 1760, 1820]]);   // lily pads
    add(R, 'decor', [{ kind: 'fountain', x: 650, z: 1250 }, ...ring('rosebush', 650, 1250, 300, 10), ...row('flower', 220, 980, 1080, 980, 9, 0.9),
      ...row('rosebush', 100, 400, 1200, 400, 8)]);
    add(R, 'furniture', [{ kind: 'bench', x: 650, z: 1500 }]);
    add(R, 'chests', [{ id: 's1d_lily', x: 650, z: 1930, give: { starPiece: 1 } }, { id: 's1d_court', x: 1000, z: 1450, give: { coins: 20 } }]);
    add(R, 'bushes', [{ id: 'bush_s1b', x: 1220, z: 1300 }, { id: 'bush_s1c', x: 300, z: 1100 }]);
    add(R, 'signs', [{ x: 650, z: 820, text: "Rosa's courtyard. The lily pads out back can hold a candle, if the candle doesn't dawdle." }]);
  }

  // ======================= THE BRAMBLE THICKET: a hedge maze on the near side, brambles in the middle, the Beast's hoard
  {
    const R = ROOMS.maze_1;
    deep(R, 2600);
    // (the short wall and the boulder still split the thicket in three, all the way back)
    add(R, 'hedges', [HEDGE(0, 500, 600, 640, 170), HEDGE(200, 700, 1000, 1040, 170), HEDGE(0, 500, 1400, 1440, 170), HEDGE(200, 700, 1800, 1840, 170), HEDGE(0, 500, 2200, 2240, 170)]);
    add(R, 'terrain', [T(950, 1100, 1600, 1720, 370, { mat: 'stump' }), T(2300, 2700, 2200, 2500, 360, { mat: 'rock' }), ramp(2150, 2300, 2250, 2450, 450, 360, 'east', 'rock')]);
    R.groves = [[760, 1400, 1900, 2550], [1510, 2800, 1000, 1800]];
    add(R, 'decor', [...row('thorn', 800, 1300, 1350, 1300, 6), ...ring('mushroom', 1900, 2350, 140, 8, 1.1)]);
    add(R, 'chests', [{ id: 'm_maze', x: 300, z: 2450, give: { starPiece: 1 } }, { id: 'm_stump', x: 1025, z: 1660, give: { item: 'embertea' } },
      { id: 'm_hoard', x: 2500, z: 2350, give: { coins: 30 } }]);
    add(R, 'blocks', [{ id: 'm_h1', x: 1150, y: 300, z: 900, hidden: true, give: { item: 'bighoney' } }]);
    add(R, 'bushes', [{ id: 'bush_m3', x: 1200, z: 2200 }, { id: 'bush_m4', x: 2000, z: 900 }, { id: 'bush_m5', x: 600, z: 1600 }]);
    add(R, 'piles', [{ id: 'pile_m1', x: 1700, z: 2400 }]);
    add(R, 'signs', [{ x: 400, z: 380, text: 'A hedge maze, way back there. Thorny on the outside, treasure on the inside. (Probably.)' }]);
    add(R, 'enemies', [
      { id: 'm1d1', x: 1100, z: 1200, kind: 'thornback', group: ['thornback', 'thornback'] },
      { id: 'm1d2', x: 400, z: 1200, kind: 'spikeshroom', group: ['spikeshroom'] },
      { id: 'm1d3', x: 2000, z: 1500, kind: 'thornback', group: ['thornback', 'spikeshroom'] },
    ]);
  }

  // ======================= THE SUMMIT SHRINE: a row of shrine gates up to a snowy garden
  {
    const R = ROOMS.seal_2;
    deep(R, 1800);
    add(R, 'terrain', [T(150, 380, 1100, 1300, 400, { mat: 'snow' }), T(760, 1000, 800, 1000, 380, { mat: 'snow' }), T(400, 700, 1500, 1700, 390, { mat: 'snow' })]);
    add(R, 'roads', [[550, 300, 550, 1450, 80]]);
    add(R, 'decor', [...row('torii', 550, 500, 550, 1400, 5)]);
    add(R, 'chests', [{ id: 's2d_top', x: 550, z: 1600, give: { coins: 25 } }, { id: 's2d_mound', x: 880, z: 900, give: { item: 'embertea', n: 2 } }]);
    add(R, 'signs', [{ x: 400, z: 340, text: 'Walk the shrine path. Every gate you pass under, think of one thing you finished today.' }]);
  }

  // ======================= MOSSY STEPS: a stream with log bridges, a staircase of mossy stumps, a mushroom ring
  {
    const R = ROOMS.grove_2;
    deep(R, 2400);
    R.hazard = 'water';
    R.wade = true;      // the stream is shallow (the logs keep your feet dry)
    R.hazardY = 456;
    add(R, 'holes', [[150, 1450, 1300, 1400]]);
    add(R, 'plats', [[400, 450, 160, 1280, 1420], [1000, 450, 160, 1280, 1420]]);   // fallen logs over the stream
    add(R, 'terrain', [
      T(300, 420, 1800, 1900, 400, { mat: 'stump' }), T(450, 570, 1820, 1920, 350, { mat: 'stump' }),
      T(600, 720, 1840, 1940, 300, { mat: 'stump' }), T(750, 870, 1860, 1960, 250, { mat: 'stump' }),
    ]);
    R.groves = [[0, 1500, 2000, 2350], [1650, 2150, 600, 2350]];
    add(R, 'decor', [...ring('mushroom', 1900, 1500, 130, 9, 1.1), ...row('fern', 200, 1250, 1400, 1250, 8)]);
    add(R, 'npcs', [{ id: 'rowan', x: 700, z: 700, kind: 'folk', name: 'Ranger Rowan', talk: 'rowan', opts: { color: '#8be07a', body: '#4f7f58', hat: 'feather' } }]);
    add(R, 'chests', [{ id: 'g2d_stump', x: 810, z: 1910, give: { starPiece: 1 } }, { id: 'g2d_ring', x: 1900, z: 1500, give: { coins: 15 } },
      { id: 'g2d_bank', x: 1300, z: 1600, give: { item: 'honeybun', n: 2 } }]);
    add(R, 'bushes', [{ id: 'bush_g2a', x: 300, z: 900 }, { id: 'bush_g2b', x: 1200, z: 1100 }, { id: 'bush_g2c', x: 1800, z: 2100 }]);
    add(R, 'piles', [{ id: 'pile_g2', x: 1100, z: 2150 }]);
    add(R, 'signs', [{ x: 1000, z: 340, text: 'Up the glen: a stream (cross on the logs) and the Mossy Stair, a staircase of old stumps. Hop up!' }]);
    add(R, 'enemies', [
      { id: 'g2d1', x: 800, z: 1000, kind: 'gloomling', group: ['gloomling', 'gloomling'] },
      { id: 'g2d2', x: 500, z: 1650, kind: 'spikeshroom', group: ['spikeshroom'] },
      { id: 'g2d3', x: 1900, z: 1000, kind: 'buzzbug', group: ['buzzbug', 'buzzbug'], y: 330 },
    ]);
  }

  // ======================= HOOT'S HOLLOW: the Owl Woods, a ring of great trees around a clearing
  {
    const R = ROOMS.grove_3;
    deep(R, 2200);
    add(R, 'props', [{ kind: 'bigtree', x: 330, z: 1250 }, { kind: 'bigtree', x: 1200, z: 1350 }, { kind: 'bigtree', x: 760, z: 1900 }]);
    add(R, 'terrain', [ramp(1050, 1200, 1700, 1850, 450, 360, 'north'), T(1000, 1400, 1850, 2100, 360)]);
    R.groves = [[0, 250, 500, 2150], [1300, 1500, 500, 1700]];
    add(R, 'decor', [...ring('mushroom', 760, 1500, 200, 12, 1), ...ring('flower', 760, 1500, 120, 8, 0.9)]);
    add(R, 'npcs', [{ id: 'grannyhoo', x: 760, z: 1760, kind: 'hoot', name: 'Granny Hoo', talk: 'grannyhoo', opts: { glasses: true }, flip: -1 }]);
    add(R, 'chests', [{ id: 'g3d_hill', x: 1300, z: 2000, give: { starPiece: 1 } }, { id: 'g3d_root', x: 330, z: 1500, give: { item: 'embertea' } }]);
    add(R, 'bushes', [{ id: 'bush_g3b', x: 500, z: 800 }, { id: 'bush_g3c', x: 1100, z: 900 }]);
    add(R, 'piles', [{ id: 'pile_g3', x: 200, z: 2000 }]);
    add(R, 'signs', [{ x: 500, z: 340, text: 'The Owl Woods. Owls have lived in these trees for a hundred years. Please hoot quietly.' }]);
    add(R, 'enemies', [{ id: 'g3d1', x: 1000, z: 1100, kind: 'buzzbug', group: ['buzzbug'], y: 340 }, { id: 'g3d2', x: 400, z: 1900, kind: 'gloomling', group: ['gloomling', 'gloomling'] }]);
  }

  // ======================= BRAMBLE GAP: the Sage's paper garden, deep woods across the gap, an island only a glider can reach
  {
    const R = ROOMS.grove_4;
    deep(R, 2400);
    // (the brambles run the whole way back: you still need to glide across)
    // (the stump is too far out to jump to, and just high enough that you have to glide the last bit)
    add(R, 'terrain', [T(1300, 1360, 1500, 1620, 380, { base: 520, mat: 'stump' }), T(300, 600, 1700, 1950, 380), ramp(400, 520, 1580, 1700, 450, 380, 'north')]);
    R.groves = [[1600, 2450, 1300, 2350], [0, 300, 1000, 2350]];
    add(R, 'decor', [...row('pinwheel', 450, 900, 1000, 900, 5), ...row('pinwheel', 450, 1300, 1000, 1300, 5)]);
    add(R, 'chests', [{ id: 'g4d_isle', x: 1330, z: 1560, give: { starPiece: 1 } }, { id: 'g4d_hill', x: 450, z: 1850, give: { coins: 15 } },
      { id: 'g4d_far', x: 2200, z: 2200, give: { item: 'bighoney' } }]);
    add(R, 'bushes', [{ id: 'bush_g4a', x: 800, z: 1600 }, { id: 'bush_g4b', x: 2000, z: 1200 }]);
    add(R, 'signs', [{ x: 700, z: 340, text: 'Way out in the middle of the brambles there is a stump with something on it. Only a paper airplane could get there.' }]);
    add(R, 'enemies', [{ id: 'g4d1', x: 700, z: 1100, kind: 'gloomling', group: ['gloomling', 'buzzbug'] }, { id: 'g4d2', x: 2000, z: 1800, kind: 'spikeshroom', group: ['spikeshroom', 'spikeshroom'] }]);
  }

  // ======================= GRUMBLE GATE: the King's mushroom gardens
  {
    const R = ROOMS.grove_5;
    deep(R, 2200);
    add(R, 'terrain', [T(1300, 1500, 1500, 1640, 360, { mat: 'stump' }), T(200, 360, 1300, 1420, 380, { mat: 'stump' })]);
    add(R, 'hedges', [HEDGE(500, 900, 1200, 1240, 100), HEDGE(1000, 1400, 1200, 1240, 100)]);
    R.groves = [[0, 400, 1700, 2150], [1500, 1850, 700, 2150]];
    add(R, 'decor', [...ring('mushroom', 950, 1700, 220, 14, 1.2), ...ring('mushroom', 950, 1700, 110, 8, 0.9), ...row('flag', 700, 1150, 1200, 1150, 3)]);
    add(R, 'npcs', [{ id: 'spore', x: 950, z: 1550, kind: 'folk', name: 'Royal Gardener Spore', talk: 'spore', opts: { color: '#c4a57a', body: '#8a5a3c', hat: 'straw' } }]);
    add(R, 'chests', [{ id: 'g5d_stump', x: 1400, z: 1570, give: { starPiece: 1 } }, { id: 'g5d_small', x: 280, z: 1360, give: { coins: 12 } },
      { id: 'g5d_ring', x: 950, z: 1700, give: { item: 'embertea', n: 2 } }]);
    add(R, 'bushes', [{ id: 'bush_g5a', x: 1600, z: 1900 }, { id: 'bush_g5b', x: 300, z: 800 }]);
    add(R, 'signs', [{ x: 950, z: 1100, text: "THE ROYAL MUSHROOM GARDEN. By order of King Grumblecap: no picking, no poking, no sitting on the toadstools." }]);
    add(R, 'enemies', [{ id: 'g5d1', x: 600, z: 1000, kind: 'spikeshroom', group: ['spikeshroom', 'gloomling'] }, { id: 'g5d2', x: 1300, z: 2000, kind: 'buzzbug', group: ['buzzbug'], y: 330 }]);
  }

  // ======================= THE SNORING THRONE: the royal clearing around the King's stump
  {
    const R = ROOMS.grove_throne;
    deep(R, 1500);
    R.groves = [[0, 250, 400, 1450], [1000, 1250, 400, 1450]];
    R.clear = [[260, 1000, -80, 1350]];   // the clearing itself stays clear for the King
    add(R, 'decor', [...ring('mushroom', 900, 900, 260, 14, 1.2), ...row('flag', 500, 600, 1100, 600, 4)]);
    add(R, 'chests', [{ id: 'gt_back', x: 900, z: 1250, give: { starPiece: 1 } }]);
  }

  // ======================= EMBER ROAD: the Ash Flats (lava pools, an island), the slopes behind the low rock, the far bank
  {
    const R = ROOMS.peak_1;
    deep(R, 2400);
    // (the lava river at the far end runs the whole way back; the old stepping stone is still the only way over)
    add(R, 'holes', [[300, 700, 1100, 1400], [880, 1260, 1700, 2100]]);
    add(R, 'plats', [[470, 450, 60, 1140, 1190], [480, 450, 60, 1230, 1280], [470, 450, 60, 1320, 1370], [1050, 450, 50, 1740, 1790]]);
    add(R, 'terrain', [T(1000, 1150, 1850, 1960, 440, { base: 520, mat: 'rock' }), T(150, 300, 1800, 1950, 340, { mat: 'rock' }), T(1650, 1950, 1500, 1700, 360, { mat: 'rock' })]);
    add(R, 'vents', [{ x: 1600, z: 1600 }]);
    add(R, 'npcs', [{ id: 'ash', x: 800, z: 800, kind: 'ember', name: 'Ash', talk: 'ash', opts: { look: 'kid', scale: 0.8 } }]);
    add(R, 'chests', [{ id: 'p1d_isle', x: 1075, z: 1900, give: { starPiece: 1 } }, { id: 'p1d_rock', x: 225, z: 1870, give: { item: 'fireseed' } },
      { id: 'p1d_slope', x: 1800, z: 1600, give: { coins: 20 } }, { id: 'p1d_far', x: 2450, z: 2200, give: { item: 'embertea', n: 2 } }]);
    add(R, 'blocks', [{ id: 'p1d_b1', x: 600, y: 300, z: 700, give: { coins: 6 } }]);
    add(R, 'signs', [{ x: 600, z: 340, text: 'The Ash Flats. The lava pools are hot. (Everything here is hot. This sign is hot.)' }]);
    add(R, 'enemies', [
      { id: 'p1d1', x: 500, z: 1600, kind: 'cinderling', group: ['cinderling', 'cinderling'] },
      { id: 'p1d2', x: 1800, z: 1000, kind: 'magmaw', group: ['magmaw'], range: 80 },
      { id: 'p1d3', x: 2400, z: 1500, kind: 'cinderling', group: ['cinderling', 'magmaw'] },
    ]);
  }

  // ======================= CINDER SPRINGS: a whole hot-spring village, a lava creek, the Steam Gardens
  {
    const R = ROOMS.peak_2;
    deep(R, 2800);
    R.hazard = 'lava';
    add(R, 'holes', [[0, R.w, 1950, 2060]]);
    add(R, 'plats', [[560, 450, 130, 1930, 2080], [1640, 450, 130, 1930, 2080]]);   // stone bridges over the lava creek
    add(R, 'props', [
      { kind: 'hotspring', x: 450, z: 1250 }, { kind: 'hotspring', x: 2000, z: 1500 }, { kind: 'hotspring', x: 900, z: 2500 },
      { kind: 'house', x: 350, z: 700, roof: '#c45a3a', wall: '#f3d6b6', wall2: '#d9b088' }, { kind: 'house', x: 650, z: 700, roof: '#e8a92a', wall: '#f3d6b6', wall2: '#d9b088' },
      { kind: 'house', x: 1900, z: 700, roof: '#a83a2a', wall: '#e0c4a8', wall2: '#b8967a' }, { kind: 'house', x: 2200, z: 750, roof: '#5a4e58', wall: '#f3d6b6', wall2: '#d9b088' },
      { kind: 'house', x: 1250, z: 1650, roof: '#c45a3a', wall: '#e0c4a8', wall2: '#b8967a' }, { kind: 'house', x: 1550, z: 1650, roof: '#e8a92a', wall: '#f3d6b6', wall2: '#d9b088' },
    ]);
    add(R, 'shops', [{ x: 2000, z: 1500, kind: 'spring', label: 'Soak' }]);
    add(R, 'plazas', [[950, 1650, 1000, 1450, '#b8a49a']]);
    R.roadColor = 'rgba(150,120,110,0.75)';
    add(R, 'roads', [[1300, 300, 1300, 1000, 90], [625, 1450, 625, 1930, 70], [1705, 1450, 1705, 1930, 70], [100, 1500, 2300, 1500, 70]]);
    add(R, 'decor', [...[1050, 1200, 1400, 1550].map(x => ({ kind: 'stall', x, z: 1380 }))]);
    // the Steam Gardens: ride a vent up onto the high rock
    add(R, 'vents', [{ x: 1150, z: 2400, period: 3 }]);
    add(R, 'terrain', [T(1250, 1450, 2350, 2500, 200, { mat: 'rock' }), T(1900, 2300, 2300, 2700, 380, { mat: 'rock' }), ramp(1750, 1900, 2400, 2600, 450, 380, 'east', 'rock')]);
    add(R, 'lamps', [{ x: 1300, z: 1100 }]);
    add(R, 'npcs', [
      { id: 'blaze', x: 1150, z: 1200, kind: 'ember', name: 'Blaze', talk: 'blaze', opts: { look: 'kid', scale: 0.65 } },
      { id: 'smolder', x: 520, z: 1050, kind: 'ember', name: 'Old Smolder', talk: 'smolder', opts: { look: 'granny', scale: 1.2 } },
      { id: 'sizzle', x: 1480, z: 1330, kind: 'ember', name: 'Sizzle', talk: 'sizzle', opts: { scale: 1.05 } },
      { id: 'puff', x: 2050, z: 1650, kind: 'kettle', name: 'Puff', talk: 'puff', flip: -1 },
    ]);
    add(R, 'chests', [{ id: 'p2d_steam', x: 1350, z: 2420, give: { starPiece: 1 } }, { id: 'p2d_rock', x: 2150, z: 2550, give: { coins: 25 } },
      { id: 'p2d_village', x: 120, z: 1100, give: { item: 'fireseed', n: 2 } }]);
    add(R, 'pots', [{ id: 'pot_p2a', x: 800, z: 900 }, { id: 'pot_p2b', x: 1750, z: 900 }]);
    add(R, 'piles', [{ id: 'pile_p2', x: 400, z: 2400 }]);
    add(R, 'signs', [{ x: 1300, z: 960, text: 'CINDER SPRINGS. Market square straight ahead, more hot springs all around, and the Steam Gardens across the lava creek.' }]);
    add(R, 'enemies', [{ id: 'p2d1', x: 600, z: 2500, kind: 'cinderling', group: ['cinderling', 'cinderling'] }, { id: 'p2d2', x: 2000, z: 2200, kind: 'magmaw', group: ['magmaw'], range: 70 }]);
  }

  // ======================= BRAZIER GATE: the Hall of Flames courtyard, a raised dais, the quiet side past the gate
  {
    const R = ROOMS.peak_3;
    deep(R, 2200);
    R.hazard = 'lava';
    add(R, 'holes', [[200, 1300, 1300, 1380]]);
    add(R, 'plats', [[340, 450, 120, 1280, 1400], [1000, 450, 120, 1280, 1400]]);
    add(R, 'terrain', [ramp(560, 760, 1600, 1750, 450, 360, 'north', 'stone'), T(450, 870, 1750, 2050, 360, { mat: 'stone' })]);
    add(R, 'decor', [...row('pillar', 300, 800, 1200, 800, 5), ...row('pillar', 300, 1150, 1200, 1150, 5), ...row('urn', 500, 1980, 820, 1980, 3)]);
    add(R, 'chests', [{ id: 'p3d_dais', x: 660, z: 1900, give: { starPiece: 1 } }, { id: 'p3d_quiet', x: 1650, z: 1800, give: { coins: 20 } }]);
    add(R, 'blocks', [{ id: 'p3d_h1', x: 1100, y: 300, z: 1000, hidden: true, give: { item: 'bighoney' } }]);
    add(R, 'signs', [{ x: 760, z: 600, text: 'The Hall of Flames. Long ago, the ember folk lit these pillars every night. Now they just stand around looking dramatic.' }]);
    add(R, 'enemies', [{ id: 'p3d1', x: 800, z: 1000, kind: 'cinderling', group: ['cinderling', 'jugglit'] }, { id: 'p3d2', x: 1100, z: 1700, kind: 'ashcrow', group: ['ashcrow'], y: 330 }]);
  }

  // ======================= LAVA FALLS: the far parts of each bank (the lava rivers run the whole way back)
  {
    const R = ROOMS.peak_4;
    deep(R, 2000);
    add(R, 'terrain', [T(1450, 1700, 1300, 1500, 360, { mat: 'rock' }), T(2350, 2600, 1200, 1400, 220, { mat: 'rock', base: 300 })]);
    add(R, 'chests', [{ id: 'p4d_a', x: 240, z: 1700, give: { coins: 20 } }, { id: 'p4d_b', x: 1575, z: 1400, give: { item: 'fireseed' } },
      { id: 'p4d_c', x: 2475, z: 1300, give: { starPiece: 1 } }, { id: 'p4d_vine', x: 2750, z: 1800, give: { item: 'bighoney' } }]);
    add(R, 'enemies', [{ id: 'p4d1', x: 1600, z: 1000, kind: 'slagbrute', group: ['slagbrute', 'cinderling'], range: 70 }, { id: 'p4d2', x: 2400, z: 1700, kind: 'jugglit', group: ['jugglit'] }]);
  }

  // ======================= CINDER CLIMB: rocky shelves going back, and a lookout over the crater
  {
    const R = ROOMS.peak_5;
    deep(R, 2000);
    add(R, 'holes', [[200, 600, 1200, 1500]]);
    add(R, 'terrain', [T(800, 1050, 1300, 1500, 320, { mat: 'rock', base: 402 }), T(2050, 2350, 1500, 1800, 250, { mat: 'rock', base: 330 })]);
    add(R, 'chests', [{ id: 'p5d_a', x: 400, z: 1700, give: { coins: 20 } }, { id: 'p5d_b', x: 925, z: 1400, give: { item: 'embertea', n: 2 } },
      { id: 'p5d_c', x: 2200, z: 1650, give: { starPiece: 1 } }]);
    add(R, 'enemies', [{ id: 'p5d1', x: 1500, z: 1200, kind: 'jugglit', group: ['jugglit', 'cinderling'] }, { id: 'p5d2', x: 2200, z: 1100, kind: 'ashcrow', group: ['ashcrow'], y: 250 }]);
  }

  // ======================= CINDERMAW'S CRATER: a lava lake fills the back of the crater
  {
    const R = ROOMS.peak_crater;
    deep(R, 1800);
    R.hazard = 'lava';
    add(R, 'holes', [[300, 1300, 900, 1720]]);
    add(R, 'terrain', [T(600, 760, 1200, 1340, 400, { base: 520, mat: 'rock' }), T(950, 1100, 1450, 1580, 380, { base: 520, mat: 'rock' })]);
    add(R, 'chests', [{ id: 'pc_rim', x: 150, z: 1600, give: { starPiece: 1 } }]);
  }

  // ======================= CASTLE GATE: the castle grounds (rose gardens, the moat and drawbridge, towers and the keep)
  {
    const R = ROOMS.castle_gate;
    deep(R, 2600);
    R.hazard = 'water';
    R.hazardY = 470;
    add(R, 'holes', [[0, R.w, 1000, 1140]]);
    add(R, 'plats', [[1240, 450, 120, 980, 1160]]);   // the drawbridge
    // the keep, its two towers and their battlements, right at the back
    add(R, 'walls', [
      [1000, 150, 600, 300, 2200, 2420], [880, 40, 120, 410, 2170, 2310], [1600, 40, 120, 410, 2170, 2310],
      ...Array.from({ length: 8 }, (_, i) => [1012 + i * 76, 118, 34, 32, 2200, 2236]),
      ...[880, 1600].flatMap(x => [[x + 6, 10, 30, 30, 2170, 2200], [x + 84, 10, 30, 30, 2170, 2200]]),
    ]);
    R.doors.find(d => d.to === 'castle_hall').z = 2196;
    add(R, 'hedges', [HEDGE(200, 600, 500, 530, 70), HEDGE(200, 600, 800, 830, 70), HEDGE(1000, 1500, 500, 530, 70), HEDGE(1000, 1500, 800, 830, 70)]);
    add(R, 'roads', [[1300, 300, 1300, 980, 100], [1300, 1160, 1300, 2190, 100]]);
    add(R, 'decor', [
      ...row('rosebush', 240, 650, 560, 650, 4), ...row('rosebush', 1040, 650, 1460, 650, 5), { kind: 'fountain', x: 800, z: 660 },
      ...row('flag', 900, 1700, 1700, 1700, 4), { kind: 'pillar', x: 1180, z: 2150 }, { kind: 'pillar', x: 1420, z: 2150 },
    ]);
    add(R, 'lamps', [{ x: 1450, z: 1250 }]);
    add(R, 'npcs', [{ id: 'hedgewick', x: 500, z: 720, kind: 'candle', name: 'Hedgewick', talk: 'hedgewick', opts: { wax: '#f6e2a8', wax2: '#d9b77a', specs: true } }]);
    add(R, 'chests', [{ id: 'cg_rose', x: 1500, z: 720, give: { coins: 20 } }, { id: 'cg_tower', x: 1780, z: 2400, give: { starPiece: 1 } },
      { id: 'cg_lawn', x: 300, z: 1800, give: { item: 'bighoney' } }]);
    add(R, 'bushes', [{ id: 'bush_cg1', x: 150, z: 1300 }, { id: 'bush_cg2', x: 1700, z: 1400 }]);
    add(R, 'signs', [{ x: 1150, z: 330, text: 'The castle grounds. The Great Hall is in the keep, over the moat at the back. Mind the moat. It is very wet.' }]);
    add(R, 'enemies', [
      { id: 'cg_d1', x: 700, z: 1600, kind: 'hollowarmor', group: ['hollowarmor'], range: 100 },
      { id: 'cg_d2', x: 1500, z: 1900, kind: 'hollowarmor', group: ['hollowarmor', 'dustbunny'], range: 100 },
      { id: 'cg_d3', x: 400, z: 400, kind: 'dustbunny', group: ['dustbunny', 'dustbunny'] },
    ]);
  }
}

// ---------------------------------------------------------------- the new folks out there
export const DEEP_SPEAKERS = {
  'Farmer Rye': 'folk', Sandy: 'folk', 'Gaslight Gus': 'candle', 'Grandpa Acorn': 'acorn', 'Picnic Pam': 'folk', 'Hermit Crag': 'folk',
  'Baker Bun': 'folk', 'Paperboy Scoop': 'folk', 'Old Sal': 'folk', 'Grandma Wix': 'candle', 'Lamplighter Lu': 'candle', 'Tinker Tess': 'folk',
  'Professor Twinkle': 'folk', 'Gatekeeper Bolt': 'folk', 'Gardener Petal': 'folk', 'Ranger Rowan': 'folk', 'Granny Hoo': 'hoot',
  'Royal Gardener Spore': 'folk', Ash: 'ember', Blaze: 'ember', 'Old Smolder': 'ember', Sizzle: 'ember', Puff: 'kettle', Hedgewick: 'candle',
};
export const DEEP_SPEAKER_OPTS = {
  'Farmer Rye': { color: '#e8b070', body: '#8a5a3c', hat: 'straw' }, Sandy: { color: '#ffb347', body: '#3b5a7b', hat: 'straw' },
  'Gaslight Gus': { wax: '#e8f0ff', wax2: '#b9c4e0', tall: true, specs: true }, 'Picnic Pam': { color: '#ff9ab0', body: '#5fae5c' },
  'Hermit Crag': { color: '#c8c2d4', body: '#5f5a52', hat: 'bucket' },
  'Baker Bun': { color: '#f6d6a8', body: '#e8a92a' }, 'Paperboy Scoop': { color: '#ffd23f', body: '#4f72bf', hat: 'bucket' },
  'Old Sal': { color: '#4f9fd6', body: '#3b5a7b', hat: 'bucket' }, 'Grandma Wix': { wax: '#fff0e0', wax2: '#e0c8b0', specs: true },
  'Lamplighter Lu': { wax: '#ffe6a8', wax2: '#e8c070', tall: true }, 'Tinker Tess': { color: '#c8c2d4', body: '#5a4e58', specs: true },
  'Professor Twinkle': { color: '#b49cff', body: '#2c3a6e', specs: true }, 'Gatekeeper Bolt': { color: '#9a93ad', body: '#5a4e68', hat: 'bucket' },
  'Gardener Petal': { color: '#ff9ab0', body: '#5fae5c', hat: 'straw' }, 'Ranger Rowan': { color: '#8be07a', body: '#4f7f58', hat: 'feather' },
  'Granny Hoo': { glasses: true }, 'Royal Gardener Spore': { color: '#c4a57a', body: '#8a5a3c', hat: 'straw' },
  Ash: { look: 'kid' }, Blaze: { look: 'kid' }, 'Old Smolder': { look: 'granny' }, Hedgewick: { wax: '#f6e2a8', wax2: '#d9b77a', specs: true },
};
export const DEEP_SCRIPTS = {
  rye: [
    ['say', 'Farmer Rye', "Barley's my cousin. He got the windmill, I got the barn out back. Back here it's quiet: just me, the crops, and the odd folded-up frog."],
    ['say', 'Farmer Rye', "If you like fishing, there's a pond west of the barn. And Lookout Hill past it has a telescope. Walk up the steps on its east side."],
  ],
  sandy: [
    ['say', 'Sandy', 'Welcome to the beach side of Mirror Lake! The islands out there are a hop, skip and a jump away. Literally. Three jumps.'],
    ['say', 'Sandy', "Gull Rock is the tall one. Getting up there takes some fancy jumping off Reed Island. There's a cove on the far shore too... if you can get across."],
  ],
  gus: [
    ['say', 'Gaslight Gus', "Evening. I used to light every lamp in this garden, every night. Then the Gloom came and I... stopped. It's hard to start again once you stop."],
    ['say', 'Gaslight Gus', "If you light them, I think I'll remember how. Walk up to a lamppost and press E. There's one up on the hill, too."],
  ],
  grandacorn: [
    ['say', 'Grandpa Acorn', "Hrmph. Young acorns these days, napping in the middle of the day. In my day we napped in the middle of the NIGHT, like civilized nuts."],
    ['say', 'Grandpa Acorn', "The Great Stump over yonder has something shiny on top. Hop up. Don't tell Nutkin I told you."],
  ],
  pam: [
    ['say', 'Picnic Pam', "Isn't it a lovely day for a picnic? I brought sandwiches. Well. I brought paper. Everything here is paper. They're paper sandwiches."],
    ['say', 'Picnic Pam', "If you climb the old watchtower, you can see all the way to the Paper Plains. The stone steps are on its west side."],
  ],
  crag: [
    ['say', 'Hermit Crag', "A visitor? Up here? Hm. I came up the mountain to be alone with my thoughts. Turns out my thoughts are mostly about snacks."],
    ['say', 'Hermit Crag', 'Glass Lake is good for thinking. The Snowcap is good for shivering. Somebody left a chest up there. Wasn\'t me. Probably.'],
  ],
  // ---- Lumen Town
  bun: [
    ['say', 'Baker Bun', 'Fresh paper bread! Crispy on the outside, papery on the inside. Free sniffs today.'],
    ['say', 'Baker Bun', "Since you lit the town back up, everybody's out in Lantern Square again. I haven't sold this much bread since before the Gloom."],
  ],
  scoop: [
    ['say', 'Paperboy Scoop', "Extra! Extra! Read all about it! ...Okay, there's no paper. I AM the newspaper. I just shout the news."],
    ['say', 'Paperboy Scoop', A => `Today's headline: ${A.rescuedCount()} folded-up folks rescued so far! ${A.rescuedCount() >= 10 ? "The Mayor's over the moon." : 'The Mayor says keep looking.'} Other news: the canal is still wet.`],
  ],
  sal: [
    ['say', 'Old Sal', "Best fishing in town, right off my little jetty. The fish are paper, so they're flat. Fits right in your pocket."],
    ['say', 'Old Sal', "Walk out on the jetty and press E to cast. And that raft out in the middle of the canal? Not mine. Nobody knows whose it is."],
  ],
  wix: [
    ['say', 'Grandma Wix', "Oh! A young candle. Sit, sit. I'm knitting a scarf for the bridge. Bridges get cold, you know."],
    ['say', 'Grandma Wix', "If you like treasure, dearie, that little island in the pond has had a chest on it since I was a wick. Hop over on the stepping stone."],
  ],
  lu: [
    ['say', 'Lamplighter Lu', "I light the street lamps every evening. And every morning. It's always evening here, so it's a LOT of lighting."],
    ['say', 'Lamplighter Lu', 'Any lamppost saves your game and heals you up. There are new ones in the square, in the park, up on Observatory Hill and by the North Gate.'],
  ],
  tess: [
    ['say', 'Tinker Tess', "Mind the crate! Actually, no, DON'T mind it. Push it around. That's what crates are for."],
    ['say', 'Tinker Tess', 'I left a jar of honey up on my loading dock and now I can\'t reach it. If only somebody pushed that crate over and climbed up...'],
  ],
  twinkle: [
    ['say', 'Professor Twinkle', "Ah, a visitor to Observatory Hill! Have a look through my telescope. You can see Count Dusk's Tower from here, way up north."],
    ['say', 'Professor Twinkle', 'Some nights I see a little light blinking at the very top of it. Like a lantern shard. Hmm. Probably a star. Probably.'],
  ],
  bolt: [
    ['if', A => !A.flag('ch1_done'), [
      ['say', 'Gatekeeper Bolt', "Halt! The North Gate stays shut until the Grumbling Grove wakes up. Orders are orders. Even if I'm the one who gave them."],
    ], [
      ['say', 'Gatekeeper Bolt', "The North Trail's open! Through the gate and keep walking until your nose gets cold. That's how you know you're there."],
    ]],
  ],
  // ---- out in the other places
  petal: [
    ['say', 'Gardener Petal', "Mothwick lets me tend his moth garden. The flowers glow at night so the moths can find them."],
    ['say', 'Gardener Petal', "...It's always night here, so the moths find them VERY easily. There's a stump out back with something shiny on it, too."],
  ],
  rowan: [
    ['say', 'Ranger Rowan', 'Welcome to Mossy Steps! The moss is soft, the steps are steep, and the stream is wet. That\'s the whole tour.'],
    ['say', 'Ranger Rowan', 'Up the glen there\'s the Mossy Stair: old stumps, each one a hop higher than the last. Somebody left a chest on the top one.'],
  ],
  grannyhoo: [
    ['say', 'Granny Hoo', "Hoo! A visitor. My grandson Hoot reads his books upside down. I read mine right side up. We disagree about a lot."],
    ['say', 'Granny Hoo', "These are the Owl Woods. We've nested in these great trees for a hundred years. There's a hill out back with a fine view. And a chest. Mostly a chest."],
  ],
  spore: [
    ['say', 'Royal Gardener Spore', "Welcome to the King's mushroom garden! Every toadstool here was planted by hand. My hand. It took forever."],
    ['say', 'Royal Gardener Spore', A => (A.flag('ch1_done') ? "The King's awake and he LOVES the garden. He told me so. Then he took a nap." : 'The King has been snoring for weeks. I keep the garden nice anyway. For when he wakes up.')],
  ],
  ash: [
    ['say', 'Ash', "Hot enough for you? The lava pools bubble when you're not looking. I've checked. A lot."],
    ['say', 'Ash', "There's a chest on a little island in the far pool. Hop the stone, then jump for it. Don't fall in. It's lava. Did I mention it's lava?"],
  ],
  blaze: [
    ['say', 'Blaze', "Whoa, a lantern! Are you the one who's gonna fix Cindermaw? Can I watch? I'll stand REALLY far back."],
    ['say', 'Blaze', 'Over the lava creek there are steam vents. Stand on one and WHOOSH! You fly! Mom says not to. I do it anyway.'],
  ],
  smolder: [
    ['say', 'Old Smolder', "Eh? Speak up, I'm a hundred and twelve. Back in my day, the volcano only erupted on weekends."],
    ['say', 'Old Smolder', 'If you want a good soak, there are more hot springs all over the village now. The one by the east houses is the warmest.'],
  ],
  sizzle: [
    ['say', 'Sizzle', 'Fresh lava cakes! Hot out of the volcano! ...You might want to let them cool for a few years.'],
    ['say', 'Sizzle', "The market's been busy since you came through. Folks are cooking again instead of hiding. That's thanks to you."],
  ],
  puff: [
    ['say', 'Puff', "Toot! I'm Kettle's little cousin. I whistle when I'm happy. TOOOOT. That means I'm happy."],
    ['say', 'Puff', "Kettle says you're never late. I'm always late. I'm a kettle. I take a while to get going."],
  ],
  hedgewick: [
    ['say', 'Hedgewick', "The Queen loved these gardens. I've kept every hedge trimmed for a whole year, even with nobody here to see them."],
    ['say', 'Hedgewick', "The Great Hall is inside the keep, over the drawbridge at the back. Watch out for the empty armor. It's been patrolling all year. Nobody told it to stop."],
  ],
};
