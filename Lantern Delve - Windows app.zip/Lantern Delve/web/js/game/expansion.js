// The Lumenfold expansion: houses and shops you can walk into, Old Lumen Castle, the Brightblade Dojo,
// the Bandit Den, new folks with new side quests, three mini-bosses and the Lost Pages of the Book of Lumenfold.
// data.js merges all of this into its tables.

// ---------------------------------------------------------------- helpers
const giver = (id, who, intro, remind, thanks) => [
  ['if', A => A.questDone(id), [['say', who, thanks]], [
    ['if', A => A.questReady(id), [['turnin', id], ['say', who, thanks]], [
      ['if', A => A.questActive(id), [['say', who, remind]], [
        ...intro, ['quest', id],
        ['if', A => A.questReady(id), [['say', who, 'Wait... you already did it?!'], ['turnin', id], ['say', who, thanks]]],
      ]],
    ]],
  ]],
];
const has = (A, k) => A.s.keyItems.includes(k);
const MAIL_FLAGS = ['mail_barley', 'mail_finn', 'mail_nutkin', 'mail_drip'];
const mailCount = A => MAIL_FLAGS.filter(f => A.flag(f)).length;
const HIDE_FLAGS = ['found_1', 'found_2', 'found_3', 'found_4', 'found_5'];
const foundCount = A => HIDE_FLAGS.filter(f => A.flag(f)).length;
const JEWELS = ['ruby', 'sapphire', 'emerald'];
const jewelCount = A => (A.flag('jewels_set') ? 3 : JEWELS.filter(k => has(A, k)).length);
export const visitedCount = A => Object.keys(A.s.visited || {}).length;
export const EXPLORE_GOAL = 35;
export const PAGES_GOAL = 10;

const GZ_FRONT = -80;   // the front edge of every floor (art2's GZ0)

// Each interior: a room box with a wallpaper style, furniture, and a doormat back outside.
const IN = (name, style, w, extra) => ({ name, theme: 'interior', style, interior: true, w, ground: [[0, w, 450]], exits: {}, ...extra });
const OUT = (to, toX, label, x = 120) => ({ x, to, toX, label, exit: true });

// ---------------------------------------------------------------- rooms
export const MORE_ROOMS = {
  // ======================= Lumen Town interiors
  inn_in: IN('Sleepy Wick Inn', 'inn', 1200, {
    area: 'town', music: 'home', icon: '🛏️', windows: [430, 800],
    doors: [OUT('pro_1', 260, 'Lumen Town')],
    furniture: [
      { kind: 'rug', x: 330, w: 210, color: '#5a7ac4', trim: '#fffaf0' },
      { kind: 'bed', x: 330, label: 'Rest', script: 'inn_rest' },
      { kind: 'fireplace', x: 680, label: 'Warm up', say: "Wick warms up by the fire. Toasty! (Wick is a candle, so he's always toasty. But it's still nice.)" },
      { kind: 'bed', x: 900, color: '#c45a5a' },
      { kind: 'table', x: 1010, cup: true, label: 'Read', say: "The guest book. Latest entries: 'Great beds! — Moss'. 'Too soft. — Pebble'. 'Who keeps writing BLORP? — Nana'." },
      { kind: 'clock', x: 1090 },
    ],
    npcs: [
      { id: 'tallow', x: 510, z: 30, kind: 'candle', name: 'Nana Tallow', talk: 'tallow', opts: { shawl: '#c45a8a', bun: true, wax: '#fff6e6' } },
      { id: 'snorbert', x: 800, z: 150, kind: 'candle', name: 'Snorbert', talk: 'snorbert', opts: { wax: '#e8f0ff', wax2: '#c6d4ee', mood: 'sleep', tall: true }, flip: -1 },
      { id: 'hide3', x: 1150, z: 210, kind: 'hidekid', name: 'Dot', talk: 'found_3', opts: { spot: 'plant' }, show: A => A.questActive('hideseek') && !A.flag('found_3') },
    ],
  }),
  goods_in: IN('Honeycomb Goods', 'shop', 1000, {
    area: 'town', music: 'home', icon: '🍯', windows: [780],
    doors: [OUT('pro_1', 580, 'Lumen Town')],
    furniture: [
      { kind: 'plant', x: 250 }, { kind: 'jars', x: 430 }, { kind: 'counter', x: 430, bell: true },
      { kind: 'barrel', x: 680, label: 'Look', say: 'A whole barrel of honey. Wick resists the urge to dive in. Barely.' },
      { kind: 'sacks', x: 880 },
    ],
    npcs: [{ id: 'bumble', x: 470, z: 100, kind: 'bee', name: 'Bumble', talk: 'bumble' }],
  }),
  bazaar_in: IN('Badge Bazaar', 'bazaar', 1000, {
    area: 'town', music: 'home', icon: '🎖️', windows: [300],
    doors: [OUT('pro_1', 900, 'Lumen Town')],
    furniture: [
      { kind: 'banner', x: 300, color: '#7b5fc7' }, { kind: 'counter', x: 460, color: '#7b5fc7', bell: true }, { kind: 'banner', x: 640, color: '#e5534b' },
      { kind: 'mirror', x: 770, label: 'Look', say: 'Wick admires his reflection. Crisp outline. Excellent flame. Ten out of ten.' },
      { kind: 'trophy', x: 900, label: 'Look', say: "A trophy: 'Best Badge Collection, Three Years Running.' Pinny made it herself." },
    ],
    npcs: [{ id: 'pinny', x: 480, z: 100, kind: 'pincushion', name: 'Pinny', talk: 'pinny' }],
  }),
  stars_in: IN('Star Exchange', 'stars', 1000, {
    area: 'town', music: 'home', icon: '⭐', night: true, windows: [580],
    doors: [OUT('pro_1', 1700, 'Lumen Town')],
    furniture: [
      { kind: 'globe', x: 280, label: 'Spin', say: "Wick spins the globe. It's a map of Lumenfold, and everything past the edge is labeled 'TOO FAR'." },
      { kind: 'counter', x: 440, color: '#3a4a8a' },
      { kind: 'telescope', x: 780, label: 'Look', script: 'telescope' },
    ],
    npcs: [{ id: 'twinkle', x: 450, z: 100, kind: 'starfolk', name: 'Twinkle', talk: 'twinkle' }],
  }),
  library_in: IN('Lumen Library', 'library', 1400, {
    area: 'town', music: 'home', icon: '📚', windows: [700],
    doors: [OUT('pro_1', 2000, 'Lumen Town')],
    plats: [[640, 340, 110], [800, 268, 110], [960, 196, 110]],
    furniture: [
      { kind: 'clock', x: 200 },
      { kind: 'bookshelf', x: 290, seed: 0, label: 'Read', say: "'A History of Lumenfold, Vol. 1: Paper.' Vol. 2 is also just 'Paper'. Vol. 3 is 'Scissors (Do Not Read)'." },
      { kind: 'bookshelf', x: 410, seed: 2, label: 'Read', say: "'Gloom: A Field Guide.' Chapter 1: 'It feels like resting, but it isn't.' Chapter 2 is unfinished. The author kept putting it off." },
      { kind: 'bookshelf', x: 530, seed: 4, label: 'Read', say: "'101 Badge Combos.' Someone wrote in the margin: 'Power Jump + Marathon Moth = OUCH.'" },
      { kind: 'bookshelf', x: 860, seed: 1 }, { kind: 'bookshelf', x: 1010, seed: 3 },
      { kind: 'table', x: 1140, candle: true, label: 'Read', say: "A sign-up sheet for Reading Hour. Every single name is 'Librarian Quill'." },
      { kind: 'globe', x: 1330 },
    ],
    npcs: [{ id: 'page', x: 1240, z: 60, kind: 'bookworm', name: 'Page', talk: 'page_worm' }],
    collect: [{ id: 'page_library', kind: 'page', x: 1015, y: 196 }],
  }),
  dojo_in: IN('Brightblade Dojo', 'dojo', 1100, {
    area: 'town', music: 'home', icon: '🥋', windows: [840],
    doors: [OUT('pro_1', 2700, 'Lumen Town')],
    furniture: [
      { kind: 'rug', x: 610, w: 360, z0: -50, z1: 90, color: '#3a6a8a', trim: '#fffaf0' },
      { kind: 'dummy', x: 290, label: 'Practice', script: 'dummy' },
      { kind: 'scroll', x: 440, seed: 1, label: 'Read', say: "The scroll says: 'Press SPACE as your attack LANDS, not before.' Underneath, smaller: 'Seriously. Not before.'" },
      { kind: 'scroll', x: 780, seed: 2, label: 'Read', say: "The scroll says: 'GUARD by pressing SPACE right before a hit. A SUPERGUARD is pressed at the very last instant, and hits back!'" },
      { kind: 'trophy', x: 960, label: 'Look', script: 'dojo_trophy' },
    ],
    npcs: [{ id: 'sensei', x: 610, z: 80, kind: 'matchstick', name: 'Sensei Strike', talk: 'sensei', flip: -1 }],
  }),
  twins_in: IN('The Dot House', 'cozy', 1100, {
    area: 'town', music: 'home', icon: '🏠', windows: [540],
    doors: [OUT('pro_1', 2980, 'Lumen Town')],
    furniture: [
      { kind: 'toybox', x: 280, label: 'Look', say: "A toy box. Inside: a paper yo-yo, a paper ball, and a note: 'DASH'S. NOT DOT'S. — Dash'." },
      { kind: 'rug', x: 560, w: 220, color: '#ffd23f', trim: '#e5534b' },
      { kind: 'painting', x: 560, pic: 'landscape', label: 'Look', say: "A painting of Lumen Fields, signed 'Dot, age 6'. It's very blue. Dot says the sky was VERY blue that day." },
      { kind: 'bed', x: 840, color: '#ff9ab0' },
      { kind: 'cookiejar', x: 1010, label: 'Peek', script: 'cookiejar' },
    ],
    npcs: [
      { id: 'mamadot', x: 420, z: 40, kind: 'inkdot', name: 'Mama Dot', talk: 'mama_dot', opts: { scale: 1.5 } },
      { id: 'biscuit', x: 690, z: 120, kind: 'cat', name: 'Biscuit', talk: 'biscuit' },
      { id: 'dot', x: 330, z: -20, kind: 'inkdot', name: 'Dot', talk: 'twin_dot', show: A => A.questDone('hideseek') },
      { id: 'dash', x: 920, z: 60, kind: 'inkdot', name: 'Dash', talk: 'twin_dash', opts: { variant: 'dash' }, show: A => A.questDone('hideseek'), flip: -1 },
    ],
  }),
  post_in: IN('Lumen Post Office', 'post', 1000, {
    area: 'town', music: 'home', icon: '✉️', windows: [780],
    doors: [OUT('pro_1', 3240, 'Lumen Town')],
    furniture: [
      { kind: 'counter', x: 410, color: '#5a7ac4', bell: true }, { kind: 'mailshelf', x: 600 },
      { kind: 'scale', x: 800, label: 'Weigh in', say: "Wick steps on the scale. Two grams. Flap whispers: 'Mostly flame.'" },
      { kind: 'sacks', x: 920 },
    ],
    npcs: [{ id: 'flap', x: 420, z: 100, kind: 'postman', name: 'Flap', talk: 'flap' }],
  }),
  moth_in: IN("Mothwick's House", 'mothwick', 1000, {
    area: 'outskirts', music: 'home', icon: '🏡', windows: [600],
    doors: [OUT('pro_3', 250, "Mothwick's Shed")],
    plats: [[700, 330, 120]],
    furniture: [
      { kind: 'bed', x: 320 },
      { kind: 'bookshelf', x: 480, seed: 5, label: 'Read', script: 'moth_journal' },
      { kind: 'table', x: 620, candle: true },
      { kind: 'painting', x: 870, pic: 'moth', label: 'Look', say: 'A portrait of Mothwick, posing heroically next to a lamp. He looks VERY proud of the lamp.' },
      { kind: 'clock', x: 950 },
    ],
    npcs: [{ id: 'hide4', x: 330, z: 118, kind: 'hidekid', name: 'Dash', talk: 'found_4', opts: { spot: 'bed' }, show: A => A.questActive('hideseek') && !A.flag('found_4') }],
    collect: [{ id: 'page_moth', kind: 'page', x: 760, y: 330 }],
  }),
  mill_in: IN('Inside the Windmill', 'mill', 1000, {
    area: 'fields', music: 'fields', icon: '🌾', windows: [520],
    doors: [OUT('fields_1', 2300, 'Lumen Fields')],
    plats: [[230, 360, 120], [420, 290, 120], [620, 220, 120], [430, 150, 120]],
    springs: [{ x: 880 }],
    furniture: [
      { kind: 'gears', x: 300 }, { kind: 'gears', x: 760 },
      { kind: 'sacks', x: 560, label: 'Look', say: "Flour sacks, stacked to the ceiling. One says 'EMERGENCY COOKIE FLOUR'." },
      { kind: 'barrel', x: 690 },
    ],
    chests: [{ id: 'mill_ch', x: 680, y: 220, give: { starPiece: 1 } }],
    collect: [{ id: 'page_mill', kind: 'page', x: 490, y: 150 }],
  }),
  hearth_in: IN("Hearth's Home", 'hearth', 1000, {
    area: 'peak', music: 'springs', icon: '🔥', windows: [420],
    doors: [OUT('peak_2', 1220, 'Cinder Springs')],
    plats: [[700, 330, 110]],
    furniture: [
      { kind: 'oven', x: 300, label: 'Look', say: "Granny Hearth's bread oven. The loaf inside has been 'almost ready' for a week. Wick decides not to rush it." },
      { kind: 'table', x: 520, food: true },
      { kind: 'painting', x: 640, pic: 'landscape', label: 'Look', say: 'A family portrait: Granny Hearth and thirty-one grandkids. Ember is a blur. Ember did not stand still.' },
      { kind: 'cookiejar', x: 900, label: 'Peek', script: 'cookiejar2' },
    ],
    collect: [{ id: 'page_hearth', kind: 'page', x: 755, y: 330 }],
  }),
  forge_in: IN("Annie's Forge", 'forge', 1000, {
    area: 'peak', music: 'springs', icon: '⚒️',
    doors: [OUT('peak_2', 1760, 'Cinder Springs')],
    furniture: [
      { kind: 'oven', x: 320 },
      { kind: 'anvil', x: 520, label: 'Look', say: "Annie's anvil. It has a sticky note on it: 'DO NOT HUG.'" },
      { kind: 'barrel', x: 680 }, { kind: 'crate', x: 750 },
    ],
    chests: [{ id: 'forge_ch', x: 880, give: { item: 'fireseed', n: 2 } }],
  }),

  // ======================= Old Lumen Castle (north of Lumen Fields, up Lantern Hill)
  castle_road: {
    name: 'Lantern Hill Road', area: 'castle', theme: 'hills', music: 'fields', w: 2600,
    ground: [[0, 760, 450], [760, 1400, 426], [1400, 2600, 402]],
    plats: [[1080, 300, 120], [1240, 230, 110], [1930, 150, 100]],
    lamps: [380],
    signs: [{ x: 250, text: 'Lantern Hill Road. North: Old Lumen Castle. (Closed since the Great Lantern went dark.)' }],
    blocks: [{ id: 'cr_b1', x: 520, y: 300, give: { coins: 5 } }, { id: 'cr_b2', x: 1273, y: 90, give: { item: 'windcookie' } }, { id: 'cr_h1', x: 1700, y: 262, hidden: true, give: { starPiece: 1 } }],
    bushes: [{ id: 'bush_cr1', x: 900 }, { id: 'bush_cr2', x: 2440 }],
    collect: [{ id: 'page_road', kind: 'page', x: 1980, y: 150 }],
    // a hedge across the front of the road: go around it at the back
    hedges: [{ x: 1500, w: 70, z0: GZ_FRONT, z1: 120, h: 110 }],
    chests: [{ id: 'z_road', x: 640, z: 220, give: { starPiece: 1 } }],
    enemies: [
      { id: 'cr_e1', x: 620, kind: 'gloomling', group: ['gloomling', 'gloomling'] },
      { id: 'cr_e2', x: 1330, kind: 'buzzbug', group: ['buzzbug', 'gloomling'], y: 340, range: 90 },
      { id: 'cr_e3', x: 1820, kind: 'dustbunny', group: ['dustbunny', 'dustbunny'] },
    ],
    doors: [
      { x: 120, to: 'fields_1', toX: 900, label: 'Lumen Fields' },
      { x: 2200, to: 'mtn_1', toX: 460, label: 'North Trail', need: 'ch1_done', needText: 'A rockslide blocks the mountain path. (It clears once the Grumbling Grove wakes up: finish Chapter 1.)' },
    ],
    exits: { right: { to: 'castle_gate', x: 60 } },
  },
  castle_gate: {
    name: 'Castle Gate', area: 'castle', theme: 'castle', w: 1800,
    ground: [[0, 1800, 450]],
    lamps: [460],
    signs: [{ x: 260, text: 'OLD LUMEN CASTLE. Visiting hours: never. — The Management (Sir Drip)' }],
    npcs: [
      { id: 'drip', x: 900, z: 60, kind: 'waxknight', name: 'Sir Drip', talk: 'drip', show: A => !A.flag('knight_down') || A.questDone('crown') },
    ],
    doors: [{ x: 1300, to: 'castle_hall', toX: 160, label: 'Great Hall', style: 'back' }],
    enemies: [{ id: 'cg_e1', x: 1600, kind: 'hollowarmor', group: ['hollowarmor'], range: 100 }],
    exits: { left: { to: 'castle_road', x: 2540 } },
  },
  castle_hall: IN('Great Hall', 'castle', 2200, {
    area: 'castle', icon: '🏰', windows: [300, 1430],
    lamps: [330],
    doors: [
      OUT('castle_gate', 1300, 'Castle Gate', 160),
      { x: 560, to: 'castle_kitchen', toX: 140, label: 'Royal Kitchen' },
      { x: 1100, to: 'castle_throne', toX: 200, label: 'Throne Room', need: 'jewels_set', lockScript: 'throne_door' },
      { x: 1700, to: 'castle_gallery', toX: 140, label: 'Portrait Gallery' },
      { x: 2020, to: 'castle_tower', toX: 140, label: 'East Tower' },
    ],
    furniture: [
      { kind: 'chandelier', x: 760 }, { kind: 'chandelier', x: 1440 },
      { kind: 'banner', x: 440 }, { kind: 'banner', x: 960, color: '#a8323e' }, { kind: 'banner', x: 1240, color: '#a8323e' }, { kind: 'banner', x: 1860 },
      { kind: 'armor', x: 820 }, { kind: 'armor', x: 1380 },
      { kind: 'painting', x: 680, pic: 'queen', label: 'Look', say: "A portrait of Queen Candela, lighting the Great Lantern. The plaque says: 'She never once lit it late.'" },
      { kind: 'painting', x: 1540, pic: 'castle', label: 'Look', say: 'A painting of this very castle, back when every window glowed.' },
      { kind: 'rug', x: 1100, w: 1000, z0: -40, z1: 60, color: '#a8323e', trim: '#ffd23f' },
    ],
    enemies: [
      { id: 'ch_e1', x: 860, kind: 'dustbunny', group: ['dustbunny', 'dustbunny'] },
      { id: 'ch_e2', x: 1540, kind: 'hollowarmor', group: ['hollowarmor', 'dustbunny'], range: 100 },
    ],
  }),
  castle_kitchen: IN('Royal Kitchen', 'hearth', 1300, {
    area: 'castle', windows: [500],
    doors: [OUT('castle_hall', 560, 'Great Hall', 140)],
    plats: [[960, 330, 120], [1120, 250, 120]],
    furniture: [
      { kind: 'oven', x: 380, label: 'Look', say: "The Royal Oven. It's cold. A note on it says: 'Start the bread. — Chef Crumb, one year ago.'" },
      { kind: 'jars', x: 640, color: '#e8e0f0' }, { kind: 'stove', x: 640 },
      { kind: 'table', x: 860, food: true },
      { kind: 'sacks', x: 1240 },
    ],
    npcs: [{ id: 'crumb', x: 760, z: 40, kind: 'chef', name: 'Chef Crumb', talk: 'crumb' }],
    pots: [{ id: 'pot_k1', x: 270 }, { id: 'pot_k2', x: 1040 }],
    chests: [{ id: 'k_sugar', x: 1180, y: 250, give: { key: 'sugar' } }],
    enemies: [{ id: 'ck_e1', x: 1020, kind: 'dustbunny', group: ['dustbunny', 'dustbunny', 'dustbunny'], range: 80 }],
  }),
  castle_gallery: IN('Portrait Gallery', 'castle', 1800, {
    area: 'castle',
    doors: [OUT('castle_hall', 1700, 'Great Hall', 140)],
    furniture: [
      { kind: 'painting', x: 380, pic: 'queen', plaque: '👑', label: 'Look', say: "Queen Candela. The plaque says: 'Her Majesty goes FIRST. Always.'" },
      { kind: 'painting', x: 640, pic: 'knight', plaque: '🛡️', label: 'Look', say: "Sir Drip, in his shining prime! The plaque says: 'Second to none... except the Queen.'" },
      { kind: 'painting', x: 900, pic: 'jester', plaque: '🃏', label: 'Look', say: "Jingles the Jester. The plaque says: 'Last, but LOUDEST!'" },
      { kind: 'chandelier', x: 1000 },
      { kind: 'sign2', x: 1080, text: 'PULL IN ORDER', label: 'Read', say: "A brass plate: 'The Royal Vault opens for those who know their place in line.'" },
      { kind: 'pedestal', x: 1690 },
    ],
    switches: [
      { id: 'lv_j', x: 1180, mark: '🃏', color: '#ffd23f', puzzle: 'gallery' },
      { id: 'lv_q', x: 1280, mark: '👑', color: '#e5534b', puzzle: 'gallery' },
      { id: 'lv_k', x: 1380, mark: '🛡️', color: '#4f72bf', puzzle: 'gallery' },
    ],
    puzzle: { id: 'gallery', order: ['lv_q', 'lv_k', 'lv_j'], flag: 'gallery_open', hint: 'The portraits! Their plaques say who goes first, second and last.' },
    gates: [{ x: 1480, w: 50, top: 170, flag: 'gallery_open' }],
    chests: [{ id: 'g_sapphire', x: 1600, give: { key: 'sapphire' } }],
    collect: [{ id: 'page_gallery', kind: 'page', x: 1740, y: 450 }],
    enemies: [{ id: 'cgl_e1', x: 560, kind: 'hollowarmor', group: ['hollowarmor', 'hollowarmor'], range: 120 }],
  }),
  castle_tower: IN('East Tower', 'castle', 1100, {
    area: 'castle', windows: [560],
    doors: [OUT('castle_hall', 2020, 'Great Hall', 140)],
    plats: [[260, 360, 120], [470, 290, 120], [280, 215, 120], [500, 145, 120], [720, 215, 100], [880, 145, 140]],
    furniture: [{ kind: 'banner', x: 700 }, { kind: 'armor', x: 960 }],
    chests: [{ id: 't_emerald', x: 950, y: 145, give: { key: 'emerald' } }],
    collect: [{ id: 'page_tower', kind: 'page', x: 120, y: 190 }],
    enemies: [
      { id: 'ct_e1', x: 760, kind: 'hollowarmor', group: ['hollowarmor'], range: 120 },
      { id: 'ct_e2', x: 620, kind: 'glowbat', group: ['glowbat', 'dustbunny'], y: 250, range: 80 },
    ],
  }),
  castle_throne: IN('Throne Room', 'throne', 1400, {
    area: 'castle', music: 'secret', windows: [500, 900],
    doors: [OUT('castle_hall', 1100, 'Great Hall', 200)],
    furniture: [
      { kind: 'rug', x: 760, w: 700, z0: -40, z1: 70, color: '#a8323e', trim: '#ffd23f' },
      { kind: 'banner', x: 380, color: '#a8323e' }, { kind: 'banner', x: 1240, color: '#a8323e' },
      { kind: 'chandelier', x: 700 },
      { kind: 'throne', x: 1100, glow: true },
    ],
    boss: { kind: 'gloomknight', x: 1000, flag: 'knight_down', scale: 1.6, awake: true },
    triggers: [{ id: 'knight', x: 600, script: 'knight_fight', when: A => !A.flag('knight_down') }],
    npcs: [
      { id: 'queen', x: 1100, z: 165, kind: 'queen', name: 'Queen Candela', talk: 'queen_after', show: A => A.flag('knight_down'), opts: { ghost: true, scale: 1.3 }, flip: -1 },
      { id: 'drip2', x: 880, z: 110, kind: 'waxknight', name: 'Sir Drip', talk: 'drip', show: A => A.flag('knight_down') && !A.questDone('crown'), opts: { proud: true } },
    ],
  }),

  // ======================= the Bandit Den (off the North Trail)
  den_1: {
    name: 'Bandit Den', area: 'mountain', theme: 'burrow', music: 'caves', w: 2000,
    ground: [[0, 2000, 450]],
    plats: [[700, 340, 120]],
    lamps: [260],
    signs: [{ x: 400, text: 'KEEP OUT. THIS MEANS YOU. (Unless you brought snacks.) — The Sticky Paws Gang' }],
    chests: [{ id: 'den_ch1', x: 760, y: 340, give: { coins: 25 } }],
    collect: [{ id: 'page_den', kind: 'page', x: 1880, y: 450 }],
    pots: [{ id: 'pot_d1', x: 1000 }],
    enemies: [
      { id: 'd1e1', x: 600, kind: 'raccoon', group: ['raccoon'] },
      { id: 'd1e2', x: 1200, kind: 'raccoon', group: ['raccoon', 'bombshroom'] },
      { id: 'd1e3', x: 1650, kind: 'raccoon', group: ['raccoon', 'raccoon'] },
    ],
    doors: [{ x: 140, to: 'mtn_1', toX: 2100, label: 'North Trail', style: 'hole' }],
    exits: { right: { to: 'den_2', x: 60 } },
  },
  den_2: {
    name: "Rocco's Hideout", area: 'mountain', theme: 'burrow', music: 'caves', w: 1300,
    ground: [[0, 1300, 450]],
    furniture: [{ kind: 'barrel', x: 300 }, { kind: 'sacks', x: 1150 }, { kind: 'crate', x: 1220 }, { kind: 'trophy', x: 1080 }],
    boss: { kind: 'rocco', x: 950, flag: 'rocco_down', scale: 1.5, awake: true },
    triggers: [{ id: 'rocco', x: 520, script: 'rocco_fight', when: A => !A.flag('rocco_down') }],
    npcs: [{ id: 'rocco_npc', x: 950, z: 40, kind: 'rocco', name: 'Rocco', talk: 'rocco_after', show: A => A.flag('rocco_down'), opts: { scale: 1.5, mood: 'worried', sack: false }, flip: -1 }],
    exits: { left: { to: 'den_1', x: 1940 } },
  },
};

// Changes to rooms that already existed: shops you can walk into, new paths, hide-and-seek spots and Lost Pages.
export function patchRooms(ROOMS) {
  const T = ROOMS.pro_1;
  T.w = 3400;
  T.ground = [[0, T.w, 450]];   // the street runs all the way to the new east end
  T.shops = [{ x: 1350, z: 135, kind: 'lantern', label: 'Pour ✦ Light' }];   // (the rest are walk-in now; this is the Great Lantern)
  T.props.find(p => p.sign === 'Library').closed = false;
  T.props.push(
    { kind: 'building', x: 2700, sign: 'Brightblade Dojo', roof: '#3a2a20', wall: '#f6ecd2', wall2: '#d8c49a', icon: '🥋' },
    { kind: 'building', x: 2980, sign: 'The Dot House', roof: '#e5534b', wall: '#d6ecd9', wall2: '#a8d0b0', icon: '🏠', w: 150, h: 120 },
    { kind: 'building', x: 3240, sign: 'Post Office', roof: '#3b5a7b', wall: '#dbe8f6', wall2: '#a8bcd8', icon: '✉️' },
  );
  const closed = 'CLOSED. (Everyone inside is hiding from the Gloom.)';
  T.doors.push(
    { x: 260, to: 'inn_in', toX: 170, label: 'Sleepy Wick Inn', style: 'none', need: 'prologue_done', needText: closed },
    { x: 580, to: 'goods_in', toX: 170, label: 'Honeycomb Goods', style: 'none', need: 'prologue_done', needText: closed },
    { x: 900, to: 'bazaar_in', toX: 170, label: 'Badge Bazaar', style: 'none', need: 'prologue_done', needText: closed },
    { x: 1700, to: 'stars_in', toX: 170, label: 'Star Exchange', style: 'none', need: 'prologue_done', needText: closed },
    { x: 2000, to: 'library_in', toX: 170, label: 'Lumen Library', style: 'none', need: 'prologue_done', needText: closed },
    { x: 2700, to: 'dojo_in', toX: 170, label: 'Brightblade Dojo', style: 'none', need: 'prologue_done', needText: closed },
    { x: 2980, to: 'twins_in', toX: 170, label: 'The Dot House', style: 'none', need: 'prologue_done', needText: closed },
    { x: 3240, to: 'post_in', toX: 170, label: 'Post Office', style: 'none', need: 'prologue_done', needText: closed },
  );
  T.signs.find(s => s.x === 2630).x = 3360;
  T.npcs.push(
    { id: 'inky', x: 1020, z: 70, kind: 'carto', name: 'Inky', talk: 'inky', show: A => A.flag('prologue_done') },
    { id: 'hide1', x: 1590, z: 175, kind: 'hidekid', name: 'Dot', talk: 'found_1', opts: { spot: 'barrel' }, show: A => A.questActive('hideseek') && !A.flag('found_1') },
  );
  // townsfolk stand around the square at different distances
  const townZ = { elder_town: 30, folk1: 90, folk2: 50, quill: 105, hazel: 15 };
  for (const n of T.npcs) if (townZ[n.id] != null) n.z = townZ[n.id];

  const O = ROOMS.pro_2;
  O.exits.left.x = 3340;
  O.collect = [...(O.collect || []), { id: 'page_path', kind: 'page', x: 365, y: 345 }];
  O.npcs.push({ id: 'hide2', x: 600, z: 190, kind: 'hidekid', name: 'Dash', talk: 'found_2', opts: { spot: 'bush' }, show: A => A.questActive('hideseek') && !A.flag('found_2') });

  // treasure tucked away at the back of places, for anyone who walks into the distance to look
  const back = (id, chest) => { ROOMS[id].chests = [...(ROOMS[id].chests || []), chest]; };
  back('pro_1', { id: 'z_town', x: 1430, z: 225, give: { coins: 15 } });
  back('pro_2', { id: 'z_path', x: 1000, z: 220, give: { item: 'honeybun', n: 2 } });
  back('fields_1', { id: 'z_fields', x: 2300, z: 232, give: { starPiece: 1 } });   // right behind the windmill
  back('grove_1', { id: 'z_grove1', x: 1800, z: 220, give: { coins: 12 } });
  back('grove_3', { id: 'z_grove3', x: 760, z: 228, give: { item: 'embertea', n: 2 } });   // behind Hoot's tree
  back('lake_1', { id: 'z_lake', x: 300, z: 215, give: { coins: 15 } });
  back('mtn_1', { id: 'z_trail', x: 1650, z: 220, give: { item: 'fireseed' } });
  back('cave_1', { id: 'z_cave', x: 1200, z: 210, give: { coins: 20 } });
  back('peak_2', { id: 'z_springs', x: 2300, z: 220, give: { item: 'bighoney' } });

  // hedges: one blocks the front of the Grove Gate path (walk around the back), one lines the back of the fields
  ROOMS.grove_1.hedges = [{ x: 1180, w: 70, z0: GZ_FRONT, z1: 130, h: 110 }];
  ROOMS.fields_1.hedges = [{ x: 420, w: 260, z0: 150, z1: 200, h: 70 }];

  ROOMS.pro_3.doors.push({ x: 250, to: 'moth_in', toX: 170, label: "Mothwick's House", style: 'none' });

  const F = ROOMS.fields_1;
  F.doors.push(
    { x: 900, to: 'castle_road', toX: 200, label: 'Lantern Hill' },
    { x: 2300, to: 'mill_in', toX: 170, label: 'Windmill', style: 'none' },
  );
  F.npcs.push({ id: 'hide5', x: 2560, z: 205, kind: 'hidekid', name: 'Dot', talk: 'found_5', opts: { spot: 'bush' }, show: A => A.questActive('hideseek') && !A.flag('found_5') });
  F.signs[0].text = 'West: the Grumbling Grove. The side paths lead south to Mirror Lake and north up Lantern Hill.';

  ROOMS.lake_1.collect = [...(ROOMS.lake_1.collect || []), { id: 'page_lake', kind: 'page', x: 1995, y: 210 }];
  ROOMS.grove_4.collect = [...(ROOMS.grove_4.collect || []), { id: 'page_gap', kind: 'page', x: 1330, y: 330 }];
  ROOMS.cave_3.collect = [...(ROOMS.cave_3.collect || []), { id: 'page_ink', kind: 'page', x: 1400, y: 300 }];

  ROOMS.mtn_1.doors.push(
    { x: 460, to: 'castle_road', toX: 2200, label: 'Lantern Hill' },
    { x: 2100, to: 'den_1', toX: 140, label: 'Suspicious Cave', style: 'hole' },
  );

  ROOMS.peak_2.doors = [
    ...(ROOMS.peak_2.doors || []),
    { x: 1220, to: 'hearth_in', toX: 170, label: "Hearth's Home", style: 'none' },
    { x: 1760, to: 'forge_in', toX: 170, label: "Annie's Forge", style: 'none' },
  ];
}

// ---------------------------------------------------------------- enemies & mini-bosses
export const MORE_ENEMIES = {
  dustbunny: { name: 'Dust Bunny', hp: 3, atk: 1, def: 0, splits: true, xp: 10, coins: [1, 2], h: 46, lvl: 3,
    tattle: "A Dust Bunny. It's what happens when nobody cleans for a whole year. Hit it without finishing it and it splits in two! Max HP 3." },
  hollowarmor: { name: 'Hollow Armor', hp: 5, atk: 2, def: 2, knight: true, xp: 18, coins: [2, 4], h: 66, lvl: 4,
    tattle: "Hollow Armor: nobody's inside! Defense 2, so jumps just clank off. But a solid HAMMER hit knocks it over, and then it's wide open. Max HP 5." },
  gloomknight: { name: 'Gloom Knight', hp: 28, atk: 3, def: 2, boss: true, xp: 90, coins: [40, 40], h: 140, scale: 1.6, lvl: 7, dents: true, thorns: true,
    tattle: "The Gloom Knight: the Gloom wearing old armor like a coat. Defense 2, but every HAMMER hit dents it. When its shield glows, attacks bounce off. Jump when its helmet spikes are down! Max HP 28." },
  rocco: { name: 'Rocco', hp: 24, atk: 2, def: 0, boss: true, xp: 70, coins: [40, 40], h: 90, scale: 1.5, lvl: 7,
    tattle: "Rocco, boss of the Sticky Paws Gang. He swipes your items, hides in smoke and calls his gang. Beat him and you get back everything he took! Max HP 24." },
  sensei: { name: 'Sensei Strike', hp: 18, atk: 2, def: 0, boss: true, xp: 40, coins: [15, 15], h: 108, lvl: 6, spar: true,
    tattle: "Sensei Strike, master of the Brightblade Dojo. When his head is LIT, don't jump on him! In Counter Stance he hits back anything that touches him: Defend or use an item that turn. Max HP 18." },
  sensei2: { name: 'Sensei Strike', hp: 32, atk: 3, def: 1, boss: true, xp: 90, coins: [30, 30], h: 108, lvl: 10, spar: true,
    tattle: 'Sensei Strike, holding nothing back. Same tricks as before, but tougher, and his Wildfire Kata hits everyone. Max HP 32, Defense 1.' },
};

export const MORE_BADGES = {
  counter_strike: { name: 'Counter Strike', bp: 1, desc: 'Superguards hit back for 2 damage instead of 1.' },
  black_belt: { name: 'Black Belt', bp: 3, desc: '+1 ATK and +1 DEF.' },
  royal_crown: { name: 'Royal Crown', bp: 2, desc: 'Your partner deals +1 damage and takes 1 less damage.' },
  sweet_tooth: { name: 'Sweet Tooth', bp: 1, desc: 'Healing items restore 3 more HP.' },
  speedy: { name: 'Speedy Soles', bp: 0, desc: 'Wick walks 20% faster in the field. (Costs no BP!)' },
  treasure_sense: { name: 'Treasure Sense', bp: 0, desc: 'Hidden blocks and Lost Pages sparkle when you are close. (Costs no BP!)' },
  story_shield: { name: 'Story Shield', bp: 1, desc: 'The first hit you take in every battle does no damage.' },
};

export const MORE_KEY_ITEMS = {
  ruby: 'the Crown Ruby', sapphire: 'the Crown Sapphire', emerald: 'the Crown Emerald', sugar: "Chef Crumb's Sugar Bowl",
  jelly: "Bumble's Royal Jelly", letters: 'a bundle of letters',
};

// ---------------------------------------------------------------- side quests
// room: where the quest giver stands; goal: where you go to do it (both are used by the guide arrow).
export const MORE_QUESTS = {
  crown: { name: 'The Lost Crown Jewels', giver: 'Sir Drip', where: 'Castle Gate, up Lantern Hill', room: ['castle_gate', 900], goal: ['castle_hall'],
    desc: "The Gloom stole Queen Candela's crown and locked the Throne Room. Find the three Crown Jewels hidden around Old Lumen Castle, then face whatever is sitting on the throne.",
    progress: A => ({ done: A.flag('knight_down'), text: A.flag('jewels_set') ? 'Jewels placed: defeat the Gloom Knight' : `Crown Jewels: ${jewelCount(A)} of 3` }),
    targets: A => (A.flag('jewels_set') ? [['castle_throne', 600]] : jewelCount(A) >= 3 ? [['castle_hall', 1100]] : [
      !has(A, 'ruby') && !A.flag('crumb_done') && (has(A, 'sugar') ? ['castle_kitchen', 760] : A.s.opened.k_sugar ? ['castle_kitchen', 760] : ['castle_kitchen', 1180]),
      !has(A, 'sapphire') && ['castle_gallery', A.flag('gallery_open') ? 1600 : 1280],
      !has(A, 'emerald') && ['castle_tower', 950],
    ].filter(Boolean)),
    reward: { badge: 'royal_crown', starPieces: 2, coins: 30 } },
  heist: { name: 'The Honey Heist', giver: 'Bumble', where: 'Honeycomb Goods, Lumen Town', room: ['goods_in', 540], goal: ['den_2'],
    desc: "Somebody stole Bumble's Royal Jelly! Sticky raccoon prints lead out the North Gate to the North Trail. Find the Sticky Paws Gang's hideout.",
    progress: A => ({ done: has(A, 'jelly'), text: has(A, 'jelly') ? 'Royal Jelly recovered!' : A.flag('rocco_down') ? 'Ask Rocco about the jelly' : 'Find the thief' }),
    reward: { badge: 'sweet_tooth', coins: 30 } },
  mail: { name: 'Mail Call', giver: 'Flap', where: 'Post Office, Lumen Town', room: ['post_in', 500],
    desc: 'Deliver four overdue letters: Farmer Barley (Lumen Fields), Fisher Finn (Mirror Lake), Nutkin (Grove Gate) and Sir Drip (the castle up Lantern Hill).',
    progress: A => ({ done: mailCount(A) >= 4, text: `Letters delivered: ${mailCount(A)} of 4` }),
    targets: A => [['mail_barley', 'fields_1', 2400], ['mail_finn', 'lake_1', 1430], ['mail_nutkin', 'grove_1', 380], ['mail_drip', 'castle_gate', 900]]
      .filter(([f]) => !A.flag(f)).map(([, r, x]) => [r, x]),
    reward: { badge: 'speedy', coins: 20 } },
  hideseek: { name: 'Hide and Seek', giver: 'Mama Dot', where: 'The Dot House, Lumen Town', room: ['twins_in', 420],
    desc: "Dot and Dash are hiding in five spots: in town, on the Outskirts Path, in the Inn, at Mothwick's house and out by the windmill. Look for little eyes!",
    progress: A => ({ done: foundCount(A) >= 5, text: `Hiding spots found: ${foundCount(A)} of 5` }),
    targets: A => [['found_1', 'pro_1', 1590], ['found_2', 'pro_2', 600], ['found_3', 'inn_in', 1150], ['found_4', 'moth_in', 330], ['found_5', 'fields_1', 2560]]
      .filter(([f]) => !A.flag(f)).map(([, r, x]) => [r, x]),
    reward: { starPieces: 2, items: { bighoney: 2 } } },
  explorer: { name: 'Map the World', giver: 'Inky', where: 'Lumen Town plaza', room: ['pro_1', 1020],
    desc: `Discover ${EXPLORE_GOAL} different places. Press TAB to see your map: '???' spots are places you haven't found yet.`,
    progress: A => ({ done: visitedCount(A) >= EXPLORE_GOAL, text: `Places discovered: ${Math.min(EXPLORE_GOAL, visitedCount(A))} of ${EXPLORE_GOAL}` }),
    reward: { badge: 'treasure_sense', starPieces: 1 } },
  pages: { name: 'The Book of Lumenfold', giver: 'Page', where: 'Lumen Library, Lumen Town', room: ['library_in', 1240],
    desc: `Find ${PAGES_GOAL} of the 12 Lost Pages of the Book of Lumenfold. They're hidden up high, inside houses and in strange places all over the world.`,
    progress: A => { const n = A.collectedCount('page'); return { done: n >= PAGES_GOAL, text: `Lost Pages: ${n} of 12 (${PAGES_GOAL} needed)` }; },
    reward: { badge: 'story_shield', starPieces: 2 } },
};

// Where the old quests' givers stand, for the guide arrow.
export const QUEST_ROOMS = {
  study_first: { room: ['pro_1', 1490] }, study_clean: { room: ['pro_1', 1490] }, study_hero: { room: ['pro_1', 1490] }, study_marathon: { room: ['pro_1', 1490] },
  acorns: { room: ['grove_1', 380] }, windmill: { room: ['fields_1', 2400], goal: ['fields_1'] }, koi: { room: ['lake_1', 1430], goal: ['lake_1', 1680] },
  overdue: { room: ['pro_1', 2090], goal: ['lake_2'] }, fieldnotes: { room: ['pro_1', 2090] }, bramble: { room: ['pro_1', 2230], goal: ['maze_1'] },
  lamps: { room: ['pro_1', 1840] }, poem: { room: ['cave_studio', 930] }, embers: { room: ['peak_2', 1370] }, ontime: { room: ['peak_2', 880] },
  forge: { room: ['peak_2', 1910], goal: ['peak_4'] },
};

// Who has a "!" over their head (something new to say).
export function newsFor(A, n) {
  const quest = { Inky: 'explorer', Flap: 'mail', 'Mama Dot': 'hideseek', Page: 'pages', 'Sir Drip': 'crown' }[n.name];
  if (quest) return !A.questKnown(quest) || A.questReady(quest);
  if (n.name === 'Bumble') return A.flag('ch1_done') && (!A.questKnown('heist') || A.questReady('heist'));
  if (n.name === 'Sensei Strike') return !A.flag('met_sensei');
  if (n.name === 'Chef Crumb') return has(A, 'sugar');
  if (n.name === 'Rocco') return A.questActive('heist') && !has(A, 'jelly');
  return MAIL[n.name] ? A.questActive('mail') && !A.flag(MAIL[n.name][0]) : null;
}

// ---------------------------------------------------------------- deliveries (Mail Call)
const MAIL = {
  'Farmer Barley': ['mail_barley', [
    ['say', 'Farmer Barley', "A letter? For me? 'Dear Barley, your cookies are too good. Please stop. Signed, everybody's belly.'"],
    ['say', 'Farmer Barley', 'Heh. Heh heh. Nope! Not stopping.'],
  ]],
  'Fisher Finn': ['mail_finn', [
    ['say', 'Fisher Finn', "Mail! 'Dear Finn, the fish say hi.' ...Who wrote this? THE FISH?"],
    ['say', 'Fisher Finn', "...It's signed 'the fish'. I'm keeping this forever."],
  ]],
  Nutkin: ['mail_nutkin', [
    ['say', 'Nutkin', A => (A.flag('ch1_done') ? "A letter! 'Dear Nutkin, you're doing great.' ...aw. Going in my acorn box."
      : "zzz... huh? a letter... 'Dear Nutkin, wake up.' ...wow. rude. accurate, but rude... zzz")],
  ]],
  'Sir Drip': ['mail_drip', [
    ['say', 'Sir Drip', "A letter... for me? 'Dear Sir Drip, please stop waiting by the gate and come inside, it's warm. — Q.C.'"],
    ['say', 'Sir Drip', "...It's dated a year ago. Oh, Your Majesty. I really should have read my mail."],
  ]],
};

// Talking to someone can be interrupted by something more important (like their mail).
export function npcHook(A, n) {
  const m = MAIL[n.name];
  if (m && A.questActive('mail') && !A.flag(m[0])) {
    return [['narrate', `Wick hands over a letter.`], ...m[1], ['flag', m[0]], ['sfx', 'chime'],
      ['tip', A2 => `✉️ Letters delivered: ${mailCount(A2)} of 4${mailCount(A2) >= 4 ? '. Go see Flap at the Post Office!' : ''}`, 6]];
  }
  return null;
}

// ---------------------------------------------------------------- the Lost Pages
export const PAGE_TEXT = {
  page_library: "'The First Light.' Long ago, Lumenfold was folded paper in the dark. Then a brave matchstick struck the very first light. Everyone agreed: much better.",
  page_moth: "'The Great Lantern.' The Great Lantern was built from five Lumen Shards. As long as it glows, the Gloom can't settle in.",
  page_mill: "'Paper Folk.' Everyone in Lumenfold is made of paper, which is why the Rain Festival is very short and very nervous.",
  page_road: "'Queen Candela.' The castle on Lantern Hill was home to Queen Candela, who lit the Great Lantern every evening. Her knight, Sir Drip, never missed a single lighting.",
  page_tower: "'Waiting.' The Gloom loves waiting. 'When I feel ready.' 'When it's the perfect time.' The perfect time is a rumor. Start anyway.",
  page_gallery: "'Jingles the Jester.' The castle jester's only rule: if a joke isn't working, tell the next one faster. Somehow, this always worked.",
  page_path: "'The Gloom.' The Gloom doesn't attack. It whispers: 'Five more minutes.' 'Tomorrow is fine.' The best defense? Start something small. Right now.",
  page_lake: "'Mirror Lake.' The lake shows you as you are, not as you wish you were. The fish think this is very funny.",
  page_gap: "'The Origami Sage.' The Sage has folded himself into a thousand shapes. His favorite is still 'crane'. Cranes are patient. Also, he forgot how to unfold.",
  page_den: "'The Sticky Paws.' The Sticky Paws Gang steals things they don't even need. Rocco once stole a door. He still doesn't know what to do with it.",
  page_ink: "'Count Dusk.' Some say Count Dusk is the shadow of every 'I'll do it later' ever said. Others say he's grumpy because nobody invites him to parties.",
  page_hearth: "'The Hero of Homework.' The oldest page of all: 'When the Gloom returns, a Hero will rise. Not the strongest or the fastest. Just the one who keeps showing up.'",
};

// ---------------------------------------------------------------- speakers
export const MORE_SPEAKERS = {
  'Nana Tallow': 'candle', Snorbert: 'candle', Bumble: 'bee', Pinny: 'pincushion', Twinkle: 'starfolk', Page: 'bookworm',
  'Sensei Strike': 'matchstick', 'Mama Dot': 'inkdot', Dot: 'inkdot', Dash: 'inkdot', Biscuit: 'cat', Flap: 'postman', Inky: 'carto',
  'Sir Drip': 'waxknight', 'Chef Crumb': 'chef', 'Queen Candela': 'queen', Rocco: 'rocco', 'Gloom Knight': 'gloomknight',
};
export const MORE_SPEAKER_OPTS = {
  'Nana Tallow': { shawl: '#c45a8a', bun: true, wax: '#fff6e6' }, Snorbert: { wax: '#e8f0ff', wax2: '#c6d4ee', mood: 'sleep', tall: true },
  Dash: { variant: 'dash' }, 'Sir Drip': { mood: 'worried' }, 'Queen Candela': { glow: true }, Rocco: { mood: 'angry' },
  'Gloom Knight': { mood: 'angry' }, 'Sensei Strike': { mood: 'determined' },
};
// how big each kind is drawn in the dialogue portrait
export const PORTRAIT_SCALE = {
  candle: 1.9, bee: 1.7, pincushion: 2, starfolk: 1.6, bookworm: 1.6, matchstick: 1.25, inkdot: 2.2, cat: 2.2, postman: 1.7,
  carto: 2, waxknight: 1.7, chef: 1.6, queen: 1.3, rocco: 1.2, gloomknight: 0.95, hidekid: 2,
};

// ---------------------------------------------------------------- scripts
export const MORE_SCRIPTS = {
  // ---- the Inn
  tallow: [
    ['say', 'Nana Tallow', "Welcome to the Sleepy Wick Inn, dear! The bed's free for heroes. Rest any time. A good rest is part of the work, you know."],
    ['if', A => !A.flag('met_sensei'), [['say', 'Nana Tallow', 'Have you met Sensei Strike yet? His dojo is at the east end of town. He can make you stronger, if you can stand his push-ups.']], [
      ['if', A => !A.s.visited || !A.s.visited.castle_gate, [['say', 'Nana Tallow', "My Snorbert keeps dreaming about clanking armor up on Lantern Hill. That's the old castle, north of Lumen Fields. Nobody's been up there in a year."]], [
        ['say', 'Nana Tallow', 'Remember: lampposts save your game, but my beds are softer.'],
      ]],
    ]],
  ],
  inn_rest: [['rest', 'You snuggle into the comfiest bed in Lumenfold. Zzz... HP and FP fully restored!']],
  snorbert: [
    ['if', A => Math.random() < 0.34, [['say', 'Snorbert', 'zzz... five more minutes... no... ONE more minute... ...zzz']], [
      ['if', A => Math.random() < 0.5, [['say', 'Snorbert', 'zzz... clank... clank... a knight with no one inside... up on the hill... zzz']], [
        ['say', 'Snorbert', 'zzz... the jester... always goes... LAST... zzz... (He seems to be dreaming about portraits.)'],
      ]],
    ]],
  ],

  // ---- shops
  bumble: [
    ['if', A => A.flag('ch1_done') && !A.questKnown('heist'), [
      ['say', 'Bumble', "Bzz! Oh, a customer! Sorry, I'm all a-buzz. Someone stole my Royal Jelly last night!"],
      ['say', 'Bumble', 'Sticky paw prints went right out the North Gate. RACCOON prints! The Sticky Paws Gang hides somewhere on the North Trail.'],
      ['say', 'Bumble', "Get it back and I'll make it worth your while. Bzz-promise!"],
      ['quest', 'heist'],
    ]],
    ['if', A => A.questReady('heist'), [['turnin', 'heist'], ['unkey', 'jelly'], ['say', 'Bumble', "My Royal Jelly! You're the bee's knees! ...Do candles have knees?"]]],
    ['say', 'Bumble', 'Welcome to Honeycomb Goods! Everything is made with real honey. Even the stuff that should not be.'],
    ['shop', 'items'],
  ],
  pinny: [
    ['say', 'Pinny', 'Ooh, a new face! Every badge in here is hand-pinned. By me. Ouch. Worth it.'],
    ['shop', 'badges'],
  ],
  twinkle: [
    ['say', 'Twinkle', 'Twinkle twinkle, welcome! Trade your Star Pieces for rare badges. I polish each one by hand. I am also the polish.'],
    ['shop', 'stars'],
  ],
  telescope: [
    ['choose', '🔭 Look through the telescope at...', [
      ['🏰 The hill to the north-west', [['narrate', "An old castle sits on Lantern Hill, north of Lumen Fields. Something big and dark is moving behind a window... and a little candle in armor is standing by the gate, looking sad."]]],
      ["🌑 Count Dusk's Tower", [['narrate', "Far to the north, Count Dusk's Tower pokes into the clouds. Two shards glow at the very top. You can't get there yet... but someday."]]],
      ['🌙 The moon', [['narrate', "The moon. It's paper too. Somebody drew a smiley face on the back. You can only see it if you squint."]]],
    ]],
  ],

  // ---- the library
  page_worm: giver('pages', 'Page', [
    ['say', 'Page', "Oh! Hello! Mind the dust. I'm Page, the library's bookworm. I eat... I mean, I READ books."],
    ['say', 'Page', "Our oldest book, the Book of Lumenfold, lost its pages when the Great Lantern broke. Whoosh! Scattered everywhere."],
    ['say', 'Page', "Each page tells a bit of Lumenfold's story. Find 10 of the 12 and I can rebind it! Look up high, inside houses, in odd little places."],
  ], A => `Lost Pages found: ${A.collectedCount('page')} of 12, and I need 10. They glow a little. Try up high, and inside houses! (There's one on top of my shelves, too.)`,
  'The Book of Lumenfold, whole again! Well, mostly whole. I may have nibbled a corner. Here, you earned this.'),

  // ---- the dojo
  sensei: [
    ['if', A => !A.flag('met_sensei'), [
      ['say', 'Sensei Strike', 'Hm. A candle. You carry a flame... but do you know how to STRIKE?'],
      ['say', 'Sensei Strike', 'I am Sensei Strike. Three hundred years ago, I struck the very first light in Lumenfold. One quick strike. That is all it ever takes.'],
      ['say', 'Sensei Strike', 'Here, I train heroes. Coins and Star Pieces pay for training: harder hits, a tougher guard, a stronger partner.'],
      ['say', 'Sensei Strike', 'Beat me in a sparring match, and I will teach you the harder lessons.'],
      ['flag', 'met_sensei'],
    ]],
    ['dojo'],
  ],
  dummy: [['narrate', 'A straw training dummy with a target on its chest. (Whack it with your hammer: X!)']],
  dojo_trophy: [
    ['narrate', A => (A.flag('dojo2') ? "The Brightblade Cup. Your name is engraved on it twice! Sensei must have done it while you weren't looking."
      : A.flag('dojo1') ? "The Brightblade Cup. Your name is engraved on it! Underneath: 'Next: beat me with NO holding back.'"
        : "The Brightblade Cup. The plate says: 'Awarded to anyone who beats Sensei Strike in a sparring match.' It's very shiny and very empty.")],
  ],

  // ---- the Dot House and hide-and-seek
  mama_dot: [
    ['if', A => !A.flag('prologue_done'), [['say', 'Mama Dot', 'Shh, the twins are scared of the dark. We\'re hiding under the blankets.']], [
      ['if', A => !A.questKnown('hideseek'), [
        ['say', 'Mama Dot', "Oh, hello dear! You haven't seen my twins, have you? Dot and Dash?"],
        ['say', 'Mama Dot', "They're playing hide-and-seek. They've been hiding for three days. They're VERY good at it."],
        ['say', 'Mama Dot', "They like five spots: somewhere in town, on the Outskirts Path, in the Inn, at Mothwick's house, and out by the windmill. Look for little eyes!"],
        ['quest', 'hideseek'],
      ], [
        ['if', A => A.questReady('hideseek'), [['turnin', 'hideseek'], ['say', 'Mama Dot', "All five! The twins say you're officially the best seeker in Lumenfold. They wanted you to have these."]], [
          ['if', A => A.questDone('hideseek'), [['say', 'Mama Dot', 'The twins finally came home. They want a rematch. Please say no. Please.']], [
            ['say', 'Mama Dot', A => `Hiding spots found: ${foundCount(A)} of 5. Try: in town, the Outskirts Path, the Inn, Mothwick's house, and by the windmill in Lumen Fields.`],
          ]],
        ]],
      ]],
    ]],
  ],
  found_1: [['say', 'Dot', "Eek! You found me! How?! I was being a BARREL!"], ['flag', 'found_1'], ['sfx', 'chime'], ['narrate', A => `Found Dot! (${foundCount(A)} of 5 hiding spots)`]],
  found_2: [['say', 'Dash', "No fair! I was being a bush! A really good bush!"], ['flag', 'found_2'], ['sfx', 'chime'], ['narrate', A => `Found Dash! (${foundCount(A)} of 5 hiding spots)`]],
  found_3: [['say', 'Dot', "You found me AGAIN?! I was being a plant this time! Plants don't even blink!"], ['flag', 'found_3'], ['sfx', 'chime'], ['narrate', A => `Found Dot! (${foundCount(A)} of 5 hiding spots)`]],
  found_4: [['say', 'Dash', "Hey! Mothwick said I could hide under his bed! ...okay, he didn't. He doesn't know I'm here."], ['flag', 'found_4'], ['sfx', 'chime'], ['narrate', A => `Found Dash! (${foundCount(A)} of 5 hiding spots)`]],
  found_5: [['say', 'Dot', "Aww! The windmill bush was my BEST spot! Okay, okay, we'll go home now."], ['flag', 'found_5'], ['sfx', 'chime'], ['narrate', A => `Found Dot! (${foundCount(A)} of 5 hiding spots)${foundCount(A) >= 5 ? ' Go tell Mama Dot!' : ''}`]],
  twin_dot: [['say', 'Dot', "Next time I'm hiding INSIDE the Great Lantern. You'll never find me there. (Please don't tell Mama.)"]],
  twin_dash: [['say', 'Dash', 'I was a bush. I was a GREAT bush. Admit it.']],
  biscuit: [
    ['sfx', 'meow'],
    ['narrate', A => ['Biscuit purrs and headbutts Wick. Wick\'s flame flickers happily. ♥', 'Biscuit rolls over. It\'s a trap. Wick knows it\'s a trap. Wick pets the belly anyway.', 'Biscuit stares at Wick\'s flame like it\'s the best toy ever invented.'][Math.floor(Math.random() * 3)]],
  ],
  cookiejar: [
    ['if', A => A.flag('jar_dots'), [['narrate', "Empty. There's a note: 'it wasnt me. — Dash'"]], [
      ['flag', 'jar_dots'], ['coins', 5], ['narrate', 'You find 5 coins under the cookies! (Mama Dot hides her savings here. She says you can keep them for finding the jar.)'],
    ]],
  ],
  cookiejar2: [
    ['if', A => A.flag('jar_hearth'), [['narrate', 'Empty, except for crumbs and a tiny, toasty note: "save some for Granny!"']], [
      ['flag', 'jar_hearth'], ['give', { items: { honeybun: 2 } }],
    ]],
  ],

  // ---- the Post Office
  flap: [
    ['if', A => !A.flag('prologue_done'), [['say', 'Flap', "Mail's closed! Too dark to fly. I crashed into the Inn twice."]], [
      ['if', A => !A.questKnown('mail'), [
        ['say', 'Flap', "Special delivery! ...Oh, you're not a letter. Hi! I'm Flap, the Lumen Post's fastest paper airplane."],
        ['say', 'Flap', "Since the Gloom came, I keep getting distracted mid-flight. Ooh, a cloud! Ooh, a bird! ...See? I've got four letters I never delivered."],
        ['say', 'Flap', 'Could you take them? Farmer Barley in Lumen Fields, Fisher Finn at Mirror Lake, Nutkin at the Grove Gate, and Sir Drip at the old castle up Lantern Hill.'],
        ['quest', 'mail'], ['key', 'letters'],
        ['narrate', 'You got a bundle of letters! Just talk to each person to hand theirs over.'],
      ], [
        ['if', A => A.questReady('mail'), [['turnin', 'mail'], ['unkey', 'letters'], ['say', 'Flap', "All four delivered?! You're faster than me! Here, take my spare soles. Zoom zoom."]], [
          ['if', A => A.questDone('mail'), [['say', 'Flap', 'Mail is flying again! I only crashed into the Inn once today. Progress!']], [
            ['say', 'Flap', A => `Letters delivered: ${mailCount(A)} of 4. Barley (Lumen Fields), Finn (Mirror Lake), Nutkin (Grove Gate), Sir Drip (castle, up Lantern Hill).`],
          ]],
        ]],
      ]],
    ]],
  ],

  // ---- the cartographer
  inky: giver('explorer', 'Inky', [
    ['say', 'Inky', "A traveler! I'm Inky, Lumenfold's official mapmaker. Unofficially? I'm a little lost."],
    ['say', 'Inky', 'My maps are full of blank spots. Every new place you visit fills in a bit more. Press TAB any time to look at the map!'],
    ['say', 'Inky', `Discover ${EXPLORE_GOAL} different places, inside and out, and I'll teach you my secret trick for finding treasure.`],
  ], A => `Places discovered: ${Math.min(EXPLORE_GOAL, visitedCount(A))} of ${EXPLORE_GOAL}. On your map (TAB), '???' marks a place next to one you know. Houses count too!`,
  "Look at this map! It's practically a work of art. A messy, wonderful work of art. Here's my trick: a badge that makes hidden treasure sparkle."),

  // ---- Mothwick's house
  moth_journal: [
    ['narrate', "Mothwick's journal. 'Day 1: The Lantern broke. Day 2: Still broken. Day 3: Found a really nice lamp. Not the point. Focus, Mothwick.'"],
    ['narrate', "'Day 4: Little Wick's flame is still burning. Somewhere, someone is working hard. I can feel it. I believe in them.'"],
  ],

  // ---- Old Lumen Castle
  drip: [
    ['if', A => A.questDone('crown'), [['say', 'Sir Drip', 'The castle is open again! Visiting hours: always. I made a new sign. It is only slightly melted.']], [
      ['if', A => A.questReady('crown'), [['turnin', 'crown'], ['say', 'Sir Drip', 'For you, from the Royal Treasury. Her Majesty insisted. She has the best ideas. She always did.']], [
        ['if', A => A.questActive('crown'), [
          ['say', 'Sir Drip', A => (A.flag('jewels_set') ? 'The Throne Room is open... and something is sitting on the Queen\'s throne. Be careful, little candle.'
            : `Crown Jewels found: ${jewelCount(A)} of 3. The Ruby was in the kitchen, the Sapphire in the Portrait Gallery, the Emerald up the East Tower. Then put them in the Throne Room door!`)],
        ], [
          ['say', 'Sir Drip', '*drip* ...Oh! A visitor. Forgive me. I am Sir Drip, Knight of the Lantern. Well. I was.'],
          ['say', 'Sir Drip', 'When Count Dusk broke the Great Lantern, the Gloom crept into our castle. It stole Queen Candela\'s crown and locked itself in the Throne Room.'],
          ['say', 'Sir Drip', 'I have been standing here ever since. Waiting for... the right moment. Waiting to feel ready. I melted a little. From all the waiting.'],
          ['say', 'Sir Drip', 'The Throne Room door needs the three Crown Jewels. They are somewhere inside. Would you... could you help an old candle start?'],
          ['quest', 'crown'],
          ['tip', 'New area: Old Lumen Castle! The door behind Sir Drip leads into the Great Hall.', 8],
        ]],
      ]],
    ]],
  ],
  throne_door: [
    ['if', A => A.questActive('crown') && JEWELS.every(k => has(A, k)), [
      ['narrate', 'You press the three Crown Jewels into the sockets: red... blue... green...'],
      ['sfx', 'chime'], ['unkey', 'ruby'], ['unkey', 'sapphire'], ['unkey', 'emerald'],
      ['cut', 'gate_open'], ['flag', 'jewels_set'],
      ['narrate', 'The great doors of the Throne Room swing open!'],
    ], [
      ['narrate', A => `A huge door with three empty sockets: red, blue and green. ${A.questKnown('crown') ? `You have ${jewelCount(A)} of the 3 Crown Jewels.` : 'Maybe the knight at the gate knows about this.'}`],
    ]],
  ],
  crumb: [
    ['if', A => has(A, 'ruby') || A.flag('jewels_set') || A.flag('crumb_done'), [['say', 'Chef Crumb', 'Mmm, smell that? Bread! I started it an hour ago. It took me a whole YEAR to start it. Worth it.']], [
      ['if', A => has(A, 'sugar'), [
        ['say', 'Chef Crumb', 'MY SUGAR BOWL! Oh, you beautiful little candle!'],
        ['unkey', 'sugar'],
        ['say', 'Chef Crumb', "Here, take this shiny red thing. I've been using it as a paperweight. Sir Drip says it's 'a priceless Crown Jewel'. Whatever."],
        ['key', 'ruby'], ['flag', 'crumb_done'], ['sfx', 'fanfare'],
        ['narrate', 'You got the Crown Ruby! (1 of the 3 Crown Jewels)'],
      ], [
        ['say', 'Chef Crumb', "Welcome to the Royal Kitchen! I'm Chef Crumb. I WOULD bake you something, but..."],
        ['say', 'Chef Crumb', '...those Dust Bunnies hid my sugar bowl on the high shelf. I keep MEANING to climb up there. For a year now.'],
        ['say', 'Chef Crumb', "Fetch it for me? I'll trade you something shiny for it."],
      ]],
    ]],
  ],
  gallery_open: [['wait', 0.3], ['cut', 'gate_open'], ['narrate', 'Click... click... CLICK! The vault gate rumbles open!']],
  knight_fight: [
    ['say', 'Gloom Knight', 'WHO DISTURBS THE THRONE? ...Oh. A candle. How... DIM.'],
    ['say', 'Gloom Knight', 'This crown is MINE now. Its glow is so comfy. So cozy. Why would anyone ever leave this room? Why do ANYTHING?'],
    ['if', A => A.s.partner === 'hoot', [['say', 'Hoot', "Wick, that armor is EMPTY. The Gloom is wearing it like a coat! A hammer should dent it."]]],
    ['if', A => A.s.partner === 'moss', [['say', 'Moss', 'blorp. tin can man. i will bonk the tin can.']]],
    ['if', A => A.s.partner === 'pebble', [['say', 'Pebble', '...big empty armor. rocks are never empty. rocks win.']]],
    ['if', A => A.s.partner === 'ember', [['say', 'Ember', "It's just sitting there doing NOTHING? Okay, that bugs me even more than doing everything at once!"]]],
    ['cut', 'boss_wake'],
    ['battle', ['gloomknight'], { boss: true }],
    ['say', 'Gloom Knight', 'My armor... my armor of excuses... dented... everywhere...'],
    ['narrate', 'The Gloom pours out of the armor like smoke. The armor clatters to the floor, empty. The crown rolls out... still glowing.'],
    ['flag', 'knight_down'],
    ['wait', 0.4],
    ['narrate', 'A warm light gathers above the throne...'],
    ['say', 'Queen Candela', '...Is it over? Is that my crown? Oh, little candle. Thank you.'],
    ['say', 'Queen Candela', 'When the Lantern broke, my knight waited for me to fix everything. And I waited for him. We both waited so long, we forgot that one of us could just... start.'],
    ['say', 'Sir Drip', 'Your Majesty! You... you came back!'],
    ['say', 'Queen Candela', 'Thanks to our hero. Sir Drip, give this candle something from the treasury. And from now on, the castle doors stay open.'],
  ],
  queen_after: [
    ['say', 'Queen Candela', A => (A.shards >= 3 ? "Three shards back in the Great Lantern. I can feel it from here. Count Dusk's tower is next, isn't it? Be brave. And take breaks."
      : 'The Great Lantern needs all five Lumen Shards. My castle is yours to rest in, little candle. Go on, then. One step at a time.')],
  ],

  // ---- the Bandit Den
  rocco_fight: [
    ['say', 'Rocco', "Well, well, well. A little candle, all the way in my hideout. You lost? Want me to steal you a map?"],
    ['if', A => A.questActive('heist'), [
      ['say', 'Rocco', "The Royal Jelly? Yeah, I took it. Don't even LIKE jelly. It was just RIGHT THERE, you know? Shiny. Sticky. Mine."],
    ], [['say', 'Rocco', 'Everything in here? Mine. That pile? Mine. That door? Also mine. Still figuring out what it\'s for.']]],
    ['say', 'Rocco', "Sticky Paws Gang! Let's show this candle how we GRAB!"],
    ['cut', 'boss_wake'],
    ['battle', ['rocco'], { boss: true }],
    ['say', 'Rocco', "Oof. Okay. OKAY! Truth is, I grab stuff and then I just... have it. Piles of it. It doesn't even make me happy."],
    ['say', 'Rocco', 'Maybe I should grab ONE thing I actually want. And then, like... use it.'],
    ['flag', 'rocco_down'],
    ['if', A => A.questActive('heist'), [['key', 'jelly'], ['sfx', 'fanfare'], ['narrate', "You got back Bumble's Royal Jelly! Bring it to Honeycomb Goods in Lumen Town."]]],
  ],
  rocco_after: [
    ['if', A => A.questActive('heist') && !has(A, 'jelly'), [
      ['say', 'Rocco', "Oh, the bee's jelly? Here. Take it. It was making my sack sticky anyway."],
      ['key', 'jelly'], ['sfx', 'fanfare'], ['narrate', "You got Bumble's Royal Jelly! Bring it to Honeycomb Goods."],
    ], [
      ['say', 'Rocco', "I made a pile called 'GIVE BACK'. It's huge. I'll start tomorrow. ...No. Today. One thing. Watch me. ...Okay, after this nap."],
    ]],
  ],
};
