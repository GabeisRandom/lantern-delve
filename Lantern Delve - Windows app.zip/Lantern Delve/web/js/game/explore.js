// The maps fill in as you explore (the user asked for it "like Mario & Luigi"). Each place is split into squares,
// CELL world units on a side (an old narrow room into a row of them), and the ones Wick walks near get drawn in on the
// minimap and the TAB map; the rest stay blank paper until he gets there. Water, lava and pits fill in all at once as
// soon as he reaches their edge (there's nowhere to walk out on them), and small rooms you can see all of from one
// spot count as seen the moment you walk in.
// The save keeps it in s.mapSeen: room id -> a base64 string of bits (one per square, front row first), or '*' when
// every square you can walk on has been seen. A save from before this counts every place it had been to as '*'.
import { ROOMS } from './data.js';
import { GZ0, GZ1 } from '../art2.js';

export const CELL = 200;
const SEE = 650;                    // how far around Wick fills in (world units)
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

export const isField = R => (R.z1 ?? GZ1) > GZ1 + 1;
// (the rooms whose maps fill in bit by bit: every big field, and the old narrow rooms that are long)
export const tracked = R => isField(R) || (!R.interior && R.w >= 1440);

export function grid(R) {
  const cols = Math.max(1, Math.ceil(R.w / CELL));
  const rows = isField(R) ? Math.max(1, Math.ceil(((R.z1 ?? GZ1) - GZ0) / CELL)) : 1;
  return { cols, rows };
}

const bit = (bits, i) => (bits[i >> 3] >> (i & 7)) & 1;
function encode(bits) { let s = ''; for (const b of bits) s += String.fromCharCode(b); return btoa(s); }
function decode(str, n) {
  const out = new Uint8Array(Math.ceil(n / 8));
  try { const s = atob(str); for (let i = 0; i < out.length && i < s.length; i++) out[i] = s.charCodeAt(i); } catch (e) { /* (a broken string: start over) */ }
  return out;
}

// Which squares have ground you can stand on (worked out once per room from where its floor, ponds and hills are).
const WALK = {};
function walkable(id) {
  if (WALK[id]) return WALK[id];
  const R = ROOMS[id], { cols, rows } = grid(R), field = isField(R), zb = R.z1 ?? GZ1;
  const out = new Uint8Array(cols * rows);
  const wade = R.wade && R.hazard === 'water';
  const inGap = (x, z) => (R.holes || []).some(h => x >= h[0] && x <= h[1] && z >= h[2] && z <= h[3] && !(wade && h[4] !== 'deep'));
  const onFloor = x => R.ground.some(g => x >= g[0] && x <= g[1]);
  const onHill = (x, z) => (R.terrain || []).some(t => x >= t.x0 && x <= t.x1 && z >= t.z0 && z <= t.z1);
  const onLedge = x => (R.plats || []).some(p => x >= p[0] && x <= p[0] + p[2]);
  for (let cz = 0; cz < rows; cz++) {
    for (let cx = 0; cx < cols; cx++) {
      let ok = false;
      for (let a = 0; a < 3 && !ok; a++) {
        for (let b = 0; b < 3 && !ok; b++) {
          const x = (cx + (a + 0.5) / 3) * CELL, z = GZ0 + (cz + (b + 0.5) / 3) * CELL;
          if (x > R.w || (field && z > zb)) continue;
          ok = field ? (onFloor(x) && !inGap(x, z)) || onHill(x, z) : onFloor(x) || onLedge(x);
        }
      }
      out[cz * cols + cx] = ok ? 1 : 0;
    }
  }
  return (WALK[id] = out);
}

// The squares seen in a room, decoded: { bits, cols, rows, gen }; or null when all of it shows (a small room, a
// place that's all filled in, or a save with no map memory at all).
const MASKS = {};
export function maskOf(s, id) {
  const R = ROOMS[id];
  if (!R || !s || !s.mapSeen || !tracked(R)) return null;
  const v = s.mapSeen[id] || '';
  if (v === '*') return null;
  const { cols, rows } = grid(R), m = MASKS[id];
  if (m && m.str === v && m.cols === cols && m.rows === rows) return m;
  return (MASKS[id] = { id, str: v, bits: decode(v, cols * rows), cols, rows, gen: (m ? m.gen : 0) + 1 });
}

const cellOf = (m, R, x, z) => [clamp(Math.floor(x / CELL), 0, m.cols - 1), isField(R) ? clamp(Math.floor((z - GZ0) / CELL), 0, m.rows - 1) : 0];
export function seenAt(m, R, x, z) {
  if (!m) return true;
  const [cx, cz] = cellOf(m, R, x, z);
  return !!bit(m.bits, cz * m.cols + cx);
}

// Fills in the squares around (x, z). True when something new got filled in.
export function reveal(s, id, x, z) {
  const R = ROOMS[id];
  if (!R || !s || !s.mapSeen || s.mapSeen[id] === '*') return false;
  if (!tracked(R)) { s.mapSeen[id] = '*'; return true; }
  const m = maskOf(s, id), field = isField(R), walk = walkable(id), n = m.cols * m.rows;
  const fresh = [];
  const set = i => { if (!bit(m.bits, i)) { m.bits[i >> 3] |= 1 << (i & 7); fresh.push(i); } };
  const [ccx, ccz] = cellOf(m, R, x, z), r = Math.ceil(SEE / CELL) + 1;
  for (let j = field ? -r : 0; j <= (field ? r : 0); j++) {
    for (let i = -r; i <= r; i++) {
      const cx = ccx + i, cz = ccz + j;
      if (cx < 0 || cx >= m.cols || cz < 0 || cz >= m.rows) continue;
      const mx = (cx + 0.5) * CELL, mz = GZ0 + (cz + 0.5) * CELL;
      if (field ? Math.hypot(mx - x, mz - z) > SEE : Math.abs(mx - x) > SEE + 150) continue;
      set(cz * m.cols + cx);
    }
  }
  if (!fresh.length) return false;
  // water, lava and pits: once you've seen an edge of one, all of it (squares with nowhere to stand, joined up)
  for (let q = 0; q < fresh.length; q++) {
    const i = fresh[q], cx = i % m.cols, cz = (i - cx) / m.cols;
    for (let dz = -1; dz <= 1; dz++) {
      for (let dx = -1; dx <= 1; dx++) {
        const nx = cx + dx, nz = cz + dz;
        if ((dx || dz) && nx >= 0 && nx < m.cols && nz >= 0 && nz < m.rows && !walk[nz * m.cols + nx]) set(nz * m.cols + nx);
      }
    }
  }
  let all = true;
  for (let i = 0; i < n && all; i++) if (walk[i] && !bit(m.bits, i)) all = false;
  m.str = s.mapSeen[id] = all ? '*' : encode(m.bits);
  m.gen++;
  return true;
}

// How much of a place you've explored, 0 to 100 (only the ground you can walk on counts), or null if it doesn't track.
export function exploredPct(s, id) {
  const R = ROOMS[id];
  if (!R || !s || !s.mapSeen || !tracked(R)) return null;
  if (s.mapSeen[id] === '*') return 100;
  const m = maskOf(s, id), walk = walkable(id);
  let all = 0, seen = 0;
  for (let i = 0; i < m.cols * m.rows; i++) if (walk[i]) { all++; if (bit(m.bits, i)) seen++; }
  return all ? Math.min(99, Math.round((100 * seen) / all)) : 100;
}

// ---------------------------------------------------------------- drawing the blank paper
// The mask as a tiny picture, one pixel per square (opaque where it's still unexplored), with a border copying the
// edge squares; scaled up smoothly it gives the paper soft, rounded edges.
export function maskCanvas(m) {
  if (m.cv && m.cvGen === m.gen) return m.cv;
  const cv = m.cv || document.createElement('canvas'), w = m.cols + 2, h = m.rows + 2;
  cv.width = w; cv.height = h;
  const c = cv.getContext('2d'), img = c.createImageData(w, h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const cx = clamp(x - 1, 0, m.cols - 1), cz = clamp(m.rows - y, 0, m.rows - 1);   // (the top row is the far back)
      img.data[(y * w + x) * 4 + 3] = bit(m.bits, cz * m.cols + cx) ? 0 : 255;
    }
  }
  c.putImageData(img, 0, 0);
  m.cv = cv; m.cvGen = m.gen;
  return cv;
}

// Cream paper with faint pencil hatching, as a pattern.
let TILE = null;
export function paperPattern(c) {
  if (!TILE) {
    TILE = document.createElement('canvas'); TILE.width = 24; TILE.height = 24;
    const g = TILE.getContext('2d');
    g.fillStyle = '#efe3c4'; g.fillRect(0, 0, 24, 24);
    g.strokeStyle = 'rgba(150,118,72,0.22)'; g.lineWidth = 2;
    for (const k of [0, 24, 48]) { g.beginPath(); g.moveTo(k - 30, 30); g.lineTo(k + 6, -6); g.stroke(); }
    g.fillStyle = 'rgba(150,118,72,0.18)';
    g.fillRect(5, 6, 2, 2); g.fillRect(16, 17, 2, 2);
  }
  const p = c.createPattern(TILE, 'repeat');
  if (p && p.setTransform && typeof DOMMatrix !== 'undefined') p.setTransform(new DOMMatrix().scaleSelf(0.5, 0.5));
  return p || '#efe3c4';
}

// Paints the paper into the canvas context f (already sized and scaled), over the unexplored squares. The squares sit
// between (left, top) and (right, bottom) in f's units, including the one-square border all round; the paper stays
// inside clip, the place's own outline (so it lies on the place like a sheet, and never past its edges).
export function paintFog(f, w, h, m, [left, top, right, bottom], clip, patternOffset = [0, 0]) {
  f.save();
  f.globalCompositeOperation = 'source-over';
  f.clearRect(0, 0, w, h);
  if (clip) { f.beginPath(); f.rect(clip[0], clip[1], clip[2] - clip[0], clip[3] - clip[1]); f.clip(); }
  const pat = paperPattern(f);
  if (typeof pat !== 'string' && pat.setTransform && typeof DOMMatrix !== 'undefined') {
    pat.setTransform(new DOMMatrix().translateSelf(patternOffset[0], patternOffset[1]).scaleSelf(0.5, 0.5));
  }
  f.fillStyle = pat; f.fillRect(0, 0, w, h);
  f.globalCompositeOperation = 'destination-in';
  f.imageSmoothingEnabled = true;
  if ('imageSmoothingQuality' in f) f.imageSmoothingQuality = 'low';   // (plain smoothing: soft enough, and quick)
  f.drawImage(maskCanvas(m), left, top, right - left, bottom - top);
  f.restore();
}

// Where the squares (with their border) go, and the place's outline, for a field seen from above or a narrow room from
// the side, given the map's x and y mapping (y: depth for a field, height for a side view) and the side view's top and
// bottom: { mask: [left, top, right, bottom], clip: [x0, y0, x1, y1] }.
export function fogRect(m, R, X, Y, top = 0, bottom = 0) {
  const left = X(-CELL), right = X((m.cols + 1) * CELL);
  if (!isField(R)) { const h = bottom - top; return { mask: [left, top - h, right, bottom + h], clip: [X(0), top - h, X(R.w), bottom + h] }; }
  return { mask: [left, Y(GZ0 + (m.rows + 1) * CELL), right, Y(GZ0 - CELL)], clip: [X(0), Y(R.z1 ?? GZ1), X(R.w), Y(GZ0)] };
}
