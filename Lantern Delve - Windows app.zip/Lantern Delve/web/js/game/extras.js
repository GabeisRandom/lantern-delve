// The side areas. The user asked for "more unique ideas, characters, and areas throughout the game": five new places,
// one in each part of Lumenfold, each with a new way to play, its own folks, and a side quest about something real
// from studying.
//   The Study Bridges (Lumen Fields): the bookend twins, Pairsley and Twain. Body doubling: ask your partner to wait on
//     a buddy pad and a bookshelf drawbridge comes down while they hold it.
//   The Pomodoro Mill (North Trail): Nonna Pomodoro and her grandson Timo. Focus and breaks: the mill runs on a big
//     tomato timer, and its gears only turn while it says FOCUS; the hammocks only come out on BREAK.
//   The Crystal Choir (Inkwell Caverns): Maestra Quartz and the geode kids. Practice: hammer the singing crystals to
//     play a melody back, a little longer each time.
//   The Chunky Quarry (Ember Peak): Chip the stonecutter. Breaking a big job into small ones: whack a boulder that's too
//     big to climb and it splits in two, and the pieces split again.
//   The Drowsy Downs (Midnight Moor): Woolly the cloud sheep and her dream lambs. Sleep: nap on a pillow and the downs
//     turn into their dream side, with other paths; wake up to switch back.
// How they play is in extras_play.js, the art in art6.js. After each quest its folks move into Lumen Town.

// ---------------------------------------------------------------- helpers
// A boulder in the Chunky Quarry splits into a left and a right half, each half as tall, until a piece is small enough
// to climb onto. Every piece has an id: 'q1' -> 'q1L' / 'q1R' -> 'q1LL'...
export const CLIMB = 150;   // (Wick's highest jump: anything taller than this needs another whack)
export function chunkTree(root) {
  const out = [];
  const add = (c, parent) => {
    out.push({ ...c, parent });
    if (c.h > CLIMB) {
      const w = c.w / 2, h = c.h / 2;
      add({ id: `${c.id}L`, x: c.x, w, h, base: c.base }, c.id);
      add({ id: `${c.id}R`, x: c.x + w, w, h, base: c.base }, c.id);
    }
  };
  add(root, null);
  return out;
}
export const LAMBS = ['lamb_nap', 'lamb_doze', 'lamb_snooze'];
const lambs = A => LAMBS.filter(id => A.flag(`got_${id}`)).length;
const songs = A => ['choir_g1', 'choir_g2', 'choir_done'].filter(f => A.flag(f)).length;
const NOTE_NAMES = ['red', 'orange', 'yellow', 'green', 'blue', 'purple'];
const hum = (set, seq, crystals) => seq.map(id => NOTE_NAMES[crystals.find(cr => cr.id === id).note]).join(', ');
export const IN = (name, style, w, extra) => ({ name, theme: 'interior', style, interior: true, w, ground: [[0, w, 450]], exits: {}, ...extra });

// ---------------------------------------------------------------- the rooms
const CHOIR_CRYSTALS = [
  { id: 'cr_a1', x: 380, note: 0, set: 'a' }, { id: 'cr_a2', x: 560, note: 2, set: 'a' }, { id: 'cr_a3', x: 740, note: 4, set: 'a' },
  { id: 'cr_b1', x: 1130, note: 1, set: 'b' }, { id: 'cr_b2', x: 1280, note: 3, set: 'b' }, { id: 'cr_b3', x: 1430, note: 0, set: 'b' }, { id: 'cr_b4', x: 1580, note: 5, set: 'b' },
  { id: 'cr_c1', x: 1930, note: 2, set: 'c' }, { id: 'cr_c2', x: 2060, note: 4, set: 'c' }, { id: 'cr_c3', x: 2190, note: 1, set: 'c' }, { id: 'cr_c4', x: 2320, note: 5, set: 'c' }, { id: 'cr_c5', x: 2450, note: 3, set: 'c' },
];
const MELODIES = {
  a: { kid: 'Pitch', seq: ['cr_a1', 'cr_a3', 'cr_a2'], flag: 'choir_g1', ok: 'choir_ok_a' },
  b: { kid: 'Tremolo', seq: ['cr_b2', 'cr_b1', 'cr_b4', 'cr_b3'], flag: 'choir_g2', ok: 'choir_ok_b' },
  c: { kid: 'Fermata', seq: ['cr_c3', 'cr_c1', 'cr_c4', 'cr_c2', 'cr_c5'], flag: 'choir_done', ok: 'choir_concert' },
};
const GEODE = { Pitch: '#7fb2ff', Tremolo: '#7cdc8a', Fermata: '#ffd23f' };

export const EXTRA_ROOMS = {
  // ======================= THE STUDY BRIDGES (off Lumen Fields)
  bud_1: {
    name: 'The Study Bridges', area: 'fields', theme: 'fields', w: 3000, noGlide: true,
    noGlideText: "The air over Babble Brook is too still to glide in. You'll need the shelves.",
    ground: [[0, 900, 450], [1200, 1900, 450], [2200, 2420, 450], [2720, 3000, 450]],
    hazard: 'water',
    lamps: [210],
    buddyPads: [{ id: 'bp1', x: 800, z: 70 }, { id: 'bp2', x: 1800, z: 70 }, { id: 'bp3a', x: 2280, z: 40 }, { id: 'bp3b', x: 2370, z: 140, held: 'twain_on_pad' }],
    buddyBridges: [{ id: 'bb1', x0: 900, x1: 1200, pads: ['bp1'] }, { id: 'bb2', x0: 1900, x1: 2200, pads: ['bp2'] }, { id: 'bb3', x0: 2420, x1: 2720, pads: ['bp3a', 'bp3b'] }],
    buddyDone: 'bookends_done',
    signs: [{ x: 640, text: "BABBLE BROOK. The Study Shelves only come down while somebody holds the counterweight. Stand by the open book and press E to ask your partner to wait there." }],
    npcs: [
      { id: 'twain_a', x: 430, z: 120, kind: 'bookend', name: 'Twain', talk: 'twain_talk', opts: { who: 'twain', mood: 'worried' }, show: A => !A.flag('twain_follows') },
      { id: 'twain_b', x: 1330, z: 150, kind: 'bookend', name: 'Twain', talk: 'twain_b', opts: { who: 'twain' }, show: A => A.flag('twain_follows') && !A.flag('twain_on_pad') },
      { id: 'twain_c', x: 2370, z: 140, kind: 'bookend', name: 'Twain', talk: 'twain_c', opts: { who: 'twain', mood: 'determined' }, show: A => A.flag('twain_on_pad') && !A.flag('bookends_done') },
      { id: 'pairsley_a', x: 2860, z: 120, kind: 'bookend', name: 'Pairsley', talk: 'pairsley_a', opts: { who: 'pairsley', mood: 'worried' }, flip: -1, show: A => !A.flag('bookends_done') },
      { id: 'pairsley_b', x: 2840, z: 120, kind: 'bookend', name: 'Pairsley', talk: 'twins_after', opts: { who: 'pairsley', mood: 'happy' }, flip: 1, show: A => A.flag('bookends_done') },
      { id: 'twain_d', x: 2900, z: 120, kind: 'bookend', name: 'Twain', talk: 'twins_after', opts: { who: 'twain', mood: 'happy' }, flip: -1, show: A => A.flag('bookends_done') },
    ],
    chests: [{ id: 'bud_ch', x: 2970, give: { starPiece: 1 } }],
    doors: [{ x: 120, to: 'fields_1', toX: 1200, label: 'Lumen Fields', exit: true }],
    triggers: [
      { id: 'bud_in', x: 280, script: 'bud_enter', once: true },
      { id: 'twain_cross', x: 1260, script: 'twain_cross', once: true, when: A => A.flag('twain_met') },
      { id: 'twin_shelf', x: 2230, script: 'twin_shelf', once: true, when: A => A.flag('twain_follows') },
      { id: 'reunion', x: 2770, script: 'bookends_reunion', once: true, when: A => A.flag('twain_on_pad') },
    ],
  },

  // ======================= THE POMODORO MILL (off the North Trail)
  pomo_1: IN('The Pomodoro Mill', 'mill', 2700, {
    area: 'mountain', noGlide: true, noBoost: true, hazard: 'gears',
    noGlideText: "There's no breeze in the mill to glide on. Ride the gears!",
    noBoostText: "Moss: Spring up there, with all those gears? I'd be flattened into a pancake!",
    ground: [[0, 760, 450], [1060, 1300, 450], [1600, 1840, 450], [2340, 2700, 450]],
    pomodoro: { focus: 8, brk: 4 },
    // [x, y, w, 'focus' | 'break']: gear belts turn while the timer says FOCUS; hammocks come out on the BREAK
    timedPlats: [[790, 430, 100, 'focus'], [935, 430, 100, 'focus'], [1330, 430, 100, 'break'], [1470, 430, 100, 'break'],
      [1870, 430, 90, 'focus'], [1995, 430, 90, 'focus'], [2235, 430, 90, 'break']],
    plats: [[2115, 430, 90]],   // (the rest bench halfway over the last gap is always there)
    dial: { x: 470, y: 205 },
    furniture: [{ kind: 'barrel', x: 150 }, { kind: 'sacks', x: 640 }, { kind: 'barrel', x: 2620 }],
    signs: [{ x: 640, text: "THE POMODORO MILL. FOCUS: the gears turn (hop on!). BREAK: the gears rest, and the hammocks come out. Rest on the benches between." }],
    npcs: [
      { id: 'nonna_mill', x: 300, kind: 'nonna', name: 'Nonna Pomodoro', talk: 'nonna_talk', show: A => !A.flag('pomo_done') },
      { id: 'timo_mill', x: 2520, kind: 'nonna', name: 'Timo', talk: 'timo_talk', opts: { kid: true, mood: 'sleep' }, flip: -1, show: A => !A.flag('pomo_done') },
      { id: 'timo_after', x: 2520, kind: 'nonna', name: 'Timo', talk: 'timo_after', opts: { kid: true, mood: 'happy' }, flip: -1, show: A => A.flag('pomo_done') },
    ],
    chests: [{ id: 'pomo_ch', x: 2640, give: { item: 'windcookie' } }],
    doors: [{ x: 120, to: 'mtn_1', toX: 700, label: 'North Trail', exit: true }],
    triggers: [{ id: 'pomo_in', x: 190, script: 'pomo_enter', once: true }],
  }),

  // ======================= THE CRYSTAL CHOIR (off the Echo Hall in the Inkwell Caverns)
  choir_1: {
    name: 'The Crystal Choir', area: 'caves', theme: 'cave', w: 2650,
    ground: [[0, 2650, 450]],
    crystals: CHOIR_CRYSTALS,
    melodies: MELODIES,
    gates: [{ x: 930, w: 50, top: 120, flag: 'choir_g1' }, { x: 1720, w: 50, top: 120, flag: 'choir_g2' }],
    lamps: [190],
    signs: [{ x: 300, text: "THE CRYSTAL CHOIR. The crystals sing when you tap them (X). Quiet, please: rehearsal in progress." }],
    npcs: [
      { id: 'quartz', x: 240, z: 150, kind: 'quartz', name: 'Maestra Quartz', talk: 'quartz_talk', show: A => !A.flag('choir_done') },
      { id: 'quartz_end', x: 2560, z: 150, kind: 'quartz', name: 'Maestra Quartz', talk: 'quartz_after', opts: { mood: 'happy' }, flip: -1, show: A => A.flag('choir_done') },
      { id: 'pitch', x: 860, z: 170, kind: 'geode', name: 'Pitch', talk: 'pitch_talk', opts: { color: GEODE.Pitch, mood: 'worried' }, flip: -1 },
      { id: 'tremolo', x: 1650, z: 170, kind: 'geode', name: 'Tremolo', talk: 'tremolo_talk', opts: { color: GEODE.Tremolo, mood: 'worried' }, flip: -1 },
      { id: 'fermata', x: 2560, z: 60, kind: 'geode', name: 'Fermata', talk: 'fermata_talk', opts: { color: GEODE.Fermata, mood: 'worried' }, flip: -1 },
    ],
    chests: [{ id: 'choir_ch', x: 2600, z: 200, give: { starPiece: 1 } }],
    doors: [{ x: 110, to: 'cave_2', toX: 450, label: 'Echo Hall', exit: true }],
    triggers: [{ id: 'choir_in', x: 170, script: 'choir_enter', once: true }],
  },

  // ======================= THE CHUNKY QUARRY (off Cinder Springs)
  quarry_1: {
    name: 'The Chunky Quarry', area: 'peak', theme: 'mountain', w: 2800, noBoost: true,
    noBoostText: "Moss: Way too tall to spring over! Better break them into smaller chunks.",
    ground: [[0, 2800, 450]],
    chunks: [{ id: 'q1', x: 620, w: 150, h: 260, base: 450, name: 'THE BIG ONE' }, { id: 'q2', x: 1300, w: 200, h: 400, base: 450, name: 'THE BIGGER ONE' },
      { id: 'q3', x: 2020, w: 280, h: 520, base: 450, name: 'THE BIGGEST ONE' }],
    lamps: [200],
    signs: [{ x: 360, text: "THE CHUNKY QUARRY. Too big to climb? Whack it (X). Still too big? Whack the pieces." }],
    npcs: [
      { id: 'chip_a', x: 470, kind: 'chip', name: 'Chip', talk: 'chip_talk', opts: { mood: 'worried' }, show: A => !A.broken('q1') },
      { id: 'chip_b', x: 1160, kind: 'chip', name: 'Chip', talk: 'chip_b', opts: { mood: 'determined' }, show: A => A.broken('q1') && !A.flag('quarry_q2') },
      { id: 'chip_c', x: 1880, kind: 'chip', name: 'Chip', talk: 'chip_c', opts: { mood: 'determined' }, show: A => A.flag('quarry_q2') && !A.flag('quarry_q3') },
      { id: 'chip_d', x: 2560, kind: 'chip', name: 'Chip', talk: 'chip_after', opts: { mood: 'happy', carve: true }, flip: -1, show: A => A.flag('quarry_q3') },
    ],
    chests: [{ id: 'quarry_ch', x: 2700, give: { item: 'fireseed' } }],
    doors: [{ x: 110, to: 'peak_2', toX: 1600, label: 'Cinder Springs', exit: true }],
    triggers: [
      { id: 'quarry_in', x: 180, script: 'quarry_enter', once: true },
      { id: 'quarry_end', x: 2480, script: 'quarry_done', once: true, when: A => A.flag('quarry_q3') },
    ],
  },

  // ======================= THE DROWSY DOWNS (off the Midnight Moor)
  dream_1: {
    name: 'The Drowsy Downs', area: 'tower', theme: 'night', w: 2850, noGlide: true, noBoost: true,
    noGlideText: "The sleepy air on the downs won't hold you up. Find another way across.",
    noBoostText: "Moss: *yawn* Too... sleepy... to spring...",
    ground: [[0, 900, 450], [1300, 1900, 450], [2300, 2850, 450]],
    hazard: 'gloom',
    pillows: [{ id: 'pl1', x: 760 }, { id: 'pl2', x: 1450 }, { id: 'pl3', x: 2440 }],
    dreamPlats: [[940, 410, 110], [1130, 380, 110], [2500, 335, 100], [2650, 255, 110]],
    awakePlats: [[1930, 430, 150], [2130, 430, 150]],
    dreamWalls: [[1660, 120, 44, 330]],   // (a hedge of Doomscroll thorns grows across the path, but only in dreams)
    lambs: [{ id: 'lamb_nap', x: 1185, y: 330 }, { id: 'lamb_doze', x: 1560, y: 410 }, { id: 'lamb_snooze', x: 2700, y: 205 }],
    lamps: [200],
    signs: [{ x: 600, text: "THE DROWSY DOWNS. Lie on a pillow (E) for a nap, and see the dream side. Some paths are only there in dreams. Some only when you're awake." }],
    npcs: [
      { id: 'woolly', x: 330, z: 140, kind: 'woolly', name: 'Woolly', talk: 'woolly_talk', show: A => !A.flag('dreams_done') },
      { id: 'woolly_end', x: 2620, z: 150, kind: 'woolly', name: 'Woolly', talk: 'woolly_after', opts: { mood: 'happy', dreamy: true }, flip: -1, show: A => A.flag('dreams_done') },
    ],
    chests: [{ id: 'dream_ch', x: 2790, give: { starPiece: 1 } }],
    doors: [{ x: 110, to: 'dusk_1', toX: 2900, label: 'Midnight Moor', exit: true }],
    triggers: [
      { id: 'downs_in', x: 180, script: 'downs_enter', once: true },
      { id: 'downs_end', x: 2560, script: 'downs_done', once: true, when: A => lambs(A) >= 3 },
    ],
  },
};

// ---------------------------------------------------------------- the way in, and who moves to town afterwards
export function patchExtras(ROOMS) {
  const add = (id, k, v) => { if (ROOMS[id]) ROOMS[id][k] = [...(ROOMS[id][k] || []), ...v]; };
  add('fields_1', 'doors', [{ x: 1200, z: 1050, to: 'bud_1', toX: 160, label: 'The Study Bridges' }]);
  add('fields_1', 'signs', [{ x: 1300, z: 990, text: "THE STUDY BRIDGES. Someone's crying down by Babble Brook..." }]);
  add('mtn_1', 'doors', [{ x: 700, z: 1100, to: 'pomo_1', toX: 160, label: 'The Pomodoro Mill' }]);
  add('mtn_1', 'signs', [{ x: 800, z: 1040, text: "THE POMODORO MILL. Focus Flour, freshly ground. (25 minutes on, 5 off. Nonna's orders.)" }]);
  add('cave_2', 'doors', [{ x: 450, to: 'choir_1', toX: 150, label: 'The Crystal Choir' }]);
  add('peak_2', 'doors', [{ x: 1600, z: 950, to: 'quarry_1', toX: 150, label: 'The Chunky Quarry' }]);
  add('peak_2', 'signs', [{ x: 1700, z: 890, text: "THE CHUNKY QUARRY. The best stone on Ember Peak. (The boulders are, ahem, a bit big.)" }]);
  add('dusk_1', 'doors', [{ x: 2900, z: 600, to: 'dream_1', toX: 150, label: 'The Drowsy Downs' }]);
  add('dusk_1', 'signs', [{ x: 3000, z: 540, text: "THE DROWSY DOWNS. Shh. (Nobody's asleep. That's the problem.)" }]);
  // after their quests, the new folks live in Lumen Town
  add('pro_1', 'npcs', [
    { id: 'pairsley_town', x: 2270, z: 600, kind: 'bookend', name: 'Pairsley', talk: 'twins_town', opts: { who: 'pairsley', mood: 'happy' }, show: A => A.questDone('buddies') },
    { id: 'twain_town', x: 2340, z: 600, kind: 'bookend', name: 'Twain', talk: 'twins_town', opts: { who: 'twain', mood: 'happy' }, flip: -1, show: A => A.questDone('buddies') },
    { id: 'nonna_town', x: 560, z: 400, kind: 'nonna', name: 'Nonna Pomodoro', talk: 'nonna_town', show: A => A.questDone('pomodoro') },
    { id: 'quartz_town', x: 2310, z: 1100, kind: 'quartz', name: 'Maestra Quartz', talk: 'quartz_town', opts: { conduct: true }, show: A => A.questDone('choir') },
    { id: 'pitch_town', x: 2390, z: 1080, kind: 'geode', name: 'Pitch', talk: 'geodes_town', opts: { color: GEODE.Pitch, sing: true }, flip: -1, show: A => A.questDone('choir') },
    { id: 'tremolo_town', x: 2450, z: 1120, kind: 'geode', name: 'Tremolo', talk: 'geodes_town', opts: { color: GEODE.Tremolo, sing: true }, flip: -1, show: A => A.questDone('choir') },
    { id: 'fermata_town', x: 2510, z: 1080, kind: 'geode', name: 'Fermata', talk: 'geodes_town', opts: { color: GEODE.Fermata, sing: true }, flip: -1, show: A => A.questDone('choir') },
    { id: 'chip_town', x: 1800, z: 400, kind: 'chip', name: 'Chip', talk: 'chip_town', opts: { mood: 'happy' }, show: A => A.questDone('quarry') },
    { id: 'woolly_town', x: 500, z: 1150, kind: 'woolly', name: 'Woolly', talk: 'woolly_town', opts: { mood: 'sleep' }, show: A => A.questDone('dreams') },
    // (and Chip's statue of Wick and friends goes up in town)
    { id: 'chip_statue', x: 1860, z: 450, kind: 'chipstatue', name: 'Statue', label: 'Read', talk: 'statue_plaque', show: A => A.questDone('quarry') },
  ]);
}

// ---------------------------------------------------------------- quests
export const EXTRA_QUESTS = {
  buddies: { name: 'The Bookend Twins', giver: 'Twain', where: 'The Study Bridges', room: ['bud_1', 430, 120],
    desc: "Twain the bookend and his sister Pairsley used to hold up the Study Shelves together. Now they're on opposite sides of Babble Brook, and neither can get a thing done alone. Help Twain get back to her.",
    progress: A => ({ done: A.flag('bookends_done'),
      text: A.flag('twain_on_pad') ? 'Hold the Twin Shelf with Twain, and cross to Pairsley' : A.flag('twain_follows') ? 'Take Twain to the Twin Shelf' : "Cross Babble Brook (ask your partner to wait on the open book)" }),
    targets: A => [A.flag('twain_on_pad') ? ['bud_1', 2860, 120] : A.flag('twain_follows') ? ['bud_1', 2280, 40] : ['bud_1', 800, 70]],
    reward: { badge: 'study_buddy', coins: 30 } },
  pomodoro: { name: 'Work, Rest, Repeat', giver: 'Nonna Pomodoro', where: 'The Pomodoro Mill', room: ['pomo_1', 300],
    desc: "Nonna Pomodoro's grandson Timo has worked at the top of the mill for three days without a break, and now he's asleep on the job. Climb up with his break snack: cross on the gears while the timer says FOCUS, and on the hammocks during the BREAK.",
    progress: A => ({ done: A.flag('pomo_done'), text: 'Take Timo his break snack, at the top of the mill' }),
    targets: () => [['pomo_1', 2520]],
    reward: { badge: 'pomodoro', coins: 40 } },
  choir: { name: 'Stage Fright', giver: 'Maestra Quartz', where: 'The Crystal Choir', room: ['choir_1', 240, 150],
    desc: "Maestra Quartz's three geode kids are too scared of a wrong note to sing at tonight's Cavern Concert. Help them practice: listen to each one's part, then play it back on the singing crystals with your hammer (X).",
    progress: A => ({ done: A.flag('choir_done'), text: `Parts practiced: ${songs(A)} of 3` }),
    targets: A => [A.flag('choir_g2') ? ['choir_1', 2560, 60] : A.flag('choir_g1') ? ['choir_1', 1650, 170] : ['choir_1', 860, 170]],
    reward: { badge: 'perfect_pitch', starPieces: 1 } },
  quarry: { name: 'One Chunk at a Time', giver: 'Chip', where: 'The Chunky Quarry', room: ['quarry_1', 470],
    desc: "Chip the stonecutter needs the good stone at the back of the quarry, but three enormous boulders are in the way, and he's too overwhelmed to start. Whack them (X), then whack the pieces, until every piece is small enough to climb.",
    progress: A => { const n = ['q1', 'quarry_q2', 'quarry_q3'].filter((k, i) => (i ? A.flag(k) : A.broken(k))).length; return { done: A.flag('quarry_done'), text: `Boulders broken down: ${n} of 3` }; },
    targets: A => [A.flag('quarry_q3') ? ['quarry_1', 2560] : A.flag('quarry_q2') ? ['quarry_1', 2020] : A.broken('q1') ? ['quarry_1', 1300] : ['quarry_1', 620]],
    reward: { badge: 'chip_off', coins: 50 } },
  dreams: { name: 'Counting Sheep', giver: 'Woolly', where: 'The Drowsy Downs', room: ['dream_1', 330, 140],
    desc: "Nobody on the Midnight Moor goes to bed anymore, so Woolly's three dream lambs wandered off into the dream side of the downs. Nap on the pillows to see the dream side, and find Nap, Doze and Snooze.",
    progress: A => ({ done: A.flag('dreams_done'), text: `Dream lambs found: ${lambs(A)} of 3` }),
    targets: A => [lambs(A) >= 3 ? ['dream_1', 2620] : ['dream_1', [1185, 1560, 2700][lambs(A)]]],
    reward: { badge: 'sweet_dreams', starPieces: 1 } },
};

export const EXTRA_BADGES = {
  study_buddy: { name: 'Study Buddy', bp: 1, desc: 'Everything is easier with someone beside you: your partner\'s attacks do 1 more damage.' },
  pomodoro: { name: 'Pomodoro', bp: 1, desc: 'Work, then rest: after every battle, Wick gets back 2 HP and 2 FP.' },
  perfect_pitch: { name: 'Perfect Pitch', bp: 1, desc: 'Practice pays off: the window for a PERFECT action command is half again as wide.' },
  chip_off: { name: 'Chip Off the Block', bp: 1, desc: 'One chunk at a time: hammer hits do 1 more damage.' },
  sweet_dreams: { name: 'Sweet Dreams', bp: 2, desc: 'Well rested: Wick can\'t be put to sleep in battle, and gets back 1 FP at the start of each of his turns.' },
};

export const EXTRA_KEY_ITEMS = { pomo_snack: "Timo's Break Snack (a tomato sandwich, still warm)" };

export const EXTRA_SPEAKERS = {
  Twain: 'bookend', Pairsley: 'bookend', 'Nonna Pomodoro': 'nonna', Timo: 'nonna', 'Maestra Quartz': 'quartz',
  Pitch: 'geode', Tremolo: 'geode', Fermata: 'geode', Chip: 'chip', Woolly: 'woolly', 'Dream Lamb': 'woolly',
};
export const EXTRA_SPEAKER_OPTS = {
  Twain: { who: 'twain' }, Pairsley: { who: 'pairsley' }, Timo: { kid: true }, Pitch: { color: GEODE.Pitch }, Tremolo: { color: GEODE.Tremolo },
  Fermata: { color: GEODE.Fermata }, 'Dream Lamb': { lamb: true },
};
export const EXTRA_PORTRAITS = { bookend: 1.2, nonna: 1.05, quartz: 0.8, geode: 1.7, chip: 1.2, woolly: 1.05 };

// A red ! over a quest giver who hasn't been asked yet.
export function extraNews(A, n) {
  const giver = { twain_a: 'buddies', nonna_mill: 'pomodoro', quartz: 'choir', chip_a: 'quarry', woolly: 'dreams' }[n.id];
  if (giver) return !A.questKnown(giver);
  if (n.id === 'pitch') return A.questKnown('choir') && !A.flag('choir_g1');
  if (n.id === 'tremolo') return A.flag('choir_g1') && !A.flag('choir_g2');
  if (n.id === 'fermata') return A.flag('choir_g2') && !A.flag('choir_done');
  if (n.id === 'timo_mill') return A.flag('pomo_met');
  if (n.id === 'nonna_town') return !A.flag('nonna_fed');
  return undefined;
}

// ---------------------------------------------------------------- scripts
const melodyTip = set => `${MELODIES[set].kid}'s part: ${hum(set, MELODIES[set].seq, CHOIR_CRYSTALS)}. Tap the crystals in that order with your hammer (X).`;
export const EXTRA_SCRIPTS = {
  // ---- the Study Bridges
  bud_enter: [
    ['narrate', "The Study Bridges. A brook babbles below, and the bookshelf bridges that used to cross it are standing straight up on the far banks, like walls."],
    ['say', 'Twain', "*sniff* ...Go away. I'm not crying. Bookends don't cry. We just... lean."],
  ],
  twain_talk: [['if', A => !A.questKnown('buddies'), [
    ['say', 'Twain', "I'm Twain. My sister Pairsley and I held up the Study Shelves together. Every day. Side by side."],
    ['say', 'Twain', "Then we argued about whose turn it was to hold the heavy end... and she stomped off across the brook."],
    ['say', 'Twain', "Now the shelves won't come down, and I can't get ANYTHING done on my own. I just sit here. Leaning."],
    ['narrate', "The open book by the water is a counterweight. If somebody waits on it, the shelf across the brook should come down."],
    ['if', A => !A.s.partner, [
      ['say', 'Twain', "...But you'd need a friend to wait on it while you cross. Come back when you've got a partner, okay?"],
    ], [
      ['say', 'Twain', "...Your friend would wait there? So you can cross? Huh. Pairsley and I used to do that for each other."],
      ['quest', 'buddies'], ['flag', 'twain_met'],
      ['tip', 'Stand by the open book and press E: your partner waits there, and the shelf comes down while they do.', 7],
    ]],
  ], [
    ['say', 'Twain', "The open book is the counterweight. Ask your friend to wait on it (press E there), and the shelf comes down."],
  ]]],
  twain_cross: [
    ['say', 'Twain', "W-wait for me! If your friend's holding it... I'm coming too!"],
    ['narrate', "Twain scurries over the shelf, very carefully, not looking down even once."],
    ['say', 'Twain', "I did it! Okay. Okay okay okay. It's easier when somebody's there, isn't it? Even if they're just... there."],
    ['flag', 'twain_follows'],
  ],
  twain_b: [['say', 'Twain', "Pairsley's on the far side. Two more shelves! Ask your friend to come and wait on the next open book."]],
  twin_shelf: [
    ['say', 'Twain', "This is the Twin Shelf. The big one. It takes TWO holders: one on each book."],
    ['say', 'Twain', "...I'll hold this end. You get your friend on the other one. Together, okay?"],
    ['flag', 'twain_on_pad'],
  ],
  twain_c: [['say', 'Twain', "I've got this end! Ask your friend to wait on the other book. It takes both of us!"]],
  pairsley_a: [['say', 'Pairsley', "Twain? Is that you over there? ...Why did I have to stomp ALL the way over here."]],
  bookends_reunion: [
    ['say', 'Pairsley', "Twain?! You crossed Babble Brook? You held the TWIN SHELF?"],
    ['say', 'Twain', "I had help. Turns out I'm a lot braver when somebody's working right next to me."],
    ['say', 'Pairsley', "...Me too. I haven't read a single page since I left. I just kept staring across the brook."],
    ['say', 'Pairsley', "Sorry I stomped off. We're bookends. We hold things up TOGETHER."],
    ['narrate', "The twins lean together, and every shelf over Babble Brook comes down at once. Thunk. Thunk. THUNK."],
    ['flag', 'bookends_done'],
    ['say', 'Twain', "Thank you! Here's the bookends' secret: studying next to somebody, even quietly, makes it SO much easier."],
    ['turnin', 'buddies'],
    ['say', 'Pairsley', "We're opening a little study corner in Lumen Town. Come and study with us any time!"],
  ],
  twins_after: [['say', 'Pairsley', "Every shelf is down for good now. Twain holds the heavy end on Mondays. I do Tuesdays."]],
  twins_town: [
    ['say', 'Twain', "Welcome to the bookends' study corner! Rule one: you don't have to talk. Just study next to somebody."],
    ['say', 'Pairsley', "It even works on a video call! When someone else is working, your brain goes 'oh, right, we're working'."],
  ],

  // ---- the Pomodoro Mill
  pomo_enter: [
    ['narrate', "The Pomodoro Mill. Gears clank, flour drifts in the air, and a giant tomato timer ticks away on the wall."],
    ['say', 'Nonna Pomodoro', "Ah! A visitor! Come in, come in. Mind the gears: they only turn while the timer says FOCUS."],
  ],
  nonna_talk: [['if', A => !A.questKnown('pomodoro'), [
    ['say', 'Nonna Pomodoro', "I'm Nonna Pomodoro. This mill grinds Focus Flour for the whole North Trail."],
    ['say', 'Nonna Pomodoro', "It runs on my timer. FOCUS: the gears turn. BREAK: they rest, and the hammocks come out. Work, rest, work, rest."],
    ['say', 'Nonna Pomodoro', "But my grandson Timo thinks breaks are for slackers. He's been up at the top for three days without one!"],
    ['say', 'Nonna Pomodoro', "And now he's fast asleep on the job. Burnt out, like a pizza left in the oven too long."],
    ['say', 'Nonna Pomodoro', "My knees can't do the climb. Would you take him his break snack? And tell him what his Nonna says!"],
    ['key', 'pomo_snack'],
    ['narrate', "You got Timo's Break Snack! (A tomato sandwich, still warm.)"],
    ['quest', 'pomodoro'], ['flag', 'pomo_met'],
    ['tip', 'Watch the timer: cross on the red gears while it says FOCUS, and on the green hammocks during the BREAK.', 8],
  ], [
    ['say', 'Nonna Pomodoro', "Timo's at the very top. Gears on FOCUS, hammocks on BREAK, and rest on the bench in between. Slow is smooth!"],
  ]]],
  timo_talk: [['if', A => A.flag('pomo_met'), [
    ['say', 'Timo', "Zzz... five more... gears... huh?! I'm awake! I'm working! I'm FOCUSED!"],
    ['say', 'Timo', "...How long was I asleep? Oh no. I'm SO behind. I can't stop now, I have to keep going!"],
    ['narrate', "You hand Timo his break snack, and tell him what his Nonna says."],
    ['say', 'Timo', "\"Work, then rest. The rest is part of the recipe.\" ...She always says that."],
    ['say', 'Timo', "I thought if I never stopped, I'd get more done. But I just got slower and slower. And then I fell asleep."],
    ['narrate', "Timo takes a real break. The two of you sit on a sack of flour and watch the gears turn. Five whole minutes go by."],
    ['say', 'Timo', "...Whoa. I feel like a whole new tomato. I could grind flour for HOURS. Well. For 25 minutes. Then another break!"],
    ['unkey', 'pomo_snack'], ['flag', 'pomo_done'],
    ['say', 'Nonna Pomodoro', "(Her voice echoes up the flour chute.) TIMO! Is that you, eating?! GOOD BOY!"],
    ['turnin', 'pomodoro'],
    ['say', 'Timo', "Nonna's opening a pasta stand in Lumen Town now that I'm running the mill properly. Go say hi! She'll feed you. A LOT."],
  ], [
    ['say', 'Timo', "Zzzz... just... one... more... gear..."],
  ]]],
  timo_after: [['say', 'Timo', "25 minutes on, 5 off. Turns out the breaks are when the flour gets good."]],
  nonna_town: [['if', A => !A.flag('nonna_fed'), [
    ['say', 'Nonna Pomodoro', "My hero! Sit, sit. You're too thin for a candle. Here: Windmill Cookies, fresh from the mill!"],
    ['give', { items: { windcookie: 2 } }], ['flag', 'nonna_fed'],
  ], [
    ['say', 'Nonna Pomodoro', "Focus for 25 minutes, then a 5-minute break. Stand up, stretch, have a snack. Then back to it!"],
  ]]],

  // ---- the Crystal Choir
  choir_enter: [
    ['narrate', "The Crystal Choir. Crystals hum all over the cave, and every little sound rings on and on."],
    ['say', 'Maestra Quartz', "Shh-shh-shh! Rehearsal! ...Oh. Oh dear. You're not one of my singers, are you."],
  ],
  quartz_talk: [['if', A => !A.questKnown('choir'), [
    ['say', 'Maestra Quartz', "I am Maestra Quartz. Tonight is the Cavern Concert, and my three little geodes are the stars."],
    ['say', 'Maestra Quartz', "But they have stage fright. They're so afraid of singing a wrong note that they won't sing a single one."],
    ['say', 'Maestra Quartz', "The secret is practice. Small pieces, again and again, until your voice remembers it for you."],
    ['say', 'Maestra Quartz', "Each of them will hum you their part. Play it back on the singing crystals with your hammer (X). Help them practice!"],
    ['quest', 'choir'], ['flag', 'choir_met'],
  ], [
    ['say', 'Maestra Quartz', "Ask a geode to hum their part. Then tap the crystals in the same order. Slowly is perfectly fine!"],
  ]]],
  pitch_talk: [['if', A => A.flag('choir_g1'), [['say', 'Pitch', "I can sing it now! Without even thinking about it!"]], [
    ['if', A => !A.questKnown('choir'), [['say', 'Pitch', "Eep! You're not the audience, are you? I'm not ready! Talk to the Maestra!"]], [
      ['say', 'Pitch', "M-my part goes like this. I'll hum it. Please don't laugh!"],
      ['cut', 'hum_a'], ['tip', melodyTip('a'), 9],
    ]],
  ]]],
  choir_ok_a: [
    ['say', 'Pitch', "That's it! That's my part! ...Again? Again! ...I think I could sing it in front of people now."],
    ['narrate', "The gate ahead rings like a bell, and swings open."],
  ],
  tremolo_talk: [['if', A => A.flag('choir_g2'), [['say', 'Tremolo', "La la LAAA! I know it by heart now!"]], [
    ['say', 'Tremolo', "Mine is longer. Four notes! What if I forget one in the middle?"],
    ['cut', 'hum_b'], ['tip', melodyTip('b'), 10],
  ]]],
  choir_ok_b: [
    ['say', 'Tremolo', "All four! And the third time, I didn't even have to think about it. My voice just KNEW."],
    ['narrate', "The second gate rings like a bell, and swings open."],
  ],
  fermata_talk: [['if', A => A.flag('choir_done'), [['say', 'Fermata', "We did it! We sang the whole thing! In FRONT of PEOPLE!"]], [
    ['say', 'Fermata', "I have the hardest part. Five notes, and the concert starts with me. Everyone will be listening."],
    ['cut', 'hum_c'], ['tip', melodyTip('c'), 11],
  ]]],
  choir_concert: [
    ['say', 'Fermata', "I got it! I really got it! ...Maestra! Maestra, we're ready!"],
    ['say', 'Maestra Quartz', "Then places, everyone! And a one, and a two..."],
    ['cut', 'concert'],
    ['narrate', "Three little voices ring through the caverns, and every crystal in the Inkwell sings along."],
    ['say', 'Maestra Quartz', "Bravissimo! You see? They didn't stop being nervous. They just practiced until the song was stronger than the nerves."],
    ['turnin', 'choir'],
    ['say', 'Maestra Quartz', "We shall give a concert in Lumen Town! The acoustics in the park are... acceptable."],
  ],
  quartz_after: [['say', 'Maestra Quartz', "Remember: a little practice every day beats one long panic the night before."]],
  quartz_town: [
    ['say', 'Maestra Quartz', "Welcome to the Lumen Park concert! My geodes rehearse here every day. Ten minutes. Every. Day."],
    ['say', 'Maestra Quartz', "Learning anything works the same way: a little, often, and out loud if you can."],
  ],
  geodes_town: [['say', 'Pitch', "♪ La la la! ♪ We're not scared of wrong notes anymore. We just sing the next one!"]],

  // ---- the Chunky Quarry
  quarry_enter: [['narrate', "The Chunky Quarry. Somewhere at the back is the best stone on Ember Peak... behind some VERY big boulders."]],
  chip_talk: [['if', A => !A.questKnown('quarry'), [
    ['say', 'Chip', "Oh! Hi. Sorry. I'm Chip. I'm a stonecutter. Well. I'm supposed to be."],
    ['say', 'Chip', "Granny Hearth ordered stone for a new hot spring, and the good stone's at the back. But LOOK at that boulder."],
    ['say', 'Chip', "It's huge. I don't even know where to start. So I... haven't. For a week. I just stand here and look at it."],
    ['narrate', "It's far too tall to climb. But a good whack with your hammer (X) might crack it into smaller pieces..."],
    ['quest', 'quarry'], ['flag', 'quarry_met'],
  ], [
    ['say', 'Chip', "Whack it until the pieces are small enough to climb. One chunk at a time!"],
  ]]],
  chip_after_1: [['say', 'Chip', "It SPLIT! It's just two medium rocks now. Medium rocks aren't scary. I can climb medium rocks!"]],
  chip_b: [['say', 'Chip', "This one's even bigger. But it's just a big rock made of smaller rocks, right? Whack it, then whack whatever's still too tall!"]],
  chip_after_2: [['say', 'Chip', "Three whacks! I thought that would take forever. It took about a minute!"]],
  chip_c: [['say', 'Chip', "THE BIGGEST ONE. ...Okay. Same trick: break it up, then break the pieces up. I'll cheer! GO, GO, GO!"]],
  chip_after_3: [['say', 'Chip', "Every piece is climbable! The good stone's just past it!"]],
  quarry_done: [
    ['say', 'Chip', "The good stone! We did it! And you know what? I don't think I was ever scared of the boulders."],
    ['say', 'Chip', "I was scared of how big the WHOLE job looked. But nobody does a whole job at once. You do one chunk. Then the next."],
    ['narrate', "Chip chips away for a while, very carefully. Then he steps back and wipes his goggles."],
    ['say', 'Chip', "Ta-da! A statue of you and your friends! I'm taking it to Lumen Town, so everybody can see it."],
    ['flag', 'quarry_done'], ['quest', 'quarry'], ['turnin', 'quarry'],
  ],
  chip_after: [['say', 'Chip', "Big job? Find the first little piece. Then the next one. That's the whole secret!"]],
  chip_town: [['say', 'Chip', "Do you like the statue? I carved it one chunk at a time. Every big thing is just a lot of small things, stuck together."]],
  statue_plaque: [['narrate', "A statue of the Hero of Homework and friends, carved by Chip. The plaque says: 'ONE CHUNK AT A TIME.'"]],

  // ---- the Drowsy Downs
  downs_enter: [['narrate', "The Drowsy Downs. Soft hills, a sleepy breeze... and not a single soul asleep."]],
  woolly_talk: [['if', A => !A.questKnown('dreams'), [
    ['say', 'Woolly', "Mmmhello, little candle. I'm Woolly. I herd the dreams of the Midnight Moor... or I used to."],
    ['say', 'Woolly', "Nobody on the moor goes to bed anymore. They stay up, and up, scrolling, saying 'just five more minutes'."],
    ['say', 'Woolly', "With no sleepers to visit, my three dream lambs had nowhere to go. They wandered off into the dream side of the downs."],
    ['say', 'Woolly', "Lie down on a pillow (press E) for a nap, and you'll see the dream side. Find my lambs: Nap, Doze and Snooze."],
    ['say', 'Woolly', "Some paths are only there in dreams... and some only when you're awake. Nap and wake up as you need to."],
    ['quest', 'dreams'], ['flag', 'dreams_met'],
  ], [
    ['say', 'Woolly', "The lambs only show up in dreams. Nap on a pillow to see the dream side, and lie down again to wake up."],
  ]]],
  downs_done: [
    ['say', 'Woolly', "(She floats over the hill.) Nap! Doze! Snooze! You found them all!"],
    ['say', 'Woolly', "Now the moor can rest. Sleep isn't wasted time, little candle. It's when your mind tidies up everything it learned that day."],
    ['say', 'Woolly', "Count Dusk's 'later' never sleeps. But real rest is something you choose on purpose. Like a pillow."],
    ['flag', 'dreams_done'], ['quest', 'dreams'], ['turnin', 'dreams'],
    ['say', 'Woolly', "I think I'll nap in Lumen Town for a while. Come by if you ever need a sleepy song."],
  ],
  woolly_after: [['say', 'Woolly', "Mmm. The whole moor is snoring. It's the most beautiful sound."]],
  woolly_town: [
    ['say', 'Woolly', "Zzz... oh, hello. A sleepy tip, little candle: screens off a little while before bed. Your dreams will thank you."],
    ['say', 'Woolly', "And a brain that slept learns twice as easily the next day. That's not magic. Well. It's a little magic."],
  ],
};
