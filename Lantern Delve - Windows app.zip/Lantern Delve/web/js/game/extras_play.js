// How the side areas play (their rooms and story are in extras.js, the art in art6.js). EXTRAS_FIELD goes onto the
// Adventure:
//   buddy pads and drawbridges (the Study Bridges): ask your partner to wait on the open book and the bookshelf across
//     the brook swings down; once you've crossed, it locks in place and your partner catches up;
//   the Pomodoro timer (the Mill): the red gear belts are there while it says FOCUS, the green hammocks on the BREAK;
//   singing crystals (the Choir): whack one and it rings; a geode hums a melody, then you play it back;
//   chunks (the Quarry): whack a boulder that's too tall to climb and it splits into two halves, half as tall;
//   naps (the Downs): a pillow switches between the awake side and the dream side, each with its own platforms and
//     walls, and the dream lambs only show up in dreams.
// adventure.js calls the hooks: extrasRoom (a room loads), extrasUpdate (every frame), extraPlats, extraSolids,
// extraInteractables / extraInteract, extraHammer, extraSmash (Pebble), drawExtraPlats, drawExtraWalls,
// drawExtrasList, drawExtrasOver.
import { INK, PAPER, glowDot, starPath } from '../art.js';
import { box, face, atDepth, GZ0, GZ1 } from '../art2.js';
import { sfx, note } from '../audio.js';
import { chunkTree, CLIMB, LAMBS } from './extras.js';
import { drawBuddyPad, drawPomoDial, drawCrystal, drawPillow, drawWoolly, NOTE_COLORS } from '../art6.js';

const W = 960, H = 540, TAU = Math.PI * 2;
const FULL = { z0: GZ0 + 10, z1: GZ1 - 10 };        // (these reach across the whole floor, front to back)
const SWING = 0.45;                                 // seconds for a drawbridge to swing down or up
const SHELF = 24;                                   // how thick a bookshelf drawbridge is
const FREQ = [523.25, 587.33, 659.25, 783.99, 880, 1046.5];   // the crystals' notes (a pentatonic scale)
const HUM_GAP = 0.62;                               // seconds between the notes of a hummed melody
const BOOKS = ['#e5534b', '#5b8def', '#5fbf6a', '#f2b43a', '#b07fe0', '#ff8ab0'];
const overlap = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y
  && (a.z0 ?? -1e9) < (b.z1 ?? 1e9) && (a.z1 ?? 1e9) > (b.z0 ?? -1e9);

// A solid made by pushing a flat outline (pts: [x, y] corners, going round) from depth z0 back to z1: the sides that
// face the camera, then its front.
function slab(c, V, pts, z0, z1, col) {
  const n = pts.length, mx = pts.reduce((s, p) => s + p[0], 0) / n, my = pts.reduce((s, p) => s + p[1], 0) / n;
  const F = pts.map(([x, y]) => [V.x(x, z0), V.y(y, z0)]), B = pts.map(([x, y]) => [V.x(x, z1), V.y(y, z1)]);
  for (let i = 0; i < n; i++) {
    const j = (i + 1) % n, [ax, ay] = pts[i], [bx, by] = pts[j];
    let nx = by - ay, ny = ax - bx;
    if (nx * (ax - mx) + ny * (ay - my) < 0) { nx = -nx; ny = -ny; }
    if (nx * (V.cx - ax) + ny * (V.hz - ay) <= 0) continue;   // (turned away from the camera)
    face(c, [F[i], F[j], B[j], B[i]], Math.abs(ny) > Math.abs(nx) ? col.top : col.side, 2);
  }
  face(c, F, col.front, 2);
}

export const EXTRAS_FIELD = {
  // ---------------------------------------------------------------- room state
  extrasRoom() {
    const R = this.room;
    this.partnerHold = null;
    this.dreaming = false;
    this.dreamFade = null;
    this.choir = null;
    this.choirGlow = {};
    this.concertT = null;
    this.pomoLast = null;
    this.pomoTick = null;
    this.lambZ = {};
    this.chunkList = R && R.chunks ? R.chunks.flatMap(chunkTree) : [];
    this.bridgeK = {};
    for (const b of (R && R.buddyBridges) || []) this.bridgeK[b.id] = this.bridgeDown(b) ? 1 : 0;
  },

  partnerName() { const id = this.s.partner; return id ? id[0].toUpperCase() + id.slice(1) : 'your partner'; },

  // ---------------------------------------------------------------- buddy pads and bridges
  padHeld(id) {
    const pad = (this.room.buddyPads || []).find(p => p.id === id);
    return !!pad && ((!!this.partnerHold && this.partnerHold.pad === id) || (!!pad.held && this.flag(pad.held)));
  },
  bridgeDown(b) { return this.flag(this.room.buddyDone) || this.flag(`bb_${b.id}`) || b.pads.every(id => this.padHeld(id)); },
  // (a pad whose shelves have all locked in place has done its job)
  padUseful(p) { return (this.room.buddyBridges || []).some(b => b.pads.includes(p.id) && !this.flag(`bb_${b.id}`)); },

  updateBridges(dt) {
    const R = this.room, P = this.p;
    let changed = false;
    for (const b of R.buddyBridges) {
      // crossed it with the shelf down: it locks in place, and your partner catches up with you
      if ((this.bridgeK[b.id] ?? 0) >= 1 && !this.flag(`bb_${b.id}`) && P.x > b.x1 + 30 && P.onGround && this.mode === 'explore') {
        this.s.flags[`bb_${b.id}`] = true;
        sfx('block');
        this.float('Clunk! The shelf locks into place.', b.x1 + 60, P.y - 120, '#fff3c4');
        if (this.partnerHold && b.pads.includes(this.partnerHold.pad)) {
          this.partnerHold = null;
          this.float(`${this.partnerName()}: Coming!`, P.x, P.y - 150, '#fff3c4');
        }
        this.saveSoon();
      }
      const want = this.bridgeDown(b) ? 1 : 0, k = this.bridgeK[b.id] ?? want;
      if (k === want) continue;
      const nk = want > k ? Math.min(1, k + dt / SWING) : Math.max(0, k - dt / SWING);
      if ((k === 0) !== (nk === 0) || (k === 1) !== (nk === 1)) changed = true;   // (it's solid all the way up or down)
      if (nk === 1 || nk === 0) { sfx('thud'); if (nk === 1) this.cut.shake = Math.max(this.cut.shake || 0, 0.25); }
      this.bridgeK[b.id] = nk;
    }
    if (changed) this.buildSolids();
  },

  // ---------------------------------------------------------------- the Pomodoro timer
  pomoPhase(R = this.room) {
    const pm = R && R.pomodoro;
    if (!pm) return null;
    const per = pm.focus + pm.brk, q = (((this.worldT || 0) % per) + per) % per;
    return q < pm.focus ? { phase: 'focus', left: pm.focus - q, k: q / pm.focus } : { phase: 'break', left: per - q, k: (q - pm.focus) / pm.brk };
  },

  updatePomodoro() {
    const P = this.p, ph = this.pomoPhase();
    const live = this.mode === 'explore';
    if (this.pomoLast && ph.phase !== this.pomoLast && live) {
      const brk = ph.phase === 'break';
      sfx(brk ? 'save' : 'chime');
      this.float(brk ? 'BREAK! The gears rest.' : 'FOCUS! The gears turn.', P.x, P.y - 120, brk ? '#8be07a' : '#ff8a76');
    }
    this.pomoLast = ph.phase;
    // a tick every half second as the phase runs out
    if (ph.left < 1.6 && live) {
      const tk = Math.ceil(ph.left / 0.5);
      if (tk !== this.pomoTick) { this.pomoTick = tk; sfx('tick'); }
    } else this.pomoTick = null;
  },

  // ---------------------------------------------------------------- chunks
  chunkUp(c) { return (c.parent == null || this.broken(c.parent)) && !this.broken(c.id); },
  chunkRootClear(root) { return this.chunkList.every(c => !c.id.startsWith(root) || !this.chunkUp(c) || c.h <= CLIMB); },

  splitChunk(c) {
    this.s.broken[c.id] = true;
    sfx('crunch'); sfx('boom');
    this.cut.shake = 0.5;
    for (let i = 0; i < 26; i++) {
      this.parts.push({ x: c.x + Math.random() * c.w, y: c.base - Math.random() * c.h, vx: (Math.random() - 0.5) * 520, vy: -100 - Math.random() * 420,
        life: 1, c: i % 3 ? '#a49e94' : '#d3cdc2', g: 1300 });
    }
    this.float('CRACK! It split in two!', c.x + c.w / 2, c.base - c.h - 20, '#ffe066');
    this.buildSolids();
    const root = c.id.match(/^q\d/)[0];
    if (this.chunkRootClear(root)) {
      if (root === 'q1') this.runScript('chip_after_1');
      if (root === 'q2' && !this.flag('quarry_q2')) { this.s.flags.quarry_q2 = true; this.runScript('chip_after_2'); }
      if (root === 'q3' && !this.flag('quarry_q3')) { this.s.flags.quarry_q3 = true; this.runScript('chip_after_3'); }
    }
    this.saveSoon();
  },

  // Pebble's Rock Smash cracks a boulder in the quarry too
  extraSmash() {
    const P = this.p;
    const big = (this.chunkList || []).filter(c => this.chunkUp(c) && c.h > CLIMB && Math.abs(Math.max(c.x, Math.min(P.x, c.x + c.w)) - P.x) < 70);
    if (!big.length) return false;
    big.sort((a, b) => Math.abs(a.x + a.w / 2 - P.x) - Math.abs(b.x + b.w / 2 - P.x));
    this.partnerSq = 0.5;
    this.float('Pebble: SMASH!', P.x, P.y - 100, '#ffe066');
    this.splitChunk(big[0]);
    return true;
  },

  // ---------------------------------------------------------------- the Drowsy Downs
  async toggleDream() {
    this.mode = 'script';
    sfx(this.dreaming ? 'chime' : 'unfold');
    await this.fadeTo(0.85, 0.35);
    this.dreaming = !this.dreaming;
    this.dreamFade = this.t;
    this.buildSolids();
    this.unstick();
    await this.fadeTo(0, 0.45);
    if (this.mode === 'script') this.mode = 'explore';
    this.float(this.dreaming ? 'Zzz... the downs go dreamy.' : 'You wake up. Yawn!', this.p.x, this.p.y - 100, '#d8d4f6');
    if (this.dreaming && !this.s.flags.dream_tip) {
      this.s.flags.dream_tip = true;
      this.tip('The dream side: soft cloud platforms, a sleepy sky... and dream lambs. Lie on a pillow again (E) to wake up.', 8);
    }
  },

  updateLambs(dt) {
    const P = this.p;
    for (const l of this.room.lambs) {
      if (this.flag(`got_${l.id}`)) continue;
      // (a lamb drifts toward whichever depth you're at, so you only have to reach it)
      const lz = this.lambZ[l.id] ?? 40;
      this.lambZ[l.id] = Math.abs(P.x - l.x) < 300 ? lz + (P.z - lz) * Math.min(1, dt * 2) : lz;
      if (Math.abs(P.x - l.x) < 34 && P.y > l.y - 20 && P.y - P.h < l.y + 26 && Math.abs(P.z - this.lambZ[l.id]) < 40) this.getLamb(l);
    }
  },

  getLamb(l) {
    this.s.flags[`got_${l.id}`] = true;
    sfx('chime'); sfx('unfold');
    const z = this.lambZ[l.id] ?? 40;
    for (let i = 0; i < 14; i++) this.parts.push({ x: l.x, y: l.y - 10, z, vx: (Math.random() - 0.5) * 200, vy: -60 - Math.random() * 160, life: 0.9, c: i % 2 ? '#fff6c8' : '#d8d4f6', star: i % 3 === 0, g: 60 });
    const n = LAMBS.filter(id => this.flag(`got_${id}`)).length;
    const name = { lamb_nap: 'Nap', lamb_doze: 'Doze', lamb_snooze: 'Snooze' }[l.id] || 'A dream lamb';
    this.float(`Baa! ${name} drifts home to Woolly (${n} of 3)`, l.x, l.y - 50, '#d8d4f6');
    if (n >= 3) this.tip('All three dream lambs are on their way home! Head to the end of the downs.', 7);
    this.saveSoon();
  },

  // ---------------------------------------------------------------- every frame
  extrasUpdate(dt) {
    const R = this.room;
    if (!R || !this.p || !this.s) return;
    if (R.buddyBridges) this.updateBridges(dt);
    if (R.pomodoro) this.updatePomodoro();
    if (R.lambs && this.dreaming && this.mode === 'explore') this.updateLambs(dt);
  },

  // ---------------------------------------------------------------- platforms and walls right now
  extraPlats() {
    const R = this.room, out = [];
    for (const b of R.buddyBridges || []) if ((this.bridgeK || {})[b.id] >= 1) out.push({ x: b.x0 - 6, y: 450, w: b.x1 - b.x0 + 12, ...FULL, bridge: b.id });
    const ph = this.pomoPhase(R);
    if (ph) for (const [x, y, w, kind] of R.timedPlats || []) if (kind === ph.phase) out.push({ x, y, w, ...FULL, timed: kind });
    for (const [x, y, w] of (this.dreaming ? R.dreamPlats : R.awakePlats) || []) out.push({ x, y, w, ...FULL });
    return out;
  },

  extraSolids(out) {
    const R = this.room;
    // a drawbridge standing up is a wall at the edge of the far bank
    for (const b of R.buddyBridges || []) if (!((this.bridgeK || {})[b.id] > 0)) out.push({ x: b.x1 - SHELF, y: 450 - (b.x1 - b.x0), w: SHELF, h: b.x1 - b.x0, type: 'wall' });
    for (const c of this.chunkList || []) if (this.chunkUp(c)) out.push({ x: c.x, y: c.base - c.h, w: c.w, h: c.h, type: 'wall', chunk: c.id });
    for (const [x, y, w, h] of (this.dreaming ? R.dreamWalls : R.awakeWalls) || []) out.push({ x, y, w, h, type: 'wall' });
  },

  // ---------------------------------------------------------------- things to use
  extraInteractables(list) {
    const R = this.room;
    const at = (type, o, z, label) => list.push({ type, x: o.x, y: this.surfaceAt(o.x, z), z, ref: o, label });
    if (R.buddyPads && !this.flag(R.buddyDone)) {
      for (const p of R.buddyPads) {
        const mine = !!this.partnerHold && this.partnerHold.pad === p.id;
        if (p.held || (!mine && !this.padUseful(p))) continue;
        at('buddypad', p, p.z ?? 50, !this.s.partner ? 'Look' : mine ? `Call ${this.partnerName()} back` : `Ask ${this.partnerName()} to wait here`);
      }
    }
    for (const pl of R.pillows || []) at('pillow', pl, pl.z ?? 20, this.dreaming ? 'Wake up' : 'Take a nap');
  },

  async extraInteract(it) {
    if (it.type === 'buddypad') {
      const p = it.ref, P = this.p;
      if (!this.s.partner) {
        await this.runScript([['narrate', 'An open book as heavy as a counterweight. If a friend waited on it, the shelf across the brook would come down.']]);
        return true;
      }
      if (this.partnerHold && this.partnerHold.pad === p.id) {
        this.partnerHold = null;
        sfx('select');
        this.float(`${this.partnerName()}: Coming!`, P.x, P.y - 100, '#fff3c4');
      } else {
        this.partnerHold = { pad: p.id, x: p.x, z: p.z ?? 50 };
        this.partnerSq = 0.7;
        sfx('block');
        this.float(`${this.partnerName()}: I'll wait right here!`, p.x, P.y - 100, '#fff3c4');
      }
      return true;
    }
    if (it.type === 'pillow') { await this.toggleDream(); return true; }
    return false;
  },

  // ---------------------------------------------------------------- the hammer: crystals ring, boulders split
  extraHammer(hb) {
    const R = this.room, P = this.p;
    if (R.crystals) {
      const tip = P.x + P.facing * 37;
      const hit = R.crystals.filter(cr => {
        const z = cr.z ?? 40, y = this.surfaceAt(cr.x, z);
        return overlap(hb, { x: cr.x - 30, y: y - 70, w: 60, h: 70, z0: z - 40, z1: z + 40 });
      }).sort((a, b) => Math.abs(a.x - tip) - Math.abs(b.x - tip));
      if (hit.length) { this.ringCrystal(hit[0]); return true; }
    }
    if (this.chunkList && this.chunkList.length) {
      const hit = this.chunkList.filter(c => this.chunkUp(c) && overlap(hb, { x: c.x, y: c.base - c.h, w: c.w, h: c.h }));
      const big = hit.find(c => c.h > CLIMB);
      if (big) { this.splitChunk(big); return true; }
      if (hit.length) { sfx('thwack'); this.float('Small enough to climb!', hit[0].x + hit[0].w / 2, hit[0].base - hit[0].h - 30, '#fff3c4'); return true; }
    }
    return false;
  },

  // ---------------------------------------------------------------- the Crystal Choir
  ringCrystal(cr) {
    note(FREQ[cr.note % FREQ.length], 0.7);
    this.choirGlow[cr.id] = this.t;
    const ch = this.choir;
    if (!ch || ch.playing || cr.set !== ch.set) return;
    const m = this.room.melodies[ch.set];
    if (m.seq[ch.i] === cr.id) {
      ch.i++;
      this.float(`♪ ${ch.i} of ${m.seq.length}`, cr.x, this.p.y - 120, '#fff3c4');
      if (ch.i < m.seq.length) return;
      this.choir = null;
      this.s.flags[m.flag] = true;
      sfx('fanfare');
      this.buildSolids();
      this.saveSoon();
      this.runScript(m.ok);
    } else {
      sfx('whiff');
      this.float('Oops! Not quite. Listen again...', cr.x, this.p.y - 120, '#ffb0a0');
      this.runScript([['wait', 0.6], ['cut', `hum_${ch.set}`]]);
    }
  },

  // A geode hums its part: each crystal of the melody lights up and sings, in order. Then it's your turn.
  async humMelody(set) {
    const R = this.room, m = R.melodies && R.melodies[set];
    if (!m) return;
    const ch = this.choir = { set, i: 0, playing: true };
    for (const n of R.npcs || []) if (n.kind === 'geode' && n.name === m.kid) n.humT = this.t;
    await this.wait(0.3);
    for (const id of m.seq) {
      if (this.choir !== ch || this.room !== R) return;
      const cr = R.crystals.find(c => c.id === id);
      note(FREQ[cr.note % FREQ.length], 0.6);
      this.choirGlow[cr.id] = this.t;
      await this.wait(HUM_GAP);
    }
    if (this.choir === ch) ch.playing = false;
  },
  cut_hum_a() { return this.humMelody('a'); },
  cut_hum_b() { return this.humMelody('b'); },
  cut_hum_c() { return this.humMelody('c'); },

  // the concert: every crystal in the cave rings out, a run of notes up and back down, twice
  async cut_concert() {
    const R = this.room, all = [...(R.crystals || [])].sort((a, b) => a.x - b.x);
    this.concertT = this.t;
    for (let rep = 0; rep < 2; rep++) {
      for (const cr of [...all, ...all.slice().reverse()]) {
        if (this.room !== R) return;
        note(FREQ[cr.note % FREQ.length], 0.5);
        this.choirGlow[cr.id] = this.t;
        await this.wait(0.13);
      }
    }
    this.cut.flash = 0.6;
    sfx('fanfare');
    await this.wait(1);
  },

  // ---------------------------------------------------------------- drawing
  // Platforms that come and go, drawn with the other platforms that reach across the floor: the mill's belts and
  // hammocks, dream clouds and awake logs. The ones that aren't there right now show as faint dotted outlines, so you
  // can see where they'll be.
  drawExtraPlats(c, V, t) {
    const R = this.room;
    const ghost = (x, y, w, col, fill) => {
      const pts = [[x, FULL.z1], [x + w, FULL.z1], [x + w, FULL.z0], [x, FULL.z0]].map(([xx, z]) => [V.x(xx, z), V.y(y, z)]);
      c.save(); c.setLineDash([7, 6]); c.strokeStyle = col; c.lineWidth = 2; c.fillStyle = fill;
      c.beginPath(); pts.forEach((p, i) => (i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]))); c.closePath(); c.fill(); c.stroke();
      c.restore();
    };
    const ph = this.pomoPhase(R);
    if (ph) {
      const warn = ph.left < 1.6 && Math.sin(t * 18) > 0;
      for (const [x, y, w, kind] of R.timedPlats || []) {
        if (kind !== ph.phase) {
          if (kind === 'focus') ghost(x, y, w, 'rgba(229,83,75,0.6)', 'rgba(229,83,75,0.08)');
          else ghost(x, y, w, 'rgba(80,170,90,0.65)', 'rgba(80,170,90,0.08)');
          continue;
        }
        c.save();
        if (warn) c.globalAlpha = 0.5;
        if (kind === 'focus') {
          box(c, V, x, y, w, 16, FULL.z0, FULL.z1, { top: '#d9534f', front: ['#c0392b', '#8e2a20'], side: '#a93226' });
          // the belt's teeth, rolling along
          c.fillStyle = '#ffe066';
          for (let i = 0; i < Math.floor(w / 18); i++) {
            const gx = x + 4 + ((i * 18 + t * 60) % (w - 8));
            c.beginPath(); c.arc(V.x(gx, FULL.z0), V.y(y + 8, FULL.z0), 2.6, 0, TAU); c.fill();
          }
        } else {
          box(c, V, x, y, w, 12, FULL.z0, FULL.z1, { top: '#8be07a', front: ['#5fbf6a', '#3f8a3a'], side: '#4f9a4a' });
          c.strokeStyle = 'rgba(255,255,255,0.55)'; c.lineWidth = 2;
          for (let i = 1; i < 4; i++) { const sx = V.x(x + (w * i) / 4, FULL.z0); c.beginPath(); c.moveTo(sx, V.y(y + 1, FULL.z0)); c.lineTo(sx, V.y(y + 11, FULL.z0)); c.stroke(); }
        }
        c.restore();
      }
    }
    for (const [x, y, w] of R.dreamPlats || []) {
      if (!this.dreaming) { ghost(x, y, w, 'rgba(150,160,240,0.55)', 'rgba(150,160,240,0.08)'); continue; }
      glowDot(c, V.x(x + w / 2, 90), V.y(y, 90), w * 0.8, '190,200,255', 0.35);
      box(c, V, x, y, w, 18, FULL.z0, FULL.z1, { top: '#f4f2ff', front: ['#e4e0fb', '#aaa2e6'], side: '#c2bcf0' });
      c.fillStyle = '#ffffff'; c.strokeStyle = INK; c.lineWidth = 1.5;
      for (let i = 0; i < 3; i++) { c.beginPath(); c.arc(V.x(x + w * (0.22 + i * 0.28), FULL.z0), V.y(y + 1, FULL.z0), 9 * V.s(FULL.z0), Math.PI, TAU); c.fill(); c.stroke(); }
    }
    for (const [x, y, w] of R.awakePlats || []) {
      if (this.dreaming) { ghost(x, y, w, 'rgba(230,180,110,0.5)', 'rgba(230,180,110,0.08)'); continue; }
      box(c, V, x, y, w, 16, FULL.z0, FULL.z1, { top: '#c49a6a', front: ['#9a7046', '#6e4a2c'], side: '#80583a' });
    }
  },

  // Walls and bridges that reach across the floor: bookshelf drawbridges (standing, swinging or lying across the
  // brook), the quarry's boulders, and the dream side's thorn hedge.
  drawExtraWalls(c, V, t, wall) {
    const R = this.room;
    for (const b of R.buddyBridges || []) {
      const k = (this.bridgeK || {})[b.id] ?? 0;
      wall(b.x0, b.x1, { z0: FULL.z0, z1: FULL.z1 }, () => this.drawShelf(c, V, b, k));
    }
    for (const ck of this.chunkList || []) {
      if (this.chunkUp(ck)) wall(ck.x, ck.x + ck.w, { z0: GZ0, z1: this.zb }, () => this.drawChunk(c, V, ck));
    }
    for (const [x, y, w, h] of R.dreamWalls || []) wall(x, x + w, { z0: GZ0, z1: this.zb }, () => this.drawThorns(c, V, x, y, w, h, t, this.dreaming));
  },

  // a bookshelf drawbridge, hinged at the edge of the far bank: k 0 = standing up, 1 = lying across the gap
  drawShelf(c, V, b, k) {
    const len = b.x1 - b.x0, th = (k * Math.PI) / 2, s = Math.sin(th), co = Math.cos(th), px = b.x1, py = 450;
    const at = (u, v) => [px - v * s - u * co, py - v * co + u * s];
    slab(c, V, [at(0, 0), at(SHELF, 0), at(SHELF, len), at(0, len)], FULL.z0, FULL.z1, { top: '#b07850', front: '#8a5a3c', side: '#6e4528' });
    // lying down, its back is a walkway of boards
    if (k >= 1) {
      c.strokeStyle = 'rgba(70,40,20,0.35)'; c.lineWidth = 1.5;
      for (let zz = FULL.z0 + 40; zz < FULL.z1 - 10; zz += 40) { c.beginPath(); c.moveTo(V.x(b.x0, zz), V.y(450, zz)); c.lineTo(V.x(b.x1, zz), V.y(450, zz)); c.stroke(); }
    }
    // the books on its front, in the shelf's own frame
    const z = FULL.z0, sc = V.s(z);
    c.save();
    c.translate(V.x(px, z), V.y(py, z)); c.scale(sc, sc); c.rotate(-th);
    c.strokeStyle = INK; c.lineWidth = 1.2;
    for (let i = 0, y = -6; y > -len + 18; i++) {
      const hgt = 10 + ((i * 7) % 5);
      c.fillStyle = BOOKS[i % BOOKS.length];
      c.fillRect(-SHELF + 4, y - hgt, SHELF - 8, hgt - 2); c.strokeRect(-SHELF + 4, y - hgt, SHELF - 8, hgt - 2);
      y -= hgt;
    }
    c.restore();
  },

  drawChunk(c, V, ck) {
    const big = ck.h > CLIMB, y = ck.base - ck.h;
    box(c, V, ck.x, y, ck.w, ck.h, GZ0, this.zb, big ? { top: '#c4bcb0', front: ['#a49e94', '#6f6a62'], side: '#7d776e' } : { top: '#d6cfc4', front: ['#b9b2a6', '#8a8379'], side: '#958e84' });
    const z = GZ0, X = xx => V.x(xx, z), Y = yy => V.y(yy, z);
    c.strokeStyle = 'rgba(43,34,53,0.3)'; c.lineWidth = 1.5;
    for (let yy = y + 30; yy < ck.base - 10; yy += 36) { c.beginPath(); c.moveTo(X(ck.x + 6), Y(yy)); c.lineTo(X(ck.x + ck.w - 6), Y(yy + 4)); c.stroke(); }
    if (big) {
      // the crack down the middle, where it'll split
      const mx = ck.x + ck.w / 2;
      c.strokeStyle = INK; c.lineWidth = 2.6 * V.s(z);
      c.beginPath(); c.moveTo(X(mx), Y(y + 4)); c.lineTo(X(mx - 7), Y(y + ck.h * 0.3)); c.lineTo(X(mx + 6), Y(y + ck.h * 0.55)); c.lineTo(X(mx - 4), Y(y + ck.h * 0.8)); c.lineTo(X(mx + 1), Y(ck.base - 2)); c.stroke();
      if (ck.name) {
        c.font = 'bold 15px Fredoka, sans-serif'; c.textAlign = 'center'; c.lineWidth = 4; c.strokeStyle = INK;
        c.strokeText(ck.name, X(mx), Y(y - 14)); c.fillStyle = '#fff3c4'; c.fillText(ck.name, X(mx), Y(y - 14));
      }
    }
  },

  // a hedge of Doomscroll thorns: solid in dreams, just a faint outline while you're awake
  drawThorns(c, V, x, y, w, h, t, solid) {
    c.save();
    if (!solid) c.globalAlpha = 0.22;
    box(c, V, x, y, w, h, GZ0, this.zb, { top: '#6a4a8e', front: ['#4a2f66', '#2a1a40'], side: '#3a2552' });
    const z = GZ0, X = xx => V.x(xx, z), Y = yy => V.y(yy, z);
    c.fillStyle = '#4a2f66'; c.strokeStyle = INK; c.lineWidth = 2;
    for (let yy = y + 10; yy < y + h; yy += 26) {
      for (const [ex, dir] of [[x, -1], [x + w, 1]]) { c.beginPath(); c.moveTo(X(ex), Y(yy)); c.lineTo(X(ex + dir * 12), Y(yy + 6)); c.lineTo(X(ex), Y(yy + 13)); c.closePath(); c.fill(); c.stroke(); }
    }
    // little glowing screens tangled in it
    for (let i = 0; i < 4; i++) {
      const yy = y + h * (0.15 + i * 0.21), mx = x + w / 2;
      c.fillStyle = `rgba(160,220,255,${0.55 + 0.3 * Math.sin(t * 3 + i)})`;
      c.fillRect(X(mx - 7), Y(yy), X(mx + 7) - X(mx - 7), Y(yy + 20) - Y(yy)); c.strokeRect(X(mx - 7), Y(yy), X(mx + 7) - X(mx - 7), Y(yy + 20) - Y(yy));
    }
    c.restore();
  },

  // things in the far-to-near list: the timer on the mill's wall, buddy pads, crystals, pillows and dream lambs (and
  // the geodes cheer up as their parts come together)
  drawExtrasList(c, V, t, add, cut) {
    const R = this.room;
    const surf = (x, z) => this.surfaceAt(x, z);
    const ph = this.pomoPhase(R);
    if (ph && R.dial) add(1e9, 0, () => atDepth(c, V, R.dial.x, R.dial.y, GZ1 - 2, () => { c.scale(1.6, 1.6); drawPomoDial(c, 0, 0, { phase: ph.phase, k: ph.k, warn: ph.left < 1.6, t }); }));
    for (const p of R.buddyPads || []) {
      const z = p.z ?? 50, on = this.padHeld(p.id) || this.flag(R.buddyDone) || !this.padUseful(p);
      cut(p.x, surf(p.x, z), z, -1, () => drawBuddyPad(c, 0, 0, { t, on }));
    }
    for (const cr of R.crystals || []) {
      const z = cr.z ?? 40, g0 = this.choirGlow[cr.id], g = g0 == null ? 0 : Math.max(0, 1 - (this.t - g0) / 0.8);
      cut(cr.x, surf(cr.x, z), z, 0, () => drawCrystal(c, 0, 0, { note: cr.note, color: NOTE_COLORS[cr.note % NOTE_COLORS.length], glow: g, t }), 80, 30);
    }
    if (R.melodies) {
      const done = { Pitch: 'choir_g1', Tremolo: 'choir_g2', Fermata: 'choir_done' }, concert = this.concertT != null && this.t - this.concertT < 8;
      for (const n of R.npcs || []) {
        if (n.kind !== 'geode') continue;
        const o = (n.opts ||= {});
        o.mood = this.flag(done[n.name]) ? 'happy' : 'worried';
        o.sing = concert || this.flag('choir_done') || (n.humT != null && this.t - n.humT < 3.4);
      }
    }
    for (const pl of R.pillows || []) { const z = pl.z ?? 20; cut(pl.x, surf(pl.x, z), z, 0, () => drawPillow(c, 0, 0, { t, dream: this.dreaming })); }
    if (this.dreaming) {
      for (const l of R.lambs || []) {
        if (this.flag(`got_${l.id}`)) continue;
        const z = (this.lambZ || {})[l.id] ?? 40;
        cut(l.x, l.y + 24, z, 1, () => drawWoolly(c, 0, 0, { lamb: true, t, seed: l.x, shadow: false }));
      }
    }
  },

  // Over everything, on the screen: the mill's timer in the corner, and the dream side's moonlit sky.
  drawExtrasOver(c) {
    const R = this.room;
    if (R.pillows) {
      const k = this.dreamFade != null ? Math.min(1, (this.t - this.dreamFade) / 0.6) : 1, a = this.dreaming ? k : 1 - k;
      if (a > 0) {
        c.save();
        c.globalAlpha = a;
        c.fillStyle = 'rgba(70,60,160,0.26)'; c.fillRect(0, 0, W, H);
        const g = c.createRadialGradient(W / 2, H / 2, 140, W / 2, H / 2, 620);
        g.addColorStop(0, 'rgba(40,30,90,0)'); g.addColorStop(1, 'rgba(40,30,90,0.45)');
        c.fillStyle = g; c.fillRect(0, 0, W, H);
        for (let i = 0; i < 26; i++) {
          const x = (((i * 137.5 - (this.camX || 0) * 0.15) % W) + W) % W, y = (i * 71.3) % (H * 0.55), tw = 0.5 + 0.5 * Math.sin(this.t * 2 + i);
          c.fillStyle = `rgba(255,250,220,${0.35 + 0.5 * tw})`; c.beginPath(); starPath(c, x, y, 3 + tw * 2, 1.4, 4); c.fill();
        }
        c.font = 'bold 18px Fredoka, sans-serif'; c.fillStyle = 'rgba(255,250,240,0.6)'; c.textAlign = 'center';
        for (let i = 0; i < 6; i++) { const q = (this.t * 0.1 + i / 6) % 1; c.fillText('z', 80 + ((i * 173) % (W - 160)) + Math.sin(this.t + i) * 12, H - q * H); }
        c.restore();
      }
    }
    const ph = this.pomoPhase(R);
    if (ph && this.mode !== 'battle') {
      c.save(); c.translate(64, 128); c.scale(0.72, 0.72);
      drawPomoDial(c, 0, 0, { phase: ph.phase, k: ph.k, warn: ph.left < 1.6, t: this.t });
      c.font = 'bold 18px Fredoka, sans-serif'; c.textAlign = 'center'; c.lineWidth = 4; c.strokeStyle = INK; c.fillStyle = PAPER;
      const left = `${Math.ceil(ph.left)}s`;
      c.strokeText(left, 0, 98); c.fillText(left, 0, 98);
      c.restore();
    }
  },
};
