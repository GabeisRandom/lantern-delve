// The guide: what to do next (the story, or a quest you're tracking), the route there through the rooms,
// the gold arrow that points the way, and the map screen (TAB) that shows where you are.
import { ROOMS, AREAS, QUESTS, storyGoal } from './data.js';
import { visitedCount } from './expansion.js';
import { DRAW, INK, PAPER, paper, shape, rrect, vgrad, glowDot, starPath } from '../art.js';
import { drawGuideArrow } from '../art2.js';
import { sfx } from '../audio.js';
import { AreaMap } from './areamap.js';

const W = 960, H = 540;

// ---------------------------------------------------------------- the room graph
let EDGES = null;
export function edges() {
  if (EDGES) return EDGES;
  EDGES = {};
  for (const [id, R] of Object.entries(ROOMS)) {
    const out = [];
    for (const side of ['left', 'right']) {
      const e = R.exits && R.exits[side];
      if (e && e.to && ROOMS[e.to]) out.push({ to: e.to, via: side, need: e.need, exit: e });
    }
    for (const d of R.doors || []) if (ROOMS[d.to]) out.push({ to: d.to, via: 'door', x: d.x, label: d.label, door: d });
    EDGES[id] = out;
  }
  return EDGES;
}

// Can Wick get through here right now? (Locked doors with a puzzle script still count: that's where you need to go.)
function passable(A, e) {
  if (e.need && !A.flag(e.need)) return false;
  const d = e.door;
  if (!d) return true;
  if (d.need && !A.flag(d.need) && !d.lockScript) return false;
  if (d.needAbility && !A.has(d.needAbility)) return false;
  if (d.needBroken && !A.broken(d.needBroken)) return false;
  if (d.needSeal && !A.broken(d.needSeal)) return false;
  return true;
}

// The list of exits/doors to take from one room to another (shortest), or null if there's no way.
export function route(A, from, to) {
  if (from === to) return [];
  for (const strict of [true, false]) {
    const prev = { [from]: null }, q = [from];
    while (q.length) {
      const id = q.shift();
      if (id === to) break;
      for (const e of edges()[id] || []) {
        if (prev[e.to] !== undefined || (strict && !passable(A, e))) continue;
        prev[e.to] = { id, e };
        q.push(e.to);
      }
    }
    if (prev[to] !== undefined) {
      const path = [];
      for (let id = to; prev[id]; id = prev[id].id) path.unshift(prev[id].e);
      return path;
    }
  }
  return null;
}

// ---------------------------------------------------------------- what to do next
export function questGoal(A, id) {
  const q = QUESTS[id];
  if (!q) return null;
  const prog = q.progress(A);
  let spots = prog.done ? [q.room] : q.targets ? q.targets(A) : [q.goal || q.room];
  spots = spots.filter(Boolean);
  if (!spots.length) return null;
  // the closest spot that still needs doing
  let best = null, bl = 1e9;
  for (const [room, x, z] of spots) {
    const r = route(A, A.roomId, room);
    // in the same room, the nearest spot wins (the big fields have a lot of ground between things)
    const n = r ? r.length + (room === A.roomId && x != null && A.p ? Math.hypot(x - A.p.x, (z ?? A.p.z) - A.p.z) / 100000 : 0) : 999;
    if (n < bl) { bl = n; best = [room, x, z]; }
  }
  return { text: prog.done ? `${q.name}: go see ${q.giver}` : `${q.name}: ${prog.text}`, room: best[0], x: best[1], z: best[2], quest: id };
}

export function currentGoal(A) {
  const id = A.s.tracked;
  if (id && A.questActive(id)) { const g = questGoal(A, id); if (g) return g; }
  else if (id) A.s.tracked = null;   // done (or gone): stop tracking it
  const g = storyGoal(A);
  if (g) return g;
  // the story is finished for now: point at a quest that's ready to hand in
  for (const qid of Object.keys(A.s.quests)) if (A.questReady(qid) && QUESTS[qid].room) return questGoal(A, qid);
  return null;
}

export function roomName(id) { return (ROOMS[id] && ROOMS[id].name) || '???'; }

// How far back a goal in this room is: what it says, or else whatever you can use at that spot (the one nearest
// Wick when there are a few in a line, front to back: the first one found could be at the far end of town).
export function goalZ(A, g) {
  if (g.z != null) return g.z;
  const near = A.interactables().filter(i => Math.abs(i.x - g.x) < 40);
  if (!near.length) return 0;
  const pz = A.p ? A.p.z : 0;
  near.sort((a, b) => Math.abs(a.z - pz) - Math.abs(b.z - pz));
  return near[0].z;
}

// Worked out a couple of times a second: the goal and the first step toward it.
export function updateGuide(A) {
  const goal = currentGoal(A);
  A.guide = { goal, path: goal ? route(A, A.roomId, goal.room) : null };
}

// A few words on how to get there, for the hint button.
export function routeText(A) {
  const g = A.guide && A.guide.goal;
  if (!g) return null;
  const path = A.guide.path;
  if (!path) return `It's in ${roomName(g.room)}, but I'm not sure how to get there from here yet.`;
  if (!path.length) return g.x != null ? `It's right here in ${roomName(g.room)}. Follow the gold arrow!` : `It's right here in ${roomName(g.room)}!`;
  const first = path[0];
  const back = first.via === 'door' && A.doorZ(first.door) > 150 ? ' at the back of this place (walk up with ↑)' : ' here';
  const how = first.via === 'door' ? `go through "${first.label || 'the door'}"${back}` : `head ${first.via}`;
  const n = path.length;
  return `It's in ${roomName(g.room)}, ${n} place${n > 1 ? 's' : ''} away. First, ${how}. Just follow the gold arrow!`;
}

// ---------------------------------------------------------------- the gold arrow in the field
// It floats beside Wick and points at the next door or path, even one at the back of the room.
export function drawGuide(c, A, V, t) {
  const g = A.guide;
  if (!g || !g.goal || !g.path || A.s.guide === false || A.mode !== 'explore' || A.dlg) return;
  const P = A.p, step = g.path[0];
  const tag = g.goal.quest ? '📜 ' : '⭐ ';
  let tx = null, tz = 0, angle = 0, label = '';
  if (step) {
    if (step.via === 'door') { tx = step.x; tz = A.doorZ(step.door); label = tag + (step.label || roomName(step.to)); }
    else {
      label = `${tag}${roomName(step.to)}`;
      // in a big field only the stretch of the edge where the road leaves goes anywhere: aim for it
      const e = step.exit;
      if (e && e.z0 != null && (P.z < e.z0 || P.z > e.z1) && Math.abs((step.via === 'left' ? 0 : A.room.w) - P.x) > 90) {
        const ex = step.via === 'left' ? 40 : A.room.w - 40, ez = (e.z0 + Math.min(e.z1, e.z0 + 360)) / 2;
        angle = Math.atan2(V.y(A.surfaceAt(ex, ez) - 60, ez) - V.y(P.y - 96, P.z), V.x(ex, ez) - V.x(P.x, P.z));
      } else angle = step.via === 'left' ? Math.PI : 0;
    }
  } else if (g.goal.x != null) {
    tx = g.goal.x;
    tz = goalZ(A, g.goal);
    label = tag + 'Here!';
  } else return;
  const wx = V.x(P.x, P.z), wy = V.y(P.y - 96, P.z);
  if (tx != null) {
    if (Math.abs(tx - P.x) < 70 && Math.abs(tz - P.z) < 80) {
      const y = A.surfaceAt(tx, tz) - 150, sx = V.x(tx, tz), sy = V.y(y, tz);
      drawGuideArrow(c, sx, sy + 26, 'up', t, step ? 'Press E' : null);
      if (!step) { c.save(); c.translate(sx, sy - 10 + Math.sin(t * 4) * 4); c.beginPath(); starPath(c, 0, 0, 13, 6); c.fillStyle = '#ffe066'; c.fill(); c.lineWidth = 2.5; c.strokeStyle = INK; c.stroke(); c.restore(); }
      return;
    }
    angle = Math.atan2(V.y(A.surfaceAt(tx, tz) - 60, tz) - wy, V.x(tx, tz) - wx);
  }
  drawGuideArrow(c, wx + Math.cos(angle) * 62, wy + Math.sin(angle) * 34, angle, t, label);
}

// ---------------------------------------------------------------- the map screen
// Rooms of an area in walking order from its start, plus which ones you know and what's in them.
function areaRooms(areaId) {
  const a = AREAS[areaId];
  const ids = Object.keys(ROOMS).filter(id => ROOMS[id].area === areaId);
  const order = [], seen = new Set();
  const q = a && a.start && ROOMS[a.start] ? [a.start] : ids.slice(0, 1);
  while (q.length) {
    const id = q.shift();
    if (seen.has(id) || !ids.includes(id)) continue;
    seen.add(id); order.push(id);
    for (const e of edges()[id] || []) if (!seen.has(e.to) && ids.includes(e.to)) q.push(e.to);
  }
  for (const id of ids) if (!seen.has(id)) order.push(id);
  return order;
}

let AREA_LINKS = null;
function areaLinks() {
  if (AREA_LINKS) return AREA_LINKS;
  const set = new Set();
  for (const [id, list] of Object.entries(edges())) {
    const a = ROOMS[id].area;
    for (const e of list) { const b = ROOMS[e.to].area; if (a !== b && AREAS[a] && AREAS[b]) set.add([a, b].sort().join('|')); }
  }
  AREA_LINKS = [...set].map(k => k.split('|'));
  return AREA_LINKS;
}

function roomInfo(A, id) {
  const R = ROOMS[id];
  const chests = (R.chests || []).filter(ch => !A.s.opened[ch.id]).length;
  const pages = (R.collect || []).filter(it => it.kind === 'page' && !A.s.collected[it.id]).length;
  const lamp = (R.lamps || []).some(l => A.s.opened[`lamp_${id}_${typeof l === 'number' ? l : l.x}`]);
  const news = (R.npcs || []).some(n => (!n.show || n.show(A)) && n.talk && A.npcHasNews(n));
  return { chests, pages, lamp, hasLamp: !!(R.lamps || []).length, news };
}

// TAB opens the detailed map of where you are (areamap.js); TAB again, or the tab at the top, shows all of Lumenfold
// (and fast travel); TAB once more, or ESC, closes it.
export class MapScreen {
  constructor(A) { this.A = A; this.sel = 'town'; this.area = new AreaMap(A); this.view = 'area'; this.tabBtns = []; }

  open() {
    const A = this.A;
    this.prev = A.mode;
    A.mode = 'map';
    this.sel = (A.room && A.room.area) || 'town';
    this.opened = A.t;
    this.msg = '';
    this.view = 'area';
    this.area.open();
  }

  close() {
    const A = this.A;
    A.mode = this.prev && this.prev !== 'map' ? this.prev : 'explore';
  }

  show(view) {
    if (view === this.view) return;
    this.view = view;
    this.opened = this.A.t;
    sfx('select');
  }

  wheel(x, y, dy) { if (this.view === 'area') this.area.wheel(x, y, dy); }
  pointer(kind, x, y) { if (this.view === 'area') this.area.pointer(kind, x, y); }
  click(x, y) {
    for (const b of this.tabBtns) if (x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) { this.show(b.id); return; }
    if (this.view === 'area') this.area.click(x, y);
  }

  key(act) {
    const A = this.A;
    if (act === 'menu') { this.close(); return; }
    if (act === 'map') { if (this.view === 'area') this.show('world'); else this.close(); return; }
    if (this.view === 'area') { this.area.key(act); return; }
    if (act === 'hammer') { this.close(); return; }
    if (act === 'jump' || act === 'act') { this.travel(); return; }
    const d = { left: [-1, 0], right: [1, 0], up: [0, -1], down: [0, 1] }[act];
    if (!d) return;
    // move to the nearest place roughly in that direction
    const cur = AREAS[this.sel];
    let best = null, bs = 1e9;
    for (const [id, a] of Object.entries(AREAS)) {
      if (id === this.sel) continue;
      const dx = a.mx - cur.mx, dy = a.my - cur.my;
      const along = dx * d[0] + dy * d[1];
      if (along <= 0.01) continue;
      const across = Math.abs(dx * d[1] - dy * d[0]);
      const score = along + across * 2.2;
      if (score < bs) { bs = score; best = id; }
    }
    if (best) { this.sel = best; this.msg = ''; sfx('select'); }
  }

  async travel() {
    const A = this.A, a = AREAS[this.sel];
    if (a.soon) { this.msg = 'Coming in a future update!'; sfx('hurt'); return; }
    if (!A.s.seenAreas[this.sel]) { this.msg = "You haven't found this place yet. Go exploring!"; sfx('hurt'); return; }
    if (A.room && A.room.area === this.sel) { this.msg = "You're already here! (TAB closes the map.)"; return; }
    if (!A.flag('prologue_done')) { this.msg = 'Fast travel opens up after the prologue.'; sfx('hurt'); return; }
    if (A.light <= 0 && this.sel !== 'town') { this.msg = 'Your lantern is out of ✦ Light! Do some homework first.'; sfx('hurt'); return; }
    sfx('menu');
    this.prev = 'explore';
    await A.fastTravel(this.sel);
  }

  // the two tabs along the top: this area's detailed map, and all of Lumenfold
  drawTabs(c) {
    const A = this.A, area = A.room && AREAS[A.room.area];
    const tabs = [['area', `📍 ${area ? area.name : roomName(A.roomId)}`], ['world', '🗺️ Lumenfold']];
    let x = 16;
    this.tabBtns = [];
    c.font = 'bold 14px "Segoe UI Emoji", Fredoka, sans-serif';
    for (const [id, label] of tabs) {
      const w = Math.min(250, c.measureText(label).width + 28), on = this.view === id;
      c.fillStyle = on ? PAPER : 'rgba(255,250,240,0.13)'; c.beginPath(); rrect(x, 12, w, 32, 10)(c); c.fill();
      if (on) { c.strokeStyle = INK; c.lineWidth = 2.5; c.stroke(); }
      c.fillStyle = on ? INK : '#fffaf0'; c.textAlign = 'center'; c.fillText(label, x + w / 2, 33, w - 14);
      this.tabBtns.push({ x, y: 12, w, h: 32, id });
      x += w + 8;
    }
  }

  draw(c, t) {
    const A = this.A;
    c.fillStyle = '#1c1636'; c.fillRect(0, 0, W, H);
    const k = Math.min(1, (t - this.opened) / 0.25), ease = 1 - Math.pow(1 - k, 3);
    if (this.view === 'area') {
      c.save(); c.globalAlpha = ease;
      this.area.draw(c, t);
      this.drawTabs(c);
      c.textAlign = 'center'; c.font = '12.5px Fredoka, sans-serif'; c.fillStyle = '#cfc6e6';
      c.fillText('Scroll, + −, SPACE / X: zoom   ·   Drag or ← → ↑ ↓: look around   ·   E: back to Wick   ·   [ ]: other places here   ·   TAB: all of Lumenfold   ·   ESC: close', W / 2, H - 14);
      c.restore();
      return;
    }
    c.save(); c.translate(0, (1 - ease) * 30); c.globalAlpha = ease;
    // ---- left: the world
    const mx = 26, my = 58, mw = 548, mh = 446;
    paper(c, p => shape(c, p, rrect(mx, my, mw, mh, 18), vgrad(c, my, my + mh, '#f6e8c6', '#e8d4a6')));
    c.strokeStyle = 'rgba(138,106,74,0.18)'; c.lineWidth = 1;
    for (let x = mx + 40; x < mx + mw; x += 40) { c.beginPath(); c.moveTo(x, my + 8); c.lineTo(x, my + mh - 8); c.stroke(); }
    for (let y = my + 40; y < my + mh; y += 40) { c.beginPath(); c.moveTo(mx + 8, y); c.lineTo(mx + mw - 8, y); c.stroke(); }
    const pos = a => [mx + 30 + a.mx * (mw - 60), my + 26 + a.my * (mh - 70)];
    c.setLineDash([8, 9]); c.lineWidth = 4;
    for (const [a, b] of areaLinks()) {
      const known = A.s.seenAreas[a] && A.s.seenAreas[b];
      c.strokeStyle = known ? '#8a6a4a' : 'rgba(138,106,74,0.35)';
      const [x1, y1] = pos(AREAS[a]), [x2, y2] = pos(AREAS[b]);
      c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.stroke();
    }
    c.setLineDash([]);
    const here = A.room ? A.room.area : 'town';
    const goal = A.guide && A.guide.goal, goalArea = goal && ROOMS[goal.room] ? ROOMS[goal.room].area : null;
    for (const [id, a] of Object.entries(AREAS)) {
      const [x, y] = pos(a), seen = !!A.s.seenAreas[id];
      if (id === this.sel) glowDot(c, x, y, 48, '255,240,180', 0.6);
      c.fillStyle = seen ? '#fffaf0' : '#cbbf9f'; c.strokeStyle = INK; c.lineWidth = id === this.sel ? 4 : 2.5;
      c.beginPath(); c.arc(x, y, id === this.sel ? 27 : 23, 0, Math.PI * 2); c.fill(); c.stroke();
      c.font = '22px "Segoe UI Emoji", sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
      c.globalAlpha = ease * (seen || a.soon ? 1 : 0.4); c.fillText(seen || a.soon ? a.icon : '?', x, y + 1); c.globalAlpha = ease;
      c.textBaseline = 'alphabetic'; c.font = 'bold 13px Fredoka, sans-serif';
      const name = seen || a.soon ? a.name : '???';
      c.lineWidth = 4; c.strokeStyle = '#f6e8c6'; c.strokeText(name, x, y + 40); c.fillStyle = INK; c.fillText(name, x, y + 40);
      if (id === goalArea) {
        c.save(); c.translate(x + 22, y - 22 + Math.sin(t * 4) * 3);
        c.beginPath(); starPath(c, 0, 0, 12, 5.5); c.fillStyle = goal.quest ? '#9fe6ff' : '#ffe066'; c.fill(); c.lineWidth = 2; c.strokeStyle = INK; c.stroke();
        c.restore();
      }
      if (id === here) {
        c.save(); c.translate(x - 26, y - 6 + Math.sin(t * 3) * 3);
        DRAW.wick(c, 0, 0, { t, scale: 0.55, shadow: false, mood: 'happy' });
        c.restore();
      }
    }
    c.font = '13px Fredoka, sans-serif'; c.fillStyle = '#cfc6e6'; c.textAlign = 'right';
    c.fillText(`📍 Places found: ${visitedCount(A)}   📄 Lost Pages: ${A.collectedCount('page')}/12   ✨ Shards: ${A.s.shards}/5`, W - 22, 34);
    // ---- right: the selected place, room by room
    const px = 590, py = 58, pw = 344, ph = 446;
    paper(c, p => shape(c, p, rrect(px, py, pw, ph, 16), PAPER));
    const a = AREAS[this.sel], seen = !!A.s.seenAreas[this.sel];
    c.textAlign = 'left'; c.fillStyle = INK; c.font = 'bold 19px Fredoka, sans-serif';
    c.fillText(`${a.icon} ${seen || a.soon ? a.name : '???'}`, px + 16, py + 32, pw - 30);
    let y = py + 54;
    if (a.soon) { this.text(c, 'Coming in a future update!', px + 16, y + 10, pw - 30); }
    else if (!seen) { this.text(c, "You haven't found this place yet. Go exploring!", px + 16, y + 10, pw - 30); }
    else {
      const ids = areaRooms(this.sel);
      const visited = A.s.visited || {};
      const frontier = id => !visited[id] && (edges()[id] || []).some(e => visited[e.to]) || Object.entries(edges()).some(([from, l]) => visited[from] && l.some(e => e.to === id));
      let known = 0, chests = 0, chestsAll = 0, pages = 0, pagesAll = 0, hidden = 0;
      for (const id of ids) {
        const R = ROOMS[id];
        chestsAll += (R.chests || []).length; chests += (R.chests || []).filter(ch => A.s.opened[ch.id]).length;
        const pg = (R.collect || []).filter(it => it.kind === 'page');
        pagesAll += pg.length; pages += pg.filter(it => A.s.collected[it.id]).length;
        if (visited[id]) known++;
      }
      c.font = '13px Fredoka, sans-serif'; c.fillStyle = '#6b5a8a';
      c.fillText(`Places ${known}/${ids.length}   ·   Chests ${chests}/${chestsAll}${pagesAll ? `   ·   Pages ${pages}/${pagesAll}` : ''}`, px + 16, y);
      y += 14;
      c.strokeStyle = '#e4d8bd'; c.setLineDash([5, 5]); c.lineWidth = 2; c.beginPath(); c.moveTo(px + 12, y); c.lineTo(px + pw - 12, y); c.stroke(); c.setLineDash([]);
      y += 8;
      const rowH = Math.min(26, (ph - 130) / Math.max(1, ids.length));
      for (const id of ids) {
        const R = ROOMS[id], v = visited[id];
        if (!v && !frontier(id)) { hidden++; continue; }
        y += rowH;
        const cur = A.roomId === id;
        if (cur) { c.fillStyle = '#fff3c9'; c.beginPath(); rrect(px + 8, y - rowH + 5, pw - 16, rowH - 1, 6)(c); c.fill(); }
        c.font = `${cur ? 'bold ' : ''}14px Fredoka, sans-serif`; c.fillStyle = v ? INK : '#9a8fb3';
        const name = v ? `${R.interior ? '🚪 ' : ''}${R.name}` : '??? (not found yet)';
        c.fillText(name, px + 18, y - 3, 190);
        if (v) {
          const info = roomInfo(A, id);
          const tags = [cur && '📍', goal && goal.room === id && (goal.quest ? '📜' : '⭐'), info.news && '❗', info.hasLamp && (info.lamp ? '🏮' : '🕯️'), R.icon, info.chests && `🎁${info.chests}`, info.pages && '📄'].filter(Boolean);
          c.font = '13px "Segoe UI Emoji", Fredoka, sans-serif'; c.textAlign = 'right';
          c.fillText(tags.join(' '), px + pw - 14, y - 3);
          c.textAlign = 'left';
        }
        if (y > py + ph - 60) break;
      }
      if (hidden) { c.font = 'italic 13px Fredoka, sans-serif'; c.fillStyle = '#9a8fb3'; c.fillText(`+ ${hidden} more place${hidden > 1 ? 's' : ''} to discover...`, px + 18, Math.min(y + 22, py + ph - 40)); }
    }
    // goal line + keys
    c.font = '13px Fredoka, sans-serif'; c.fillStyle = INK; c.textAlign = 'left';
    const gl = goal ? `${goal.quest ? '📜' : '⭐'} ${goal.text} (${roomName(goal.room)})` : '⭐ No story goal right now. Explore and try side quests!';
    this.text(c, gl, px + 16, py + ph - 26, pw - 30);
    c.textAlign = 'center'; c.font = '13px Fredoka, sans-serif'; c.fillStyle = '#cfc6e6';
    c.fillText(this.msg || '← → ↑ ↓ choose a place   ·   SPACE fast travel (places you\'ve been)   ·   TAB / ESC close', W / 2, H - 14);
    c.restore();
    this.drawTabs(c);
  }

  text(c, s, x, y, w) {
    // simple two-line wrap
    const words = s.split(' ');
    let line = '', yy = y;
    for (const wd of words) {
      const test = line ? `${line} ${wd}` : wd;
      if (c.measureText(test).width > w && line) { c.fillText(line, x, yy); line = wd; yy += 16; }
      else line = test;
    }
    if (line) c.fillText(line, x, yy);
  }
}
