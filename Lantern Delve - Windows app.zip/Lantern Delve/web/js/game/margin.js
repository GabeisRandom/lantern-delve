// Bonus Chapter (after the ending): The Unfinished Margin. Past the edge of the map lies the Margin, a land that was
// only ever sketched in pencil, because its ruler, Queen Pristine, erases anything that isn't perfect. Nothing there
// has been finished in a hundred years. A letter from Doodle (a shy crayon kid) brings Wick there on Captain Crease's
// paper boat from Mirror Lake. Wick's light brings the color back wherever he walks; unblocking each Color Fount
// colors an area in for good. Doodle joins at the Blue Fount, the Wastebasket guards the Green Fount in the
// Sketchwood, and Queen Pristine waits on the Blank Throne. The lesson: done is better than perfect.
// data.js merges all of this in (see patchMargin). The field and battle mechanics are in margin_play.js.
import { ramp } from './deep.js';

const T = (x0, x1, z0, z1, y, more = {}) => ({ x0, x1, z0, z1, y, ...more });
const IN = (name, style, w, extra) => ({ name, theme: 'interior', style, interior: true, w, ground: [[0, w, 450]], exits: {}, ...extra });
const ring = (kind, x, z, r, n, k = 1) => Array.from({ length: n }, (_, i) => ({ kind, k, x: x + Math.cos((i / n) * Math.PI * 2) * r, z: z + Math.sin((i / n) * Math.PI * 2) * r * 0.7 }));
const row = (kind, x0, z0, x1, z1, n, k = 1) => Array.from({ length: n }, (_, i) => ({ kind, k, x: x0 + ((x1 - x0) * i) / Math.max(1, n - 1), z: z0 + ((z1 - z0) * i) / Math.max(1, n - 1) }));
// a line from whoever is travelling with you right now (if it's them)
const pal = (id, name, line) => ['if', A => A.s.partner === id, [['say', name, line]]];
const crayons = A => A.collectedCount('crayon');
// the Study Challenge counts assignments finished after it was given
const finishedSince = A => Math.max(0, A.stat('quests_done') - (A.s.doneBase ?? A.stat('quests_done')));

// the crayon colors of Doodle's five lost crayons (margin_play.js draws them)
export const CRAYON_COLORS = { crayon_1: '#ff6b6b', crayon_2: '#ffb347', crayon_3: '#ffe066', crayon_4: '#5fbf6a', crayon_5: '#b49cff' };

// ---------------------------------------------------------------- the new partner
export const MARGIN_PARTNERS = {
  doodle: {
    name: 'Doodle', hp: 10, color: '#5b8def',
    moves: [
      { id: 'scribble', name: 'Scribble', fp: 0, desc: 'Doodle dashes in and scribbles all over an enemy. Press SPACE as each scribble lands for another!' },
      { id: 'colorin', name: 'Color In', fp: 2, desc: 'Doodle colors your hearts back in: Wick and Doodle get 3 HP each. Press SPACE on the beat for 1 more.' },
      { id: 'outline', name: 'Outline', fp: 3, desc: 'Doodle outlines every enemy in bright crayon. For 2 turns every hit on them does 1 more damage.' },
    ],
    team: { name: 'Masterpiece', fp: 4, desc: 'Paint a giant picture together: SPACE, X, SPACE... on each brushstroke, faster and faster. Then it comes to life and hits every enemy, harder for every stroke. More strokes at higher Bond.' },
    field: { name: 'Sketch', desc: 'Doodle draws in dotted outlines: bridges, planks and steps. (Press C near a dotted outline.)' },
  },
};

// ---------------------------------------------------------------- enemies
export const MARGIN_ENEMIES = {
  erasebit: { name: 'Erasebit', hp: 4, atk: 2, def: 0, turn: 'erasebitTurn', xp: 26, coins: [2, 4], h: 34, lvl: 16,
    tattle: "An Erasebit. It rubs out anything that isn't perfect... including your FP! If its Rub Out gets you, you lose 2 FP. Max HP 4, Attack 2." },
  redpen: { name: 'Red Pen', hp: 5, atk: 2, def: 1, turn: 'redpenTurn', xp: 28, coins: [2, 4], h: 56, lvl: 16,
    tattle: "A Red Pen. It marks you WRONG with a big red ✗: while you're marked, every hit on you does 1 more damage. Guard the ✗! Defense 1. Max HP 5." },
  crumple: { name: 'Crumple', hp: 4, atk: 2, def: 0, turn: 'crumpleTurn', xp: 26, coins: [2, 3], h: 38, lvl: 16,
    tattle: "A Crumple: a draft somebody threw away. Hurt it without finishing it and it smooths itself out and starts over at full HP (once). Finish what you start! Max HP 4." },
  straightedge: { name: 'Straightedge', hp: 6, atk: 2, def: 1, turn: 'straightedgeTurn', xp: 32, coins: [3, 5], h: 70, lvl: 17,
    tattle: "A Straightedge. 'Only PERFECT counts!' A normal guard does nothing against its Strict Swing: SUPERGUARD it... or just take the hit. It's only 2. Defense 1. Max HP 6." },
  wastebasket: { name: 'The Wastebasket', hp: 32, atk: 2, def: 1, boss: true, turn: 'wastebasketTurn', xp: 220, coins: [60, 60], h: 130, scale: 1.3, lvl: 17,
    tattle: "The Wastebasket, where every 'not good enough' draft ends up. It tosses Crumples back out at you and slams its lid. At half HP it gets so full it overflows. Defense 1. Max HP 32." },
  pristine: { name: 'Queen Pristine', hp: 60, atk: 3, def: 1, boss: true, turn: 'pristineTurn', xp: 400, coins: [120, 120], h: 170, scale: 1.45, lvl: 19,
    tattle: "Queen Pristine, the Perfect Queen. She erases anything that isn't flawless. She calls Straightedges, rains red ink, and if the battle gets messy she calls a DO-OVER. Defense 1. Max HP 60." },
};

// ---------------------------------------------------------------- badges
export const MARGIN_BADGES = {
  rough_draft: { name: 'Rough Draft', bp: 1, desc: 'Done is better than perfect: a GOOD action command (not a PERFECT one) does 1 more damage.' },
  crayon_heart: { name: 'Crayon Heart', bp: 2, desc: 'Every PERFECT action command colors you back in: +1 HP and +1 FP.' },
  steady_hand: { name: 'Steady Hand', bp: 1, desc: "Nobody can mark you WRONG or rub out your FP." },
};

// ---------------------------------------------------------------- side quests
export const MARGIN_QUESTS = {
  crayons: { name: "Doodle's Lost Crayons", giver: 'Doodle', where: 'The Margin',
    desc: "The Erasebits chased Doodle all over the Margin, and five of her crayons fell out of her pocket. They're the only bright things around, so they're easy to spot.",
    progress: A => { const n = crayons(A); return { done: n >= 5, text: `Crayons found: ${n} of 5` }; },
    reward: { badge: 'crayon_heart', coins: 40 } },
  donebetter: { name: 'Done Is Better', giver: 'Mayor Margo', where: 'Draft Shore', study: true,
    desc: "Study Challenge: finish 2 whole assignments (every step checked off) from now on. Not perfect. Just done!",
    progress: A => { const n = finishedSince(A); return { done: n >= 2, text: `Assignments finished: ${Math.min(2, n)} of 2` }; },
    reward: { badge: 'rough_draft', starPieces: 2 } },
};

// ---------------------------------------------------------------- speakers
export const MARGIN_SPEAKERS = {
  Doodle: 'doodle', 'Captain Crease': 'crease', Erasebit: 'erasebit', 'Mayor Margo': 'draftee', 'Almost Al': 'draftee', 'Redo Ray': 'draftee',
  'Rough Ruth': 'draftee', 'Half-Done Hal': 'draftee', 'The Wastebasket': 'wastebasket', 'Queen Pristine': 'pristine', 'Color Fount': 'fount',
};
export const MARGIN_SPEAKER_OPTS = {
  'Mayor Margo': { hat: 'crown', color: '#ffd23f', color2: '#7fb2e6' },
  'Almost Al': { hat: 'cap', color: '#8be07a', color2: '#ff9a8f' },
  'Redo Ray': { hat: 'beret', color: '#ff9ab0', color2: '#b49cff' },
  'Rough Ruth': { hat: 'bow', color: '#ffb347', color2: '#7fd6ff' },
  'Half-Done Hal': { hat: 'beret', color: '#9fe6ff', color2: '#ffd23f' },
  'Queen Pristine': {},
};
export const MARGIN_PORTRAITS = { doodle: 2.2, crease: 1.2, draftee: 1.3, wastebasket: 0.62, pristine: 0.5, fount: 0.8 };

// ---------------------------------------------------------------- the story goal (data.js asks this after the ending)
export function marginGoal(A, G) {
  if (!A.flag('ending_seen') || A.flag('margin_done')) return null;
  if (!A.flag('margin_open')) return G("Go back to Lumen Town: there's a letter for you!", 'pro_1', 1350);
  if (!A.s.seenAreas.margin) return G('Take the paper boat at the Paper Pier, on the far shore of Mirror Lake', 'lake_1', 1900, "Walk to the back of Mirror Lake. The Paper Pier is on the shore, by Captain Crease. Step aboard with ↑.", 1380);
  if (!A.hasPartner('doodle')) return G("Find whoever sent the letter, in the village on the Draft Shore", 'margin_1', 1300, 'The village is up the shore, around the big fountain.', 1000);
  if (!A.flag('bin_down')) return G('Follow the road east into the Sketchwood, to the Green Fount', 'margin_2', 2850, "Doodle can draw in dotted outlines: press C next to one to make a bridge.", 1900);
  return G("Enter Pristine Palace and face Queen Pristine", 'margin_4', 700, 'The palace gate is at the far back of the Sketchwood, past the Green Fount.');
}
export const MARGIN_AFTER = 'The Margin is finished (well, finished enough)! Side quests, secrets and Study Challenges are still out there (ESC → Quests).';

// A field of the Margin is a pencil sketch on blank paper until its fount flows, then colored in: green crayon ground,
// a blue sky, leafy trees and flowers (the floor, sky and scenery all follow the theme; see art5.js)
const sketchOrColor = A => (A.marginColored() ? 'marginfree' : 'margin');

// the two looks of a Color Fount: blocked with a giant eraser, then (once the flag is set) flowing with color
const fount = (id, x, z, color, flag) => [
  { id: `${id}_cap`, x, z, kind: 'fount', name: 'Color Fount', talk: `${id}_look`, label: 'Look', opts: { color, capped: true }, show: A => !A.flag(flag) },
  { id: `${id}_on`, x, z, kind: 'fount', name: 'Color Fount', talk: 'fount_flowing', label: 'Look', opts: { color, flowing: true }, show: A => A.flag(flag) },
];

// ---------------------------------------------------------------- rooms
export const MARGIN_ROOMS = {
  // ======================= THE DRAFT SHORE: the boat lands on the blank edge of the page; up the shore, the village
  // of the Draftees (folks nobody ever finished drawing) and the Blue Fount; off to the east, the Sketchwood.
  margin_1: {
    name: 'Draft Shore', area: 'margin', theme: sketchOrColor, battleTheme: 'marginstage', w: 3200, z1: 2400,
    ground: [[0, 3200, 450]],
    hazard: 'blank',
    faded: 'fount_blue',
    roadColor: 'rgba(150,140,120,0.45)',
    holes: [[0, 140, -80, 2400], [2050, 2450, 1500, 1800], [380, 700, 1150, 1400]],   // the blank sea, and two erased patches
    terrain: [
      T(2180, 2320, 1600, 1700, 440, { base: 500, mat: 'stone' }),                                                  // a scrap of ground left in the middle of the erased patch
      T(300, 800, 1800, 2250, 330, { mat: 'stone' }), ramp(800, 960, 1900, 2100, 450, 330, 'west', 'stone'),       // Sketch Hill
    ],
    plazas: [[1100, 1500, 880, 1240, '#e6dfcf']],
    roads: [[260, 120, 820, 620, 80], [820, 620, 1150, 960, 80], [1450, 1060, 2300, 1060, 80], [2300, 1060, 3150, 220, 80]],
    groves: [[2650, 3200, 1300, 2400], [140, 380, 500, 1100]],
    // (bright houses: in the pencil-sketch Margin their colors only show in Wick's light, until the fount flows)
    props: [
      { kind: 'house', x: 900, z: 760, roof: '#e5534b', wall: '#fff3d6', wall2: '#f2d9a8' },
      { kind: 'house', x: 1160, z: 600, roof: '#5b8def', wall: '#f3f8ff', wall2: '#cfdcf2' },
      { kind: 'house', x: 1560, z: 660, roof: '#f2b134', wall: '#fff6e8', wall2: '#f0d6b0' },
      { kind: 'house', x: 1780, z: 1000, roof: '#5fbf6a', wall: '#f4fff0', wall2: '#d2ecc6' },
      { kind: 'house', x: 880, z: 1300, roof: '#b06bd6', wall: '#fbf2ff', wall2: '#e4cdf0' },
    ],
    decor: [...row('ruler', 1020, 1500, 1580, 1500, 5), ...ring('paperball', 2250, 1650, 250, 6, 0.9), { kind: 'pencil', x: 2550, z: 700, k: 1.2 }, { kind: 'eraserblock', x: 600, z: 760 }],
    lamps: [{ x: 420, z: 260 }, { x: 1300, z: 760 }],
    signs: [
      { x: 380, z: 120, text: "THE MARGIN. Under construction. Forever. Please don't finish anything. — Queen Pristine" },
      { x: 1980, z: 1420, text: "Erased ground ahead: nothing there but blank paper, and blank paper is VERY bouncy. (Somebody with a crayon could draw a bridge over it...)" },
      { x: 3000, z: 120, text: 'East: the Sketchwood. (Nobody ever finished coloring it in.)' },
    ],
    furniture: [{ kind: 'bench', x: 1220, z: 1230 }],
    npcs: [
      { id: 'crease_m', x: 240, z: 300, kind: 'crease', name: 'Captain Crease', talk: 'crease_margin' },
      { id: 'margo', x: 1250, z: 820, kind: 'draftee', name: 'Mayor Margo', talk: 'margo', opts: { hat: 'crown', color: '#ffd23f', color2: '#7fb2e6' } },
      { id: 'al', x: 980, z: 1000, kind: 'draftee', name: 'Almost Al', talk: 'al', opts: { hat: 'cap', color: '#8be07a', color2: '#ff9a8f' } },
      { id: 'ray', x: 1640, z: 1300, kind: 'draftee', name: 'Redo Ray', talk: 'ray', opts: { hat: 'beret', color: '#ff9ab0', color2: '#b49cff' }, flip: -1 },
      { id: 'ruth', x: 1700, z: 780, kind: 'draftee', name: 'Rough Ruth', talk: 'ruth', opts: { hat: 'bow', color: '#ffb347', color2: '#7fd6ff' }, flip: -1 },
      // Doodle, hiding behind the Blue Fount (until the Erasebits guarding it are gone)
      { id: 'doodle_npc', x: 1385, z: 1150, kind: 'doodle', name: 'Doodle', talk: 'doodle_hiding', opts: { mood: 'worried' }, flip: -1, show: A => !A.hasPartner('doodle') },
      ...fount('fount_blue', 1300, 1060, '#5b8def', 'fount_blue'),
    ],
    sketches: [{ id: 'sk_d1', x: 2215, y: 450, w: 70, z0: 1460, z1: 1615 }, { id: 'sk_d2', x: 520, y: 450, w: 70, z0: 1120, z1: 1430 }],
    chests: [
      { id: 'mg_isle', x: 2250, z: 1650, give: { starPiece: 1 } },
      { id: 'mg_village', x: 760, z: 1460, give: { coins: 40 } },
      { id: 'mg_hill', x: 520, z: 2150, give: { item: 'bighoney', n: 2 } },
    ],
    collect: [{ id: 'crayon_1', kind: 'crayon', x: 2700, y: 330, z: 600 }, { id: 'crayon_2', kind: 'crayon', x: 555, y: 400, z: 1280 }],
    blocks: [{ id: 'mg_b1', x: 1900, y: 300, z: 400, give: { coins: 10 } }, { id: 'mg_h1', x: 2600, y: 290, z: 1900, hidden: true, give: { starPiece: 1 } }],
    enemies: [
      { id: 'm1e1', x: 1950, z: 500, kind: 'erasebit', group: ['erasebit', 'erasebit'] },
      { id: 'm1e2', x: 2450, z: 900, kind: 'redpen', group: ['redpen'] },
      { id: 'm1e3', x: 2800, z: 1700, kind: 'erasebit', group: ['erasebit', 'redpen'] },
      { id: 'm1e4', x: 1100, z: 1900, kind: 'crumple', group: ['crumple', 'erasebit'] },
    ],
    doors: [{ x: 170, z: 330, to: 'lake_1', toX: 1900, label: "Captain Crease's boat", style: 'none' }],
    triggers: [
      { id: 'margin_card', x: 0, script: 'margin_card', once: true },
      { id: 'margin_arrive', x: 0, script: 'margin_arrive', once: true },
      { id: 'fount_guards', x: 1020, script: 'fount_blue_fight', when: A => !A.flag('fount_blue') && A.p.z > 820 && A.p.z < 1400 },
      { id: 'margin_party', x: 0, script: 'margin_party', once: true, when: A => A.flag('margin_done') },
    ],
    exits: { right: { to: 'margin_2', x: 60 } },
  },

  // ======================= THE SKETCHWOOD: a forest nobody ever finished coloring in, cut by erased ravines (Doodle
  // sketches bridges over them), with the Wastebasket's dump and the Green Fount at the far back, and the palace gate.
  margin_2: {
    name: 'The Sketchwood', area: 'margin', theme: sketchOrColor, battleTheme: 'marginstage', w: 3400, z1: 2600,
    ground: [[0, 3400, 450]],
    hazard: 'blank',
    faded: 'fount_green',
    roadColor: 'rgba(150,140,120,0.45)',
    holes: [[900, 1200, -80, 1400], [1700, 2100, 1650, 2050], [2350, 2600, 300, 900]],
    terrain: [T(1840, 1960, 1780, 1920, 440, { base: 500, mat: 'stone' })],
    groves: [[0, 850, 900, 2600], [1250, 1650, 300, 1300], [2650, 3400, 300, 1300]],
    clear: [[2450, 3400, 1450, 2600]],
    roads: [[60, 100, 880, 220, 80], [1220, 220, 2300, 1000, 80], [2300, 1000, 2850, 1750, 80]],
    decor: [...ring('paperball', 2900, 2000, 360, 14, 1), ...ring('paperball', 2900, 2000, 220, 8, 0.8), { kind: 'pencil', x: 2500, z: 1600, k: 1.3 }, { kind: 'pencil', x: 3300, z: 1700, k: 1.1 }, { kind: 'eraserblock', x: 1500, z: 1500 }],
    lamps: [{ x: 300, z: 240 }, { x: 2300, z: 1450 }],
    signs: [
      { x: 330, z: 120, text: "THE SKETCHWOOD. Nobody ever finished coloring it in. (Mind the erased bits: blank paper is VERY bouncy.)" },
      { x: 2380, z: 1500, text: 'THE DUMP. Everything that "wasn\'t good enough" ends up here. Beware of the bin.' },
    ],
    npcs: [
      { id: 'hal', x: 1500, z: 800, kind: 'draftee', name: 'Half-Done Hal', talk: 'hal', opts: { hat: 'beret', color: '#9fe6ff', color2: '#ffd23f' } },
      ...fount('fount_green', 2900, 2360, '#5fbf6a', 'fount_green'),
    ],
    furniture: [{ kind: 'painting', x: 1580, z: 760, pic: 'castle', label: 'Look', say: "Hal's painting: one tree. Just one, in the corner, very carefully done. The rest of the canvas is blank. It has been for twelve years." }],
    sketches: [{ id: 'sk_w1', x: 880, y: 450, w: 340, z0: 160, z1: 280 }, { id: 'sk_w2', x: 1875, y: 450, w: 60, z0: 1630, z1: 1785 }, { id: 'sk_w3', x: 2330, y: 450, w: 290, z0: 560, z1: 660 }],
    boss: { kind: 'wastebasket', x: 2900, z: 2000, flag: 'bin_down', scale: 1.3, awake: true },
    chests: [
      { id: 'mw_isle', x: 1900, z: 1850, give: { starPiece: 1 } },
      { id: 'mw_dump', x: 3200, z: 2350, give: { item: 'feather' } },
      { id: 'mw_hal', x: 1360, z: 1000, give: { coins: 30 } },
      { id: 'mw_ravine', x: 2500, z: 1000, give: { item: 'bighoney', n: 2 } },
    ],
    collect: [{ id: 'crayon_3', kind: 'crayon', x: 1060, y: 360, z: 1300 }, { id: 'crayon_4', kind: 'crayon', x: 3150, y: 300, z: 950 }],
    blocks: [{ id: 'mw_b1', x: 2000, y: 300, z: 600, give: { coins: 10 } }, { id: 'mw_h1', x: 600, y: 290, z: 600, hidden: true, give: { item: 'embertea', n: 2 } }],
    enemies: [
      { id: 'm2e1', x: 1450, z: 450, kind: 'crumple', group: ['crumple', 'crumple'] },
      { id: 'm2e2', x: 2050, z: 1250, kind: 'straightedge', group: ['straightedge'] },
      { id: 'm2e3', x: 2700, z: 650, kind: 'redpen', group: ['redpen', 'crumple'] },
      { id: 'm2e4', x: 1100, z: 1900, kind: 'erasebit', group: ['erasebit', 'erasebit', 'crumple'] },
      { id: 'm2e5', x: 3100, z: 1300, kind: 'straightedge', group: ['straightedge', 'erasebit'] },
    ],
    doors: [{ x: 3250, z: 2470, to: 'margin_3', toX: 160, label: 'Pristine Palace', need: 'fount_green',
      needText: "A gate of perfectly white paper, with a sign: 'NO UNFINISHED THINGS BEYOND THIS POINT.' It won't budge. (Something in the dump is keeping it shut.)" }],
    triggers: [
      { id: 'sketch_tip', x: 640, script: 'sketch_tip', once: true, when: A => A.hasPartner('doodle') },
      { id: 'bin_fight', x: 2450, script: 'bin_fight', when: A => !A.flag('bin_down') && A.p.z > 1600 },
    ],
    exits: { left: { to: 'margin_1', x: 3140 } },
  },

  // ======================= PRISTINE PALACE: the Gallery of Almost (unfinished paintings, perfect guards)
  margin_3: IN('The Gallery of Almost', 'palace', 2800, {
    area: 'margin', battleTheme: 'palacestage', windows: [420, 1460, 2420], faded: 'margin_done',
    ground: [[0, 900, 450], [1200, 1900, 450], [2200, 2800, 450]],
    hazard: 'blank',
    lamps: [300],
    sketches: [{ id: 'sk_p1', x: 880, y: 450, w: 340 }, { id: 'sk_p2', x: 1880, y: 450, w: 340 }],
    plats: [[1500, 340, 120]],
    furniture: [
      { kind: 'painting', x: 560, pic: 'castle', label: 'Look', say: "A portrait of Queen Pristine. Half of her face is erased. A little card underneath: 'Not quite right. Will try again in a hundred years.'" },
      { kind: 'painting', x: 1340, pic: 'castle', label: 'Look', say: "A bowl of fruit. Well, a bowl. The fruit 'wasn't perfect', so it was erased. The bowl looks lonely." },
      { kind: 'painting', x: 1720, pic: 'castle', label: 'Look', say: "A landscape: a lovely sky, and then nothing at all. In the corner, very small: 'the hills were wrong'." },
      { kind: 'painting', x: 2420, pic: 'castle', label: 'Look', say: "An empty golden frame, polished to a shine. The label says 'MASTERPIECE (coming soon)'. The dust on it is a hundred years thick." },
      { kind: 'banner', x: 980, color: '#e8dfc6' }, { kind: 'banner', x: 2120, color: '#e8dfc6' },
      { kind: 'armor', x: 2270 },   // (well clear of the throne room door: right beside it, you could hop up on it and not reach the door)
    ],
    signs: [
      { x: 360, text: "PRISTINE PALACE. Please wipe your feet. Then wipe them again. Then wipe them PERFECTLY." },
      { x: 780, text: "No bridge? The Queen erased it for being 'slightly crooked'. (Doodle could sketch a new one: press C.)" },
    ],
    collect: [{ id: 'crayon_5', kind: 'crayon', x: 1560, y: 300 }],   // (on the little ledge: hop up onto it)
    chests: [{ id: 'mp_badge', x: 2550, give: { badge: 'steady_hand' } }],
    enemies: [
      { id: 'm3e1', x: 640, kind: 'straightedge', group: ['straightedge'], range: 70 },
      { id: 'm3e2', x: 1450, kind: 'redpen', group: ['redpen', 'straightedge'], range: 70 },
      { id: 'm3e3', x: 2400, kind: 'erasebit', group: ['erasebit', 'erasebit', 'redpen'], range: 70 },
    ],
    doors: [
      { x: 120, to: 'margin_2', toX: 3250, label: 'The Sketchwood', exit: true },
      { x: 2700, to: 'margin_4', toX: 160, label: 'The Blank Throne' },
    ],
    triggers: [{ id: 'gallery', x: 300, script: 'gallery_enter', once: true }],
  }),

  // ======================= THE BLANK THRONE: Queen Pristine, and the last (Red) Color Fount
  margin_4: {
    name: 'The Blank Throne', area: 'margin', theme: 'blankthrone', battleTheme: 'blankthrone', w: 1600, faded: 'margin_done',
    ground: [[0, 1600, 450]],
    boss: { kind: 'pristine', x: 1150, flag: 'margin_done', scale: 1.45, awake: true },
    npcs: [
      { id: 'pristine_npc', x: 1150, kind: 'pristine', name: 'Queen Pristine', talk: 'pristine_after', opts: { scale: 1.15, mood: 'happy' }, flip: -1, show: A => A.flag('margin_done') },
      ...fount('fount_red', 380, null, '#e5534b', 'margin_done'),
    ],
    triggers: [{ id: 'pristine', x: 640, script: 'pristine_fight', when: A => !A.flag('margin_done') }],
    doors: [{ x: 140, to: 'margin_3', toX: 2700, label: 'The Gallery of Almost' }],
    exits: {},
  },
};
// (the throne room is an old-style narrow room: its fountain needs no depth)
for (const n of MARGIN_ROOMS.margin_4.npcs) if (n.z === null) delete n.z;

// ---------------------------------------------------------------- story scripts
export const MARGIN_SCRIPTS = {
  // ---- the letter (in Lumen Town, after the ending)
  margin_call: [
    ['cut', 'plane'],
    ['narrate', "A paper airplane loops over the rooftops of Lumen Town... and lands right at Wick's feet."],
    ['say', 'Mothwick', 'A letter? For you, Wick! The handwriting is very... wobbly. Let me read it out.'],
    ['say', 'Mothwick', '"To whoever lit that great big light: HELP! Everything here keeps getting ERASED. We live past the edge of the map, in the Margin. Please come!"'],
    ['say', 'Mothwick', '"P.S. Sorry about my handwriting. It is not very good. — Doodle"'],
    ['say', 'Count Dusk', "The Margin? Past the edge of the map? ...Oh dear. That's Queen Pristine's land."],
    ['say', 'Count Dusk', "She erases anything that isn't perfect. So nothing there ever gets finished. Not a house, not a song, not even a sandwich. It's been a first draft for a hundred years."],
    ['say', 'Count Dusk', 'And believe me, I know a thing or two about never finishing things.'],
    ['say', 'Mothwick', "Captain Crease's paper boat still sails from the Paper Pier, on the far shore of Mirror Lake. He'll take you past the edge of the map."],
    pal('moss', 'Moss', 'blorp! a boat! made of paper! ...on water. hm.'),
    pal('tick', 'Tick', "RING-A-DING! Somebody needs help? Then it's time to GO!"),
    ['flag', 'margin_open'],
    ['tip', 'Bonus Chapter! Go to Mirror Lake (west of Lumen Fields) and find the Paper Pier on the far shore of the lake.', 10],
  ],
  // ---- the Paper Pier at Mirror Lake
  crease: [
    ['if', A => !A.flag('margin_open'), [
      ['say', 'Captain Crease', "Ahoy! Captain Crease. I fold myself a new boat every morning. Nowhere to sail to these days, though."],
    ], [
      ['if', A => !A.s.seenAreas.margin, [
        ['say', 'Captain Crease', "Ahoy! Captain Crease, at your service. Folded myself out of an old sea chart, I did."],
        ['say', 'Captain Crease', "Past the edge of the map, you say? To the Margin? Aye, I sail there. Not many ask."],
        ['say', 'Captain Crease', "Step aboard (walk onto the pier and press ↑) whenever you're ready!"],
      ], [
        ['say', 'Captain Crease', 'Back to the Margin? Step aboard whenever you like!'],
      ]],
    ]],
  ],
  crease_margin: [
    ['say', 'Captain Crease', "My boat's right here whenever you want to sail home to Mirror Lake. Just step aboard (↑ by the boat)."],
    ['if', A => !A.hasPartner('doodle'), [['say', 'Captain Crease', "Whoever wrote that letter must live in the village up the shore. Go on, I'll wait!"]]],
  ],

  // ---- arriving
  margin_card: [['card', 'Bonus Chapter', 'The Unfinished Margin']],
  margin_arrive: [
    ['narrate', 'Past the edge of the map, the world just... stops being finished. Everything here is a pencil sketch. There is no color at all.'],
    ['narrate', "Well, almost none. Wherever Wick's lantern light falls, the color comes rushing back."],
    pal('moss', 'Moss', "blorp... it's all gray. even the grass. ESPECIALLY the grass."),
    pal('hoot', 'Hoot', 'Fascinating. A whole land left as a first draft. Someone has been rubbing it out.'),
    pal('pebble', 'Pebble', '...the rocks are only outlines. sad rocks.'),
    pal('ember', 'Ember', "WHO ERASED ALL THE COLOR?! I'll color it back in MYSELF! ...Maybe not with fire."),
    pal('tick', 'Tick', "This whole place is stuck on the first draft! Somebody needs to tell it it's time to FINISH!"),
    ['say', 'Captain Crease', "Here we are: the Margin. Whoever sent that letter must be in the village, up the shore. I'll wait right here by the boat!"],
  ],

  // ---- the Draftees of Draft Shore
  margo: [
    ['if', A => !A.flag('fount_blue'), [
      ['say', 'Mayor Margo', "A visitor! In COLOR! Oh, you're glowing. We haven't seen a color since... well. Since ever."],
      ['say', 'Mayor Margo', "I'm the mayor. Well, a sketch of a mayor. Queen Pristine never lets anyone get finished, you see."],
      ['say', 'Mayor Margo', "Our Color Founts used to fill the whole Margin with color. She jammed giant erasers in them. 'Better blank than imperfect,' she said."],
      ['say', 'Mayor Margo', "Now her Erasebits guard the fountain right here in the square, and rub out anyone who tries to color anything in."],
    ], [
      ['if', A => !A.flag('margin_done'), [
        ['say', 'Mayor Margo', "LOOK AT ME! I have a NOSE! And it's a bit lopsided and I LOVE it!"],
        ['say', 'Mayor Margo', "The Green Fount is in the Sketchwood, to the east. And the Queen lives in her palace past it. Please be careful."],
      ], [
        ['if', A => !A.questKnown('donebetter'), [
          ['say', 'Mayor Margo', "Hero! The whole Margin is finished! Well, finished enough. And it's the best thing I've ever seen."],
          ['say', 'Mayor Margo', "Here's something for your Hero of Homework: two whole assignments. Not perfect. Just DONE. Done is better than perfect!"],
          ['if', A => { A.s.doneBase = A.stat('quests_done'); return true; }, [['quest', 'donebetter']]],
          ['narrate', 'New Study Challenge: Done Is Better! (ESC → Quests)'],
        ], [
          ['if', A => A.questReady('donebetter'), [['turnin', 'donebetter'], ['say', 'Mayor Margo', "Two whole assignments, DONE! You know what? I'm going to finish my speech now. It's short. Ahem: HOORAY!"]], [
            ['say', 'Mayor Margo', A => (A.questDone('donebetter') ? 'Done is better than perfect! I had it painted on the town hall. The letters are wonky. Perfect.'
              : `Assignments finished since I asked: ${Math.min(2, finishedSince(A))} of 2. Not perfect. Just done!`)],
          ]],
        ]],
      ]],
    ]],
  ],
  al: [['say', 'Almost Al', A => (A.flag('fount_blue')
    ? "I finished my house! Well, the door is the wrong shape. It's fine! I can still go in it! I've been in and out forty times!"
    : "I almost finished my house. Then the Erasebits came and rubbed it out because the door was a bit crooked. That's the 112th time. I'll start over... once I can do it perfectly.")]],
  ray: [['say', 'Redo Ray', A => (A.flag('fount_blue')
    ? "I painted a self-portrait! One go, no do-overs. I look like a potato. A HAPPY potato. I'm keeping it!"
    : "I've drawn my self-portrait four hundred times. It's never right, so I rub it out. ...I don't actually remember what I look like anymore.")]],
  ruth: [['say', 'Rough Ruth', A => (A.flag('fount_blue')
    ? "I baked bread! It's lumpy. It tastes AMAZING. Turns out bread doesn't care if it's perfect."
    : "I'm a baker! Well, I would be. Every loaf gets erased before it's out of the oven. 'Not perfectly round,' they say. I'm SO hungry.")]],
  hal: [['say', 'Half-Done Hal', A => (A.flag('fount_green')
    ? "I painted the WHOLE canvas! In one afternoon! Half of it's wrong and I've never been prouder. Twelve years for one tree, one afternoon for everything else!"
    : "I've been painting this tree for twelve years. It's nearly perfect. Then I'll start on the rest. ...Maybe I should just paint the rest? No. The tree first. It has to be perfect.")]],
  fount_blue_look: [['say', 'Color Fount', "A stone fountain with a gigantic pink eraser jammed in the top. Not a drop of color comes out."]],
  fount_green_look: [['say', 'Color Fount', "Another fountain, blocked with a giant eraser. The Wastebasket's lid is rattling nearby."]],
  fount_red_look: [['say', 'Color Fount', "The last fountain, right next to the Queen's throne. Its eraser is polished to a perfect shine."]],
  fount_flowing: [['say', 'Color Fount', "Color pours out of the fountain and runs off across the paper in little rivers of crayon."]],
  doodle_hiding: [['say', 'Doodle', "Eep! Is... is it safe? The Erasebits are still around! I'm hiding until they go away. Forever, probably."]],

  // ---- the Blue Fount: the Erasebits, Doodle, and the first color
  fount_blue_fight: [
    ['say', 'Erasebit', 'HALT! This fountain is closed until the Margin is PERFECT. Which is never!'],
    ['say', 'Erasebit', "And what's THAT? A glowing candle? You're all SMUDGY! Rub him out!"],
    ['battle', ['erasebit', 'erasebit', 'redpen']],
    ['say', 'Doodle', "...Did they go? Are they gone? Oh! You came! You actually came!"],
    ['say', 'Doodle', "I'm Doodle! I sent the letter! Sorry it was so messy. I'm a crayon. Crayons are messy. That's kind of our whole thing."],
    ['say', 'Doodle', "The Erasebits chase me everywhere, because whatever I draw is never perfect. So I stopped drawing. And then I stopped coming out."],
    pal('moss', 'Moss', 'blorp. messy is good. i am made of goo. i would know.'),
    pal('hoot', 'Hoot', 'Young lady, every masterpiece in history started as a mess.'),
    pal('tick', 'Tick', "It doesn't have to be perfect! It just has to get STARTED!"),
    ['say', 'Doodle', "...You really think so? Then... watch this. Erasers can't rub out crayon. Not if you press really hard!"],
    ['narrate', 'Doodle scribbles all over the giant eraser. Big, wobbly, bright blue scribbles. The eraser cracks... and pops right out!'],
    ['flag', 'fount_blue'],
    ['cut', 'color_flood'],
    ['narrate', "COLOR! Blue, then every color at once, rushing out of the fountain and running across the Draft Shore!"],
    ['say', 'Doodle', "I... I did that? With a SCRIBBLE?! It wasn't even a good scribble!"],
    ['say', 'Doodle', "There are two more founts: the Green one in the Sketchwood, and the Red one in the Queen's palace. Can I come with you? I can draw stuff! Messy stuff, but still!"],
    ['partner', 'doodle'],
    ['narrate', 'Doodle joined your party! In battle she Scribbles, Colors In your hearts and Outlines enemies. In the field, press C near a dotted outline and she sketches it in: bridges, planks, steps.'],
    ['say', 'Doodle', "Oh no. I lost my crayons! Five of them fell out of my pocket when the Erasebits chased me. They're the only bright things around here, so they should be easy to spot..."],
    ['quest', 'crayons'],
    ['tip', 'Press C next to a dotted outline and Doodle sketches it in. Try the erased patches by the village!', 10],
  ],
  crayons_done: [
    ['say', 'Doodle', "ALL FIVE! My whole crayon box! Red, orange, yellow, green, purple... and me! I'm the blue one!"],
    ['turnin', 'crayons'],
    ['say', 'Doodle', "Here, I made you this. It's a heart. It's a bit lopsided. It's the best heart I've ever made!"],
  ],

  // ---- the Sketchwood
  sketch_tip: [
    ['say', 'Doodle', "See those dotted lines over the erased ravine? That's where a bridge used to be, before the Queen erased it for being crooked."],
    ['say', 'Doodle', "I can sketch it back in! Walk up to the dotted outline and press C. It'll be a wobbly bridge. But wobbly bridges hold you up just fine!"],
  ],
  bin_fight: [
    ['say', 'The Wastebasket', 'CRUMPLE! CRUMPLE! Another one for the bin! Everything that isn\'t good enough comes to ME!'],
    ['cut', 'boss_wake'],
    ['say', 'Doodle', "That's the Wastebasket! Every drawing anyone ever threw away is in there... mine too. Hundreds of mine."],
    ['say', 'The Wastebasket', "Oooh, a CANDLE! Slightly melted! Bit of a drip on the side! NOT GOOD ENOUGH! INTO THE BIN!"],
    ['battle', ['wastebasket'], { boss: true }],
    ['say', 'The Wastebasket', "...oof. I'm so FULL. Do you know how heavy a hundred years of 'not good enough' is?"],
    ['say', 'Doodle', "Hey... these drawings in here aren't bad at all. Look, this one's a horse! Sort of. It has five legs. It's GREAT."],
    ['say', 'The Wastebasket', "...You think? They looked fine to me too. Nobody ever asked the bin."],
    ['narrate', 'The Wastebasket spits out the eraser that was jamming the Green Fount. PTOO!'],
    ['flag', 'bin_down'],
    ['flag', 'fount_green'],
    ['cut', 'color_flood'],
    ['narrate', 'Green, then every color at once, pours out across the Sketchwood! The pencil trees fill in with leaves.'],
    ['say', 'Doodle', "Two founts! One more, and it's in the Queen's palace. The gate is right behind the dump. ...I'm scared. But I'm coming anyway."],
  ],

  // ---- the palace
  gallery_enter: [
    ['narrate', 'Pristine Palace. Everything is white, and spotless, and perfectly straight. It is the quietest place Wick has ever been.'],
    ['say', 'Doodle', "These are all the Queen's paintings. She never finishes any of them. Not one. She says they're 'almost' perfect."],
    pal('hoot', 'Hoot', '"Almost" is a very comfortable place to hide.'),
  ],
  pristine_fight: [
    ['say', 'Queen Pristine', 'Stop. Right there. Do not take one more smudgy step on my floor.'],
    ['say', 'Queen Pristine', "A candle. Dripping wax. Wobbly flame. And a CRAYON. A crayon who colors outside the lines."],
    ['say', 'Doodle', "...I d-do color outside the lines. A lot. On purpose sometimes!"],
    ['say', 'Queen Pristine', "In MY Margin, nothing is finished until it is perfect. A blank page can never be wrong. Isn't that wonderful? Nothing here will EVER be wrong."],
    ['say', 'Doodle', "But a blank page can't be anything at ALL!"],
    ['say', 'Queen Pristine', "...How dare you. Very well. I shall erase you both. Perfectly."],
    ['battle', ['pristine'], { boss: true, music: 'pristine' }],
    ['say', 'Queen Pristine', '...My crown is crooked. My gown is smudged. I am... messy.'],
    ['say', 'Doodle', "Here. I drew you something. It's you! You're smiling in it. The smile's a bit wonky."],
    ['say', 'Queen Pristine', "...It's crooked. It's messy. The colors go everywhere. ...It's the first thing in this palace anyone ever finished."],
    ['say', 'Queen Pristine', "I erased everything because I was afraid it would be wrong. But the only thing that's really wrong... is a hundred years of nothing."],
    ['narrate', 'Queen Pristine raises her scepter... and, for the very first time, uses it to lift the eraser OUT of the last fountain.'],
    ['flag', 'margin_done'],
    ['cut', 'color_flood'],
    ['narrate', 'RED! Then every color in the crayon box, all at once! It floods out of the palace and across the whole Margin: the shore, the woods, the village, everything!'],
    ['card', 'Bonus Chapter complete!', 'The Margin is finished. (Well, finished enough!)'],
    ['goto', 'margin_1', 1300],
  ],
  pristine_after: [['say', 'Queen Pristine', "I've turned my palace into a gallery of FINISHED things. Messy, wobbly, done. It's my favorite place now. I even have a bench for sitting on. It's a little uneven."]],
  margin_party: [
    ['narrate', 'Down on the Draft Shore, every Draftee is out in the square, fully colored in for the very first time.'],
    ['say', 'Mayor Margo', 'Our hero! Look at us! We have COLORS! I have no idea what to do with them and I love it!'],
    ['say', 'Rough Ruth', 'Lumpy bread for everyone!'],
    ['say', 'Doodle', "Wick... thank you. I'm going to keep every single drawing from now on. Even the bad ones. ESPECIALLY the bad ones."],
    ['say', 'Doodle', "Is it okay if I keep coming with you? I want to draw ALL of Lumenfold. Messily."],
    pal('ember', 'Ember', 'ONE MESSY THING AT A TIME!'),
    ['narrate', 'Mayor Margo has a Study Challenge for the Hero of Homework. (Talk to her!)'],
  ],
};

// ---------------------------------------------------------------- hooking it into Lumenfold (data.js runs this last)
export function patchMargin(ROOMS, SCRIPTS, AREAS) {
  // the letter arrives in Lumen Town after the ending (right after THE END, like a scene after the credits; or, for
  // a save that saw the ending before this chapter existed, the next time you're in town)
  ROOMS.pro_1.triggers.push({ id: 'margin_call', x: 0, script: 'margin_call', once: true, when: A => A.flag('ending_seen') });
  // the Paper Pier, on the far (north) shore of Mirror Lake
  const lake = ROOMS.lake_1;
  (lake.npcs = lake.npcs || []).push({ id: 'crease', x: 1800, z: 1330, kind: 'crease', name: 'Captain Crease', talk: 'crease', flip: 1, show: A => A.flag('ending_seen') });
  (lake.doors = lake.doors || []).push({ x: 1900, z: 1380, to: 'margin_1', toX: 280, label: 'Paper Pier', style: 'none', need: 'margin_open',
    needText: "An empty little pier made of folded paper. Nobody has sailed from here in a long, long time." });
  (lake.boats = lake.boats || []).push({ x: 1900, z: 1500, show: A => A.flag('margin_open') });
  ROOMS.margin_1.boats = [{ x: 60, z: 330 }];
  AREAS.margin = { name: 'The Margin', start: 'margin_1', x: 300, icon: '✏️', mx: 0.04, my: 0.98, music: 'margin' };
  void SCRIPTS;
}
