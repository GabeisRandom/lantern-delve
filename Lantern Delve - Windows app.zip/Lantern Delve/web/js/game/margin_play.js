// How the Bonus Chapter plays (its rooms and story are in margin.js). MARGIN_FIELD goes onto the Adventure: the
// pencil-sketch look of the Margin (Wick's light brings the color back), Doodle's Sketch, the paper boats, Doodle's lost
// crayons and the chapter's cutscenes. MARGIN_BATTLE goes onto the Battle: Doodle's moves and her Masterpiece team
// attack, the Margin's creatures, the Wastebasket and Queen Pristine.
import { INK, glowDot } from '../art.js';
import { view, HZ, GZ0, GZ1 } from '../art2.js';
import { sfx } from '../audio.js';
import { MARGIN_PARTNERS, MARGIN_SPEAKER_OPTS, CRAYON_COLORS } from './margin.js';

const W = 960, H = 540, FLOOR = 452, TAU = Math.PI * 2;
const lerp = (a, b, p) => a + (b - a) * p;
const ease = p => (p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2);
const SKETCH_REACH = 360;   // how near a dotted outline has to be for Doodle to sketch it in
const FLOOD = 2.2;          // seconds the color takes to flood out of a fount
const CRAYON = ['#ff6b6b', '#ffb347', '#ffe066', '#5fbf6a', '#5b8def', '#b49cff'];
// The Margin's art is in art5.js (it adds Doodle, the Draftees, the enemies and the scenery to the DRAW lists). It's
// loaded on its own, so even if it ever failed to load, the rest of the game would keep working.
let ART5 = {};
import('../art5.js').then(m => { ART5 = m; }).catch(e => console.error('art5.js', e));

// ---------------------------------------------------------------- in the field
export const MARGIN_FIELD = {
  // A Margin room stays a pencil sketch until its fount flows (and they all color in once the Queen is beaten).
  marginColored(R = this.room) { return !R || !R.faded || this.flag(R.faded) || this.flag('margin_done'); },

  // The platforms a room has right now: its own, plus every dotted outline Doodle has sketched in.
  platList(R) {
    const sk = (R.sketches || []).filter(s => this.s.revealed[s.id]).map(s => [s.x, s.y, s.w, s.z0, s.z1]);
    return [...(R.plats || []), ...sk].map(p => {
      const full = p[3] == null && this.groundLevelAt(p[0] + p[2] / 2) == null;
      return { x: p[0], y: p[1], w: p[2], z0: p[3] ?? (full ? GZ0 + 10 : -50), z1: p[4] ?? (full ? GZ1 - 10 : 90), full };
    });
  },

  // Doodle's Sketch (C): every dotted outline nearby gets drawn in with a wobbly crayon line, for good
  sketchStart() {
    const R = this.room, P = this.p;
    this.partnerSq = 0.6;
    const near = (R.sketches || []).filter(s => !this.s.revealed[s.id] && Math.abs(s.x + s.w / 2 - P.x) < SKETCH_REACH + s.w / 2
      && (s.z0 == null || Math.abs((s.z0 + s.z1) / 2 - P.z) < SKETCH_REACH));
    if (!near.length) { this.float('Doodle: Nothing to draw here... (look for dotted outlines!)', P.x, P.y - 100, '#9fc4ff'); return; }
    for (const s of near) {
      this.s.revealed[s.id] = true;
      for (let i = 0; i < 18; i++) {
        this.parts.push({ x: s.x + Math.random() * s.w, y: s.y - 6, z: s.z0 != null ? s.z0 + Math.random() * (s.z1 - s.z0) : P.z,
          vx: (Math.random() - 0.5) * 140, vy: -60 - Math.random() * 140, life: 0.8, c: CRAYON[i % CRAYON.length], g: 200, star: i % 3 === 0 });
      }
    }
    this.staticPlats = this.platList(R);
    this.buildSolids();
    sfx('unfold'); sfx('chime');
    this.float(near.length > 1 ? `Doodle: SKETCH! (${near.length} of them!)` : 'Doodle: SKETCH!', P.x, P.y - 100, '#9fc4ff');
    this.saveSoon();
  },

  // things on the floor, in the far-to-near list: Doodle's dotted outlines, paper boats; and the Draftees color in
  // (with their portraits) along with their land
  drawMarginList(c, V, t, add, cut) {
    const R = this.room, P = this.p;
    const colored = this.marginColored(R);
    for (const n of R.npcs || []) if (n.kind === 'draftee') (n.opts ||= {}).colored = colored;
    if (R.area === 'margin') for (const o of Object.values(MARGIN_SPEAKER_OPTS)) o.colored = colored;
    for (const s of R.sketches || []) {
      if (this.s.revealed[s.id]) continue;
      const full = s.z0 == null && this.groundLevelAt(s.x + s.w / 2) == null;
      const z0 = s.z0 ?? (full ? GZ0 + 10 : -50), z1 = s.z1 ?? (full ? GZ1 - 10 : 90);
      if (z1 < V.camZ - 400) continue;
      const near = this.s.partner === 'doodle' && Math.abs(s.x + s.w / 2 - P.x) < SKETCH_REACH + s.w / 2 && Math.abs((z0 + z1) / 2 - P.z) < SKETCH_REACH;
      add((z0 + z1) / 2, 0, () => this.drawOutline(c, V, s.x, s.y, s.w, Math.max(z0, V.camZ - 380), z1, t, near));
    }
    const wy = R.hazardY ?? 500;
    if (ART5.drawPaperBoat) for (const b of R.boats || []) if (!b.show || b.show(this)) cut(b.x, wy, b.z ?? 0, 0, () => ART5.drawPaperBoat(c, 0, 0, t), 190);
  },

  // a dotted outline of the plank Doodle can draw in, glowing when she's close enough
  drawOutline(c, V, x, y, w, z0, z1, t, near) {
    const P = (xx, yy, z) => [V.x(xx, z), V.y(yy, z)];
    const pts = [P(x, y, z1), P(x + w, y, z1), P(x + w, y, z0), P(x, y, z0)];
    c.save();
    c.setLineDash([9, 7]); c.lineDashOffset = -t * 24; c.lineCap = 'round';
    c.fillStyle = near ? 'rgba(91,141,239,0.16)' : 'rgba(120,120,140,0.08)';
    c.beginPath(); c.moveTo(...pts[0]); for (const p of pts.slice(1)) c.lineTo(...p); c.closePath(); c.fill();
    c.strokeStyle = near ? `rgba(91,141,239,${0.75 + 0.25 * Math.sin(t * 5)})` : 'rgba(110,105,130,0.7)'; c.lineWidth = near ? 3 : 2;
    c.stroke();
    const [fx0, fy0] = pts[3], [fx1] = pts[2], fy1 = V.y(y + 16, z0);
    c.beginPath(); c.moveTo(fx0, fy0); c.lineTo(fx0, fy1); c.lineTo(fx1, fy1); c.lineTo(fx1, fy0); c.stroke();
    c.restore();
    if (near) {
      const [cx, cy] = P(x + w / 2, y, (z0 + z1) / 2);
      c.font = `bold ${Math.round(15 * Math.max(0.7, V.s((z0 + z1) / 2)))}px Fredoka, sans-serif`; c.textAlign = 'center';
      c.lineWidth = 4; c.strokeStyle = INK; c.strokeText('✏️ C: Sketch', cx, cy - 18 + Math.sin(t * 4) * 3);
      c.fillStyle = '#cfe0ff'; c.fillText('✏️ C: Sketch', cx, cy - 18 + Math.sin(t * 4) * 3);
    }
  },

  // a crayon floating in the field (Doodle's lost crayons)
  drawCrayonItem(c, it, tt) {
    if (ART5.drawCrayon) ART5.drawCrayon(c, 0, 0, tt, CRAYON_COLORS[it.id]);
    else glowDot(c, 0, -10, 22, '255,224,140', 0.8);
  },

  async crayonPickedUp(it) {
    sfx('chime');
    const n = this.collectedCount('crayon');
    this.float(`Doodle's crayon! (${n}/5)`, it.x, it.y - 50, CRAYON_COLORS[it.id] || '#ffe066', it.z);
    if (!this.questKnown('crayons')) { this.tip('A crayon! The brightest thing for miles. Somebody around here must have dropped it.', 5); return; }
    if (n >= 5 && this.questActive('crayons')) await this.runScript('crayons_done');
  },

  // The pencil-sketch look: everything is drained of color except inside Wick's glow (bigger while he flares). When a
  // fount starts flowing, the color floods out from it across the whole screen.
  drawMarginFade(c) {
    const R = this.room, P = this.p;
    if (!R || !R.faded || !P) return;
    const F = this.colorFlood;
    if (F && this.t - F.t0 > FLOOD) this.colorFlood = null;
    if (this.marginColored(R) && !this.colorFlood) return;
    const camX = Math.round(this.camX);
    const V = view(camX, HZ, W, { camZ: this.camZ || 0, zb: this.zb });
    const k = Math.min(1.4, Math.max(0.6, V.s(P.z)));
    let sx = V.x(P.x, P.z) - camX, sy = V.y(P.y - 40, P.z), r0 = 70 * k, r1 = (this.flareOn ? 340 : 230) * k;
    if (this.colorFlood) {
      const e = ease(Math.min(1, (this.t - this.colorFlood.t0) / FLOOD));
      const fz = this.colorFlood.z ?? 0, fy = this.surfaceAt(this.colorFlood.x, fz) - 60;
      sx = lerp(sx, V.x(this.colorFlood.x, fz) - camX, Math.min(1, e * 3)); sy = lerp(sy, V.y(fy, fz), Math.min(1, e * 3));
      r0 += e * 1300; r1 += e * 1500;
    }
    c.save();
    const g = c.createRadialGradient(sx, sy, r0, sx, sy, r1);
    g.addColorStop(0, 'rgba(128,128,128,0)'); g.addColorStop(1, 'rgba(128,128,128,1)');
    c.globalCompositeOperation = 'saturation'; c.fillStyle = g; c.fillRect(0, 0, W, H);
    c.globalCompositeOperation = 'source-over';
    const g2 = c.createRadialGradient(sx, sy, r0, sx, sy, r1 * 1.15);
    g2.addColorStop(0, 'rgba(250,246,236,0)'); g2.addColorStop(1, 'rgba(250,246,236,0.24)');
    c.fillStyle = g2; c.fillRect(0, 0, W, H);
    c.restore();
  },

  // over the room: the paper airplane with Doodle's letter
  drawMarginOver(c) {
    if (this.cut.plane == null || !this.p) return;
    const p = Math.min(1, (this.t - this.cut.plane) / 1.6), P = this.p, camX = Math.round(this.camX);
    const V = view(camX, HZ, W, { camZ: this.camZ || 0, zb: this.zb });
    const tx = V.x(P.x + 46, P.z) - camX, ty = V.y(P.y - 4, P.z);
    const pos = q => [lerp(-60, tx, q) + Math.sin(q * 9) * 40 * (1 - q), lerp(50, ty, q * q) - Math.sin(q * Math.PI) * 90];
    const [x, y] = pos(p), [x2, y2] = pos(Math.min(1, p + 0.02));
    c.save(); c.translate(x, y); c.rotate(p >= 1 ? 0.1 : Math.atan2(y2 - y, x2 - x));
    c.fillStyle = '#fffaf0'; c.strokeStyle = INK; c.lineWidth = 2; c.lineJoin = 'round';
    c.beginPath(); c.moveTo(22, 0); c.lineTo(-18, -12); c.lineTo(-10, 0); c.lineTo(-18, 10); c.closePath(); c.fill(); c.stroke();
    c.fillStyle = '#e4dcc8'; c.beginPath(); c.moveTo(22, 0); c.lineTo(-10, 0); c.lineTo(-14, 6); c.closePath(); c.fill(); c.stroke();
    c.restore();
  },

  // ---------------------------------------------------------------- cutscenes ('cut' in a script)
  async cut_plane() {
    while (this.fadeA > 0.05) await this.wait(0.05);   // (it can start while the screen is still fading in)
    this.cut.plane = this.t;
    sfx('swish');
    await this.wait(1.7);
    sfx('block');
    await this.wait(0.3);
    this.cut.plane = null;
  },
  // a Color Fount starts flowing: color floods out of it across the whole room
  async cut_color_flood() {
    const R = this.room, P = this.p;
    const f = (R.npcs || []).filter(n => n.kind === 'fount').sort((a, b) => Math.abs(a.x - P.x) - Math.abs(b.x - P.x))[0];
    const fx = f ? f.x : P.x, fz = f ? f.z ?? 0 : P.z;
    this.colorFlood = { t0: this.t, x: fx, z: fz };
    this.cut.flash = 0.5;
    sfx('fanfare'); sfx('chime');
    const y = this.surfaceAt(fx, fz) - 90;
    for (let i = 0; i < 60; i++) {
      const a = Math.random() * TAU, sp = 160 + Math.random() * 460;
      this.parts.push({ x: fx, y, z: fz, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 220, life: 1.5, c: CRAYON[i % CRAYON.length], g: 420, star: i % 3 === 0 });
    }
    // a field's scenery colors in too (leafy trees and flowers among the sketches): the theme just switched
    if (this.field) { this.decor = this.fieldDecor(this.roomId); this.buildSolids(); }
    await this.wait(FLOOD + 0.2);
  },
};

// ---------------------------------------------------------------- in battle
const DOODLE_MOVES = MARGIN_PARTNERS.doodle.moves.map(m => m.id);

export const MARGIN_BATTLE = {
  isDoodleMove(v) { return DOODLE_MOVES.includes(v); },

  async doodleAction(v) {
    const P = this.partner, s = this.A.s, H = this.hero;
    const cost = (MARGIN_PARTNERS.doodle.moves.find(m => m.id === v) || {}).fp || 0;
    if (v === 'scribble') {
      const t = await this.pickTarget(() => true, 'Scribble on');
      if (t === undefined) { this.say('Nothing to scribble on right now!'); return false; }
      if (!t) return false;
      await this.partnerHits(P, t);
    } else if (v === 'colorin') {
      s.hero.fp -= cost;
      this.say('Color In! Doodle colors your hearts back in...', 2);
      const impact = this.now() + 0.75;
      this.arm(impact, 'press', 'space', P);
      P.state = 'scribble';
      sfx('unfold');
      await this.anim(0.75, () => {
        for (const a of [H, P]) if (Math.random() < 0.5) this.parts.push({ x: a.x + (Math.random() - 0.5) * 50, y: a.y - 30 - Math.random() * 60, vx: 0, vy: -40, life: 0.5, c: CRAYON[Math.floor(Math.random() * CRAYON.length)], g: 0, star: true });
      });
      const ok = await this.judge(impact);
      if (ok) this.rate(1, P);
      const n = 3 + (ok ? 1 : 0);
      for (const a of [H, P]) {
        if (a !== H && !a.alive) continue;
        a.hp = Math.min(a.maxHp, a.hp + n);
        this.float(`+${n} ♥`, a.x, a.y - 100, '#ff9ab0');
      }
      sfx('chime');
      P.state = 'idle';
      await this.wait(0.5);
    } else if (v === 'outline') {
      s.hero.fp -= cost;
      this.say('Outline! Doodle traces every enemy in bright crayon.', 2);
      const impact = this.now() + 0.65;
      this.arm(impact, 'press', 'space', P);
      P.state = 'scribble';
      sfx('swish');
      await this.anim(0.65, p => { P.y = FLOOR - Math.sin(p * Math.PI) * 30; });
      P.y = FLOOR;
      const ok = await this.judge(impact);
      if (ok) this.rate(1, P);
      for (const e of this.enemies) {
        if (!e.alive) continue;
        e.status.outlined = ok ? 3 : 2;
        this.float('OUTLINED! +1 damage', e.x, e.y - this.eh(e) - 30, '#9fc4ff');
      }
      sfx('unfold');
      P.state = 'idle';
      await this.wait(0.5);
    }
    this.layout();
    return true;
  },

  // Masterpiece: Wick and Doodle paint a giant picture in turns (SPACE, X, SPACE...), faster each stroke. Then it
  // comes to life and hits every enemy: 1 damage, plus 1 for every two strokes. (free: the Blank Page version.)
  async masterpiece(lv, free = false) {
    const H = this.hero, P = this.partner;
    if (!this.enemies.some(e => e.alive)) return false;
    await Promise.all([this.moveTo(H, 380, 0.35), this.moveTo(P, 200, 0.35)]);
    H.flip = -1; P.flip = 1;
    const easel = { x: 290, y: FLOOR, strokes: [], pop: 0, life: 0 };
    this.easel = easel;
    sfx('unfold');
    await this.anim(0.3, p => { easel.pop = p; });
    const maxStrokes = 3 + lv + (free ? 2 : 0);
    let strokes = 0, perfects = 0, dur = 0.58, who = H;
    for (;;) {
      const key = who === H ? 'space' : 'x';
      const ok = await this.beat(who, key, dur, p => { who.sq = 1 - 0.08 * Math.sin(p * Math.PI); easel.brush = p; });
      who.sq = 1;
      if (!ok) break;
      strokes++;
      perfects += this.perfectBonus();
      easel.strokes.push({ c: CRAYON[(strokes - 1) % CRAYON.length], seed: Math.random() * 10 });
      this.rate(strokes, who);
      sfx('swish');
      if (strokes >= maxStrokes) break;
      who = who === H ? P : H;
      dur = Math.max(0.3, dur - 0.045);
    }
    if (!strokes) {
      this.easel = null;
      await this.fizzle('The paint dried!');
    } else {
      this.float(strokes >= maxStrokes ? 'MASTERPIECE!' : `${strokes} strokes!`, 290, 190, '#ffd23f');
      sfx('fanfare');
      this.shake = 6 + strokes;
      await this.anim(0.5, p => { easel.life = p; });
      this.confetti(easel.x, easel.y - 140, 24, 520);
      const dmg = 1 + Math.floor((strokes + perfects) / 2) + (free ? 3 : 0);
      for (const e of [...this.enemies]) if (e.alive) this.hit(e, dmg, { by: 'hero', kind: 'team', ranged: true, reveal: true, pierce: free });
      await this.wait(0.6);
      this.easel = null;
    }
    await Promise.all([this.moveTo(H, H.hx, 0.35), this.moveTo(P, P.hx, 0.35)]);
    return true;
  },

  // PERFECT timing with the Crayon Heart badge on: +1 HP and +1 FP
  crayonHeart() {
    const H = this.hero, sh = this.A.s.hero;
    if (H.hp < H.maxHp) H.hp++;
    if (sh.fp < sh.maxFp) sh.fp++;
    this.float('+1 ♥ +1 FP', H.x - 30, H.y - 150, '#ffb0e0');
  },

  // an Erasebit's Rub Out: 2 FP gone
  rubOut(n) {
    const sh = this.A.s.hero, H = this.hero;
    if (this.badge('steady_hand')) { this.float('Steady Hand! Nothing rubbed out.', H.x, H.y - 130, '#9fe6ff'); return; }
    const lost = Math.min(n, sh.fp);
    if (!lost) { this.float("No FP to rub out! Ha!", H.x, H.y - 130, '#cfc6e6'); return; }
    sh.fp -= lost;
    this.float(`-${lost} FP (rubbed out!)`, H.x, H.y - 130, '#ffb0c8');
    for (let i = 0; i < 12; i++) this.parts.push({ x: H.x + (Math.random() - 0.5) * 40, y: H.y - 60, vx: (Math.random() - 0.5) * 240, vy: -Math.random() * 200, life: 0.7, c: i % 2 ? '#ff9ab0' : '#fff0f4', g: 600 });
  },

  // a Red Pen's (or the Queen's) big red ✗: every hit on Wick does 1 more damage for a while
  markWrong(T) {
    if (this.badge('steady_hand')) { this.float('Steady Hand! Not wrong at all.', T.x, T.y - 130, '#9fe6ff'); return; }
    T.status.marked = 2;
    this.float('MARKED WRONG! (+1 damage taken)', T.x, T.y - 130, '#ff6b6b');
  },

  // throw a red ✗ at Wick: guard it, or he's marked
  async throwMark(e, from, line) {
    const H = this.hero;
    this.say(line, 2.4);
    const impact = this.now() + 0.75;
    this.arm(impact, 'guard');
    const mark = { x: from.x, y: from.y, rot: 0 };
    this.redMark = mark;
    sfx('swish');
    await this.anim(0.75, p => { mark.x = lerp(from.x, H.x, p); mark.y = lerp(from.y, H.y - 60, p) - Math.sin(p * Math.PI) * 70; mark.rot = p * 9; });
    this.redMark = null;
    const r = await this.resolveGuard(e, H, 1, impact, { noContact: true });
    if ((r === 'hit' || r === 'none') && H.hp > 0) this.markWrong(H);
    else this.say('Guarded! Not wrong at all!', 1.6);
    await this.wait(0.5);
  },

  // ---------------------------------------------------------------- the Margin's creatures
  async erasebitTurn(e) {
    if (Math.random() < 0.5) {
      this.say(`${e.name}: RUB OUT! (If it gets you, 2 FP get rubbed out!)`, 2.2);
      const r = await this.attack(e, this.hero, e.atk);
      if ((r === 'hit' || r === 'none') && this.hero.hp > 0) { this.rubOut(2); await this.wait(0.5); }
      return;
    }
    await this.attack(e, this.pickVictim(), e.atk);
  },

  async redpenTurn(e) {
    if (!(this.hero.status.marked > 0) && Math.random() < 0.6) {
      await this.throwMark(e, { x: e.x - 20, y: e.y - this.eh(e) * 0.7 }, `${e.name}: WRONG! (Guard the red ✗, or every hit on Wick does 1 more damage!)`);
      return;
    }
    this.say(`${e.name}: PEN JAB!`);
    await this.attack(e, this.pickVictim(), e.atk);
  },

  // a hurt Crumple smooths itself out and starts over at full HP (once); otherwise it rolls into you, bouncing twice
  async crumpleTurn(e) {
    e.ai = e.ai || {};
    if (e.hp < e.maxHp && !e.ai.redo) {
      e.ai.redo = true;
      this.say(`${e.name}: DO-OVER! (It smooths itself out and starts again at full HP. Finish what you start!)`, 2.8);
      sfx('unfold');
      await this.anim(0.7, p => { e.sq = 1 + 0.2 * Math.sin(p * Math.PI * 3); });
      e.sq = 1; e.hp = e.maxHp; e.smooth = true;
      this.float('FULL HP!', e.x, e.y - this.eh(e) - 20, '#9cff8a');
      await this.wait(0.4);
      return;
    }
    const T = this.pickVictim(), x0 = e.x, y0 = e.y;
    this.say(`${e.name} rolls up into a ball! (Guard both bounces!)`, 1.8);
    sfx('swish');
    let impact = this.now() + 0.6;
    this.arm(impact, 'guard');
    await this.anim(0.6, p => { e.x = lerp(x0, T.x + 34, p * p); e.rot = -p * 9; });
    await this.resolveGuard(e, T, 1, impact);
    if (this.hero.hp > 0 && e.alive) {
      impact = this.now() + 0.5;
      this.arm(impact, 'guard');
      const xb = e.x;
      await this.anim(0.5, p => { e.x = lerp(xb, T.x + 22, p); e.y = y0 - Math.sin(p * Math.PI) * 90; e.rot = -9 - p * 6; });
      e.y = y0;
      await this.resolveGuard(e, T, 1, impact);
    }
    const xs = e.x;
    await this.anim(0.4, p => { e.x = lerp(xs, e.hx, ease(p)); e.rot = -15 * (1 - p); });
    e.x = e.hx; e.y = e.baseY; e.rot = 0;
  },

  async straightedgeTurn(e) {
    this.say(`${e.name}: STRICT SWING! Only a PERFECT guard counts! (SUPERGUARD it)`, 2.2);
    await this.attack(e, this.pickVictim(), e.atk, { strict: true });
  },

  // paper balls falling on someone (guard each)
  async paperRain(e, n) {
    this.paperBalls = [];
    for (let i = 0; i < n; i++) {
      if (this.hero.hp <= 0) break;
      const T = this.pickVictim(), dur = 0.58 - i * 0.05, impact = this.now() + dur;
      this.arm(impact, 'guard');
      const ball = { x: T.x + (Math.random() - 0.5) * 30, y: -30, rot: 0 };
      this.paperBalls.push(ball);
      await this.anim(dur, p => { ball.y = lerp(-30, T.y - 40, p * p); ball.rot = p * 6; });
      this.paperBalls.splice(this.paperBalls.indexOf(ball), 1);
      this.shake = 3;
      await this.resolveGuard(e, T, 1, impact, { noContact: true });
      await this.wait(0.1);
    }
    this.paperBalls = [];
  },

  // ---------------------------------------------------------------- the Wastebasket
  // Throws Crumples back out, Lid Slam on both of you, a Paper Avalanche. At half HP: OVERFLOWING (no more Defense,
  // but it hits harder).
  async wastebasketTurn(e) {
    e.ai = e.ai || { n: 0, full: false };
    const n = ++e.ai.n;
    const minions = this.enemies.filter(x => x.alive && !x.boss).length;
    if (e.hp <= e.maxHp / 2 && !e.ai.full) {
      e.ai.full = true; e.def = 0; e.atk += 1;
      this.say("The Wastebasket: I'M TOO FULL! I'M OVERFLOWING! (Its lid won't shut: no more Defense... but it hits harder!)", 3);
      this.shake = 8;
      sfx('crunch');
      for (let i = 0; i < 26; i++) this.parts.push({ x: e.x, y: e.y - this.eh(e), vx: (Math.random() - 0.5) * 600, vy: -200 - Math.random() * 400, life: 1, c: i % 2 ? '#fffaf0' : '#d9d3c4', g: 700 });
      await this.anim(0.9, p => { e.x = e.hx + Math.sin(p * 40) * 5; });
      e.x = e.hx;
      return;
    }
    if (n % 3 === 1 && minions < 2) { await this.summon(e, 'crumple', 2 - minions, 'The Wastebasket: Not good enough! Not good enough! Back OUT you go, Crumples!'); return; }
    if (n % 3 === 2) {
      this.say('The Wastebasket: LID SLAM!', 1.6);
      for (const T of [this.hero, this.partner]) {
        if (!T || !T.alive || this.hero.hp <= 0 || !e.alive) continue;
        await this.attack(e, T, e.atk);
      }
      return;
    }
    this.say('The Wastebasket: PAPER AVALANCHE! Guard every ball!', 2);
    await this.paperRain(e, e.ai.full ? 4 : 3);
  },

  // ---------------------------------------------------------------- Queen Pristine
  // Eraser Sweep (both of you), Red Ink Rain, Rule of Perfection (Straightedges), Everything Is Wrong (a red ✗).
  // At half HP she calls a DO-OVER (heals, and rubs out your Outlines). At a quarter she erases the whole stage into a
  // perfect blank page... and Doodle knows exactly what to do with a blank page: a free MASTERPIECE.
  async pristineTurn(e) {
    e.ai = e.ai || { n: 0, redo: false, blank: false };
    const n = ++e.ai.n;
    if (e.hp <= e.maxHp * 0.25 && !e.ai.blank) { e.ai.blank = true; await this.blankPage(e); return; }
    if (e.hp <= e.maxHp * 0.5 && !e.ai.redo) { e.ai.redo = true; await this.doOver(e); return; }
    const minions = this.enemies.filter(x => x.alive && !x.boss).length;
    const plan = ['sweep', 'ink', 'rule', 'mark', 'sweep', 'ink'];
    const m = plan[(n - 1) % plan.length];
    if (m === 'rule' && minions < 2) {
      await this.summon(e, 'straightedge', e.ai.redo ? 2 - minions : 1, 'Queen Pristine: RULE OF PERFECTION! Straightedges, measure them up!');
      return;
    }
    if (m === 'ink') {
      this.say('Queen Pristine: RED INK RAIN! Every drop a correction! (Guard each one!)', 2.4);
      this.inkDrops = [];
      for (let i = 0; i < (e.ai.redo ? 4 : 3); i++) {
        if (this.hero.hp <= 0) break;
        const T = this.pickVictim(), dur = 0.56 - i * 0.04, impact = this.now() + dur;
        this.arm(impact, 'guard');
        const drop = { x: T.x + (Math.random() - 0.5) * 30, y: -30 };
        this.inkDrops.push(drop);
        await this.anim(dur, p => { drop.y = lerp(-30, T.y - 40, p * p); });
        this.inkDrops.splice(this.inkDrops.indexOf(drop), 1);
        this.shake = 4;
        await this.resolveGuard(e, T, 1, impact, { noContact: true });
        await this.wait(0.1);
      }
      this.inkDrops = [];
      return;
    }
    if (m === 'mark' && !(this.hero.status.marked > 0)) {
      await this.throwMark(e, { x: e.x - 60, y: e.y - this.eh(e) * 0.75 }, 'Queen Pristine: Everything about you is WRONG! (Guard the ✗!)');
      return;
    }
    this.say('Queen Pristine: ERASER SWEEP!');
    for (const T of [this.hero, this.partner]) {
      if (!T || !T.alive || this.hero.hp <= 0 || !e.alive) continue;
      await this.attack(e, T, e.atk);
    }
  },

  async doOver(e) {
    this.say('Queen Pristine: This battle is NOT going perfectly. I call a DO-OVER!', 2.8);
    sfx('unfold');
    this.shake = 6;
    await this.anim(0.9, p => { this.blank = Math.sin(p * Math.PI) * 0.85; });
    this.blank = 0;
    const heal = 10;
    e.hp = Math.min(e.maxHp, e.hp + heal);
    this.float(`+${heal}`, e.x, e.y - this.eh(e) - 20, '#9cff8a');
    for (const x of this.enemies) if (x.alive) x.status.outlined = 0;
    sfx('chime');
    await this.wait(1.2);
    const P = this.partner;
    if (P && P.kind === 'doodle' && P.alive) this.say("Doodle: A do-over can't erase what we've LEARNED! Keep going, Wick!", 2.6);
    else this.say("She rubbed out the last few minutes... but Wick still remembers everything he learned.", 2.6);
    await this.wait(1.2);
  },

  async blankPage(e) {
    this.say('Queen Pristine: ENOUGH! I shall erase EVERYTHING. A perfect, BLANK page. Nothing on it can ever be wrong!', 3.2);
    sfx('crunch');
    this.shake = 10;
    await this.anim(1.4, p => { this.blank = p; });
    await this.wait(0.7);
    const P = this.partner, doodle = P && P.kind === 'doodle' && P.alive;
    this.say(doodle ? 'Doodle: ...A blank page? Wick, I know EXACTLY what to do with a blank page!'
      : "...But a blank page is a fresh start, too. Wick's flame flickers... and burns brighter than ever!", 3.2);
    await this.wait(1.8);
    if (doodle) {
      this.say('MASTERPIECE! (This one is free!) SPACE = Wick · X = Doodle', 2.6);
      await this.wait(0.7);
      await this.masterpiece(P.bond, true);
      for (const a of [this.hero, P]) { a.x = a.hx; a.y = FLOOR; a.state = 'idle'; a.flip = 1; a.sq = 1; }
    } else {
      sfx('fanfare');
      this.shake = 10;
      this.hit(e, 8, { by: 'hero', pierce: true, reveal: true });
      await this.wait(0.6);
    }
    await this.anim(0.9, p => { this.blank = 1 - p; });
    this.blank = 0;
    if (e.alive) this.say('Color everywhere! Finish it!', 2.2);
  },

  // ---------------------------------------------------------------- extra drawing on the battle stage
  drawMarginExtras(c, t) {
    // the Blank Page: the whole stage erased to white, except Wick, his partner and the Queen herself
    if (this.blank > 0) {
      c.fillStyle = `rgba(252,250,244,${Math.min(1, this.blank)})`; c.fillRect(-300, -300, W + 600, H + 600);
      if (this.blank > 0.5) {
        c.strokeStyle = `rgba(150,160,190,${0.25 * this.blank})`; c.lineWidth = 1;
        for (let y = 40; y < H; y += 34) { c.beginPath(); c.moveTo(-300, y); c.lineTo(W + 300, y); c.stroke(); }
        for (const a of [this.partner, this.hero, ...this.enemies.filter(x => x.kind === 'pristine' && x.alive)]) if (a) this.drawActor(c, a, t);
      }
    }
    // Doodle's Outline on enemies: a dashed crayon ring that wiggles
    for (const e of this.enemies) {
      if (!e.alive || !(e.status.outlined > 0)) continue;
      const h = this.eh(e);
      c.save(); c.setLineDash([10, 6]); c.lineDashOffset = -t * 30; c.strokeStyle = 'rgba(91,141,239,0.9)'; c.lineWidth = 3.5;
      c.beginPath(); c.ellipse(e.x, e.y - h * 0.5, h * 0.55 + 14, h * 0.62 + 10, Math.sin(t * 3) * 0.05, 0, TAU); c.stroke(); c.restore();
    }
    // a red ✗ over Wick while he's marked WRONG
    const hero = this.hero;
    if (hero && hero.status.marked > 0) this.drawRedX(c, hero.x + 28, hero.y - 118 + Math.sin(t * 5) * 3, 0.55, 0);
    // a Red Pen's ✗ on its way
    if (this.redMark) this.drawRedX(c, this.redMark.x, this.redMark.y, 0.9, this.redMark.rot);
    // crumpled paper balls (the Wastebasket's avalanche) and red ink drops (the Queen's)
    for (const b of this.paperBalls || []) {
      c.save(); c.translate(b.x, b.y); c.rotate(b.rot);
      c.fillStyle = '#fbf8f0'; c.strokeStyle = INK; c.lineWidth = 2;
      c.beginPath(); for (let i = 0; i < 9; i++) { const a = (i / 9) * TAU, r = 15 + ((i * 7) % 5); i ? c.lineTo(Math.cos(a) * r, Math.sin(a) * r) : c.moveTo(Math.cos(a) * r, Math.sin(a) * r); } c.closePath(); c.fill(); c.stroke();
      c.strokeStyle = 'rgba(43,34,53,0.35)'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(-8, -6); c.lineTo(4, 2); c.lineTo(-2, 9); c.moveTo(6, -9); c.lineTo(2, 1); c.stroke();
      c.restore();
    }
    for (const d of this.inkDrops || []) { c.fillStyle = '#d8323a'; c.strokeStyle = INK; c.lineWidth = 2; c.beginPath(); c.moveTo(d.x, d.y - 16); c.quadraticCurveTo(d.x + 11, d.y + 2, d.x, d.y + 8); c.quadraticCurveTo(d.x - 11, d.y + 2, d.x, d.y - 16); c.fill(); c.stroke(); }
    // Masterpiece: a big canvas on an easel, filling up with strokes, then glowing to life
    const E = this.easel;
    if (E) {
      const s = 0.4 + 0.6 * Math.min(1, E.pop);
      c.save(); c.translate(E.x, E.y); c.scale(s, s);
      if (E.life > 0) glowDot(c, 0, -150, 150 + 60 * E.life, '255,236,170', 0.5 * E.life);
      c.strokeStyle = '#7a4f24'; c.lineWidth = 7; c.lineCap = 'round';
      c.beginPath(); c.moveTo(-60, 0); c.lineTo(-30, -250); c.moveTo(60, 0); c.lineTo(30, -250); c.moveTo(0, -40); c.lineTo(0, -255); c.stroke();
      c.fillStyle = '#fffaf0'; c.strokeStyle = INK; c.lineWidth = 4;
      c.fillRect(-85, -240, 170, 140); c.strokeRect(-85, -240, 170, 140);
      c.save(); c.beginPath(); c.rect(-82, -237, 164, 134); c.clip();
      E.strokes.forEach((st, i) => {
        c.strokeStyle = st.c; c.lineWidth = 16; c.lineCap = 'round';
        c.beginPath();
        const y0 = -220 + (i % 5) * 26 + Math.sin(st.seed) * 6;
        c.moveTo(-80, y0); c.bezierCurveTo(-30, y0 - 30 + Math.sin(st.seed * 2) * 20, 20, y0 + 30, 82, y0 - 10 + Math.cos(st.seed) * 10);
        c.stroke();
      });
      if (E.life > 0) { c.fillStyle = `rgba(255,255,240,${0.6 * Math.sin(E.life * Math.PI)})`; c.fillRect(-85, -240, 170, 140); }
      c.restore();
      c.font = 'bold 26px Fredoka, sans-serif'; c.textAlign = 'center'; c.lineWidth = 5; c.strokeStyle = INK; c.fillStyle = '#ffd23f';
      if (E.strokes.length) { c.strokeText(`×${E.strokes.length}`, 0, -260); c.fillText(`×${E.strokes.length}`, 0, -260); }
      c.restore();
    }
  },

  drawRedX(c, x, y, s, rot) {
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(s, s);
    c.lineCap = 'round';
    c.strokeStyle = INK; c.lineWidth = 16; c.beginPath(); c.moveTo(-20, -20); c.lineTo(20, 20); c.moveTo(20, -20); c.lineTo(-20, 20); c.stroke();
    c.strokeStyle = '#e5333b'; c.lineWidth = 10; c.stroke();
    c.restore();
  },
};
