// Things to play with out in the world, Paper Mario style: stickers you peel off the world and stick on outlines,
// crates you push, pressure plates, bombs you pick and throw, fog and boards in the way, updrafts, tears in the
// paper floor that you patch with confetti, and folks folded up and hidden all over Lumenfold.
// adventure.js installs these as methods of the Adventure.
import { sfx } from '../audio.js';
import { api } from '../api.js';
import { drawPot, drawFolk, PAPER, INK, rrect } from '../art.js';
import { atDepth, GZ0, drawPlat3d } from '../art2.js';
import {
  drawCrate3d, drawPlate3d, drawBomb, drawBombPlant, drawBoom, drawSticker, drawSlot, drawFan, drawSunSticker, drawBridge3d,
  drawFlower3d, drawPopStairs, drawFog3d, drawBoards, drawRockWall3d, drawUpdraft, drawTear3d, drawPatch3d, drawFoldedFolk,
  drawConfettiPile, drawTent, drawCampfire, drawStall, drawResetTotem, drawBars, CONF,
} from '../art3.js';
import { STICKERS, SHOP_STICKERS, FOLKS, TEARS } from './wilds.js';

const CRATE = 56;        // crates are cubes this wide
const PUSH = 110;        // how fast you can shove one
const GRAV = 2300, FUSE = 4, REGROW = 4;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const overlap = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y
  && (a.z0 ?? -1e9) < (b.z1 ?? 1e9) && (a.z1 ?? 1e9) > (b.z0 ?? -1e9);
// camp things you walk around: [half width, half depth, height]
const CAMP_FOOT = { tent: [66, 30, 96], stall: [70, 24, 150], campfire: [24, 16, 22] };

export const MECH = {
  // ---------------------------------------------------------------- a new room
  initMechanics() {
    const R = this.room, s = this.s;
    this.live = {};          // flags that only last while something holds them (blue pressure plates)
    this.carry = null;       // the bomb or pot over Wick's head
    this.thrown = [];
    this.booms = [];
    this.pops = [];          // folks popping back into shape
    this.plantT = {};        // when each bomb plant was last picked
    this.fadeOut = {};       // barriers that just went away, fading out
    this.fadeIn = {};        // sticker things that just appeared
    this.fallT = null;       // falling into a tear
    this.crates = (R.crates || []).map(cr => {
      const sv = s.crates[cr.id];
      const o = { id: cr.id, home: cr, x: sv ? sv.x : cr.x, z: sv ? sv.z : cr.z ?? 0, y: sv ? sv.y : this.surfaceAt(cr.x, cr.z ?? 0), vy: 0 };
      o.solid = { type: 'crate', ref: o, x: 0, y: 0, w: CRATE, h: CRATE, z0: 0, z1: 0 };
      this.syncCrate(o);
      return o;
    });
    for (const pl of R.plates || []) if (pl.mode !== 'latch') this.live[pl.flag] = this.plateDown(pl);
    this.wasUp = {};
    for (const b of R.barriers || []) this.wasUp[b.id] = this.barrierUp(b);
    this.clearOfTears();
  },

  // When a barrier comes down (a fan, a plate, a sticker, a bomb...), it fades away instead of vanishing.
  checkBarriers() {
    for (const b of this.room.barriers || []) {
      const up = this.barrierUp(b);
      if (this.wasUp[b.id] && !up) {
        this.fadeOut[b.id] = this.fadeOut[b.id] ?? this.t;
        if (b.look === 'bars') { sfx('door'); sfx('chime'); this.cut.shake = 0.3; this.tip('🔓 With a grinding rumble, the vault bars slide open!', 5); }
      }
      this.wasUp[b.id] = up;
    }
  },

  syncCrate(o) {
    const S = o.solid;
    S.x = o.x - CRATE / 2; S.y = o.y - CRATE; S.z0 = o.z - CRATE / 2; S.z1 = o.z + CRATE / 2;
  },

  // Solids for buildSolids: barriers, pop-up stairs, camp things and crates.
  mechSolids(out) {
    const R = this.room;
    for (const b of R.barriers || []) {
      if (b.solid === false || !this.barrierUp(b)) continue;
      const h = b.h || 400, y = this.surfaceAt(b.x + b.w / 2, b.z0 != null ? (b.z0 + b.z1) / 2 : 0);
      // (one that runs into the distance gets a hill's care for its side walls, so you're drawn right beside it)
      out.push({ x: b.x, y: y - h, w: b.w, h, ...(b.z0 != null ? { z0: b.z0, z1: b.z1, big: true } : {}), type: 'barrier', ref: b });
    }
    for (const rs of R.resets || []) {
      const z = rs.z ?? 0;
      out.push({ x: rs.x - 14, y: this.surfaceAt(rs.x, z) - 104, w: 28, h: 104, z0: z - 12, z1: z + 12, type: 'wall' });
    }
    for (const x of R.xplats || []) {
      if (x.look !== 'stairs' || !this.xOn(x)) continue;
      for (const st of this.stairSteps(x)) {
        const x0 = x.dir === -1 ? x.x : st.x, x1 = x.dir === -1 ? st.x + st.w : x.x1;
        out.push({ x: x0, y: st.top, w: x1 - x0, h: st.base - st.top, z0: x.z0, z1: x.z1, type: 'ground' });
      }
    }
    for (const cp of R.camp || []) {
      const f = CAMP_FOOT[cp.kind];
      if (f) out.push({ x: cp.x - f[0], y: this.surfaceAt(cp.x, cp.z) - f[2], w: f[0] * 2, h: f[2], z0: cp.z - f[1], z1: cp.z + f[1], type: 'wall' });
    }
    for (const o of this.crates || []) out.push(o.solid);
  },

  // A barrier stays up until it's blown apart, or until its flag is set (with a list of flags: all of them).
  barrierUp(b) {
    if (this.broken(b.id)) return false;
    if (!b.unless) return true;
    return Array.isArray(b.unless) ? !b.unless.every(f => this.flag(f)) : !this.flag(b.unless);
  },
  xOn(x) { return !x.when || this.flag(x.when); },
  // Pop-up stairs: steps of 24 or less, so you walk right up them.
  stairSteps(x) {
    const base = x.y0 ?? 450, n = Math.max(2, Math.ceil((base - x.y1) / 24)), rise = (base - x.y1) / n, sw = (x.x1 - x.x) / n;
    const out = [];
    for (let i = 0; i < n; i++) out.push({ x: x.dir === -1 ? x.x1 - (i + 1) * sw : x.x + i * sw, w: sw, top: base - (i + 1) * rise, base, z0: x.z0, z1: x.z1 });
    return out;
  },
  // Platforms from stickers (bridges, giant flowers) for plats().
  xplatList() {
    const out = [];
    for (const x of this.room.xplats || []) if (x.look !== 'stairs' && this.xOn(x)) out.push({ x: x.x, y: x.y, w: x.w, z0: x.z0 ?? GZ0 + 10, z1: x.z1 ?? this.zb - 10, xplat: x });
    return out;
  },

  // ---------------------------------------------------------------- every frame while exploring
  updateMechanics(dt) {
    this.dtNow = dt;
    if (this.crates.length) this.updateCrates(dt);
    this.updatePlates();
    if (this.carry && this.carry.kind === 'bomb') {
      this.carry.fuse -= dt;
      if (this.carry.fuse <= 0) { const P = this.p; this.carry = null; this.explode(P.x, P.y - 74, P.z); }
    }
    if (this.thrown.length) this.updateThrown(dt);
    this.checkBarriers();
    this.booms = this.booms.filter(b => this.t - b.t0 < 0.6);
    this.pops = this.pops.filter(p => this.t - p.t0 < 2.6);
    const P = this.p;
    for (const pl of this.room.piles || []) {
      if (this.s.collected[pl.id] || Math.abs(P.x - pl.x) > 34 || Math.abs(P.z - (pl.z ?? 0)) > 34 || P.y < this.surfaceAt(pl.x, pl.z ?? 0) - 60) continue;
      this.s.collected[pl.id] = true;
      this.addConfetti(15);
      sfx('coin'); sfx('chime');
      for (let i = 0; i < 22; i++) this.parts.push({ x: pl.x, y: P.y - 20, z: pl.z ?? 0, vx: (Math.random() - 0.5) * 320, vy: -120 - Math.random() * 300, life: 1, c: CONF[i % 6], g: 500 });
      this.float('+15 🎉 Confetti!', pl.x, P.y - 90, '#ffe066', pl.z ?? 0);
      if (!this.s.flags.confetti_tip) {
        this.s.flags.confetti_tip = true;
        this.tip('🎉 Confetti! Use it to patch tears in the paper floor (walk up to one and press E). Bushes, pots and battles give confetti too.', 8);
      }
      this.saveSoon();
    }
  },

  // ---------------------------------------------------------------- crates
  // Walk into a crate to shove it (sideways or into the distance). Shove it off a ledge and it drops.
  pushCrate(o, dx, dz) {
    if (o.vy) return false;
    const step = PUSH * (this.dtNow || 1 / 60);
    const mx = dx ? Math.sign(dx) * Math.min(Math.abs(dx), step) : 0, mz = dz ? Math.sign(dz) * Math.min(Math.abs(dz), step) : 0;
    const nx = clamp(o.x + mx, CRATE / 2 + 2, this.room.w - CRATE / 2 - 2), nz = clamp(o.z + mz, GZ0 + CRATE / 2, this.zb - CRATE / 2);
    if (Math.abs(nx - o.x) < 0.01 && Math.abs(nz - o.z) < 0.01) return false;
    const nb = { x: nx - CRATE / 2, y: o.y - CRATE + 1, w: CRATE, h: CRATE - 2, z0: nz - CRATE / 2, z1: nz + CRATE / 2 };
    if (this.solids.some(s => s !== o.solid && overlap(nb, s))) return false;
    if (this.enemies.some(e => !e.dead && Math.abs(e.x - nx) < 46 && Math.abs(e.z - nz) < 44)) return false;
    o.x = nx; o.z = nz; o.moved = true;
    this.syncCrate(o);
    this.pushT = this.t;
    if (this.t - (this.pushSfxT ?? -9) > 0.3) { this.pushSfxT = this.t; sfx('push'); this.dust(o.x - Math.sign(mx) * 26, o.y, 1, Math.sign(mx)); }
    return true;
  },

  updateCrates(dt) {
    for (const o of this.crates) {
      const fy = this.crateFloor(o);
      if (fy != null && o.y >= fy - 0.5 && !o.vy) { if (o.y !== fy) { o.y = fy; this.syncCrate(o); } continue; }
      o.vy = Math.min(1100, o.vy + GRAV * dt);
      o.y += o.vy * dt;
      if (fy != null && o.y >= fy) {
        o.y = fy; o.vy = 0; o.moved = true;
        sfx('thud'); this.dust(o.x, o.y, 6);
        this.cut.shake = Math.max(this.cut.shake || 0, 0.15);
      }
      if (o.y > 640) this.resetCrate(o, true);
      this.syncCrate(o);
    }
    // remember where crates were left
    for (const o of this.crates) {
      if (!o.moved || o.vy) continue;
      o.moved = false;
      this.s.crates[o.id] = { x: Math.round(o.x), z: Math.round(o.z), y: o.y };
      this.saveSoon();
    }
  },

  // The top of whatever is right under a crate's middle.
  crateFloor(o) {
    let best = null;
    for (const s of this.solids) {
      if (s === o.solid || o.x < s.x || o.x > s.x + s.w || s.y < o.y - 4) continue;
      if (s.z0 != null && (o.z < s.z0 || o.z > s.z1)) continue;
      if (best == null || s.y < best) best = s.y;
    }
    return best;
  },

  resetCrate(o, fell) {
    o.x = o.home.x; o.z = o.home.z ?? 0; o.y = this.surfaceAt(o.x, o.z); o.vy = 0; o.moved = false;
    delete this.s.crates[o.id];
    this.syncCrate(o);
    for (let i = 0; i < 12; i++) this.parts.push({ x: o.x, y: o.y - 28, z: o.z, vx: (Math.random() - 0.5) * 240, vy: (Math.random() - 0.5) * 240, life: 0.6, dust: true, r: 6, g: 0 });
    sfx('poof');
    // never drop it on top of Wick: he steps out in front
    const P = this.p;
    if (P && overlap(this.pbox(), o.solid)) P.z = o.solid.z0 - 12 >= this.zmin ? o.solid.z0 - 12 : o.solid.z1 + 12;
    if (fell) this.float('The crate popped back!', o.x, o.y - 80, '#fffaf0', o.z);
  },

  resetCrates() {
    for (const o of this.crates) this.resetCrate(o, false);
    sfx('chime');
    this.updatePlates();
    this.saveSoon();
  },

  // ---------------------------------------------------------------- pressure plates
  // Gold plates stay down once pressed (a saved flag). Blue ones only while something sits on them.
  updatePlates() {
    const R = this.room;
    if (!R.plates) return;
    let changed = false;
    for (const pl of R.plates) {
      const down = this.plateDown(pl), y = this.surfaceAt(pl.x, pl.z);
      if (pl.mode === 'latch') {
        if (!down || this.s.flags[pl.flag]) continue;
        this.s.flags[pl.flag] = true; changed = true;
        sfx('chime'); this.cut.shake = 0.3;
        this.float('Ka-chunk!', pl.x, y - 60, '#ffe066', pl.z);
        if (pl.script) this.runScript(pl.script);
        this.saveSoon();
      } else if (!!this.live[pl.flag] !== down) {
        this.live[pl.flag] = down; changed = true;
        sfx(down ? 'chime' : 'select');
        if (down) this.float('Click!', pl.x, y - 60, '#bfe6ff', pl.z);
      }
    }
    if (changed) this.buildSolids();
  },

  plateDown(pl) {
    const w = (pl.w || 60) / 2 + 6, d = (pl.d || 50) / 2 + 6, y = this.surfaceAt(pl.x, pl.z), P = this.p;
    if (P && P.onGround && Math.abs(P.x - pl.x) < w && Math.abs(P.z - pl.z) < d && Math.abs(P.y - y) < 3) return true;
    return (this.crates || []).some(o => !o.vy && Math.abs(o.x - pl.x) < w + 8 && Math.abs(o.z - pl.z) < d + 8 && Math.abs(o.y - y) < 3);
  },

  // ---------------------------------------------------------------- bombs and pots
  plantRipe(bp) { const t0 = this.plantT[bp.id]; return t0 == null ? 1 : Math.min(1, (this.t - t0) / REGROW); },

  pickBomb(bp) {
    this.plantT[bp.id] = this.t;
    this.carry = { kind: 'bomb', fuse: FUSE };
    sfx('select');
    if (!this.s.flags.bomb_tip) {
      this.s.flags.bomb_tip = true;
      this.tip('💣 A bomb! Throw it with E or X (hold ↑ or ↓ to throw it into the distance). It goes off in 4 seconds, so be quick!', 8);
    }
  },

  liftPot(pt) {
    this.cleared.add(pt.id);
    this.carry = { kind: 'pot' };
    sfx('select');
  },

  throwCarry() {
    const P = this.p, c = this.carry, k = this.keys;
    this.carry = null;
    const az = (k.has('up') ? 1 : 0) - (k.has('down') ? 1 : 0);
    // holding ↑ or ↓ throws it (nearly) straight into or out of the distance
    this.thrown.push({ kind: c.kind, fuse: c.fuse ?? 99, x: P.x + P.facing * (az ? 4 : 14), y: P.y - P.h - 4, z: P.z,
      vx: P.facing * (az ? 40 : 420) + P.vx * (az ? 0.15 : 0.4), vy: az ? -400 : -330, vz: az * 320 + P.vz * 0.3 });
    sfx('jump');
    P.sq = 0.9;
  },

  updateThrown(dt) {
    const bx = (x, y, z) => ({ x: x - 9, y: y - 18, w: 18, h: 17, z0: z - 9, z1: z + 9 });
    for (const b of [...this.thrown]) {
      b.vy = Math.min(1100, b.vy + 1700 * dt);
      const nx = b.x + b.vx * dt, nz = clamp(b.z + b.vz * dt, GZ0 + 8, this.zb - 8);
      const wall = this.solids.find(s => overlap(bx(nx, b.y, b.z), s));
      if (wall) {
        if (b.kind === 'pot') { this.smashPot(b); continue; }
        // a bomb thrown at something bombable stops right there; anything else, it bounces off
        if (wall.type === 'barrier' && wall.ref.bomb) { b.vx = 0; b.vz = 0; } else b.vx *= -0.3;
        sfx('tock');
      } else b.x = nx;
      if (this.solids.some(s => s.z0 != null && overlap(bx(b.x, b.y, nz), s))) b.vz *= -0.4; else b.z = nz;
      const ny = b.y + b.vy * dt, fy = b.vy >= 0 ? this.floorBelow(b.x, b.y, b.z) : null;
      if (fy != null && ny >= fy) {
        b.y = fy;
        if (b.kind === 'pot') { this.smashPot(b); continue; }
        if (b.vy > 160) { sfx('tock'); b.vy = -b.vy * 0.35; b.vx *= 0.62; b.vz *= 0.62; }
        else { b.vy = 0; const f = Math.max(0, 1 - 5 * dt); b.vx *= f; b.vz *= f; }
      } else b.y = ny;
      for (const e of this.enemies) {
        // generous: anything that sails just over someone's head still bonks them
        if (e.dead || Math.abs(e.x - b.x) > 28 || Math.abs(e.z - b.z) > 30 || b.y < e.y - e.h - 60 || b.y > e.y + 8) continue;
        if (b.kind === 'pot') { e.stun = 3; e.ai = 'return'; this.float('Bonk!', e.x, e.y - e.h - 20, '#ffe066', e.z); this.smashPot(b); break; }
        if (b.fuse > 0.05) b.fuse = 0.05;   // a bomb that hits someone goes off right away
      }
      if (!this.thrown.includes(b)) continue;
      if (b.kind === 'bomb') {
        b.fuse -= dt;
        if (b.fuse <= 0) { this.thrown.splice(this.thrown.indexOf(b), 1); this.explode(b.x, b.y - 16, b.z); continue; }
      }
      if (b.y > 700) this.thrown.splice(this.thrown.indexOf(b), 1);
    }
  },

  smashPot(b) {
    const i = this.thrown.indexOf(b);
    if (i >= 0) this.thrown.splice(i, 1);
    sfx('crunch');
    for (let k = 0; k < 12; k++) this.parts.push({ x: b.x, y: b.y - 14, z: b.z, vx: (Math.random() - 0.5) * 300, vy: -100 - Math.random() * 250, life: 0.7, c: '#c0744a', g: 900 });
    this.loot(b.x, b.y, b.z);
  },

  // What a bush or a pot leaves behind: maybe coins or a heart, and always a little confetti.
  loot(x, y, z) {
    const r = Math.random(), lucky = this.s.badges.equipped.includes('lucky_patch');
    if (r < 0.55) { const n = (1 + Math.floor(Math.random() * 3)) * (lucky ? 2 : 1); this.addCoins(n); this.float(`+${n} 🪙`, x, y - 60, undefined, z); sfx('coin'); }
    else if (r < 0.72) { const h = this.s.hero; h.hp = Math.min(h.maxHp, h.hp + 2); this.float('+2 ♥', x, y - 60, '#ff9ab0', z); }
    this.addConfetti(2);
    this.float('+2 🎉', x + 30, y - 34, '#ffd23f', z);
  },

  explode(x, y, z) {
    const R = this.room, P = this.p;
    sfx('boom');
    this.cut.shake = Math.max(this.cut.shake || 0, 0.6);
    this.booms.push({ x, y, z, t0: this.t });
    for (let i = 0; i < 26; i++) this.parts.push({ x, y, z, vx: (Math.random() - 0.5) * 640, vy: -Math.random() * 520, life: 0.8, c: ['#ff8a3d', '#ffe066', '#5a5470'][i % 3], g: 900 });
    const reach = (bx, bw) => Math.abs(clamp(x, bx, bx + bw) - x);
    let rebuild = false;
    for (const b of R.barriers || []) {
      if (!b.bomb || !this.barrierUp(b) || reach(b.x, b.w) > 130) continue;
      if (b.z0 != null && Math.abs(clamp(z, b.z0, b.z1) - z) > 110) continue;
      this.s.broken[b.id] = true; this.fadeOut[b.id] = this.t; rebuild = true;
      const bz = b.z0 != null ? (b.z0 + b.z1) / 2 : z, by = this.surfaceAt(b.x + b.w / 2, bz);
      for (let i = 0; i < 20; i++) this.parts.push({ x: b.x + Math.random() * b.w, y: by - Math.random() * (b.vh || 130), z: bz, vx: (Math.random() - 0.5) * 500, vy: -Math.random() * 450, life: 0.9, c: b.look === 'boards' ? '#b07a45' : '#a08a70', g: 1200 });
      this.float('KABOOM!', b.x + b.w / 2, by - (b.vh || 130) - 20, '#ffe066', bz);
      if (b.script) this.runScript(b.script);
    }
    for (const ck of R.cracks || []) if (!this.broken(ck.id) && reach(ck.x, ck.w) < 100) { this.s.broken[ck.id] = true; rebuild = true; }
    for (const e of this.enemies) {
      if (e.dead || Math.hypot(e.x - x, (e.z - z) * 1.2) > 130) continue;
      e.stun = 4; e.ai = 'return';
      this.float('Dazed!', e.x, e.y - e.h - 20, '#ffe066', e.z);
    }
    for (const [list, kind] of [[R.bushes, 'bush'], [R.pots, 'pot']]) {
      for (const b of list || []) {
        const bz = this.thingZ(b, kind), by = this.surfaceAt(b.x, bz);
        if (this.cleared.has(b.id) || Math.hypot(b.x - x, (bz - z) * 1.2) > 100) continue;
        this.cleared.add(b.id);
        this.loot(b.x, by, bz);
      }
    }
    if (P.invuln <= 0 && Math.hypot(P.x - x, (P.z - z) * 1.2) < 80 && Math.abs(P.y - 30 - y) < 90) this.hurtPlayer(1, Math.sign(P.x - x) || 1);
    if (rebuild) { this.buildSolids(); this.saveSoon(); }
  },

  // A bump in the field (never a knockout: Wick keeps at least 1 HP out here).
  hurtPlayer(n, dir) {
    const P = this.p, h = this.s.hero;
    const hurt = this.flag('prologue_done') && h.hp > 1;
    if (hurt) h.hp = Math.max(1, h.hp - n);
    P.vx = dir * 340; P.vy = -420; P.onGround = false; P.invuln = 1.4;
    sfx('hurt');
    this.float(hurt ? `-${n} ♥` : 'Ouch!', P.x, P.y - 90, '#ff9ab0');
  },

  // ---------------------------------------------------------------- stickers
  peelVisible(k) {
    if (!k.behind) return true;
    const b = (this.room.barriers || []).find(bb => bb.id === k.behind);
    return !b || !this.barrierUp(b);
  },

  peelSticker(k) {
    const S = STICKERS[k.kind];
    this.s.peeled[k.id] = true;
    this.s.stickers[k.kind] = (this.s.stickers[k.kind] || 0) + 1;
    sfx('peel');
    const z = k.z ?? 0, y = (k.y ?? this.surfaceAt(k.x, z)) - 40;
    for (let i = 0; i < 12; i++) this.parts.push({ x: k.x, y, z, vx: (Math.random() - 0.5) * 260, vy: -60 - Math.random() * 220, life: 0.8, c: '#fff6c8', g: 300, star: true });
    this.float(`🗒️ ${S.name}!`, k.x, y - 50, '#ffe066', z);
    if (!this.s.flags.peel_tip) {
      this.s.flags.peel_tip = true;
      this.tip('🗒️ Peeled! Stickers go in your Sticker Album (ESC → Sticker Album). Find an outline of the same shape and press E to stick it there.', 9);
    }
    this.saveSoon();
  },

  async stickSlot(sl) {
    const S = STICKERS[sl.kind];
    if (!((this.s.stickers[sl.kind] || 0) > 0)) {
      await this.runScript([['narrate', `A sticker-shaped outline of ${S.outline} You need ${S.a}. ${S.where}`]]);
      return;
    }
    this.s.stickers[sl.kind]--;
    this.s.stuck[sl.id] = sl.kind;
    const flag = sl.flag || `slot_${sl.id}`;
    this.s.flags[flag] = true;
    this.fadeIn[flag] = this.t;
    for (const b of this.room.barriers || []) if (b.unless === flag) this.fadeOut[b.id] = this.t;
    sfx('peel'); sfx('chime');
    this.cut.flash = 0.45;
    const z = sl.z ?? 0, y = (sl.y ?? this.surfaceAt(sl.x, z)) - 50;
    for (let i = 0; i < 24; i++) this.parts.push({ x: sl.x, y, z, vx: (Math.random() - 0.5) * 380, vy: -100 - Math.random() * 300, life: 1, c: CONF[i % 6], g: 500 });
    this.float(`${S.name} stuck!`, sl.x, y - 50, '#ffe066', z);
    this.buildSolids();
    this.saveNow();
    if (sl.script) await this.runScript(sl.script);
    else this.tip(S.done, 6);
  },

  // ---------------------------------------------------------------- folded folks
  // hidden in a bush until it's smashed, or lost behind fog (or some other barrier) until it's cleared
  folkVisible(f) {
    if (f.bush && !this.cleared.has(f.bush)) return false;
    const b = f.behind && (this.room.barriers || []).find(bb => bb.id === f.behind);
    return !(b && this.barrierUp(b));
  },
  rescuedCount() { return Object.keys(this.s.rescued || {}).length; },

  unfold(f) {
    this.s.rescued[f.id] = true;
    sfx('unfold'); sfx('chime');
    const z = f.z ?? 0, y = f.y ?? this.surfaceAt(f.x, z);
    for (let i = 0; i < 28; i++) this.parts.push({ x: f.x, y: y - 30, z, vx: (Math.random() - 0.5) * 420, vy: -150 - Math.random() * 320, life: 1.1, c: CONF[i % 6], g: 500 });
    this.pops.push({ x: f.x, y, z, t0: this.t, opts: f.opts || {}, line: f.line || 'Thank you!!' });
    this.addConfetti(3);
    const n = this.rescuedCount();
    this.float(`${f.name} is free! (${n}/${FOLKS.length})`, f.x, y - 140, '#ffe066', z);
    if (!this.questKnown('rescue')) this.tip('A folded-up folk! Mayor Pennywick at the Paper Plains camp is looking for everyone the Gloom Gale blew away.', 8);
    else this.tip(`🧍 Folks rescued: ${n} of ${FOLKS.length}. They'll be waiting for you in Lumen Town!`, 5);
    this.saveSoon();
  },

  // ---------------------------------------------------------------- tears in the paper
  onTear() {
    const P = this.p;
    if (!P.onGround) return null;
    for (const tr of this.room.tears || []) {
      if (this.s.patched[tr.id]) continue;
      const dx = (P.x - tr.x) / ((tr.w || 70) * 0.38), dz = (P.z - (tr.z ?? 0)) / ((tr.d || 54) * 0.38);
      if (dx * dx + dz * dz < 1 && Math.abs(P.y - this.surfaceAt(tr.x, tr.z ?? 0)) < 4) return tr;
    }
    return null;
  },

  // Never start (or respawn) standing on a tear: step out in front of it.
  clearOfTears() {
    const P = this.p;
    for (let i = 0; i < 3; i++) {
      const tr = this.onTear();
      if (!tr) return;
      P.z = (tr.z ?? 0) - (tr.d || 54) * 0.5 - 12;
      if (P.z < ZMIN) P.z = (tr.z ?? 0) + (tr.d || 54) * 0.5 + 12;
      P.safe = { x: P.x, y: P.y, z: P.z };
    }
  },

  startFall(tr) {
    const P = this.p;
    this.fallT = this.t;
    P.vx = 0; P.vz = 0;
    P.x = tr.x + (P.x - tr.x) * 0.4; P.z = (tr.z ?? 0) + (P.z - (tr.z ?? 0)) * 0.4;
    sfx('fall');
  },

  updateFall() {
    if (this.t - this.fallT < 0.7) return;
    const P = this.p;
    this.fallT = null;
    Object.assign(P, { x: P.safe.x, y: P.safe.y, z: P.safe.z ?? P.z, vx: 0, vy: 0, vz: 0, invuln: 1, onGround: true });
    this.clearOfTears();
    sfx('hurt');
    this.float('Whoa! A tear in the paper!', P.x, P.y - 90, '#ff9ab0');
    if (!this.s.flags.tear_tip) {
      this.s.flags.tear_tip = true;
      this.tip('🕳️ Careful: tears in the paper! Walk up to one and press E to patch it with 🎉 confetti. (Stitch at the Paper Plains camp knows all about it.)', 9);
    }
  },

  async patchTear(tr) {
    const cost = tr.cost || 10, have = this.s.confetti || 0;
    if (have < cost) {
      await this.runScript([['narrate', `A tear in the paper! Patching it takes ${cost} 🎉 confetti, and you have ${have}. Smash bushes and pots, win battles and grab confetti piles to fill your bag.`]]);
      return;
    }
    this.s.confetti = have - cost;
    this.s.patched[tr.id] = true;
    sfx('patch'); sfx('chime');
    const z = tr.z ?? 0, y = this.surfaceAt(tr.x, z);
    for (let i = 0; i < 30; i++) this.parts.push({ x: tr.x + (Math.random() - 0.5) * 50, y: y - 4, z: z + (Math.random() - 0.5) * 30, vx: (Math.random() - 0.5) * 200, vy: -200 - Math.random() * 300, life: 1, c: CONF[i % 6], g: 600 });
    const n = Object.keys(this.s.patched).length;
    this.float(`Patched! (${n}/${TEARS.length})`, tr.x, y - 100, '#ffe066', z);
    this.mode = 'script';
    if (tr.give) await this.collect(tr.give, tr.x, y - 60, true);
    else { this.addCoins(5); sfx('coin'); this.float('+5 🪙', tr.x, y - 60, undefined, z); }
    if (this.mode === 'script') this.mode = 'explore';
    if (this.questActive('patch')) this.tip(`🧵 Tears patched: ${n} of ${TEARS.length}${n >= 8 ? '. Go tell Stitch!' : ''}`, 5);
    this.saveSoon();
  },

  addConfetti(n) {
    const before = this.s.confetti || 0;
    this.s.confetti = Math.min(99, before + n);
    if (before < 99 && this.s.confetti >= 99) this.tip('🎉 Your confetti bag is full (99)! Patch some tears with it.', 5);
  },

  // ---------------------------------------------------------------- updrafts
  applyUpdrafts(dt) {
    const P = this.p;
    for (const u of this.room.updrafts || []) {
      if (u.when && !this.flag(u.when)) continue;
      if (P.x < u.x || P.x > u.x + u.w || P.z < u.z0 || P.z > u.z1) continue;
      if (P.y < u.top || P.y > this.surfaceAt(u.x + u.w / 2, (u.z0 + u.z1) / 2) + 2) continue;
      P.vy = Math.max(-430, Math.min(P.vy, 60) - 3400 * dt);
      if (P.y < u.top + 70) P.vy = Math.max(P.vy, -110);   // bob along at the top
      P.onGround = false; P.cut = true; P.coyote = 0;
      if (Math.random() < 0.3) this.parts.push({ x: P.x + (Math.random() - 0.5) * 30, y: P.y, z: P.z, vx: 0, vy: -200, life: 0.4, dust: true, r: 3, g: 0 });
    }
  },

  // ---------------------------------------------------------------- what you can press E on
  mechInteractables(list) {
    const R = this.room, s = this.s;
    const at = (type, o, z, label) => list.push({ type, x: o.x, y: o.y ?? this.surfaceAt(o.x, z), z, ref: o, label });
    for (const k of R.peels || []) if (!s.peeled[k.id] && this.peelVisible(k)) at('peel', k, k.z ?? 0, 'Peel');
    for (const sl of R.slots || []) if (!s.stuck[sl.id]) at('slot', sl, sl.z ?? 0, (s.stickers[sl.kind] || 0) > 0 ? `Stick: ${STICKERS[sl.kind].short}` : 'Look');
    for (const f of R.folks || []) if (!s.rescued[f.id] && this.folkVisible(f)) at('folk', f, f.z ?? 0, 'Unfold');
    for (const tr of R.tears || []) if (!s.patched[tr.id]) at('tear', tr, tr.z ?? 0, `Patch (${tr.cost || 10} 🎉)`);
    for (const bp of R.bombplants || []) if (this.plantRipe(bp) >= 1) at('bombplant', bp, bp.z ?? 0, 'Pick a bomb');
    for (const pt of R.pots || []) if (!this.cleared.has(pt.id)) at('pot', pt, this.thingZ(pt, 'pot'), 'Lift');
    for (const rs of R.resets || []) at('reset', rs, rs.z ?? 0, 'Reset the crates');
  },

  async mechInteract(it) {
    if (it.type === 'peel') this.peelSticker(it.ref);
    else if (it.type === 'slot') await this.stickSlot(it.ref);
    else if (it.type === 'folk') this.unfold(it.ref);
    else if (it.type === 'tear') await this.patchTear(it.ref);
    else if (it.type === 'bombplant') this.pickBomb(it.ref);
    else if (it.type === 'pot') this.liftPot(it.ref);
    else if (it.type === 'reset') this.resetCrates();
    else return false;
    return true;
  },

  // ---------------------------------------------------------------- drawing
  // Flat things on the floor: tears, patches and pressure plates.
  drawMechFloor(c, V, t) {
    const R = this.room;
    for (const tr of R.tears || []) {
      const z = tr.z ?? 0, y = this.surfaceAt(tr.x, z), w = tr.w || 70, d = tr.d || 54, seed = tr.x * 0.13;
      if (this.s.patched[tr.id]) drawPatch3d(c, V, tr.x, y, z, w, d, seed);
      else drawTear3d(c, V, tr.x, y, z, w, d, t, seed);
    }
    for (const pl of R.plates || []) {
      const down = pl.mode === 'latch' ? !!this.s.flags[pl.flag] : !!this.live[pl.flag];
      drawPlate3d(c, V, pl.x, this.surfaceAt(pl.x, pl.z), pl.z, down, { latch: pl.mode === 'latch', w: pl.w, d: pl.d });
    }
  },

  // Fog banks and rock walls reach across the floor, so they're drawn with the walls (wall: drawRoom's, which in a
  // big field puts them among everything else, far to near, so what stands behind one is hidden by it).
  drawMechWalls(c, V, t, wall = (x0, x1, o, fn) => fn()) {
    for (const b of this.room.barriers || []) {
      if (b.look === 'boards' || b.look === 'bars') continue;
      const up = this.barrierUp(b), f = this.fadeOut[b.id];
      const k = up ? 0 : f != null ? (t - f) / 0.9 : 1;
      if (k >= 1) continue;
      const y = this.surfaceAt(b.x + b.w / 2, b.z0 != null ? (b.z0 + b.z1) / 2 : 0), fog = b.look === 'fog';
      const z0 = b.z0 ?? (fog ? GZ0 + 10 : GZ0), z1 = b.z1 ?? (fog ? this.zb - 10 : this.zb);
      wall(b.x, b.x + b.w, { z0, z1 }, () => {
        c.save(); c.globalAlpha = 1 - k;
        if (fog) { c.translate(k * 160, -k * 40); drawFog3d(c, V, b.x, y, b.w, b.vh || 230, t, z0, z1); }
        else drawRockWall3d(c, V, b.x, y - (b.vh || 190), b.w, b.vh || 190, z0, z1);
        c.restore();
      });
    }
  },

  // Everything else stands on the floor: it joins drawRoom's far-to-near list.
  drawMechList(c, V, t, add, cut) {
    const R = this.room, P = this.p, s = this.s, surf = (x, z) => this.surfaceAt(x, z);
    for (const cp of R.camp || []) {
      const y = surf(cp.x, cp.z);
      if (cp.kind === 'tent') cut(cp.x, y, cp.z, 0, () => drawTent(c, 0, 0, { t, color: cp.color }));
      else if (cp.kind === 'campfire') cut(cp.x, y, cp.z, 0, () => drawCampfire(c, 0, 0, t));
      else if (cp.kind === 'stall') cut(cp.x, y, cp.z, 0, () => drawStall(c, 0, 0, t));
    }
    for (const x of R.xplats || []) {
      if (!this.xOn(x)) continue;
      const a = this.fadeIn[x.when] != null ? Math.min(1, (t - this.fadeIn[x.when]) / 0.5) : 1;
      const z0 = x.z0 ?? GZ0 + 10, z1 = x.z1 ?? this.zb - 10;
      const fade = fn => () => { c.save(); c.globalAlpha = a; fn(); c.restore(); };
      if (x.look === 'stairs') add(z0, 0, fade(() => drawPopStairs(c, V, this.stairSteps(x))));
      else if (x.look === 'flower') add(z0, 0, fade(() => drawFlower3d(c, V, x.x, x.y, x.w, z0, z1, surf(x.x + x.w / 2, (z0 + z1) / 2), t)));
      else if (x.look === 'bridge') add(z0, 0, fade(() => drawBridge3d(c, V, x.x, x.y, x.w, z0, z1)));
      else add(z0, 0, fade(() => drawPlat3d(c, V, x.x, x.y, x.w, this.theme(), false, z0, z1)));
    }
    for (const u of R.updrafts || []) {
      if (u.when && !this.flag(u.when)) continue;
      const zc = (u.z0 + u.z1) / 2;
      add(zc, 0, () => drawUpdraft(c, V, u.x, u.w, zc, u.top, surf(u.x + u.w / 2, zc), t));
    }
    for (const b of R.barriers || []) {
      if (b.look !== 'boards' && b.look !== 'bars') continue;
      const up = this.barrierUp(b), f = this.fadeOut[b.id];
      if (!up && (f == null || t - f > 0.6)) continue;
      const bz = b.z0 != null ? (b.z0 + b.z1) / 2 : 0, lit = Array.isArray(b.unless) ? b.unless.filter(fl => this.flag(fl)).length : 0;
      cut(b.x + b.w / 2, surf(b.x + b.w / 2, bz), bz - 2, 0, () => {
        if (!up) { c.globalAlpha = Math.max(0, 1 - (t - f) / 0.6); c.translate(0, -(t - f) * 160); }   // bars slide up out of the way
        if (b.look === 'bars') drawBars(c, b.w, b.vh || 150, lit, Array.isArray(b.unless) ? b.unless.length : 1);
        else drawBoards(c, b.w, b.vh || 130);
        c.globalAlpha = 1;
      });
    }
    for (const sl of R.slots || []) {
      const z = sl.z ?? 0, y = sl.y ?? surf(sl.x, z), kind = s.stuck[sl.id];
      if (!kind) cut(sl.x, y, z, 0, () => drawSlot(c, 0, 0, { t, kind: sl.kind }));
      else if (kind === 'fan') cut(sl.x, y, z, 0, () => drawFan(c, 0, 0, { t, dir: sl.dir || 1 }));
      else if (kind === 'sun') cut(sl.x, y, z, 0, () => drawSunSticker(c, 0, 0, t));
      else cut(sl.x, y, z, 0, () => drawSticker(c, 0, 0, { t, kind, r: kind === 'key' ? 18 : 12, peel: false, still: true, glint: false }));
    }
    for (const k of R.peels || []) {
      if (s.peeled[k.id] || !this.peelVisible(k)) continue;
      cut(k.x, k.y ?? surf(k.x, k.z ?? 0), k.z ?? 0, 0, () => drawSticker(c, 0, 0, { t, kind: k.kind }));
    }
    for (const bp of R.bombplants || []) cut(bp.x, surf(bp.x, bp.z ?? 0), bp.z ?? 0, 0, () => drawBombPlant(c, 0, 0, { t, ripe: this.plantRipe(bp) }));
    for (const f of R.folks || []) {
      if (s.rescued[f.id] || !this.folkVisible(f)) continue;
      const z = f.z ?? 0, near = Math.abs(f.x - P.x) < 130 && Math.abs(z - P.z) < 110;
      cut(f.x, f.y ?? surf(f.x, z), z, 1, () => drawFoldedFolk(c, 0, 0, { t: t + f.x * 0.01, look: f.look, color: (f.opts || {}).color, near }));
    }
    for (const pl of R.piles || []) if (!s.collected[pl.id]) cut(pl.x, surf(pl.x, pl.z ?? 0), pl.z ?? 0, 0, () => drawConfettiPile(c, 0, 0, t));
    for (const rs of R.resets || []) cut(rs.x, surf(rs.x, rs.z ?? 0), rs.z ?? 0, 0, () => drawResetTotem(c, 0, 0, t));
    for (const o of this.crates) add(o.z - CRATE / 2, 0, () => drawCrate3d(c, V, o.x, o.y, o.z, { s: CRATE }));
    for (const b of this.thrown) {
      add(b.z, 2, () => {
        this.floorShadow(c, V, b.x, b.y, b.z, 12);
        atDepth(c, V, b.x, b.y, b.z, () => {
          if (b.kind === 'bomb') drawBomb(c, 0, 0, { t, fuse: b.fuse, shadow: false });
          else { c.translate(0, -14); c.rotate(t * 9); drawPot(c, 0, 14); }
        });
      });
    }
    for (const p of this.pops) {
      const age = t - p.t0, grow = Math.min(1, age / 0.3), leave = Math.max(0, (age - 2) / 0.6);
      cut(p.x + leave * 70, p.y - Math.sin(grow * Math.PI) * 34, p.z, 1, () => {
        c.save(); c.globalAlpha = 1 - leave;
        const k = 0.4 + 0.6 * grow; c.scale(k, k);
        drawFolk(c, 0, 0, { t, ...p.opts, mood: 'happy', lit: true });
        c.restore();
        if (age > 0.3 && age < 2.1) {
          c.font = 'bold 14px Fredoka, sans-serif'; c.textAlign = 'center';
          const w = Math.min(260, c.measureText(p.line).width + 22);
          c.fillStyle = PAPER; c.strokeStyle = INK; c.lineWidth = 2;
          c.beginPath(); rrect(-w / 2, -112, w, 26, 10)(c); c.fill(); c.stroke();
          c.fillStyle = INK; c.fillText(p.line, 0, -94, 240);
        }
      });
    }
  },

  // The bomb or pot over Wick's head (drawn with him, so it sorts with him).
  drawCarried(c, t) {
    const C = this.carry;
    if (!C) return;
    const top = -(this.p.rolled ? 34 : 64) - 2;
    if (C.kind === 'bomb') drawBomb(c, 0, top, { t, fuse: C.fuse, shadow: false });
    else drawPot(c, 0, top);
  },

  drawMechOver(c, V, t) {
    for (const b of this.booms) drawBoom(c, V.x(b.x, b.z), V.y(b.y, b.z), (t - b.t0) / 0.6);
  },

  // ---------------------------------------------------------------- HUD, album and shop
  mechHud() {
    const s = this.s, n = Object.values(s.stickers || {}).reduce((a, b) => a + b, 0);
    const conf = s.confetti || this.questKnown('patch') ? `<span class="hud-pill" title="Confetti: patch tears in the paper with it">🎉 ${s.confetti || 0}</span>` : '';
    return conf + (n ? `<span class="hud-pill" title="Stickers in your album (ESC → Sticker Album)">🗒️ ${n}</span>` : '');
  },

  async stickerAlbum() {
    const s = this.s;
    const items = Object.entries(STICKERS).map(([k, S]) => ({ label: `${S.icon} ${S.name}`, right: `×${s.stickers[k] || 0}`, value: k, desc: `${S.desc} ${S.where}` }));
    await this.menu(this.panelEl, '🗒️ Sticker Album', items, { cancel: true,
      info: `🧍 Folks rescued: ${this.rescuedCount()}/${FOLKS.length} · 🕳️ Tears patched: ${Object.keys(s.patched || {}).length}/${TEARS.length} · 🎉 Confetti: ${s.confetti || 0}/99. Peel stickers off the world with E, then stick them on outlines of the same shape.` });
  },

  async stickerShop() {
    for (;;) {
      const w = this.walletCache;
      const items = SHOP_STICKERS.map(k => ({ label: `${STICKERS[k].icon} ${STICKERS[k].name}`, right: `${STICKERS[k].price} 🪙`, value: k,
        desc: `${STICKERS[k].desc} You have ${this.s.stickers[k] || 0}.`, disabled: w.coins < STICKERS[k].price }));
      const v = await this.menu(this.panelEl, "🗒️ Peely's Sticker Stand", items, { cancel: true,
        info: `You have 🪙 ${w.coins} coins. Each sticker works once: stick it on an outline of the same shape.` });
      if (!v) return;
      const r = await api('/api/wallet', { coins: -STICKERS[v].price });
      if (!r.ok) { sfx('hurt'); continue; }
      this.walletCache = { ...this.walletCache, ...r.wallet };
      this.s.stickers[v] = (this.s.stickers[v] || 0) + 1;
      sfx('peel');
      this.saveNow();
      this.hub.refresh();
    }
  },
};
