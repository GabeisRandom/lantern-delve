// The Lantern Square carnival: four booths, each a quick game played for coins, with Star Pieces the first time you
// reach a silver and a gold score. A game takes over the screen the way a battle does (mode 'minigame'): it gets the
// keys and clicks, draws itself and keeps the score; the booth does the counting in, the results and the prizes.
import { DRAW, drawGloomling, paper, shape, rrect, ell, poly, vgrad, glowDot, starPath, flame, INK, PAPER } from '../art.js';
import { DECOR_DRAW, DECOR_FOOT } from '../art2.js';
import { sfx } from '../audio.js';
import { music } from '../music.js';

const W = 960, H = 540, TAU = Math.PI * 2;
const MEDAL = ['No medal', 'Bronze', 'Silver', 'Gold'], MEDAL_ICON = ['', '🥉', '🥈', '🥇'];
const MEDAL_COINS = [2, 5, 10, 15];
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, k) => a + (b - a) * k;
const shuffle = list => { const l = [...list]; for (let i = l.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [l[i], l[j]] = [l[j], l[i]]; } return l; };

// ---------------------------------------------------------------- shared bits of drawing
// big outlined text, the carnival way
function label(c, text, x, y, size = 26, fill = PAPER, align = 'center') {
  c.font = `bold ${size}px Fredoka, sans-serif`; c.textAlign = align; c.lineJoin = 'round';
  c.lineWidth = Math.max(3, size / 5); c.strokeStyle = INK; c.strokeText(text, x, y);
  c.fillStyle = fill; c.fillText(text, x, y);
}

function pill(c, x, y, w, h, text, fill = PAPER) {
  c.fillStyle = fill; c.strokeStyle = INK; c.lineWidth = 3;
  c.beginPath(); rrect(x, y, w, h, h / 2)(c); c.fill(); c.stroke();
  c.font = `bold ${Math.round(h * 0.52)}px Fredoka, sans-serif`; c.textAlign = 'center'; c.fillStyle = INK;
  c.fillText(text, x + w / 2, y + h * 0.68);
}

// the time left, as a bar along the top
function timeBar(c, left, total) {
  const k = clamp(left / total, 0, 1);
  c.fillStyle = 'rgba(20,10,30,0.45)'; c.beginPath(); rrect(300, 18, 360, 18, 9)(c); c.fill();
  c.fillStyle = k < 0.2 ? '#ff7a6e' : '#ffd25e'; c.beginPath(); rrect(300, 18, Math.max(18, 360 * k), 18, 9)(c); c.fill();
  c.strokeStyle = INK; c.lineWidth = 3; c.beginPath(); rrect(300, 18, 360, 18, 9)(c); c.stroke();
}

// strings of carnival lights swinging across the top
function lights(c, t, y0 = 70) {
  for (let s = 0; s < 2; s++) {
    const y = y0 + s * 38, sag = 26;
    c.strokeStyle = 'rgba(30,20,40,0.6)'; c.lineWidth = 2;
    c.beginPath(); c.moveTo(-20, y); c.quadraticCurveTo(W / 2, y + sag * 2, W + 20, y); c.stroke();
    for (let i = 0; i <= 16; i++) {
      const u = i / 16, x = -20 + u * (W + 40), yy = y + sag * 4 * u * (1 - u);
      const on = 0.6 + 0.4 * Math.sin(t * 3 + i * 1.7 + s);
      glowDot(c, x, yy + 6, 16, ['255,214,120', '255,140,170', '150,220,255'][(i + s) % 3], 0.35 * on);
      c.fillStyle = ['#ffd25e', '#ff9ab0', '#9fe6ff'][(i + s) % 3]; c.beginPath(); c.arc(x, yy + 6, 4, 0, TAU); c.fill();
    }
  }
}

// little scores and words that float up and fade (on the game's clock, so they wait while the game is paused)
class Pops {
  constructor(A) { this.A = A; this.list = []; }
  add(text, x, y, col = PAPER, size = 24) { this.list.push({ text, x, y, col, size, t0: this.A.t }); }
  draw(c) {
    const now = this.A.t;
    this.list = this.list.filter(p => now - p.t0 < 0.8);
    for (const p of this.list) {
      const a = (now - p.t0) / 0.8;
      c.save(); c.globalAlpha = 1 - a * a;
      label(c, p.text, p.x, p.y - a * 46, p.size, p.col);
      c.restore();
    }
  }
}

// ---------------------------------------------------------------- Whack-a-Gloomling
// Three rows of holes on a felt board. Gloomlings pop up and duck back down, faster and faster; bonk one for 10, a
// crowned one for 30, hits in a row multiply it (x2 from 5, x3 from 10). Don't bonk Moss.
class Whack {
  constructor(A) {
    this.A = A; this.total = 30; this.left = 30; this.score = 0; this.combo = 0; this.top = 0; this.hits = 0; this.over = false;
    this.cur = 4; this.swing = -9; this.next = 0.5; this.pops = new Pops(A);
    this.holes = Array.from({ length: 9 }, (_, i) => ({ i, who: null, state: 'empty', t: 0, until: 0 }));
  }

  hole(i) { const r = Math.floor(i / 3), k = [0.8, 0.94, 1.1][r]; return { x: 480 + ((i % 3) - 1) * 210 * k, y: [258, 352, 466][r], k }; }

  update(dt) {
    const A = this.A;
    this.left -= dt;
    if (this.left <= 0) { this.left = 0; this.over = true; return; }
    const prog = 1 - this.left / this.total;
    this.next -= dt;
    if (this.next <= 0) { this.spawn(prog); this.next = lerp(1, 0.5, prog) * (0.75 + Math.random() * 0.5); }
    for (const h of this.holes) {
      if (h.state === 'up' && A.t >= h.until) {
        h.state = 'down'; h.t = A.t;
        if (h.who !== 'moss') this.combo = 0;   // one got away
      } else if ((h.state === 'down' && A.t - h.t > 0.14) || (h.state === 'hit' && A.t - h.t > 0.32)) h.state = 'empty';
    }
  }

  spawn(prog) {
    const free = this.holes.filter(h => h.state === 'empty');
    if (!free.length) return;
    const h = free[Math.floor(Math.random() * free.length)], r = Math.random(), A = this.A;
    h.who = r < 0.1 ? 'gold' : r < 0.22 ? 'moss' : 'gloom';
    // (long enough to get the hammer over with the arrow keys, even near the end)
    h.state = 'up'; h.t = A.t; h.until = A.t + (h.who === 'gold' ? 1 : 1.6) * (1 - prog * 0.4);
  }

  key(act) {
    const r = Math.floor(this.cur / 3), col = this.cur % 3;
    if (act === 'left') this.cur = r * 3 + Math.max(0, col - 1);
    else if (act === 'right') this.cur = r * 3 + Math.min(2, col + 1);
    else if (act === 'up') this.cur = Math.max(0, r - 1) * 3 + col;
    else if (act === 'down') this.cur = Math.min(2, r + 1) * 3 + col;
    else if (act === 'jump' || act === 'act' || act === 'hammer') this.whack();
  }

  click(x, y) {
    let best = null, bd = 1e9;
    for (let i = 0; i < 9; i++) { const p = this.hole(i), d = Math.hypot(x - p.x, (y - p.y + 30 * p.k) * 1.4); if (d < bd) { bd = d; best = i; } }
    if (bd < 110) { this.cur = best; this.whack(); }
  }

  whack() {
    const A = this.A, h = this.holes[this.cur], p = this.hole(this.cur);
    this.swing = A.t;
    if (h.state !== 'up') { this.combo = 0; sfx('swish'); return; }
    h.state = 'hit'; h.t = A.t;
    if (h.who === 'moss') {
      this.score = Math.max(0, this.score - 20); this.combo = 0;
      this.pops.add('Ow! Not Moss! -20', p.x, p.y - 110 * p.k, '#ff9a8f', 22);
      sfx('hurt');
      return;
    }
    this.combo++; this.hits++; this.top = Math.max(this.top, this.combo);
    const mult = this.combo >= 10 ? 3 : this.combo >= 5 ? 2 : 1, pts = (h.who === 'gold' ? 30 : 10) * mult;
    this.score += pts;
    this.pops.add(`+${pts}`, p.x, p.y - 110 * p.k, h.who === 'gold' ? '#ffe066' : PAPER, h.who === 'gold' ? 30 : 24);
    sfx(h.who === 'gold' ? 'coin' : 'hit');
  }

  draw(c, t) {
    c.fillStyle = vgrad(c, 0, H, '#2c2458', '#54417f'); c.fillRect(0, 0, W, H);
    lights(c, t, 52);
    // the felt board, with a wooden rim along the back
    c.fillStyle = vgrad(c, 196, H, '#6cc068', '#3d7a40');
    c.beginPath(); c.moveTo(170, 196); c.lineTo(790, 196); c.lineTo(950, H + 4); c.lineTo(10, H + 4); c.closePath(); c.fill();
    c.strokeStyle = INK; c.lineWidth = 4; c.stroke();
    c.fillStyle = vgrad(c, 176, 202, '#c58b55', '#8a5a3c');
    c.beginPath(); rrect(160, 176, 640, 26, 8)(c); c.fill(); c.stroke();
    label(c, 'WHACK-A-GLOOMLING', 480, 196, 20, '#ffe066');
    for (const h of this.holes) this.drawHole(c, h, t);
    this.drawHammer(c);
    this.pops.draw(c);
    pill(c, 20, 14, 170, 38, `Score ${this.score}`);
    timeBar(c, this.left, this.total);
    if (this.combo >= 2) pill(c, W - 190, 14, 170, 38, `Combo ${this.combo}${this.combo >= 10 ? ' ×3' : this.combo >= 5 ? ' ×2' : ''}`, this.combo >= 5 ? '#ffe066' : PAPER);
  }

  drawHole(c, h, t) {
    const { x, y, k } = this.hole(h.i), A = this.A;
    c.fillStyle = '#1c1428'; c.beginPath(); c.ellipse(x, y, 62 * k, 21 * k, 0, 0, TAU); c.fill();
    // who's in there: rising out, waiting, ducking back down, or squashed flat by a bonk
    const age = A.t - h.t;
    const rise = h.state === 'up' ? Math.min(1, age / 0.12) : h.state === 'down' ? Math.max(0, 1 - age / 0.12)
      : h.state === 'hit' ? Math.max(0, 1 - age / 0.32) : 0;
    if (rise > 0) {
      c.save();
      c.beginPath(); c.rect(x - 100 * k, y - 260 * k, 200 * k, 260 * k + 3); c.clip();   // only what's above the hole shows
      c.translate(x, y + (1 - rise) * 110 * k);
      if (h.state === 'hit') c.scale(1.2, 0.55 + 0.45 * rise);
      const s = 1.9 * k;
      if (h.who === 'moss') DRAW.moss(c, 0, 0, { t, scale: s * 0.9, shadow: false, mood: h.state === 'hit' ? 'angry' : 'happy' });
      else {
        drawGloomling(c, 0, 0, { t, scale: s, shadow: false });
        if (h.who === 'gold') {
          glowDot(c, 0, -40 * s, 46 * s, '255,215,90', 0.45);
          paper(c, p => shape(c, p, poly([[-14 * s, -38 * s], [-14 * s, -52 * s], [-7 * s, -45 * s], [0, -56 * s], [7 * s, -45 * s], [14 * s, -52 * s], [14 * s, -38 * s]]), '#ffd23f', 2));
        }
      }
      c.restore();
      if (h.state === 'hit') { for (let i = 0; i < 3; i++) { c.fillStyle = '#ffe066'; c.beginPath(); starPath(c, x + Math.cos(t * 6 + i * 2.1) * 40 * k, y - 70 * k + Math.sin(t * 6 + i * 2.1) * 12 * k, 7 * k, 3 * k); c.fill(); } }
    }
    // the hole's front lip covers their feet
    c.strokeStyle = '#8fd47a'; c.lineWidth = 7 * k; c.beginPath(); c.ellipse(x, y, 62 * k, 21 * k, 0, 0.15, Math.PI - 0.15); c.stroke();
    c.strokeStyle = INK; c.lineWidth = 2.5; c.beginPath(); c.ellipse(x, y, 66 * k, 24 * k, 0, 0, TAU); c.stroke();
  }

  drawHammer(c) {
    const { x, y, k } = this.hole(this.cur), age = this.A.t - this.swing;
    // a dashed ring on the hole it's aimed at
    c.strokeStyle = 'rgba(255,230,120,0.95)'; c.lineWidth = 3; c.setLineDash([9, 7]);
    c.beginPath(); c.ellipse(x, y, 74 * k, 29 * k, 0, 0, TAU); c.stroke(); c.setLineDash([]);
    // raised just over the hole, then down onto it (the head lands on the hole) and back up
    const ang = age < 0.07 ? lerp(0.6, 0, age / 0.07) : age < 0.22 ? lerp(0, 0.6, (age - 0.07) / 0.15) : 0.6;
    c.save(); c.translate(x + 102 * k, y - 22 * k); c.rotate(ang); c.scale(k, k);
    paper(c, p => {
      shape(c, p, rrect(-90, -6, 86, 12, 5), '#a8794e');
      shape(c, p, rrect(-124, -24, 44, 48, 10), '#c8c2d4');
      shape(c, p, rrect(-124, -24, 11, 48, 5), '#9a93ad');
    });
    c.restore();
  }
}

// ---------------------------------------------------------------- Memory Match
// Sixteen cards, eight pairs of faces from the adventure. Flip two at a time; a pair stays up. Each match scores 100,
// matches in a row add 50 more each (up to +150), and seconds left over once they're all found are worth 10 each.
const FACES = ['wick', 'moss', 'hoot', 'pebble', 'ember', 'peely', 'cat', 'gloomling'];
const FACE_SCALE = { wick: 0.92, moss: 1.35, hoot: 1.1, pebble: 0.95, ember: 0.85, peely: 1.1, cat: 0.95, gloomling: 1.25 };
const CW = 92, CH = 96, CX0 = 480 - (4 * CW + 3 * 16) / 2, CY0 = 96;

class Memory {
  constructor(A) {
    this.A = A; this.total = 60; this.left = 60; this.score = 0; this.streak = 0; this.pairs = 0; this.mistakes = 0; this.over = false;
    this.cards = shuffle([...FACES, ...FACES]).map((k, i) => ({ i, k, up: false, done: false, flip: 1 }));
    this.cur = 5; this.open = []; this.wait = 0; this.peek = 1.8; this.pops = new Pops(A);
  }

  pos(i) { return { x: CX0 + (i % 4) * (CW + 16), y: CY0 + Math.floor(i / 4) * (CH + 8) }; }

  update(dt) {
    for (const cd of this.cards) {
      const want = cd.up || cd.done || this.peek > 0 ? 1 : 0;
      cd.flip += clamp(want - cd.flip, -dt * 6, dt * 6);
    }
    if (this.peek > 0) { this.peek -= dt; return; }   // (the clock waits while you get your peek)
    this.left -= dt;
    if (this.wait > 0) {
      this.wait -= dt;
      if (this.wait <= 0) { for (const cd of this.open) cd.up = false; this.open = []; }
    }
    if (this.pairs === FACES.length || this.left <= 0) {
      if (this.pairs === FACES.length) { const bonus = Math.ceil(this.left) * 10; this.score += bonus; this.timeBonus = bonus; }
      this.left = Math.max(0, this.left);
      this.over = true;
    }
  }

  key(act) {
    const r = Math.floor(this.cur / 4), col = this.cur % 4;
    if (act === 'left') this.cur = r * 4 + (col + 3) % 4;
    else if (act === 'right') this.cur = r * 4 + (col + 1) % 4;
    else if (act === 'up') this.cur = ((r + 3) % 4) * 4 + col;
    else if (act === 'down') this.cur = ((r + 1) % 4) * 4 + col;
    else if (act === 'jump' || act === 'act' || act === 'hammer') this.flip(this.cur);
  }

  click(x, y) {
    for (let i = 0; i < 16; i++) {
      const p = this.pos(i);
      if (x >= p.x && x <= p.x + CW && y >= p.y && y <= p.y + CH) { this.cur = i; this.flip(i); return; }
    }
  }

  flip(i) {
    const cd = this.cards[i];
    if (this.peek > 0 || this.wait > 0 || cd.up || cd.done) return;
    cd.up = true; this.open.push(cd); sfx('select');
    if (this.open.length < 2) return;
    const [a, b] = this.open, p = this.pos(i);
    if (a.k === b.k) {
      a.done = b.done = true; this.open = []; this.pairs++; this.streak++;
      const pts = 100 + Math.min(this.streak - 1, 3) * 50;
      this.score += pts;
      this.pops.add(`+${pts}${this.streak > 1 ? `  ${this.streak} in a row!` : ''}`, p.x + CW / 2, p.y + 10, '#ffe066', 22);
      sfx('coin');
    } else {
      this.wait = 0.75; this.streak = 0; this.mistakes++;
      sfx('tock');
    }
  }

  draw(c, t) {
    // a fortune teller's tent: velvet and gold
    c.fillStyle = vgrad(c, 0, H, '#5a1f4a', '#2a1240'); c.fillRect(0, 0, W, H);
    for (let x = 0; x < W; x += 80) { c.fillStyle = 'rgba(255,255,255,0.04)'; c.fillRect(x, 0, 40, H); }
    c.fillStyle = 'rgba(255,215,90,0.85)';
    for (let x = 20; x < W; x += 60) { c.beginPath(); starPath(c, x, 70 + Math.sin(x) * 6, 4, 2); c.fill(); }
    for (const cd of this.cards) this.drawCard(c, cd, t);
    // the card you're on
    const p = this.pos(this.cur);
    c.strokeStyle = '#ffe066'; c.lineWidth = 4; c.setLineDash([10, 6]);
    c.beginPath(); rrect(p.x - 6, p.y - 6, CW + 12, CH + 12, 14)(c); c.stroke(); c.setLineDash([]);
    this.pops.draw(c);
    pill(c, 20, 14, 170, 38, `Score ${this.score}`);
    timeBar(c, this.left, this.total);
    pill(c, W - 190, 14, 170, 38, `Pairs ${this.pairs}/${FACES.length}`);
    if (this.peek > 0) label(c, 'Take a good look...', 480, 82, 22, '#ffe066');
  }

  drawCard(c, cd, t) {
    const p = this.pos(cd.i), face = cd.flip > 0.5, sx = Math.max(0.04, Math.abs(cd.flip * 2 - 1));
    c.save(); c.translate(p.x + CW / 2, p.y + CH / 2); c.scale(sx, 1);
    paper(c, pp => shape(c, pp, rrect(-CW / 2, -CH / 2, CW, CH, 12), face ? (cd.done ? '#fff6d6' : PAPER) : vgrad(c, -CH / 2, CH / 2, '#7b5fc7', '#4f3a8a')));
    if (face) {
      c.save(); c.beginPath(); rrect(-CW / 2 + 4, -CH / 2 + 4, CW - 8, CH - 8, 9)(c); c.clip();
      const s = FACE_SCALE[cd.k];
      DRAW[cd.k](c, 0, CH / 2 - 12, { t, scale: s, shadow: false, mood: 'happy', glasses: true, flip: 1 });
      c.restore();
      if (cd.done) { c.strokeStyle = '#f2c14e'; c.lineWidth = 4; c.beginPath(); rrect(-CW / 2 + 3, -CH / 2 + 3, CW - 6, CH - 6, 10)(c); c.stroke(); }
    } else {
      // a little lantern on the back of every card
      glowDot(c, 0, 0, 30, '255,214,120', 0.4);
      paper(c, pp => { shape(c, pp, rrect(-12, -16, 24, 30, 6), '#ffd25e', 2); shape(c, pp, rrect(-8, -22, 16, 6, 2), '#3b3350', 2); });
      c.fillStyle = 'rgba(255,255,255,0.18)';
      for (let k = 0; k < 6; k++) { c.beginPath(); starPath(c, Math.cos(k) * 30, Math.sin(k * 2.3) * 34, 3, 1.4); c.fill(); }
    }
    c.restore();
  }
}

// ---------------------------------------------------------------- Lantern Beat
// Flames fall down four lanes, in time with the Lantern Beat groove (songs.js); press a lane's arrow as its flame
// reaches the lantern. The song counts you in for two bars, then the chart runs sixteen bars and gets busier.
const BEAT_BPM = 112, BEAT_LEAD = 8, HIT_Y = 430, PX_BEAT = 150;
const LANE_X = [300, 420, 540, 660], LANE_COL = ['#ff7a8a', '#6fb8ff', '#7fd67a', '#ffd25e'], LANE_KEY = ['←', '↓', '↑', '→'];
const BEAT_CHART = (() => {
  const P = {
    q: [[0, 0], [1, 1], [2, 2], [3, 3]],
    r: [[0, 3], [1, 2], [2, 1], [3, 0]],
    e: [[0, 0], [1, 2], [1.5, 1], [2, 3], [3, 1], [3.5, 2]],
    s: [[0, 1], [0.75, 2], [1.5, 0], [2, 3], [2.75, 2], [3.5, 1]],
    w: [[0, 0], [0.5, 1], [1, 2], [1.5, 3], [2, 2], [2.5, 1], [3, 0], [3.5, 3]],
    f: [[0, 3], [0.5, 3], [1, 0], [1.5, 0], [2, 2], [2.5, 1], [3, 2], [3.5, 1]],
  };
  const plan = ['q', 'r', 'q', 'r', 'e', 's', 'e', 's', 'w', 's', 'e', 'w', 'f', 'w', 's', 'f'];
  const out = [];
  plan.forEach((name, bar) => P[name].forEach(([o, lane]) => out.push({ b: BEAT_LEAD + bar * 4 + o, lane })));
  return out;
})();
const BEAT_END = BEAT_LEAD + 16 * 4 + 1.5;
// every flame a perfect hit, the combo bonus building to double; the medals ask for 30%, 50% and 72% of that (an
// everyday player lands about half their hits perfect and gets silver; gold takes really steady timing)
const BEAT_MAX = BEAT_CHART.reduce((n, _, i) => n + Math.round(100 * (1 + Math.min(i + 1, 40) / 40)), 0);
const BEAT_MEDALS = [0.3, 0.5, 0.72].map(k => Math.round((BEAT_MAX * k) / 100) * 100);

class Beat {
  constructor(A) {
    this.A = A; this.score = 0; this.combo = 0; this.top = 0; this.perfect = 0; this.good = 0; this.miss = 0; this.over = false;
    this.notes = BEAT_CHART.map(n => ({ ...n, hit: null }));
    this.src = null; this.t0 = A.t; this.beat = -1; this.lastTick = -1;
    this.lit = [-9, -9, -9, -9]; this.judged = [null, null, null, null];
  }

  // The beat as you hear it: from the song when the music's playing, else our own clock (with a ticking count-in).
  now() {
    if (this.src === 'music') {
      const b = music.playing === 'lantern_beat' ? music.beat : null;
      if (b != null) return b;
      // the music stopped (turned off with M, say): carry on counting from here ourselves
      this.src = 'own'; this.t0 = this.A.t - (Math.max(0, this.beat) * 60) / BEAT_BPM; this.lastTick = Math.floor(this.beat);
    }
    if (this.src === 'own') return ((this.A.t - this.t0) * BEAT_BPM) / 60;
    return -1;
  }

  // how that press went, shown under the lane's lantern (one at a time, so a fast run doesn't pile up)
  judge(lane, text, col) { this.judged[lane] = { text, col, t: this.A.t }; }

  update() {
    const A = this.A;
    if (!this.src) {
      // wait a moment for the song to start; if the music's off, keep time ourselves
      if (music.enabled && music.volume > 0.001 && music.playing === 'lantern_beat' && music.beat != null) this.src = 'music';
      else if (A.t - this.t0 > (music.enabled && music.volume > 0.001 ? 1.2 : 0)) { this.src = 'own'; this.t0 = A.t; }
      else return;
    }
    this.beat = this.now();
    if (this.src === 'own' && Math.floor(this.beat) > this.lastTick) { this.lastTick = Math.floor(this.beat); sfx(this.beat < BEAT_LEAD ? 'tick' : 'tock'); }
    for (const n of this.notes) {
      if (n.hit == null && this.beat > n.b + 0.3) {
        n.hit = 'miss'; this.miss++; this.combo = 0;
        this.judge(n.lane, 'Miss', '#b9b0d0');
      }
    }
    if (this.beat >= BEAT_END) this.over = true;
  }

  key(act) {
    const lane = { left: 0, down: 1, up: 2, right: 3 }[act];
    if (lane == null || this.beat < BEAT_LEAD - 1) return;
    const b = this.now();
    this.lit[lane] = this.A.t;
    let best = null;
    for (const n of this.notes) if (n.hit == null && n.lane === lane && Math.abs(n.b - b) <= 0.3 && (!best || Math.abs(n.b - b) < Math.abs(best.b - b))) best = n;
    if (!best) return;   // (a stray press costs nothing)
    const off = Math.abs(best.b - b), perfect = off <= 0.12;
    if (off > 0.24) { best.hit = 'miss'; this.miss++; this.combo = 0; this.judge(lane, b < best.b ? 'Early' : 'Late', '#b9b0d0'); return; }
    best.hit = perfect ? 'perfect' : 'good';
    this.combo++; this.top = Math.max(this.top, this.combo);
    if (perfect) this.perfect++; else this.good++;
    const pts = Math.round((perfect ? 100 : 50) * (1 + Math.min(this.combo, 40) / 40));
    this.score += pts;
    this.judge(lane, perfect ? 'PERFECT!' : 'Good', perfect ? '#ffe066' : PAPER);
    sfx(perfect ? 'block' : 'select');
  }

  click(x) {
    // tapping a lane counts as its key
    const lane = LANE_X.findIndex(lx => Math.abs(x - lx) < 60);
    if (lane >= 0) this.key(['left', 'down', 'up', 'right'][lane]);
  }

  draw(c, t) {
    const b = this.beat, pulse = b >= 0 ? Math.max(0, 1 - (b - Math.floor(b)) * 3) : 0;
    c.fillStyle = vgrad(c, 0, H, '#1a1236', '#3a2a66'); c.fillRect(0, 0, W, H);
    // the square at night, glowing a little on every beat
    c.fillStyle = `rgba(255,214,120,${0.05 + pulse * 0.08})`; c.fillRect(0, 0, W, H);
    for (let i = 0; i < 9; i++) {
      const x = 40 + i * 110, h = 90 + (i * 37) % 60;
      c.fillStyle = '#2a1f4a'; c.fillRect(x, 330 - h, 80, h + 220);
      c.fillStyle = `rgba(255,214,120,${0.25 + pulse * 0.3})`; c.fillRect(x + 18, 350 - h, 14, 16); c.fillRect(x + 48, 350 - h, 14, 16);
    }
    // the four lanes
    for (let l = 0; l < 4; l++) {
      const x = LANE_X[l];
      c.fillStyle = 'rgba(255,250,240,0.08)'; c.beginPath(); rrect(x - 44, 40, 88, HIT_Y + 30 - 40, 16)(c); c.fill();
      c.strokeStyle = 'rgba(255,250,240,0.25)'; c.lineWidth = 2; c.stroke();
    }
    // flames coming down
    for (const n of this.notes) {
      if (n.hit && n.hit !== 'miss') continue;
      const d = n.b - b;
      if (d > 2.6 || d < -0.45) continue;
      const x = LANE_X[n.lane], y = HIT_Y - d * PX_BEAT;
      c.save(); c.globalAlpha = (n.hit === 'miss' ? 0.35 : 1) * clamp((y - 40) / 40, 0, 1);   // (fading in at the top of the lane)
      glowDot(c, x, y, 34, '255,200,120', 0.35);
      paper(c, pp => shape(c, pp, ell(x, y, 17, 17), LANE_COL[n.lane], 2.5));
      flame(c, x, y - 4, 0.95, t * 1.5 + n.b);
      c.restore();
    }
    // the lanterns you light
    for (let l = 0; l < 4; l++) {
      const x = LANE_X[l], since = this.A.t - this.lit[l], glow = Math.max(0, 1 - since / 0.25);
      glowDot(c, x, HIT_Y, 60, '255,214,120', 0.15 + glow * 0.5);
      paper(c, pp => {
        shape(c, pp, rrect(x - 10, HIT_Y - 40, 20, 8, 3), '#3b3350');
        shape(c, pp, rrect(x - 26, HIT_Y - 32, 52, 60, 18), glow > 0 ? '#fff2c4' : LANE_COL[l]);
        shape(c, pp, rrect(x - 12, HIT_Y + 26, 24, 8, 3), '#3b3350');
      });
      label(c, LANE_KEY[l], x, HIT_Y + 8, 26, PAPER);
      const j = this.judged[l], a = j ? (this.A.t - j.t) / 0.5 : 1;
      if (a < 1) { c.save(); c.globalAlpha = 1 - a * a; label(c, j.text, x, HIT_Y + 74 - a * 6, j.text === 'PERFECT!' ? 21 : 19, j.col); c.restore(); }
    }
    if (b >= 0 && b < BEAT_LEAD) {
      const n = Math.floor(b), word = n < 4 ? 'Get ready...' : ['3', '2', '1', 'GO!'][n - 4];
      label(c, word, 480, 250, n < 4 ? 34 : 64 + pulse * 20, '#ffe066');
    }
    if (this.combo >= 4) label(c, `${this.combo} combo`, 480, 100, 30 + pulse * 6, this.combo >= 20 ? '#ffe066' : PAPER);
    pill(c, 20, 14, 190, 38, `Score ${this.score}`);
    timeBar(c, BEAT_END - Math.max(0, b), BEAT_END);
  }
}

// ---------------------------------------------------------------- Paper Plane Glide
// A paper plane over Lumenfold. Hold up to climb, let go to glide, down to dive. Rings score 10, plus 5 for each ring
// in a row before it (up to +50); stars are 5. Storm clouds and crows knock a heart off (three and you're down).
class Plane {
  constructor(A) {
    this.A = A; this.total = 45; this.left = 45; this.score = 0; this.chain = 0; this.top = 0; this.rings = 0; this.hearts = 3; this.over = false;
    this.y = 270; this.vy = 0; this.px = 230; this.speed = 260; this.dist = 0; this.inv = 0;
    this.items = []; this.nextRing = 1; this.nextFoe = 6; this.ringY = 270; this.pops = new Pops(A);
    this.clouds = Array.from({ length: 7 }, (_, i) => ({ x: i * 150 + Math.random() * 80, y: 40 + Math.random() * 200, s: 0.6 + Math.random() * 0.7 }));
  }

  update(dt) {
    const A = this.A;
    this.left -= dt;
    if (this.left <= 0 || this.hearts <= 0) { this.left = Math.max(0, this.left); this.over = true; return; }
    this.speed = 260 + (1 - this.left / this.total) * 150;
    const up = A.keys.has('up') || A.keys.has('jump') || this.mouse, down = A.keys.has('down');
    this.vy = clamp(this.vy + (up ? -1150 : down ? 950 : 430) * dt, -340, 400);
    this.y += this.vy * dt;
    if (this.y < 46) { this.y = 46; this.vy = Math.max(0, this.vy); }
    if (this.y > 494) { this.y = 494; this.vy = Math.min(0, this.vy); }
    const dx = this.speed * dt;
    this.dist += dx;
    if (this.inv > 0) this.inv -= dt;
    for (const cl of this.clouds) { cl.x -= dx * 0.3 * cl.s; if (cl.x < -160) { cl.x += W + 320; cl.y = 40 + Math.random() * 200; } }
    // what's coming: rings at a height that wanders, a star or two between them, and later on clouds and crows
    this.nextRing -= dt;
    if (this.nextRing <= 0) {
      this.ringY = clamp(this.ringY + (Math.random() - 0.5) * 260, 100, 440);
      this.items.push({ kind: 'ring', x: W + 60, y: this.ringY });
      if (Math.random() < 0.7) this.items.push({ kind: 'star', x: W + 60 + this.speed * 0.6, y: clamp(this.ringY + (Math.random() - 0.5) * 160, 70, 470) });
      this.nextRing = 1.15 + Math.random() * 0.35;
    }
    this.nextFoe -= dt;
    if (this.nextFoe <= 0) {
      const crow = Math.random() < 0.5;
      let fy = 60 + Math.random() * 400;
      for (const it of this.items) if (it.kind === 'ring' && it.x > W - 120 && Math.abs(it.y - fy) < 110) fy = it.y > 270 ? it.y - 170 : it.y + 170;   // (never right in a ring)
      this.items.push({ kind: crow ? 'crow' : 'storm', x: W + 120, y: clamp(fy, 60, 470), ph: Math.random() * 6 });
      this.nextFoe = lerp(2.6, 1.3, 1 - this.left / this.total) + Math.random() * 0.8;
    }
    for (const it of this.items) {
      const before = it.x;
      it.x -= dx * (it.kind === 'crow' ? 1.25 : 1);
      if (it.kind === 'crow') it.y += Math.sin(A.t * 3 + it.ph) * 40 * dt;
      if (it.done) continue;
      if (it.kind === 'ring' && before >= this.px && it.x < this.px) {
        it.done = true;
        if (Math.abs(this.y - it.y) < 40) {
          this.chain++; this.rings++; this.top = Math.max(this.top, this.chain);
          const pts = 10 + Math.min(this.chain - 1, 10) * 5;
          this.score += pts; it.got = A.t;
          this.pops.add(`+${pts}`, this.px + 30, it.y - 60, '#ffe066', 24);
          sfx('coin');
        } else { this.chain = 0; sfx('tock'); }
      } else if (it.kind === 'star' && Math.hypot(it.x - this.px, it.y - this.y) < 30) {
        it.done = true; this.score += 5; this.pops.add('+5', it.x, it.y - 30, PAPER, 20); sfx('select');
      } else if ((it.kind === 'crow' || it.kind === 'storm') && this.inv <= 0 && Math.abs(it.x - this.px) < (it.kind === 'storm' ? 56 : 32) && Math.abs(it.y - this.y) < (it.kind === 'storm' ? 34 : 26)) {
        this.hearts--; this.inv = 1.3; this.chain = 0; this.vy = 220;
        this.pops.add(it.kind === 'storm' ? 'Zap!' : 'Caw!', this.px, this.y - 50, '#ff9a8f', 24);
        sfx('hurt');
      }
    }
    this.items = this.items.filter(it => it.x > -160);
  }

  key() { /* held keys steer (see update) */ }
  click() { /* (holding the mouse button climbs: see pointer below) */ }

  draw(c, t) {
    c.fillStyle = vgrad(c, 0, H, '#8fd6f2', '#ffe2c4'); c.fillRect(0, 0, W, H);
    glowDot(c, 820, 90, 160, '255,240,180', 0.5);
    c.fillStyle = '#fff6d8'; c.beginPath(); c.arc(820, 90, 34, 0, TAU); c.fill();
    // paper hills far below, sliding by slowly
    for (let layer = 0; layer < 2; layer++) {
      const off = (this.dist * (layer ? 0.25 : 0.12)) % 240;
      c.fillStyle = layer ? '#7fc56a' : '#a8d890';
      c.beginPath(); c.moveTo(0, H);
      for (let x = -off - 240; x < W + 240; x += 240) c.quadraticCurveTo(x + 120, H - (layer ? 90 : 130) - 40, x + 240, H - (layer ? 40 : 70));
      c.lineTo(W, H); c.closePath(); c.fill();
    }
    for (const cl of this.clouds) this.cloud(c, cl.x, cl.y, cl.s, '#ffffff', 0.5, true);
    // the far half of each ring, then the plane, then the near half: the plane flies through
    for (const it of this.items) if (it.kind === 'ring') this.ring(c, it, t, false);
    for (const it of this.items) {
      if (it.kind === 'star' && !it.done) { c.save(); c.translate(it.x, it.y); c.rotate(t * 2); paper(c, pp => shape(c, pp, cc => starPath(cc, 0, 0, 14, 6), '#ffe066', 2)); c.restore(); }
      else if (it.kind === 'storm') {
        this.cloud(c, it.x, it.y, 0.75, '#5b5674', 1);
        // a cross little face, and a lightning bolt that flickers
        c.strokeStyle = PAPER; c.lineWidth = 3; c.lineCap = 'round';
        c.beginPath(); c.moveTo(it.x - 16, it.y - 12); c.lineTo(it.x - 6, it.y - 8); c.moveTo(it.x + 16, it.y - 12); c.lineTo(it.x + 6, it.y - 8); c.stroke();
        if (Math.floor(t * 6 + it.ph) % 3) {
          c.fillStyle = '#ffe066'; c.strokeStyle = INK; c.lineWidth = 1.5;
          c.beginPath(); c.moveTo(it.x + 4, it.y + 8); c.lineTo(it.x - 8, it.y + 30); c.lineTo(it.x + 2, it.y + 28); c.lineTo(it.x - 6, it.y + 48); c.lineTo(it.x + 12, it.y + 22); c.lineTo(it.x + 2, it.y + 24); c.closePath(); c.fill(); c.stroke();
        }
      }
      else if (it.kind === 'crow') DRAW.ashcrow(c, it.x, it.y + 20, { t: t + it.ph, scale: 0.9, flip: -1, shadow: false });
    }
    this.plane(c, t);
    for (const it of this.items) if (it.kind === 'ring') this.ring(c, it, t, true);
    this.pops.draw(c);
    pill(c, 20, 14, 170, 38, `Score ${this.score}`);
    timeBar(c, this.left, this.total);
    pill(c, W - 230, 14, 210, 38, `${'♥'.repeat(this.hearts)}${'♡'.repeat(3 - this.hearts)}  Chain ${this.chain}`, this.chain >= 5 ? '#ffe066' : PAPER);
  }

  // (the soft ones are just scenery, far behind: no outline, so they never look like something to dodge)
  cloud(c, x, y, s, col, a, soft = false) {
    c.save(); c.globalAlpha = a; c.translate(x, y); c.scale(s, s);
    const puffs = [[-40, 6, 40, 24], [0, -8, 46, 32], [42, 6, 38, 24]];
    if (soft) { c.fillStyle = col; for (const [ex, ey, rx, ry] of puffs) { c.beginPath(); c.ellipse(ex, ey, rx, ry, 0, 0, TAU); c.fill(); } }
    else paper(c, pp => { for (const [ex, ey, rx, ry] of puffs) shape(c, pp, ell(ex, ey, rx, ry), col, 2); });
    c.restore();
  }

  ring(c, it, t, near) {
    const got = it.got != null ? Math.min(1, (this.A.t - it.got) / 0.4) : 0;
    c.save(); c.translate(it.x, it.y); c.scale(1 + got * 0.4, 1 + got * 0.4); c.globalAlpha = 1 - got;
    c.lineWidth = 9; c.strokeStyle = near ? '#ffd23f' : '#c8981e';
    c.beginPath(); c.ellipse(0, 0, 14, 44, 0, near ? Math.PI / 2 : -Math.PI / 2, near ? Math.PI * 1.5 : Math.PI / 2); c.stroke();
    c.lineWidth = 2; c.strokeStyle = INK; c.stroke();
    c.restore();
    if (!near && !it.done) glowDot(c, it.x, it.y, 40, '255,220,110', 0.25 + Math.sin(t * 5) * 0.08);
  }

  plane(c, t) {
    if (this.inv > 0 && Math.floor(t * 12) % 2) return;
    const ang = Math.atan2(this.vy, this.speed) * 0.9;
    c.save(); c.translate(this.px, this.y); c.rotate(ang); c.scale(1.3, 1.3);
    paper(c, pp => {
      shape(c, pp, poly([[38, 0], [-30, -18], [-18, 0]]), '#fffaf0', 2.2);
      shape(c, pp, poly([[38, 0], [-18, 0], [-34, 14]]), '#e8e2f4', 2.2);
      shape(c, pp, poly([[38, 0], [-24, 4], [-30, 8]]), '#d8d0ea', 1.6);
    });
    c.restore();
  }
}

// ---------------------------------------------------------------- the booths
export const GAMES = {
  whack: {
    name: 'Whack-a-Gloomling', host: 'Bonk', medals: [200, 500, 950], song: 'battle', make: A => new Whack(A),
    intro: "Step right up! Gloomlings keep popping out of my board, and somebody's gotta bonk 'em! 30 seconds, and the better you bonk, the better the prize!",
    rules: "Move the hammer with the ARROW KEYS (or click a hole) and press SPACE to bonk. Plain Gloomlings are 10, crowned ones 30. Bonk a bunch in a row for double and triple points! But if Moss pops up... DON'T bonk Moss.",
  },
  memory: {
    name: 'Memory Match', host: 'Madame Shuffle', medals: [400, 900, 1400], song: 'menu', make: A => new Memory(A),
    intro: 'Ahh, a traveler with sharp eyes! I see... sixteen cards in your future. Eight pairs of faces you may know. Find them all before the sands run out!',
    rules: "Flip two cards at a time with the ARROW KEYS and SPACE (or click them). A matching pair stays face up. Matches in a row are worth extra, and every second left when you've found them all is a bonus. You get one peek at the start. Use it wisely!",
  },
  beat: {
    name: 'Lantern Beat', host: 'DJ Flicker', medals: BEAT_MEDALS, song: 'lantern_beat', make: A => new Beat(A),
    intro: "Yo yo yo! Lantern Square needs a little more GLOW, and you've got the rhythm to light it up. Hit the lanterns on the beat and let's get FUNKY!",
    rules: "Flames fall toward four lanterns. When one reaches its lantern, hit that lantern's ARROW KEY (← ↓ ↑ →, or A S W D) right on the beat. Perfect hits score double what OK ones do, and your combo bonus builds all the way to double. Keep the streak alive!",
  },
  plane: {
    name: 'Paper Plane Glide', host: 'Pilot Pleat', medals: [300, 700, 1150], song: 'fields', make: A => new Plane(A),
    intro: "Ever wanted to see Lumenfold from up high? Hop in my paper plane! Fly through the golden rings, and mind the weather.",
    rules: 'Hold ↑ (or SPACE, or the mouse button) to climb, let go to glide down, and press ↓ to dive. Fly through the golden rings: each ring in a row is worth more than the last. Stars are a bonus. Storm clouds and crows knock you around. Three bumps and you land early!',
  },
};

// what the host says when you're done: nothing, bronze, silver, gold
const VERDICT = {
  whack: ['Ooh, so close! The Gloomlings are laughing at me now. Go again?', 'Nice bonking! A bronze for you.', 'Wham! Bam! Silver bonker!', "THE BONK LEGEND! Gold! I've never seen a hammer move like that!"],
  memory: ['The cards were cloudy today... Try again, traveler.', 'Bronze! Your memory is waking up.', 'Silver! The spirits are impressed.', 'Gold! You remembered everything. Are you sure you are not a fortune teller?'],
  beat: ['Hey, everybody starts somewhere! Feel the groove and run it back!', "Bronze! You've got the beat in you!", 'Silver! The whole square is grooving now!', 'GOLD! The lanterns have never been brighter! You ARE the funk!'],
  plane: ['Bumpy flight! The sky will be here when you want another go.', 'Bronze wings! Not bad at all.', "Silver wings! You're a natural flyer.", 'Gold wings! The finest flying this side of Lumenfold!'],
};

const COUNT_IN = 2.4;   // seconds of "3, 2, 1, GO!" (Lantern Beat's song counts you in instead)

export const MINI = {
  miniRecord(id) {
    this.s.minigames = this.s.minigames || {};
    return this.s.minigames[id] || (this.s.minigames[id] = { best: 0, medal: 0, plays: 0 });
  },

  // Talking to a booth's host: what the game is (the first time), then play, hear the rules, or leave.
  async boothMenu(id) {
    const g = GAMES[id];
    if (!this.miniRecord(id).plays) await this.say(g.host, g.intro);
    for (;;) {
      const rec = this.miniRecord(id);
      const prize = rec.medal >= 3 ? "Win coins every time. (You've already won both Star Piece prizes here!)"
        : rec.medal === 2 ? 'Win coins every time, and 3 ⭐ Star Pieces the first time you get a gold.'
        : 'Win coins every time, and ⭐ Star Pieces the first time you get a silver (1) and a gold (3 more).';
      this.inMenu = true;
      let v;
      try {
        v = await this.menu(this.panelEl, `🎪 ${g.name}`, [
          { label: '🎮 Play!', value: 'play', desc: prize },
          { label: '📜 How to play', value: 'rules' },
          { label: 'Not now', value: 'leave' },
        ], { info: `Best: ${rec.best ? `${rec.best} ${MEDAL_ICON[rec.medal]}` : '—'}   ·   🥉 ${g.medals[0]}   🥈 ${g.medals[1]}   🥇 ${g.medals[2]}` });
      } finally { this.inMenu = false; }
      this.panelEl.classList.add('hidden');
      if (v === 'rules') { await this.say(g.host, g.rules); continue; }
      if (v !== 'play') return;
      const res = await this.playMinigame(id);
      if (res) await this.say(g.host, VERDICT[id][res.medal]);
    }
  },

  // One game: count in, play, show the score. Resolves with the result (null if you quit).
  playMinigame(id) {
    return new Promise(resolve => {
      const g = GAMES[id];
      this.keys.clear();
      this.mini = { id, g, game: g.make(this), phase: id === 'beat' ? 'play' : 'ready', t0: this.t, resolve };
      this.mode = 'minigame';
      if (id !== 'beat') sfx('menu');
    });
  },

  updateMinigame(dt) {
    const M = this.mini;
    if (!M) return;
    if (M.phase === 'ready') {
      if (this.t - M.t0 >= COUNT_IN) { M.phase = 'play'; M.t0 = this.t; sfx('start'); }
      return;
    }
    if (M.phase === 'play') {
      M.game.update(dt);
      if (M.game.over) this.finishMinigame();
    }
  },

  finishMinigame() {
    const M = this.mini, rec = this.miniRecord(M.id), score = Math.round(M.game.score);
    const medal = M.g.medals.filter(m => score >= m).length;
    const stars = (medal >= 2 && rec.medal < 2 ? 1 : 0) + (medal >= 3 && rec.medal < 3 ? 3 : 0);
    const coins = MEDAL_COINS[medal], best = score > rec.best;
    rec.plays++;
    if (best) rec.best = score;
    rec.medal = Math.max(rec.medal, medal);
    M.result = { score, medal, best, coins, stars };
    M.phase = 'results'; M.t0 = this.t;
    (async () => { await this.addCoins(coins); if (stars) await this.addStars(stars); this.hub.refresh(); })();
    sfx(medal >= 3 ? 'fanfare' : medal ? 'levelup' : 'chime');
    this.saveSoon();
  },

  closeMinigame(quit) {
    const M = this.mini;
    if (!M) return;
    this.mini = null;
    this.mode = 'script';   // (back to the booth's conversation)
    this.keys.clear();
    M.resolve(quit ? null : M.result);
  },

  minigameKey(act) {
    const M = this.mini;
    if (M.phase === 'results') {
      if (this.t - M.t0 > 0.6 && ['jump', 'act', 'menu', 'hammer'].includes(act)) this.closeMinigame(false);
      return;
    }
    if (act === 'menu') { this.closeMinigame(true); return; }   // ESC: walk away from the booth
    if (M.phase === 'play') M.game.key(act);
  },

  minigameClick(x, y) {
    const M = this.mini;
    if (M.phase === 'results') { if (this.t - M.t0 > 0.6) this.closeMinigame(false); return; }
    if (M.phase === 'play') M.game.click(x, y);
  },

  // the paper plane climbs while the mouse button is held down
  minigamePointer(down) { if (this.mini && this.mini.game instanceof Plane) this.mini.game.mouse = down; },

  drawMinigame(c) {
    const M = this.mini;
    if (!M) return;
    M.game.draw(c, this.t);
    if (M.phase === 'ready') {
      const age = this.t - M.t0, n = Math.floor(age / (COUNT_IN / 3)), k = (age % (COUNT_IN / 3)) / (COUNT_IN / 3);
      c.fillStyle = 'rgba(20,10,30,0.35)'; c.fillRect(0, 0, W, H);
      label(c, M.g.name, 480, 190, 34, '#ffe066');
      label(c, ['3', '2', '1'][Math.min(2, n)], 480, 300, 90 * (1.2 - k * 0.3), PAPER);
    } else if (M.phase === 'results') this.drawResults(c, M);
    c.font = '13px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillStyle = 'rgba(255,250,240,0.75)';
    c.fillText(M.phase === 'results' ? 'SPACE: back to the booth' : 'ESC: quit', 480, H - 8);
  },

  drawResults(c, M) {
    const r = M.result, age = this.t - M.t0, pop = Math.min(1, age / 0.25);
    c.fillStyle = `rgba(20,10,30,${0.55 * pop})`; c.fillRect(0, 0, W, H);
    c.save(); c.translate(480, 270); c.scale(0.8 + pop * 0.2, 0.8 + pop * 0.2);
    paper(c, pp => shape(c, pp, rrect(-230, -150, 460, 300, 24), PAPER, 3));
    c.fillStyle = INK; c.textAlign = 'center';
    c.font = 'bold 26px Fredoka, sans-serif'; c.fillText(M.g.name, 0, -104);
    c.font = 'bold 64px Fredoka, sans-serif'; c.fillText(String(r.score), 0, -30);
    c.font = 'bold 26px Fredoka, sans-serif';
    c.fillText(r.medal ? `${MEDAL_ICON[r.medal]} ${MEDAL[r.medal]}!` : 'No medal this time', 0, 18);
    c.font = '20px Fredoka, sans-serif';
    c.fillText(`+${r.coins} 🪙${r.stars ? `   +${r.stars} ⭐ Star Piece${r.stars > 1 ? 's' : ''}` : ''}`, 0, 58);
    if (r.best) { c.fillStyle = '#c4572a'; c.font = 'bold 20px Fredoka, sans-serif'; c.fillText('★ New best! ★', 0, 96); }
    c.restore();
  },
};

// ---------------------------------------------------------------- the booths in Lantern Square
// A market stall in the game's colors, with its name on a board over the awning and a hint of the game on the counter.
// (The counter is low, and what's on it sits at the ends, so you can see the host standing behind it.)
const BOOTH = {
  whack: { sign: 'WHACK!', cols: ['#e5534b', '#fffaf0'], board: '#ffe066' },
  memory: { sign: 'MEMORY', cols: ['#7b5fc7', '#fff3c4'], board: '#e8dcff' },
  beat: { sign: 'BEAT', cols: ['#ff6fa8', '#fffaf0'], board: '#9fe6ff' },
  plane: { sign: 'GLIDE', cols: ['#4f9fd6', '#fffaf0'], board: '#fff3c4' },
};

function drawBooth(c, t, id) {
  const b = BOOTH[id];
  paper(c, p => {
    shape(c, p, rrect(-50, -112, 6, 112, 2), '#8a5a3c', 2);
    shape(c, p, rrect(44, -112, 6, 112, 2), '#8a5a3c', 2);
    shape(c, p, rrect(-56, -34, 112, 34, 4), vgrad(c, -34, 0, '#c9925c', '#8a5a3c'), 2);
    shape(c, p, rrect(-3, -168, 6, 44, 2), '#8a5a3c', 2);
    shape(c, p, rrect(-50, -166, 100, 30, 8), b.board, 2.5);
  });
  for (let i = 0; i < 6; i++) {
    c.fillStyle = b.cols[i % 2]; c.strokeStyle = INK; c.lineWidth = 2;
    c.beginPath(); c.moveTo(-62 + i * 21, -126); c.lineTo(-41 + i * 21, -126); c.lineTo(-41 + i * 21, -104); c.quadraticCurveTo(-51.5 + i * 21, -96, -62 + i * 21, -104); c.closePath(); c.fill(); c.stroke();
  }
  c.font = 'bold 17px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillStyle = INK; c.fillText(b.sign, 0, -145);
  // the twinkling bulbs around the board
  for (let i = 0; i < 6; i++) { c.fillStyle = (Math.floor(t * 3) + i) % 2 ? '#fff6c8' : '#ffb347'; c.beginPath(); c.arc(-40 + i * 16, -136, 2.6, 0, TAU); c.fill(); }
  // what's on the counter
  if (id === 'whack') {
    paper(c, p => { shape(c, p, rrect(-52, -41, 30, 6, 3), '#a8794e', 1.5); shape(c, p, rrect(-30, -48, 14, 18, 4), '#c8c2d4', 1.5); });
    drawGloomling(c, 38, -34, { t, scale: 0.4, shadow: false });
  } else if (id === 'memory') {
    for (const [x, a, back] of [[-44, -0.3, 0], [-34, 0.05, 1], [34, -0.05, 1], [44, 0.3, 0]]) {
      c.save(); c.translate(x, -34); c.rotate(a);
      paper(c, p => shape(c, p, rrect(-7, -20, 14, 20, 3), back ? '#7b5fc7' : PAPER, 1.5));
      c.restore();
    }
  } else if (id === 'beat') {
    const k = Math.max(0, 1 - ((t * 112) / 60 % 1) * 3);
    for (const s of [-1, 1]) {
      paper(c, p => { shape(c, p, rrect(s * 40 - 11, -60, 22, 26, 4), '#3b3350', 2); shape(c, p, ell(s * 40, -47, 7, 7), s < 0 ? '#ff6fa8' : '#9fe6ff', 1.5); });
      c.strokeStyle = `rgba(255,214,120,${0.4 + k * 0.6})`; c.lineWidth = 2;
      c.beginPath(); c.arc(s * 40, -47, 14 + k * 4, s > 0 ? -0.9 : Math.PI - 0.9, s > 0 ? 0.9 : Math.PI + 0.9); c.stroke();
    }
  } else if (id === 'plane') {
    for (const [x, y, a] of [[-38, -44, -0.2], [38, -48, 0.15]]) {
      c.save(); c.translate(x, y + Math.sin(t * 2 + x) * 2); c.rotate(a);
      paper(c, p => { shape(c, p, poly([[14, 0], [-12, -8], [-7, 0]]), '#fffaf0', 1.5); shape(c, p, poly([[14, 0], [-7, 0], [-13, 6]]), '#d8d0ea', 1.5); });
      c.restore();
    }
  }
}

for (const id of Object.keys(BOOTH)) {
  DECOR_DRAW[`booth_${id}`] = (c, t) => drawBooth(c, t, id);
  DECOR_FOOT[`booth_${id}`] = DECOR_FOOT.stall;
}

// The booth hosts' scripts (the hosts themselves stand behind the Lantern Square booths: see deep.js).
export const MINI_SCRIPTS = {
  mg_whack: [['minigame', 'whack']],
  mg_memory: [['minigame', 'memory']],
  mg_beat: [['minigame', 'beat']],
  mg_plane: [['minigame', 'plane']],
};
export const MINI_SPEAKERS = { Bonk: 'folk', 'Madame Shuffle': 'folk', 'DJ Flicker': 'candle', 'Pilot Pleat': 'folk' };
export const MINI_SPEAKER_OPTS = {
  Bonk: { color: '#ff9a7a', body: '#c45a5a', hat: 'bucket' },
  'Madame Shuffle': { color: '#d9b8ff', body: '#5d4a70', hat: 'feather', specs: true },
  'DJ Flicker': { wax: '#ffb0c8', wax2: '#d9708f', specs: true },
  'Pilot Pleat': { color: '#9fe6ff', body: '#4f72bf', hat: 'straw' },
};
