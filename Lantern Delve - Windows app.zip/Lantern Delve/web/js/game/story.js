// More story along the way: a few lines the first time you reach each place (with whoever is travelling with you
// chiming in), Mothwick back in town after the first shard, and "meanwhile..." scenes with Count Dusk and the
// boss of each chapter. data.js merges STORY_SCRIPTS and runs patchStory() last. Every scene is a once-only room
// trigger (x 0 = as you arrive), so each plays one time per save.

// a line from whoever is travelling with you right now (if it's them)
const pal = (id, name, line) => ['if', A => A.s.partner === id, [['say', name, line]]];

export const STORY_SCRIPTS = {
  // ---- the Prologue
  story_outskirts: [
    ['narrate', 'The Outskirts Path. With the Great Lantern broken, the dark out here feels thick enough to touch.'],
    ['narrate', 'Down in the gaps between the stones, Gloom bubbles like cold soup. Better to jump over it than find out what it tastes like.'],
  ],

  // ---- between the Prologue and Chapter 1
  story_fields: [
    ['narrate', "Lumen Fields. Even under a sky this dark, the farmers have hung little lanterns along their fences. Nobody out here has given up."],
    pal('moss', 'Moss', 'blorp! grass! the good kind. the kind you can roll in.'),
    ['narrate', 'Somewhere at the back of the west woods, a forest path winds up toward the Grumbling Grove.'],
  ],
  story_lake: [
    ['narrate', "Mirror Lake. The water is so still it shows the stars... even the ones Count Dusk's darkness has hidden from the sky."],
    pal('moss', 'Moss', 'blorp. if i fall in, i float. probably.'),
    pal('hoot', 'Hoot', 'Some say the old library at the bottom of this lake holds every story ever written down.'),
  ],

  // ---- Chapter 1
  story_grove: [
    ['narrate', 'Meanwhile, at the top of a tower that was never there before...'],
    ['say', 'Count Dusk', "A candle? They sent a CANDLE? Ha! Candles burn down. It's the only thing candles ever do."],
    ['say', 'Count Dusk', "Let him wander the Grumbling Grove. The trees there have forgotten how to wake up. Soon he'll forget too."],
    ['narrate', 'Back in the grove, the trees creak... as if they are listening for someone.'],
    pal('moss', 'Moss', 'blorp. the trees are whispering. about us? rude.'),
  ],
  story_after_ch1: [
    ['say', 'Mothwick', "Wick! The first shard! When you walked back into town the Great Lantern flickered. Only for a moment, but I saw it."],
    ['say', 'Mothwick', "Every bit of Light that keeps your lantern burning comes from the Hero of Homework's focus. Remember that, both of you."],
    ['say', 'Mothwick', "The next shard went north, into the Inkwell Caverns. The North Gate is open now, at the east side of town."],
    pal('hoot', 'Hoot', "Caverns. Dark, damp and full of ink. Good thing I brought my spectacles."),
    pal('moss', 'Moss', 'blorp. caves are echo-y. blorp. blorp. see?'),
    ['narrate', 'High on the Great Lantern, one small flame flickers back to life.'],
  ],

  // ---- Chapter 2
  story_trail: [
    ['narrate', 'The North Trail climbs toward the mountains. The wind up here smells like ink and old paper.'],
    pal('hoot', 'Hoot', 'Ink on the wind... Someone up there is painting with the dark itself.'),
  ],
  story_caves: [
    ['narrate', 'Meanwhile, in the tower...'],
    ['say', 'Count Dusk', 'Smudge, my Ink Witch! The candle is coming your way. Make those caverns so dark he forgets what he came for.'],
    ['say', 'Smudge', "Ooh, a visitor! I'll paint him the most BEAUTIFUL darkness. He'll never, ever want to leave."],
    ['narrate', 'In the caverns, the dark drips from the ceiling... and somewhere deep inside, someone is humming.'],
  ],

  // ---- Chapter 3
  story_peak: [
    ['narrate', 'Meanwhile, high above Ember Peak...'],
    ['say', 'Count Dusk', 'Two shards gone. TWO! Cindermaw, do everything at once! Burn hotter! Faster! Never stop!'],
    ['say', 'Cindermaw', '...ALWAYS... HOTTER... NEVER... REST...'],
    ['narrate', "Far below, the mountain rumbles like it's very, very tired."],
    pal('pebble', 'Pebble', '...mountain sounds sad.'),
    pal('hoot', 'Hoot', "Everything here is running on fumes. Even the rocks look like they need a nap."),
  ],

  // ---- Chapter 4
  story_moor: [
    ['narrate', 'Midnight Moor. Every clock out here has stopped at one minute to twelve, as if the whole world is holding its breath.'],
    pal('ember', 'Ember', "This is it, Wick. His tower. Whatever's waiting up there, we face it together."),
    pal('pebble', 'Pebble', '...big tower. we go up. one step at a time.'),
    pal('hoot', 'Hoot', 'One minute to midnight. Then we have exactly one minute. Plenty, if we spend it well.'),
  ],

  // ---- side places
  story_castle: [
    ['narrate', 'Lantern Hill Road. Up ahead, Old Lumen Castle sits dark on its hill, its towers like candles nobody has lit in years.'],
  ],
};

// room id -> [trigger id, script, when?]
const SCENES = [
  ['pro_2', 'story_outskirts', A => A.flag('intro_done'), 300],
  ['fields_1', 'story_fields', A => A.flag('prologue_done')],
  ['lake_1', 'story_lake', A => A.flag('prologue_done')],
  ['grove_1', 'story_grove', A => !A.flag('ch1_done')],
  ['pro_1', 'story_after_ch1', A => A.flag('ch1_done') && !A.flag('ch2_done')],
  ['mtn_1', 'story_trail', A => A.flag('ch1_done')],
  ['cave_1', 'story_caves', A => !A.flag('ch2_done')],
  ['peak_1', 'story_peak', A => !A.flag('ch3_done')],
  ['dusk_1', 'story_moor', A => !A.flag('ch4_done')],
  ['castle_road', 'story_castle', A => A.flag('prologue_done')],
];

export function patchStory(ROOMS) {
  for (const [room, script, when, x = 0] of SCENES) {
    const R = ROOMS[room];
    if (!R) continue;
    (R.triggers ||= []).push({ id: script, x, script, once: true, when });
  }
}
