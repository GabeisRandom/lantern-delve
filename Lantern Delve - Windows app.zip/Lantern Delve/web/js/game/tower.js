// Chapter 4: Count Dusk's Tower. North of the North Trail lies the Midnight Moor, where it has been ten minutes to night
// for as long as anyone remembers, and on it a crooked clock tower. Count Dusk stopped every clock in Lumenfold at
// "Later O'Clock". The Great Lantern's light lays a path across the moor; inside the tower Wick frees Tick (an alarm
// clock who can stop time), beats the Scrollwyrm (the endless feed) for Shard 4, climbs the Dim Stair with every friend
// he has made, and faces Count Dusk at the top for Shard 5. data.js merges all of this in (see patchTower).
// The field and battle mechanics for it (Time Stop, pendulums, Tick's moves, the bosses) live in tower_play.js.
import { ramp } from './deep.js';

const T = (x0, x1, z0, z1, y, more = {}) => ({ x0, x1, z0, z1, y, ...more });
const IN = (name, style, w, extra) => ({ name, theme: 'interior', style, interior: true, w, ground: [[0, w, 450]], exits: {}, ...extra });
const ring = (kind, x, z, r, n, k = 1) => Array.from({ length: n }, (_, i) => ({ kind, k, x: x + Math.cos((i / n) * Math.PI * 2) * r, z: z + Math.sin((i / n) * Math.PI * 2) * r * 0.7 }));
const CLOCKS = ['clock1', 'clock2', 'clock3', 'clock4'];
const wound = A => CLOCKS.filter(id => A.flag(`wound_${id}`)).length;
const hrs = s => ((s || 0) / 3600).toFixed(1);

// ---------------------------------------------------------------- the new partner
export const TOWER_PARTNERS = {
  tick: {
    name: 'Tick', hp: 9, color: '#e8a93a',
    moves: [
      { id: 'ring', name: 'Ring Bash', fp: 0, desc: "Tick hops on an enemy and BONGs it (brass doesn't mind spikes). Press SPACE as Tick lands for a second ring!" },
      { id: 'alarm', name: 'Alarm', fp: 2, desc: "RING-A-DING! Every enemy jumps out of its skin and may lose its next turn. Press SPACE with the ring to make it stick. (Startled enemies ignore it for a few rounds.)" },
      { id: 'rewind', name: 'Rewind', fp: 3, desc: "Winds back the enemies' last turn: Wick and Tick get back the HP they just lost." },
    ],
    team: { name: 'Countdown', fp: 4, desc: "Wind up the alarm together: SPACE, X, SPACE... on each tick, faster and faster. Then RING: it hits every enemy, harder for every wind. More winds at higher Bond." },
    field: { name: 'Time Stop', desc: 'Tick stops time for a few seconds: pendulums, moving platforms, steam and enemies all freeze. (Bump a frozen enemy for a First Strike!)' },
  },
};

// ---------------------------------------------------------------- enemies
export const TOWER_ENEMIES = {
  notifly: { name: 'Notifly', hp: 2, atk: 1, def: 0, flying: true, turn: 'notiflyTurn', xp: 16, coins: [1, 3], h: 36, lvl: 9,
    tattle: 'A Notifly. DING! DING! Leave one alone and it calls another. Notifications pile up FAST, so swat them early. It flies: no hammers. Max HP 2.' },
  snoozer: { name: 'Snoozer', hp: 4, atk: 2, def: 0, turn: 'snoozerTurn', xp: 20, coins: [2, 4], h: 50, lvl: 9,
    tattle: 'A Snoozer: an alarm clock that hit snooze so many times it forgot how to stop. Its lullaby ring puts you to sleep, so guard it! Max HP 4, Attack 2.' },
  scrollbug: { name: 'Scrollbug', hp: 3, atk: 1, def: 0, turn: 'scrollbugTurn', xp: 18, coins: [2, 3], h: 40, lvl: 9,
    tattle: "A Scrollbug. It wiggles an endless feed of shiny nothing in your face. If it bites you, you're distracted: timing gets harder for a bit. Max HP 3." },
  sandglass: { name: 'Sandglass', hp: 5, atk: 1, def: 1, bomb: true, turn: 'sandglassTurn', xp: 24, coins: [3, 5], h: 58, lvl: 10,
    tattle: "A Sandglass. Its sand runs out in 3 turns, and then: TIME'S UP, a big hit on everyone. Beat it first! Defense 1. Max HP 5." },
  scrollwyrm: { name: 'The Scrollwyrm', hp: 36, atk: 2, def: 0, boss: true, turn: 'scrollwyrmTurn', xp: 200, coins: [60, 60], h: 160, scale: 1.5, lvl: 13,
    tattle: "The Scrollwyrm, the endless feed. 'Just one more' is all it ever says. It plays Scrollbugs up next, and if a whole round goes by without you hurting it, it heals. Tick's Alarm snaps it out of it! Max HP 36." },
  duskboss: { name: 'Count Dusk', hp: 60, atk: 3, def: 0, boss: true, turn: 'duskTurn', xp: 300, coins: [100, 100], h: 160, scale: 1.55, lvl: 15,
    tattle: "Count Dusk, the Lord of Later. He knows every trick in the book: snoozing, smudging, doing it all at once, one more video. His LATER! spell postpones your turn, so guard it! Max HP 50." },
};

// ---------------------------------------------------------------- badges
export const TOWER_BADGES = {
  early_bird: { name: 'Early Bird', bp: 2, desc: 'Every battle (except bosses) starts with a First Strike.' },
  snooze_proof: { name: 'Snooze Proof', bp: 1, desc: "Nothing can put you to sleep. Not even Count Dusk." },
  time_keeper: { name: 'Time Keeper', bp: 1, desc: "Every action command's timing window is 25% wider." },
  lumen_crown: { name: 'Lumen Crown', bp: 3, desc: '+1 damage on every hit, and you take 1 less damage from every attack.' },
};

// ---------------------------------------------------------------- side quests
export const TOWER_QUESTS = {
  gears: { name: "Tick's Lost Gears", giver: 'Tick', where: "Count Dusk's Tower",
    desc: "Count Dusk shook five of Tick's gears loose when he locked Tick up. They rolled all over the Midnight Moor and the tower. Some ended up somewhere high.",
    progress: A => { const n = A.collectedCount('gear'); return { done: n >= 5, text: `Gears found: ${n} of 5` }; },
    reward: { badge: 'early_bird', coins: 30 } },
  clocks: { name: 'Wind the Old Clocks', giver: 'Old Minute', where: 'Midnight Moor',
    desc: "Old Minute's four oldest friends are stopped clocks out on the Midnight Moor. Walk up to each one and wind it (E).",
    progress: A => ({ done: wound(A) >= 4, text: `Clocks wound: ${wound(A)} of 4` }),
    reward: { badge: 'snooze_proof', starPieces: 1 } },
  ticktock: { name: 'Tick Tock', giver: 'Old Minute', where: 'Midnight Moor', study: true,
    desc: 'Study Challenge: check off 25 homework steps, in total. One small step at a time!',
    progress: A => ({ done: A.stat('steps_done') >= 25, text: `Homework steps checked off: ${Math.min(25, A.stat('steps_done'))} of 25` }),
    reward: { badge: 'time_keeper', starPieces: 2 } },
};

// ---------------------------------------------------------------- speakers
export const TOWER_SPEAKERS = {
  Tick: 'tick', 'Old Minute': 'minute', 'The Scrollwyrm': 'scrollwyrm', 'Stopped Clock': 'gclock',
  'Later Larry': 'folk', 'Someday Sue': 'folk', 'Tomorrow Tom': 'folk',
};
export const TOWER_SPEAKER_OPTS = {
  'Later Larry': { color: '#a89cc8', body: '#4f4670', hat: 'bucket' },
  'Someday Sue': { color: '#d8a8c8', body: '#6a4a70', hat: 'feather' },
  'Tomorrow Tom': { color: '#9ab8c8', body: '#3f5670', specs: true },
  'The Scrollwyrm': { mood: 'happy' },
};
export const TOWER_PORTRAITS = { tick: 2.3, minute: 0.95, scrollwyrm: 0.6, gclock: 0.95 };

// ---------------------------------------------------------------- the story goal for Chapter 4 (data.js asks this)
export function towerGoal(A, G) {
  if (A.flag('ch4_done')) return null;
  if (!A.flag('ch4_open')) return G('Go back to Lumen Town and talk to Mothwick', 'pro_1', 1490);
  if (!A.s.seenAreas.tower) return G('Take the North Gate up the North Trail, then follow the Lantern Path north', 'mtn_1', 1100, 'The Lantern Path starts at the far back of the North Trail, between Glass Lake and the Snowcap.');
  if (!A.hasPartner('tick')) return G("Cross the Midnight Moor into Count Dusk's Tower", 'dusk_2', 1200, "Somebody is ringing in the lobby. The brass plate by the bells tells you the order.");
  if (!A.flag('wyrm_down')) return G('Get through the Pendulum Hall (Tick can stop time: press C)', 'dusk_4', 560, 'With Tick as your partner, press C to freeze the pendulums, then walk right past them.');
  return G("Climb the Dim Stair to the top of Count Dusk's Tower", 'dusk_top', 600, "Every friend has a trick for the Dim Stair: Pebble smashes, Ember burns, Moss springs, Hoot peeks, Tick stops time. Switch partners with ESC → Party.");
}
export const AFTER_STORY = 'You saved Lumenfold! Side quests, secrets and Study Challenges are still out there (ESC → Quests).';

// ---------------------------------------------------------------- rooms
export const TOWER_ROOMS = {
  // ======================= THE MIDNIGHT MOOR: one big open field, 3600 wide and 2400 deep. The tower is at the far
  // north-east corner; the Lantern Path glows from the North Trail signpost all the way to the tower gate.
  dusk_1: {
    name: 'Midnight Moor', area: 'tower', theme: 'moor', music: 'dusk', w: 3600, z1: 2400,
    ground: [[0, 3600, 450]],
    hazard: 'ink',
    decorSet: 'moor',
    roadColor: 'rgba(255,214,120,0.5)',
    holes: [[900, 1500, 600, 1000], [2050, 2650, 1350, 1750]],   // two gloom bogs
    terrain: [
      ramp(800, 1000, 1850, 2050, 450, 300, 'west', 'stone'), T(300, 800, 1800, 2300, 300, { mat: 'stone' }),   // Moonrise Knoll
    ],
    groves: [[0, 600, 700, 1600], [3000, 3600, 200, 1400]],
    roads: [[160, -40, 700, 300], [700, 300, 1700, 1150], [1700, 1150, 2700, 1050], [2700, 1050, 3300, 2330]],
    plats: [
      [1000, 450, 70, 780, 840], [1120, 450, 70, 780, 840], [1240, 450, 70, 780, 840],   // stepping stones into the west bog
      [1320, 450, 120, 760, 860],                                                        // a little island of stone
    ],
    lamps: [{ x: 420, z: 260 }, { x: 2950, z: 1900 }],
    decor: [...ring('mclock', 2350, 2150, 210, 7), { kind: 'deadtree', x: 1800, z: 1650, k: 1.6 }, { kind: 'deadtree', x: 2900, z: 700, k: 1.5 }],
    furniture: [{ kind: 'telescope', x: 560, z: 2150, label: 'Look', say: "Through the telescope: the top of Count Dusk's Tower. A tiny figure in a big cape is lying on a deck chair up there. He's... napping?" }],
    npcs: [
      { id: 'minute', x: 1250, z: 330, kind: 'minute', name: 'Old Minute', talk: 'minute' },
      { id: 'larry', x: 560, z: 760, kind: 'folk', name: 'Later Larry', talk: 'larry', opts: { color: '#a89cc8', body: '#4f4670', hat: 'bucket', mood: 'sleepy' } },
      { id: 'sue', x: 1900, z: 1350, kind: 'folk', name: 'Someday Sue', talk: 'sue', opts: { color: '#d8a8c8', body: '#6a4a70', hat: 'feather', mood: 'sleepy' }, flip: -1 },
      { id: 'tom', x: 2750, z: 450, kind: 'folk', name: 'Tomorrow Tom', talk: 'tom', opts: { color: '#9ab8c8', body: '#3f5670', specs: true, mood: 'sleepy' } },
      { id: 'sage4', x: 3080, z: 2150, kind: 'crane', name: 'Origami Sage', talk: 'sage_tower', flip: -1 },
      // Old Minute's four friends: stopped, then (once wound) ticking
      ...[['clock1', 720, 1300], ['clock2', 1950, 620], ['clock3', 2350, 2150], ['clock4', 3380, 760]].flatMap(([id, x, z]) => [
        { id, x, z, kind: 'gclock', name: 'Stopped Clock', talk: id, label: 'Wind', show: A => !A.flag(`wound_${id}`) },
        { id: `${id}_on`, x, z, kind: 'gclock', name: 'Stopped Clock', talk: 'clock_ticking', opts: { running: true }, show: A => A.flag(`wound_${id}`) },
      ]),
    ],
    enemies: [
      { id: 'm_e1', x: 1000, z: 300, kind: 'notifly', group: ['notifly', 'notifly'], y: 340, range: 90 },
      { id: 'm_e2', x: 1600, z: 1300, kind: 'snoozer', group: ['snoozer'] },
      { id: 'm_e3', x: 2200, z: 900, kind: 'scrollbug', group: ['scrollbug', 'scrollbug'] },
      { id: 'm_e4', x: 2800, z: 1600, kind: 'snoozer', group: ['snoozer', 'notifly'] },
      { id: 'm_e5', x: 3200, z: 2000, kind: 'scrollbug', group: ['scrollbug', 'notifly', 'snoozer'] },
      { id: 'm_e6', x: 1300, z: 1500, kind: 'notifly', group: ['notifly', 'notifly', 'notifly'], y: 330, range: 100 },
    ],
    chests: [
      { id: 'm_bog', x: 1380, z: 810, give: { starPiece: 1 } },
      { id: 'm_woods', x: 3450, z: 1100, give: { item: 'bighoney', n: 2 } },
      { id: 'm_grave', x: 2350, z: 2060, give: { coins: 30 } },
      { id: 'm_knoll', x: 680, z: 2200, give: { item: 'embertea', n: 2 } },
    ],
    collect: [{ id: 'gear_knoll', kind: 'gear', x: 480, y: 300, z: 2050 }, { id: 'gear_bog', kind: 'gear', x: 1155, y: 450, z: 810 }],
    blocks: [{ id: 'm_b1', x: 2000, y: 300, z: 1150, give: { coins: 8 } }, { id: 'm_h1', x: 2600, y: 290, z: 600, hidden: true, give: { starPiece: 1 } }],
    signs: [
      { x: 320, z: 120, text: "The Midnight Moor. It's been ten minutes to night here for as long as anyone can remember. The Lantern Path glows all the way to the tower." },
      { x: 3160, z: 2270, text: "COUNT DUSK'S TOWER. Visitors: please come back LATER. — The Management" },
      { x: 900, z: 520, text: 'Gloom bogs: ink so thick and sticky that nothing ever gets done in it. Keep to the stepping stones!' },
    ],
    seals: [{ id: 'seal_time', x: 2000, need: 21600 }],
    doors: [
      { x: 140, to: 'mtn_1', toX: 1100, label: 'North Trail', style: 'front' },
      { x: 3300, z: 2370, to: 'dusk_2', toX: 160, label: "Count Dusk's Tower" },
      { x: 2000, to: 'seal_4', toX: 140, label: '???', needSeal: 'seal_time' },
    ],
    triggers: [
      { id: 'ch4_card', x: 0, script: 'ch4_card', once: true },
      { id: 'dusk_moor', x: 2700, script: 'dusk_moor', once: true, when: A => !A.flag('ch4_done') },
    ],
    exits: {},
  },

  // ======================= inside the tower
  dusk_2: IN('Clockwork Lobby', 'clocktower', 2000, {
    area: 'tower', battleTheme: 'towerstage', night: true, windows: [420, 1640],
    lamps: [260],
    plats: [[300, 330, 120]],
    doors: [
      { x: 120, to: 'dusk_1', toX: 3300, label: 'Midnight Moor', exit: true },
      { x: 1880, to: 'dusk_3', toX: 160, label: 'Up the stairs' },
    ],
    furniture: [
      { kind: 'clock', x: 560, label: 'Look', say: "A grandfather clock, stopped at ten to midnight. Somebody has painted over the 12. Now it just says LATER." },
      { kind: 'gears', x: 760 },
      { kind: 'banner', x: 900, color: '#5d4a70' }, { kind: 'banner', x: 1660, color: '#5d4a70' },
      { kind: 'chandelier', x: 1150 },
      { kind: 'sign2', x: 1000, text: '♫ ♪ ♬', label: 'Read', say: "A brass plate under the bells: 'MY DOOR CHIME: ♫, then ♪, then ♬. — C.D.' Underneath, scratched in very small letters: 'please let me out. — Tick'" },
      { kind: 'painting', x: 1440, pic: 'castle', label: 'Look', say: "A painting of this very tower, from back when its clock still ran. In the corner, in Count Dusk's handwriting: 'boring'." },
      { kind: 'armor', x: 1760 },
    ],
    switches: [
      { id: 'bell_a', x: 1100, mark: '♪', color: '#f2c14e', puzzle: 'bells' },
      { id: 'bell_b', x: 1200, mark: '♫', color: '#9fe6ff', puzzle: 'bells' },
      { id: 'bell_c', x: 1300, mark: '♬', color: '#ff9ab0', puzzle: 'bells' },
    ],
    puzzle: { id: 'bells', order: ['bell_b', 'bell_a', 'bell_c'], flag: 'tick_cage', hint: 'The brass plate by the bells has the order: ♫, then ♪, then ♬.' },
    cages: [{ x: 1500, y: 380, z: 136, flag: 'tick_cage' }],
    pendulums: [{ x: 1880, top: 50, len: 360, r: 32, amp: 0.85, period: 2.2 }],
    // (Tick stands inside the cage: a touch further back than its bars)
    npcs: [{ id: 'tick_npc', x: 1500, y: 372, z: 144, kind: 'tick', name: 'Tick', talk: 'tick_caged', show: A => !A.flag('tick_cage') }],
    collect: [{ id: 'gear_lobby', kind: 'gear', x: 360, y: 330 }],
    enemies: [{ id: 'l_e1', x: 700, kind: 'hollowarmor', group: ['hollowarmor', 'notifly'], range: 100 }],
    triggers: [{ id: 'lobby', x: 320, script: 'dusk_lobby', once: true }],
  }),
  dusk_3: IN('Pendulum Hall', 'clocktower', 2900, {
    area: 'tower', battleTheme: 'towerstage', night: true, windows: [300, 2560],
    ground: [[0, 560, 450], [860, 1300, 450], [1640, 2060, 450], [2400, 2900, 450]],
    lamps: [200],
    movers: [
      { x: 580, y: 440, w: 110, dx: 160, period: 3.4 },
      { x: 1320, y: 440, w: 110, dx: 200, period: 3.6, phase: 1 },
      { x: 2080, y: 440, w: 110, dx: 200, period: 3.2, phase: 2 },
    ],
    pendulums: [
      { x: 1080, top: 50, len: 360, r: 32, amp: 0.95, period: 2.0 },
      { x: 1850, top: 50, len: 360, r: 32, amp: 1.0, period: 1.8, phase: 1.5 },
      { x: 2650, top: 50, len: 360, r: 32, amp: 0.9, period: 1.6 },
    ],
    plats: [[1700, 290, 100]],
    collect: [{ id: 'gear_hall', kind: 'gear', x: 1750, y: 290 }],
    blocks: [{ id: 'h_b1', x: 1040, y: 300, give: { item: 'honeybun' } }, { id: 'h_h1', x: 2560, y: 290, hidden: true, give: { starPiece: 1 } }],
    furniture: [{ kind: 'gears', x: 400 }, { kind: 'gears', x: 2780 }, { kind: 'banner', x: 1460, color: '#5d4a70' }],
    signs: [{ x: 360, text: "The Pendulum Hall. Those pendulums hit like a Monday morning. With Tick as your partner, press C to stop time, then walk right past them." }],
    enemies: [
      { id: 'h_e1', x: 960, kind: 'sandglass', group: ['sandglass'], range: 60 },
      { id: 'h_e2', x: 2500, kind: 'hollowarmor', group: ['hollowarmor', 'sandglass'], range: 80 },
    ],
    doors: [
      { x: 140, to: 'dusk_2', toX: 1880, label: 'Clockwork Lobby' },
      { x: 2800, to: 'dusk_4', toX: 160, label: 'The Endless Gallery' },
    ],
  }),
  dusk_4: IN('The Endless Gallery', 'clocktower', 1500, {
    area: 'tower', battleTheme: 'towerstage', night: true, windows: [400, 1100],
    lamps: [260],
    doors: [
      { x: 140, to: 'dusk_3', toX: 2800, label: 'Pendulum Hall' },
      { x: 1380, to: 'dusk_5', toX: 160, label: 'The Dim Stair', need: 'wyrm_down', needText: "The Scrollwyrm's coils are wrapped round the stairs." },
    ],
    furniture: [
      { kind: 'painting', x: 520, pic: 'castle', label: 'Look', say: 'A screen in a picture frame. It says: "Up next: another one of these." Then another one of those.' },
      { kind: 'painting', x: 820, pic: 'castle', label: 'Look', say: 'Another framed screen: "Are you still watching?" Nobody has ever pressed No.' },
    ],
    boss: { kind: 'scrollwyrm', x: 1000, flag: 'wyrm_down', scale: 1.5, awake: true },
    triggers: [{ id: 'wyrm', x: 560, script: 'wyrm_fight', when: A => !A.flag('wyrm_down') }],
    npcs: [{ id: 'wyrm_npc', x: 1000, kind: 'scrollwyrm', name: 'The Scrollwyrm', talk: 'wyrm_after', show: A => A.flag('wyrm_down'), opts: { scale: 1.2, mood: 'happy' }, flip: -1 }],
  }),
  // The Dim Stair: Count Dusk's last defense, every kind of trouble in a row, and a friend for each one.
  dusk_5: IN('The Dim Stair', 'clocktower', 3500, {
    area: 'tower', battleTheme: 'towerstage', night: true, windows: [260, 1620, 3340],
    ground: [[0, 1100, 450], [1100, 1420, 240], [1900, 2300, 240], [2300, 2700, 450], [3200, 3500, 330]],
    lamps: [200],
    // (solid, and taller than a jump: Pebble's the one to smash it, as the sign says; a boulder without `solid` only
    // hides a door or a chest)
    boulders: [{ id: 'g_boulder', x: 520, solid: [465, 290, 110, 160] }],
    vines: [{ id: 'g_vines', x: 820, y: -200, w: 34, h: 650 }],
    blocks: [
      { id: 'g_hb1', x: 1500, y: 250, hidden: true, give: { coins: 5 } },
      { id: 'g_hb2', x: 1640, y: 250, hidden: true, give: { coins: 5 } },
      { id: 'g_hb3', x: 1780, y: 250, hidden: true, give: { item: 'honeybun' } },
    ],
    pendulums: [
      { x: 2010, top: 50, len: 160, r: 26, amp: 1.0, period: 1.4 },
      { x: 2190, top: 50, len: 160, r: 26, amp: 1.0, period: 1.4, phase: 2.1 },
    ],
    low: [[2420, 180]],
    hidden: [[2780, 410, 110], [2960, 370, 110], [3110, 340, 90]],
    collect: [{ id: 'gear_stair', kind: 'gear', x: 2600, y: 450 }],
    signs: [
      { x: 330, text: "THE DIM STAIR. Count Dusk's last defense: every kind of trouble, one after another. Good thing you've got every kind of friend. (Switch partners any time: ESC → Party.)" },
      { x: 430, text: 'A boulder! Pebble can smash it (C).' },
      { x: 730, text: 'Vines! Ember can burn them away (C).' },
      { x: 1010, text: 'Way too high to jump. Moss can spring you up there (C).' },
      { x: 1360, y: 240, text: "A pit with nothing over it... or is there? Hoot can Peek for hidden blocks (C)." },
      { x: 1950, y: 240, text: 'Pendulums! Tick can stop time (C).' },
      { x: 2330, text: 'Low rocks: hold R to roll under.' },
      { x: 2650, text: 'Pitch dark over the pit. Flare (F) to light up the way across!' },
    ],
    enemies: [
      { id: 'g_e1', x: 650, kind: 'snoozer', group: ['snoozer', 'notifly'], range: 60 },
      { id: 'g_e2', x: 2550, kind: 'scrollbug', group: ['scrollbug', 'sandglass'], range: 70 },
    ],
    doors: [
      { x: 140, to: 'dusk_4', toX: 1380, label: 'The Endless Gallery' },
      { x: 3400, to: 'dusk_top', toX: 160, label: 'The Clock Face' },
    ],
  }),
  // the very top: the roof over the clock face, under the moon
  dusk_top: {
    name: 'The Clock Face', area: 'tower', theme: 'dusktop', w: 1500,
    ground: [[0, 1500, 450]],
    lamps: [200],
    boss: { kind: 'duskboss', x: 1060, flag: 'ch4_done', scale: 1.55, awake: true },
    triggers: [{ id: 'dusk_final', x: 600, script: 'dusk_fight', when: A => !A.flag('ch4_done') }],
    npcs: [
      { id: 'moth_top', x: 820, kind: 'mothwick', name: 'Mothwick', talk: 'moth_top', show: A => A.flag('moth_top') && !A.flag('ending_seen') },
      { id: 'dusk_npc', x: 1060, kind: 'dusk', name: 'Count Dusk', talk: 'dusk_after', show: A => A.flag('ch4_done') && !A.flag('ending_seen'), opts: { scale: 1.3 }, flip: -1 },
    ],
    doors: [{ x: 140, to: 'dusk_5', toX: 3400, label: 'The Dim Stair' }],
    exits: {},
  },
  seal_4: IN('Timeless Vault', 'stars', 1100, {
    area: 'tower', music: 'secret', night: true,
    doors: [{ x: 120, to: 'dusk_1', toX: 2000, label: 'Back out', exit: true }],
    signs: [{ x: 330, text: 'Only the truly focused may enter. (Six whole hours of it. You are unstoppable.)' }],
    chests: [{ id: 's4ch1', x: 600, give: { badge: 'lumen_crown' } }, { id: 's4ch2', x: 860, give: { starPiece: 3 } }],
  }),
};

// ---------------------------------------------------------------- story scripts
const focusLine = A => {
  const h = A.stat('focus_seconds') / 3600;
  return h >= 1 ? `I felt every bit of it: ${hrs(A.stat('focus_seconds'))} hours of real, focused work. THAT is what lit the Great Lantern.`
    : "Every focused minute they gave went into that light. That's what lit the Great Lantern.";
};
const pickLine = list => () => list[Math.floor(Math.random() * list.length)];

export const TOWER_SCRIPTS = {
  ch4_call: [
    ['cut', 'beam'],
    ['say', 'Mothwick', "Wick! Look at the Great Lantern! Three shards, and it's... humming. And that beam is pointing north."],
    ['say', 'Mothwick', "Past the North Trail is the Midnight Moor, where it's always ten minutes to night. And on the moor stands Count Dusk's Tower."],
    ['say', 'Mothwick', "The last two shards are up in that tower. The Lantern's light has laid a path across the moor for you. It starts at the far end of the North Trail."],
    ['say', 'Mothwick', "And Wick... Count Dusk is the one who whispers 'later' in everyone's ear. He'll whisper it to you too. Don't listen."],
    ['flag', 'ch4_open'],
    ['tip', 'Chapter 4 is open! Take the North Gate up the North Trail, then follow the Lantern Path at the back of the trail.', 9],
  ],
  ch4_card: [['card', 'Chapter 4', "Count Dusk's Tower"]],
  dusk_moor: [
    ['cut', 'dusk_in'],
    ['say', 'Count Dusk', "Ah, candle-boy. Welcome to MY moor. Lovely, isn't it? It's always almost bedtime here."],
    ['say', 'Count Dusk', "Nobody here ever has to START anything. They just wait. Forever. It's very relaxing."],
    ['say', 'Count Dusk', 'Why not have a little sit? You can save the kingdom... later.'],
    ['narrate', "Wick's flame flickers. Somewhere far away, the Hero of Homework is still working. The flame steadies."],
    ['say', 'Count Dusk', "...Hmph. Stubborn little wick. Fine! Come up to my tower, if you can stand the wait. Mwahaha!"],
    ['cut', 'dusk_out'],
  ],
  larry: [['say', 'Later Larry', A => (A.flag('ch4_done')
    ? "I answered ONE message. Then another one! It's four now. I'm on a roll! ...I'm taking a break after five. On purpose!"
    : "I'll answer my messages later. ...I've been saying that for three hundred days. There are a lot of messages now.")]],
  sue: [['say', 'Someday Sue', A => (A.flag('ch4_done')
    ? "I wrote the first sentence of my novel! It's a bad sentence. I LOVE it. Tomorrow I'll write another one. A real tomorrow!"
    : "Someday I'll write my novel. Someday when I'm ready. When I'm more ready. When I'm... the most ready...")]],
  tom: [['say', 'Tomorrow Tom', A => (A.flag('ch4_done')
    ? 'I cleaned my room. Okay, one corner of my room. But it was a REALLY messy corner!'
    : "Tomorrow. I'll start tomorrow. ...It's never tomorrow here. It's always ten minutes to night. So it never comes. Convenient!")]],
  sage_tower: [
    ['say', 'Origami Sage', 'Ah. The little candle. All the way to the end of the map.'],
    ['say', 'Origami Sage', 'Glide. Roll. Every fold I showed you was really the same lesson: make the big thing small, and begin.'],
    ['say', 'Origami Sage', 'Count Dusk cannot fold. He can only wait. You, little candle, have never been better at beginning.'],
  ],
  minute: [
    ['if', A => !A.questKnown('clocks'), [
      ['say', 'Old Minute', '...Oh... a visitor... tick... how... unexpected... tock...'],
      ['say', 'Old Minute', "Forgive me... I've slowed down a little... since Count Dusk stopped all the clocks..."],
      ['say', 'Old Minute', "My four oldest friends... are out on the moor... stopped... at ten to midnight. ...Could you wind them for me? ...Just walk up and give them a turn..."],
      ['quest', 'clocks'],
    ], [
      ['if', A => A.questReady('clocks'), [
        ['turnin', 'clocks'],
        ['say', 'Old Minute', "...Listen. Tick... tock... tick... They're all running again. ...Thank you, young candle. Here: you'll never doze off when it counts."],
      ], [
        ['if', A => A.questActive('clocks'), [['say', 'Old Minute', A => `...Clocks wound so far: ${wound(A)} of 4... They're scattered all over the moor... one is in the dead woods to the east...`]], [
          ['if', A => !A.questKnown('ticktock'), [
            ['say', 'Old Minute', "...Time doesn't wait, sonny. ...But it doesn't rush, either. It just goes... one tick at a time."],
            ['say', 'Old Minute', "...Tell your Hero of Homework: twenty-five little steps. Checked off, one by one. ...That's how anything big gets done."],
            ['quest', 'ticktock'],
            ['narrate', 'New Study Challenge: Tick Tock! (ESC → Quests)'],
          ], [
            ['if', A => A.questReady('ticktock'), [['turnin', 'ticktock'], ['say', 'Old Minute', '...Twenty-five steps... Splendid... Tick by tick, a whole mountain moved.']], [
              ['say', 'Old Minute', A => (A.questDone('ticktock') ? '...Tick... tock... Lovely sound, isn\'t it?...' : `...Homework steps so far: ${Math.min(25, A.stat('steps_done'))} of 25... one tick at a time...`)],
            ]],
          ]],
        ]],
      ]],
    ]],
  ],
  clock_ticking: [['say', 'Stopped Clock', "Tick... tock... tick... tock... (It's running again. It sounds very pleased about it.)"]],
  ...Object.fromEntries(CLOCKS.map(id => [id, [
    ['sfx', 'tock'],
    ['flag', `wound_${id}`],
    ['sfx', 'chime'],
    ['narrate', A => `You give the old clock a good wind. Tick... tock... It's running again! (${wound(A)} of 4)`],
    ['if', A => !A.questKnown('clocks'), [['narrate', "Someone on the moor would probably love to hear that sound. A very old clock, maybe."]]],
  ]])),

  dusk_lobby: [
    ['say', 'Count Dusk', "(His voice echoes down from somewhere above.) You actually came IN? ...I didn't tidy up. I was going to. Later."],
    ['say', 'Tick', 'HEY! HEY YOU! The candle! Up here! In the cage! RING RING RING! Get me OUT of here!'],
  ],
  tick_caged: [
    ['say', 'Tick', "The bells! Ring them in the right order and this cage pops open. Count Dusk hums his door chime ALL DAY. It's on the brass plate by the bells."],
    ['say', 'Tick', "Hurry! I've been in here since... since... nobody knows! He stopped the clocks!"],
  ],
  tick_cage: [
    ['wait', 0.3],
    ['sfx', 'chime'],
    ['narrate', 'DING, DONG, DANG! The cage door springs open!'],
    ['say', 'Tick', "FREEDOM! RING-A-DING-DING! You have NO idea how long I was in there!"],
    ['say', 'Tick', "...Actually, nobody does. Count Dusk stopped every clock in Lumenfold. It's been Later O'Clock for weeks."],
    ['say', 'Tick', "I'm Tick! I'm an alarm clock. I tell folks when it's time to START. Count Dusk hates that, so he stuffed me in a birdcage."],
    ['say', 'Tick', 'He even shook my gears loose. FIVE of them! They rolled all over the moor and the tower. I feel... loose.'],
    ['say', 'Tick', "You're going up to stop him? Take me with you! I can stop time. Well. For a few seconds. It's a long story. It involves a sneeze."],
    ['partner', 'tick'],
    ['narrate', 'Tick joined your party! In battle, Tick rings enemies, sets off an Alarm, and can Rewind a bad turn. In the field, press C to stop time for a few seconds.'],
    ['quest', 'gears'],
    ['tip', 'Press C: Time Stop! Pendulums, moving platforms and enemies freeze for a few seconds. Try it on the big pendulum by the stairs.', 12],
  ],
  gears_done: [
    ['say', 'Tick', "THAT'S IT! THE FIFTH GEAR! I'm all wound up again! The good kind of wound up!"],
    ['turnin', 'gears'],
    ['say', 'Tick', "Here, this is for you. Now you'll always be first. Like a good alarm. RING!"],
  ],
  wyrm_fight: [
    ['say', 'The Scrollwyrm', 'just one more... just one more... just ONE more...'],
    ['cut', 'boss_wake'],
    ['say', 'Tick', "That's the Scrollwyrm! It's been saying 'one more' since lunch. LAST MONTH'S lunch!"],
    ['say', 'The Scrollwyrm', "Oh! New viewers! Stay a while. Stay FOREVER. There's always something next..."],
    ['say', 'Tick', "Don't look at the shiny stuff, Wick! My Alarm can snap it out of it!"],
    ['battle', ['scrollwyrm'], { boss: true }],
    ['say', 'The Scrollwyrm', '...wait. What time is it? How long have I been scrolling?'],
    ['say', 'Tick', 'About a hundred hours, buddy.'],
    ['say', 'The Scrollwyrm', "A HUNDRED? I was only going to watch ONE... and I don't even remember any of it."],
    ['say', 'The Scrollwyrm', 'This was stuck at the very bottom of my feed. I never scrolled far enough to see it.'],
    ['shard', 4],
    ['flag', 'wyrm_down'],
    ['cut', 'dusk_in'],
    ['say', 'Count Dusk', "FOUR?! You put down the scroll? NOBODY puts down the scroll!"],
    ['say', 'Count Dusk', "Fine. Come up to the top, if you dare. I'll be waiting. I am VERY good at waiting."],
    ['cut', 'dusk_out'],
    ['say', 'Tick', "One more floor: the Dim Stair. Every trick you know, Wick, you'll need ALL of them. Good thing you have friends!"],
  ],
  wyrm_after: [['say', 'The Scrollwyrm', "I set a timer for my scrolling now. Tick helped. It's VERY loud. ...I went outside! It's so big out there."]],
  dusk_fight: [
    ['say', 'Count Dusk', 'So. The little candle made it all the way to the top. How... punctual.'],
    ['say', 'Count Dusk', "Do you know what I am, candle-boy? I am the Dusk. The end of the day. The part where everyone finally stops."],
    ['say', 'Count Dusk', "I only ever wanted folks to REST. But they never stopped! So I gave them LATER. Later is a rest that never has to end!"],
    ['say', 'Tick', "That's not rest! That's just waiting, with extra guilt!"],
    ['say', 'Count Dusk', "SILENCE, ALARM CLOCK! Enough talk. Let's settle this... NOW. ...Ugh. I hate that word."],
    ['battle', ['duskboss'], { boss: true, music: 'finale' }],
    ['say', 'Count Dusk', '...no... NO! Later ALWAYS wins! Everybody always says "later"...'],
    ['flag', 'moth_top'],
    ['sfx', 'door'],
    ['say', 'Mothwick', 'Not everybody. Not anymore, old friend.'],
    ['say', 'Count Dusk', '...Mothwick? You flew all the way up here? With those little wings?'],
    ['say', 'Mothwick', "Rest is a good thing, Dusk. Folks NEED rest. But real rest is something you choose, on purpose, when you need it. 'Later' is just hiding from the thing. It never feels like rest."],
    ['say', 'Mothwick', "Lumenfold doesn't need an endless night. It needs a dusk. A real one, the kind that comes at the end of a good day."],
    ['say', 'Count Dusk', "...The end of a good day. I used to be that. Before I got so tired of waiting for everyone."],
    ['say', 'Count Dusk', "Here. The last shard. Take it before I change my mind. ...I won't. I'm done putting things off. Starting... now."],
    ['shard', 5],
    ['flag', 'ch4_done'],
    ['cut', 'clocks_start'],
    ['narrate', 'TICK. TOCK. All across Lumenfold, every stopped clock starts ticking again.'],
    ['say', 'Tick', "THEY'RE RUNNING! ALL OF THEM! It's not Later O'Clock anymore! RING-A-DING-DING-DING!"],
    ['card', 'Chapter 4 complete!', 'All five Lumen Shards are found'],
    ['goto', 'pro_1', 1350],
  ],
  moth_top: [['say', 'Mothwick', "Let's go home, Wick. The Great Lantern is waiting."]],
  dusk_after: [['say', 'Count Dusk', "...I'll see you in town. I'm moving in. Someone has to make sure everyone gets a good night's sleep. ON TIME."]],
  finale_town: [
    ['cut', 'relight'],
    ['narrate', 'Five Lumen Shards click into place. The Great Lantern blazes brighter than anyone in Lumen Town has ever seen.'],
    ['say', 'Lampkin', "IT'S SO BRIGHT! I can see my whole to-do list! ...I'm going to start it. Right now. Okay, right after the cheering."],
    ['say', 'Moss', 'blorp! we did it! can we celebrate with snacks? i think we should celebrate with snacks.'],
    ['say', 'Hoot', 'Hoo! A most satisfying conclusion. I shall write it all down. Twice, for safety.'],
    ['say', 'Pebble', '...good job, wick. ...i wrote a poem about it. it is about rocks. and you.'],
    ['say', 'Ember', "ONE THING AT A TIME, AND WE DID ALL OF IT! ...wait. That's still one thing at a time. HUH!"],
    ['say', 'Tick', "RING-A-DING! It's NOW O'Clock, everybody!"],
    ['say', 'Mothwick', 'Wick, you did it. And so did the Hero of Homework, out there somewhere, one focused minute at a time.'],
    ['say', 'Mothwick', focusLine],
    ['say', 'Mothwick', "The Gloom will always try to creep back. 'Later' never gives up for good. But now we know how to beat it: start small, start now, and rest when you need to. On purpose."],
    ['card', 'THE END', 'Thank you for playing, Hero of Homework!'],
    ['narrate', "...but the adventure isn't over! Side quests, secrets and Study Challenges are still out there. And Count Dusk has moved into Lumen Town. (He's trying his best.)"],
    ['flag', 'ending_seen'],
  ],
  dusk_town: [['say', 'Count Dusk', pickLine([
    'Evening, candle. Did you do some good work today? Then rest. Properly. That is an order. A NICE order.',
    "I'm practicing 'now'. Now I'm reading. Now I'm napping. The napping is going extremely well.",
    "I made a to-do list. Tick keeps ringing at me about it. I've done TWO things! Two!",
    "Dusk isn't the end of the story, you know. It's just the part where you put your feet up after a good day.",
    "Mothwick says I'm 'the good kind of dusk' now. I had a little cry about it. On purpose. It was very restful.",
  ])]],
};

// ---------------------------------------------------------------- hooking it into the rest of Lumenfold
// (data.js runs this after the big fields are deepened)
export function patchTower(ROOMS, SCRIPTS, AREAS) {
  const town = ROOMS.pro_1;
  town.triggers.push(
    { id: 'ch4_call', x: 0, script: 'ch4_call', once: true, when: A => A.flag('ch3_done') },
    { id: 'finale', x: 0, script: 'finale_town', once: true, when: A => A.flag('ch4_done') },
  );
  town.npcs.push({ id: 'dusk_town', x: 1560, z: 700, kind: 'dusk', name: 'Count Dusk', talk: 'dusk_town', show: A => A.flag('ending_seen'), opts: { scale: 1.1 } });
  // the Lantern Path starts at the far back of the North Trail
  const trail = ROOMS.mtn_1;
  (trail.doors = trail.doors || []).push({ x: 1100, z: 2570, to: 'dusk_1', toX: 140, label: 'Lantern Path', need: 'ch4_open',
    needText: "A faint path leads north into the gloom, toward a crooked tower. It's far too dark to follow. (It opens in Chapter 4, once Ember Peak is calm.)" });
  (trail.signs = trail.signs || []).push({ x: 1180, z: 2450, text: "North: the Midnight Moor. (Nobody goes there. It's always nearly bedtime.)" });
  // Lampkin has a line for every shard; now there's one for all five
  SCRIPTS.folk_town = [['if', A => A.shards >= 5, [['say', 'Lampkin', 'All five shards! The Great Lantern is SO bright. I finished my whole to-do list! Then I made a new one. For fun!']], SCRIPTS.folk_town]];
  // Chapter 3's last card used to say the tower was coming in an update
  for (const cmd of SCRIPTS.cindermaw_fight) if (cmd[0] === 'card' && cmd[1] === 'Chapter 3 complete!') cmd[2] = 'The Great Lantern is humming...';
  Object.assign(AREAS.tower, { start: 'dusk_1', x: 300, music: 'tower' });
  delete AREAS.tower.soon;
}
