// How Chapter 4 plays (its rooms and story are in tower.js). TOWER_FIELD goes onto the Adventure: Tick's Time Stop,
// the pendulums, Tick's birdcage, the lost gears and the chapter's cutscenes. TOWER_BATTLE goes onto the Battle: Tick's
// moves and his Countdown team attack, the tower's creatures, the Scrollwyrm and Count Dusk.
import { INK, glowDot, starPath } from '../art.js';
import { drawPendulum, drawCage } from '../art4.js';
import { sfx } from '../audio.js';
import { TOWER_PARTNERS } from './tower.js';

const W = 960, H = 540, FLOOR = 452, TAU = Math.PI * 2;
const lerp = (a, b, p) => a + (b - a) * p;
const TIME_STOP = 4;          // seconds the world stays frozen
const TIME_STOP_REST = 1.5;   // and how long Tick needs to catch his breath after

// ---------------------------------------------------------------- in the field
export const TOWER_FIELD = {
  // The world clock. Moving platforms, steam vents and pendulums all run on it, so Time Stop can hold them still.
  towerUpdate(dt) {
    this.worldT = this.worldT || 0;
    if (this.timeStop > 0) {
      const before = Math.ceil(this.timeStop);
      this.timeStop = Math.max(0, this.timeStop - dt);
      if (this.timeStop === 0) { sfx('chime'); this.timeRest = TIME_STOP_REST; }
      else if (Math.ceil(this.timeStop) < before) sfx('tick');
    } else {
      this.worldT += dt;
      if (this.timeRest > 0) this.timeRest -= dt;
    }
    if (this.bonkT > 0) this.bonkT -= dt;
    if (this.room && this.room.pendulums && this.mode === 'explore' && this.p) this.pendulumHits();
  },

  timeStopStart() {
    if (this.timeStop > 0) return;
    if (this.timeRest > 0) { this.float('Tick: Phew... one sec!', this.p.x, this.p.y - 100, '#ffd23f'); return; }
    this.timeStop = TIME_STOP;
    this.partnerSq = 0.55;
    sfx('alert'); sfx('tock');
    this.float('TIME STOP!', this.p.x, this.p.y - 100, '#c8dcff');
  },

  // where a pendulum's bob is right now (and which way it's swinging)
  pendulum(p) {
    const w = TAU / (p.period || 2), ph = (this.worldT || 0) * w + (p.phase || 0);
    const a = (p.amp ?? 0.9) * Math.sin(ph), da = (p.amp ?? 0.9) * Math.cos(ph) * w;
    return { bx: p.x + Math.sin(a) * p.len, by: p.top + Math.cos(a) * p.len, vx: Math.cos(a) * p.len * da, r: p.r || 30 };
  },

  // a swinging pendulum knocks Wick flying (a frozen one is harmless)
  pendulumHits() {
    if (this.timeStop > 0 || this.bonkT > 0) return;
    const P = this.p;
    for (const p of this.room.pendulums) {
      const { bx, by, vx, r } = this.pendulum(p);
      const dx = P.x - bx, dy = (P.y - P.h / 2) - by;
      if (dx * dx + dy * dy > (r + 16) ** 2) continue;
      const dir = Math.abs(vx) > 40 ? Math.sign(vx) : Math.sign(dx) || 1;
      P.vx = dir * 640; P.vy = -430; P.onGround = false; P.cut = true;
      if (P.rolled) { P.rolled = false; P.h = 58; }
      this.bonkT = 0.6;
      this.cut.shake = 0.3;
      sfx('thud'); sfx('block');
      this.float('BONG!', P.x, P.y - 90, '#ffd23f');
      if (this.s.partner === 'tick' && !this.timeTipped) { this.timeTipped = true; this.tip('Tick: Press C and I\'ll stop time! Then just walk past.', 5); }
      return;
    }
  },

  // pendulums and cages, drawn in the far-to-near list with everything else
  drawTowerList(c, V, t, add, cut) {
    const R = this.room;
    const frozen = this.timeStop > 0;
    for (const p of R.pendulums || []) {
      const z = p.z ?? 120;
      cut(p.x, p.top + p.len, z, 0, () => {
        const { bx, by, r } = this.pendulum(p);
        drawPendulum(c, 0, -p.len, bx - p.x, by - p.top - p.len, r, frozen);
      }, p.len + 40);
    }
    for (const g of R.cages || []) cut(g.x, g.y, g.z ?? 140, 0, () => drawCage(c, 0, 0, this.flag(g.flag), t), 520);
  },

  // the frozen-time look: a cool tint, and Tick's countdown in the corner
  drawTimeStop(c) {
    if (!(this.timeStop > 0)) return;
    const k = Math.min(1, this.timeStop / 0.4, (TIME_STOP - this.timeStop) / 0.25 + 0.2);
    c.save();
    c.globalCompositeOperation = 'saturation'; c.fillStyle = `rgba(128,128,128,${0.75 * k})`; c.fillRect(0, 0, W, H);
    c.globalCompositeOperation = 'source-over';
    c.fillStyle = `rgba(150,180,255,${0.16 * k})`; c.fillRect(0, 0, W, H);
    // (under the minimap, when there is one)
    const cx = W - 70, cy = this.miniRect ? this.miniRect[1] + this.miniRect[3] + 40 : 110, left = this.timeStop / TIME_STOP;
    c.fillStyle = 'rgba(20,16,40,0.6)'; c.beginPath(); c.arc(cx, cy, 30, 0, TAU); c.fill();
    c.fillStyle = 'rgba(200,220,255,0.9)'; c.beginPath(); c.moveTo(cx, cy); c.arc(cx, cy, 26, -Math.PI / 2, -Math.PI / 2 + TAU * left); c.closePath(); c.fill();
    c.strokeStyle = INK; c.lineWidth = 3; c.beginPath(); c.arc(cx, cy, 30, 0, TAU); c.stroke();
    c.font = 'bold 20px Fredoka, sans-serif'; c.textAlign = 'center'; c.lineWidth = 4; c.strokeStyle = INK;
    c.strokeText(String(Math.ceil(this.timeStop)), cx, cy + 7); c.fillStyle = '#fffaf0'; c.fillText(String(Math.ceil(this.timeStop)), cx, cy + 7);
    c.restore();
  },

  // ---------------------------------------------------------------- Tick's lost gears
  async gearPickedUp(it) {
    sfx('chime');
    const n = this.collectedCount('gear');
    this.float(`Tick's gear! (${n}/5)`, it.x, it.y - 50, '#ffd23f', it.z);
    if (!this.questKnown('gears')) { this.tip("A little brass gear, still warm. Somebody in Count Dusk's Tower must be missing it.", 5); return; }
    if (n >= 5 && this.questActive('gears')) await this.runScript('gears_done');
  },

  // ---------------------------------------------------------------- cutscenes ('cut' in a script)
  // the Great Lantern hums with three shards, and throws a beam of light away to the north
  async cut_beam() {
    while (this.fadeA > 0.05) await this.wait(0.05);   // (this can start while the screen is still fading in)
    this.cut.beam = this.t;
    sfx('flare'); sfx('chime');
    this.cut.shake = 0.4;
    await this.wait(1.8);
  },
  // all five shards: the Great Lantern blazes
  async cut_relight() {
    while (this.fadeA > 0.05) await this.wait(0.05);
    this.cut.townLit = true;
    this.cut.flash = 1;
    this.cut.beam = this.t;
    sfx('fanfare');
    const lantern = (this.room.props || []).find(p => p.kind === 'lantern');
    const x = lantern ? lantern.x : this.p.x, y = 260;
    for (let i = 0; i < 60; i++) {
      const a = Math.random() * TAU, sp = 200 + Math.random() * 500;
      this.parts.push({ x, y, z: lantern ? lantern.z ?? 0 : this.p.z, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 200, life: 1.6, c: ['#ffe066', '#ff9ab0', '#9fe6ff', '#b49cff', '#8be07a'][i % 5], g: 420, star: i % 3 === 0 });
    }
    await this.wait(1.6);
  },
  // the stopped clocks of Lumenfold start ticking again
  async cut_clocks_start() {
    this.cut.flash = 0.8;
    for (let i = 0; i < 4; i++) { sfx(i % 2 ? 'tock' : 'tick'); await this.wait(0.32); }
    sfx('chime');
    await this.wait(0.5);
  },

  // The beam of light out of the Great Lantern, shooting away across the sky to Count Dusk's Tower on the northern
  // horizon (drawn over the town for a few seconds; from up the street, the Lantern itself is behind you).
  drawBeam(c, V) {
    if (this.cut.beam == null) return;
    const age = this.t - this.cut.beam;
    if (age > 3.4) { this.cut.beam = null; return; }
    const lantern = (this.room.props || []).find(p => p.kind === 'lantern');
    const camX = Math.round(this.camX);
    let x0 = this.p ? V.x(this.p.x, this.p.z) - camX : W / 2;
    if (lantern) { const z = lantern.z ?? 0; if (z > V.camZ - 200) x0 = V.x(lantern.x, z) - camX; }
    x0 = Math.max(60, Math.min(W - 60, x0));
    const x1 = 480 - camX * 0.02, y1 = 150;
    const a = Math.min(1, age / 0.35) * Math.min(1, (3.4 - age) / 0.9);
    const reach = Math.min(1, age / 0.6), xe = lerp(x0, x1, reach), ye = lerp(H + 20, y1, reach);
    const g = c.createLinearGradient(x0, H, xe, ye);
    g.addColorStop(0, `rgba(255,236,170,${0.8 * a})`); g.addColorStop(1, `rgba(255,236,170,${0.25 * a})`);
    c.fillStyle = g;
    c.beginPath(); c.moveTo(x0 - 70, H + 20); c.lineTo(x0 + 70, H + 20); c.lineTo(xe + 10, ye); c.lineTo(xe - 10, ye); c.closePath(); c.fill();
    glowDot(c, xe, ye, 90, '255,236,170', 0.6 * a);
    glowDot(c, x0, H, 200, '255,230,150', 0.35 * a);
  },
};

// ---------------------------------------------------------------- in battle
const TICK_MOVES = TOWER_PARTNERS.tick.moves.map(m => m.id);

export const TOWER_BATTLE = {
  isTickMove(v) { return TICK_MOVES.includes(v); },
  canRewind() { const L = this.lostHp; return !!L && (L.hero > 0 || L.partner > 0); },
  sleepHero(T) {
    if (this.badge('snooze_proof')) { this.float('Snooze Proof!', T.x, T.y - 120, '#9fe6ff'); return false; }
    if (T === this.hero && this.badge('sweet_dreams')) { this.float('Well rested!', T.x, T.y - 120, '#d8d4f6'); return false; }
    T.status.sleep = 1;
    this.say(`${T.name} fell asleep!`);
    return true;
  },

  async tickAction(v) {
    const P = this.partner, s = this.A.s;
    const cost = (TOWER_PARTNERS.tick.moves.find(m => m.id === v) || {}).fp || 0;
    if (v === 'ring') {
      const t = await this.pickTarget(() => true, 'Ring Bash');
      if (t === undefined) { this.say('Nothing to ring right now!'); return false; }
      if (!t) return false;
      P.state = 'ring';
      await this.partnerHits(P, t);
      P.state = 'idle';
    } else if (v === 'alarm') {
      s.hero.fp -= cost;
      this.say('ALARM! RING-A-DING-DING!', 2);
      const impact = this.now() + 0.6;
      this.arm(impact, 'press', 'space', P);
      P.state = 'ring';
      sfx('alert');
      await this.anim(0.6, p => { P.y = FLOOR - Math.sin(p * Math.PI) * 36; });
      P.y = FLOOR;
      const ok = await this.judge(impact), perfect = this.perfectBonus() > 0;
      if (ok) this.rate(1, P);
      this.shake = 6;
      this.fx.push({ kind: 'ring', x: P.x, y: FLOOR, t0: this.t });
      for (const e of this.enemies) {
        if (!e.alive) continue;
        if (e.kind === 'duskboss') { this.float('Unimpressed.', e.x, e.y - this.eh(e) - 20, '#c8c0d8'); continue; }
        // (once startled, an enemy's ears are still ringing for a few rounds: the alarm can't startle it again yet)
        if (e.status.alarmed > 0) { this.float('Still ringing... ignored it!', e.x, e.y - this.eh(e) - 30, '#c8c0d8'); continue; }
        const chance = e.kind === 'scrollwyrm' ? 1 : e.boss ? 0 : perfect ? 0.85 : ok ? 0.6 : 0.25;
        if (Math.random() < chance) {
          e.status.dazed = 1;
          e.status.alarmed = e.boss ? 4 : 3;
          this.float(e.kind === 'scrollwyrm' ? 'SNAPPED OUT OF IT!' : 'STARTLED!', e.x, e.y - this.eh(e) - 30, '#ffe066');
        } else this.float('Shrugged it off', e.x, e.y - this.eh(e) - 30, '#c8c0d8');
      }
      await this.wait(0.7);
      P.state = 'idle';
    } else if (v === 'rewind') {
      s.hero.fp -= cost;
      const L = this.lostHp || { hero: 0, partner: 0 };
      this.say('Rewind! Tick spins his hands backwards...', 2);
      sfx('unfold');
      const H = this.hero;
      await this.anim(0.9, p => {
        for (const a of [H, P]) if (Math.random() < 0.5) this.parts.push({ x: a.x + Math.cos(p * 20) * 40, y: a.y - 50 + Math.sin(p * 20) * 40, vx: 0, vy: 0, life: 0.5, c: '#c8dcff', g: 0, star: true });
      });
      if (L.hero > 0) { H.hp = Math.min(H.maxHp, H.hp + L.hero); this.float(`+${L.hero} ♥`, H.x, H.y - 100, '#ff9ab0'); }
      if (L.partner > 0) { P.hp = Math.min(P.maxHp, P.hp + L.partner); P.alive = true; this.float(`+${L.partner} ♥`, P.x, P.y - 100, '#ff9ab0'); }
      this.lostHp = { hero: 0, partner: 0 };
      sfx('chime');
      await this.wait(0.5);
    }
    this.layout();
    return true;
  },

  // Countdown: Wick and Tick wind a giant alarm clock in turns (SPACE, X, SPACE...), faster each time, then it RINGS
  // and every enemy takes 1 damage, plus 1 for every two winds.
  async countdown(lv) {
    const H = this.hero, P = this.partner;
    if (!this.enemies.some(e => e.alive)) return false;
    await Promise.all([this.moveTo(H, 380, 0.35), this.moveTo(P, 200, 0.35)]);
    H.flip = -1; P.flip = 1;
    const clock = { x: 290, y: FLOOR, wind: 0, spin: 0, pop: 0 };
    this.bigClock = clock;
    sfx('block');
    await this.anim(0.3, p => { clock.pop = p; });
    const maxWinds = 3 + lv;
    let winds = 0, perfects = 0, dur = 0.58, who = H;
    for (;;) {
      const key = who === H ? 'space' : 'x';
      const s0 = clock.spin;
      const ok = await this.beat(who, key, dur, p => { clock.spin = s0 + p * 0.25; who.sq = 1 - 0.08 * Math.sin(p * Math.PI); });
      who.sq = 1;
      if (!ok) break;
      winds++;
      perfects += this.perfectBonus();
      clock.wind = winds;
      this.rate(winds, who);
      sfx('tick');
      if (winds >= maxWinds) break;
      who = who === H ? P : H;
      dur = Math.max(0.3, dur - 0.045);
    }
    if (!winds) {
      this.bigClock = null;
      await this.fizzle('The key slipped!');
    } else {
      this.float(winds >= maxWinds ? 'MAX WIND!' : `${winds} winds!`, 290, 200, '#ffd23f');
      clock.ringing = true;
      sfx('alert'); sfx('crunch');
      this.shake = 6 + winds;
      for (let i = 0; i < 3; i++) this.fx.push({ kind: 'ring', x: clock.x, y: FLOOR, t0: this.t + i * 0.12 });
      await this.wait(0.35);
      const dmg = 1 + Math.floor((winds + perfects) / 2);   // (a PERFECT wind counts twice)
      for (const e of [...this.enemies]) if (e.alive) this.hit(e, dmg, { by: 'hero', kind: 'team', ranged: true, reveal: true });
      await this.wait(0.6);
      this.bigClock = null;
    }
    await Promise.all([this.moveTo(H, H.hx, 0.35), this.moveTo(P, P.hx, 0.35)]);
    return true;
  },

  // ---------------------------------------------------------------- the tower's creatures
  async notiflyTurn(e) {
    const flies = this.enemies.filter(x => x.alive && x.kind === 'notifly').length;
    const all = this.enemies.filter(x => x.alive).length;
    if (flies < 3 && all < 5 && Math.random() < 0.5) {
      this.say(`${e.name}: DING! DING! Another notification!`, 1.8);
      sfx('alert');
      await this.wait(0.4);
      const m = this.addEnemy('notifly');
      m.x = e.x; m.y = -60;
      this.layout();
      await this.anim(0.5, p => { m.x = lerp(m.x, m.hx, p); m.y = lerp(-60, m.baseY, p); });
      m.y = m.baseY;
      return;
    }
    await this.attack(e, this.pickVictim(), e.atk);
  },

  async snoozerTurn(e) {
    e.ai = e.ai || { n: 0 };
    if (++e.ai.n % 2 === 1) {
      this.say(`${e.name} rings a sleepy lullaby... Guard it or doze off!`, 2.2);
      const T = this.hero, impact = this.now() + 0.85;
      this.arm(impact, 'guard');
      sfx('chime');
      for (let i = 0; i < 10; i++) this.parts.push({ x: e.x - 30, y: e.y - 40 - i * 4, vx: (T.x - e.x) * 1.1 + (Math.random() - 0.5) * 60, vy: -20 + (Math.random() - 0.5) * 40, life: 0.85, c: '#c8d4ff', g: 0, star: true });
      await this.wait(0.85);
      const r = await this.resolveGuard(e, T, 1, impact, { noContact: true });
      if ((r === 'hit' || r === 'none') && T.hp > 0) this.sleepHero(T);
      else this.say('You shook off the lullaby!');
      await this.wait(0.6);
      return;
    }
    await this.attack(e, this.pickVictim(), e.atk);
  },

  async scrollbugTurn(e) {
    if (Math.random() < 0.5) {
      this.say(`${e.name} wiggles an endless feed in your face!`, 1.8);
      const r = await this.attack(e, this.hero, e.atk);
      if ((r === 'hit' || r === 'none') && this.hero.hp > 0) {
        this.hero.status.distracted = 2;
        this.say('Wick got distracted! Timing is harder for a bit.', 2.2);
        await this.wait(0.6);
      }
      return;
    }
    await this.attack(e, this.pickVictim(), e.atk);
  },

  // the sand runs out over three turns, then TIME'S UP hits everyone, and it flips itself over to start again
  async sandglassTurn(e) {
    e.fuse--;
    if (e.fuse > 0) {
      this.say(`${e.name}: the sand is running out... ${e.fuse}!`, 1.6);
      sfx('tick');
      await this.anim(0.6, p => { e.x = e.hx + Math.sin(p * 40) * (4 - e.fuse); });
      e.x = e.hx;
      return;
    }
    this.say(`${e.name}: TIME'S UP!`, 2);
    sfx('crunch');
    this.shake = 10;
    for (let i = 0; i < 26; i++) this.parts.push({ x: e.x, y: e.y - 30, vx: (Math.random() - 0.5) * 700, vy: -Math.random() * 500, life: 0.9, c: i % 2 ? '#f2c14e' : '#fff3c4' });
    for (const T of [this.hero, this.partner]) {
      if (!T || !T.alive || this.hero.hp <= 0) continue;
      const impact = this.now() + 0.45;
      this.arm(impact, 'guard');
      await this.wait(0.45);
      await this.resolveGuard(e, T, 3, impact, { noContact: true });
      await this.wait(0.2);
    }
    if (!e.alive) return;
    e.fuse = 3;
    this.float('It flipped itself over!', e.x, e.y - 80, '#ffe066');
    await this.anim(0.4, p => { e.rot = Math.sin(p * Math.PI) * 0.6; });
    e.rot = 0;
  },

  // ---------------------------------------------------------------- the Scrollwyrm
  // "Just one more": if a whole round goes by and nobody hurt it, it heals. At half HP it's 3 AM and it moves twice a turn.
  async scrollwyrmTurn(e) {
    e.ai = e.ai || { n: 0, late: false, hp: e.hp };
    const n = ++e.ai.n;
    if (n > 1 && e.hp >= e.ai.hp && e.hp < e.maxHp) {
      const h = Math.min(4, e.maxHp - e.hp);
      e.hp += h;
      this.float(`+${h}`, e.x, e.y - this.eh(e) - 20, '#9cff8a');
      this.say('The Scrollwyrm: Just one more... (Nobody hurt it all round, so it watched another one and healed!)', 2.8);
      sfx('chime');
      await this.wait(1);
      e.ai.hp = e.hp;
      return;
    }
    if (e.hp <= e.maxHp / 2 && !e.ai.late) {
      e.ai.late = true;
      this.say("The Scrollwyrm: IT'S 3 AM AND I'M WIDE AWAKE! (It moves twice a turn now!)", 2.8);
      this.shake = 8;
      sfx('alert');
      await this.anim(0.9, p => { e.x = e.hx + Math.sin(p * 40) * 5; });
      e.x = e.hx;
      e.ai.hp = e.hp;
      return;
    }
    for (let i = 0; i < (e.ai.late ? 2 : 1); i++) {
      if (this.hero.hp <= 0 || !e.alive) break;
      await this.scrollwyrmMove(e, n * 2 + i);
    }
    e.ai.hp = e.hp;
  },

  async scrollwyrmMove(e, k) {
    const bugs = this.enemies.filter(x => x.alive && !x.boss).length;
    const step = k % 3;
    if (step === 0 && bugs < 2) { await this.summon(e, 'scrollbug', 2 - bugs, 'The Scrollwyrm: UP NEXT... more Scrollbugs!'); return; }
    if (step === 1 && !(this.hero.status.dazzled > 0)) {
      this.say("The Scrollwyrm: INFINITE FEED! (It's so shiny you can't see the timing cues!)", 2.6);
      sfx('guard');
      for (let i = 0; i < 24; i++) this.parts.push({ x: this.hero.x + (Math.random() - 0.5) * 140, y: this.hero.y - 40 - Math.random() * 110, vx: (Math.random() - 0.5) * 80, vy: -30, life: 1.2, c: ['#7fd6ff', '#ff9ab0', '#ffe066', '#b49cff'][i % 4], g: 0, star: true });
      this.hero.status.dazzled = 2;
      await this.wait(1);
      return;
    }
    this.say('The Scrollwyrm: TAIL SWIPE!');
    for (const T of [this.hero, this.partner]) {
      if (!T || !T.alive || this.hero.hp <= 0 || !e.alive) continue;
      await this.attack(e, T, e.atk);
    }
  },

  // ---------------------------------------------------------------- Count Dusk
  // LATER! (postpones your turn), a trick from each of the Gloom's old champions, Cape Slash. At half HP the lights go
  // out; at a quarter he tries to stop time forever, and the Hero of Homework's light answers: the Lumen Beam.
  async duskTurn(e) {
    e.ai = e.ai || { n: 0, dark: false, beam: false, trick: -1 };
    const n = ++e.ai.n;
    if (e.hp <= e.maxHp * 0.25 && !e.ai.beam) { e.ai.beam = true; await this.lumenBeam(e); return; }
    if (e.hp <= e.maxHp / 2 && !e.ai.dark) {
      e.ai.dark = true;
      this.say("Count Dusk: LIGHTS OUT! Let's see how well you do things... in the DARK!", 2.8);
      sfx('crunch');
      this.shake = 6;
      await this.anim(1, p => { this.darkness = 0.7 * p; });
      return;
    }
    if (e.ai.dark && !e.ai.beam && Math.random() < 0.5 && !(this.hero.status.dazzled > 0)) {
      this.hero.status.dazzled = 1;
      this.float("Too dark to see the cues!", this.hero.x, this.hero.y - 130, '#c8c0d8');
    }
    const plan = ['later', 'trick', 'slash', 'trick', 'later', 'slash'];
    const m = plan[(n - 1) % plan.length];
    if (m === 'later') { await this.duskLater(e); return; }
    if (m === 'trick') { await this.duskTrick(e); return; }
    this.say('Count Dusk: CAPE SLASH!');
    await this.attack(e, this.pickVictim(), e.atk);
  },

  async duskLater(e) {
    this.say("Count Dusk: LATER! (Guard it, or Wick's next turn gets postponed!)", 2.4);
    const T = this.hero, impact = this.now() + 0.9;
    this.arm(impact, 'guard');
    const orb = { x: e.x - 40, y: e.y - 130 };
    this.duskOrb = orb;
    sfx('flare');
    await this.anim(0.9, p => { orb.x = lerp(e.x - 40, T.x, p); orb.y = lerp(e.y - 130, T.y - 50, p) - Math.sin(p * Math.PI) * 60; });
    this.duskOrb = null;
    const r = await this.resolveGuard(e, T, 1, impact, { noContact: true });
    if ((r === 'hit' || r === 'none') && T.hp > 0) { T.status.later = 1; this.say("Wick's next turn is postponed... until LATER!", 2.4); }
    else this.say('Guarded! Not later: NOW!', 1.8);
    await this.wait(0.6);
  },

  async duskTrick(e) {
    e.ai.trick = (e.ai.trick + 1) % 4;
    const k = e.ai.trick;
    const minions = this.enemies.filter(x => x.alive && !x.boss).length;
    if (k === 0) {
      this.say("Count Dusk: Five more minutes... SPORE SNOOZE! (Guard it!)", 2.4);
      const T = this.hero, impact = this.now() + 0.9;
      this.arm(impact, 'guard');
      for (let i = 0; i < 18; i++) this.parts.push({ x: T.x + (Math.random() - 0.5) * 90, y: T.y - 220 - Math.random() * 60, vx: 0, vy: 260, life: 0.9, c: '#e8d0ff', g: 0 });
      await this.wait(0.9);
      const r = await this.resolveGuard(e, T, 1, impact, { noContact: true });
      if ((r === 'hit' || r === 'none') && T.hp > 0) this.sleepHero(T); else this.say('You shook off the spores!');
      await this.wait(0.6);
    } else if (k === 1) {
      this.say("Count Dusk: It's not PERFECT! INK RAIN! (Guard every drop!)", 2.4);
      for (let i = 0; i < 3; i++) {
        if (this.hero.hp <= 0) break;
        const T = this.pickVictim(), dur = 0.56 - i * 0.04, impact = this.now() + dur;
        this.arm(impact, 'guard');
        const drop = { x: T.x + (Math.random() - 0.5) * 30, y: -30, ink: true };
        this.duskOrb = drop;
        await this.anim(dur, p => { drop.y = lerp(-30, T.y - 40, p * p); });
        this.duskOrb = null;
        this.shake = 4;
        await this.resolveGuard(e, T, 1, impact, { noContact: true });
        await this.wait(0.1);
      }
      if (this.hero.hp > 0) { this.hero.status.inked = 2; this.say('Wick got inked! Timing is harder for a bit.', 2); await this.wait(0.5); }
    } else if (k === 2 && minions < 3) {
      await this.summon(e, 'cinderling', Math.min(2, 3 - minions), 'Count Dusk: Do EVERYTHING at once! Cinderlings, attack!');
    } else if (k === 3 && minions < 3) {
      await this.summon(e, 'scrollbug', Math.min(2, 3 - minions), 'Count Dusk: Just ONE more video... Scrollbugs!');
    } else {
      this.say('Count Dusk: CAPE SLASH!');
      await this.attack(e, this.pickVictim(), e.atk);
    }
  },

  async lumenBeam(e) {
    this.say('Count Dusk: ENOUGH! If you will not wait, then ALL of time will stop! MIDNIGHT, FOREVER!', 3);
    sfx('crunch');
    this.shake = 10;
    await this.anim(1.2, p => { this.darkness = 0.7 + 0.5 * p; });
    await this.wait(0.6);
    const hrs = this.A.stat('focus_seconds') / 3600;
    this.say(hrs >= 1 ? `...But far away, a light is shining. The Hero of Homework! ${hrs.toFixed(1)} hours of focus pour into Wick's flame!`
      : "...But far away, a light is shining. The Hero of Homework is still working! Their focus pours into Wick's flame!", 3.6);
    sfx('fanfare');
    await this.anim(1.4, p => { this.darkness = 1.2 * (1 - p); this.glory = p; });
    this.darkness = 0;
    const H = this.hero, P = this.partner, sh = this.A.s.hero;
    H.hp = H.maxHp; sh.fp = sh.maxFp;
    this.float('FULLY HEALED!', H.x, H.y - 120, '#ffe066');
    if (P) { P.hp = P.maxHp; P.alive = true; }
    for (const k of ['sleep', 'later', 'inked', 'distracted', 'dazzled', 'smoke']) H.status[k] = 0;
    await this.wait(0.8);
    this.say('LUMEN BEAM! Hold SPACE, let go when the star lights up!', 99);
    const res = await this.holdCommand(H);
    this.msg = '';
    this.beam = { t0: this.t, to: e };
    sfx('flare'); sfx('crunch');
    this.shake = 14;
    await this.wait(0.45);
    this.hit(e, (res === 'ok' ? 12 : 9) + this.perfectBonus(), { by: 'hero', pierce: true, reveal: true });
    if (res === 'ok') this.rate(5);
    await this.wait(0.9);
    this.beam = null; this.glory = 0;
    if (e.alive) this.say('The light is back! Finish it!', 2.2);
  },

  // ---------------------------------------------------------------- extra drawing on the battle stage
  drawExtras(c, t) {
    // the giant alarm clock for Countdown
    const K = this.bigClock;
    if (K) {
      const s = 0.4 + 0.6 * Math.min(1, K.pop), shake = K.ringing ? Math.sin(t * 70) * 4 : 0;
      c.save(); c.translate(K.x + shake, K.y); c.scale(s, s);
      glowDot(c, 0, -90, 110, '255,214,120', 0.25 + 0.05 * K.wind);
      c.fillStyle = '#e8a93a'; c.strokeStyle = INK; c.lineWidth = 4;
      for (const sx of [-1, 1]) { c.beginPath(); c.arc(sx * 40, -150, 26, Math.PI, 0); c.closePath(); c.fill(); c.stroke(); }
      c.beginPath(); c.arc(0, -90, 62, 0, TAU); c.fill(); c.stroke();
      c.fillStyle = '#fffaf0'; c.beginPath(); c.arc(0, -90, 48, 0, TAU); c.fill(); c.stroke();
      c.strokeStyle = INK; c.lineCap = 'round';
      const a = K.spin * TAU;
      c.lineWidth = 6; c.beginPath(); c.moveTo(0, -90); c.lineTo(Math.sin(a) * 34, -90 - Math.cos(a) * 34); c.stroke();
      c.lineWidth = 4; c.beginPath(); c.moveTo(0, -90); c.lineTo(Math.sin(a / 12) * 22, -90 - Math.cos(a / 12) * 22); c.stroke();
      c.fillStyle = '#7a4f24'; c.fillRect(-6, -36, 12, 30); c.fillRect(-28, -10, 56, 10);
      c.font = 'bold 26px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillStyle = '#ffd23f'; c.lineWidth = 5; c.strokeStyle = INK;
      if (K.wind) { c.strokeText(`×${K.wind}`, 0, -170); c.fillText(`×${K.wind}`, 0, -170); }
      c.restore();
    }
    // Count Dusk's LATER clock and his ink drops
    const O = this.duskOrb;
    if (O) {
      if (O.ink) { c.fillStyle = '#2b2235'; c.beginPath(); c.ellipse(O.x, O.y, 10, 14, 0, 0, TAU); c.fill(); }
      else {
        glowDot(c, O.x, O.y, 46, '170,110,255', 0.6);
        c.fillStyle = '#e8dcff'; c.strokeStyle = '#3b2f6a'; c.lineWidth = 3;
        c.beginPath(); c.arc(O.x, O.y, 18, 0, TAU); c.fill(); c.stroke();
        c.lineCap = 'round'; c.beginPath(); c.moveTo(O.x, O.y); c.lineTo(O.x + Math.sin(t * 9) * 12, O.y - Math.cos(t * 9) * 12); c.stroke();
      }
    }
    // dazed enemies see stars
    for (const e of this.enemies) {
      if (!e.alive || !(e.status.dazed > 0)) continue;
      for (let i = 0; i < 3; i++) {
        const a = t * 4 + i * 2.1;
        c.fillStyle = '#ffe066'; c.beginPath(); starPath(c, e.x + Math.cos(a) * 22, e.y - this.eh(e) - 12 + Math.sin(a) * 6, 6, 2.6); c.fill();
      }
    }
    // Lights Out, and the Lumen Beam
    if (this.darkness > 0) {
      const hx = this.hero.x, hy = this.hero.y - 50;
      const g = c.createRadialGradient(hx, hy, 50, hx, hy, 420);
      g.addColorStop(0, 'rgba(8,4,20,0)'); g.addColorStop(1, `rgba(8,4,20,${Math.min(0.95, this.darkness)})`);
      c.fillStyle = g; c.fillRect(-200, -200, W + 400, H + 400);
    }
    if (this.glory > 0) { c.fillStyle = `rgba(255,236,170,${0.25 * this.glory})`; c.fillRect(-200, -200, W + 400, H + 400); }
    // (the Lumen Beam, or a thinner Lantern Beam: beam.w scales it)
    if (this.beam) {
      const k = Math.min(1, (this.t - this.beam.t0) / 0.3), x0 = this.hero.x + 20, y0 = this.hero.y - 60, x1 = this.beam.to.x, y1 = this.beam.to.y - this.eh(this.beam.to) * 0.5;
      const xe = lerp(x0, x1, k), ye = lerp(y0, y1, k), bw = this.beam.w || 1;
      c.lineCap = 'round';
      c.strokeStyle = 'rgba(255,236,170,0.55)'; c.lineWidth = 60 * bw; c.beginPath(); c.moveTo(x0, y0); c.lineTo(xe, ye); c.stroke();
      c.strokeStyle = 'rgba(255,255,240,0.95)'; c.lineWidth = 22 * bw; c.beginPath(); c.moveTo(x0, y0); c.lineTo(xe, ye); c.stroke();
      glowDot(c, xe, ye, 120 * bw, '255,236,170', 0.8);
    }
  },
};
