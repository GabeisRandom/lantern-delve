// The Paper Plains update: a wide-open meadow south of Lumen Town, the Hidden Grotto, the Sticker Shrine, 24 folks
// the Gloom Gale folded up and blew all over Lumenfold, 10 tears in the paper to patch with confetti, and stickers.
// data.js merges all of this into its tables; mechanics.js makes the stickers, crates, bombs and tears work.

// ---------------------------------------------------------------- stickers
// Peel them off the world (E), then stick them on outlines of the same shape (E).
export const STICKERS = {
  bridge: { name: 'Bridge Sticker', short: 'Bridge', icon: '🌉', price: 12, a: 'a Bridge Sticker', outline: 'a little plank bridge.',
    desc: 'Lays a plank bridge across a gap.', where: 'Peely sells them at the Paper Plains camp.', done: 'A plank bridge unfolds across the gap!' },
  stairs: { name: 'Stairs Sticker', short: 'Stairs', icon: '🪜', price: 12, a: 'a Stairs Sticker', outline: 'a staircase.',
    desc: 'Pops up a paper staircase you can walk right up.', where: 'Peely sells them at the Paper Plains camp.', done: 'Paper stairs pop up! Walk right up them.' },
  fan: { name: 'Fan Sticker', short: 'Fan', icon: '🌀', price: 18, a: 'a Fan Sticker', outline: 'a big fan.',
    desc: 'A big paper fan: it blows fog away and powers updrafts.', where: 'Peely sells them, and one is stuck to the big tree on Windmill Hill.', done: 'Whoosh! The fan blows the fog away.' },
  sprout: { name: 'Sprout Sticker', short: 'Sprout', icon: '🌱', price: 15, a: 'a Sprout Sticker', outline: 'a little sprout.',
    desc: 'Grows a giant flower you can stand on.', where: 'Peely sells them at the Paper Plains camp.', done: 'A giant flower shoots up! Jump onto it.' },
  key: { name: 'Key Sticker', short: 'Key', icon: '🗝️', a: 'a Key Sticker', outline: 'a key.',
    desc: 'Opens a sticker lock.', where: 'Rumor says one is hidden in a boarded-up cave in the Paper Plains.', done: 'Click! The sticker lock opens.' },
  sun: { name: 'Sun Sticker', short: 'Sun', icon: '☀️', a: 'a Sun Sticker', outline: 'a little sun.',
    desc: 'A little paper sun that lights up a dark room for good.', where: 'There must be one somewhere in the Sticker Shrine.', done: 'The little sun lights up the whole room!' },
};
export const SHOP_STICKERS = ['bridge', 'stairs', 'fan', 'sprout'];

// ---------------------------------------------------------------- the folded folks of Pinwheel Village
// Where each one landed (look: the shape they were folded into), what they say when unfolded, and in Lumen Town after.
const F = (id, name, room, x, z, look, opts, line, town, more = {}) => ({ id, name, room, x, z, look, opts, line, town, ...more });
export const FOLKS = [
  F('f_crinkle', 'Crinkle', 'plains', 420, 1950, 'crane', { color: '#ff9ab0', body: '#7a5a8a' },
    "I've been a crane for THREE DAYS. My neck hurts.", "Being unfolded is the best. I'm going to stretch EVERY morning from now on."),
  F('f_pip', 'Pip', 'plains', 1500, 300, 'ball', { color: '#ffd23f', body: '#5a7ac4' },
    'Crumpled up in a bush! How undignified!', 'Did you know a crumpled-up ball of paper is 100% scrunchier than a flat one? I do now.', { bush: 'bush_pl1' }),
  F('f_tuck', 'Tuck', 'plains', 1410, 760, 'boat', { color: '#5fc8f0', body: '#3b5a7b', hat: 'bucket' },
    'Ahoy! ...Sorry. Habit. I was a boat for a while.', 'I keep trying to float in puddles. Old habits.'),
  F('f_twirl', 'Twirl', 'plains', 3300, 3060, 'star', { color: '#b49cff', body: '#5a4fa8' },
    "I'm a star! ...Oh. I'm a person again. That's fine too.", 'Lumen Town is so bright at night. It reminds me of being a star. Twinkle twinkle.'),
  F('f_flutter', 'Flutter', 'plains', 4900, 2380, 'plane', { color: '#8be07a', body: '#3d6b4a', hat: 'feather' },
    'I flew all the way up here and crashed into a tree!', "Flying was fun until the landing part. I'm a walking person now. Walking is underrated."),
  F('f_pleat', 'Pleat', 'plains', 5900, 2850, 'frog', { color: '#7cc46a', body: '#6b8a3a' },
    'Ribbit! ...I mean. Thank you so much!', "Every now and then I still say 'ribbit'. Nobody has noticed. ...Ribbit."),
  F('f_dottie', 'Dottie', 'plains', 8600, 1000, 'star', { color: '#ffb347', body: '#8a3a2a', hat: 'straw' },
    'Oh, thank goodness. Being pointy all over was exhausting.', "The Mayor says we'll rebuild Pinwheel Village soon. Until then, Lumen Town is lovely!"),
  F('f_fogg', 'Fogg', 'plains', 6050, 700, 'ball', { color: '#c6bcdc', body: '#5a4a7a' },
    "I've been stuck in that fog for ages! I couldn't even see my own folds!", "I'm afraid of fog now. And mist. And steam. And soup, a little.", { behind: 'fog_gully' }),
  F('f_ridge', 'Ridge', 'plains', 6260, 1120, 'crane', { color: '#e0604a', body: '#5a4a7a' },
    'How did you get up here?! A crate? Genius!', "Pushing crates around to solve problems. That's my whole philosophy now.", { y: 280, behind: 'fog_gully' }),
  F('f_skye', 'Skye', 'plains', 7020, 2060, 'boat', { color: '#9fe6ff', body: '#4f72bf' },
    'A boat, stuck way up on a mesa. The Gale has a sense of humor.', 'I saw a giant flower grow out of nowhere. Then a candle jumped on it. Best day ever.', { y: 180 }),
  F('f_hopper', 'Hopper', 'plains', 8300, 330, 'frog', { color: '#5fae5c', body: '#3d6b4a' },
    'Is the Sticker Shrine still glued shut? Somebody should DO something!', "The Gloop Golem glued my hat to my head once. I don't wear hats anymore."),
  F('f_sprocket', 'Sprocket', 'plains', 1520, 2860, 'crane', { color: '#ffb347', body: '#5a4fa8' },
    "I've been walking in circles in this maze for a week. As a crane. Cranes are bad at mazes.", 'I can find my way out of any maze now. I just keep one wing on the left wall. ...Hand. One hand.'),
  F('f_rubble', 'Rubble', 'plains', 5000, 480, 'frog', { color: '#a49e94', body: '#5f5a52' },
    "These ruins are spooky! Did you know there's a vault? Three gold stones open it, apparently!", 'I used to think ruins were boring. Then I saw a vault. Now I think about vaults constantly.'),
  F('f_echo', 'Echo', 'plains', 8400, 2860, 'star', { color: '#ff9ab0', body: '#7a5a8a' },
    'Hello? Hello? ...Oh good, a real voice, not the cliffs talking back!', "The north cliffs echo everything you say. I said 'I'm lost' and they agreed with me. Rude."),
  F('f_bram', 'Bram', 'grotto_1', 1110, 40, 'ball', { color: '#a8743a', body: '#6e4a30' },
    "Thank you! It's very dark in here. And echo-y. Echo-y. Echo-y.", 'Caves are not for me. Too many echoes. Echoes. Echoes.'),
  F('f_washi', 'Washi', 'shrine_1', 1440, 220, 'crane', { color: '#c0392b', body: '#7a5a50' },
    'I was meditating as a crane. Very peaceful. Thank you anyway!', "The shrine has a saying: 'A sticker never forgets where it was stuck.' I think about it a lot."),
  F('f_gust', 'Gust', 'shrine_2', 930, 40, 'plane', { color: '#9fe6ff', body: '#3b5a7b' },
    'The updraft blew me up here and then STOPPED. Rude.', 'I miss the updraft. Wheee. ...That was it. Wheee.', { y: 180 }),
  F('f_kindle', 'Kindle', 'shrine_3', 1450, 210, 'star', { color: '#ffd23f', body: '#8a5a3c' },
    'Did something explode? Something DEFINITELY exploded. Thanks!', "BOOM! ...Sorry. I'm still a little jumpy from the Bomb Hall."),
  F('f_sprig', 'Sprig', 'fields_1', 1500, 60, 'frog', { color: '#8be07a', body: '#6b8a3a', hat: 'straw' },
    "Ah! Light! I've been in that bush since Tuesday!", 'Farmer Barley gave me a cookie for being brave. Being folded up is very brave, apparently.', { bush: 'bush_f2' }),
  F('f_nib', 'Nib', 'pro_2', 1350, 40, 'ball', { color: '#c46a8f', body: '#5a4a7a' },
    'Crumpled up in a bush on the Outskirts Path... I hope nobody saw.', 'If anyone asks, I was never a crumpled ball of paper. I was always this tall and dignified.', { bush: 'bush_p2' }),
  F('f_bobbin', 'Bobbin', 'lake_1', 2250, 215, 'boat', { color: '#4f9fd6', body: '#2f6fa8', hat: 'bucket' },
    'I floated across the WHOLE lake! Fisher Finn nearly caught me!', "Fisher Finn and I are friends now. He says he's glad he didn't catch me. Me too."),
  F('f_wicket', 'Wicket', 'pro_3', 980, 225, 'star', { color: '#ffe066', body: '#3b3350' },
    "Is this Mothwick's shed? I've been a star in his yard all night!", "Mothwick showed me his moth collection. It's just him. He's the collection."),
  F('f_burl', 'Burl', 'grove_1', 1950, 225, 'crane', { color: '#a8743a', body: '#5e3b24' },
    'The trees here grumble a LOT. Thank you for getting me out!', "I picked up grumbling from the grove trees. Grrrmble. It's very relaxing."),
  F('f_lark', 'Lark', 'grove_2', 640, 0, 'plane', { color: '#6cc068', body: '#4f7f58' },
    "I landed on a ledge and couldn't get down! Planes can't climb!", "I'm learning to jump properly now. Up is easy. Down is the scary part.", { y: 290 }),
  F('f_tassel', 'Tassel', 'castle_road', 2300, 225, 'frog', { color: '#b49cff', body: '#5a4e68', hat: 'feather' },
    'I hopped all the way up Lantern Hill! As a FROG! Do you know how far that is?!', 'My legs are SO strong now. Frog legs. Want to see me jump? ...Maybe later.'),
  F('f_flint', 'Flint', 'mtn_1', 1900, 230, 'ball', { color: '#9a93ad', body: '#5f5a52' },
    'Brrr! The North Trail is cold when you are a ball of paper!', "I'm knitting a scarf. For next time I get folded. You can never be too careful."),
  F('f_ollie', 'Ollie', 'pro_1', 2560, 232, 'plane', { color: '#ff7a6e', body: '#7a5a8a' },
    'Lumen Town! I made it! ...By crashing. But I made it!', 'I crashed right here in town and nobody noticed for days. Thanks for noticing.'),
  // out in the far parts of the old places (deep.js made them big)
  F('f_bale', 'Bale', 'fields_1', 2300, 1100, 'frog', { color: '#e8c66a', body: '#6b8a3a', hat: 'straw' },
    "I was a frog in a cabbage patch. Do you know how many snails there are in a cabbage patch? ALL of them.", "Farmer Rye says I can visit the farm any time. Not as a frog, though. He was very clear."),
  F('f_ripple', 'Ripple', 'fields_1', 800, 1900, 'boat', { color: '#5fc8f0', body: '#3b5a7b' },
    'I sailed across the fishing pond! The fish were very rude about it.', "Every time I see a puddle now, I feel like I should be floating on it. I don't. But I want to."),
  F('f_reed', 'Reed', 'lake_1', 1400, 1900, 'crane', { color: '#8be07a', body: '#4f7f58' },
    'Marooned on an island as a crane! At least the view was nice.', "I've decided I like islands. Not living on them. Looking at them. From here."),
  F('f_coral', 'Coral', 'lake_1', 1200, 2450, 'star', { color: '#ff7a6e', body: '#c45a5a' },
    'The far shore! You found the far shore! Nobody EVER finds the far shore!', 'I made a sandcastle on the far shore. If you see it, tell it I said hi.'),
  F('f_lumi', 'Lumi', 'pro_2', 1400, 2000, 'star', { color: '#ffe066', body: '#5a4a7a' },
    "I was a star up in the Lantern Garden. Gus kept trying to light me. I'm not a lamp, Gus!", "Gus lights the garden lamps every night again. He says it's because of you. He doesn't say it out loud, but he does."),
  F('f_fern', 'Fern', 'grove_1', 700, 1700, 'frog', { color: '#6cc068', body: '#3d6b4a' },
    'A bush! I was IN a bush! In the deep woods! As a FROG!', 'Grandpa Acorn says I was very brave in that bush. I was not. But I appreciate it.', { bush: 'bush_g1d' }),
  F('f_kite', 'Kite', 'castle_road', 600, 1200, 'plane', { color: '#b49cff', body: '#5a4e68' },
    'I flew over Lantern Hill! Then I flew INTO a hedge. The flying part was great.', 'Picnic Pam shares her paper sandwiches with me. They taste like paper. I love them.'),
  F('f_frost', 'Frost', 'mtn_1', 2000, 2300, 'star', { color: '#bff0ff', body: '#5f5a52' },
    "It's COLD on the Snowcap! I've been a frozen star for a week!", "I've warmed up now. Lumen Town is so cozy. I'm never going up a mountain again. Unless there are snacks."),
  // all over the rest of Lumenfold, now that it's big too
  F('f_tuck', 'Tuck', 'pro_1', 920, 2620, 'frog', { color: '#8be07a', body: '#4f72bf' },
    "I was a frog in a bush in the PARK. Right in the middle of town! Nobody looked!", 'I sit on the bench by the pond now. As a person. It is much more comfortable.', { bush: 'bush_t1' }),
  F('f_gloss', 'Gloss', 'pro_1', 3300, 2850, 'star', { color: '#fff3c4', body: '#2c3a6e' },
    "Behind the Observatory! Professor Twinkle kept pointing his telescope at me. 'A new star!' he said.", "Professor Twinkle named a star after me. It's actually a lamp. I didn't tell him."),
  F('f_skipper', 'Skipper', 'pro_1', 1725, 1330, 'boat', { color: '#ff7a6e', body: '#3b5a7b', hat: 'bucket' },
    "So THAT'S whose raft this is! It's mine! I was the raft's boat! ...I'm confused too.", 'Old Sal lets me sit on the jetty. We do not talk about the raft.', { y: 450 }),
  F('f_dusk', 'Dusky', 'pro_3', 520, 2150, 'crane', { color: '#b49cff', body: '#5a4a7a' },
    "The moths kept landing on me! Do I look like a lamp?! ...Oh. I'm next to a candle. That explains it.", "Mothwick's moths still follow me around. I've given up. They're my friends now."),
  F('f_bloom', 'Bloom', 'seal_1', 1220, 1300, 'star', { color: '#ff9ab0', body: '#7a5a8a' },
    "A secret garden inside a secret garden! I've been hiding from... nobody. Nobody ever comes here.", "Old Rosa says I can visit her roses whenever I like. Through the magic door. Very fancy.", { bush: 'bush_s1b' }),
  F('f_twig', 'Twig', 'grove_2', 1350, 2200, 'crane', { color: '#a8743a', body: '#4f7f58' },
    'Deep in the woods, folded up as a crane! The trees grumbled at me ALL NIGHT.', "Ranger Rowan says I'm an honorary ranger now. I didn't ask what that means."),
  F('f_hush', 'Hush', 'grove_3', 1100, 2050, 'ball', { color: '#c8c2d4', body: '#7a5a8a' },
    'Shhh! The owls were sleeping! ...Okay, they woke up. Thank you!', "Granny Hoo taught me to hoot. I'm not very good. It comes out as a 'hmm'."),
  F('f_drift', 'Drift', 'grove_4', 2250, 1700, 'plane', { color: '#9fe6ff', body: '#4f7f58' },
    'I flew over the Bramble Gap! Then I ran out of fly. Then I landed here.', 'The Origami Sage says I have excellent folds. I blushed so hard I almost unfolded.'),
  F('f_morel', 'Morel', 'grove_5', 1600, 1900, 'frog', { color: '#c4a57a', body: '#8a5a3c' },
    "I was a frog in the King's garden! If he finds out I sat on a toadstool, I'm DONE.", 'Spore says the toadstool forgives me. Spore talks to toadstools a lot.', { bush: 'bush_g5a' }),
  F('f_flare', 'Flare', 'peak_1', 600, 1950, 'ball', { color: '#ff8a3d', body: '#5a3a2a' },
    'A ball of paper on the ASH FLATS! I was one spark away from being a campfire!', "I'm staying far away from lava from now on. Very far. Lumen Town far."),
  F('f_steam', 'Steamy', 'peak_2', 1000, 2300, 'boat', { color: '#e0e8ff', body: '#5a4e58' },
    'I sailed into the Steam Gardens and got all foggy! Thanks for finding me!', 'I soak in the hot springs every day now. As a person. Boats get soggy.'),
  F('f_glint', 'Glint', 'maze_1', 300, 2350, 'star', { color: '#ffe066', body: '#3d6b4a' },
    "The middle of the maze! You found the middle! I've been stuck here since the hedges grew!", "I can't look at a hedge anymore. Lumen Town has planters. Planters I can handle."),
  F('f_regal', 'Regal', 'castle_gate', 1500, 1500, 'crane', { color: '#ffd23f', body: '#a8323e' },
    "On the castle lawn, folded up like a royal napkin! How undignified.", 'Hedgewick says the Queen would have liked me. I like to think so too.'),
];
export const RESCUE_GOAL = 25;
// where rescued folks hang around in Lumen Town: [x, depth]
const TOWN_SPOTS = [[340, 60], [450, 110], [650, 20], [790, 130], [960, 40], [1270, 100], [1420, 90], [1580, 40], [1760, 110], [1920, 20],
  [2150, 60], [2300, 110], [2460, 40], [2560, 130], [2640, 20], [2780, 90], [2880, 40], [3060, 100], [3140, 30], [3320, 80],
  [1180, 10], [600, 70], [2050, 10], [2400, 90], [520, 140], [1300, 20], [1650, 120], [2200, 30], [2520, 100], [2700, 60],
  [2950, 120], [3200, 50], [400, 20], [1000, 125], [1850, 10], [3360, 130], [1480, 135], [2600, 10], [3000, 20], [700, 110]];

// ---------------------------------------------------------------- tears in the paper
export const TEARS = [
  { id: 'tear_p1a', room: 'plains', x: 700, z: 600 },
  { id: 'tear_p1b', room: 'plains', x: 2750, z: 1300, give: { item: 'honeybun', n: 2 } },
  { id: 'tear_p1c', room: 'plains', x: 4200, z: 2900 },
  { id: 'tear_p2a', room: 'plains', x: 5300, z: 1250 },
  { id: 'tear_p2b', room: 'plains', x: 7250, z: 800, give: { starPiece: 1 } },
  { id: 'tear_p2c', room: 'plains', x: 8700, z: 2400 },
  { id: 'tear_fields', room: 'fields_1', x: 700, z: 120 },
  { id: 'tear_lake', room: 'lake_1', x: 2100, z: 60, give: { item: 'feather' } },
  { id: 'tear_path', room: 'pro_2', x: 420, z: 150 },
  { id: 'tear_grove', room: 'grove_1', x: 1400, z: 150, give: { coins: 15 } },
  { id: 'tear_fields2', room: 'fields_1', x: 1600, z: 1100 },
  { id: 'tear_lake2', room: 'lake_1', x: 2000, z: 900, give: { item: 'honeybun' } },
  { id: 'tear_road', room: 'castle_road', x: 1700, z: 900 },
  { id: 'tear_trail', room: 'mtn_1', x: 2500, z: 800, give: { coins: 15 } },
  { id: 'tear_park', room: 'pro_1', x: 760, z: 1580 },
  { id: 'tear_green', room: 'pro_1', x: 1900, z: 2420, give: { item: 'honeybun', n: 2 } },
  { id: 'tear_shed', room: 'pro_3', x: 900, z: 1250 },
  { id: 'tear_thicket', room: 'maze_1', x: 1100, z: 1500, give: { coins: 15 } },
  { id: 'tear_sage', room: 'grove_4', x: 800, z: 1900 },
  { id: 'tear_springs', room: 'peak_2', x: 800, z: 1750, give: { item: 'fireseed' } },
  { id: 'tear_hall', room: 'peak_3', x: 800, z: 1450 },
  { id: 'tear_castle', room: 'castle_gate', x: 750, z: 400, give: { starPiece: 1 } },
];
export const PATCH_GOAL = 10;

const rescued = A => Object.keys(A.s.rescued || {}).length;
const patched = A => Object.keys(A.s.patched || {}).length;
const stickers = (A, k) => (A.s.stickers || {})[k] || 0;

// ---------------------------------------------------------------- rooms
const FRONT = -80;   // the front edge of every floor
const SHRINE = (name, w, extra) => ({ name, area: 'shrine', theme: 'interior', style: 'shrine', interior: true, battleTheme: 'plains', w,
  ground: [[0, w, 450]], exits: {}, ...extra });
// a hedge in the maze: x0..x1 across, z0..z1 deep, too tall to jump
const HEDGE = (x0, x1, z0, z1) => ({ x: x0, w: x1 - x0, z0, z1, h: 170 });
const OUT = (to, toX, label, x = 120) => ({ x, to, toX, label, exit: true });
const BACK = (x, to, toX, label) => ({ x, to, toX, label, style: 'back' });

export const WILD_ROOMS = {
  // ======================= THE PAPER PLAINS (south of Lumen Town): one huge open field, 9000 wide and 3200 deep.
  // North (the far back) is Lumen Town and the Outskirts; south (the front) is the Sticker Shrine; west is Mirror Lake.
  plains: {
    name: 'Paper Plains', area: 'plains', theme: 'plains', w: 9000, z1: 3200,
    ground: [[0, 9000, 450]],
    hazard: 'water',
    wade: true,       // the ponds are shallow; the river is deep (that's what the bridge is for)
    hazardY: 456,
    holes: [
      // the River Fold winds from the north edge to the south edge
      [3420, 3800, FRONT, 900, 'deep'], [3500, 3880, 900, 1800, 'deep'], [3440, 3820, 1800, 2700, 'deep'], [3520, 3900, 2700, 3200, 'deep'],
      // Lily Pond (southwest) and Pinwheel Pond (east)
      [880, 1360, 640, 1010], [7000, 7520, 2280, 2660],
    ],
    terrain: [
      { x0: 4400, x1: 5400, z0: 1700, z1: 2500, y: 260 },               // Windmill Hill
      { x0: 5600, x1: 5720, z0: 300, z1: 1420, y: 130, mat: 'rock' },   // the Hidden Glade's cliffs (fog across the open south side)
      { x0: 6380, x1: 6500, z0: 300, z1: 1420, y: 130, mat: 'rock' },
      { x0: 5720, x1: 6380, z0: 1300, z1: 1420, y: 130, mat: 'rock' },
      { x0: 6140, x1: 6380, z0: 900, z1: 1300, y: 280 },                // the crate ledge inside the glade
      { x0: 6800, x1: 7250, z0: 1650, z1: 2150, y: 180 },               // Flower Mesa
      { x0: 7400, x1: 8700, z0: 2950, z1: 3200, y: 150, mat: 'rock' },  // the north cliffs (a boarded cave in their face)
      { x0: 600, x1: 720, z0: 1300, z1: 1400, y: 340, mat: 'rock' },    // a rocky outcrop (a sticker on top)
      { x0: 1150, x1: 1260, z0: 820, z1: 900, y: 440, base: 456 },      // a little island in Lily Pond
      // the Old Ruins: broken walls you can hop over, and the vault's tall walls
      { x0: 4450, x1: 4500, z0: 250, z1: 900, y: 380, mat: 'stone' },
      { x0: 4500, x1: 5150, z0: 860, z1: 900, y: 390, mat: 'stone' },
      { x0: 5100, x1: 5150, z0: 250, z1: 600, y: 375, mat: 'stone' },
      { x0: 4700, x1: 4760, z0: 380, z1: 640, y: 230, mat: 'stone' },
      { x0: 4840, x1: 4900, z0: 380, z1: 640, y: 230, mat: 'stone' },
      { x0: 4760, x1: 4840, z0: 600, z1: 640, y: 230, mat: 'stone' },
    ],
    // thick woods in the northwest and the east
    groves: [[0, 880, 1600, 3150], [8150, 9000, 1750, 2850]],
    roads: [
      [0, 150, 1500, 380], [1500, 380, 2050, 1560],                     // up from Mirror Lake to the village
      [2200, 1600, 2200, 3200],                                         // the North Road to Lumen Town
      [2600, 1500, 3420, 1345, 80],                                     // east to the river crossing (Peely's bridge spot)
      [3900, 1345, 4300, 1420], [4300, 1420, 5500, 1250], [5500, 1250, 5500, 200, 80], [5500, 200, 6000, 150, 80],
      [6100, 110, 7900, 40, 80],                                        // the shrine road
      [4300, 1420, 4250, 2050, 70],                                     // up to Windmill Hill's stairs
      [3920, 2985, 5600, 2600, 70], [5600, 2600, 6800, 3200, 80],       // the north meadow road to the Outskirts
    ],
    plats: [
      [3500, 450, 420, 2950, 3020],                                     // a fallen log across the river, way up north
      [1175, 450, 60, 680, 735], [1195, 450, 60, 760, 812],             // stepping stones out to the island
      [6740, 255, 55, 1895, 1960],                                      // a step from the giant flower up to the mesa
    ],
    lamps: [{ x: 2150, z: 1650 }],
    camp: [{ kind: 'tent', x: 2050, z: 2000, color: '#ff9ab0' }, { kind: 'campfire', x: 2330, z: 1780 }, { kind: 'stall', x: 2520, z: 1960 }],
    props: [
      { kind: 'house', x: 1800, z: 2250, roof: '#ff9ab0' }, { kind: 'house', x: 2760, z: 2280, roof: '#5fc8f0' },
      { kind: 'bigtree', x: 4900, z: 2300 },
    ],
    npcs: [
      { id: 'mayor', x: 2260, z: 1880, kind: 'mayor', name: 'Mayor Pennywick', talk: 'mayor' },
      { id: 'peely', x: 2520, z: 1905, kind: 'peely', name: 'Peely', talk: 'peely', flip: -1 },
      { id: 'stitch', x: 2700, z: 1760, kind: 'stitch', name: 'Stitch', talk: 'stitch', flip: -1 },
    ],
    doors: [
      { x: 2200, z: 3170, to: 'pro_1', toX: 2380, label: 'Lumen Town' },
      { x: 6800, z: 3170, to: 'pro_2', toX: 1700, label: 'Outskirts Path' },
      { x: 8000, to: 'shrine_1', toX: 160, label: 'Sticker Shrine', style: 'front', need: 'slot_shrinekey', lockScript: 'shrine_locked' },
      { x: 7950, z: 2945, to: 'grotto_1', toX: 160, label: 'Boarded Cave', style: 'crawl', needBroken: 'boards_cave',
        needText: 'Thick boards are nailed over this cave. Something explosive might clear them...' },
    ],
    barriers: [
      { id: 'boards_cave', x: 7905, w: 90, look: 'boards', z0: 2930, z1: 2940, bomb: true, solid: false, vh: 90 },
      { id: 'fog_gully', x: 5720, w: 660, look: 'fog', unless: 'slot_gully', z0: 220, z1: 330, vh: 240 },
      { id: 'ruin_bars', x: 4760, w: 80, look: 'bars', z0: 382, z1: 396, unless: ['ruin_a', 'ruin_b', 'ruin_c'], vh: 140 },
    ],
    plates: [
      { id: 'pl_ruin_a', x: 4580, z: 320, flag: 'ruin_a', mode: 'latch' },
      { id: 'pl_ruin_b', x: 5020, z: 780, flag: 'ruin_b', mode: 'latch' },
      { id: 'pl_ruin_c', x: 4990, z: 300, flag: 'ruin_c', mode: 'latch' },
    ],
    bombplants: [{ id: 'bp_p1', x: 7700, z: 2600 }],
    slots: [
      { id: 'river', kind: 'bridge', x: 3455, z: 1345 }, { id: 'hill', kind: 'stairs', x: 4290, z: 2200 },
      { id: 'gully', kind: 'fan', x: 6050, z: 150, dir: 1 }, { id: 'sprout2', kind: 'sprout', x: 6720, z: 2010 },
      { id: 'shrinekey', kind: 'key', x: 7900, z: -10 },
    ],
    xplats: [
      { look: 'bridge', x: 3480, y: 450, w: 420, z0: 1300, z1: 1390, when: 'slot_river' },
      { look: 'stairs', x: 4250, x1: 4400, y1: 260, z0: 2060, z1: 2140, when: 'slot_hill' },
      { look: 'flower', x: 6670, y: 330, w: 90, z0: 1890, z1: 1970, when: 'slot_sprout2' },
    ],
    peels: [
      { id: 'pk_stairs', kind: 'stairs', x: 660, y: 340, z: 1350 },     // on top of the outcrop
      { id: 'pk_tree', kind: 'fan', x: 4900, y: 236, z: 2272 },          // stuck to the big tree's trunk
      { id: 'pk_sprout', kind: 'sprout', x: 1380, z: 2890 },             // in the middle of the hedge maze
    ],
    crates: [{ id: 'cr_glade', x: 5900, z: 700 }],
    resets: [{ x: 5800, z: 420 }],
    springs: [{ x: 5480, z: 2100 }],
    hedges: [
      HEDGE(900, 1250, 2300, 2340), HEDGE(1350, 1700, 2300, 2340),     // the Hedge Maze, with the way in on the south side
      HEDGE(900, 940, 2340, 3000), HEDGE(1660, 1700, 2340, 3000), HEDGE(940, 1660, 2960, 3000),
      HEDGE(940, 1450, 2440, 2480), HEDGE(1150, 1660, 2580, 2620), HEDGE(940, 1300, 2720, 2760), HEDGE(1400, 1660, 2720, 2760),
    ],
    decor: [
      { kind: 'pinwheel', x: 7300, z: 1100, k: 2.4 }, { kind: 'pinwheel', x: 7620, z: 1260, k: 2 }, { kind: 'pinwheel', x: 7460, z: 880, k: 2.8 },
      { kind: 'torii', x: 7000, z: 60 }, { kind: 'torii', x: 7600, z: 30 },
    ],
    piles: [
      { id: 'pile_p1a', x: 300, z: 900 }, { id: 'pile_p1b', x: 4600, z: 1900 }, { id: 'pile_p1c', x: 8300, z: 1500 },
      { id: 'pile_p2a', x: 6000, z: 1000 }, { id: 'pile_p2b', x: 1200, z: 2850 }, { id: 'pile_p3', x: 3000, z: 600 }, { id: 'pile_p4', x: 7700, z: 2300 },
    ],
    bushes: [
      { id: 'bush_pl1', x: 1500, z: 300 }, { id: 'bush_pl2', x: 4700, z: 2050 }, { id: 'bush_pl3', x: 3100, z: 2000 },
      { id: 'bush_pl4', x: 600, z: 600 }, { id: 'bush_pl5', x: 2850, z: 1100 }, { id: 'bush_pl6', x: 5200, z: 2800 },
      { id: 'bush_pl7', x: 6600, z: 1300 }, { id: 'bush_pl8', x: 7800, z: 900 }, { id: 'bush_pl9', x: 8500, z: 450 },
      { id: 'bush_pl10', x: 4100, z: 600 }, { id: 'bush_pl11', x: 1900, z: 2900 }, { id: 'bush_pl12', x: 6200, z: 2300 },
    ],
    pots: [{ id: 'pot_pl1', x: 1950, z: 1720 }, { id: 'pot_pl2', x: 2650, z: 2060 }, { id: 'pot_pl3', x: 4600, z: 700 }, { id: 'pot_pl4', x: 4990, z: 650 }],
    chests: [
      { id: 'p_hill', x: 5200, z: 1800, give: { item: 'bighoney' } },
      { id: 'p_ledge', x: 6320, z: 1160, give: { starPiece: 1 } },
      { id: 'p_mesa', x: 7120, z: 1900, give: { coins: 30 } },
      { id: 'p_island', x: 1215, z: 865, give: { item: 'honeybun', n: 2 } },
      { id: 'p_maze', x: 1290, z: 2880, give: { item: 'windcookie' } },
      { id: 'p_vault', x: 4800, z: 520, give: { starPiece: 2 } },
      { id: 'p_woods', x: 8620, z: 2300, give: { coins: 20 } },
    ],
    blocks: [
      { id: 'p_b1', x: 2900, y: 300, z: 700, give: { coins: 5 } }, { id: 'p_b2', x: 5190, y: 300, z: 420, give: { item: 'honeybun' } },
      { id: 'p_b3', x: 7600, y: 300, z: 1500, hidden: true, give: { starPiece: 1 } }, { id: 'p_b4', x: 1600, y: 300, z: 1200, give: { coins: 5 } },
    ],
    signs: [
      { x: 200, z: 260, text: "The Paper Plains! The Gloom Gale folded up the folks of Pinwheel Village and blew them all over. If a little paper shape wiggles, press E to unfold it. (The little map in the corner shows where you are.)" },
      { x: 2000, z: 1540, text: "Pinwheel Village (what's left of it). The camp has a lamppost, Peely's sticker stand and a very worried mayor." },
      { x: 3320, z: 1420, text: "The River Fold. Peely says a Bridge Sticker would cross it right here. (There's an old fallen log way up north, too.)" },
      { x: 4200, z: 1900, text: "Windmill Hill. There used to be a windmill up there, until the Gloom Gale folded it into a giant paper fan. It's still stuck to that tree." },
      { x: 4620, z: 200, text: "The Old Ruins. Carved on a stone: 'Three gold stones hold the vault shut. Step on all three.'" },
      { x: 1290, z: 2240, text: "The Hedge Maze. 'Whoever planted this: we are not friends.' — everyone" },
      { x: 5900, z: 140, text: "Gloom fog fills the Hidden Glade. Way too thick to walk through. A big fan would blow it right out." },
      { x: 7700, z: 120, text: "To the Sticker Shrine. 'Keep the lock sticky side up.'" },
    ],
    enemies: [
      { id: 'pe1', x: 900, z: 380, kind: 'snipper', group: ['snipper'] },
      { id: 'pe2', x: 2900, z: 820, kind: 'gloomling', group: ['gloomling', 'gloomling'] },
      { id: 'pe3', x: 3150, z: 2450, kind: 'buzzbug', group: ['buzzbug', 'buzzbug'], y: 330, range: 110 },
      { id: 'pe4', x: 4150, z: 1000, kind: 'snipper', group: ['snipper', 'gloomling'] },
      { id: 'pe5', x: 5250, z: 1150, kind: 'dustbunny', group: ['dustbunny'] },
      { id: 'pe6', x: 5700, z: 2650, kind: 'snipper', group: ['snipper', 'snipper'] },
      { id: 'pe7', x: 6650, z: 800, kind: 'gloomling', group: ['gloomling', 'snipper'] },
      { id: 'pe8', x: 7500, z: 1350, kind: 'snailshell', group: ['snailshell'], calm: true },
      { id: 'pe9', x: 8250, z: 1900, kind: 'snipper', group: ['snipper'] },
      { id: 'pe10', x: 8450, z: 650, kind: 'buzzbug', group: ['buzzbug'], y: 330 },
      { id: 'pe11', x: 1500, z: 1950, kind: 'gloomling', group: ['gloomling'] },
      { id: 'pe12', x: 650, z: 2600, kind: 'dustbunny', group: ['dustbunny', 'dustbunny'] },
    ],
    triggers: [{ id: 'plains_hello', x: 0, script: 'plains_hello', once: true }],
    exits: { left: { to: 'lake_1', x: 2540, z0: -60, z1: 420 } },
  },
  grotto_1: {
    name: 'Hidden Grotto', area: 'plains', theme: 'cave', music: 'caves', w: 1500,
    ground: [[0, 1500, 450]],
    lamps: [320],
    doors: [{ x: 140, to: 'plains', toX: 7950, label: 'Paper Plains' }],
    bombplants: [{ id: 'bp_gr', x: 620, z: 60 }],
    barriers: [{ id: 'rocks_grotto', x: 880, w: 80, look: 'rocks', bomb: true }],
    peels: [{ id: 'pk_key', kind: 'key', x: 1250, z: 150 }],
    chests: [{ id: 'gr_ch', x: 1400, z: 90, give: { coins: 20 } }],
    piles: [{ id: 'pile_gr', x: 420, z: 200 }],
    pots: [{ id: 'pot_gr1', x: 520, z: 170 }, { id: 'pot_gr2', x: 1340, z: 210 }],
    signs: [{ x: 760, z: 60, text: "A cracked rock wall, much too thick for a hammer. 'DANGER: BLASTING ZONE' is scratched into it. Somebody had the right idea." }],
    enemies: [{ id: 'gr_e1', x: 720, kind: 'glowbat', group: ['glowbat', 'glowbat'], y: 330, range: 80 }],
    exits: {},
  },

  // ======================= THE STICKER SHRINE (behind the sticker lock in Pinwheel Meadow)
  shrine_1: SHRINE('Sticker Shrine: Crate Hall', 1500, {
    windows: [520, 980],
    doors: [OUT('plains', 8000, 'Paper Plains'), BACK(1380, 'shrine_2', 160, 'Wind Hall')],
    gates: [{ x: 1150, w: 40, top: 230, flag: 'sh1_gate' }],
    plates: [{ id: 'pl_sh1', x: 820, z: 170, flag: 'sh1_gate', mode: 'hold' }],
    crates: [{ id: 'cr_sh1', x: 480, z: 20 }],
    resets: [{ x: 300, z: 200 }],
    furniture: [{ kind: 'pedestal', x: 820, z: 90 }, { kind: 'banner', x: 640, color: '#c0392b' }, { kind: 'banner', x: 1000, color: '#c0392b' }],
    peels: [{ id: 'pk_sh1', kind: 'fan', x: 1265, z: 120 }],
    signs: [{ x: 200, z: 60, text: "The Sticker Shrine. 'Only the patient may pass. Also the pushy.' Underneath, smaller: 'We mean crates. Blue plates only stay down while something sits on them.'" }],
    triggers: [{ id: 'shrine_hello', x: 0, script: 'shrine_hello', once: true }],
  }),
  shrine_2: SHRINE('Sticker Shrine: Wind Hall', 1600, {
    ground: [[0, 1150, 450], [1150, 1600, 200]],
    windows: [700],
    doors: [BACK(120, 'shrine_1', 1380, 'Crate Hall'), BACK(1480, 'shrine_3', 160, 'Bomb Hall')],
    slots: [{ id: 'sh2fan', kind: 'fan', x: 420, z: 30, dir: 1 }],
    barriers: [{ id: 'fog_sh2', x: 560, w: 150, look: 'fog', unless: 'slot_sh2fan' }],
    updrafts: [{ x: 1030, w: 115, z0: -40, z1: 130, top: 150, when: 'slot_sh2fan' }],
    plats: [[880, 180, 100]],
    piles: [{ id: 'pile_sh2', x: 300, z: 180 }],
    signs: [{ x: 250, z: 60, text: "Wind Hall. The wind here used to blow straight up, all day long. Then somebody stole the fan. (It was the Gloop Golem. It's always the Gloop Golem.)" }],
  }),
  shrine_3: SHRINE('Sticker Shrine: Bomb Hall', 1700, {
    ground: [[0, 700, 450], [980, 1700, 450]],
    windows: [1300],
    doors: [BACK(120, 'shrine_2', 1480, 'Wind Hall'), BACK(1580, 'shrine_4', 160, 'Glue Sanctum')],
    bombplants: [{ id: 'bp_sh3', x: 260, z: 60 }],
    barriers: [{ id: 'rocks_sh3', x: 440, w: 70, look: 'rocks', bomb: true }],
    peels: [{ id: 'pk_sh3_bridge', kind: 'bridge', x: 590, z: 160 }, { id: 'pk_sun', kind: 'sun', x: 1300, z: 120 }],
    slots: [{ id: 'sh3bridge', kind: 'bridge', x: 665, z: 30 }],
    xplats: [{ look: 'bridge', x: 700, y: 450, w: 280, z0: -10, z1: 80, when: 'slot_sh3bridge' }],
    pots: [{ id: 'pot_sh3a', x: 150, z: 180 }, { id: 'pot_sh3b', x: 1180, z: 200 }],
    signs: [{ x: 340, z: 170, text: "Bomb Hall. 'Rocks in your way? Try a little BOOM. Throw from a safe distance!' — the old shrine keeper" }],
  }),
  shrine_4: SHRINE('Sticker Shrine: Glue Sanctum', 1400, {
    dark: true, litBy: 'slot_sh4sun', music: 'secret',
    windows: [700],
    doors: [BACK(120, 'shrine_3', 1580, 'Bomb Hall')],
    slots: [{ id: 'sh4sun', kind: 'sun', x: 330, z: 40 }],
    boss: { kind: 'gluegolem', x: 1000, flag: 'golem_down', scale: 1.4 },
    chests: [{ id: 'sh4ch', x: 1260, z: 60, give: { coins: 30 } }],
    triggers: [
      { id: 'sh4_dark', x: 430, script: 'sh4_dark', when: A => !A.flag('slot_sh4sun') },
      { id: 'golem', x: 700, script: 'golem_fight', when: A => !A.flag('golem_down') && A.flag('slot_sh4sun') },
    ],
  }),
};

// ---------------------------------------------------------------- hooking the Plains into the old world
export function patchWilds(ROOMS) {
  for (const f of FOLKS) (ROOMS[f.room].folks = ROOMS[f.room].folks || []).push(f);
  for (const t of TEARS) (ROOMS[t.room].tears = ROOMS[t.room].tears || []).push(t);
  // the South Road leaves town across from the North Gate; the Outskirts Path and Mirror Lake lead there too
  const closed = "The road south is still dark. (Light up the town first.)";
  const door = (id, d) => (ROOMS[id].doors = ROOMS[id].doors || []).push(d);
  door('pro_1', { x: 2380, to: 'plains', toX: 2200, label: 'South Road', style: 'front', need: 'prologue_done', needText: closed });
  door('pro_2', { x: 1700, to: 'plains', toX: 6800, label: 'Paper Plains', style: 'front', need: 'prologue_done', needText: closed });
  ROOMS.lake_1.exits.right = { to: 'plains', x: 60 };
  // folks hiding in bushes need the bush right where they are
  ROOMS.fields_1.bushes.find(b => b.id === 'bush_f2').z = 60;
  ROOMS.pro_2.bushes.find(b => b.id === 'bush_p2').z = 40;
  // everyone you rescue moves into Lumen Town for now
  FOLKS.forEach((f, i) => {
    const [x, z] = TOWN_SPOTS[i % TOWN_SPOTS.length];
    ROOMS.pro_1.npcs.push({ id: `rf_${f.id}`, x, z, kind: 'folk', name: f.name, talk: `rf_${f.id}`, opts: { ...f.opts, seed: i },
      flip: i % 2 ? -1 : 1, show: A => !!A.s.rescued[f.id] && A.flag('prologue_done') });
  });
  ROOMS.pro_1.triggers.push({ id: 'plains_news', x: 1300, once: true, script: 'plains_news', when: A => A.flag('prologue_done') && !(A.s.visited || {}).plains_1 });
}

// ---------------------------------------------------------------- areas, enemies, badges, speakers
export const WILD_AREAS = {
  plains: { name: 'Paper Plains', start: 'plains', x: 2150, z: 1600, icon: '🌼', mx: 0.55, my: 0.84, music: 'fields' },
  shrine: { name: 'Sticker Shrine', start: 'shrine_1', x: 200, icon: '🗒️', mx: 0.66, my: 0.93, music: 'castle' },
};

export const WILD_ENEMIES = {
  snipper: { name: 'Snipper', hp: 4, atk: 2, def: 0, xp: 12, coins: [1, 3], h: 44, lvl: 4,
    tattle: 'A Snipper: a pair of scissors with an attitude. It snips at anything made of paper, which is everything around here. Max HP 4, Attack 2.' },
  gluedrop: { name: 'Glue Drop', hp: 2, atk: 1, def: 0, xp: 4, coins: [0, 1], h: 34, lvl: 3,
    tattle: 'A Glue Drop that dripped off the Gloop Golem. Sticky, but not tough. Max HP 2.' },
  gluegolem: { name: 'Gloop Golem', hp: 26, atk: 2, def: 0, boss: true, xp: 80, coins: [40, 40], h: 140, scale: 1.4, lvl: 7,
    tattle: "The Gloop Golem: the paste blob that glued the Sticker Shrine shut. Its Glue Spit sticks Wick's feet to the floor, so no jumping next turn (the hammer still works!). It drips Glue Drops, and at half HP it goes runny and hits harder. Max HP 26." },
};

export const WILD_BADGES = {
  sticker_star: { name: 'Sticker Star', bp: 2, desc: 'The first hit Wick lands in every battle does 2 extra damage.' },
  lucky_patch: { name: 'Lucky Patch', bp: 1, desc: 'Bushes and pots drop twice as many coins.' },
  paper_heart: { name: 'Paper Heart', bp: 1, desc: 'Win a battle and Wick gets 2 HP back.' },
};

export const WILD_SPEAKERS = { Peely: 'peely', Stitch: 'stitch', 'Mayor Pennywick': 'mayor', 'Gloop Golem': 'gluegolem' };
export const WILD_SPEAKER_OPTS = { 'Gloop Golem': { mood: 'angry' } };
for (const f of FOLKS) { WILD_SPEAKERS[f.name] = 'folk'; WILD_SPEAKER_OPTS[f.name] = f.opts; }
export const WILD_PORTRAITS = { peely: 2, stitch: 1.45, mayor: 1.7, gluegolem: 1.1 };

// ---------------------------------------------------------------- quests
export const WILD_QUESTS = {
  stickerbook: { name: 'The Sticker Shrine', giver: 'Peely', where: 'Paper Plains camp', room: ['plains', 2520, 1905], goal: ['shrine_1'],
    desc: "The Gloop Golem glued itself inside the Sticker Shrine (at the south edge of the Paper Plains, far to the east) and took Peely's family sticker collection with it. Find a Key Sticker for the shrine's sticker lock, then work your way to the very back.",
    progress: A => ({ done: A.flag('golem_down'), text: A.flag('golem_down') ? 'The Gloop Golem is beaten!' : A.flag('slot_shrinekey') ? 'Reach the back of the Sticker Shrine' : 'Find a Key Sticker for the shrine lock' }),
    targets: A => (A.flag('slot_shrinekey') ? [['shrine_4', 900]] : stickers(A, 'key') > 0 ? [['plains', 7900, -10]] : [['grotto_1', 1250]]),
    reward: { badge: 'sticker_star', starPieces: 2 } },
  rescue: { name: 'Folded Folks', giver: 'Mayor Pennywick', where: 'Paper Plains camp', room: ['plains', 2260, 1880],
    desc: `The Gloom Gale folded the folks of Pinwheel Village into paper shapes and blew them all over Lumenfold. If a little paper shape wiggles, press E to unfold it. ${RESCUE_GOAL} of the ${FOLKS.length} will do!`,
    progress: A => { const n = rescued(A); return { done: n >= RESCUE_GOAL, text: `Folks rescued: ${n} of ${FOLKS.length} (${RESCUE_GOAL} needed)` }; },
    targets: A => FOLKS.filter(f => !A.s.rescued[f.id]).map(f => [f.room, f.x, f.z]),
    reward: { badge: 'paper_heart', starPieces: 2 } },
  patch: { name: 'Mind the Gaps', giver: 'Stitch', where: 'Paper Plains camp', room: ['plains', 2700, 1760],
    desc: `The Gloom Gale tore holes right through the paper! Patch ${PATCH_GOAL} of the ${TEARS.length} tears with confetti: walk up to one and press E. Bushes, pots, battles and confetti piles fill your bag.`,
    progress: A => { const n = patched(A); return { done: n >= PATCH_GOAL, text: `Tears patched: ${n} of ${TEARS.length} (${PATCH_GOAL} needed)` }; },
    targets: A => TEARS.filter(t => !A.s.patched[t.id]).map(t => [t.room, t.x, t.z]),
    reward: { badge: 'lucky_patch', starPieces: 1 } },
};

// Who has a "!" over their head.
export function wildNews(A, n) {
  const quest = { Peely: 'stickerbook', 'Mayor Pennywick': 'rescue', Stitch: 'patch' }[n.name];
  if (!quest) return null;
  if (n.name === 'Mayor Pennywick' && A.questActive('rescue') && [5, 10, 15, 20].some(m => rescued(A) >= m && !A.flag(`mayor_${m}`))) return true;
  return !A.questKnown(quest) || A.questReady(quest);
}

// ---------------------------------------------------------------- scripts
const giver = (id, who, intro, remind, thanks) => [
  ['if', A => A.questDone(id), [['say', who, thanks]], [
    ['if', A => A.questReady(id), [['turnin', id], ['say', who, thanks]], [
      ['if', A => A.questActive(id), [['say', who, remind]], [...intro, ['quest', id]]],
    ]],
  ]],
];
// the Mayor's thank-you gifts on the way to 20
const mile = (n, line, gift) => ['if', A => A.questActive('rescue') && rescued(A) >= n && !A.flag(`mayor_${n}`), [['flag', `mayor_${n}`], ['say', 'Mayor Pennywick', line], ...gift]];

export const WILD_SCRIPTS = {
  plains_news: [['tip', '🌼 Psst! The South Road at the east end of town (across from the North Gate) leads somewhere new: the Paper Plains!', 9]],
  plains_hello: [
    ['narrate', 'The Paper Plains. Pinwheels spin all the way to the horizon, and from out here you can see half of Lumenfold: the Great Lantern, the castle on Lantern Hill... and Count Dusk\'s Tower, way off to the north.'],
    ['tip', "🌼 Explore anywhere! Folded-up folks are hiding all over (even back in places you've been). There's a camp just ahead.", 8],
  ],
  peely: [
    ['if', A => !A.flag('met_peely'), [
      ['flag', 'met_peely'],
      ['say', 'Peely', "Oh! A visitor! Sorry, I'm a little... peeled. *pat pat* There. Hi! I'm Peely, and this is my sticker stand!"],
      ['say', 'Peely', 'Out here, stickers are MAGIC. Peel one off the world with E and it goes in your Sticker Album.'],
      ['say', 'Peely', 'Then find an outline of the same shape, press E, and stick it there. A bridge outline becomes a bridge. A fan outline becomes a fan. Easy!'],
      ['say', 'Peely', 'Here, a welcome present! That river east of camp could REALLY use a bridge.'],
      ['sticker', 'bridge'],
    ]],
    ...giver('stickerbook', 'Peely', [
      ['say', 'Peely', "Can I ask a favor? My family's sticker collection is kept in the Sticker Shrine, at the south edge of the plains, way out east."],
      ['say', 'Peely', "But the Gloop Golem oozed in there and glued EVERYTHING shut. The front door has a sticker lock, so you'd need a Key Sticker."],
      ['say', 'Peely', "I heard there's one in a boarded-up cave under the north cliffs, east of the river. Boards, hmm... bombs might help? There's a bomb plant out that way."],
    ], 'The Sticker Shrine is at the south edge of the plains, way out east. Key Sticker for the lock, then all the way to the back. You can do it!',
    "You beat the Gloop Golem?! Our stickers are free! You're a true Sticker Star. Here, this badge is yours!"),
    ['choose', 'Peely: Want to look at my stickers?', [['🗒️ Browse stickers', [['shop', 'stickers']]]]],
  ],
  mayor: [
    ['if', A => A.questDone('rescue'), [['say', 'Mayor Pennywick', A => `${rescued(A)} villagers home safe! You, my friend, are an honorary citizen of Pinwheel Village.`]], [
      ['if', A => !A.questKnown('rescue'), [
        ['say', 'Mayor Pennywick', 'Ahem! Mayor Pennywick, of Pinwheel Village. Or rather, of the patch of grass where Pinwheel Village USED to be.'],
        ['say', 'Mayor Pennywick', 'A dreadful wind came through: the Gloom Gale. It folded every last villager into a little paper shape and blew them across all of Lumenfold!'],
        ['say', 'Mayor Pennywick', "Cranes, frogs, little boats... if you see a paper shape that wiggles, that's one of my villagers. Press E to unfold them. Some of them landed far away, even back in places you've already been!"],
        ['say', 'Mayor Pennywick', `Bring ${RESCUE_GOAL} of them home and I'll make it worth your while. They can stay in Lumen Town for now. Our village is rather... flat, at the moment.`],
        ['quest', 'rescue'],
      ]],
      mile(5, 'Five villagers already! Splendid. Have a Stairs Sticker, and a little something for your trouble.', [['sticker', 'stairs'], ['coins', 20]]),
      mile(10, 'Ten! TEN! The town council (also me) votes you this Star Piece.', [['give', { starPieces: 1 }]]),
      mile(15, 'Fifteen villagers! This old Fan Sticker was in my hat. Take it, take it!', [['sticker', 'fan'], ['give', { items: { bighoney: 1 } }]]),
      mile(20, 'Twenty! The village choir has enough voices again. They sing terribly. It is wonderful. A Star Piece for you!', [['give', { starPieces: 1 }]]),
      ['if', A => A.questReady('rescue'), [
        ['turnin', 'rescue'],
        ['say', 'Mayor Pennywick', `${RESCUE_GOAL} villagers! Pinwheel Village lives again! This Paper Heart badge is our village's highest honor. It used to be a coaster.`],
      ], [
        ['if', A => A.questActive('rescue'), [['say', 'Mayor Pennywick', A => `${rescued(A)} of ${FOLKS.length} villagers found so far. Keep your eyes peeled for anything paper-shaped that wiggles! Your quest log (ESC → Quests) can point you to them.`]]],
      ]],
    ]],
  ],
  stitch: [
    ['if', A => !A.flag('met_stitch'), [
      ['flag', 'met_stitch'],
      ['say', 'Stitch', "Hm? Oh, hello. Stitch. I fix things. Rips, holes, torn hems, broken hearts. Mostly hems."],
      ['say', 'Stitch', 'The Gloom Gale tore holes right through the paper of the world. Step in one and down you go. Not dangerous, just embarrassing.'],
    ]],
    ...giver('patch', 'Stitch', [
      ['say', 'Stitch', "Here's the trick: fill a tear with confetti and it seals right up. Ten confetti per tear. Bushes, pots and battles all shake some loose, and you'll find big piles lying around."],
      ['say', 'Stitch', `Patch ${PATCH_GOAL} tears for me and I'll give you something lucky. There are ${TEARS.length} that I know of, all over Lumenfold: the Plains, Lumen Town, the fields and the lake, the Grove, the castle grounds, even up on Ember Peak.`],
    ], A => `Tears patched: ${patched(A)} of ${TEARS.length}. You have ${A.s.confetti || 0} 🎉 confetti. Walk up to a tear and press E.`,
    'Not a single hole left that I can see. Fine work! This Lucky Patch is my best stitching. Bushes and pots will be extra generous now.'),
  ],
  shrine_locked: [['narrate', "The Sticker Shrine's gate has a sticker lock: a key-shaped outline right next to it. Stick a Key Sticker there to open it."]],
  shrine_hello: [
    ['narrate', 'The Sticker Shrine. Paper walls, red beams... and glue. So much glue. Something squelches, far off in the back.'],
    ['tip', '📦 Crates! Walk into one to push it, sideways or into the distance. If one gets stuck, the purple totem puts it back.', 8],
  ],
  sh4_dark: [['narrate', "It's pitch dark in here. Something big is breathing... squelchily. You can't fight what you can't see. Maybe a Sun Sticker would help?"]],
  golem_fight: [
    ['cut', 'boss_wake'],
    ['say', 'Gloop Golem', 'GLOOOP. WHO TURNED ON THE LIGHTS. I WAS STICKING TO MY NAP.'],
    ['say', 'Gloop Golem', "THESE STICKERS ARE MINE NOW. I GLUED THEM. THAT'S HOW OWNING WORKS."],
    ['say', 'Wick', "...That's not how owning works."],
    ['say', 'Gloop Golem', 'GLOOP! STICK AROUND, THEN!'],
    ['battle', ['gluegolem'], { boss: true }],
    ['flag', 'golem_down'],
    ['narrate', "The Gloop Golem melts into a harmless puddle of paste. Peely's family stickers peel loose from every wall and flutter around the room!"],
    ['give', { starPieces: 1, coins: 20 }],
    ['tip', '✨ Go tell Peely at the Paper Plains camp!', 8],
  ],
};
for (const f of FOLKS) WILD_SCRIPTS[`rf_${f.id}`] = [['say', f.name, f.town]];
