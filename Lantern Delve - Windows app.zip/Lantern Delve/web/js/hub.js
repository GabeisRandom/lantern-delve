// Main window: Today / Homework / Adventure / Settings.
import { api, fmt, esc, rewardText, uploadFile, openFile, fileChip, MAX_UPLOAD, sizeText } from './api.js';
import { sfx, setSound } from './audio.js';
import { music } from './music.js';

const $ = s => document.querySelector(s);
let S = null;
let tab = (location.hash || '#today').slice(1);
let selQuest = null;
let startQuest = '';
let pledge = false;
let paperMode = false;
let adventure = null;
let modal = null;
let ackedSummary = null;
let editing = null;
let edFiles = [];      // the editor's files: {key, id, name, size, state: 'up' | 'ok' | 'err', err}
let fileKey = 0;
const rendered = {};

// ---------------------------------------------------------------- plumbing
function toast(msg, ms = 2600) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.remove('hidden');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => t.classList.add('hidden'), ms);
}

async function refresh() {
  try {
    S = await api('/api/state');
    onState();
  } catch (e) { /* server not up yet */ }
}

async function poll() {
  await refresh();
  setTimeout(poll, 1000);
}

function switchTab(name) {
  if (!['today', 'homework', 'adventure', 'settings'].includes(name)) name = 'today';
  tab = name;
  document.querySelectorAll('#tabs button').forEach(b => b.classList.toggle('active', b.dataset.tab === name));
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.id === 'tab-' + name));
  history.replaceState(null, '', '#' + name);
  rendered[name] = null;
  if (name === 'adventure') ensureAdventure();
  if (adventure) adventure.setActive(name === 'adventure');
  syncMusic();
  if (S) renderTab();
}

// Outside the Adventure (which picks its own songs) the home theme plays, except during focus,
// when the study buddy window plays study music instead.
function syncMusic() {
  if (!S || tab === 'adventure') return;
  const s = S && S.session;
  music.want(s && s.mode === 'focus' ? null : 'home');
}

async function ensureAdventure() {
  if (adventure) return;
  const { Adventure } = await import('./game/adventure.js');
  adventure = new Adventure($('#game-root'), { getState: () => S, toast, goTab: switchTab, refresh });
  window.__adv = adventure;
  adventure.setActive(tab === 'adventure');
  if (S) adventure.onState(S);
}

function onState() {
  setSound(S.settings.sound !== false);
  music.applySettings(S.settings);
  syncMusic();
  $('#w-light').textContent = S.wallet.light;
  $('#w-coins').textContent = S.wallet.coins;
  $('#w-stars').textContent = S.wallet.star_pieces;
  $('#w-streak').textContent = S.streak;
  renderSessionBar();
  renderUpdateBar();
  // (the start menu steps aside for a tab the buddy window asked for, or a focus session's summary)
  if (start && (S.pending_tab || (S.summary && S.summary.id !== ackedSummary))) leaveStart(null);
  renderStartStats();
  if (S.pending_tab) {
    const t = S.pending_tab;
    api('/api/tab/ack', {});
    S.pending_tab = null;
    switchTab(t);
  }
  if (S.summary && S.summary.id !== ackedSummary && !modal) showSummary(S.summary);
  if (adventure) adventure.onState(S);
  renderTab();
}

function renderTab() {
  if (tab === 'today') {
    const k = JSON.stringify([S.daily, S.streak, S.streak_rewards, S.today.focus >= 900, Math.floor(S.today.focus / 60), S.chests,
      S.today.steps, S.log, !!S.session, S.session && S.session.mode, S.session && Math.floor(S.session.focus_s / 10),
      S.quests.map(q => [q.id, q.title, q.done, q.steps.filter(s => s.done).length, q.steps.length]), startQuest, pledge, paperMode]);
    if (rendered.today !== k) { rendered.today = k; renderToday(); }
  } else if (tab === 'homework') {
    const k = JSON.stringify([S.quests, selQuest, !!S.session, doneOpen]);
    if (rendered.homework !== k) { rendered.homework = k; renderHomework(); }
  } else if (tab === 'settings') {
    if (!rendered.settings) { rendered.settings = 1; renderSettings(); }
    renderAiStatus();
  }
}

// ---------------------------------------------------------------- session bar
// A downloaded update: it installs by itself next time, or right now with a restart.
let hiddenUpdate = null;
function renderUpdateBar() {
  const u = S.update || {}, bar = $('#update-bar');
  if (!bar) return;
  const show = u.status === 'ready' && u.version && hiddenUpdate !== u.version;
  const k = JSON.stringify([show, u.version, !!S.session]);
  if (bar.dataset.k !== k) {
    bar.dataset.k = k;
    bar.classList.toggle('hidden', !show);
    bar.innerHTML = !show ? '' : `<span>✨ <b>New version ready</b>${u.notes ? `: ${esc(u.notes)}` : ''}</span><span class="grow"></span>
      ${S.session ? '<span class="muted">It installs after your focus session.</span>'
        : `<button class="btn small gold" data-a="update-now">↻ Restart now</button>
           <span class="muted">or it ${S.web ? 'loads' : 'installs'} next time you open Lantern Delve</span>`}
      <button class="btn small ghost" data-a="update-hide" title="Hide">✕</button>`;
  }
  const el = $('#upd-status');
  if (el) { const t = updateText(u); if (el.innerHTML !== t) el.innerHTML = t; }
}

function updateText(u) {
  if (u.status === 'off') {
    return u.current === 'dev' ? "This is your own copy, where the game gets made, so it doesn't update itself. Friends' copies update themselves when you publish a new version."
      : `Version ${esc(u.current)}.`;
  }
  const v = `You have version <b>${esc(u.current)}</b>.`;
  if (u.status === 'ready') return `${v} ✨ Version <b>${esc(u.version)}</b> is downloaded and ${S.web ? 'loads' : 'installs'} next time you open Lantern Delve.`;
  if (u.status === 'current') return `${v} ✓ It's up to date. New versions download and install by themselves.`;
  if (u.status === 'error') return `${v} Couldn't check for updates just now (offline?). It tries again later.`;
  return `${v} New versions download and install by themselves.`;
}

function renderSessionBar() {
  const bar = $('#session-bar');
  const s = S.session;
  if (!s) { bar.classList.add('hidden'); return; }
  const a = s.alert;
  bar.className = 'session-bar ' + (a ? 'alert' : s.mode === 'break' ? 'break' : '');
  let text;
  if (s.mode === 'break') text = `☕ Break · ${fmt(s.break_bank)} left · the Adventure is unlocked!`;
  else if (a && a.kind === 'blocked') text = `🚫 ${a.label} is open · −${a.lost || 0} ✦ so far`;
  else if (a && a.kind === 'idle') text = `👀 Your buddy is asking what's up`;
  else if (a && a.kind === 'offtask') text = `🤔 That window doesn't look like your assignment`;
  else if (a && a.kind === 'breakover') text = `⏰ Break's over!`;
  else text = `Focusing · ${fmt(s.focus_s)} · ✦ +${s.light_earned} · x${s.combo.toFixed(1)}`
    + (s.quest && s.quest.step_text ? ` · Step ${s.quest.step_index + 1}: ${s.quest.step_text}` : '');
  bar.innerHTML = `<span class="dot"></span><span class="grow">${esc(text)}</span>`
    + (s.mode === 'break' ? '<button class="btn small green" data-a="resume">▶ Back to work</button>'
      : '<button class="btn small" data-a="take-break">☕ Break</button>')
    + '<button class="btn small ghost" data-a="end-session">⏹ End</button>';
}

// ---------------------------------------------------------------- Today
function renderToday() {
  const s = S.session;
  const open = S.quests.filter(q => !q.done);
  if (startQuest && !open.find(q => String(q.id) === String(startQuest))) startQuest = '';
  const q = open.find(o => String(o.id) === String(startQuest));
  const next = q ? q.steps.find(st => !st.done) : null;
  const start = s ? `
    <div class="card paper start-card">
      <h2>🔥 Focus session running</h2>
      <p>${s.quest ? `Working on <b>${esc(s.quest.title)}</b>` : 'Free session'} · ${fmt(s.focus_s)} focused · ✦ +${s.light_earned}
        ${s.light_lost ? `· <span style="color:#c0392b">−${s.light_lost} lost</span>` : ''}</p>
      <p class="muted">${s.mode === 'break' ? 'You are on a break, so the Adventure tab is unlocked!'
        : S.web ? "Switch to your work now: time spent in this tab doesn't count. Take a break in Wick's window to unlock the Adventure."
        : 'Your buddy window is keeping you company. Take a break in it to unlock the Adventure.'}</p>
      <div class="row"><button class="btn red" data-a="end-session">⏹ End session</button></div>
    </div>` : `
    <div class="card paper start-card">
      <h2>Ready to focus?</h2>
      <div class="field"><label for="start-quest">What are you working on?</label>
        <select id="start-quest"><option value="">✨ Free session (anything)</option>
          ${open.map(o => `<option value="${o.id}" ${String(o.id) === String(startQuest) ? 'selected' : ''}>${esc(o.title)} (${o.steps.filter(x => x.done).length}/${o.steps.length} steps)</option>`).join('')}
        </select>
        ${!open.length ? '<div class="hint">Tip: add your assignment in the <b>Homework</b> tab and it gets split into tiny steps.</div>' : ''}
      </div>
      ${next ? `<div class="next-step">First up: <b>${esc(next.text)}</b></div>` : ''}
      <label class="check"><input type="checkbox" id="opt-pledge" ${pledge ? 'checked' : ''}><span>📱 My phone is in another room or face down <b>(+25% Light)</b></span></label>
      ${S.web ? '' : `<label class="check"><input type="checkbox" id="opt-paper" ${paperMode ? 'checked' : ''}><span>📖 I'm working on paper or reading a book (skip the "you haven't moved" checks)</span></label>`}
      <button class="btn gold big" data-a="start" style="width:100%">▶ Start focus session</button>
      <p class="muted" style="font-size:13px;margin-top:10px">${S.web
        ? `A study buddy window keeps you company${S.web.canFloat ? ' and floats on top of your other windows' : ''}. This copy can't see your other windows, so it runs on trust: every 10 minutes or so, Wick checks that you're still at it.`
        : 'A study buddy window keeps you company. Social media, games and Discord get a warning, then cost you Light, then get minimized.'}</p>
    </div>`;

  const d = S.daily;
  const tasks = d.tasks.map(t => `
    <div class="task ${t.claimed ? 'done' : ''}">
      <div><div class="title">${esc(t.text)}</div><div class="reward">${rewardText(t.reward)}</div></div>
      <div>${t.claimed ? '✅' : t.done ? `<button class="btn gold small" data-a="claim" data-id="${t.id}">Claim!</button>`
        : `<span class="muted">${t.minutes ? `${Math.floor(t.progress / 60)}/${t.goal / 60} min` : `${t.progress}/${t.goal}`}</span>`}</div>
      <div class="bar"><i style="width:${Math.round((100 * t.progress) / t.goal)}%"></i></div>
    </div>`).join('');
  const bonus = d.bonus_claimed ? '<p class="muted">🎁 Daily chest opened. See you tomorrow!</p>'
    : d.all_claimed ? '<button class="btn gold" data-a="bonus" style="width:100%">🎁 Open the daily chest (+1 ⭐ +10 ✦)</button>'
      : '<p class="muted">Finish all three for a bonus chest 🎁</p>';
  const daily = `<div class="card paper"><h2>📜 Daily quests</h2>${tasks}<div style="margin-top:10px">${bonus}</div></div>`;

  const todayMin = Math.floor(S.today.focus / 60);
  const streak = `<div class="card paper"><h2>Streak</h2>
    <div class="row"><div class="streak-big">🔥 ${S.streak}</div>
      <div class="muted">day${S.streak === 1 ? '' : 's'} in a row<br>Focus 15+ minutes a day to keep it going.</div></div>
    <p style="margin-top:12px">Today: <b>${Math.min(15, todayMin)}/15 min</b></p>
    <div class="bar"><i style="width:${Math.min(100, Math.round((S.today.focus / 900) * 100))}%"></i></div>
    <div class="milestones">${S.streak_rewards.map(r => `<div class="milestone ${r.claimed ? 'claimed' : r.ready ? 'ready' : ''}">
      ${r.days} days · ${rewardText(r.reward)} ${r.ready && !r.claimed ? `<button class="btn gold small" data-a="streak" data-days="${r.days}">Claim</button>` : r.claimed ? '✓' : ''}</div>`).join('')}</div>
  </div>`;

  const log = (S.log || []).slice(-5).reverse().map(l => `<div>${esc(l.quest || 'Free session')} · ${fmt(l.focus_s)} · ✦ +${l.light_earned}${l.light_lost ? ` −${l.light_lost}` : ''} · ${l.steps_done} step${l.steps_done === 1 ? '' : 's'}${l.clean ? ' · ✨ clean' : ''}</div>`).join('');
  const today = `<div class="card paper"><h2>📊 Today</h2>
    <div class="stat-row"><div class="stat"><b>${fmt(S.today.focus)}</b>focused</div>
    <div class="stat"><b>${S.today.steps}</b>steps done</div><div class="stat"><b>${S.wallet.light}</b>✦ Light</div></div>
    ${log ? `<h3>Recent sessions</h3><div class="log">${log}</div>` : ''}</div>`;

  const nCh = (S.chests.study || 0) + (S.chests.golden || 0);
  const how = `<div class="card paper"><h2>🏮 How it works</h2>
    <p><b>1.</b> Start a focus session. Every focused minute earns <b>✦ Light</b> (more the longer you stay locked in).</p>
    <p><b>2.</b> Every homework step gives a <b>🎁 Study Chest</b>, and every finished assignment a <b>🏆 Golden Chest</b> and a <b>⭐ Star Piece</b>. Open them in the Adventure (ESC → Study chests).</p>
    <p><b>3.</b> Your adventure partner studies with you: their <b>💛 Bond</b> grows with every focused minute and powers up their Team Attack.</p>
    <p><b>4.</b> Light fuels Wick's lantern in the <b>Adventure</b>. Play on breaks or after you're done. Some secret areas only open after hours of real focus!</p>
    <p><b>5.</b> ${S.web ? "The Gloom eats your Light if you hang around the game during focus time or leave Wick's check-ins unanswered."
      : 'The Gloom eats your Light when you open social media or games, or sit idle without saying why.'}</p>
    ${nCh ? `<p class="next-step">🎁 You have <b>${nCh}</b> chest${nCh > 1 ? 's' : ''} waiting in the Adventure!</p>` : ''}</div>`;

  $('#tab-today').innerHTML = `<div class="grid">${start}${daily}${streak}${today}${how}</div>`;
}

// ---------------------------------------------------------------- Homework
// Finished assignments tuck away into a "Completed" folder under the list (closed unless you open it, or you've
// picked one from inside it). Whether it's open is remembered in this browser.
let doneOpen = false;
try { doneOpen = localStorage.getItem('ld-done-open') === '1'; } catch (e) { /* no storage here */ }

function renderHomework() {
  const todo = S.quests.filter(x => !x.done).sort((a, b) => a.id - b.id);
  const fin = S.quests.filter(x => x.done).sort((a, b) => b.id - a.id);   // (newest first)
  if (selQuest == null || !S.quests.find(x => x.id === selQuest)) selQuest = todo.length ? todo[0].id : null;
  const q = S.quests.find(x => x.id === selQuest);
  const item = x => {
    const done = x.steps.filter(s => s.done).length;
    return `<div class="quest-item ${x.id === selQuest ? 'sel' : ''} ${x.done ? 'done' : ''}" data-a="sel-quest" data-id="${x.id}">
      <div class="t">${x.done ? '✅ ' : ''}${esc(x.title)}</div>
      <div class="m">${done}/${x.steps.length} steps${x.due ? ` · due ${esc(x.due)}` : ''}</div>
      <div class="bar"><i style="width:${Math.round((100 * done) / x.steps.length)}%"></i></div></div>`;
  };
  const open = doneOpen || !!(q && q.done);
  const folder = !fin.length ? '' : `<div class="done-folder ${open ? 'open' : ''}">
    <button class="folder-tab" data-a="toggle-done" aria-expanded="${open}">
      <span class="ico">${open ? '📂' : '📁'}</span><span class="name">Completed</span><span class="count">${fin.length}</span>
      <span class="arrow">${open ? '▾' : '▸'}</span></button>
    ${open ? `<div class="folder-body">${fin.map(item).join('')}</div>` : ''}</div>`;
  const list = (todo.length ? todo.map(item).join('')
    : S.quests.length ? '<div class="all-done">🎉 Nothing left to do! Finished work is in the folder below.</div>' : '') + folder;
  let detail;
  if (!q && S.quests.length) {
    detail = `<div class="empty">🎉 All caught up!<br>Every assignment is finished, and they're all in the 📁 Completed folder.<br><br>
      <button class="btn gold big" data-a="new-quest">+ Add an assignment</button></div>`;
  } else if (!q) {
    detail = `<div class="empty">No assignments yet.<br>Add one and it gets split into tiny, doable steps.<br><br>
      <button class="btn gold big" data-a="new-quest">+ Add an assignment</button></div>`;
  } else {
    const nextI = q.steps.findIndex(s => !s.done);
    const done = q.steps.filter(s => s.done).length;
    const active = S.session && S.session.quest && S.session.quest.id === q.id;
    detail = `<div class="card paper">
      <div class="row"><h2 style="margin:0;flex:1">${esc(q.title)}</h2>
        <button class="btn small" data-a="edit-quest">✏️ Edit</button>
        <button class="btn small" data-a="del-quest" ${active ? 'disabled' : ''}>🗑</button></div>
      ${q.due ? `<p class="muted">Due: ${esc(q.due)}</p>` : ''}
      <div class="files">${(q.files || []).map(f => fileChip(f, 'detach-file', `data-id="${esc(f.id)}"`)).join('')}
        <button class="btn small" data-a="attach-files" title="Attach the assignment sheet, rubric, slides…">📎 ${(q.files || []).length ? 'Attach more' : 'Attach files'}</button>
        <input type="file" id="hw-file" multiple hidden></div>
      <div class="bar" style="margin-top:10px"><i style="width:${Math.round((100 * done) / q.steps.length)}%"></i></div>
      <ul class="steps">${q.steps.map((s, i) => `<li class="${s.done ? 'done' : ''} ${i === nextI ? 'next' : ''}" data-a="toggle-step" data-i="${i}">
        <input type="checkbox" ${s.done ? 'checked' : ''} tabindex="-1"><span>${esc(s.text)}</span></li>`).join('')}</ul>
      <div class="row">${q.done ? '<b>🎉 Finished! That earned you a ⭐ Star Piece.</b>'
        : active ? '<b>🔥 You are focusing on this right now.</b>'
          : `<button class="btn gold big" data-a="start-this" ${S.session ? 'disabled' : ''}>▶ Focus on this</button>
             <span class="muted">${S.session ? 'Finish your current session first.' : 'Check off steps in the buddy window to earn bonus Light.'}</span>`}</div>
    </div>`;
  }
  $('#tab-homework').innerHTML = `<div class="hw">
    <div class="hw-list"><button class="btn gold" data-a="new-quest">+ New assignment</button>${list}</div>
    <div>${detail}</div></div>`;
}

function openEditor(q) {
  editing = q ? q.id : null;
  modal = 'editor';
  $('#modal-card').innerHTML = `<h2>${q ? 'Edit assignment' : 'New assignment'}</h2>
    <div class="field"><label>Name</label><input type="text" id="ed-title" placeholder="e.g. Essay 2: Climate policy" value="${esc(q ? q.title : '')}"></div>
    <div class="field"><label>Due (optional)</label><input type="text" id="ed-due" placeholder="e.g. Fri 11:59pm" value="${esc(q ? q.due : '')}"></div>
    <div class="field"><label>Instructions (optional, but pasting them in makes the breakdown much better)</label>
      <textarea id="ed-details" rows="4" placeholder="Paste the assignment prompt or rubric here">${esc(q ? q.details : '')}</textarea></div>
    <div class="field"><label>Files (optional): the assignment sheet, rubric, slides, a photo of the worksheet…</label>
      <div class="drop" id="ed-drop" data-a="pick-files">📎 <b>Attach files</b> <span class="muted">or drag them here</span></div>
      <input type="file" id="ed-file" multiple hidden>
      <div class="files" id="ed-files"></div>
      ${S.web ? `<div class="hint">Files are kept in this browser (backups don't include them).</div>` : ''}</div>
    <div class="row"><button class="btn purple" data-a="breakdown">✨ Break it down for me</button><span id="ed-note" class="muted" style="font-size:13px"></span></div>
    <div class="field"><label>Steps (one per line, keep them tiny!)</label>
      <textarea id="ed-steps" rows="9" placeholder="Open the doc&#10;Read the prompt&#10;...">${esc(q ? q.steps.map(s => s.text).join('\n') : '')}</textarea></div>
    <div class="row end"><button class="btn" data-a="close-modal">Cancel</button><button class="btn gold" data-a="save-quest">Save</button></div>`;
  edFiles = (q && q.files ? q.files : []).map(f => ({ ...f, key: ++fileKey, state: 'ok' }));
  renderEdFiles();
  const drop = $('#ed-drop');
  drop.addEventListener('dragover', e => { e.preventDefault(); drop.classList.add('over'); });
  drop.addEventListener('dragleave', () => drop.classList.remove('over'));
  drop.addEventListener('drop', e => { e.preventDefault(); drop.classList.remove('over'); addEdFiles(e.dataTransfer.files); });
  $('#modal').classList.remove('hidden');
  $('#ed-title').focus();
}

function renderEdFiles() {
  const el = $('#ed-files');
  if (el) el.innerHTML = edFiles.map(f => fileChip(f, 'unpick-file', `data-key="${f.key}"`)).join('');
}

// Files picked in the editor upload right away (so ✨ Break it down can read them) and wait for Save.
function addEdFiles(list) {
  for (const file of list) {
    const f = { key: ++fileKey, name: file.name, size: file.size, state: 'up' };
    edFiles.push(f);
    if (file.size > MAX_UPLOAD) { Object.assign(f, { state: 'err', err: `too big (max ${sizeText(MAX_UPLOAD)})` }); continue; }
    uploadFile(file).then(r => Object.assign(f, r.ok ? { ...r.file, state: 'ok' } : { state: 'err', err: r.error }))
      .catch(() => Object.assign(f, { state: 'err', err: "couldn't upload" }))
      .finally(renderEdFiles);
  }
  renderEdFiles();
}

const readyFiles = () => edFiles.filter(f => f.state === 'ok').map(({ id, name, size }) => ({ id, name, size }));

// 📎 on an assignment: upload and attach in one go.
async function attachToQuest(list) {
  const q = quest();
  if (!q || !list.length) return;
  const files = [...list];
  const big = files.filter(f => f.size > MAX_UPLOAD);
  if (big.length) toast(`${big.map(f => f.name).join(', ')}: too big (max ${sizeText(MAX_UPLOAD)})`, 4000);
  const ok = files.filter(f => f.size <= MAX_UPLOAD);
  if (!ok.length) return;
  toast(ok.length > 1 ? `Uploading ${ok.length} files…` : `Uploading ${ok[0].name}…`, 60000);
  const up = [];
  for (const file of ok) {
    try {
      const r = await uploadFile(file);
      if (r.ok) up.push(r.file); else toast(`${file.name}: ${r.error || "couldn't upload"}`, 4000);
    } catch (e) { toast(`${file.name}: couldn't upload`, 4000); }
  }
  if (!up.length) return;
  await api('/api/quests/attach', { id: q.id, files: up });
  await refresh();
  toast(up.length > 1 ? `Attached ${up.length} files 📎` : `Attached ${up[0].name} 📎`);
}

function closeModal() {
  modal = null;
  editing = null;
  $('#modal').classList.add('hidden');
  rendered[tab] = null;
}

function showSummary(sum) {
  modal = 'summary';
  ackedSummary = sum.id;
  sfx('fanfare');
  $('#modal-card').innerHTML = `<h2>🌟 Session complete!</h2>
    <p>${sum.quest ? `You worked on <b>${esc(sum.quest)}</b>.` : 'Free session.'}</p>
    <div class="summary-grid">
      <div class="stat"><b>${fmt(sum.focus_s)}</b>focused</div>
      <div class="stat"><b>+${sum.light_earned} ✦</b>Light earned</div>
      <div class="stat"><b>${sum.steps_done}</b>steps done</div>
      <div class="stat"><b>−${sum.light_lost} ✦</b>lost to the Gloom</div>
      <div class="stat"><b>${sum.distractions}</b>distractions</div>
      <div class="stat"><b>${sum.clean ? '✨ Yes' : 'No'}</b>clean run</div>
    </div>
    ${sum.clean ? '<p>Clean run bonus: <b>+10 ✦</b>. No distractions at all, amazing.</p>' : sum.focus_s < 1200 ? '<p class="muted">Tip: a 20+ minute session with zero distractions earns a clean-run bonus.</p>' : ''}
    <div class="row end"><button class="btn" data-a="ack-summary">Close</button>
    <button class="btn gold" data-a="ack-summary-play">🎮 Spend Light in the Adventure</button></div>`;
  $('#modal').classList.remove('hidden');
}

// ---------------------------------------------------------------- Settings
function renderSettings() {
  const st = S.settings;
  const off = S.web ? ' hidden' : '';   // the one-file copy can't watch windows or talk to Claude
  $('#tab-settings').innerHTML = `<div class="grid">
    <div class="card paper span2${off}">
      <h2>🤖 Claude focus checks</h2>
      <p>Claude compares the window you have open with the assignment you're working on, and splits assignments into tiny steps.
        It uses <b>your own Claude account</b> through Claude Code, so there's no separate key to pay for.</p>
      <div id="ai-status" class="ai-status"><span class="dot"></span><span id="ai-text"></span></div>
      <div class="row"><button class="btn purple" data-a="ai-login">🔑 Connect my Claude account</button>
        <button class="btn" data-a="ai-recheck">↻ Check again</button></div>
      <label class="check"><input type="checkbox" id="set-ai" ${st.ai_checks ? 'checked' : ''}><span>Check whether my windows match my assignment</span></label>
      <p class="muted" style="font-size:13px">Only the window title, the app name and your assignment text are sent, and only for windows you stay on for a few seconds.
        Each answer is remembered, so the same page isn't checked twice.</p>
    </div>
    <div class="card paper">
      <h2>⏱ Focus rules</h2>
      <div class="field${off}"><label>Ask what's up after this many minutes without moving</label><input type="number" id="set-idle" min="1" max="30" value="${st.idle_minutes}"></div>
      <div class="field"><label>${S.web ? 'Remind me about my banked break every ___ minutes (0 = off)' : 'Soft check-in every ___ minutes (0 = off)'}</label><input type="number" id="set-checkin" min="0" max="120" value="${st.checkin_minutes}"></div>
      <label class="check${off}"><input type="checkbox" id="set-min" ${st.auto_minimize ? 'checked' : ''}><span>Minimize distracting apps if I stay on them</span></label>
    </div>
    <div class="card paper">
      <h2>🎵 Music & sound</h2>
      <label class="check"><input type="checkbox" id="set-music" ${music.enabled ? 'checked' : ''}><span>Game & menu music</span></label>
      <div class="field"><label for="set-music-vol">Game music volume: <span id="music-vol-num">${Math.round(music.volume * 100)}%</span></label>
        <input type="range" id="set-music-vol" min="0" max="100" step="5" value="${Math.round(music.volume * 100)}"></div>
      <div class="field"><label for="set-study">Study music (while you focus)</label>
        <select id="set-study">${[['lofi', 'Lo-fi beats'], ['piano', 'Calm piano'], ['rain', 'Rain sounds'], ['funk', '🎸 Game funk (intense lock-in)'], ['off', 'Off']]
          .map(([v, l]) => `<option value="${v}" ${(['battle', 'phonk'].includes(st.study_music) ? 'funk' : st.study_music || 'lofi') === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
      <div class="field"><label for="set-study-vol">Study music volume: <span id="study-vol-num">${st.study_vol ?? 40}%</span></label>
        <input type="range" id="set-study-vol" min="0" max="100" step="5" value="${st.study_vol ?? 40}"></div>
      <label class="check"><input type="checkbox" id="set-sound" ${st.sound !== false ? 'checked' : ''}><span>Sound effects (beeps, chimes and alerts)</span></label>
      <p class="muted" style="font-size:13px">Press <b>M</b> in the Adventure to turn game music on or off, or click <b>🎵</b> in your study buddy's window to switch study music.
        Study music goes muffled while you're off task.</p>
    </div>
    <div class="card paper${off}">
      <h2>🚫 Blocked during focus</h2>
      <p class="muted">Always blocked: social media (YouTube, TikTok, Instagram, Reddit, X, Facebook, Snapchat, Discord, WhatsApp…),
        streaming (Netflix, Hulu, Twitch…) and games (Steam, Epic, Roblox, Minecraft, browser game sites, anything in a game folder).</p>
      <div class="field"><label>Also block these words (one per line)</label>
        <textarea id="set-extra" rows="5" placeholder="e.g. spotify&#10;amazon">${esc((st.extra_block || []).join('\n'))}</textarea>
        <div class="hint">Matched against window titles and app names.</div></div>
    </div>
    <div class="card paper">
      <h2>🔄 Updates</h2>
      <p id="upd-status">${updateText(S.update || {})}</p>
    </div>
    <div class="card paper${off}">
      <h2>🖥️ App shortcut</h2>
      <p class="muted">Open Lantern Delve from the Start menu or your Desktop, like any other app. (Tip: right-click the Start menu entry to pin it to the taskbar.)</p>
      <button class="btn blue" data-a="shortcuts">Add to Start menu & Desktop</button>
    </div>
    ${S.web ? `<div class="card paper">
      <h2>💾 Your save</h2>
      <p class="muted">Your progress lives in this browser. Download a backup now and then, or to move to another browser or computer.</p>
      ${S.web.saved ? '' : `<p style="color:#c0392b"><b>This browser isn't keeping your save</b> (private windows forget everything). Download a backup before you close it.</p>`}
      <div class="row"><button class="btn blue" data-a="export-save">⬇ Download a backup</button>
        <button class="btn" data-a="import-save">⬆ Load a backup</button></div>
    </div>` : ''}
    <div class="card paper">
      <h2>🗺️ Adventure</h2>
      <p class="muted">Start the adventure over from the prologue. Your Light, coins, homework and streak are kept.</p>
      <button class="btn red" data-a="reset-adv">Reset adventure progress</button>
    </div>
  </div>
  <div class="row end" style="max-width:1200px;margin:16px auto 0"><span id="set-saved" class="muted"></span>
    <button class="btn gold big" data-a="save-settings">Save settings</button></div>`;
  renderAiStatus();
}

function renderAiStatus() {
  const el = $('#ai-status');
  if (!el) return;
  const ai = S.ai;
  const label = { ready: '✅ Connected', not_logged_in: 'Not connected yet', missing: 'Claude Code not found', checking: 'Checking…', error: 'Problem' }[ai.status] || ai.status;
  el.className = 'ai-status ' + ai.status;
  $('#ai-text').innerHTML = `<b>${label}.</b> ${esc(ai.detail || '')}`;
}

// ---------------------------------------------------------------- actions
function quest() { return S.quests.find(x => x.id === selQuest); }

const ACTIONS = {
  async start() {
    await api('/api/session/start', { quest_id: startQuest ? Number(startQuest) : null, pledge, paper: paperMode });
    sfx('start');
  },
  async 'start-this'() {
    await api('/api/session/start', { quest_id: selQuest, pledge, paper: paperMode });
    sfx('start');
  },
  async 'end-session'() { if (confirm('End this focus session?')) await api('/api/session/end', {}); },
  async 'take-break'() { await api('/api/session/break', {}); },
  async resume() { await api('/api/session/resume', {}); },
  async claim(el) {
    const r = await api('/api/daily/claim', { id: el.dataset.id });
    if (r.ok) { sfx('coin'); toast(`Claimed ${rewardText(r.reward)}`); }
  },
  async bonus() {
    const r = await api('/api/daily/bonus', {});
    if (r.ok) { sfx('fanfare'); toast(`Daily chest: ${rewardText(r.reward)}`); }
  },
  async streak(el) {
    const r = await api('/api/streak/claim', { days: Number(el.dataset.days) });
    if (r.ok) { sfx('fanfare'); toast(`Streak reward: ${rewardText(r.reward)}`); }
  },
  'new-quest'() { openEditor(null); },
  'edit-quest'() { const q = quest(); if (q) openEditor(q); },
  async 'del-quest'() {
    const q = quest();
    if (q && confirm(`Delete "${q.title}"?`)) { await api('/api/quests/delete', { id: q.id }); selQuest = null; }
  },
  'sel-quest'(el) { selQuest = Number(el.dataset.id); rendered.homework = null; },
  'toggle-done'() {
    const q = quest();
    // (closing the folder while one of its assignments is picked goes back to the first one still to do)
    if (doneOpen || (q && q.done)) { doneOpen = false; if (q && q.done) selQuest = null; } else doneOpen = true;
    try { localStorage.setItem('ld-done-open', doneOpen ? '1' : '0'); } catch (e) { /* no storage here */ }
    sfx('select');
    rendered.homework = null;
  },
  async 'toggle-step'(el) {
    const q = quest();
    if (q) await api('/api/quests/toggle', { id: q.id, index: Number(el.dataset.i) });
  },
  async 'update-now'() {
    const r = await api('/api/update/restart', {});
    if (r.ok) toast(S.web ? 'Loading the new version…' : 'Restarting with the new version… (the window reopens in a few seconds)', 8000);
    else toast("Couldn't restart right now. It'll install next time you open Lantern Delve.");
  },
  'update-hide'() { hiddenUpdate = (S.update || {}).version; renderUpdateBar(); },
  'pick-files'() { $('#ed-file').click(); },
  'unpick-file'(el) { edFiles = edFiles.filter(f => f.key !== Number(el.dataset.key)); renderEdFiles(); },
  async 'open-file'(el) {
    const r = await openFile(el.dataset.id);
    if (!r.ok) toast(r.error || "Couldn't open that file.");
  },
  'attach-files'() { $('#hw-file').click(); },
  async 'detach-file'(el) {
    const q = quest(), f = q && (q.files || []).find(x => x.id === el.dataset.id);
    if (f && confirm(`Remove "${f.name}" from this assignment? (It gets deleted from Lantern Delve's folder.)`)) {
      await api('/api/quests/detach', { id: q.id, file: f.id });
    }
  },
  async breakdown(el) {
    const title = $('#ed-title').value.trim();
    if (!title) { $('#ed-note').textContent = 'Give it a name first!'; return; }
    if (edFiles.some(f => f.state === 'up')) { $('#ed-note').textContent = 'One sec, your files are still uploading…'; return; }
    el.disabled = true;
    const files = readyFiles();
    $('#ed-note').textContent = files.length && S.ai.status === 'ready'
      ? `Reading your file${files.length > 1 ? 's' : ''} and splitting it into tiny steps… (this can take a minute)`
      : 'Splitting it into tiny steps…';
    try {
      const r = await api('/api/breakdown', { title, details: $('#ed-details').value, files });
      $('#ed-steps').value = r.steps.join('\n');
      $('#ed-note').textContent = r.note;
    } catch (e) {
      $('#ed-note').textContent = "Couldn't break it down right now. Try again, or write steps yourself.";
    }
    el.disabled = false;
  },
  async 'save-quest'() {
    if (edFiles.some(f => f.state === 'up')) { toast('One sec, your files are still uploading…'); return; }
    const old = editing != null ? S.quests.find(q => q.id === editing) : null;
    const doneSet = new Set(old ? old.steps.filter(s => s.done).map(s => s.text) : []);
    const steps = $('#ed-steps').value.split('\n').map(s => s.trim()).filter(Boolean).map(text => ({ text, done: doneSet.has(text) }));
    const r = await api('/api/quests/save', {
      quest: { id: editing, title: $('#ed-title').value.trim(), due: $('#ed-due').value.trim(), details: $('#ed-details').value,
        steps, files: readyFiles() },
    });
    if (!r.ok) { alert(r.error || "Couldn't save."); return; }
    selQuest = r.id;
    closeModal();
    toast('Saved!');
  },
  'close-modal'() { closeModal(); },
  async 'ack-summary'() { await api('/api/summary/ack', {}); closeModal(); },
  async 'ack-summary-play'() { await api('/api/summary/ack', {}); closeModal(); switchTab('adventure'); },
  async 'save-settings'() {
    await api('/api/settings', {
      idle_minutes: Number($('#set-idle').value) || 3,
      checkin_minutes: Number($('#set-checkin').value) || 0,
      auto_minimize: $('#set-min').checked,
      sound: $('#set-sound').checked,
      ai_checks: $('#set-ai').checked,
      extra_block: $('#set-extra').value.split('\n').map(s => s.trim()).filter(Boolean),
    });
    $('#set-saved').textContent = 'Saved ✓';
    sfx('select');
  },
  async 'ai-login'() {
    const r = await api('/api/ai/login', {});
    if (!r.ok) { toast('Claude Code was not found on this PC.'); return; }
    toast('A login window opened. Log in with your Claude account there.', 5000);
    let tries = 0;
    const again = async () => {
      const st = await api('/api/ai/recheck', {});
      if (st.status !== 'ready' && ++tries < 20) setTimeout(again, 8000);
      else if (st.status === 'ready') { toast('Claude connected! ✅'); sfx('fanfare'); }
    };
    setTimeout(again, 8000);
  },
  async 'ai-recheck'() { const st = await api('/api/ai/recheck', {}); toast(st.detail || st.status); },
  async shortcuts() { await api('/api/shortcuts', {}); toast('Added! Look for "Lantern Delve" in your Start menu and on your Desktop.', 5000); },
  async 'reset-adv'() {
    if (!confirm('Reset your adventure progress? (Homework, Light, coins and streak are kept.)')) return;
    await api('/api/reset_adventure', {});
    if (adventure) adventure.reset();
    toast('Adventure reset.');
  },
  // one-file copy only: the save lives in the browser, so these move it in and out as a file
  async 'export-save'() {
    const r = await api('/api/save/export', {});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([JSON.stringify(r.data)], { type: 'application/json' }));
    a.download = `Lantern Delve save ${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 10000);
  },
  'import-save'() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json,application/json';
    input.onchange = async () => {
      try {
        const r = await api('/api/save/import', { data: JSON.parse(await input.files[0].text()) });
        if (!r.ok) { toast(r.error); return; }
        toast('Backup loaded!');
        setTimeout(() => location.reload(), 800);
      } catch (e) { toast("That file isn't a Lantern Delve save."); }
    };
    input.click();
  },
};

document.addEventListener('click', async e => {
  const tabBtn = e.target.closest('#tabs button');
  if (tabBtn) { switchTab(tabBtn.dataset.tab); return; }
  if (e.target.id === 'modal' && modal === 'editor') return;
  const el = e.target.closest('[data-a]');
  if (!el || !ACTIONS[el.dataset.a]) return;
  if (el.closest('#game-root')) return;
  e.preventDefault();
  try { await ACTIONS[el.dataset.a](el); } catch (err) { toast('Something went wrong: ' + err.message); }
  rendered[tab] = null;
  await refresh();
});

document.addEventListener('change', e => {
  if (e.target.id === 'ed-file') { addEdFiles(e.target.files); e.target.value = ''; }
  if (e.target.id === 'hw-file') { const list = [...e.target.files]; e.target.value = ''; attachToQuest(list); }
  if (e.target.id === 'start-quest') { startQuest = e.target.value; rendered.today = null; renderTab(); }
  if (e.target.id === 'opt-pledge') pledge = e.target.checked;
  if (e.target.id === 'opt-paper') paperMode = e.target.checked;
  // music & sound settings take effect (and save) right away
  if (e.target.id === 'set-music') { music.setEnabled(e.target.checked, true); api('/api/settings', { music: e.target.checked }); }
  if (e.target.id === 'set-music-vol') api('/api/settings', { music_vol: Number(e.target.value) });
  if (e.target.id === 'set-study') api('/api/settings', { study_music: e.target.value });
  if (e.target.id === 'set-study-vol') api('/api/settings', { study_vol: Number(e.target.value) });
  if (e.target.id === 'set-sound') { setSound(e.target.checked); api('/api/settings', { sound: e.target.checked }); }
});

document.addEventListener('input', e => {
  if (e.target.id === 'set-study-vol') $('#study-vol-num').textContent = `${e.target.value}%`;
  if (e.target.id !== 'set-music-vol') return;
  $('#music-vol-num').textContent = `${e.target.value}%`;
  music.setVolume(Number(e.target.value) / 100, true);
});

document.addEventListener('keydown', e => {
  if (start && !modal) {
    const go = { Enter: 'today', ' ': 'today', 1: 'today', 2: 'homework', 3: 'adventure', 4: 'settings' }[e.key];
    if (go) { e.preventDefault(); leaveStart(go); }
    return;
  }
  if (e.key === 'Escape' && modal === 'editor') closeModal();
});

// ---------------------------------------------------------------- the start menu
// Opening Lantern Delve shows a title screen first, instead of dropping you straight into Today. Opening it on a
// tab (#adventure, say, or the buddy window asking for one) skips it, and so does a focus session's summary.
let start = null;
function showStart() {
  document.body.insertAdjacentHTML('beforeend', `<div id="start" class="start">
    <div class="start-inner">
      <canvas id="start-art" width="560" height="250"></canvas>
      <h1 class="start-title">Lantern <span>Delve</span></h1>
      <p class="start-sub">a homework adventure</p>
      <p class="start-hi">${greeting()}</p>
      <div class="start-btns">
        <button class="sbtn primary" data-go="today"><span class="i">🌅</span><b>Today</b><small>Start a focus session</small></button>
        <button class="sbtn" data-go="homework"><span class="i">📚</span><b>Homework</b><small>Your assignments</small></button>
        <button class="sbtn" data-go="adventure"><span class="i">🗺️</span><b>Adventure</b><small>Spend your Light</small></button>
        <button class="sbtn" data-go="settings"><span class="i">⚙️</span><b>Settings</b><small>Music, sound, updates</small></button>
      </div>
      <p class="start-stats" id="start-stats"></p>
      <p class="start-keys">Enter: Today · 1 2 3 4 to pick</p>
    </div></div>`);
  start = { el: $('#start') };
  start.el.addEventListener('click', e => { const b = e.target.closest('[data-go]'); if (b) leaveStart(b.dataset.go); });
  drawStartArt();
}

function greeting() {
  const h = new Date().getHours();
  return h < 5 ? '🌙 Up late? Wick will keep you company.' : h < 12 ? '☀️ Good morning! Ready to light the way?'
    : h < 18 ? '🌤️ Good afternoon! Ready to light the way?' : '🌙 Good evening! Ready to light the way?';
}

function renderStartStats() {
  const el = start && $('#start-stats');
  if (!el || !S) return;
  const left = S.quests.filter(q => !q.done).length;
  const bits = [`✦ ${S.wallet.light} Light`, S.streak > 0 ? `🔥 ${S.streak}-day streak` : '🔥 start a streak today',
    left ? `📚 ${left} assignment${left > 1 ? 's' : ''} to do` : S.quests.length ? '📚 all caught up' : '📚 no assignments yet'];
  if (S.session) bits.unshift(S.session.mode === 'break' ? '☕ on a break' : '🔥 focusing right now');
  const t = bits.join('  ·  ');
  if (el.textContent !== t) el.textContent = t;
}

function leaveStart(name) {
  if (!start) return;
  const el = start.el;
  start = null;
  el.classList.add('hide');
  setTimeout(() => el.remove(), 400);
  if (name) { sfx('select'); switchTab(name); }
}

// Wick and a lamppost on a little hill, with motes of light drifting up
async function drawStartArt() {
  let art;
  try { art = await import('./art.js'); } catch (e) { return; }
  const cv = $('#start-art');
  if (!cv) return;
  const c = cv.getContext('2d');
  const motes = Array.from({ length: 16 }, () => ({ x: Math.random() * 560, y: Math.random() * 250, v: 12 + Math.random() * 20, r: 1.5 + Math.random() * 2, p: Math.random() * 6 }));
  let last = performance.now();
  const frame = now => {
    if (!start || !cv.isConnected) return;
    const t = now / 1000, dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    c.clearRect(0, 0, cv.width, cv.height);
    art.glowDot(c, 300, 165, 150, '255,200,110', 0.16 + Math.sin(t * 2) * 0.03);
    c.fillStyle = '#2c2350'; c.beginPath(); c.ellipse(290, 272, 240, 62, 0, 0, Math.PI * 2); c.fill();
    c.strokeStyle = 'rgba(255,255,255,0.08)'; c.lineWidth = 2; c.beginPath(); c.ellipse(290, 272, 240, 62, 0, Math.PI, Math.PI * 2); c.stroke();
    art.drawLamp(c, 372, 226, { t, lit: true });
    art.drawWick(c, 236, 226, { t, scale: 1.45, mood: 'happy', flame: 1.35, hammer: false });
    for (const m of motes) {
      m.y -= m.v * dt;
      if (m.y < -10) { m.y = 255; m.x = Math.random() * 560; }
      art.glowDot(c, m.x + Math.sin(t * 1.3 + m.p) * 9, m.y, m.r * 5, '255,224,140', 0.55);
    }
    requestAnimationFrame(frame);
  };
  requestAnimationFrame(frame);
}

if (!location.hash) showStart();
switchTab(tab);
poll();
