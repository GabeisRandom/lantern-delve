// Background music: a little paper orchestra synthesized live with Web Audio (no audio files).
// The songs themselves are written out as note strings and chord charts in songs.js.
import { SONGS } from './songs.js';

const LOOKAHEAD = 0.3;   // seconds of music scheduled ahead of the playhead
const MASTER = 0.4;   // keeps the music under the sound effects (the compressor adds some makeup gain)
const DUR = { w: 4, h: 2, q: 1, e: 0.5, s: 0.25, t: 1 / 3 };
const PC = { c: 0, d: 2, e: 4, f: 5, g: 7, a: 9, b: 11 };
const QUAL = {
  '': [0, 4, 7], m: [0, 3, 7], 7: [0, 4, 7, 10], maj7: [0, 4, 7, 11], m7: [0, 3, 7, 10], 6: [0, 4, 7, 9], m6: [0, 3, 7, 9],
  dim: [0, 3, 6], dim7: [0, 3, 6, 9], m7b5: [0, 3, 6, 10], aug: [0, 4, 8], sus4: [0, 5, 7], sus2: [0, 2, 7],
  '7sus4': [0, 5, 7, 10], 9: [0, 4, 7, 10, 14], maj9: [0, 4, 7, 11, 14], m9: [0, 3, 7, 10, 14], add9: [0, 4, 7, 14],
  madd9: [0, 3, 7, 14], '7b9': [0, 4, 7, 10, 13], mmaj7: [0, 3, 7, 11],
};
const CHORD = /^([A-G])(#|b)?(maj9|maj7|mmaj7|m7b5|madd9|m9|m7|m6|m|dim7|dim|aug|7sus4|sus4|sus2|7b9|add9|9|7|6)?(?:\/([A-G])(#|b)?)?$/;
const TOKEN = /^(\[[a-g#b\d-]+\]|[a-g](?:#|b)?-?\d|r|~)([whqest]*)(\.?)([>'?]*)$/;
const VEL = { X: 1, x: 0.78, o: 0.42 };
const PLUCK = { harp: [2.2, 0.55, 0.6], guitar: [1.5, 0.42, 0.55], koto: [1.4, 0.9, 0.6], pizz: [0.45, 0.32, 0.55], harpsi: [1, 0.85, 0.6], funkgtr: [0.8, 0.8, 0.5] };

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const mtof = m => 440 * Math.pow(2, (m - 69) / 12);
const acc = s => (s === '#' ? 1 : s === 'b' ? -1 : 0);
const pcOf = m => ((m % 12) + 12) % 12;
const avg = v => v.reduce((a, x) => a + x, 0) / v.length;
const hash = i => { const x = Math.sin(i * 12.9898) * 43758.5453; return x - Math.floor(x); };

let ac = null;        // the AudioContext everything plays into (swapped out for offline renders)
let master = null;
let vol = 0.6, on = false, touched = 0;   // silent until the player's settings arrive (applySettings)
let current = null, sting = null, want = null;
let stayOn = false, ducked = false;
let energy = 0.5;     // 0..1, handed to song generators (battle-mode study music builds with your focus combo)
const resumeAt = {};  // where each area song left off, so it picks up again after a battle
const compiled = {};

// ---------------------------------------------------------------- reading the notation
function pitch(s) {
  const m = /^([a-g])(#|b)?(-?\d)$/.exec(s);
  return 12 * (Number(m[3]) + 1) + PC[m[1]] + acc(m[2]);
}

function parseNotes(str, meter, warn) {
  const notes = [];
  let beat = 0, dur = 1, last = null;
  str.split('|').map(s => s.trim()).filter(Boolean).forEach((bar, i) => {
    const start = beat;
    for (const tok of bar.split(/\s+/)) {
      const m = TOKEN.exec(tok);
      if (!m) { warn(`bad note "${tok}" in bar ${i + 1}`); continue; }
      if (m[2]) dur = [...m[2]].reduce((a, c) => a + DUR[c], 0) * (m[3] ? 1.5 : 1);
      if (m[1] === '~') { if (last) last.d += dur; }
      else if (m[1] === 'r') last = null;
      else {
        const ps = m[1][0] === '[' ? m[1].match(/[a-g](?:#|b)?-?\d/g).map(pitch) : [pitch(m[1])];
        last = { b: beat, d: dur, ps, mod: m[4] };
        notes.push(last);
      }
      beat = Math.round((beat + dur) * 48) / 48;
    }
    if (Math.abs(beat - start - meter) > 1e-6) warn(`bar ${i + 1} lasts ${+(beat - start).toFixed(3)} beats`);
  });
  return { notes, beats: beat };
}

function parseChords(str, meter, warn) {
  const out = [];
  let beat = 0, prev = [];
  str.split('|').map(s => s.trim()).filter(Boolean).forEach((bar, i) => {
    let toks = bar.split(/\s+/);
    if (toks.length === 1 && toks[0] === '%') toks = prev;
    prev = toks;
    const slot = meter / toks.length;
    for (const tok of toks) {
      const m = CHORD.exec(tok);
      if (tok === '.' && out.length) out[out.length - 1].d += slot;
      else if (!m) warn(`bad chord "${tok}" in bar ${i + 1}`);
      else {
        const root = pcOf(PC[m[1].toLowerCase()] + acc(m[2]));
        const bass = m[4] ? pcOf(PC[m[4].toLowerCase()] + acc(m[5])) : root;
        out.push({ b: beat, d: slot, root, bass, iv: QUAL[m[3] || ''] });
      }
      beat += slot;
    }
  });
  return { chords: out, beats: beat };
}

// ---------------------------------------------------------------- turning a song into a list of notes
function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function chordAt(chords, b) {
  let lo = 0, hi = chords.length - 1, r = chords[0];
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (chords[mid].b <= b + 1e-9) { r = chords[mid]; lo = mid + 1; } else hi = mid - 1;
  }
  return r;
}

// the midi note with pitch class pc in [lo, hi] closest to ref
function near(pc, ref, [lo, hi]) {
  let best = null;
  for (let m = lo; m <= hi; m++) if (pcOf(m) === pc && (best == null || Math.abs(m - ref) < Math.abs(best - ref))) best = m;
  return best ?? lo + pcOf(pc - lo);
}

function below(pc, m) { while (pcOf(m) !== pc) m--; return m; }

// A chord voicing inside [lo, hi] that moves as little as possible from the last one.
function voicing(ch, [lo, hi], prev, opt) {
  let iv = ch.iv.slice();
  if (iv.length >= 5) iv = iv.filter(x => x !== 7);
  if (opt.rootless && iv.length >= 4) iv = iv.filter(x => x !== 0);
  const pcs = [...new Set(iv.map(x => (ch.root + x) % 12))];
  const mid = (lo + hi) / 2;
  let best = null, score = Infinity;
  for (let r = 0; r < pcs.length; r++) {
    const order = pcs.slice(r).concat(pcs.slice(0, r));
    for (let base = lo + pcOf(order[0] - lo); base <= hi; base += 12) {
      const v = [base];
      for (let i = 1; i < order.length; i++) { let x = v[i - 1] + 1; while (pcOf(x) !== order[i]) x++; v.push(x); }
      if (v[v.length - 1] > hi) continue;
      let s = Math.abs(avg(v) - mid) * 0.3;
      if (prev && prev.length === v.length) s += v.reduce((a, x, i) => a + Math.abs(x - prev[i]), 0);
      else if (prev && prev.length) s += Math.abs(avg(v) - avg(prev)) * 2;
      if (s < score) { score = s; best = v; }
    }
  }
  return best || [lo + pcOf(ch.root - lo)];
}

// Bass degrees: R/8/-8 follow the bass note (slash chords too); the rest are counted from the chord's root.
function degree(ch, deg, st) {
  const has = x => ch.iv.includes(x);
  const third = has(3) ? 3 : has(4) ? 4 : has(5) ? 5 : 2;
  const fifth = has(7) ? 7 : has(6) ? 6 : has(8) ? 8 : 7;
  const sev = has(10) ? 10 : has(11) ? 11 : has(9) ? 9 : 10;
  const R = st.rootM, B = st.bassM;
  return { R: B, 8: B + 12, '-8': B - 12, 3: R + third, 5: R + fifth, 7: R + sev, 6: R + 9, 9: R + 14,
    '-5': R + fifth - 12, '-7': R + sev - 12, 10: R + third + 12 }[deg] ?? B;
}

function genPart(ctx, s, pid, part, c, out, st) {
  const { meter, song } = ctx;
  const warn = m => ctx.warn(`${s.sid}.${pid}: ${m}`);
  const push = e => out.push({ part: pid, ...e, b: e.b + s.at });
  const bars = Math.round(s.len / meter);
  const at = b => chordAt(ctx.chords, s.at + b);
  if (part.kit) {
    const names = String(c).split(/\s+/);
    for (let i = 0; i < bars; i++) {
      const name = names[i % names.length], pat = song.drums[name];
      if (!pat) { if (name !== '-') warn(`no drum pattern "${name}"`); continue; }
      for (const [voice, steps] of Object.entries(pat)) {
        for (let k = 0; k < steps.length; k++) {
          const v = VEL[steps[k]];
          if (v) push({ b: i * meter + (k * meter) / steps.length, drum: voice, v, p: hash(s.at * 7 + i * 31 + k) });
        }
      }
    }
    return;
  }
  if (Array.isArray(c.ev)) {   // ready-made notes from a song generator
    for (const n of c.ev) push({ b: n.b, d: n.d, m: n.m, v: n.v ?? 0.7, gate: part.gate || 0.92, mel: 1 });
    return;
  }
  if (typeof c === 'string' || typeof c.n === 'string') {
    const { notes, beats } = parseNotes(c.n || c, meter, warn);
    if (Math.abs(beats - s.len) > 1e-6) warn(`lasts ${beats} beats but the section is ${s.len}`);
    for (const n of notes) {
      const v = n.mod.includes('>') ? 1 : n.mod.includes('?') ? 0.55 : 0.8;
      const gate = n.mod.includes("'") ? 0.45 : part.gate || 0.92;
      for (const m of n.ps) push({ b: n.b, d: n.d, m: m + (c.tr || 0), v, gate, mel: 1 });
    }
    return;
  }
  if (!ctx.chords.length) { warn('needs a chord chart'); return; }
  const range = c.range || part.range || [48, 72];
  if (c.walk) {
    const rnd = rng(s.at * 977 + 13);
    for (let b = 0; b < Math.round(s.len); b++) {
      const ch = at(b), nb = s.at + b + 1;
      const nx = chordAt(ctx.chords, nb >= ctx.total ? ctx.introLen : nb);
      const ref = st.last ?? (range[0] + range[1]) / 2;
      const start = Math.abs(ch.b - (s.at + b)) < 1e-6;
      let m;
      if (start) m = near(ch.bass, ref, range);
      else if (nx !== ch || nb >= ctx.total) {
        // last beat before the chord changes: lean into the next root from a half step away
        const target = near(nx.bass, ref, range);
        m = target + (ref > target ? 1 : -1);
        if (m < range[0] || m > range[1]) m = target - (m < range[0] ? -1 : 1);
      } else {
        const pcs = ch.iv.filter(x => x > 0 && x < 12).map(x => (ch.root + x) % 12);
        const opts = [];
        for (let x = ref - 7; x <= ref + 7; x++) if (x !== ref && x >= range[0] && x <= range[1] && pcs.includes(pcOf(x))) opts.push(x);
        m = opts.length ? opts[Math.floor(rnd() * opts.length)] : ref;
      }
      push({ b, d: 0.9, m, v: start ? 0.9 : 0.72, gate: 1 });
      st.last = m;
    }
  } else if (c.bass) {
    for (let i = 0; i < bars; i++) {
      for (const [o, d, deg, v = 0.8] of c.bass) {
        const b = i * meter + o;
        if (b >= s.len - 1e-9) continue;
        const ch = at(b);
        if (st.chord !== ch) {
          st.chord = ch;
          st.bassM = near(ch.bass, st.bassM ?? (range[0] + range[1]) / 2, range);
          st.rootM = ch.bass === ch.root ? st.bassM : below(ch.root, st.bassM);
        }
        push({ b, d, m: degree(ch, deg, st), v, gate: 1 });
      }
    }
  } else if (c.comp) {
    const pats = Array.isArray(c.comp[0][0]) ? c.comp : [c.comp];
    for (let i = 0; i < bars; i++) {
      for (const [o, d, v = 0.75] of pats[i % pats.length]) {
        const b = i * meter + o;
        if (b >= s.len - 1e-9) continue;
        const notes = voicing(at(b), range, st.prev, c);
        st.prev = notes;
        notes.forEach((m, k) => push({ b, d, m, v: v * (k === notes.length - 1 ? 1 : 0.85), gate: 1, o: (c.strum || 0) * k }));
      }
    }
  } else if (c.pad) {
    const spans = [];
    for (const ch of ctx.chords) {
      if (ch.b < s.at - 1e-9 || ch.b >= s.at + s.len - 1e-9) continue;
      const lastSpan = spans[spans.length - 1];
      if (lastSpan && lastSpan.ch.root === ch.root && lastSpan.ch.bass === ch.bass && lastSpan.ch.iv === ch.iv) lastSpan.d += ch.d;
      else spans.push({ ch, b: ch.b - s.at, d: ch.d });
    }
    for (const sp of spans) {
      const notes = voicing(sp.ch, range, st.prev, c);
      st.prev = notes;
      for (const m of notes) push({ b: sp.b, d: sp.d - 0.05, m, v: 0.7, gate: 1 });
    }
  } else if (c.arp) {
    const rate = c.rate || 0.5, n = Math.round(s.len / rate), per = Math.round(meter / rate);
    let cur = null, tones = null;
    for (let k = 0; k < n; k++) {
      const b = k * rate, ch = at(b);
      if (ch !== cur) {
        cur = ch;
        const v = voicing(ch, range, st.prev, c);
        st.prev = v;
        tones = [...v, ...v.map(x => x + 12), ...v.map(x => x + 24)];
      }
      const idx = c.arp[k % c.arp.length];
      push({ b, d: rate * (c.hold || 1), m: tones[Math.min(idx, tones.length - 1)], v: k % per === 0 ? 0.85 : 0.68, gate: 1 });
    }
  } else warn('unknown part content');
}

function compile(name) {
  if (SONGS[name].make) return piece(name);
  return compiled[name] || (compiled[name] = compileSong(name, SONGS[name]));
}

// Songs with a `make(seed, energy)` (the study music) write a brand-new piece every time they come around.
function piece(name) {
  const song = SONGS[name];
  return song.make ? compileSong(name, { ...song.make((Math.random() * 2 ** 31) >>> 0, energy), fresh: true }) : compile(name);
}

function compileSong(name, song) {
  const meter = song.meter || 4;
  const warn = msg => console.warn(`[music] ${name}: ${msg}`);
  const intro = song.intro || [], order = [...intro, ...(song.loop || [])];
  const secs = [], chords = [];
  let at = 0;
  order.forEach((sid, k) => {
    const sec = song.sections[sid];
    if (!sec) { warn(`missing section ${sid}`); return; }
    const ch = sec.chords ? parseChords(sec.chords, meter, m => warn(`${sid} chords: ${m}`)) : { chords: [], beats: 0 };
    let len = ch.beats || (sec.bars || 0) * meter;
    if (!len) for (const [pid, c] of Object.entries(sec)) {
      if (song.parts[pid] && !song.parts[pid].kit && (typeof c === 'string' || (c && typeof c.n === 'string'))) {
        len = Math.max(len, parseNotes(c.n || c, meter, () => {}).beats);
      }
    }
    for (const c of ch.chords) chords.push({ ...c, b: c.b + at });
    secs.push({ sid, sec, at, len, intro: k < intro.length });
    at += len;
  });
  const introLen = secs.filter(s => s.intro).reduce((a, s) => a + s.len, 0);
  const ctx = { song, meter, chords, total: at, introLen, warn };
  const events = [], state = {};
  for (const s of secs) {
    for (const [pid, part] of Object.entries(song.parts)) {
      const c = s.sec[pid];
      if (c != null) genPart(ctx, s, pid, part, c, events, state[pid] || (state[pid] = {}));
    }
  }
  events.sort((a, b) => a.b - b.b);
  const once = !!song.once;
  return {
    name, song, meter, chords, total: at, introLen: once ? at : introLen, loopLen: once ? 0 : at - introLen,
    intro: once ? events : events.filter(e => e.b < introLen - 1e-9),
    loop: once ? [] : events.filter(e => e.b >= introLen - 1e-9).map(e => ({ ...e, b: e.b - introLen })),
  };
}

// ---------------------------------------------------------------- synth building blocks
const cache = () => ac._ld || (ac._ld = { ks: {}, ir: {}, noise: null, pulse: null });

function noiseBuffer() {
  const C = cache();
  if (!C.noise) {
    const n = ac.sampleRate;
    C.noise = ac.createBuffer(1, n, n);
    const d = C.noise.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
  }
  return C.noise;
}

function pulseWave() {
  const C = cache();
  if (!C.pulse) {
    const N = 48, re = new Float32Array(N), im = new Float32Array(N);
    for (let k = 1; k < N; k++) { re[k] = Math.sin(2 * Math.PI * k * 0.25) / (Math.PI * k); im[k] = (1 - Math.cos(2 * Math.PI * k * 0.25)) / (Math.PI * k); }
    C.pulse = ac.createPeriodicWave(re, im);
  }
  return C.pulse;
}

function osc(type, f, t, end) {
  const o = ac.createOscillator();
  if (type === 'pulse') o.setPeriodicWave(pulseWave()); else o.type = type;
  o.frequency.setValueAtTime(f, t);
  o.start(t);
  o.stop(end);
  return o;
}

function noise(t, end) {
  const s = ac.createBufferSource();
  s.buffer = noiseBuffer();
  s.loop = true;
  s.start(t, Math.random() * 0.8);
  s.stop(end);
  return s;
}

function gain(v = 0) { const g = ac.createGain(); g.gain.value = v; return g; }
function filt(type, f, q = 0.7) { const b = ac.createBiquadFilter(); b.type = type; b.frequency.value = f; b.Q.value = q; return b; }
function cleanup(src, nodes) { src.onended = () => { for (const n of nodes) n.disconnect(); }; }

// percussive: instant attack, then fades over about `ring` seconds
function hit(p, t, peak, ring) {
  p.setValueAtTime(0, t);
  p.linearRampToValueAtTime(peak, t + 0.004);
  p.setTargetAtTime(0, t + 0.004, ring / 3);
}

// held: attack, decay to a sustain level, then release when the note ends
function adsr(p, t, peak, a, dec, sus, rel, len) {
  p.setValueAtTime(0, t);
  p.linearRampToValueAtTime(peak, t + a);
  if (sus !== 1) p.setTargetAtTime(peak * sus, t + a, dec / 3);
  p.setTargetAtTime(0, t + Math.max(len, a + 0.02), rel / 3);
}

function damp(p, at, rel) { p.setTargetAtTime(0, at, rel / 3); }

// a slow wobble in pitch (cents) that fades in after `delay` (skipped for notes too short to hear it)
function vibrato(oscs, t, end, rate, cents, delay) {
  if (delay > 0 && end - t < delay + 0.45) return [];
  const l = osc('sine', rate, t, end), g = gain(0);
  g.gain.setValueAtTime(0, t + delay);
  g.gain.linearRampToValueAtTime(cents, t + delay + 0.3);
  l.connect(g);
  for (const o of oscs) g.connect(o.detune);
  return [l, g];
}

function slide(oscs, n) {
  if (n.from == null || !n.glide || n.from === n.m) return;
  for (const o of oscs) {
    o.detune.setValueAtTime((n.from - n.m) * 100, n.t);
    o.detune.linearRampToValueAtTime(0, n.t + n.glide);
  }
}

function breath(n, end, f, q, level) {
  const s = noise(n.t, end), bp = filt('bandpass', f, q), g = gain();
  adsr(g.gain, n.t, level * n.v, 0.02, 0.1, 0.35, 0.1, n.d);
  s.connect(bp).connect(g).connect(n.out);
  return [s, bp, g];
}

// Karplus-Strong plucked string, rendered once per pitch. The buffer's sample rate is picked so the
// loop length is a whole number of samples, which keeps every pitch exactly in tune.
function ksBuffer(m, kind) {
  const C = cache(), id = kind + m;
  if (C.ks[id]) return C.ks[id];
  const [secs, bright] = PLUCK[kind];
  const f = mtof(m), N = Math.max(4, Math.round(32000 / f - 0.5)), rate = (N + 0.5) * f;
  const len = Math.ceil(rate * secs), d = new Float32Array(len);
  let lp = 0, mean = 0;
  for (let i = 0; i <= N; i++) { lp += (Math.random() * 2 - 1 - lp) * bright; d[i] = lp; mean += lp; }
  mean /= N + 1;
  for (let i = 0; i <= N; i++) d[i] -= mean;
  const loss = Math.pow(0.001, 1 / (secs * f));
  for (let i = N + 1; i < len; i++) d[i] = loss * 0.5 * (d[i - N] + d[i - N - 1]);
  let peak = 0;
  for (let i = 0; i < len; i++) peak = Math.max(peak, Math.abs(d[i]));
  if (peak > 0) for (let i = 0; i < len; i++) d[i] /= peak;
  const buf = ac.createBuffer(1, len, rate);
  buf.getChannelData(0).set(d);
  return (C.ks[id] = buf);
}

function pluck(n, kind, m = n.m, level = 1) {
  const t = n.t, s = ac.createBufferSource(), g = gain(PLUCK[kind][2] * n.v * level);
  s.buffer = ksBuffer(m, kind);
  if (kind === 'koto') { s.playbackRate.setValueAtTime(1.012, t); s.playbackRate.setTargetAtTime(1, t, 0.03); }
  s.connect(g).connect(n.out);
  s.start(t);
  if (kind !== 'harp' && kind !== 'koto') { damp(g.gain, t + n.d + 0.04, 0.12); s.stop(t + n.d + 0.45); }
  cleanup(s, [s, g]);
}

// A stereo room made of decaying noise, used as the reverb impulse.
function impulse(kind) {
  const C = cache();
  if (C.ir[kind]) return C.ir[kind];
  const secs = kind === 'hall' ? 3.2 : 1.7, sr = ac.sampleRate, len = Math.floor(sr * secs);
  const buf = ac.createBuffer(2, len, sr);
  for (let ch = 0; ch < 2; ch++) {
    const d = buf.getChannelData(ch);
    let lp = 0;
    for (let i = 0; i < len; i++) {
      const x = i / len;
      lp += (Math.random() * 2 - 1 - lp) * (0.75 - 0.6 * x);
      d[i] = lp * Math.pow(1 - x, kind === 'hall' ? 2.2 : 3) * Math.min(1, i / (sr * 0.012));
    }
  }
  return (C.ir[kind] = buf);
}

// ---------------------------------------------------------------- the orchestra
// Each instrument plays one note: n = { t: start time, d: length (s), m: midi note, v: velocity, out, from, glide }
const INST = {
  marimba(n) {
    const f = mtof(n.m), t = n.t, ring = clamp(0.6 - (n.m - 50) * 0.01, 0.15, 0.6), end = t + ring * 2.6;
    const a = osc('sine', f, t, end), b = osc('sine', f * 3.93, t, end), ga = gain(), gb = gain();
    hit(ga.gain, t, 0.5 * n.v, ring);
    hit(gb.gain, t, 0.09 * n.v, ring * 0.25);
    a.connect(ga).connect(n.out);
    b.connect(gb).connect(n.out);
    cleanup(a, [a, b, ga, gb]);
  },
  vibes(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 1.3;
    const a = osc('sine', f, t, end), b = osc('sine', f * 4, t, end), l = osc('sine', 5.2, t, end);
    const ga = gain(), gb = gain(), trem = gain(1), depth = gain(0.2);
    hit(ga.gain, t, 0.42 * n.v, 2.4);
    damp(ga.gain, t + n.d + 0.1, 0.35);
    hit(gb.gain, t, 0.05 * n.v, 0.3);
    l.connect(depth).connect(trem.gain);
    a.connect(ga).connect(trem);
    b.connect(gb).connect(trem);
    trem.connect(n.out);
    cleanup(a, [a, b, l, ga, gb, trem, depth]);
  },
  musicbox(n) {
    const f = mtof(n.m), t = n.t, end = t + 2.2;
    const a = osc('sine', f, t, end), b = osc('sine', f * 2, t, end), c = osc('sine', f * 6.27, t, t + 0.4);
    const ga = gain(), gb = gain(), gc = gain();
    hit(ga.gain, t, 0.36 * n.v, 1.4);
    hit(gb.gain, t, 0.07 * n.v, 0.5);
    hit(gc.gain, t, 0.05 * n.v, 0.12);
    a.connect(ga).connect(n.out);
    b.connect(gb).connect(n.out);
    c.connect(gc).connect(n.out);
    cleanup(a, [a, b, c, ga, gb, gc]);
  },
  kalimba(n) {
    const f = mtof(n.m), t = n.t, end = t + 1.6;
    const a = osc('sine', f, t, end), b = osc('triangle', f, t, t + 0.2), c = osc('sine', f * 6.27, t, t + 0.3);
    const ga = gain(), gb = gain(), gc = gain();
    hit(ga.gain, t, 0.38 * n.v, 0.7);
    hit(gb.gain, t, 0.16 * n.v, 0.05);
    hit(gc.gain, t, 0.04 * n.v, 0.06);
    a.connect(ga).connect(n.out);
    b.connect(gb).connect(n.out);
    c.connect(gc).connect(n.out);
    cleanup(a, [a, b, c, ga, gb, gc]);
  },
  glass(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 1.2;
    const a = osc('sine', f, t, end), b = osc('sine', f * 2, t, end), gb = gain(0.14), amp = gain();
    a.connect(amp);
    b.connect(gb).connect(amp);
    amp.connect(n.out);
    adsr(amp.gain, t, 0.36 * n.v, 0.06, 0.9, 0.55, 0.9, n.d);
    const v = vibrato([a, b], t, end, 4.5, 6, 0.25);
    cleanup(a, [a, b, gb, amp, ...v]);
  },
  // a mellow, slightly wobbly electric piano for lo-fi (like an old tape)
  rhodes(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 1;
    const car = osc('sine', f, t, end), mod = osc('sine', f, t, end), mg = gain(), amp = gain();
    mg.gain.setValueAtTime(f * (0.3 + 0.8 * n.v), t);
    mg.gain.setTargetAtTime(f * 0.08, t, 0.3);
    mod.connect(mg).connect(car.frequency);
    amp.gain.setValueAtTime(0, t);
    amp.gain.linearRampToValueAtTime(0.3 * n.v, t + 0.01);
    amp.gain.setTargetAtTime(0.12 * n.v, t + 0.01, 1.2);
    damp(amp.gain, t + n.d, 0.4);
    car.connect(amp).connect(n.out);
    cleanup(car, [car, mod, mg, amp, ...vibrato([car], t, end, 0.7, 7, 0)]);
  },
  // slap bass: a bright thumb-slap attack that snaps shut into a round tone (harder notes pop brighter)
  slap(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 0.15;
    const a = osc('sawtooth', f, t, end), b = osc('square', f, t, end), c = osc('sine', f, t, end);
    const gb = gain(0.5), gc = gain(0.6), lp = filt('lowpass', f * 4, 4), amp = gain();
    lp.frequency.setValueAtTime(Math.min(f * (8 + 10 * n.v), 7000), t);
    lp.frequency.setTargetAtTime(f * 2.5, t, 0.035);
    a.connect(lp);
    b.connect(gb).connect(lp);
    lp.connect(amp);
    c.connect(gc).connect(amp);
    amp.connect(n.out);
    adsr(amp.gain, t, 0.32 * n.v, 0.002, 0.18, 0.45, 0.04, n.d);
    cleanup(a, [a, b, c, gb, gc, lp, amp]);
  },
  // a bright FM lead, like the brass on an old game console
  fmlead(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 0.3;
    const car = osc('sine', f, t, end), mod = osc('sine', f, t, end), mg = gain(), amp = gain();
    mg.gain.setValueAtTime(f * 3.2, t);
    mg.gain.setTargetAtTime(f * 1.6, t, 0.12);
    mod.connect(mg).connect(car.frequency);
    car.connect(amp).connect(n.out);
    adsr(amp.gain, t, 0.2 * n.v, 0.01, 0.2, 0.75, 0.08, n.d);
    slide([car], n);
    cleanup(car, [car, mod, mg, amp, ...vibrato([car], t, end, 5.5, 12, 0.2)]);
  },
  // a soft, ringing piano
  piano(n) {
    const f = mtof(n.m), t = n.t, ring = clamp(2.8 - (n.m - 48) * 0.045, 0.7, 2.8), end = t + Math.min(n.d + 1.6, ring * 2.6 + 0.1);
    const car = osc('sine', f, t, end), mod = osc('sine', f, t, end), h2 = osc('sine', f * 2.002, t, end);
    const mg = gain(), amp = gain(), g2 = gain();
    mg.gain.setValueAtTime(f * (0.6 + 0.9 * n.v), t);
    mg.gain.setTargetAtTime(f * 0.05, t, 0.12);
    mod.connect(mg).connect(car.frequency);
    hit(amp.gain, t, 0.3 * n.v, ring);
    damp(amp.gain, t + n.d + 0.3, 0.5);
    hit(g2.gain, t, 0.06 * n.v, ring * 0.4);
    car.connect(amp).connect(n.out);
    h2.connect(g2).connect(n.out);
    cleanup(car, [car, mod, h2, mg, amp, g2]);
  },
  epiano(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 0.7;
    const car = osc('sine', f, t, end), mod = osc('sine', f, t, end), mg = gain(), amp = gain();
    mg.gain.setValueAtTime(f * (0.5 + 1.4 * n.v), t);
    mg.gain.setTargetAtTime(f * 0.2, t, 0.25);
    mod.connect(mg).connect(car.frequency);
    amp.gain.setValueAtTime(0, t);
    amp.gain.linearRampToValueAtTime(0.3 * n.v, t + 0.005);
    amp.gain.setTargetAtTime(0.09 * n.v, t + 0.005, 0.9);
    damp(amp.gain, t + n.d, 0.25);
    car.connect(amp).connect(n.out);
    cleanup(car, [car, mod, mg, amp]);
  },
  organ(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 0.3, amp = gain(), nodes = [amp], oscs = [];
    for (const [r, a] of [[1, 0.5], [2, 0.32], [3, 0.16], [4, 0.12], [6, 0.05]]) {
      const o = osc('sine', f * r, t, end), g = gain(a);
      o.connect(g).connect(amp);
      oscs.push(o);
      nodes.push(o, g);
    }
    adsr(amp.gain, t, 0.28 * n.v, 0.012, 0.1, 1, 0.08, n.d);
    amp.connect(n.out);
    cleanup(oscs[0], [...nodes, ...vibrato(oscs, t, end, 6.2, 5, 0)]);
  },
  flute(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 0.3;
    const a = osc('sine', f, t, end), b = osc('triangle', f, t, end), gb = gain(0.22), lp = filt('lowpass', Math.min(f * 5, 6000)), amp = gain();
    a.connect(lp);
    b.connect(gb).connect(lp);
    lp.connect(amp).connect(n.out);
    adsr(amp.gain, t, 0.3 * n.v, 0.05, 0.25, 0.85, 0.12, n.d);
    slide([a, b], n);
    cleanup(a, [a, b, gb, lp, amp, ...breath(n, end, f * 2, 1.2, 0.05), ...vibrato([a, b], t, end, 5, 12, 0.22)]);
  },
  ocarina(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 0.3, amp = gain();
    const a = osc('sine', f, t, end), b = osc('sine', f * 2, t, end), c = osc('sine', f * 3, t, end), gb = gain(0.07), gc = gain(0.025);
    a.connect(amp);
    b.connect(gb).connect(amp);
    c.connect(gc).connect(amp);
    amp.connect(n.out);
    adsr(amp.gain, t, 0.32 * n.v, 0.03, 0.2, 0.9, 0.08, n.d);
    slide([a, b, c], n);
    cleanup(a, [a, b, c, gb, gc, amp, ...breath(n, end, f * 3, 1.5, 0.02), ...vibrato([a, b, c], t, end, 5.5, 10, 0.18)]);
  },
  shaku(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 0.35;
    const a = osc('sine', f, t, end), b = osc('triangle', f, t, end), gb = gain(0.15), amp = gain();
    a.connect(amp);
    b.connect(gb).connect(amp);
    amp.connect(n.out);
    adsr(amp.gain, t, 0.3 * n.v, 0.08, 0.3, 0.85, 0.15, n.d);
    for (const o of [a, b]) { o.detune.setValueAtTime(-70, t); o.detune.linearRampToValueAtTime(0, t + 0.12); }
    cleanup(a, [a, b, gb, amp, ...breath(n, end, f * 1.5, 0.8, 0.09), ...vibrato([a, b], t, end, 4.5, 18, 0.3)]);
  },
  reed(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 0.3;
    const a = osc('square', f, t, end), lp = filt('lowpass', Math.min(f * 3.5, 4500), 0.9), amp = gain();
    a.connect(lp).connect(amp).connect(n.out);
    adsr(amp.gain, t, 0.3 * n.v, 0.04, 0.2, 0.85, 0.1, n.d);
    slide([a], n);
    cleanup(a, [a, lp, amp, ...vibrato([a], t, end, 5, 9, 0.3)]);
  },
  bassoon(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 0.2;
    const a = osc('sawtooth', f, t, end), lp = filt('lowpass', Math.min(f * 4, 1600), 1.6), amp = gain();
    a.connect(lp).connect(amp).connect(n.out);
    adsr(amp.gain, t, 0.36 * n.v, 0.025, 0.15, 0.8, 0.06, n.d);
    cleanup(a, [a, lp, amp]);
  },
  brass(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 0.25;
    const a = osc('sawtooth', f, t, end), b = osc('sawtooth', f, t, end), lp = filt('lowpass', f, 1.4), amp = gain();
    a.detune.value = -7;
    b.detune.value = 7;
    lp.frequency.setValueAtTime(f * 1.2, t);
    lp.frequency.linearRampToValueAtTime(Math.min(f * 7, 7000), t + 0.06);
    lp.frequency.setTargetAtTime(Math.min(f * 4, 4500), t + 0.06, 0.25);
    a.connect(lp);
    b.connect(lp);
    lp.connect(amp).connect(n.out);
    adsr(amp.gain, t, 0.3 * n.v, 0.03, 0.2, 0.8, 0.1, n.d);
    cleanup(a, [a, b, lp, amp, ...vibrato([a, b], t, end, 5.5, 8, 0.3)]);
  },
  horn(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 0.4;
    const a = osc('sawtooth', f, t, end), lp = filt('lowpass', f, 0.7), amp = gain();
    lp.frequency.setValueAtTime(f, t);
    lp.frequency.linearRampToValueAtTime(Math.min(f * 3.2, 3000), t + 0.09);
    a.connect(lp).connect(amp).connect(n.out);
    adsr(amp.gain, t, 0.36 * n.v, 0.07, 0.3, 0.9, 0.15, n.d);
    slide([a], n);
    cleanup(a, [a, lp, amp, ...vibrato([a], t, end, 5, 7, 0.35)]);
  },
  strings(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 0.5, lp = filt('lowpass', Math.min(f * 5, 5000), 0.5), amp = gain(), oscs = [];
    for (const dt of [-7, 7]) { const o = osc('sawtooth', f, t, end); o.detune.value = dt; o.connect(lp); oscs.push(o); }
    lp.connect(amp).connect(n.out);
    adsr(amp.gain, t, 0.195 * n.v, 0.16, 0.3, 1, 0.35, n.d);
    cleanup(oscs[0], [...oscs, lp, amp, ...vibrato(oscs, t, end, 5.5, 8, 0.25)]);
  },
  stac(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 0.2, lp = filt('lowpass', Math.min(f * 6, 6000), 0.5), amp = gain(), oscs = [];
    for (const dt of [-6, 6]) { const o = osc('sawtooth', f, t, end); o.detune.value = dt; o.connect(lp); oscs.push(o); }
    lp.connect(amp).connect(n.out);
    adsr(amp.gain, t, 0.2 * n.v, 0.006, 0.08, 0.35, 0.05, n.d);
    cleanup(oscs[0], [...oscs, lp, amp]);
  },
  pad(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 1.2, lp = filt('lowpass', 1200, 0.5), amp = gain(), oscs = [];
    for (const [type, dt] of [['sawtooth', -9], ['sawtooth', 9], ['triangle', 0]]) { const o = osc(type, f, t, end); o.detune.value = dt; o.connect(lp); oscs.push(o); }
    lp.connect(amp).connect(n.out);
    adsr(amp.gain, t, 0.08 * n.v, 0.5, 1, 1, 0.9, n.d);
    cleanup(oscs[0], [...oscs, lp, amp]);
  },
  square(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 0.2;
    const a = osc('pulse', f, t, end), lp = filt('lowpass', 5200), amp = gain();
    a.connect(lp).connect(amp).connect(n.out);
    adsr(amp.gain, t, 0.26 * n.v, 0.004, 0.12, 0.7, 0.05, n.d);
    cleanup(a, [a, lp, amp, ...vibrato([a], t, end, 6, 12, 0.25)]);
  },
  upright(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 0.4;
    const a = osc('sine', f, t, end), b = osc('triangle', f, t, end), c = osc('sawtooth', f, t, t + 0.4);
    const gb = gain(0.5), gc = gain(), lp = filt('lowpass', f * 6, 1), amp = gain();
    lp.frequency.setValueAtTime(f * 7, t);
    lp.frequency.setTargetAtTime(f * 1.6, t, 0.05);
    hit(gc.gain, t, 0.35, 0.18);
    a.connect(amp);
    b.connect(gb).connect(amp);
    c.connect(gc).connect(lp).connect(amp);
    amp.connect(n.out);
    adsr(amp.gain, t, 0.5 * n.v, 0.006, 0.35, 0.45, 0.08, n.d);
    cleanup(a, [a, b, c, gb, gc, lp, amp]);
  },
  fretless(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 0.4;
    const a = osc('sine', f, t, end), b = osc('triangle', f, t, end), gb = gain(0.4), lp = filt('lowpass', 900), amp = gain();
    a.connect(lp);
    b.connect(gb).connect(lp);
    lp.connect(amp).connect(n.out);
    adsr(amp.gain, t, 0.45 * n.v, 0.02, 0.8, 0.65, 0.1, n.d);
    slide([a, b], n);
    cleanup(a, [a, b, gb, lp, amp]);
  },
  pick(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 0.3;
    const a = osc('sawtooth', f, t, end), b = osc('sine', f, t, end), ga = gain(0.5), lp = filt('lowpass', f * 8, 2), amp = gain();
    lp.frequency.setValueAtTime(f * 8, t);
    lp.frequency.setTargetAtTime(f * 2.5, t, 0.07);
    a.connect(ga).connect(lp).connect(amp);
    b.connect(amp);
    amp.connect(n.out);
    adsr(amp.gain, t, 0.42 * n.v, 0.004, 0.3, 0.5, 0.05, n.d);
    cleanup(a, [a, b, ga, lp, amp]);
  },
  synbass(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 0.3;
    const a = osc('sawtooth', f, t, end), b = osc('square', f, t, end), c = osc('sine', f, t, end);
    const gb = gain(0.4), gc = gain(0.5), lp = filt('lowpass', f * 12, 5), amp = gain();
    lp.frequency.setValueAtTime(Math.min(f * 12, 6000), t);
    lp.frequency.setTargetAtTime(f * 2.2, t, 0.06);
    a.connect(lp);
    b.connect(gb).connect(lp);
    lp.connect(amp);
    c.connect(gc).connect(amp);
    amp.connect(n.out);
    adsr(amp.gain, t, 0.36 * n.v, 0.003, 0.2, 0.55, 0.04, n.d);
    cleanup(a, [a, b, c, gb, gc, lp, amp]);
  },
  sub(n) {
    const f = mtof(n.m), t = n.t, end = t + n.d + 0.8;
    const a = osc('sine', f, t, end), amp = gain();
    a.connect(amp).connect(n.out);
    adsr(amp.gain, t, 0.5 * n.v, 0.12, 0.5, 1, 0.5, n.d);
    cleanup(a, [a, amp]);
  },
  timp(n) {
    const f = mtof(n.m), t = n.t, end = t + 2.2;
    const a = osc('sine', f * 1.04, t, end), g = gain(), s = noise(t, t + 0.2), lp = filt('lowpass', 300), gn = gain();
    a.frequency.exponentialRampToValueAtTime(f, t + 0.08);
    hit(g.gain, t, 0.7 * n.v, 1.1);
    hit(gn.gain, t, 0.25 * n.v, 0.1);
    a.connect(g).connect(n.out);
    s.connect(lp).connect(gn).connect(n.out);
    cleanup(a, [a, g, s, lp, gn]);
  },
  harp: n => pluck(n, 'harp'),
  guitar: n => pluck(n, 'guitar'),
  funkgtr: n => pluck(n, 'funkgtr'),   // bright and choked short: chicken-scratch funk guitar
  koto: n => pluck(n, 'koto'),
  pizz: n => pluck(n, 'pizz'),
  harpsi: n => { pluck(n, 'harpsi'); pluck(n, 'harpsi', n.m + 12, 0.35); },
};

// ---------------------------------------------------------------- the drum kit: (time, velocity, out, p = a 0..1 variation)
function noiseHit(t, v, out, type, f, q, peak, ring) {
  const s = noise(t, t + ring * 2.6), fl = filt(type, f, q), g = gain();
  hit(g.gain, t, peak * v, ring);
  s.connect(fl).connect(g).connect(out);
  cleanup(s, [s, fl, g]);
}

function toneHit(t, v, out, type, f, f2, peak, ring) {
  const o = osc(type, f, t, t + ring * 2.6), g = gain();
  if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + Math.min(0.3, ring));
  hit(g.gain, t, peak * v, ring);
  o.connect(g).connect(out);
  cleanup(o, [o, g]);
}

const tom = f => (t, v, out) => { toneHit(t, v, out, 'sine', f, f * 0.72, 0.6, 0.3); noiseHit(t, v, out, 'bandpass', f * 4, 1, 0.08, 0.03); };

const DRUMS = {
  k(t, v, out) {
    const o = osc('sine', 150, t, t + 0.6), g = gain();
    o.frequency.exponentialRampToValueAtTime(46, t + 0.09);
    hit(g.gain, t, 0.95 * v, 0.32);
    o.connect(g).connect(out);
    cleanup(o, [o, g]);
    noiseHit(t, v, out, 'highpass', 2500, 0.7, 0.12, 0.012);
  },
  s(t, v, out) { noiseHit(t, v, out, 'highpass', 1400, 0.7, 0.5, 0.16); toneHit(t, v, out, 'triangle', 190, 150, 0.3, 0.08); },
  b(t, v, out) {
    const s = noise(t, t + 0.4), bp = filt('bandpass', 2800, 0.6), g = gain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.22 * v, t + 0.018);
    g.gain.setTargetAtTime(0, t + 0.02, 0.05);
    s.connect(bp).connect(g).connect(out);
    cleanup(s, [s, bp, g]);
  },
  rim(t, v, out) { toneHit(t, v, out, 'triangle', 1650, 0, 0.22, 0.025); noiseHit(t, v, out, 'bandpass', 2400, 3, 0.2, 0.02); },
  h(t, v, out) { noiseHit(t, v, out, 'highpass', 8000, 0.7, 0.22, 0.04); },
  oh(t, v, out) { noiseHit(t, v, out, 'highpass', 7000, 0.7, 0.18, 0.28); },
  r(t, v, out) {
    noiseHit(t, v, out, 'highpass', 5500, 0.7, 0.08, 0.55);
    toneHit(t, v, out, 'sine', 3300, 0, 0.04, 0.25);
    toneHit(t, v, out, 'sine', 5150, 0, 0.025, 0.18);
  },
  sh(t, v, out) {
    const s = noise(t, t + 0.15), bp = filt('bandpass', 6500, 1.2), g = gain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.2 * v, t + 0.012);
    g.gain.setTargetAtTime(0, t + 0.014, 0.02);
    s.connect(bp).connect(g).connect(out);
    cleanup(s, [s, bp, g]);
  },
  tb(t, v, out) { noiseHit(t, v, out, 'highpass', 7500, 0.7, 0.2, 0.13); },
  cl(t, v, out) {
    const s = noise(t, t + 0.3), bp = filt('bandpass', 1300, 1.4), g = gain();
    g.gain.setValueAtTime(0, t);
    for (const [dt, a] of [[0.002, 0.5], [0.01, 0.1], [0.012, 0.5], [0.022, 0.1], [0.024, 0.45]]) g.gain.linearRampToValueAtTime(a * v, t + dt);
    g.gain.setTargetAtTime(0, t + 0.026, 0.03);
    s.connect(bp).connect(g).connect(out);
    cleanup(s, [s, bp, g]);
  },
  t1: tom(230),
  t2: tom(170),
  t3: tom(120),
  tk(t, v, out) { toneHit(t, v, out, 'sine', 100, 55, 0.9, 0.6); noiseHit(t, v, out, 'lowpass', 700, 0.7, 0.35, 0.08); },
  cr(t, v, out) { noiseHit(t, v, out, 'highpass', 4200, 0.7, 0.22, 1.8); },
  cb(t, v, out) {
    const a = osc('square', 562, t, t + 0.7), b = osc('square', 845, t, t + 0.7), bp = filt('bandpass', 1700, 1.5), g = gain();
    hit(g.gain, t, 0.12 * v, 0.22);
    a.connect(bp);
    b.connect(bp);
    bp.connect(g).connect(out);
    cleanup(a, [a, b, bp, g]);
  },
  wb(t, v, out) { toneHit(t, v, out, 'sine', 1180, 0, 0.32, 0.05); toneHit(t, v, out, 'triangle', 2360, 0, 0.06, 0.02); },
  wl(t, v, out) { toneHit(t, v, out, 'sine', 790, 0, 0.32, 0.06); },
  cg(t, v, out) { toneHit(t, v, out, 'sine', 220, 200, 0.45, 0.2); },
  bg(t, v, out) { toneHit(t, v, out, 'sine', 390, 360, 0.4, 0.12); },
  tri(t, v, out) { toneHit(t, v, out, 'sine', 4200, 0, 0.06, 1.1); toneHit(t, v, out, 'sine', 6150, 0, 0.03, 0.7); },
  sn(t, v, out) { noiseHit(t, v, out, 'bandpass', 2600, 4, 0.5, 0.03); },
  drip(t, v, out, p) {
    const f = 700 + p * 1100, o = osc('sine', f, t, t + 0.3), g = gain();
    o.frequency.exponentialRampToValueAtTime(f * 1.7, t + 0.06);
    hit(g.gain, t, 0.22 * v, 0.08);
    o.connect(g).connect(out);
    cleanup(o, [o, g]);
  },
  // lo-fi: a soft, papery snare and the hiss and pops of an old record (one bar's worth)
  ls(t, v, out) { noiseHit(t, v, out, 'bandpass', 1900, 0.8, 0.35, 0.12); toneHit(t, v, out, 'triangle', 210, 170, 0.18, 0.06); },
  crackle(t, v, out) {
    const s = noise(t, t + 3.5), bp = filt('bandpass', 5000, 0.4), g = gain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.012 * v, t + 0.3);
    g.gain.setValueAtTime(0.012 * v, t + 3.1);
    g.gain.linearRampToValueAtTime(0, t + 3.5);
    s.connect(bp).connect(g).connect(out);
    cleanup(s, [s, bp, g]);
    for (let i = 4 + Math.floor(Math.random() * 6); i > 0; i--) {
      noiseHit(t + Math.random() * 3.2, v * (0.3 + Math.random() * 0.7), out, 'highpass', 2500 + Math.random() * 3000, 0.7, 0.18, 0.004);
    }
  },
  // rain sounds: steady beds of deep brown noise and rain hiss (each lasts one 4-second bar and
  // crossfades into the next), plus scattered drops
  brown(t, v, out) { bed(t, v, out, longNoise('brown'), 30, 500, 0.9); },
  rain(t, v, out) { bed(t, v, out, longNoise('white'), 600, 8000, 0.09); },
  drop(t, v, out, p) { noiseHit(t, v, out, 'bandpass', 1800 + p * 4500, 2.5, 0.2, 0.006); },
};

function longNoise(kind) {
  const C = cache(), id = 'long_' + kind;
  if (!C[id]) {
    const n = ac.sampleRate * 8, b = ac.createBuffer(1, n, ac.sampleRate), d = b.getChannelData(0);
    let x = 0, peak = 0;
    for (let i = 0; i < n; i++) {
      const w = Math.random() * 2 - 1;
      x = kind === 'brown' ? (x + 0.02 * w) / 1.02 : w;
      d[i] = x;
      peak = Math.max(peak, Math.abs(x));
    }
    for (let i = 0; i < n; i++) d[i] *= 0.9 / peak;
    C[id] = b;
  }
  return C[id];
}

const FADE = [...Array(32)].map((_, i) => Math.sin((i / 31) * Math.PI / 2));

function bed(t, v, out, buf, lo, hi, level) {
  const s = ac.createBufferSource(), hp = filt('highpass', lo, 0.5), lp = filt('lowpass', hi, 0.5), g = gain(0);
  s.buffer = buf;
  s.start(t, Math.random() * (buf.duration - 5.5));
  s.stop(t + 5.05);
  // equal-power fades, so overlapping beds never dip or bulge
  g.gain.setValueCurveAtTime(new Float32Array(FADE.map(x => x * level * v)), t, 1);
  g.gain.setValueCurveAtTime(new Float32Array(FADE.map((_, i) => FADE[31 - i] * level * v)), t + 4, 1);
  s.connect(hp).connect(lp).connect(g).connect(out);
  cleanup(s, [s, hp, lp, g]);
}

// ---------------------------------------------------------------- playing a song
class Track {
  constructor(c, pos, fade) {
    const song = c.song, now = ac.currentTime + 0.08;
    this.c = c;
    this.name = c.name;
    this.spb = 60 / song.bpm;
    this.sw = 0.5 + (song.swing || 0) / 6;   // where the off-beat eighth lands (0.5 straight .. 0.667 triplet swing)
    this.out = gain(0);
    this.out.connect(master);
    const g = song.gain ?? 1;
    if (fade > 0) { this.out.gain.setValueAtTime(0, now); this.out.gain.linearRampToValueAtTime(g, now + fade); }
    else this.out.gain.value = g;
    this.verb = ac.createConvolver();
    this.verb.buffer = impulse(song.room || 'room');
    this.verb.connect(this.out);
    this.nodes = [this.out, this.verb];
    let dly = null;
    if (Object.values(song.parts).some(p => p.delay)) {
      const d = ac.createDelay(2), fb = gain(song.delayFb ?? 0.35), lp = filt('lowpass', 2600);
      d.delayTime.value = this.spb * (song.delayBeats ?? 0.75);
      dly = gain(1);
      dly.connect(d).connect(lp).connect(fb).connect(d);
      lp.connect(this.out);
      this.nodes.push(dly, d, fb, lp);
      this.dly = d;
    }
    this.buses = {};
    for (const [pid, p] of Object.entries(song.parts)) {
      const bus = gain(p.vol ?? 0.5), pan = ac.createStereoPanner();
      let src = bus;
      if (p.lp) { const lp = filt('lowpass', p.lp, 0.6); src.connect(lp); src = lp; this.nodes.push(lp); }   // a dusty, muffled part
      pan.pan.value = p.pan || 0;
      src.connect(pan).connect(this.out);
      this.nodes.push(bus, pan);
      if (p.verb) { const sv = gain(p.verb); src.connect(sv).connect(this.verb); this.nodes.push(sv); }
      if (p.delay && dly) { const sd = gain(p.delay); src.connect(sd).connect(dly); this.nodes.push(sd); }
      this.buses[pid] = bus;
    }
    this.last = {};
    this.lastEnd = {};
    this.base = c.introLen;
    if (pos != null && c.loopLen) {
      // pick up from the bar we left off at
      this.seg = 'loop';
      this.idx = c.loop.findIndex(e => e.b >= pos - 1e-9);
      if (this.idx < 0) this.idx = c.loop.length;
      this.t0 = now - (c.introLen + pos) * this.spb;
    } else {
      this.seg = c.intro.length || !c.loopLen ? 'intro' : 'loop';
      this.idx = 0;
      this.t0 = now;
    }
    this.endAt = c.loopLen ? Infinity : this.timeOf(c.total) + 0.4;
    this.prewarm();
  }

  // render the plucked-string notes ahead of time so they don't stall playback
  prewarm() {
    const c = this.c;
    for (const e of [...c.intro, ...c.loop]) {
      const inst = c.song.parts[e.part].inst;
      if (PLUCK[inst]) { ksBuffer(e.m, inst); if (inst === 'harpsi') ksBuffer(e.m + 12, inst); }
    }
  }

  // the end of one time around: loop again, or for generated music move on to a brand-new piece
  next() {
    const end = this.base + this.c.loopLen;
    if (this.c.song.fresh) {
      const T = this.timeOf(end);
      this.c = piece(this.name);
      this.spb = 60 / this.c.song.bpm;
      this.sw = 0.5 + (this.c.song.swing || 0) / 6;
      this.t0 = T - end * this.spb;
      if (this.dly) this.dly.delayTime.setValueAtTime(this.spb * (this.c.song.delayBeats ?? 0.75), T);
      this.prewarm();
    }
    this.base = end;
    this.idx = 0;
  }

  // beats -> seconds, with swing pushing each off-beat eighth a little later
  timeOf(B) {
    const i = Math.floor(B), f = B - i, m = this.sw;
    return this.t0 + (i + (f < 0.5 ? f * 2 * m : m + (f - 0.5) * 2 * (1 - m))) * this.spb;
  }

  schedule(horizon) {
    let c = this.c;
    for (let guard = 0; guard < 4000; guard++) {
      const list = this.seg === 'intro' ? c.intro : c.loop;
      if (this.idx >= list.length) {
        if (this.seg === 'intro') {
          if (!c.loopLen) return;
          this.seg = 'loop';
          this.idx = 0;
          this.base = c.introLen;
          continue;
        }
        if (!list.length) return;
        this.next();
        c = this.c;
        continue;
      }
      const e = list[this.idx];
      const B = (this.seg === 'intro' ? 0 : this.base) + e.b;
      const t = this.timeOf(B);
      if (t > horizon) return;
      this.idx++;
      if (t < ac.currentTime - 0.05) continue;   // fell behind (the page was busy): skip instead of bunching up
      this.play(e, t, B);
    }
  }

  play(e, t, B) {
    const p = this.c.song.parts[e.part], out = this.buses[e.part];
    t = Math.max(ac.currentTime, t + (Math.random() - 0.5) * 0.006);
    if (e.drum) { const d = DRUMS[e.drum]; if (d) d(t, e.v * (0.9 + Math.random() * 0.2), out, e.p); return; }
    const inst = INST[p.inst];
    if (!inst) return;
    const len = Math.max(0.03, (this.timeOf(B + e.d) - this.timeOf(B)) * (e.gate ?? 0.92));
    const from = p.glide && this.lastEnd[e.part] > t - 0.08 ? this.last[e.part] : null;
    inst({ t: t + (e.o || 0), d: len, m: e.m, v: e.v * (0.92 + Math.random() * 0.12), out, from, glide: p.glide });
    this.last[e.part] = e.m;
    this.lastEnd[e.part] = t + len;
  }

  // the loop bar we're in right now, so the song can pick up from here later
  position() {
    const B = (ac.currentTime - this.t0) / this.spb - this.c.introLen;
    if (!this.c.loopLen || B < 0) return null;
    return Math.floor((B % this.c.loopLen) / this.c.meter) * this.c.meter;
  }

  stop(fade) {
    const now = ac.currentTime, g = this.out.gain;
    g.cancelScheduledValues(now);
    g.setValueAtTime(g.value, now);
    g.linearRampToValueAtTime(0, now + fade);
    setTimeout(() => { for (const n of this.nodes) n.disconnect(); }, (fade + 0.5) * 1000);
  }
}

// ---------------------------------------------------------------- the jukebox
function makeMaster(level) {
  const g = gain(level), lp = filt('lowpass', 20000, 0.5), dg = gain(1), comp = ac.createDynamicsCompressor();
  comp.threshold.value = -18;
  comp.knee.value = 10;
  comp.ratio.value = 3;
  comp.attack.value = 0.01;
  comp.release.value = 0.3;
  g.connect(lp).connect(dg).connect(comp).connect(ac.destination);
  g.duck = [lp, dg];
  return g;
}

// "underwater" music: muffled and quieter (study music does this while you're off task)
function setDuck(t) {
  const [lp, dg] = master.duck;
  lp.frequency.cancelScheduledValues(t);
  lp.frequency.setTargetAtTime(ducked ? 420 : 20000, t, 0.25);
  dg.gain.cancelScheduledValues(t);
  dg.gain.setTargetAtTime(ducked ? 0.55 : 1, t, 0.25);
}

const canPlay = () => stayOn || !document.hidden;

function ensure() {
  if (ac) return true;
  try { ac = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { return false; }
  master = makeMaster(vol * MASTER);
  if (ducked) setDuck(0);
  setInterval(tick, 50);
  const wake = () => { if (ac.state === 'suspended' && canPlay() && (current || sting)) ac.resume(); };
  window.addEventListener('pointerdown', wake, true);
  window.addEventListener('keydown', wake, true);
  // a hidden or minimized window goes quiet and picks up from the same spot when it comes back
  // (unless this page's music should keep going, like study music in the study buddy window)
  document.addEventListener('visibilitychange', () => { if (!canPlay()) ac.suspend(); else wake(); });
  return true;
}

function tick() {
  // hidden pages only get a timer tick about once a second, so plan further ahead there
  const h = ac.currentTime + (document.hidden ? 1.6 : LOOKAHEAD);
  if (sting) {
    sting.schedule(h);
    if (ac.currentTime > sting.endAt) { sting.stop(1.5); sting = null; apply(); }
  }
  if (current) current.schedule(h);
}

const audible = () => on && vol > 0.001;

function leave(fade) {
  if (current.c.song.resume) resumeAt[current.name] = current.position();
  current.stop(fade);
  current = null;
}

function apply() {
  if (sting && !audible()) { sting.stop(0.3); sting = null; }
  if (sting) return;
  const name = audible() && want && SONGS[want] ? want : null;
  if (current && current.name === name) return;
  const song = name && SONGS[name], from = current && current.c.song;
  // battles cut in fast; menus slide in and out quickly; everything else crossfades gently
  if (current) leave(song && song.battle ? 0.2 : (song && song.snappy) || (from && (from.snappy || from.battle)) ? 0.3 : 0.9);
  if (!name) {
    // nothing to play: once the fade is done, let go of the speakers entirely
    if (ac) setTimeout(() => { if (!current && !sting) ac.suspend(); }, 1500);
    return;
  }
  if (!ensure()) return;
  if (ac.state === 'suspended' && canPlay()) ac.resume();
  const fade = song.battle ? 0.02 : song.snappy ? 0.25 : from && from.snappy ? 0.5 : 1.2;
  current = new Track(piece(name), song.resume ? resumeAt[name] : null, fade);
}

export const music = {
  // Ask for a song by name (null = silence). Calling it every frame is fine.
  want(name) {
    name = name || null;
    if (name === want) return;
    want = name;
    apply();
  },
  // A short jingle that interrupts the music (the requested song comes back after it). False if muted.
  stinger(name) {
    if (!audible() || !SONGS[name] || !ensure()) return false;
    if (ac.state === 'suspended' && canPlay()) ac.resume();
    if (current) leave(0.15);
    if (sting) sting.stop(0.1);
    sting = new Track(piece(name), null, 0);
    return true;
  },
  // Cut a jingle short (a battle's victory fanfare once you're back in the field) so the wanted song can play.
  endStinger(fade = 0.5) {
    if (!sting) return;
    sting.stop(fade);
    sting = null;
    apply();
  },
  // muffle the music (true) or bring it back to normal (false)
  duck(v) {
    if (!!v === ducked) return;
    ducked = !!v;
    if (master) setDuck(ac.currentTime);
  },
  // keep playing even while this window is hidden or minimized (the study buddy's study music)
  set stayOn(v) { stayOn = !!v; },
  // how intense generated music should be from its next piece on (0..1)
  set energy(v) { energy = clamp(v, 0, 1); },
  setVolume(v, byUser) {
    vol = clamp(v, 0, 1);
    if (byUser) touched = Date.now();
    if (master) master.gain.setTargetAtTime(vol * MASTER, ac.currentTime, 0.05);
    apply();
  },
  setEnabled(v, byUser) {
    on = !!v;
    if (byUser) touched = Date.now();
    apply();
  },
  // Settings from the server: the game & menu music, or (kind 'study') the study music.
  // Ignored for a moment after the player changes them here, so a poll can't undo it.
  applySettings(st, kind = 'game') {
    if (Date.now() - touched < 4000) return;
    const enabled = kind === 'study' ? (st.study_music || 'lofi') !== 'off' : st.music !== false;
    if (enabled !== on) this.setEnabled(enabled);
    const v = (kind === 'study' ? st.study_vol ?? 40 : st.music_vol ?? 60) / 100;
    if (Math.abs(v - vol) > 0.001) this.setVolume(v);
  },
  get enabled() { return on; },
  get volume() { return vol; },
  get playing() { return sting ? sting.name : current ? current.name : null; },
  get position() { return current ? current.position() : null; },
  // Where the playing song is right now, in beats from its very start, as you hear it (for a rhythm game to keep time
  // with), or null. Only for songs that are the same every time (a generated one starts a new piece each time around).
  get beat() {
    if (!current || sting || current.c.song.fresh || !ac || ac.state !== 'running') return null;
    return (ac.currentTime - (ac.outputLatency || ac.baseLatency || 0) - current.t0) / current.spb;
  },
  songs: () => Object.keys(SONGS),
  compile,
  // Render `secs` of a song offline, from the top or from loop beat `pos` (for checking levels without speakers).
  async render(name, secs = 16, raw = false, pos = null) {
    const saved = [ac, master];
    const off = new OfflineAudioContext(2, Math.ceil(44100 * secs), 44100);
    ac = off;
    try {
      if (raw) { master = gain(1); master.connect(off.destination); } else master = makeMaster(vol * MASTER);
      new Track(piece(name), pos, 0).schedule(secs);
    } finally { [ac, master] = saved; }
    return off.startRendering();
  },
};
