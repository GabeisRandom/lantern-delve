// Reading a QR code from a camera picture: how a phone links itself from inside the home-screen app (Settings →
// 📱 Phone & sync → 📷 Scan the code), which the camera app's links never reach (they open in the browser, and the
// home-screen app keeps its own storage). Browsers with BarcodeDetector (Chrome on Android) use that instead; this
// is for the rest, like Safari on an iPhone.
// The steps are the usual ones (as in ZXing): a black-and-white version of the picture, the three finder squares,
// the grid between them (straightened out with the alignment square), the bits, Reed-Solomon error correction, and
// the text. It reads what qr.js makes: error correction L or M, versions 1 to 20.
import { ECC_PER_BLOCK, NUM_BLOCKS, rawModules, alignmentPositions } from './qr.js';

// ---------------------------------------------------------------- black and white
// Each pixel is judged against the brightness around it (8-pixel blocks, averaged 5 blocks each way), so a screen's
// glare, a shadow or a dim room don't matter.
// smooth: for a grainy picture (a dim room), the brightness is softened first, so specks don't break up the patterns
function binarize(img, smooth = false) {
  const { data, width: w, height: h } = img;
  let lum = new Uint8Array(w * h);
  for (let i = 0, j = 0; i < lum.length; i++, j += 4) lum[i] = (data[j] * 77 + data[j + 1] * 150 + data[j + 2] * 29) >> 8;
  if (smooth) {                              // (a 3x3 blur, weights 1 2 1)
    const o = new Uint8Array(w * h);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      let s = 0, n = 0;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        const xx = x + dx, yy = y + dy;
        if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
        const k = (dx ? 1 : 2) * (dy ? 1 : 2);
        s += lum[yy * w + xx] * k; n += k;
      }
      o[y * w + x] = s / n;
    }
    lum = o;
  }
  const B = 8, bw = Math.ceil(w / B), bh = Math.ceil(h / B), black = new Float32Array(bw * bh);
  const x0 = bx => Math.min(bx * B, w - B), y0 = by => Math.min(by * B, h - B);   // (the last ones overlap the edge)
  const mins = new Uint8Array(bw * bh), maxs = new Uint8Array(bw * bh), means = new Float32Array(bw * bh);
  for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
    let sum = 0, min = 255, max = 0;
    for (let y = y0(by), ye = y + B; y < ye; y++) for (let x = x0(bx), xe = x + B; x < xe; x++) {
      const v = lum[y * w + x];
      sum += v;
      if (v < min) min = v;
      if (v > max) max = v;
    }
    const i = by * bw + bx;
    mins[i] = min; maxs[i] = max; means[i] = sum / (B * B);
  }
  // A block counts as flat (no edge between dark and light in it) when its spread is small next to the picture's
  // own contrast: a white border's slight shading, or a grainy sensor, shouldn't read as dark specks.
  const sortedMin = Array.from(mins).sort((a, b) => a - b), sortedMax = Array.from(maxs).sort((a, b) => a - b);
  const contrast = sortedMax[Math.floor(sortedMax.length * 0.95)] - sortedMin[Math.floor(sortedMin.length * 0.05)];
  const FLAT = Math.max(24, Math.min(40, contrast / 4));
  for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
    const i = by * bw + bx, min = mins[i], max = maxs[i];
    let t = means[i];
    if (max - min <= FLAT) {               // a flat block, all light or all dark: lean on the blocks next to it
      t = min / 2;
      if (by > 0 && bx > 0) {
        const nb = (black[(by - 1) * bw + bx] + 2 * black[by * bw + bx - 1] + black[(by - 1) * bw + bx - 1]) / 4;
        if (min < nb) t = nb;
      }
    }
    black[by * bw + bx] = t;
  }
  const bits = new Uint8Array(w * h);
  for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
    let sum = 0;
    for (let dy = -2; dy <= 2; dy++) {
      const row = Math.min(Math.max(by + dy, 0), bh - 1) * bw;
      for (let dx = -2; dx <= 2; dx++) sum += black[row + Math.min(Math.max(bx + dx, 0), bw - 1)];
    }
    const t = sum / 25;
    for (let y = y0(by), ye = y + B; y < ye; y++) for (let x = x0(bx), xe = x + B; x < xe; x++) bits[y * w + x] = lum[y * w + x] <= t ? 1 : 0;
  }
  return { bits, w, h };
}

// ---------------------------------------------------------------- the finder squares
// Straight through its middle, a finder square reads dark, light, dark, light, dark at 1:1:3:1:1.
// (any line through its middle does, at any angle: only the lengths change)
function ratioOk(s, slack = 0.5) {
  const total = s[0] + s[1] + s[2] + s[3] + s[4];
  if (total < 7 || !s[0] || !s[1] || !s[2] || !s[3] || !s[4]) return false;
  const m = total / 7, v = m * slack;
  return Math.abs(m - s[0]) < v && Math.abs(m - s[1]) < v && Math.abs(3 * m - s[2]) < 3 * v && Math.abs(m - s[3]) < v && Math.abs(m - s[4]) < v;
}

// From a dark pixel (x, y) in a finder's middle, along (dx, dy) both ways: that line's middle, or null. total: the
// length the first line through it had (null: any length, for the diagonal, whose length depends on the angle)
function crossCheck(P, x, y, dx, dy, maxCount, total) {
  const { bits, w, h } = P;
  const at = t => { const xx = x + t * dx, yy = y + t * dy; return xx >= 0 && yy >= 0 && xx < w && yy < h ? bits[yy * w + xx] : -1; };
  if (at(0) !== 1) return null;
  const s = [0, 0, 0, 0, 0];
  let t = 0;
  while (at(t) === 1) { s[2]++; t--; }
  const back = t;
  while (at(t) === 0 && s[1] <= maxCount) { s[1]++; t--; }
  if (at(t) !== 1 || s[1] > maxCount) return null;
  while (at(t) === 1 && s[0] <= maxCount) { s[0]++; t--; }
  if (s[0] > maxCount) return null;
  t = 1;
  while (at(t) === 1) { s[2]++; t++; }
  const fwd = t;
  while (at(t) === 0 && s[3] <= maxCount) { s[3]++; t++; }
  if (at(t) !== 1 || s[3] > maxCount) return null;
  while (at(t) === 1 && s[4] <= maxCount) { s[4]++; t++; }
  if (s[4] > maxCount) return null;
  const sum = s[0] + s[1] + s[2] + s[3] + s[4];
  if (total == null ? !ratioOk(s, 0.75) : 5 * Math.abs(sum - total) >= 2 * total || !ratioOk(s)) return null;
  const c = (back + fwd) / 2;              // (the middle of the center run; pixel centers sit at +0.5)
  return { x: x + 0.5 + c * dx, y: y + 0.5 + c * dy, size: sum / 7 };
}

// Every row (or every few, in a big picture), looking for that pattern, each find checked up and down, across and
// diagonally. The same square found on several rows adds up (count), which tells real ones from look-alikes.
function findFinders(P) {
  const { bits, w, h } = P, found = [];
  const add = (s, y, endX) => {
    const total = s[0] + s[1] + s[2] + s[3] + s[4];
    const cx = Math.floor(endX - s[4] - s[3] - s[2] / 2);
    const v = crossCheck(P, cx, y, 0, 1, s[2], total);
    if (!v) return;
    const hz = crossCheck(P, cx, Math.floor(v.y), 1, 0, s[2], total);
    if (!hz) return;
    if (!crossCheck(P, Math.floor(hz.x), Math.floor(v.y), 1, 1, s[2] * 3, null)) return;
    const p = { x: hz.x, y: v.y, size: (hz.size + v.size) / 2 };
    const near = found.find(f => Math.abs(f.x - p.x) <= Math.max(f.size, 2) && Math.abs(f.y - p.y) <= Math.max(f.size, 2)
      && Math.abs(f.size - p.size) <= Math.max(1, f.size * 0.5));
    if (near) {
      const n = near.count;
      near.x = (near.x * n + p.x) / (n + 1);
      near.y = (near.y * n + p.y) / (n + 1);
      near.size = (near.size * n + p.size) / (n + 1);
      near.count++;
    } else found.push({ ...p, count: 1 });
  };
  const skip = Math.max(1, Math.min(3, Math.floor(h / 200)));
  for (let y = 0; y < h; y += skip) {
    const s = [0, 0, 0, 0, 0];
    let st = 0;
    for (let x = 0, i = y * w; x < w; x++, i++) {
      if (bits[i]) {
        if (st & 1) st++;
        s[st]++;
      } else if (st & 1) s[st]++;
      else if (st === 4) {
        if (ratioOk(s)) add(s, y, x);
        s[0] = s[2]; s[1] = s[3]; s[2] = s[4]; s[3] = 1; s[4] = 0; st = 3;
      } else s[++st]++;
    }
    if (st === 4 && ratioOk(s)) add(s, y, w);
  }
  return found;
}

const d2 = (a, b) => (a.x - b.x) ** 2 + (a.y - b.y) ** 2;

// The likeliest sets of three: alike in size, at the corners of a right angle with two equal sides (give or take
// the camera's angle), best first.
function triples(found) {
  const strong = found.filter(f => f.count >= 2);
  const list = (strong.length >= 3 ? strong : found).slice().sort((a, b) => b.count - a.count).slice(0, 12);
  const out = [];
  for (let i = 0; i < list.length; i++) for (let j = i + 1; j < list.length; j++) for (let k = j + 1; k < list.length; k++) {
    const t = [list[i], list[j], list[k]];
    const sizes = t.map(p => p.size), mean = (sizes[0] + sizes[1] + sizes[2]) / 3;
    const spread = (Math.max(...sizes) - Math.min(...sizes)) / mean;
    if (spread > 0.8) continue;                        // (an angled code's far corners look smaller)
    const d = [d2(t[0], t[1]), d2(t[1], t[2]), d2(t[0], t[2])].sort((a, b) => a - b);
    if (Math.sqrt(d[0]) < 9 * mean) continue;          // (finders sit at least 14 modules apart)
    const score = Math.abs(d[2] - d[0] - d[1]) / d[2] + Math.abs(d[1] - d[0]) / d[1] + spread / 2;
    if (score < 1) out.push({ t, score });
  }
  return out.sort((a, b) => a.score - b.score).slice(0, 4).map(o => o.t);
}

// [top left, top right, bottom left]: the corner one is across from the longest side, and the other two go clockwise
function orient([a, b, c]) {
  const ab = d2(a, b), bc = d2(b, c), ac = d2(a, c);
  const [tl, p, q] = bc >= ab && bc >= ac ? [a, b, c] : ac >= ab && ac >= bc ? [b, a, c] : [c, a, b];
  return (p.x - tl.x) * (q.y - tl.y) - (p.y - tl.y) * (q.x - tl.x) > 0 ? [tl, p, q] : [tl, q, p];
}

// sizes (modules across) worth trying, nearest to the finders' spacing first
function sizesToTry(tl, tr, bl) {
  const ms = (tl.size + tr.size + bl.size) / 3;
  const est = (Math.sqrt(d2(tl, tr)) + Math.sqrt(d2(tl, bl))) / 2 / ms + 7;
  const out = [];
  for (let v = 1; v <= 20; v++) { const n = 17 + 4 * v; if (Math.abs(n - est) <= 8 + est * 0.15) out.push(n); }
  return out.sort((a, b) => Math.abs(a - est) - Math.abs(b - est));
}

// ---------------------------------------------------------------- straightening the grid
// The projective map from grid coordinates to picture coordinates through four matching points.
function homography(src, dst) {
  const A = [], b = [];
  for (let i = 0; i < 4; i++) {
    const [x, y] = src[i], [u, v] = dst[i];
    A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]); b.push(u);
    A.push([0, 0, 0, x, y, 1, -v * x, -v * y]); b.push(v);
  }
  for (let col = 0; col < 8; col++) {
    let piv = col;
    for (let r = col + 1; r < 8; r++) if (Math.abs(A[r][col]) > Math.abs(A[piv][col])) piv = r;
    if (Math.abs(A[piv][col]) < 1e-9) return null;
    [A[col], A[piv]] = [A[piv], A[col]];
    [b[col], b[piv]] = [b[piv], b[col]];
    for (let r = 0; r < 8; r++) {
      if (r === col || !A[r][col]) continue;
      const f = A[r][col] / A[col][col];
      for (let k = col; k < 8; k++) A[r][k] -= f * A[col][k];
      b[r] -= f * b[col];
    }
  }
  const H = b.map((v, i) => v / A[i][i]);
  return (x, y) => { const d = H[6] * x + H[7] * y + 1; return [(H[0] * x + H[1] * y + H[2]) / d, (H[3] * x + H[4] * y + H[5]) / d]; };
}

// Where the grid's bottom right part sits. Seen at an angle, the far side of the code looks smaller, and so do its
// finder squares: their sizes say how much the grid shrinks or grows toward each corner, which bends the guess the
// right way (a plain parallelogram misses badly at an angle). at: modules in from the bottom right finder's middle.
function cornerGuess(tl, tr, bl, n, at) {
  const k = n - 7, sTR = tr.size / tl.size, sBL = bl.size / tl.size, sBR = Math.max(0.4, sTR + sBL - 1);
  const ux = (tr.x - tl.x) / k, uy = (tr.y - tl.y) / k, vx = (bl.x - tl.x) / k, vy = (bl.y - tl.y) / k;
  const fv = (sTR + sBR) / (1 + sBL), fu = (sBL + sBR) / (1 + sTR);   // (right side vs left side, bottom vs top)
  const d = k - at;
  const ax = tr.x + d * vx * fv - at * ux * sBR, ay = tr.y + d * vy * fv - at * uy * sBR;     // down the right side
  const bx = bl.x + d * ux * fu - at * vx * sBR, by = bl.y + d * uy * fu - at * vy * sBR;     // along the bottom
  const su = 2 * sBR / (1 + sTR), sv = 2 * sBR / (1 + sBL);
  return { x: (ax + bx) / 2, y: (ay + by) / 2, ux: ux * su, uy: uy * su, vx: vx * sv, vy: vy * sv };
}

// The alignment square near the bottom right corner (versions 2 and up): around where it should be, the best match
// for its 5x5 look (dark ring, light ring, dark middle), at a few sizes.
function findAlignment(P, tl, tr, bl, n) {
  const { bits, w, h } = P, g = cornerGuess(tl, tr, bl, n, 3);
  const at = (x, y) => { const xi = Math.floor(x), yi = Math.floor(y); return xi >= 0 && yi >= 0 && xi < w && yi < h ? bits[yi * w + xi] : 0; };
  const ms = Math.sqrt((g.ux * g.ux + g.uy * g.uy + g.vx * g.vx + g.vy * g.vy) / 2);
  const R = Math.max(4, Math.round(n / 7)) * ms, step = Math.max(0.6, ms / 3);
  let best = null, bestScore = -1;
  for (const f of [1, 0.85, 1.18]) {
    const ux = g.ux * f, uy = g.uy * f, vx = g.vx * f, vy = g.vy * f;
    for (let dy = -R; dy <= R; dy += step) for (let dx = -R; dx <= R; dx += step) {
      const cx = g.x + dx, cy = g.y + dy;
      let score = 0;
      for (let j = -2; j <= 2; j++) for (let i = -2; i <= 2; i++) {
        if (at(cx + i * ux + j * vx, cy + i * uy + j * vy) === (Math.max(Math.abs(i), Math.abs(j)) !== 1 ? 1 : 0)) score++;
      }
      score -= Math.hypot(dx, dy) / (R * 20) + Math.abs(f - 1) / 10;   // (nearer, and the expected size, win a tie)
      if (score > bestScore) { bestScore = score; best = { x: cx, y: cy }; }
    }
  }
  return bestScore >= 21 ? best : null;
}

// each module from five points around its middle (a majority), so one stray pixel doesn't flip it
function sample(P, H, n) {
  const { bits, w, h } = P, m = [];
  const dark = (x, y) => { const [px, py] = H(x, y), xi = Math.floor(px), yi = Math.floor(py); return xi >= 0 && yi >= 0 && xi < w && yi < h && bits[yi * w + xi] === 1 ? 1 : 0; };
  for (let r = 0; r < n; r++) {
    const row = new Array(n);
    for (let c = 0; c < n; c++) {
      const x = c + 0.5, y = r + 0.5;
      row[c] = dark(x, y) + dark(x - 0.22, y - 0.22) + dark(x + 0.22, y - 0.22) + dark(x - 0.22, y + 0.22) + dark(x + 0.22, y + 0.22) >= 3;
    }
    m.push(row);
  }
  return m;
}

// ---------------------------------------------------------------- the bits (laid out as qr.js lays them)
const FORMATS = [];
for (const [ecl, e] of [['L', 1], ['M', 0], ['Q', 3], ['H', 2]]) for (let mask = 0; mask < 8; mask++) {
  const data = (e << 3) | mask;
  let rem = data;
  for (let i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
  FORMATS.push({ bits: ((data << 10) | rem) ^ 0x5412, ecl, mask });
}
const popcount = x => { let c = 0; for (; x; x &= x - 1) c++; return c; };

// error correction level and mask, from either copy of the format bits (up to 3 bits off)
function readFormat(m, n) {
  const get = (x, y) => (m[y][x] ? 1 : 0);
  let a = 0, b = 0;
  const p1 = [];
  for (let i = 0; i <= 5; i++) p1.push([8, i]);
  p1.push([8, 7], [8, 8], [7, 8]);
  for (let i = 9; i < 15; i++) p1.push([14 - i, 8]);
  p1.forEach(([x, y], i) => { a |= get(x, y) << i; });
  for (let i = 0; i < 8; i++) b |= get(n - 1 - i, 8) << i;
  for (let i = 8; i < 15; i++) b |= get(8, n - 15 + i) << i;
  let best = null, bestD = 99;
  for (const f of FORMATS) for (const v of [a, b]) { const d = popcount(f.bits ^ v); if (d < bestD) { bestD = d; best = f; } }
  return bestD <= 3 ? best : null;
}

// which modules are fixed patterns rather than data
function functionModules(ver, n) {
  const fn = Array.from({ length: n }, () => new Uint8Array(n));
  const set = (x, y) => { if (x >= 0 && y >= 0 && x < n && y < n) fn[y][x] = 1; };
  for (let i = 0; i < n; i++) { set(6, i); set(i, 6); }
  for (const [cx, cy] of [[3, 3], [n - 4, 3], [3, n - 4]]) for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) set(cx + dx, cy + dy);
  const pos = alignmentPositions(ver, n), na = pos.length;
  for (let i = 0; i < na; i++) for (let j = 0; j < na; j++) {
    if ((i === 0 && j === 0) || (i === 0 && j === na - 1) || (i === na - 1 && j === 0)) continue;
    for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) set(pos[i] + dx, pos[j] + dy);
  }
  for (let i = 0; i <= 8; i++) { set(8, i); set(i, 8); }
  for (let i = 0; i < 8; i++) { set(n - 1 - i, 8); set(8, n - 1 - i); }
  if (ver >= 7) for (let i = 0; i < 18; i++) { const a = n - 11 + (i % 3), b = Math.floor(i / 3); set(a, b); set(b, a); }
  return fn;
}

const MASKS = [(x, y) => (x + y) % 2 === 0, (x, y) => y % 2 === 0, x => x % 3 === 0, (x, y) => (x + y) % 3 === 0,
  (x, y) => (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0, (x, y) => ((x * y) % 2) + ((x * y) % 3) === 0,
  (x, y) => (((x * y) % 2) + ((x * y) % 3)) % 2 === 0, (x, y) => (((x + y) % 2) + ((x * y) % 3)) % 2 === 0];

function readCodewords(m, fn, n, mask) {
  const out = [], inv = MASKS[mask];
  let cur = 0, nb = 0;
  for (let right = n - 1; right >= 1; right -= 2) {
    if (right === 6) right = 5;
    const up = ((right + 1) & 2) === 0;
    for (let vert = 0; vert < n; vert++) for (let j = 0; j < 2; j++) {
      const x = right - j, y = up ? n - 1 - vert : vert;
      if (fn[y][x]) continue;
      cur = (cur << 1) | ((m[y][x] ? 1 : 0) ^ (inv(x, y) ? 1 : 0));
      if (++nb === 8) { out.push(cur); cur = 0; nb = 0; }
    }
  }
  return out;
}

// ---------------------------------------------------------------- Reed-Solomon error correction
// GF(256) modulo x^8 + x^4 + x^3 + x^2 + 1; the code's roots are α^0 .. α^(e-1), as qr.js's rsDivisor makes them.
const EXP = new Uint8Array(512), LOG = new Uint8Array(256);
for (let i = 0, x = 1; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 0x100) x ^= 0x11d; }
for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255];
const mul = (a, b) => (a && b ? EXP[LOG[a] + LOG[b]] : 0);
const div = (a, b) => (a ? EXP[(LOG[a] + 255 - LOG[b]) % 255] : 0);
const pow = e => EXP[((e % 255) + 255) % 255];

// One block (data then error correction, first byte = highest power), corrected; null if it's beyond repair.
export function rsCorrect(r, e) {
  const n = r.length, S = new Array(e).fill(0);
  const syndromes = msg => {
    let bad = false;
    for (let j = 0; j < e; j++) {
      const a = pow(j);
      let s = 0;
      for (let k = 0; k < n; k++) s = mul(s, a) ^ msg[k];
      S[j] = s;
      if (s) bad = true;
    }
    return bad;
  };
  if (!syndromes(r)) return r;
  // Berlekamp-Massey: the error locator Λ(x) = 1 + Λ1 x + ... (lowest power first)
  let C = [1], B = [1], L = 0, m = 1, b = 1;
  for (let i = 0; i < e; i++) {
    let d = S[i];
    for (let k = 1; k <= L; k++) d ^= mul(C[k] || 0, S[i - k]);
    if (!d) { m++; continue; }
    const T = C.slice(), coef = div(d, b);
    while (C.length < B.length + m) C.push(0);
    for (let k = 0; k < B.length; k++) C[k + m] ^= mul(coef, B[k]);
    if (2 * L <= i) { L = i + 1 - L; B = T; b = d; m = 1; } else m++;
  }
  if (2 * L > e) return null;
  // Chien search: an error at power p (byte n-1-p) when Λ(α^-p) = 0
  const errs = [];
  for (let p = 0; p < n; p++) {
    const xi = pow(-p);
    let v = 0;
    for (let k = C.length - 1; k >= 0; k--) v = mul(v, xi) ^ C[k];
    if (!v) errs.push(p);
  }
  if (errs.length !== L) return null;
  // Forney: the size of each error, e = X·Ω(X⁻¹) / Λ'(X⁻¹), with Ω(x) = S(x)Λ(x) mod x^e
  const omega = new Array(e).fill(0);
  for (let i = 0; i < e; i++) for (let k = 0; k <= i && k < C.length; k++) omega[i] ^= mul(C[k], S[i - k]);
  const out = r.slice();
  for (const p of errs) {
    const xi = pow(-p);
    let num = 0;
    for (let i = e - 1; i >= 0; i--) num = mul(num, xi) ^ omega[i];
    let den = 0;
    for (let k = 1; k < C.length; k += 2) den ^= mul(C[k], pow(-p * (k - 1)));
    if (!den) return null;
    out[n - 1 - p] ^= mul(pow(p), div(num, den));
  }
  return syndromes(out) ? null : out;
}

// the data codewords: blocks taken apart again (as qr.js interleaved them), each one corrected
function dataCodewords(words, ver, ecl) {
  const numBlocks = NUM_BLOCKS[ecl][ver], eccLen = ECC_PER_BLOCK[ecl][ver];
  const raw = Math.floor(rawModules(ver) / 8);
  if (words.length < raw) return null;
  const numShort = numBlocks - (raw % numBlocks), shortLen = Math.floor(raw / numBlocks);
  const blocks = Array.from({ length: numBlocks }, () => []);
  let k = 0;
  for (let i = 0; i <= shortLen; i++) for (let j = 0; j < numBlocks; j++) {
    if (i === shortLen - eccLen && j < numShort) continue;     // (short blocks have one data codeword fewer)
    blocks[j].push(words[k++]);
  }
  const out = [];
  for (const block of blocks) {
    const fixed = rsCorrect(block, eccLen);
    if (!fixed) return null;
    out.push(...fixed.slice(0, fixed.length - eccLen));
  }
  return out;
}

// ---------------------------------------------------------------- the text
const ALNUM = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:';
function parseData(bytes, ver) {
  let p = 0;
  const total = bytes.length * 8;
  const read = n => {
    let v = 0;
    for (let i = 0; i < n; i++, p++) v = (v << 1) | (p < total ? (bytes[p >> 3] >> (7 - (p & 7))) & 1 : 0);
    return v;
  };
  const out = [];
  while (p + 4 <= total) {
    const mode = read(4);
    if (mode === 0) break;
    if (mode === 4) {                                          // bytes (what qr.js writes)
      const len = read(ver <= 9 ? 8 : 16);
      if (p + len * 8 > total) return null;
      for (let i = 0; i < len; i++) out.push(read(8));
    } else if (mode === 2) {                                   // letters and digits
      let len = read(ver <= 9 ? 9 : 13);
      for (; len >= 2; len -= 2) { const v = read(11); out.push(ALNUM.charCodeAt(Math.floor(v / 45)), ALNUM.charCodeAt(v % 45)); }
      if (len) out.push(ALNUM.charCodeAt(read(6)));
    } else if (mode === 1) {                                   // digits
      let len = read(ver <= 9 ? 10 : 12);
      for (; len >= 3; len -= 3) out.push(...String(read(10)).padStart(3, '0').split('').map(c => c.charCodeAt(0)));
      if (len === 2) out.push(...String(read(7)).padStart(2, '0').split('').map(c => c.charCodeAt(0)));
      else if (len === 1) out.push(48 + read(4));
    } else if (mode === 7) read(8);                            // (a character set marker: UTF-8 is assumed anyway)
    else return null;
    if (p > total) return null;
  }
  try { return new TextDecoder('utf-8', { fatal: true }).decode(new Uint8Array(out)); } catch (e) { return null; }
}

function readMatrix(m, ver) {
  const n = m.length, fmt = readFormat(m, n);
  if (!fmt || !NUM_BLOCKS[fmt.ecl] || ver > 20) return null;  // (Q and H codes aren't made by qr.js)
  const words = readCodewords(m, functionModules(ver, n), n, fmt.mask);
  const data = dataCodewords(words, ver, fmt.ecl);
  return data ? parseData(data, ver) : null;
}

const transpose = m => m.map((row, i) => row.map((_, j) => m[j][i]));

// The text of the QR code in a picture ({data, width, height}, like canvas ImageData), or null if there's none it
// can read. (A mirrored picture, from a front camera, reads too.)
export function readQR(img) {
  if (!img || img.width < 21 || img.height < 21) return null;
  return readFrom(binarize(img)) ?? readFrom(binarize(img, true));   // (then once more with the grain smoothed out)
}

function readFrom(P) {
  for (const t of triples(findFinders(P))) {
    const [tl, tr, bl] = orient(t);
    for (const n of sizesToTry(tl, tr, bl)) {
      const ver = (n - 17) / 4;
      const al = ver >= 2 ? findAlignment(P, tl, tr, bl, n) : null, br = cornerGuess(tl, tr, bl, n, 0);
      const H = al ? homography([[3.5, 3.5], [n - 3.5, 3.5], [3.5, n - 3.5], [n - 6.5, n - 6.5]], [[tl.x, tl.y], [tr.x, tr.y], [bl.x, bl.y], [al.x, al.y]])
        : homography([[3.5, 3.5], [n - 3.5, 3.5], [3.5, n - 3.5], [n - 3.5, n - 3.5]], [[tl.x, tl.y], [tr.x, tr.y], [bl.x, bl.y], [br.x, br.y]]);
      if (!H) continue;
      const m = sample(P, H, n);
      const text = readMatrix(m, ver) ?? readMatrix(transpose(m), ver);
      if (text != null) return text;
    }
  }
  return null;
}
