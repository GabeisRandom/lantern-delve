// The Lantern Delve soundtrack, written out for the synth orchestra in music.js. Every tune is original.
// Melody lines: note + octave + length (w h q e s t, add "." for dotted), "r" = rest, "~" = tie, "|" = bar line,
// [c4e4g4] = chord, ' = short, > = accent, ? = soft. A length carries over until it changes.
// Chord charts split each bar evenly between its chords; "." holds the chord before it.
// Most themes hide the "lantern motif": a rising sol-do-re-mi.

const WALK = { walk: true };
const PAD = { pad: true };
const HOLD = { bass: [[0, 3.9, 'R', 0.8]] };
const SWING_COMP = { comp: [[[0, 0.7, 0.8], [1.5, 0.5, 0.7]], [[1, 0.5, 0.65], [2.5, 1.3, 0.8]]], rootless: true, range: [55, 72] };
const GALLOP = { bass: [[0, 0.9, 'R', 0.9], [1, 0.45, 'R', 0.6], [1.5, 0.45, '5', 0.7], [2, 0.9, '8', 0.8], [3, 0.45, '5', 0.7], [3.5, 0.45, 'R', 0.6]] };
const DRIVE = { bass: [[0, 0.45, 'R', 0.95], [0.5, 0.45, 'R', 0.6], [1, 0.45, '8', 0.8], [1.5, 0.45, 'R', 0.6], [2, 0.45, 'R', 0.85], [2.5, 0.45, 'R', 0.6], [3, 0.45, '8', 0.8], [3.5, 0.45, '5', 0.7]] };
const FUNK = { bass: [[0, 0.4, 'R', 1], [0.5, 0.2, 'R', 0.55], [0.75, 0.2, '8', 0.85], [1.5, 0.4, 'R', 0.8], [2, 0.2, '5', 0.7], [2.5, 0.4, '7', 0.8], [3, 0.2, '8', 0.9], [3.5, 0.4, '5', 0.7]] };
const BOSSA = { comp: [[[0, 0.45], [1.5, 0.45], [3, 0.45]], [[1, 0.45], [2.5, 0.45]]], range: [55, 71], strum: 0.012 };
const BOSSA_BASS = { bass: [[0, 1.4, 'R', 0.85], [1.5, 0.45, '5', 0.7], [2, 1.4, '5', 0.8], [3.5, 0.45, 'R', 0.7]] };
const GRUMBLE = { bass: [[0, 0.4, 'R', 0.9], [1, 0.4, '-5', 0.7], [2, 0.4, '-7', 0.75], [2.5, 0.4, 'R', 0.8], [3.5, 0.4, '-5', 0.7]] };
const OOM = { bass: [[0, 2.8, 'R', 0.8]] };
const WALTZ = { comp: [[1, 0.8, 0.6], [2, 0.8, 0.55]], range: [59, 74] };

// ---------------------------------------------------------------- Lumen Town: cozy lamplit swing
const TOWN_HEAD = 'f5q g5e a5e ~h | re g5e f5e d5e ~q c5q | d5q. f5e ~q e5e d5e | e5q. c5e ~q re c5e | f5q g5e a5e ~q c6q | bb5q. ab5e ~q g5e f5e';
const TOWN_A = `${TOWN_HEAD} | e5e g5e ~e e5e f#5e a5e ~e c6e | bb5q a5e g5e e5q re c5e`;
const TOWN_A2 = `${TOWN_HEAD} | d6q bb5e g5e e5q. g5e | f5h. rq`;
const TOWN_A4 = `${TOWN_HEAD} | d6q bb5e g5e e5q. g5e | f5h. re c5e`;
const TOWN_CH = 'Fmaj7 | Dm7 | Gm7 | C7 | Fmaj7 | Bb7 | Gm7 C7 | F6';

// ---------------------------------------------------------------- the dark town before the lantern is relit
const NIGHT_CH = 'Dm | Bbmaj7 | Gm7 | A7 | Dm | Bbmaj7 | Gm6 | A7sus4 A7';
const NIGHT_MEL = 'd5q e5e f5e ~h | re e5e d5e bb4e ~q a4q | bb4q. d5e ~q c5e bb4e | c#5h. re a4e | d5q e5e f5e ~q a5q | g5q. f5e ~q e5e d5e | e5q d5q bb4q g4q | a4h c#5h';

// ---------------------------------------------------------------- Lumen Fields: open-air adventure
const FIELDS_HEAD = 'a4e d5e e5e f#5e ~q a5q | b5q. a5e ~q f#5q | d5q. e5e f#5q d5q | e5h. rq | b4e d5e g5e ~e a5q b5q';

// ---------------------------------------------------------------- Mirror Lake: lazy bossa nova
const LAKE_HEAD = 'd5q. g5e ~e a5e b5q | ~h. rq | c6q. b5e ~q a5q | f#5h. rq | d5q. g5e ~e a5e b5q | e6q. d6e ~q b5q';

// ---------------------------------------------------------------- Grumbling Grove: a shuffling, grumpy forest
const GROVE_A = 'a4e d5e e5e f5e ~q d5q | e5q d5e b4e ~q g4q | a4e d5e e5e f5e ~e g5e a5q | b5q. a5e g5q f5q | d5q f5q a5q. g5e | g5q. f5e e5q c5q | d5e f5e a5e d6e ~q c6q | c#6q. a5e e5q c#5q';

// ---------------------------------------------------------------- Ember Peak
const PEAK_A = 'b4e e5e f#5e g5e ~q. b5e | g5q. e5e ~q c5q | f#5q. a5e ~q d5q | f#5h. re b4e | e5e f#5e g5e b5e ~q a5e g5e | e5q. g5e ~q c6q | b5q a5q e5q c5q | b4q d#5q f#5q a5q';
const PEAK_B = 'g5h. e5q | f#5h. a5q | b5h. g5q | e5w | c6h. b5q | a5h. f#5q | a5h c6h | b5h d#5h';

// ---------------------------------------------------------------- Cinder Springs: a warm little waltz
const SPRINGS_A = 'd5q g5q a5q | b5h. | a5q g5q e5q | d5h. | d5q g5q a5q | b5q d6q b5q | a5q. g5e e5q | d5h.';
const SPRINGS_B = 'g5h e5q | d5h. | e5q. d5e e5q | b4q d5h | e5q g5q b5q | a5h. | g5q e5q d5q | f#5h.';

// ---------------------------------------------------------------- battles
const BATTLE_A = 'a4e c5e e5e a5e ~e g5e e5q | f#5e a5e ~e f#5e d5q c5q | e5e f5e a5e c6e ~q b5e a5e | g#5q. b5e ~q d6q | a5e c6e ~e a5e e6q d6e c6e | a5e f#5e ~e a5e c6q b5e a5e | a5q c6q b5q d6q | e6q. d6e b5q g#5q';
const BATTLE_B = 'd5q f5e a5e ~q g5e f5e | g5e b5e ~e d6e ~h | e5q g5e b5e ~q a5e g5e | a5q c6e e6e ~h | d6q. b5e ~q a5q | g#5q b5q d6q e6q | c6e b5e a5e g5e e5e g5e a5e c6e | b5q. g#5e ~q e5q';
const BOSS_A = 'c5q. g4e c5e d5e eb5q | c5h ab4h | f4q. c5e f5e g5e ab5q | g5h. b4q | c5q. g4e c5e d5e eb5q | eb5q. c5e ~q ab4q | ab5q. f5e ~q db5q | b4q d5q f5q ab5q';
const BOSS_B = 'eb5h c5q eb5q | f5h d5q f5q | g5q. f5e d5q bb4q | c5h. rq | ab5q. g5e f5q c5q | f5q. eb5e db5q ab4q | b4h d5h | g5q f5q d5q b4q';
const BOSS_TIMP = 'c3q rq rh | ab2q rq rh | f2q rq rh | g2q rq g2q g2q | c3q rq rh | ab2q rq rh | db3q rq rh | g2q g2q g2q g2q';
const BOSS_TIMP_B = 'ab2q rq rh | bb2q rq rh | g2q rq rh | c3q rq c3q c3q | f2q rq rh | db3q rq rh | g2q rq rh | g2q g2q g2q g2q';

// ---------------------------------------------------------------- Count Dusk: a sneaky villain's waltz
const DUSK_A = "bb5q' a5q' g5q' | eb5h. | f#5q' a5q' c6q' | bb5h. | g5q. f5e eb5q | c6q. bb5e g5q | a5q' f#5q' d5q' | d5q f#5q a5q";

// ---------------------------------------------------------------- Old Lumen Castle: a wistful little minuet for an empty ballroom
const CASTLE_A = 'd5q f5q a5q | bb5h f5q | g5q. f5e g5q | e5h. | f5q a5q d6q | c6h a5q | bb5q g5e a5e e5q | d5h.';
const CASTLE_B = 'c6q. a5e f5q | e5q g5q c6q | d6q. c6e a5q | bb5h. | g5q bb5q d6q | c6q. bb5e g5q | a5h f5q | e5h c#5q';
const CASTLE_ARP = { arp: [0, 1, 2, 1, 2, 1], rate: 0.5, range: [57, 74] };
const CASTLE_OOM = { bass: [[0, 0.9, 'R', 0.9], [1, 0.4, '5', 0.55], [2, 0.4, '5', 0.55]] };

const SECRET_A = 'b5e g#5e d#6e b5e ~h | a#5e f#5e c#6e a#5e ~h | g#5q b5q d#6q. c#6e | a#5h. rq | g#5q. e5e b5q c#6q | a#5q. f#5e e5q c#5q | d#5q f#5q a#5q. b5e | g#5h f#5h';

// ---------------------------------------------------------------- Count Dusk's Tower: a sneaky clockwork groove,
// all ticking hats and plucked harpsichord; the music box in the B part hums the lantern motif in a minor key
const TOWER_A = 'd5e f5e a5e d6e ~q c#6q | d6e a5e f5e d5e ~h | bb4e d5e f5e bb5e ~q a5q | g5h. rq | a4e d5e f5e a5e ~q g5q | f5e d5e bb4e d5e ~h | g5q. f5e e5q c#5q | d5h. rq';
const TOWER_B = 'a4q d5q e5q f5q | g5h e5h | e5q a5q g5q e5q | f5w | d5q g5q a5q bb5q | c6h bb5h | a5q f5q c5q f5q | e5h c#5h';
const TICKS = { comp: [[0.5, 0.2, 0.6], [1.5, 0.2, 0.5], [2.5, 0.2, 0.6], [3.5, 0.2, 0.5]], range: [57, 72] };

// ---------------------------------------------------------------- the final battle: Count Dusk's waltz motif, sped up
// into a funk stomp; the B part is the heroes answering with the lantern motif
const FINALE_A = 'bb5e a5e g5e d5e ~q eb5q | ~h. rq | f#5e a5e c6e a5e ~q d6q | bb5h. rq | g5q. f5e eb5q g5q | c6q. bb5e g5q eb5q | a5e f#5e d5e f#5e a5q c6q | bb5q a5q g5q f#5q';
const FINALE_B = 'd5q g5q a5q bb5q | c6h. a5q | a5q d6q c6q a5q | bb5h. g5q | g5q c6q bb5q g5q | a5q. f5e c6q a5q | bb5q d6q f6q d6q | c6h f#5h';
const FINALE_STABS = { comp: [[0, 0.3, 0.9], [1.5, 0.3, 0.7], [2.5, 0.3, 0.8], [3.5, 0.2, 0.6]], range: [55, 72] };

// ---------------------------------------------------------------- The Unfinished Margin: a sketchy hip-hop shuffle for the
// land past the edge of the map. Pizzicato pencil lines, a papery snare and brush scribbles over a slap bass; the hook
// tiptoes up to a curious lydian note, and Doodle's shy ocarina tune in the B part hums the lantern motif
const MARGIN_CH = 'Fmaj7 | G/F | Em7 | Am7 | Dm7 | G7sus4 G7 | Cmaj7 | C7';
const MARGIN_CH2 = 'Fmaj7 | G/F | Em7 | Am7 | Dm7 | G7sus4 G7 | Em7 A7 | Dm7 G7';
const MARGIN_HEAD = "e5e' f5e' g5q' e5e' f5e' b5q | re a5e' g5e' d5q' b4e' d5q' | d5e' e5e' f#5q' d5e' e5e' a5q | re g5e' e5e' c5q' a4e' c5q' | f5e' g5e' a5q' f5e' g5e' d6q | re c6e' b5e' g5q' f5e' d5q'";
const MARGIN_A = `${MARGIN_HEAD} | e5e' g5e' c6q' b5e' g5e' e5q | rq bb5e' a5e' g5e' f5e' e5e' d5e'`;
const MARGIN_A2 = `${MARGIN_HEAD} | g5e' e5e' b5q' c#6e' a5e' e5q | f5e' a5e' d6q' b5e' g5e' f5q`;
const MARGIN_B = 'g4q? c5q? d5q? e5q? | g5h.? rq | a4q? c5q? e5q? f5q? | ab5h. rq | g5q. f#5e e5q d5q | c#5q. e5e a5q g5q | f5q. e5e d5q a5q | bb5q. a5e g5q e5q';
const MARGIN_ANSWER = "rw | rh. b5e' g5e' | rw | rh. c6e' ab5e' | rw | rw | rw | rh. e6e' c6e'";
// slap bass: the root with a ghost note, an octave pop on the "and" of 2, then a step into the next chord
const MARGIN_BASS_HEAD = "f2e.> f2s? re f3e'> re c3e' f2e' e2e' | f2e.> f2s? re f3e'> re d3e' g2e' f2e' | e2e.> e2s? re e3e'> re b2e' g2e' g#2e' | a2e.> a2s? re a3e'> re e3e' g2e' c#2e' | d2e.> d2s? re d3e'> re a2e' c3e' a2e' | g2e.> g2s? re g3e'> re d3e' f2e' b1e'";
const MARGIN_BASS_A = `${MARGIN_BASS_HEAD} | c2e.> c2s? re c3e'> re g2e' e2e' g2e' | c2e.> c2s? re c3e'> re bb2e' g2e' e2e'`;
const MARGIN_BASS_A2 = `${MARGIN_BASS_HEAD} | e2e.> e2s? re e3e'> re a2e' e2e' c#2e' | d2e.> d2s? re d3e'> re g2e' f2e' g#2e'`;
const MARGIN_BASS_B = { bass: [[0, 1.4, 'R', 0.85], [1.5, 0.4, '8', 0.55], [2.5, 0.9, '5', 0.7], [3.5, 0.4, 'R', 0.6]], range: [36, 52] };
const MARGIN_KEYS = { comp: [[[0, 1.4, 0.6], [2.5, 1.2, 0.5]], [[0.5, 0.9, 0.55], [2, 0.4, 0.45], [3.5, 0.4, 0.45]]], rootless: true, range: [55, 72], strum: 0.02 };
const MARGIN_CHK = { comp: [[1, 0.15, 0.7], [1.75, 0.06, 0.35], [3, 0.15, 0.7], [3.5, 0.06, 0.35], [3.75, 0.06, 0.4]], range: [57, 72], strum: 0.008 };
const MARGIN_SCRATCH = { comp: [[0.5, 0.15, 0.7], [1, 0.06, 0.35], [1.25, 0.06, 0.3], [1.5, 0.15, 0.7], [2.5, 0.15, 0.7], [3, 0.06, 0.35], [3.5, 0.15, 0.7], [3.75, 0.06, 0.35]], range: [57, 72], strum: 0.008 };

// ---------------------------------------------------------------- Queen Pristine, the final battle of the Margin: a strict,
// perfect harpsichord toccata in E minor (mordents, scale runs, a circle-of-fifths sequence) over a driving funk beat.
// The B part is the heroes answering with the Margin's hook, done instead of perfect; B2 is the duel, climbing to the top
// on a chromatic bass and a Neapolitan F before it drops back into her theme
const PRISTINE_CH = 'Em | Am | D | G | Cmaj7 | F#m7b5 | B7 | Em';
const PRISTINE_A = 'e6s> d#6s e6q b5e g5e e5e b4q | a4s b4s c5s d5s e5s f#5s g5s a5s c6q b5e a5e | d6s> c#6s d6q a5e f#5e d5e a4q | g4s a4s b4s c5s d5s e5s f#5s g5s b5q a5e g5e | c6s> b5s c6q g5e e5e c5e g4q | f#4s g4s a4s b4s c5s d5s e5s f#5s a5q g5e f#5e | b5e a5e g5e f#5e e5e d#5e c6e b5e | g5e f#5e e5e d#5e e5q rq';
const PRISTINE_B = "b4e' c5e' d5q' b4e' c5e' f#5q | re e5e' d5e' a4q' f#4e' a4q' | a4e' b4e' c#5q' a4e' b4e' e5q | re d5e' b4e' g4q' e4e' g4q' | c5e' d5e' e5q' c5e' d5e' a5q | re g5e' f#5e' d5q' c5e' a4q' | b4e' d5e' g5q' f#5e' d5e' b4q | b4e' d#5e' f#5e' a5e' b5q d#6q";
const PRISTINE_DUEL = 'c6s> b5s c6q re rh | c#6s> c6s c#6q re rh | d6s> c#6s d6q re rh | d#6s> d6s d#6q re rh | e6s> b5s g5s b5s e6s b5s g5s b5s e6q> b5q | e6s> c6s a5s c6s e6s c6s a5s c6s e6q> c6q | f6s> c6s a5s c6s f6s c6s a5s c6s f6q> c6q | b5s> c6s b5s a#5s b5s c6s b5s a#5s b5e d#6e f#6e d#6e';
const PRISTINE_HEROES = "rh e5e' g5e' b5q' | rh e5e' g5e' c#6q' | rh f#5e' a5e' d6q' | rh f#5e' a5e' c6q' | d5q g5q a5q b5q | c6w | c6h a5h | b5w";
const PRISTINE_TIMP = 'e3q rq rh | a2q rq rh | d3q rq rh | g2q rq rh | c3q rq rh | f#2q rq rh | b2q rq b2q b2q | e3q rq rh';
const PRISTINE_TIMP_B2 = 'c3q rq rh | c#3q rq rh | d3q rq rh | d#3q rq rh | e3q rq e3q e3q | a2q rq rh | f2q rq rh | b2e b2e b2e b2e b2e b2e b2e b2e';
const PRISTINE_ARP = { arp: [0, 2, 1, 2, 3, 2, 1, 2], rate: 0.25, range: [52, 67] };
const PRISTINE_BASS = { bass: [[0, 0.35, 'R', 1], [0.5, 0.3, '8', 0.8], [1, 0.35, 'R', 0.85], [1.5, 0.3, '8', 0.8], [1.75, 0.2, '5', 0.6], [2, 0.35, 'R', 0.9], [2.5, 0.3, '8', 0.8], [3, 0.35, 'R', 0.85], [3.5, 0.2, '8', 0.8], [3.75, 0.2, '3', 0.65]] };
const DISCO = { bass: [[0, 0.4, 'R', 1], [0.5, 0.35, '8', 0.85], [1, 0.4, 'R', 0.8], [1.5, 0.35, '8', 0.85], [2, 0.4, 'R', 0.9], [2.5, 0.35, '8', 0.85], [3, 0.4, 'R', 0.8], [3.5, 0.35, '8', 0.85]] };
const PRISTINE_SCRATCH = { comp: [[0.25, 0.06, 0.35], [0.5, 0.2, 0.75], [1.25, 0.06, 0.35], [1.5, 0.2, 0.7], [2.25, 0.06, 0.35], [2.5, 0.2, 0.75], [3.25, 0.06, 0.35], [3.5, 0.2, 0.7]], range: [57, 72], strum: 0.008 };

// ---------------------------------------------------------------- home (Today / Homework / Settings): the main theme, taking it easy
const HOME_CH_A = 'Ebmaj7 | Cm7 | Abmaj7 | Bb7sus4 Bb7 | Ebmaj7 | Gm7 C7 | Fm7 | Bb7sus4 Bb7';
const HOME_A = 'bb4q. eb5e f5q g5q | g5h. f5q | eb5q. c5e ~q ab4q | f5h d5h | bb4q. eb5e f5q g5q | bb5h g5q e5q | ab5q. g5e f5q c5q | eb5h d5h';
const HOME_B = 'c5q eb5q g5q. f5e | f5h d5h | d5q. f5e bb5q a5q | g5w | ab5q. g5e f5q eb5q | d5h f5q ab5q | g5h. bb5q | ab5h f5h';
const HOME_COMP = { comp: [[[0, 1.8, 0.65], [2, 1.8, 0.6]], [[0, 0.9, 0.6], [1.5, 2.4, 0.65]]], rootless: true, range: [55, 72] };
const TWO = { bass: [[0, 1.8, 'R', 0.85], [2, 1.8, '5', 0.7]] };

// ---------------------------------------------------------------- menus (pause menu, shops, the map): a bouncy little shopping tune
const MENU_A = "f5e' d5e' bb4e' d5e' f5q a5q | g5e' f5e' d5e' bb4e' g4h | eb5e' g5e' c6e' bb5e' ~q g5q | a5q. f5e c5q eb5q | f5e' d5e' bb4e' d5e' f5q bb5q | d6q bb5e' g5e' ~q f5q | eb5q g5q a5q c6q | bb5q. g5e bb5q rq";
const MENU_B = 'g5q. bb5e ~q g5q | bb5q. g5e ~q e5q | f5q d5q bb4q d5q | b4q. d5e f5q g5q | eb5q. g5e c6q bb5q | a5q. c6e eb6q c6q | d6q a5q b5q f5q | eb5q g5q a5q f5q';
const MENU_PIZZ = { comp: [[1, 0.3, 0.6], [3, 0.3, 0.6]], range: [57, 72] };

// ---------------------------------------------------------------- study music
// Made up fresh every few minutes, so a long session never loops the same tune. It stays soft and
// steady on purpose: no big hooks, nothing that pulls your attention off the work.
function rngOf(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const pick = (r, list) => list[Math.floor(r() * list.length)];
const NAMES_FLAT = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'Gb', 'G', 'Ab', 'A', 'Bb', 'B'];
const NAMES_SHARP = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
const STUDY_IV = { maj7: [0, 4, 7, 11], maj9: [0, 4, 7, 11, 2], m7: [0, 3, 7, 10], m9: [0, 3, 7, 10, 2], 7: [0, 4, 7, 10],
  9: [0, 4, 7, 10, 2], '7sus4': [0, 5, 7, 10], m6: [0, 3, 7, 9], add9: [0, 4, 7, 2], '': [0, 4, 7], m: [0, 3, 7] };
// a chord is [semitones above the key, quality]
const symbol = (key, [deg, q], sharp = [2, 4, 7, 9, 11].includes(key)) => (sharp ? NAMES_SHARP : NAMES_FLAT)[(key + deg) % 12] + q;
const tonesOf = (key, [deg, q]) => STUDY_IV[q].map(x => (key + deg + x) % 12);
const pcDist = (a, b) => (((a - b) % 12) + 12) % 12;

// A short, lazy tune: notes from the major pentatonic that don't rub against the chord, ending on a chord tone.
function noodle(r, key, prog, beatsPerChord, [lo, hi], rhythm) {
  const penta = [0, 2, 4, 7, 9].map(x => (key + x) % 12);
  let prev = Math.round((lo + hi) / 2);
  return rhythm.map(([b, d], i) => {
    const tones = tonesOf(key, prog[Math.min(prog.length - 1, Math.floor(b / beatsPerChord))]);
    const ok = i === rhythm.length - 1 ? tones
      : tones.concat(penta.filter(pc => tones.every(t => ![1, 11].includes(pcDist(pc, t)))));
    const target = prev + Math.round((r() - 0.5) * 8);
    let best = prev, bd = 99;
    for (let m = lo; m <= hi; m++) if (ok.includes(m % 12) && Math.abs(m - target) < bd) { bd = Math.abs(m - target); best = m; }
    prev = best;
    return { b, d, m: best, v: 0.5 + r() * 0.2 };
  });
}

const LOFI_PROGS = [
  [[2, 'm9'], [7, '7'], [0, 'maj9'], [9, 'm7']],
  [[5, 'maj7'], [4, 'm7'], [2, 'm7'], [0, 'maj7']],
  [[0, 'maj9'], [9, 'm9'], [2, 'm9'], [7, '7sus4']],
  [[5, 'maj9'], [5, 'm6'], [4, 'm7'], [9, '7']],
  [[9, 'm9'], [2, 'm9'], [7, '9'], [0, 'maj7']],
  [[0, 'maj7'], [0, 'maj7'], [5, 'maj9'], [5, 'maj9']],
  [[4, 'm7'], [9, 'm7'], [2, 'm9'], [7, '7sus4']],
];
const LOFI_DRUMS = {
  L1: { k: 'x.......x.x.....', ls: '....x.......x...', h: 'o.o.o.o.o.o.o.o.' },
  L2: { k: 'x.....x...x.....', ls: '....x.......x..o', h: 'o.o.o.o.o.oo.o.o' },
  L3: { k: 'x.........x.....', ls: '........x.......', h: 'o...o...o...o...' },
  L4: { k: 'x.......x..x....', ls: '....x.......x...', h: '..o...o...o...o.', sh: 'o.o.o.o.o.o.o.o.' },
  LF: { k: 'x.......x.......', ls: '....x.......x.oo', h: 'o.o.o.o.o.o.....' },
  V: { crackle: 'x...............' },
};
const LOFI_KEYS = [[[0, 3.8, 0.7]], [[0, 1.9, 0.7], [2.5, 1.4, 0.6]], [[0, 0.9, 0.65], [1.5, 2.3, 0.7]]];
const LOFI_BASS = [
  [[0, 1.5, 'R', 0.85], [2.5, 0.5, '5', 0.6], [3, 0.9, 'R', 0.7]],
  [[0, 2.8, 'R', 0.85], [3.5, 0.45, '5', 0.6]],
  [[0, 0.9, 'R', 0.8], [1.5, 0.45, 'R', 0.55], [2, 1.4, '5', 0.7], [3.5, 0.45, '8', 0.5]],
];
const LOFI_TUNES = [   // [beat, length] over 4 bars, with plenty of room to breathe
  [[0.5, 0.5], [1, 1], [2, 1.5], [4.5, 0.5], [5, 2.5]],
  [[1, 0.5], [1.5, 0.5], [2, 2], [8.5, 0.5], [9, 0.5], [9.5, 2]],
  [[0, 1.5], [1.5, 0.5], [2, 1], [3, 1], [8, 3]],
  [[2.5, 0.5], [3, 1], [4, 2], [10.5, 0.5], [11, 1], [12, 3]],
  [[0, 0.5], [0.5, 0.5], [1, 0.5], [1.5, 2.5], [6, 2]],
];

// lo-fi beats: dusty keys, a round bass, lazy drums, record crackle and now and then a few soft notes on top
function lofi(seed) {
  const r = rngOf(seed);
  const key = pick(r, [5, 3, 2, 8, 0, 7, 10]);
  const progs = [pick(r, LOFI_PROGS), pick(r, LOFI_PROGS)];
  const blocks = 12 + Math.floor(r() * 5), loop = [], sections = {};
  for (let i = 0; i < blocks; i++) {
    const prog = progs[Math.floor(i / 4) % 2];
    const role = i === 0 ? 'intro' : i === blocks - 1 ? 'outro' : i % 5 === 4 ? 'rest' : 'full';
    const groove = pick(r, ['L1', 'L2', 'L4']);
    const sec = {
      chords: prog.map(c => symbol(key, c)).join(' | '),
      keys: { comp: pick(r, LOFI_KEYS), rootless: true, range: [55, 72], strum: 0.025 },
      vinyl: 'V',
    };
    if (role !== 'intro') sec.bass = { bass: pick(r, LOFI_BASS) };
    if (role === 'full') sec.drums = `${groove} ${groove} ${groove} LF`;
    if (role === 'rest') sec.drums = 'L3';
    if (role !== 'intro' && role !== 'outro' && r() < 0.55) sec.mel = { ev: noodle(r, key, prog, 4, [65, 79], pick(r, LOFI_TUNES)) };
    sections['S' + i] = sec;
    loop.push('S' + i);
  }
  return {
    bpm: pick(r, [72, 74, 76, 78]), swing: 0.45, gain: 0.9,
    parts: {
      keys: { inst: 'rhodes', vol: 0.6, pan: -0.1, verb: 0.25, lp: 2600 },
      bass: { inst: 'fretless', vol: 0.4, range: [33, 50] },
      mel: { inst: pick(r, ['vibes', 'kalimba', 'glass']), vol: 0.65, pan: 0.2, verb: 0.35, lp: 3200 },
      drums: { kit: true, vol: 0.55, verb: 0.05, lp: 3600 },
      vinyl: { kit: true, vol: 1 },
    },
    drums: LOFI_DRUMS, loop, sections,
  };
}

const CALM_PROGS = [
  [[0, 'maj9'], [9, 'm9'], [5, 'maj9'], [7, '7sus4']],
  [[5, 'maj7'], [0, 'maj7'], [2, 'm9'], [9, 'm7']],
  [[0, 'add9'], [4, 'm7'], [5, 'maj7'], [5, 'm6']],
  [[9, 'm9'], [5, 'maj9'], [0, 'maj9'], [7, '7sus4']],
];
const CALM_ARPS = [[0, 1, 2, 3, 4, 3, 2, 1], [0, 2, 4, 2, 1, 3, 5, 3], [0, 1, 2, 4, 3, 2, 1, 2]];
const CALM_TUNES = [[[4, 4], [8, 6], [16, 4], [24, 8]], [[0, 2], [2, 2], [4, 8], [20, 6]], [[8, 3], [11, 1], [12, 8], [26, 4]]];

// calm piano: slow rolling chords, a soft pad, and a few bell notes floating on top
function calm(seed) {
  const r = rngOf(seed);
  const key = pick(r, [0, 5, 7, 2, 3, 8]);
  const prog = pick(r, CALM_PROGS);
  const blocks = 4 + Math.floor(r() * 3), loop = [], sections = {};
  for (let i = 0; i < blocks; i++) {
    const sec = {
      chords: prog.map(c => `${symbol(key, c)} | %`).join(' | '),
      piano: { arp: pick(r, CALM_ARPS), rate: 0.5, range: [52, 67], hold: 3 },
      pad: { pad: true, range: [55, 72] },
      bass: { bass: [[0, 3.9, 'R', 0.6]] },
    };
    if (i > 0 && r() < 0.6) sec.bell = { ev: noodle(r, key, prog, 8, [74, 86], pick(r, CALM_TUNES)) };
    sections['C' + i] = sec;
    loop.push('C' + i);
  }
  return {
    bpm: pick(r, [62, 64, 66]), room: 'hall', gain: 1.15,
    parts: {
      piano: { inst: 'piano', vol: 0.6, pan: -0.1, verb: 0.45 },
      pad: { inst: 'pad', vol: 0.6, verb: 0.5 },
      bass: { inst: 'sub', vol: 0.25, range: [33, 48] },
      bell: { inst: 'glass', vol: 0.35, pan: 0.2, verb: 0.6 },
    },
    loop, sections,
  };
}

// ---------------------------------------------------------------- game funk: study music for an intense lock-in
// Acid-jazz and game-funk grooves in the spirit of Persona and Sonic: slap bass, chicken-scratch guitar, electric
// piano, brass stabs and a short FM-synth hook that repeats until it's part of the furniture. It builds with your
// focus combo (energy 0..1): brass first, then congas and the hook, then a faster tempo with busier hats.
// Minor-key funk, as [semitones above the key's root, quality]
const FUNK_PROGS = [
  [[0, 'm9'], [0, 'm9'], [5, '9'], [5, '9']],         // dorian vamp: i9 IV9
  [[0, 'm9'], [10, '9'], [8, 'maj7'], [7, '7']],      // i9 VII9 VImaj7 V7
  [[0, 'm7'], [5, 'm7'], [10, '9'], [3, 'maj7']],     // i iv VII III
  [[8, 'maj7'], [7, '7'], [0, 'm9'], [0, 'm9']],      // VImaj7 V7 i i
  [[0, 'm9'], [3, 'maj7'], [5, 'm7'], [7, '7sus4']],  // i III iv Vsus
];
const FUNK_BASS = [
  [[0, 0.4, 'R', 1], [0.75, 0.2, '8', 0.85], [1, 0.2, 'R', 0.55], [1.5, 0.4, 'R', 0.9], [2.25, 0.2, '8', 0.85], [2.5, 0.2, '7', 0.7],
    [3, 0.4, '5', 0.85], [3.5, 0.2, 'R', 0.6], [3.75, 0.2, '8', 0.8]],
  [[0, 0.6, 'R', 1], [0.75, 0.2, 'R', 0.6], [1, 0.2, '8', 0.9], [1.5, 0.4, 'R', 0.8], [2, 0.2, '5', 0.75], [2.5, 0.4, 'R', 0.85],
    [3.25, 0.2, '7', 0.75], [3.5, 0.4, '8', 0.9]],
  FUNK.bass,
];
const FUNK_GTR = [   // chicken scratch: muted ghost strums between short chord stabs
  [[0.25, 0.06, 0.35], [0.5, 0.2, 0.75], [1.25, 0.06, 0.35], [1.5, 0.2, 0.7], [2.25, 0.06, 0.35], [2.5, 0.2, 0.75], [3.25, 0.06, 0.35], [3.5, 0.2, 0.7]],
  [[0, 0.15, 0.7], [0.5, 0.06, 0.35], [0.75, 0.15, 0.7], [1.5, 0.06, 0.35], [1.75, 0.2, 0.75], [2.5, 0.06, 0.35], [3, 0.15, 0.7], [3.75, 0.06, 0.4]],
];
const FUNK_KEYS = [[[0, 1.4, 0.6], [2.5, 1.2, 0.55]], [[0.5, 0.9, 0.55], [2, 0.4, 0.5], [3.5, 0.4, 0.5]]];
const FUNK_BRASS = [[[1.5, 0.25, 0.9], [3, 0.25, 0.85]], [[0, 0.25, 0.9], [0.75, 0.25, 0.75], [2.5, 0.5, 0.85]]];
const FUNK_HOOKS = [   // 16th-note hits over two bars: a phrase, then room to breathe
  'x..x..x.x.......x..x..x.xx......',
  '..x.x..x...x....x.x.x..x..x.....',
  'x.x...x.x...x...x.x.....x.x.x...',
];
const FUNK_DRUMS = {
  G1: { k: 'x.....x...x.....', s: '....x..o....x..o', h: 'xoxoxoxoxoxoxoxo' },
  G2: { k: 'x..x......x..x..', s: '....x.o.....x...', h: 'xoxoxoxoxoxoxoxo', oh: '......x.......x.' },
  G3: { k: 'x.....x...x.x...', s: '....x..o.o..x..o', h: 'xxxxxxxxxxxxxxxx', tb: '....x.......x...' },   // busier, once you're locked in
  FL: { k: 'x.....x...x.....', s: '....x.......xxXX', h: 'xoxoxoxoxoxo....' },                            // a fill into the next part
  BR: { k: 'x.........x.....', h: 'x.x.x.x.x.x.x.x.', cg: '..x..x....x..x.x' },                            // breakdown
  P: { cg: '..x..x....x..x.x', bg: 'x.....x.x.....x.' },                                                     // congas and bongos on top
  C: { cr: 'X...............' },
};

// A repeating riff: its rhythm and melodic shape come back every two bars while the notes bend to fit each chord.
function riff(r, key, prog, rhythm, shape, lo) {
  const scale = [0, 3, 5, 7, 10].map(x => (key + x) % 12);   // minor pentatonic
  const out = [];
  prog.forEach((c, bar) => {
    const tones = tonesOf(key, c);
    const ok = tones.concat(scale.filter(pc => tones.every(t => ![1, 11].includes(pcDist(pc, t)))));
    const notes = [];
    for (let m = lo; m < lo + 13; m++) if (ok.includes(m % 12)) notes.push(m);
    for (let s = 0; s < 16; s++) {
      const i = (bar % 2) * 16 + s;
      if (rhythm[i] === 'x') out.push({ b: bar * 4 + s / 4, d: 0.25, m: notes[Math.min(shape[i], notes.length - 1)], v: s % 4 === 0 ? 0.9 : 0.7 });
    }
  });
  return out;
}

function funk(seed, energy = 0.5) {
  const r = rngOf(seed);
  const key = pick(r, [4, 9, 2, 7, 0, 5]), sharp = key === 4 || key === 9;
  const progs = [pick(r, FUNK_PROGS), pick(r, FUNK_PROGS)];
  const bass = pick(r, FUNK_BASS), gtr = pick(r, FUNK_GTR), keys = pick(r, FUNK_KEYS), brass = pick(r, FUNK_BRASS);
  const hook = pick(r, FUNK_HOOKS), shape = [...hook].map(() => pick(r, [0, 1, 2, 2, 3, 4]));
  const lo = key > 6 ? 60 + key : 72 + key;   // the hook's root, G4..F5
  const groove = energy > 0.65 ? 'G3' : pick(r, ['G1', 'G2']);
  const plan = ['groove', 'groove', 'full', 'full', 'break', 'groove', 'hype', 'hype', 'full', 'hype', 'hype', 'full'];
  const loop = [], sections = {};
  plan.forEach((role, i) => {
    const prog = progs[i < 5 ? 0 : 1];
    const sec = { chords: prog.map(c => symbol(key, c, sharp)).join(' | '), bass: { bass } };
    if (role === 'break') {
      sec.drums = 'BR';
      sec.keys = { comp: keys, rootless: true, range: [55, 72] };
    } else {
      sec.drums = `${groove} ${groove} ${groove} FL`;
      sec.hits = 'C - - -';
      sec.gtr = { comp: gtr, range: [57, 72], strum: 0.008 };
      if (role !== 'groove') sec.keys = { comp: keys, rootless: true, range: [55, 72] };
      if (role !== 'groove' && energy > 0.3) sec.brass = { comp: brass, range: [55, 70] };
      if (role !== 'groove' && energy > 0.5) sec.perc = 'P';
      if (role === 'hype' && energy > 0.5) sec.lead = { ev: riff(r, key, prog, hook, shape, lo) };
    }
    sections['F' + i] = sec;
    loop.push('F' + i);
  });
  return {
    bpm: Math.round(112 + energy * 12 + r() * 4), delayBeats: 0.75, delayFb: 0.3, gain: 0.8,
    parts: {
      bass: { inst: 'slap', vol: 0.52, range: [28, 47] },
      gtr: { inst: 'funkgtr', vol: 1.28, pan: -0.3, verb: 0.15 },
      keys: { inst: 'epiano', vol: 0.4, pan: 0.25, verb: 0.25 },
      brass: { inst: 'brass', vol: 0.45, pan: 0.15, verb: 0.2 },
      lead: { inst: 'fmlead', vol: 1.18, pan: 0.05, verb: 0.25, delay: 0.15 },
      drums: { kit: true, vol: 0.5, verb: 0.06 },
      hits: { kit: true, vol: 0.45, verb: 0.2 },
      perc: { kit: true, vol: 0.45, pan: 0.3, verb: 0.15 },
    },
    drums: FUNK_DRUMS, loop, sections,
  };
}

// Lantern Beat, the rhythm game at the Lantern Square carnival: one fixed game-funk groove (a song that's the same
// every time, so the notes you play can land on its beats). Two bars of drums count you in; then the groove, the full
// band, and the hook twice.
function lanternBeat() {
  const r = rngOf(1123), key = 4, prog = FUNK_PROGS[0];   // E dorian: Em9 Em9 A9 A9
  const chords = prog.map(c => symbol(key, c, true)).join(' | ');
  const hook = FUNK_HOOKS[0], shape = [...hook].map(() => pick(r, [0, 1, 2, 2, 3, 4]));
  const gtr = { comp: FUNK_GTR[0], range: [57, 72], strum: 0.008 }, keys = { comp: FUNK_KEYS[0], rootless: true, range: [55, 72] };
  const band = { chords, bass: { bass: FUNK_BASS[0] }, gtr, keys, brass: { comp: FUNK_BRASS[0], range: [55, 70] }, perc: 'P' };
  return {
    bpm: 112, delayBeats: 0.75, delayFb: 0.3, gain: 0.8,
    parts: {
      bass: { inst: 'slap', vol: 0.52, range: [28, 47] },
      gtr: { inst: 'funkgtr', vol: 1.28, pan: -0.3, verb: 0.15 },
      keys: { inst: 'epiano', vol: 0.4, pan: 0.25, verb: 0.25 },
      brass: { inst: 'brass', vol: 0.45, pan: 0.15, verb: 0.2 },
      lead: { inst: 'fmlead', vol: 1.18, pan: 0.05, verb: 0.25, delay: 0.15 },
      drums: { kit: true, vol: 0.5, verb: 0.06 },
      hits: { kit: true, vol: 0.45, verb: 0.2 },
      perc: { kit: true, vol: 0.45, pan: 0.3, verb: 0.15 },
    },
    drums: FUNK_DRUMS,
    intro: ['I'],
    loop: ['A', 'B', 'C', 'D'],
    sections: {
      I: { bars: 2, drums: 'G1 FL' },
      A: { chords, bass: { bass: FUNK_BASS[0] }, gtr, drums: 'G1 G1 G1 FL', hits: 'C - - -' },
      B: { ...band, drums: 'G2 G2 G2 FL', hits: 'C - - -' },
      C: { ...band, drums: 'G3 G3 G3 FL', hits: 'C - - -', lead: { ev: riff(r, key, prog, hook, shape, 76) } },
      D: { ...band, drums: 'G3 G3 G3 FL', hits: 'C - - -', lead: { ev: riff(r, key, prog, hook, shape, 76) } },
    },
  };
}

// rain sounds: deep brown noise and rain hiss with drops scattered on top (no music at all)
function rain(seed) {
  const r = rngOf(seed), drums = { B: { brown: 'x', rain: 'x' } };
  for (let i = 0; i < 8; i++) {
    let s = '';
    for (let k = 0; k < 32; k++) s += r() < 0.3 ? (r() < 0.3 ? 'x' : 'o') : '.';
    drums['D' + i] = { drop: s };
  }
  return {
    bpm: 60, gain: 1,   // 60 bpm = the 4-second bars the noise beds are built for
    parts: { bed: { kit: true, vol: 0.8 }, drops: { kit: true, vol: 0.9, verb: 0.25 } },
    drums, loop: ['R'],
    sections: { R: { bars: 16, bed: 'B', drops: [...Array(16)].map(() => 'D' + Math.floor(r() * 8)).join(' ') } },
  };
}

export const SONGS = {
  town: {
    bpm: 108, swing: 0.55, resume: true, gain: 0.85,
    parts: {
      vibes: { inst: 'vibes', vol: 0.66, pan: 0.2, verb: 0.3 },
      flute: { inst: 'flute', vol: 0.71, pan: -0.15, verb: 0.35 },
      keys: { inst: 'epiano', vol: 0.35, pan: -0.25, verb: 0.2 },
      bass: { inst: 'upright', vol: 0.45, range: [31, 50] },
      drums: { kit: true, vol: 0.88, verb: 0.08 },
    },
    drums: {
      S: { r: 'o...o.o.o...o.o.', b: '....x.......x...', k: 'o.......o.......', h: '....o.......o...' },
      F: { r: 'o...o.o.o.......', b: '....x.....o.x.ox', k: 'o.......o.....o.', h: '....o.......o...' },
    },
    intro: ['I'],
    loop: ['A', 'A2', 'B', 'A4'],
    sections: {
      I: { chords: 'Fmaj7 | Gm7 C7', vibes: 'rw | rh. re c5e', keys: SWING_COMP, bass: WALK, drums: 'S F' },
      A: { chords: 'Fmaj7 | Dm7 | Gm7 | C7 | Fmaj7 | Bb7 | Am7 D7 | Gm7 C7', vibes: TOWN_A, keys: SWING_COMP, bass: WALK, drums: 'S S S S S S S F' },
      A2: { chords: TOWN_CH, flute: TOWN_A2, keys: SWING_COMP, bass: WALK, drums: 'S S S S S S S F' },
      B: {
        chords: 'Bbmaj7 | Bbm6 | Am7 | D7 | Gm7 | C7 | Am7 Dm7 | Gm7 C7',
        vibes: 'd6h. c6q | bb5h db6q c6q | c6q. a5e ~h | rq a5e b5e c6q f#5q | bb5h. a5q | g5q. e5e ~q c5q | c6q a5q d6q a5q | bb5q. a5e g5q re c5e',
        flute: 'f5w? | f5w? | e5w? | f#5w? | d5w? | e5w? | e5h? f5h? | d5h? e5h?',
        keys: SWING_COMP, bass: WALK, drums: 'S S S S S S S F',
      },
      A4: { chords: TOWN_CH, vibes: TOWN_A4, flute: { n: TOWN_A4, tr: -12 }, keys: SWING_COMP, bass: WALK, drums: 'S S S S S S S F' },
    },
  },

  night: {
    bpm: 72, room: 'hall', resume: true, gain: 0.91,
    parts: {
      box: { inst: 'musicbox', vol: 0.91, pan: 0.15, verb: 0.45, delay: 0.2 },
      strings: { inst: 'strings', vol: 0.25, pan: -0.1, verb: 0.4 },
      melo: { inst: 'strings', vol: 0.95, pan: 0.05, verb: 0.4 },
      harp: { inst: 'harp', vol: 0.8, pan: -0.25, verb: 0.35 },
      bass: { inst: 'sub', vol: 0.26, range: [33, 48] },
    },
    loop: ['A', 'B'],
    sections: {
      A: { chords: NIGHT_CH, box: NIGHT_MEL, strings: { pad: true, range: [50, 69] }, bass: HOLD },
      B: { chords: NIGHT_CH, melo: { n: NIGHT_MEL, tr: -12 }, harp: { arp: [0, 1, 2, 3, 4, 3, 2, 1], rate: 0.5, range: [45, 62] }, bass: HOLD },
    },
  },

  fields: {
    bpm: 126, resume: true, gain: 0.83,
    parts: {
      flute: { inst: 'flute', vol: 0.66, pan: 0.15, verb: 0.25 },
      horn: { inst: 'horn', vol: 0.93, pan: -0.15, verb: 0.3 },
      pizz: { inst: 'pizz', vol: 1.1, pan: -0.3, verb: 0.15 },
      strings: { inst: 'strings', vol: 0.28, pan: 0.25, verb: 0.3 },
      bass: { inst: 'pick', vol: 0.54, range: [33, 52] },
      drums: { kit: true, vol: 0.44, verb: 0.06 },
    },
    drums: {
      G: { k: 'x.......x.x.....', s: '....x.......x...', sh: 'o.x.o.x.o.x.o.x.', tb: '....o.......o...' },
      C: { cr: 'x...............', k: 'x.......x.x.....', s: '....x.......x...', sh: 'o.x.o.x.o.x.o.x.' },
      F: { k: 'x.......x.......', s: '....x...........', sh: 'o.x.o.x.o.x.....', t1: '........x.x.....', t2: '............x.x.' },
    },
    intro: ['I'],
    loop: ['A', 'A2', 'B'],
    sections: {
      I: { chords: 'D | A7sus4 A7', pizz: { arp: [0, 2, 1, 2], rate: 0.5, range: [55, 72] }, strings: PAD, bass: GALLOP, drums: 'G F' },
      A: {
        chords: 'D | Gmaj7 | Bm7 | A | G | D/F# | Em7 | A7',
        flute: `${FIELDS_HEAD} | a5q. f#5e ~q d5q | e5q g5q b5q d6q | e6h c#6q rq`,
        pizz: { arp: [0, 2, 1, 2], rate: 0.5, range: [55, 72] }, strings: { pad: true, range: [55, 74] }, bass: GALLOP, drums: 'C G G G G G G F',
      },
      A2: {
        chords: 'D | Gmaj7 | Bm7 | A | G | A/G | F#m7 B7 | Em7 A7',
        flute: `${FIELDS_HEAD} | c#6q. b5e ~q a5q | c#6q a5q b5q a5q | g5q. f#5e e5q c#5q`,
        pizz: { arp: [0, 2, 1, 2], rate: 0.5, range: [55, 72] }, strings: { pad: true, range: [55, 74] }, bass: GALLOP, drums: 'G G G G G G G F',
      },
      B: {
        chords: 'Gmaj7 | A/G | F#m7 | Bm7 | Em7 | F#m7 | Gmaj7 | A7sus4 A7',
        horn: 'd4q g4q b4q. a4e | a4h e4h | f#4q a4q c#5q. b4e | b4h. rq | g4q b4q e5q. d5e | c#5h a4h | b4q d5q f#5q. e5e | d5h c#5h',
        flute: 'rw | rw | rw | rw | b5h.? a5q? | a5h.? rq | f#5h.? g5q? | a5w?',
        pizz: { arp: [0, 2, 1, 2], rate: 0.5, range: [55, 72] }, strings: { pad: true, range: [55, 74] }, bass: GALLOP, drums: 'C G G G G G G F',
      },
    },
  },

  lake: {
    bpm: 112, resume: true, gain: 0.94,
    parts: {
      reed: { inst: 'reed', vol: 0.66, pan: 0.15, verb: 0.3, glide: 0.04 },
      guitar: { inst: 'guitar', vol: 0.66, pan: -0.2, verb: 0.2 },
      keys: { inst: 'epiano', vol: 0.3, pan: 0.25, verb: 0.25 },
      bass: { inst: 'fretless', vol: 0.38, range: [31, 50], glide: 0.05 },
      drums: { kit: true, vol: 0.58, verb: 0.1 },
    },
    drums: {
      B1: { rim: 'x.....x.....x...', sh: 'o.x.o.x.o.x.o.x.', k: 'o.....o.o.....o.' },
      B2: { rim: '....x.....x.....', sh: 'o.x.o.x.o.x.o.x.', k: 'o.....o.o.....o.' },
    },
    intro: ['I'],
    loop: ['A', 'A2', 'B', 'A2'],
    sections: {
      I: { chords: 'Gmaj7 | Am7 D7', guitar: BOSSA, bass: BOSSA_BASS, drums: 'B1 B2' },
      A: {
        chords: 'Gmaj7 | G6 | Am7 | D7 | Gmaj7 | Cmaj7 | Bm7 E7 | Am7 D7',
        reed: `${LAKE_HEAD} | d6q a5q g#5q b5q | c6q. b5e a5q f#5q`, guitar: BOSSA, bass: BOSSA_BASS, drums: 'B1 B2',
      },
      A2: {
        chords: 'Gmaj7 | G6 | Am7 | D7 | Gmaj7 | Cmaj7 | Am7 D7 | G6',
        reed: `${LAKE_HEAD} | e5q. c6e ~q a5q | g5h. rq`, guitar: BOSSA, bass: BOSSA_BASS, drums: 'B1 B2',
      },
      B: {
        chords: 'Cmaj7 | Cm6 | Bm7 | E7 | Am7 | D7 | Gmaj7 | Am7 D7',
        reed: 'e5q g5q b5q. a5e | a5h eb5q. g5e | f#5h. re d5e | g#5q. b5e ~q d6q | c6h. b5q | a5q f#5q d5q c5q | b4q. d5e ~q f#5q | e5q. c5e ~q a4q',
        keys: { pad: true, rootless: true, range: [57, 74] }, guitar: BOSSA, bass: BOSSA_BASS, drums: 'B1 B2',
      },
    },
  },

  grove: {
    bpm: 104, swing: 0.85, resume: true, gain: 0.97,
    parts: {
      oca: { inst: 'ocarina', vol: 0.7, pan: 0.1, verb: 0.3 },
      bsn: { inst: 'bassoon', vol: 1, pan: -0.1, verb: 0.15, range: [38, 55] },
      kal: { inst: 'kalimba', vol: 0.41, pan: 0.3, verb: 0.25 },
      drums: { kit: true, vol: 0.6, verb: 0.1 },
    },
    drums: {
      W: { k: 'x.......o.......', wb: '....x.......x...', wl: '..o.......o.....', sh: 'o.o.o.o.o.o.o.o.' },
      F: { k: 'x.......x.......', wb: '....x...x...x.x.', bg: 'x.x.x.x.........' },
    },
    intro: ['I'],
    loop: ['A', 'B', 'A', 'B'],
    sections: {
      I: { chords: 'Dm7 | Dm7', bsn: GRUMBLE, drums: 'W F' },
      A: {
        chords: 'Dm7 | G7 | Dm7 | G7 | Bbmaj7 | C | Dm7 | A7',
        oca: GROVE_A, bsn: GRUMBLE, kal: { comp: [[1, 0.3, 0.7], [3, 0.3, 0.7], [3.5, 0.25, 0.5]], range: [62, 79] }, drums: 'W W W W W W W F',
      },
      B: {
        chords: 'Gm7 | C7 | Fmaj7 | Bbmaj7 | Em7b5 | A7 | Dm7 | A7',
        bsn: "g2q bb2e' c3e' d3q bb2q | c3q rq g2q rq | f2q a2e' bb2e' c3q a2q | bb2q rq f2q rq | e2q g2e' a2e' bb2q g2q | a2q rq e2q rq | d3q c3e' bb2e' a2q g2q | a2q e2q a2q c#3q",
        oca: 'rw | e5e g5e bb5e g5e ~q rq | rw | d5e f5e a5e f5e ~q rq | rw | c#5e e5e g5e bb5e ~q a5q | rh f5q a5q | g5q. e5e c#5q a4q',
        kal: { comp: [[1, 0.3, 0.7], [3, 0.3, 0.7], [3.5, 0.25, 0.5]], range: [62, 79] }, drums: 'W W W W W W W F',
      },
    },
  },

  caves: {
    bpm: 80, room: 'hall', resume: true, delayBeats: 0.75, delayFb: 0.38,
    parts: {
      glass: { inst: 'glass', vol: 0.67, pan: 0.1, verb: 0.55, delay: 0.3 },
      harp: { inst: 'harp', vol: 0.75, pan: -0.2, verb: 0.45 },
      pad: { inst: 'pad', vol: 0.45, verb: 0.5 },
      sub: { inst: 'sub', vol: 0.26, range: [33, 45] },
      drums: { kit: true, vol: 0.77, verb: 0.6 },
    },
    drums: {
      D1: { k: 'o...............', drip: '..........x.....' },
      D2: { drip: '......x.......o.' },
      D3: { k: 'o...............', drip: '...o............' },
      D4: { drip: '..........x..o..' },
    },
    intro: ['I'],
    loop: ['A', 'B'],
    sections: {
      I: { chords: 'Am | Am', harp: { arp: [0, 1, 2, 3, 4, 3, 2, 1], rate: 0.5, range: [45, 64] }, sub: HOLD, drums: 'D1 D2' },
      A: {
        chords: 'Am | Fmaj7 | Dm7 | E7sus4 E7 | Am | Fmaj7 | Bbmaj7 | E7',
        glass: 'e4q. a4e b4q c5q | e5h. d5q | c5h a4h | b4h g#4h | e4q. a4e b4q c5q | a5h. g5q | d5h f5h | e5w',
        harp: { arp: [0, 1, 2, 3, 4, 3, 2, 1], rate: 0.5, range: [45, 64] }, pad: { pad: true, range: [52, 69] }, sub: HOLD, drums: 'D1 D2 D3 D4',
      },
      B: {
        chords: 'Fmaj7 | G | Em7 | Am | Dm7 | Em7 | Fmaj7 | E7sus4 E7',
        glass: 'c5q. e5e a5h | b5h. g5q | g5q. b5e e5h | c6h b5q a5q | f5q. a5e d6h | b5h. a5q | a5h g5q f5q | a5h g#5h',
        harp: { arp: [0, 1, 2, 3, 4, 3, 2, 1], rate: 0.5, range: [45, 64] }, pad: { pad: true, range: [52, 69] }, sub: HOLD, drums: 'D1 D2 D3 D4',
      },
    },
  },

  peak: {
    bpm: 138, resume: true, gain: 0.78,
    parts: {
      brass: { inst: 'brass', vol: 0.97, pan: 0.1, verb: 0.25 },
      strings: { inst: 'strings', vol: 1.09, pan: -0.15, verb: 0.3 },
      ost: { inst: 'stac', vol: 0.91, pan: -0.3, verb: 0.15 },
      stabs: { inst: 'brass', vol: 0.37, pan: 0.3, verb: 0.2 },
      bass: { inst: 'synbass', vol: 0.48, range: [28, 47] },
      drums: { kit: true, vol: 0.36, verb: 0.1 },
    },
    drums: {
      P: { k: 'x.......x.x.....', s: '....x.......x...', h: 'x.x.x.x.x.x.x.x.', tk: 'x.....x.........' },
      C: { cr: 'x...............', k: 'x.......x.x.....', s: '....x.......x...', h: '..x.x.x.x.x.x.x.', tk: 'x.....x.........' },
      F: { k: 'x.......x.......', s: '....x...x.x.xxxx', h: 'x.x.x.x.........', tk: 'x.....x.........' },
    },
    intro: ['I'],
    loop: ['A', 'B', 'A2', 'B2'],
    sections: {
      I: { chords: 'Em | Em', ost: { arp: [0, 1, 2, 1], rate: 0.25, range: [64, 76] }, bass: DRIVE, drums: 'P F' },
      A: {
        chords: 'Em | C | D | Bm | Em | C | Am | B7',
        brass: PEAK_A, ost: { arp: [0, 1, 2, 1], rate: 0.25, range: [64, 76] }, bass: DRIVE, drums: 'C P P P P P P F',
      },
      B: {
        chords: 'C | D | Em | Em | Cmaj7 | D | F | B7',
        strings: PEAK_B, stabs: { comp: [[0, 0.3, 0.9], [1.5, 0.3, 0.7], [2.5, 0.3, 0.8]], range: [55, 72] },
        ost: { arp: [0, 1, 2, 1], rate: 0.25, range: [64, 76] }, bass: DRIVE, drums: 'C P P P P P P F',
      },
      A2: {
        chords: 'Em | C | D | Bm | Em | C | Am | B7',
        brass: PEAK_A, strings: { n: PEAK_A, tr: -12 }, ost: { arp: [0, 1, 2, 1], rate: 0.25, range: [64, 76] }, bass: DRIVE, drums: 'C P P P P P P F',
      },
      B2: {
        chords: 'C | D | Em | Em | Cmaj7 | D | F | B7',
        strings: PEAK_B, brass: { n: PEAK_B, tr: -12 }, stabs: { comp: [[0, 0.3, 0.9], [1.5, 0.3, 0.7], [2.5, 0.3, 0.8]], range: [55, 72] },
        ost: { arp: [0, 1, 2, 1], rate: 0.25, range: [64, 76] }, bass: DRIVE, drums: 'C P P P P P P F',
      },
    },
  },

  springs: {
    bpm: 96, meter: 3, resume: true, gain: 1.4,
    parts: {
      koto: { inst: 'koto', vol: 1.52, pan: 0.15, verb: 0.3 },
      kotoarp: { inst: 'koto', vol: 0.85, pan: 0.25, verb: 0.3 },
      shaku: { inst: 'shaku', vol: 0.71, pan: -0.1, verb: 0.35, delay: 0.12 },
      harp: { inst: 'harp', vol: 0.57, pan: -0.25, verb: 0.3 },
      bass: { inst: 'fretless', vol: 0.38, range: [36, 52] },
      drums: { kit: true, vol: 0.53, verb: 0.15 },
    },
    drums: {
      W: { k: 'o.....', sh: '..o.o.' },
      T: { k: 'o.....', sh: '..o.o.', tri: '....o.' },
    },
    intro: ['I'],
    loop: ['A', 'B', 'A2', 'B2'],
    sections: {
      I: { chords: 'G | D7sus4', harp: WALTZ, bass: OOM, drums: 'W T' },
      A: { chords: 'G | Em7 | Cmaj7 | D | G | Em7 | Am7 | D7sus4', koto: SPRINGS_A, harp: WALTZ, bass: OOM, drums: 'W W W T W W W T' },
      B: {
        chords: 'Cmaj7 | Bm7 | Am7 | G | Cmaj7 | Bm7 | Am7 | D',
        shaku: SPRINGS_B, kotoarp: { arp: [0, 1, 2, 1, 2, 1], rate: 0.5, range: [62, 76] }, bass: OOM, drums: 'W W W T W W W T',
      },
      A2: {
        chords: 'G | Em7 | Cmaj7 | D | G | Em7 | Am7 | D7sus4',
        shaku: { n: SPRINGS_A, tr: -12 }, kotoarp: { arp: [0, 1, 2, 1, 2, 1], rate: 0.5, range: [62, 76] }, bass: OOM, drums: 'W W W T W W W T',
      },
      B2: { chords: 'Cmaj7 | Bm7 | Am7 | G | Cmaj7 | Bm7 | Am7 | D', koto: SPRINGS_B, harp: WALTZ, bass: OOM, drums: 'W W W T W W W T' },
    },
  },

  secret: {
    bpm: 88, room: 'hall', resume: true, delayBeats: 0.75, delayFb: 0.4,
    parts: {
      cel: { inst: 'musicbox', vol: 0.59, pan: 0.2, verb: 0.5, delay: 0.25 },
      harp: { inst: 'harp', vol: 0.38, pan: -0.2, verb: 0.45 },
      pad: { inst: 'pad', vol: 0.43, verb: 0.5 },
      sub: { inst: 'sub', vol: 0.24, range: [36, 48] },
      drums: { kit: true, vol: 2.6, verb: 0.6 },
    },
    drums: { C: { tri: 'o...............' } },
    loop: ['A', 'A2'],
    sections: {
      A: {
        chords: 'Emaj7 | F#/E | Emaj7 | F#/E | C#m7 | F#7 | Bmaj7 | B6',
        cel: SECRET_A, harp: { arp: [0, 1, 2, 3, 4, 5, 4, 3, 2, 1, 2, 3, 4, 3, 2, 1], rate: 0.25, range: [52, 66] },
        pad: { pad: true, range: [52, 68] }, sub: HOLD, drums: 'C - - - C - - -',
      },
      A2: {
        chords: 'Emaj7 | F#/E | Emaj7 | F#/E | C#m7 | F#7 | Bmaj7 | B6',
        cel: { n: SECRET_A, tr: -12 }, harp: { arp: [0, 2, 4, 2], rate: 0.5, range: [52, 66] },
        pad: { pad: true, range: [52, 68] }, sub: HOLD, drums: 'C - - - C - - -',
      },
    },
  },

  battle: {
    bpm: 150, battle: true, gain: 0.85,
    parts: {
      lead: { inst: 'square', vol: 1.65, pan: 0.1, verb: 0.15 },
      brass: { inst: 'brass', vol: 0.39, pan: -0.15, verb: 0.2 },
      keys: { inst: 'epiano', vol: 0.45, pan: 0.3, verb: 0.15 },
      bass: { inst: 'synbass', vol: 0.51, range: [28, 50] },
      drums: { kit: true, vol: 0.44, verb: 0.06 },
    },
    drums: {
      G: { k: 'x..x..x...x..x..', s: '....x.......x...', h: 'xoxoxoxoxoxoxoxo' },
      C: { cr: 'x...............', k: 'x..x..x...x..x..', s: '....x.......x...', h: '..xoxoxoxoxoxoxo' },
      F: { k: 'x..x..x...x.....', s: '....x.......xxxx', h: 'xoxoxoxoxoxo....' },
      I: { cr: 'x...............', k: 'x...x...x...x...', s: '........x.x.xxxx' },
    },
    intro: ['I'],
    loop: ['A', 'B', 'A2', 'B2'],
    sections: {
      I: {
        chords: 'Am7 | E7',
        brass: '[a4c5e5]e> re [a4c5e5]e> re [a4c5e5]e> rq. | [g#4b4d5]q> [g#4b4e5]q> [b4d5e5]q> [b4d5g#5]q>',
        bass: FUNK, drums: 'I F',
      },
      A: {
        chords: 'Am7 | D7 | Fmaj7 | E7 | Am7 | D7 | F G | E7',
        lead: BATTLE_A, keys: { comp: [[0.5, 0.2, 0.6], [1.5, 0.2, 0.55], [2.5, 0.2, 0.6], [3.5, 0.2, 0.55]], rootless: true, range: [60, 76] },
        bass: FUNK, drums: 'C G G G G G G F',
      },
      B: {
        chords: 'Dm7 | G7 | Cmaj7 | Fmaj7 | Bm7b5 | E7 | Am7 | E7',
        lead: BATTLE_B, brass: { comp: [[1.5, 0.3, 0.8], [3, 0.3, 0.9]], range: [55, 72] }, bass: FUNK, drums: 'C G G G G G G F',
      },
      A2: {
        chords: 'Am7 | D7 | Fmaj7 | E7 | Am7 | D7 | F G | E7',
        lead: BATTLE_A, brass: { n: BATTLE_A, tr: -12 }, keys: { comp: [[0.5, 0.2, 0.6], [1.5, 0.2, 0.55], [2.5, 0.2, 0.6], [3.5, 0.2, 0.55]], rootless: true, range: [60, 76] },
        bass: FUNK, drums: 'C G G G G G G F',
      },
      B2: {
        chords: 'Dm7 | G7 | Cmaj7 | Fmaj7 | Bm7b5 | E7 | Am7 | E7',
        lead: BATTLE_B, brass: { n: BATTLE_B, tr: -12 }, bass: FUNK, drums: 'C G G G G G G F',
      },
    },
  },

  boss: {
    bpm: 164, room: 'hall', battle: true, gain: 0.75,
    parts: {
      brass: { inst: 'brass', vol: 0.97, pan: 0.1, verb: 0.3 },
      organ: { inst: 'organ', vol: 0.34, pan: -0.2, verb: 0.35 },
      organ2: { inst: 'organ', vol: 0.94, pan: -0.1, verb: 0.35 },
      trem: { inst: 'stac', vol: 0.63, pan: 0.25, verb: 0.25 },
      bass: { inst: 'synbass', vol: 0.52, range: [28, 47] },
      timp: { inst: 'timp', vol: 0.4, verb: 0.3 },
      drums: { kit: true, vol: 0.46, verb: 0.12 },
    },
    drums: {
      G: { k: 'x...x...x...x...', s: '....x.......x...', h: 'x.x.x.x.x.x.x.x.' },
      C: { cr: 'x...............', k: 'x...x...x...x...', s: '....x.......x...', h: '..x.x.x.x.x.x.x.' },
      F: { k: 'x...x...x...x...', s: '........xxxxXXXX' },
      R: { tk: 'x...x...x...x...', s: 'o.o.o.o.o.o.xxxx' },
    },
    intro: ['I'],
    loop: ['A', 'B', 'A2', 'B2'],
    sections: {
      I: { chords: 'Cm | G7', timp: 'c3e c3e c3e c3e c3e c3e c3e c3e | g2q rq g2q g2q', organ: { pad: true, range: [48, 67] }, drums: '- R' },
      A: {
        chords: 'Cm | Ab | Fm | G | Cm | Ab | Db | G7',
        brass: BOSS_A, organ: { pad: true, range: [48, 67] }, trem: { comp: [[0, 0.45], [0.5, 0.45], [1, 0.45], [1.5, 0.45], [2, 0.45], [2.5, 0.45], [3, 0.45], [3.5, 0.45]], range: [55, 70] },
        bass: DRIVE, timp: BOSS_TIMP, drums: 'C G G G G G G F',
      },
      B: {
        chords: 'Ab | Bb | Gm | Cm | Fm | Db | G | G7',
        brass: BOSS_B, organ: { pad: true, range: [48, 67] }, trem: { comp: [[0, 0.45], [0.5, 0.45], [1, 0.45], [1.5, 0.45], [2, 0.45], [2.5, 0.45], [3, 0.45], [3.5, 0.45]], range: [55, 70] },
        bass: DRIVE, timp: BOSS_TIMP_B, drums: 'C G G G G G G F',
      },
      A2: {
        chords: 'Cm | Ab | Fm | G | Cm | Ab | Db | G7',
        brass: BOSS_A, organ2: { n: BOSS_A, tr: -12 }, trem: { comp: [[0, 0.45], [0.5, 0.45], [1, 0.45], [1.5, 0.45], [2, 0.45], [2.5, 0.45], [3, 0.45], [3.5, 0.45]], range: [55, 70] },
        bass: DRIVE, timp: BOSS_TIMP, drums: 'C G G G G G G F',
      },
      B2: {
        chords: 'Ab | Bb | Gm | Cm | Fm | Db | G | G7',
        brass: BOSS_B, organ2: { n: BOSS_B, tr: -12 }, trem: { comp: [[0, 0.45], [0.5, 0.45], [1, 0.45], [1.5, 0.45], [2, 0.45], [2.5, 0.45], [3, 0.45], [3.5, 0.45]], range: [55, 70] },
        bass: DRIVE, timp: BOSS_TIMP_B, drums: 'C G G G G G G R',
      },
    },
  },

  victory: {
    bpm: 150, once: true, gain: 0.9,
    parts: {
      lead: { inst: 'brass', vol: 1.13, verb: 0.25 },
      hits: { inst: 'brass', vol: 0.42, pan: -0.2, verb: 0.25 },
      bass: { inst: 'synbass', vol: 0.43, range: [36, 52] },
      timp: { inst: 'timp', vol: 0.46, verb: 0.3 },
      drums: { kit: true, vol: 0.55, verb: 0.15 },
    },
    drums: {
      V1: { k: 'x.......x.......', s: '............xxxx' },
      V2: { k: 'x.......x.......', s: '........x.x.xxxX' },
      V3: { cr: 'X...............', k: 'X...............' },
    },
    intro: ['V'],
    sections: {
      V: {
        chords: 'C | F G | C',
        lead: 'g4e c5e d5e e5e ~e c5e g5q | a5q c6q b5q d6q | c6h. rq',
        hits: { comp: [[[0, 0.3], [2.5, 0.3]], [[0, 0.4], [1, 0.4], [2, 0.4], [3, 0.4]], [[0, 3]]], range: [55, 72] },
        bass: { bass: [[0, 0.9, 'R', 0.9], [2, 0.9, '5', 0.8]] },
        timp: 'c3q rq rh | f2q rq g2q g2q | c3q rh.',
        drums: 'V1 V2 V3',
      },
    },
  },

  dusk: {
    bpm: 126, meter: 3, room: 'hall', resume: true, gain: 1.3,
    parts: {
      harpsi: { inst: 'harpsi', vol: 1.5, pan: 0.15, verb: 0.3 },
      harparp: { inst: 'harpsi', vol: 0.74, pan: 0.2, verb: 0.3 },
      organ: { inst: 'organ', vol: 1.1, pan: -0.15, verb: 0.4 },
      pizz: { inst: 'pizz', vol: 0.91, pan: -0.25, verb: 0.2 },
      bass: { inst: 'pizz', vol: 1.32, range: [31, 50] },
    },
    loop: ['A', 'A2'],
    sections: {
      A: {
        chords: 'Gm | Cm | D7 | Gm | Eb | Cm | D | D7',
        harpsi: DUSK_A, pizz: { comp: [[1, 0.3, 0.6], [2, 0.3, 0.55]], range: [55, 70] }, bass: { bass: [[0, 0.8, 'R', 0.9]] },
      },
      A2: {
        chords: 'Gm | Cm | D7 | Gm | Eb | Cm | D | D7',
        organ: { n: DUSK_A, tr: -12 }, harparp: { arp: [0, 1, 2, 1, 2, 1], rate: 0.5, range: [62, 76] },
        pizz: { comp: [[1, 0.3, 0.6], [2, 0.3, 0.55]], range: [55, 70] }, bass: { bass: [[0, 0.8, 'R', 0.9]] },
      },
    },
  },

  castle: {
    bpm: 104, meter: 3, room: 'hall', resume: true, gain: 1.15,
    parts: {
      flute: { inst: 'flute', vol: 0.75, pan: 0.1, verb: 0.45 },
      harp: { inst: 'harp', vol: 0.55, pan: -0.2, verb: 0.4 },
      strings: { inst: 'strings', vol: 0.3, pan: 0.15, verb: 0.45 },
      horn: { inst: 'horn', vol: 0.45, pan: -0.1, verb: 0.4 },
      bass: { inst: 'pizz', vol: 1.1, range: [31, 50] },
      timp: { inst: 'timp', vol: 0.4, verb: 0.35 },
    },
    intro: ['I'],
    loop: ['A', 'B', 'A2'],
    sections: {
      I: { chords: 'Dm | A7', harp: CASTLE_ARP, timp: 'd3q rh | a2q rh', bass: { bass: [[0, 0.9, 'R', 0.9]] } },
      A: { chords: 'Dm | Bb | Gm | A7 | Dm | F | Gm A7 | Dm', flute: CASTLE_A, harp: CASTLE_ARP, strings: PAD, bass: CASTLE_OOM },
      B: {
        chords: 'F | C | Dm | Bb | Gm | C7 | F | A7', flute: CASTLE_B, horn: { n: CASTLE_B, tr: -12 }, harp: CASTLE_ARP, strings: PAD, bass: CASTLE_OOM,
        timp: 'f2q rh | rh. | rh. | rh. | g2q rh | rh. | f2q rh | a2q rh',
      },
      A2: { chords: 'Dm | Bb | Gm | A7 | Dm | F | Gm A7 | Dm', flute: CASTLE_A, horn: { n: CASTLE_A, tr: -12 }, harp: CASTLE_ARP, strings: PAD, bass: CASTLE_OOM },
    },
  },

  tower: {
    bpm: 108, room: 'hall', resume: true, gain: 1.05, delayBeats: 0.75, delayFb: 0.3,
    parts: {
      harpsi: { inst: 'harpsi', vol: 1.3, pan: 0.15, verb: 0.3 },
      mbox: { inst: 'musicbox', vol: 0.62, pan: -0.2, verb: 0.45, delay: 0.2 },
      organ: { inst: 'organ', vol: 0.5, pan: -0.15, verb: 0.4 },
      pizz: { inst: 'pizz', vol: 0.8, pan: -0.25, verb: 0.2 },
      bass: { inst: 'synbass', vol: 0.5, range: [28, 47] },
      drums: { kit: true, vol: 0.4, verb: 0.15 },
    },
    drums: {
      T: { h: 'x.o.x.o.x.o.x.o.' },
      G: { k: 'x.....x...x.....', s: '....o.......o...', h: 'x.o.x.o.x.o.x.o.' },
      C: { cr: 'x...............', k: 'x.....x...x.....', s: '....o.......o...', h: '..o.x.o.x.o.x.o.' },
      F: { k: 'x.....x.........', s: '....o.......xoxo', h: 'x.o.x.o.x.o.....', tri: 'x...............' },
    },
    intro: ['I'],
    loop: ['A', 'B', 'A2', 'B2'],
    sections: {
      I: { chords: 'Dm | A7', pizz: TICKS, drums: 'T F' },
      A: { chords: 'Dm | Bbmaj7 | Gm7 | A7 | Dm | Bbmaj7 | Em7b5 A7 | Dm', harpsi: TOWER_A, pizz: TICKS, bass: FUNK, drums: 'C G G G G G G F' },
      B: { chords: 'Bbmaj7 | C | Am7 | Dm | Gm7 | C7 | Fmaj7 | A7', mbox: TOWER_B, organ: PAD, bass: TWO, drums: 'C G G G G G G F' },
      A2: { chords: 'Dm | Bbmaj7 | Gm7 | A7 | Dm | Bbmaj7 | Em7b5 A7 | Dm', harpsi: TOWER_A, organ: { n: TOWER_A, tr: -12 }, pizz: TICKS, bass: FUNK, drums: 'C G G G G G G F' },
      B2: { chords: 'Bbmaj7 | C | Am7 | Dm | Gm7 | C7 | Fmaj7 | A7', mbox: TOWER_B, harpsi: { n: TOWER_B, tr: -12 }, organ: PAD, bass: TWO, drums: 'C G G G G G G F' },
    },
  },

  finale: {
    bpm: 168, room: 'hall', battle: true, gain: 0.76,
    parts: {
      lead: { inst: 'square', vol: 1.4, pan: 0.1, verb: 0.2 },
      brass: { inst: 'brass', vol: 0.85, pan: -0.1, verb: 0.3 },
      stabs: { inst: 'brass', vol: 0.4, pan: 0.3, verb: 0.2 },
      organ: { inst: 'organ', vol: 0.4, pan: -0.25, verb: 0.35 },
      bass: { inst: 'synbass', vol: 0.55, range: [28, 47] },
      timp: { inst: 'timp', vol: 0.42, verb: 0.3 },
      drums: { kit: true, vol: 0.46, verb: 0.1 },
    },
    drums: {
      G: { k: 'x..x..x...x..x..', s: '....x.......x...', h: 'xoxoxoxoxoxoxoxo' },
      C: { cr: 'x...............', k: 'x..x..x...x..x..', s: '....x.......x...', h: '..xoxoxoxoxoxoxo' },
      F: { k: 'x..x..x...x.....', s: '....x.......xxxx', h: 'xoxoxoxoxoxo....' },
      I: { cr: 'x...............', k: 'x...x...x...x...', s: '........x.x.xxxx' },
    },
    intro: ['I'],
    loop: ['A', 'B', 'A2', 'B2'],
    sections: {
      I: { chords: 'Gm | D7', organ: PAD, timp: 'g2q rq g2q g2q | d3q rq d3e d3e d3e d3e', drums: 'I F' },
      A: { chords: 'Gm7 | Ebmaj7 | D7 | Gm7 | Cm7 | Cm7 | D7 | Gm D7', lead: FINALE_A, organ: PAD, stabs: FINALE_STABS, bass: FUNK, drums: 'C G G G G G G F' },
      B: {
        chords: 'Ebmaj7 | F | Dm7 | Gm7 | Cm7 | F7 | Bbmaj7 | D7', brass: FINALE_B, organ: PAD, stabs: FINALE_STABS, bass: FUNK,
        timp: 'eb3q rq rh | f2q rq rh | d3q rq rh | g2q rq g2q g2q | c3q rq rh | f2q rq rh | bb2q rq rh | d3q d3q d3q d3q', drums: 'C G G G G G G F',
      },
      A2: { chords: 'Gm7 | Ebmaj7 | D7 | Gm7 | Cm7 | Cm7 | D7 | Gm D7', lead: FINALE_A, brass: { n: FINALE_A, tr: -12 }, stabs: FINALE_STABS, bass: FUNK, drums: 'C G G G G G G F' },
      B2: { chords: 'Ebmaj7 | F | Dm7 | Gm7 | Cm7 | F7 | Bbmaj7 | D7', lead: FINALE_B, brass: { n: FINALE_B, tr: -12 }, organ: PAD, bass: FUNK, drums: 'C G G G G G G F' },
    },
  },

  // the post-game chapter, The Unfinished Margin: the fields (see MARGIN_* above)
  margin: {
    bpm: 100, swing: 0.4, resume: true, gain: 0.95, delayBeats: 0.75, delayFb: 0.3,
    parts: {
      pizz: { inst: 'pizz', vol: 1.3, pan: 0.15, verb: 0.2 },
      reed: { inst: 'reed', vol: 0.55, pan: -0.1, verb: 0.25 },
      oca: { inst: 'ocarina', vol: 0.75, pan: 0.05, verb: 0.35, glide: 0.03, delay: 0.12 },
      mbox: { inst: 'musicbox', vol: 0.45, pan: 0.3, verb: 0.4, delay: 0.2 },
      keys: { inst: 'rhodes', vol: 0.5, pan: -0.2, verb: 0.25, lp: 3000 },
      gtr: { inst: 'funkgtr', vol: 1, pan: -0.35, verb: 0.12 },
      bass: { inst: 'slap', vol: 0.5, range: [28, 47] },
      drums: { kit: true, vol: 0.6, verb: 0.08 },
    },
    drums: {
      G: { k: 'x..x......x.....', ls: '....x.......x...', sh: 'o.x.o.x.o.x.o.x.', b: '.......o.......o' },
      G2: { k: 'x..x......x..x..', ls: '....x..o....x...', sh: 'o.xoo.xoo.xoo.xo', b: '..o....o..o....x' },
      C: { tri: 'x...............', k: 'x..x......x.....', ls: '....x.......x...', sh: 'o.x.o.x.o.x.o.x.', b: '.......o.......o' },
      F: { k: 'x..x......x.....', ls: '....x.......x.oo', sh: 'o.x.o.x.o.x.....', b: '........o.xoxoxx', wb: '..........x...x.' },
      S: { k: 'x.........x.....', ls: '........x.......', sh: 'o.o.o.o.o.o.o.o.', b: '..o...o...o...ox' },
    },
    intro: ['I'],
    loop: ['A', 'A2', 'B', 'A3'],
    sections: {
      I: {
        chords: 'Cmaj7 | Gm7 C7', pizz: "rw | rh g4e' a4e' c5e' d5e'", keys: MARGIN_KEYS,
        bass: "c2e.> c2s? re c3e'> re g2e' c2e' f#2e' | g2e.> g2s? re g3e'> re c3e' bb2e' e2e'", drums: 'S F',
      },
      A: { chords: MARGIN_CH, pizz: MARGIN_A, keys: MARGIN_KEYS, bass: MARGIN_BASS_A, drums: 'C G G G G G G F' },
      A2: { chords: MARGIN_CH2, reed: MARGIN_A2, pizz: TICKS, gtr: MARGIN_CHK, keys: MARGIN_KEYS, bass: MARGIN_BASS_A2, drums: 'C G G2 G G G2 G F' },
      B: {
        chords: 'Am7 | Em7 | Fmaj7 | Fm6 | Em7 | A7 | Dm7 | Gm7 C7',
        oca: MARGIN_B, mbox: MARGIN_ANSWER, pizz: { arp: [0, 2, 1, 3], rate: 0.5, range: [55, 72] },
        keys: { pad: true, rootless: true, range: [57, 72] }, bass: MARGIN_BASS_B, drums: 'S S S S S S S F',
      },
      A3: {
        chords: MARGIN_CH, pizz: MARGIN_A, mbox: MARGIN_A, reed: { n: MARGIN_A, tr: -12 }, gtr: MARGIN_SCRATCH, keys: MARGIN_KEYS,
        bass: MARGIN_BASS_A, drums: 'C G2 G G2 G G2 G F',
      },
    },
  },

  // the post-game final battle: Queen Pristine (see PRISTINE_* above)
  pristine: {
    bpm: 152, room: 'hall', battle: true, gain: 0.8,
    parts: {
      harpsi: { inst: 'harpsi', vol: 1.35, pan: 0.15, verb: 0.25 },
      harparp: { inst: 'harpsi', vol: 0.55, pan: -0.3, verb: 0.25 },
      organ: { inst: 'organ', vol: 0.3, pan: -0.1, verb: 0.35 },
      organ2: { inst: 'organ', vol: 0.75, pan: -0.15, verb: 0.35 },
      strings: { inst: 'strings', vol: 0.32, pan: 0.2, verb: 0.35 },
      lead: { inst: 'fmlead', vol: 1.1, pan: 0.05, verb: 0.2 },
      pizz: { inst: 'pizz', vol: 0.7, pan: 0.3, verb: 0.15 },
      gtr: { inst: 'funkgtr', vol: 1.15, pan: -0.3, verb: 0.12 },
      bass: { inst: 'slap', vol: 0.55, range: [28, 47] },
      timp: { inst: 'timp', vol: 0.42, verb: 0.3 },
      drums: { kit: true, vol: 0.46, verb: 0.1 },
    },
    drums: {
      G: { k: 'x.....x.x.....x.', s: '....x..o....x..o', h: 'xoxoxoxoxoxoxoxo' },
      C: { cr: 'x...............', k: 'x.....x.x.....x.', s: '....x..o....x..o', h: '..xoxoxoxoxoxoxo' },
      G2: { k: 'x.x...x.x.x...x.', s: '....x..o.o..x..o', h: 'xxxxxxxxxxxxxxxx', tb: '..x...x...x...x.' },
      C2: { cr: 'x...............', k: 'x.x...x.x.x...x.', s: '....x..o.o..x..o', h: '..xxxxxxxxxxxxxx', tb: '..x...x...x...x.' },
      D: { k: 'x...x...x...x...', s: '....x.......x...', cl: '....x.......x...', h: 'xo.oxo.oxo.oxo.o', oh: '..x...x...x...x.' },
      DC: { cr: 'x...............', k: 'x...x...x...x...', s: '....x.......x...', cl: '....x.......x...', h: '...oxo.oxo.oxo.o', oh: '..x...x...x...x.' },
      F: { k: 'x.....x.x.......', s: '....x.......xxXX', h: 'xoxoxoxoxoxo....' },
      R: { tk: 'x...x...x...x...', s: 'o.o.o.o.xoxoxxXX' },
    },
    intro: ['I'],
    loop: ['A', 'B', 'A2', 'B2'],
    sections: {
      I: { chords: 'Em | B7', harparp: PRISTINE_ARP, organ: { pad: true, range: [48, 67] }, timp: 'e3q rq e3q e3q | b2q rq b2e b2e b2e b2e', drums: '- R' },
      A: { chords: PRISTINE_CH, harpsi: PRISTINE_A, harparp: PRISTINE_ARP, organ: { pad: true, range: [48, 67] }, bass: PRISTINE_BASS, drums: 'C G G G G G G F' },
      B: {
        chords: 'Cmaj7 | D/C | Bm7 | Em7 | Am7 | D7sus4 D7 | Gmaj7 | B7',
        lead: PRISTINE_B, pizz: { n: PRISTINE_B, tr: 12 }, gtr: PRISTINE_SCRATCH, strings: { pad: true, range: [55, 72] }, bass: DISCO, drums: 'DC D D D D D D F',
      },
      A2: {
        chords: PRISTINE_CH, harpsi: PRISTINE_A, organ2: { n: PRISTINE_A, tr: -12 }, harparp: PRISTINE_ARP, bass: PRISTINE_BASS, timp: PRISTINE_TIMP,
        drums: 'C2 G2 G2 G2 G2 G2 G2 F',
      },
      B2: {
        chords: 'Cmaj7 | C#m7b5 | D | D#dim7 | Em | Am | F | B7',
        harpsi: PRISTINE_DUEL, lead: PRISTINE_HEROES, harparp: PRISTINE_ARP, strings: { pad: true, range: [55, 74] }, organ: { pad: true, range: [48, 67] },
        bass: PRISTINE_BASS, timp: PRISTINE_TIMP_B2, drums: 'DC D D D C2 G2 G2 R',
      },
    },
  },

  home: {
    bpm: 84, swing: 0.25, room: 'hall', resume: true, gain: 0.95,
    parts: {
      keys: { inst: 'epiano', vol: 0.8, pan: 0.1, verb: 0.35 },
      flute: { inst: 'flute', vol: 0.6, pan: -0.15, verb: 0.4 },
      comp: { inst: 'epiano', vol: 0.3, pan: -0.25, verb: 0.3 },
      strings: { inst: 'strings', vol: 0.25, pan: 0.2, verb: 0.4 },
      cel: { inst: 'musicbox', vol: 0.35, pan: 0.3, verb: 0.5 },
      bass: { inst: 'upright', vol: 0.4, range: [31, 50] },
      drums: { kit: true, vol: 0.6, verb: 0.1 },
    },
    drums: {
      S: { k: 'o.......o.......', b: '....o.......o...', sh: 'o.o.o.o.o.o.o.o.' },
      F: { k: 'o.......o.....o.', b: '....o.....o.o.o.', sh: 'o.o.o.o.o.o.o.o.' },
    },
    intro: ['I'],
    loop: ['A', 'B', 'A2'],
    sections: {
      I: { chords: 'Ebmaj7 | Bb7sus4 Bb7', comp: HOME_COMP, strings: { pad: true, range: [55, 74] }, bass: TWO },
      A: { chords: HOME_CH_A, keys: HOME_A, comp: HOME_COMP, strings: { pad: true, range: [55, 74] }, bass: TWO, drums: 'S S S S S S S F' },
      B: {
        chords: 'Abmaj7 | Bb/Ab | Gm7 | Cm7 | Fm7 | Bb7 | Ebmaj7 | Bb7sus4 Bb7',
        flute: HOME_B, comp: HOME_COMP, strings: { pad: true, range: [55, 74] }, bass: TWO, drums: 'S S S S S S S F',
      },
      A2: { chords: HOME_CH_A, keys: HOME_A, cel: { n: HOME_A, tr: 12 }, comp: HOME_COMP, strings: { pad: true, range: [55, 74] }, bass: TWO, drums: 'S S S S S S S F' },
    },
  },

  menu: {
    bpm: 116, swing: 0.6, snappy: true, resume: true,
    parts: {
      mar: { inst: 'marimba', vol: 0.9, pan: 0.15, verb: 0.2 },
      pizz: { inst: 'pizz', vol: 0.6, pan: -0.25, verb: 0.15 },
      bass: { inst: 'upright', vol: 0.38, range: [31, 50] },
      drums: { kit: true, vol: 0.55, verb: 0.08 },
    },
    drums: {
      M: { sh: 'o.x.o.x.o.x.o.x.', rim: '....x.......x...', k: 'o.......o.......' },
      F: { sh: 'o.x.o.x.o.x.o.x.', rim: '....x.....x.x.x.', k: 'o.......o.......', wb: '..............x.' },
    },
    loop: ['A', 'B'],
    sections: {
      A: { chords: 'Bbmaj7 | Gm7 | Cm7 | F7 | Bbmaj7 | Gm7 | Cm7 F7 | Bb6', mar: MENU_A, pizz: MENU_PIZZ, bass: WALK, drums: 'M M M M M M M F' },
      B: { chords: 'Ebmaj7 | Edim7 | Bb/F | G7 | Cm7 | F7 | Dm7 G7 | Cm7 F7', mar: MENU_B, pizz: MENU_PIZZ, bass: WALK, drums: 'M M M M M M M F' },
    },
  },

  // study music for focus sessions, played by the study buddy window (see lofi(), calm() and rain() above)
  study_lofi: { make: lofi },
  study_piano: { make: calm },
  study_rain: { make: rain },
  study_funk: { make: funk },
  lantern_beat: lanternBeat(),
};
