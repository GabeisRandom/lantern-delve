// The Study tab: practice questions made from your homework, reviewed in quiz battles against the Gloom.
// Claude writes the questions from an assignment's files and your notes. Without Claude (the copy for friends has
// none), the tab turns sentences from pasted notes into fill-in-the-blank cards, and you can always write your own.
// Every card has a box: a right answer moves it up, so it comes back later (tomorrow, 3 days, a week...), and a wrong
// one sends it back to the start. Time in this tab counts as focus during a session. The rules themselves live in
// lantern_delve.py (Game.study_*) and offline.js (Game.study*).
import { api, esc } from './api.js';
import { sfx } from './audio.js';

const ENEMIES = ['gloomling', 'inkblot', 'buzzbug', 'puddlet', 'wisp', 'glowbat', 'spikeshroom', 'cinderling'];
const BATTLE_MAX = 12;        // cards in one battle
const PRACTICE_MAX = 10;
const INK = '#2b2235';
let art = null;               // art.js: Wick and the enemies (loaded when the first battle starts)
const loadArt = () => (art ? Promise.resolve(art) : import('./art.js').then(m => (art = m), () => null));

// ---------------------------------------------------------------- helpers
const shuffle = a => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const answerText = c => (c.type === 'mc' ? c.options[c.answer] : c.answer);
const deckKey = c => (c.quest != null ? `q:${c.quest}` : `d:${c.deck}`);
const daysBetween = (a, b) => Math.round((new Date(`${b}T12:00`) - new Date(`${a}T12:00`)) / 86400000);
const localToday = () => { const d = new Date(), p = n => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`; };
function whenText(today, due) {
  const d = daysBetween(today, due);
  return d <= 0 ? 'due now' : d === 1 ? 'tomorrow' : d < 14 ? `in ${d} days` : d < 60 ? `in ${Math.round(d / 7)} weeks` : `in ${Math.round(d / 30)} months`;
}

// Typed answers are checked leniently: case, punctuation, "the/a" and a small typo don't matter.
const norm = s => String(s).toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9 ]+/g, ' ')
  .replace(/\b(the|a|an)\b/g, ' ').replace(/\s+/g, ' ').trim();
function lev(a, b) {
  const d = Array.from({ length: b.length + 1 }, (_, j) => j);
  for (let i = 1; i <= a.length; i++) {
    let prev = d[0];
    d[0] = i;
    for (let j = 1; j <= b.length; j++) { const t = d[j]; d[j] = Math.min(d[j] + 1, d[j - 1] + 1, prev + (a[i - 1] === b[j - 1] ? 0 : 1)); prev = t; }
  }
  return d[b.length];
}
export function matches(given, accepted) {
  const g = norm(given);
  if (!g) return false;
  return accepted.some(a => {
    const t = norm(a);
    if (!t) return false;
    if (g === t || g.includes(t)) return true;
    if (t.includes(g) && g.length >= Math.max(4, t.length * 0.6)) return true;
    return lev(g, t) <= (t.length >= 8 ? 2 : 1);
  });
}

// Fill-in-the-blank cards from pasted notes, for when Claude isn't around. Definitions make the best blanks ("X is
// ...", "called X", "X (...)"); otherwise the sentence's longest uncommon word gets blanked out.
const STOP = new Set(`the a an and or but of to in on at for with by from as is are was were be been being this that these
  those it its their there which who whom whose what when where why how than then so such can could may might will would
  should do does did not no also into over under about between more most less least very much many some any each every
  other another same just only they them you your we our he she his her has have had one two three first second because
  while during after before since until like using used often usually always never itself however therefore`.split(/\s+/));
const reEsc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
function pickTerm(s) {
  let m = s.match(/^([A-Z][\w'’-]*(?:\s+[\w'’-]+){0,3}?)\s+(?:is|are|means|refers to)\b/);
  if (m && !STOP.has(m[1].toLowerCase())) return m[1];
  m = s.match(/\b(?:called|known as|defined as|termed)\s+(?:the\s+)?["“']?([\w'’-]+(?:\s+[\w'’-]+){0,2})/i);
  if (m && !STOP.has(m[1].toLowerCase())) return m[1].replace(/["”']$/, '');
  m = s.match(/([A-Za-z][\w'’-]+(?:\s+[A-Za-z][\w'’-]+){0,2})\s*\(/);
  if (m && !STOP.has(m[1].toLowerCase())) return m[1];
  const words = (s.match(/[A-Za-z][A-Za-z'’-]{5,}/g) || []).filter(w => !STOP.has(w.toLowerCase()));
  return words.sort((a, b) => b.length - a.length)[0] || null;
}
export function notesToCards(text, max = 10) {
  const sentences = String(text).replace(/\r/g, '').split(/(?<=[.!?])\s+|\n+/)
    .map(s => s.replace(/^[\s•*·\-–—\d.)]+/, '').trim())
    .filter(s => s.split(/\s+/).length >= 5 && s.length <= 260);
  const score = s => (/\b(is|are|means|refers to|called|known as|defined as)\b/i.test(s) ? 2 : 0) + (/[(:]/.test(s) ? 1 : 0);
  const cards = [], used = new Set();
  for (const s of sentences.map((s, i) => [s, i]).sort((a, b) => score(b[0]) - score(a[0]) || a[1] - b[1]).map(x => x[0])) {
    if (cards.length >= max) break;
    const term = pickTerm(s);
    if (!term || used.has(term.toLowerCase()) || term.length > 60) continue;
    used.add(term.toLowerCase());
    cards.push({ type: 'short', q: s.replace(new RegExp(reEsc(term), 'i'), '_____'), answer: term, accept: [], source: s });
  }
  return cards;
}

// Teach Wick without Claude: an idea from the deck counts as explained when most of its words (or a close form of
// them) turn up in what you wrote.
function coversIdea(idea, text) {
  const words = norm(idea).split(' ').filter(w => w.length > 2 && !STOP.has(w));
  if (!words.length) return false;
  const t = ` ${norm(text)} `;
  const hit = words.filter(w => t.includes(` ${w}`) || (w.length >= 6 && t.includes(w.slice(0, w.length - 2))));
  return hit.length / words.length >= (words.length <= 2 ? 1 : 0.6);
}

// one of Teach Wick's candles: lit for every idea Wick understood
function candleSVG(lit) {
  return `<svg viewBox="0 0 30 46" aria-hidden="true">
    ${lit ? '<circle cx="15" cy="10" r="10" fill="rgba(255,215,110,.45)"/><path d="M15 2 C20 8 21 13 18 16 C16.5 18 13.5 18 12 16 C9 13 10 8 15 2 Z" fill="#ffc23a" stroke="#2b2235" stroke-width="1.6"/>'
      : '<path d="M15 6 C18 10 18.5 13 17 15 C16 16.5 14 16.5 13 15 C11.5 13 12 10 15 6 Z" fill="none" stroke="#b9ae96" stroke-width="1.6" stroke-dasharray="2 2"/>'}
    <path d="M15 18 L15 21" stroke="#2b2235" stroke-width="1.6"/>
    <rect x="7" y="21" width="16" height="23" rx="4" fill="${lit ? '#fff3dc' : '#ece4d2'}" stroke="#2b2235" stroke-width="2"/>
  </svg>`;
}

// ---------------------------------------------------------------- the tab
export class Study {
  constructor({ root, toast, getState, refresh }) {
    Object.assign(this, { root, toast, getState, refresh });
    this.data = null;          // {cards, today, light_today, cap, ai} from /api/study
    this.view = 'decks';       // decks | deck | make | write | battle
    this.deck = null;          // the picked deck's key: "q:<assignment id>" or "d:<name>"
    this.makeFrom = null;      // the make form's starting choice ("q:<id>" or "topic")
    this.writeTo = null;       // where written cards go: {quest, name}
    this.battle = null;
    this.teach = null;         // Teach Wick: {quest, name, cards, concept, ask, ideas, turns, result, prev, revealed, busy, local}
    this.active = false;
    this.key = null;
    root.addEventListener('click', e => {
      const el = e.target.closest('[data-s]');
      if (!el || !root.contains(el)) return;
      e.preventDefault();
      this.act(el.dataset.s, el).catch(err => this.toast(`Something went wrong: ${err.message}`));
    });
    root.addEventListener('change', e => { if (e.target.id === 's-from') this.syncFrom(); });
    root.addEventListener('submit', e => { e.preventDefault(); if (e.target.id === 's-short') this.submitShort(); });
    document.addEventListener('keydown', e => this.onKey(e));
  }

  // ---- showing and refreshing
  show() { this.active = true; this.load(); if (this.view === 'battle') this.loop(); if (this.view === 'teach') this.teachLoop(); }
  hide() { this.active = false; }

  async load() {
    try { this.data = await api('/api/study'); } catch (e) { this.data = this.data || { cards: [], today: localToday(), light_today: 0, cap: 30, ai: false }; }
    if (this.view !== 'battle' && this.view !== 'teach') { this.key = null; this.render(); }
  }

  // called on every state poll while the tab is open: it only redraws when something it shows has changed, never
  // during a battle, and never under someone typing
  render() {
    const S = this.getState();
    if (!this.data || !S || this.view === 'battle' || this.view === 'teach') return;
    const k = JSON.stringify([this.view, this.deck, this.data.cards.map(c => [c.id, c.due]), this.data.light_today, this.data.ai,
      S.quests.map(q => [q.id, q.title, q.done, (q.files || []).length]), !!(S.session && S.session.mode === 'focus')]);
    if (k === this.key) return;
    const f = document.activeElement;
    if (this.key && f && this.root.contains(f) && /^(INPUT|TEXTAREA|SELECT)$/.test(f.tagName)) return;
    this.key = k;
    this.draw();
  }
  redraw() { this.key = null; this.render(); }

  decks() {
    const S = this.getState(), today = this.data.today, map = new Map();
    for (const c of this.data.cards) {
      const key = deckKey(c);
      let d = map.get(key);
      if (!d) map.set(key, d = { key, quest: c.quest, name: c.deck, cards: [] });
      d.cards.push(c);
    }
    for (const d of map.values()) {
      const q = d.quest != null && S ? S.quests.find(x => x.id === d.quest) : null;   // (named after the assignment as it is now)
      if (q) d.name = q.title;
      d.due = d.cards.filter(c => c.due <= today).length;
      d.mastery = Math.round((100 * d.cards.reduce((n, c) => n + Math.min(c.box, 4), 0)) / (4 * d.cards.length));
    }
    return [...map.values()].sort((a, b) => b.due - a.due || a.name.localeCompare(b.name));
  }

  draw() {
    const S = this.getState(), decks = this.decks(), today = this.data.today;
    const due = this.data.cards.filter(c => c.due <= today).length;
    if (this.view === 'deck' && !decks.find(d => d.key === this.deck)) {
      // (an assignment with no cards yet: straight to making some)
      this.view = this.deck && this.deck.startsWith('q:') ? 'make' : decks.length ? 'decks' : 'make';
      if (this.view === 'make') this.makeFrom = this.deck;
    }
    if (this.view === 'decks') {
      if (decks.length) { this.deck = decks[0].key; this.view = 'deck'; } else this.view = 'make';
    }
    const side = `<aside class="study-side">
      <div class="card paper s-due">
        <h2>🃏 Study</h2>
        ${this.data.cards.length ? `<div class="s-due-row"><b class="num">${due}</b><span>card${due === 1 ? '' : 's'} due for review${due ? '' : '. 🌿'}</span></div>
          <button class="btn gold big" data-s="review-due" ${due ? '' : 'disabled'} style="width:100%">⚔️ Review due cards</button>
          <p class="s-light">✦ ${this.data.light_today}/${this.data.cap} Light from studying today${S && S.session && S.session.mode === 'focus' ? ' · 🔥 counts as focus' : ''}</p>`
          : `<p>Turn your homework into practice questions, then battle them. Cards you miss come back sooner; cards you know wait longer.</p>`}
      </div>
      ${decks.length ? `<div class="s-decks">${decks.map(d => `<button class="s-deck ${this.view !== 'make' && this.view !== 'write' && d.key === this.deck ? 'sel' : ''}" data-s="deck" data-k="${esc(d.key)}">
          <b>${esc(d.name)}</b><span class="n">${d.cards.length} card${d.cards.length === 1 ? '' : 's'}${d.due ? ` · <span class="due">${d.due} due</span>` : ''}</span>
          <span class="bar"><i style="width:${d.mastery}%"></i></span></button>`).join('')}</div>` : ''}
      <button class="btn" data-s="make">✨ New practice questions</button>
    </aside>`;
    let main = '';
    if (this.view === 'deck') main = this.deckHtml(decks.find(d => d.key === this.deck));
    else if (this.view === 'make') main = this.makeHtml();
    else if (this.view === 'write') main = this.writeHtml();
    else if (this.view === 'battle') main = this.battleHtml();
    else if (this.view === 'teach') main = this.teachHtml();
    this.root.innerHTML = `<div class="study">${side}<section class="study-main">${main}</section></div>`;
    if (this.view === 'make') this.syncFrom();
    if (this.view === 'battle') { this.cv = this.root.querySelector('#s-canvas'); this.renderHP(); }
    if (this.view === 'teach') { this.drawTeach(); this.teachLoop(); }
  }

  deckHtml(d) {
    const today = this.data.today;
    const known = d.cards.filter(c => c.box >= 3).length;
    const cards = [...d.cards].sort((a, b) => a.due.localeCompare(b.due) || a.id - b.id);
    return `<div class="card paper s-deckcard">
      <div class="row"><h2 style="margin:0;flex:1">${esc(d.name)}</h2>
        <button class="btn small" data-s="del-deck" title="Delete this deck">🗑</button></div>
      <p class="muted">${d.cards.length} card${d.cards.length === 1 ? '' : 's'} · ${d.due} due now · ${known} you know well</p>
      <div class="row">
        <button class="btn gold big" data-s="battle">⚔️ ${d.due ? `Battle (${Math.min(d.due, BATTLE_MAX)} due)` : 'Practice anyway'}</button>
        <button class="btn" data-s="teach" title="Explain it in your own words; Wick says what clicked and asks about what's missing">🕯️ Teach Wick</button>
        <button class="btn" data-s="more">✨ More questions</button>
        <button class="btn" data-s="write">✍️ Write a card</button>
      </div>
      ${d.due ? '' : '<p class="muted s-small">Nothing here is due, so practice won\'t change when cards come back or earn Light. They come back on their own when it\'s time.</p>'}
      <ul class="s-cards">${cards.map(c => {
        const dd = daysBetween(today, c.due);
        return `<li><div class="q">${esc(c.q)}</div><div class="a">→ ${esc(answerText(c))}${c.by === 'claude' ? '' : c.by === 'notes' ? ' <span class="muted">· from your notes</span>' : ' <span class="muted">· written by you</span>'}</div>
          <span class="due-chip ${dd <= 0 ? 'today' : dd === 1 ? 'tomorrow' : ''}">${whenText(today, c.due)}</span>
          <button class="x" data-s="del-card" data-id="${c.id}" title="Delete this card (if it's wrong or useless)">×</button></li>`;
      }).join('')}</ul>
    </div>`;
  }

  makeHtml() {
    const S = this.getState(), quests = S ? [...S.quests].sort((a, b) => a.done - b.done || b.id - a.id) : [];
    const pick = this.makeFrom || (quests[0] ? `q:${quests[0].id}` : 'topic');
    const ai = this.data.ai;
    return `<div class="card paper s-make">
      <h2>✨ New practice questions</h2>
      <div class="field"><label for="s-from">What are you studying?</label>
        <select id="s-from">${quests.map(q => `<option value="q:${q.id}" ${pick === `q:${q.id}` ? 'selected' : ''}>${q.done ? '✅ ' : ''}${esc(q.title)}${(q.files || []).length ? ` (📎 ${q.files.length})` : ''}</option>`).join('')}
          <option value="topic" ${pick === 'topic' ? 'selected' : ''}>Something else…</option></select></div>
      <div class="field" id="s-topic-row"><label for="s-topic">Topic</label><input id="s-topic" type="text" maxlength="120" placeholder="e.g. Cell respiration, Big-O notation, the French Revolution"></div>
      <div class="field"><label for="s-notes">Notes to use <span class="muted" id="s-notes-hint"></span></label>
        <textarea id="s-notes" rows="7" placeholder="Paste notes, slide text or part of a reading…"></textarea></div>
      <div class="row">
        ${ai ? '<button class="btn gold" data-s="make-ai">✨ Write questions with Claude</button>' : ''}
        <button class="btn ${ai ? '' : 'gold'}" data-s="make-notes">📝 Fill-in-the-blanks from my notes</button>
        <button class="btn small" data-s="write-new">✍️ Write my own</button>
        ${this.data.cards.length ? '<button class="btn small" data-s="back">Cancel</button>' : ''}
      </div>
      <p class="muted s-note" id="s-note">${ai ? "Claude reads the assignment's files and your notes, then writes 8 questions (multiple choice and short answer). It takes about a minute."
        : S && S.web ? "This copy can't reach Claude, so it turns sentences from your notes into fill-in-the-blank cards. You can also write your own."
        : 'Connect Claude in Settings and it writes real questions from your files. Until then, it turns sentences from your notes into fill-in-the-blank cards.'}</p>
    </div>`;
  }

  // the make form follows its "What are you studying?" pick: a topic box for "Something else", a hint about files
  syncFrom() {
    const sel = this.root.querySelector('#s-from');
    if (!sel) return;
    this.makeFrom = sel.value;
    const S = this.getState(), q = sel.value.startsWith('q:') && S ? S.quests.find(x => `q:${x.id}` === sel.value) : null;
    this.root.querySelector('#s-topic-row').hidden = !!q;
    const n = q ? (q.files || []).length : 0;
    this.root.querySelector('#s-notes-hint').textContent = n && this.data.ai ? `(optional: Claude also reads its ${n} file${n > 1 ? 's' : ''})` : '(optional for Claude, needed for fill-in-the-blanks)';
  }

  readFrom() {
    const sel = this.root.querySelector('#s-from');
    const S = this.getState();
    if (sel && sel.value.startsWith('q:')) {
      const q = S && S.quests.find(x => `q:${x.id}` === sel.value);
      if (q) return { quest: q.id, name: q.title, files: (q.files || []).length };
    }
    const topic = (this.root.querySelector('#s-topic') || {}).value || '';
    if (!topic.trim()) { this.note('Type a topic first.'); this.root.querySelector('#s-topic').focus(); return null; }
    return { quest: null, name: topic.trim().slice(0, 80), files: 0 };
  }

  writeHtml() {
    const w = this.writeTo || { name: 'My cards' };
    return `<div class="card paper s-write">
      <h2>✍️ Write a card</h2>
      <p class="muted">For <b>${esc(w.name)}</b>. Short answers work best: a word or two.</p>
      <div class="field"><label for="s-wq">Question</label><textarea id="s-wq" rows="2" maxlength="300" placeholder="e.g. What does the hippocampus do?"></textarea></div>
      <div class="field"><label for="s-wa">Answer</label><input id="s-wa" type="text" maxlength="140" placeholder="e.g. Forms new long-term memories"></div>
      <div class="row"><button class="btn gold" data-s="add-card">＋ Add card</button><button class="btn small" data-s="back">Done</button></div>
      <p class="muted s-note" id="s-wnote"></p>
    </div>`;
  }

  note(text, id = 's-note') { const el = this.root.querySelector('#' + id); if (el) el.textContent = text; }
  busy(on) { for (const b of this.root.querySelectorAll('.study-main .btn')) b.disabled = on; }
  updateCard(card) {
    const i = this.data.cards.findIndex(c => c.id === card.id);
    if (i >= 0) this.data.cards[i] = card;
  }

  // ---- actions
  async act(name, el) {
    const S = this.getState();
    const deck = this.decks().find(d => d.key === this.deck);
    if (name === 'deck') { this.deck = el.dataset.k; this.view = 'deck'; sfx('select'); this.redraw(); return; }
    if (name === 'make') { this.view = 'make'; this.makeFrom = this.deck && this.deck.startsWith('q:') ? this.deck : null; this.redraw(); return; }
    if (name === 'more') { this.view = 'make'; this.makeFrom = deck && deck.quest != null ? deck.key : 'topic'; this.redraw(); if (deck && deck.quest == null) this.root.querySelector('#s-topic').value = deck.name; return; }
    if (name === 'back' || name === 'done') { this.battle = null; this.teach = null; this.view = this.deck ? 'deck' : 'decks'; this.redraw(); return; }
    // Teach Wick
    if (name === 'teach') { if (deck) return this.startTeach(deck); return; }
    if (name === 'teach-send') {
      const T = this.teach;
      if (!T) return;
      T.turns = [];             // (a fresh explanation starts the conversation over)
      T.revealed = false;
      return this.teachSend(this.root.querySelector('#s-explain').value);
    }
    if (name === 'teach-reply') {
      const box = this.root.querySelector('#s-reply');
      const sent = await this.teachSend(box.value);
      if (sent && box.isConnected) box.value = '';
      return;
    }
    if (name === 'teach-reveal') { if (this.teach) { this.teach.revealed = true; this.drawTeach(); } return; }
    if (name === 'teach-new') { const T = this.teach; if (T) return this.startTeach({ quest: T.quest, name: T.name, cards: T.cards }); return; }
    if (name === 'teach-pick') { const p = this.root.querySelector('#s-pick'); p.hidden = !p.hidden; if (!p.hidden) this.root.querySelector('#s-concept').focus(); return; }
    if (name === 'teach-pick-go') {
      const T = this.teach, concept = this.root.querySelector('#s-concept').value.trim();
      if (!T || !concept) { this.root.querySelector('#s-concept').focus(); return; }
      return this.startTeach({ quest: T.quest, name: T.name, cards: T.cards }, concept);
    }
    if (name === 'write') { this.writeTo = deck ? { quest: deck.quest, name: deck.name } : { quest: null, name: 'My cards' }; this.view = 'write'; this.redraw(); this.root.querySelector('#s-wq').focus(); return; }
    if (name === 'write-new') {
      const from = this.readFrom();
      if (!from) return;
      this.writeTo = { quest: from.quest, name: from.name };
      this.view = 'write';
      this.redraw();
      this.root.querySelector('#s-wq').focus();
      return;
    }
    if (name === 'add-card') return this.addCard();
    if (name === 'make-ai') return this.makeAI();
    if (name === 'make-notes') return this.makeNotes();
    if (name === 'review-due') return this.startDue();
    if (name === 'battle') return this.startDeck();
    if (name === 'del-card') {
      const c = this.data.cards.find(x => x.id === Number(el.dataset.id));
      if (!c || !confirm(`Delete this card?\n\n${c.q}`)) return;
      await api('/api/study/delete', { id: c.id });
      await this.load();
      return;
    }
    if (name === 'del-deck') {
      if (!deck || !confirm(`Delete all ${deck.cards.length} cards in "${deck.name}"?`)) return;
      await api('/api/study/delete', deck.quest != null ? { quest: deck.quest } : { deck: deck.name });
      this.deck = null;
      this.view = 'decks';
      await this.load();
      return;
    }
    // in a battle
    if (name === 'opt') return this.pickOption(Number(el.dataset.i));
    if (name === 'next') return this.nextCard();
    if (name === 'override') return this.override();
    if (name === 'flee') { this.battle = null; this.view = this.deck ? 'deck' : 'decks'; await this.load(); return; }
    if (name === 'again') {
      const b = this.battle;
      return this.startBattle(b.cards.map(c => this.data.cards.find(x => x.id === c.id)).filter(Boolean), 'practice');
    }
    if (S && name === 'noop') return;
  }

  async makeAI() {
    const from = this.readFrom();
    if (!from) return;
    const notes = this.root.querySelector('#s-notes').value;
    const what = from.files ? `the assignment's file${from.files > 1 ? 's' : ''}${notes.trim() ? ' and your notes' : ''}` : notes.trim() ? 'your notes' : `about ${from.name}`;
    this.busy(true);
    this.note(`Claude is reading ${what} and writing questions… (this can take a minute)`);
    let r;
    try { r = await api('/api/study/make', { quest: from.quest, topic: from.quest == null ? from.name : '', notes, count: 8 }); } catch (e) { r = { ok: false, error: "Couldn't reach Claude just now. Try again in a minute." }; }
    if (!this.root.querySelector('#s-note')) return;   // (left the form meanwhile)
    this.busy(false);
    if (!r.ok) { this.note(r.error || "Claude didn't write any questions. Try again?"); return; }
    sfx('fanfare');
    this.toast(`✨ ${r.cards.length} new questions, ready to battle!`);
    this.deck = deckKey(r.cards[0]);
    this.view = 'deck';
    await this.load();
  }

  async makeNotes() {
    const from = this.readFrom();
    if (!from) return;
    const notes = this.root.querySelector('#s-notes').value;
    if (notes.trim().length < 40) { this.note('Paste a few sentences of your notes first.'); this.root.querySelector('#s-notes').focus(); return; }
    const cards = notesToCards(notes, 10);
    if (!cards.length) { this.note("Couldn't find sentences to turn into blanks. Try longer notes, or write your own cards."); return; }
    const r = await api('/api/study/add', { cards, quest: from.quest, deck: from.name, by: 'notes' });
    if (!r.ok) { this.note("Couldn't save those cards. Try again?"); return; }
    sfx('select');
    this.toast(`📝 ${r.cards.length} fill-in-the-blank cards made from your notes.`);
    this.deck = deckKey(r.cards[0]);
    this.view = 'deck';
    await this.load();
  }

  async addCard() {
    const q = this.root.querySelector('#s-wq').value.trim(), a = this.root.querySelector('#s-wa').value.trim();
    if (!q || !a) { this.note('It needs a question and an answer.', 's-wnote'); return; }
    const w = this.writeTo || { quest: null, name: 'My cards' };
    const r = await api('/api/study/add', { cards: [{ type: 'short', q, answer: a }], quest: w.quest, deck: w.name, by: 'you' });
    if (!r.ok) { this.note("Couldn't add that card.", 's-wnote'); return; }
    sfx('select');
    this.deck = deckKey(r.cards[0]);
    const data = await api('/api/study').catch(() => null);
    if (data) this.data = data;
    this.root.querySelector('#s-wq').value = '';
    this.root.querySelector('#s-wa').value = '';
    const n = this.data.cards.filter(c => deckKey(c) === this.deck).length;
    this.note(`Added! That deck has ${n} card${n === 1 ? '' : 's'} now. Write another, or press Done.`, 's-wnote');
    this.root.querySelector('#s-wq').focus();
  }

  // ---- battles
  async startDue() {
    if (!this.data) await this.load();
    const today = this.data.today;
    const due = this.data.cards.filter(c => c.due <= today).sort((a, b) => a.box - b.box || a.id - b.id).slice(0, BATTLE_MAX);
    if (!due.length) { this.toast('Nothing is due right now. 🌿'); return; }
    return this.startBattle(due, 'due');
  }

  startDeck() {
    const deck = this.decks().find(d => d.key === this.deck);
    if (!deck) return;
    const due = deck.cards.filter(c => c.due <= this.data.today).sort((a, b) => a.box - b.box || a.id - b.id).slice(0, BATTLE_MAX);
    return due.length ? this.startBattle(due, 'due') : this.startBattle(shuffle([...deck.cards]).slice(0, PRACTICE_MAX), 'practice');
  }

  async startBattle(list, mode) {
    if (!list.length) return;
    await loadArt();
    const prep = c => {
      if (c.type !== 'mc') return { ...c, accept: [c.answer, ...(c.accept || [])] };
      const order = shuffle(c.options.map((_, k) => k));
      return { ...c, options: order.map(k => c.options[k]), answer: order.indexOf(c.answer) };
    };
    const cards = list.map(prep);
    this.battle = { mode, cards, byId: new Map(cards.map(c => [c.id, c])), queue: cards.map(c => c.id), max: cards.length, hp: cards.length,
      streak: 0, firstTry: 0, misses: new Set(), light: 0, enemy: ENEMIES[Math.floor(Math.random() * ENEMIES.length)],
      anim: null, floats: [], cur: null, answered: false, defeated: null };
    this.view = 'battle';
    this.key = null;
    this.draw();
    sfx('start');
    this.nextCard();
    this.loop();
  }

  battleHtml() {
    const b = this.battle;
    const name = { gloomling: 'Gloomling', inkblot: 'Inkblot', buzzbug: 'Buzzbug', puddlet: 'Puddlet', wisp: 'Wisp', glowbat: 'Glowbat', spikeshroom: 'Spikeshroom', cinderling: 'Cinderling' }[b.enemy];
    return `<div class="card paper s-battle">
      <div class="s-arena"><canvas id="s-canvas"></canvas>
        <div class="s-hp"><span>Forgetful ${name}</span> · <span id="s-hp-t"></span><div class="bar"><i id="s-hp"></i></div></div>
        <button class="btn small s-flee" data-s="flee" title="Stop this battle (your answers so far still count)">✕ Stop</button>
        ${b.mode === 'practice' ? '<span class="s-mode">Practice: no Light, no schedule changes</span>' : ''}
      </div>
      <div class="s-q" id="s-q"></div>
      <div class="s-victory" id="s-victory" hidden></div>
    </div>`;
  }

  renderHP() {
    const b = this.battle;
    if (!b) return;
    const fill = this.root.querySelector('#s-hp'), t = this.root.querySelector('#s-hp-t');
    if (fill) fill.style.width = `${(100 * b.hp) / b.max}%`;
    if (t) t.textContent = `${b.hp}/${b.max}`;
  }

  nextCard() {
    const b = this.battle;
    if (!b) return;
    if (!b.queue.length) { this.victory(); return; }
    const c = b.cur = b.byId.get(b.queue.shift());
    b.answered = false;
    const meta = [`Hit ${b.max - b.hp + 1} of ${b.max}`];
    if (b.streak >= 2) meta.push(`🔥 ${b.streak} in a row`);
    if (b.misses.has(c.id)) meta.push('back for another try');
    const box = this.root.querySelector('#s-q');
    box.innerHTML = `<div class="s-meta">${meta.join(' · ')}<span class="s-deckname">${esc(c.deck)}</span></div>
      <h3 class="s-text">${esc(c.q)}</h3>
      ${c.type === 'mc' ? `<div class="s-options">${c.options.map((o, k) => `<button class="s-opt" data-s="opt" data-i="${k}"><kbd>${k + 1}</kbd><span>${esc(o)}</span></button>`).join('')}</div>`
        : '<form class="s-short" id="s-short"><input class="s-field" id="s-input" type="text" autocomplete="off" placeholder="Type your answer" aria-label="Your answer"><button class="btn gold" type="submit">Answer</button></form>'}
      <div class="s-fb" id="s-fb" hidden></div>`;
    if (c.type === 'short') this.root.querySelector('#s-input').focus({ preventScroll: true });
  }

  pickOption(k) {
    const b = this.battle;
    if (!b || b.answered || !b.cur || b.cur.type !== 'mc') return;
    this.root.querySelectorAll('.s-opt').forEach((el, i) => {
      el.disabled = true;
      el.classList.add(i === b.cur.answer ? 'right' : i === k ? 'wrong' : 'dim');
    });
    this.resolve(k === b.cur.answer);
  }

  submitShort() {
    const b = this.battle;
    if (!b || b.answered || !b.cur) return;
    const inp = this.root.querySelector('#s-input'), v = inp.value.trim();
    if (!v) return;
    inp.disabled = true;
    this.resolve(matches(v, b.cur.accept));
  }

  async resolve(ok, overriding = false) {
    const b = this.battle, c = b.cur;
    b.answered = true;
    const first = !b.misses.has(c.id);
    let res = null;
    try { res = await api('/api/study/answer', { id: c.id, right: ok, first }); } catch (e) { /* the battle goes on */ }
    if (this.battle !== b) return;          // (stopped meanwhile)
    if (res && res.ok && res.card) this.updateCard(res.card);
    let html;
    if (ok) {
      b.hp--;
      b.streak++;
      if (first) b.firstTry++;
      const beam = b.streak % 3 === 0;
      this.heroHit(beam);
      if (res && res.light) { b.light += res.light; this.float(`+${res.light} ✦`, 'light'); }
      const due = res && res.card ? res.card.due : null;
      const when = b.mode === 'practice' || !due ? 'Practice: its schedule stays the same' : `Comes back ${whenText(this.data.today, due)}`;
      html = `<div><b>${beam ? '✨ Lantern Beam! That’s 3 in a row.' : overriding ? '✓ Counted!' : '✓ Right!'}</b><span class="s-when">${when}</span></div>`;
    } else {
      b.streak = 0;
      b.misses.add(c.id);
      this.foeHit();
      b.queue.splice(Math.min(2, b.queue.length), 0, c.id);   // (it comes back a couple of questions later)
      html = `<div><b>✗ Not quite.</b> It's <b>${esc(answerText(c))}</b>.<span class="s-when">Back in a moment</span></div>`;
      if (c.type === 'short') html += '<div><button class="btn small" data-s="override">That’s what I meant (count it)</button></div>';
    }
    if (c.source) html += `<blockquote><small>From your material</small>${esc(c.source)}</blockquote>`;
    html += `<div class="row s-end"><button class="btn gold" data-s="next">${b.queue.length ? 'Next ▸' : 'Finish ▸'}</button></div>`;
    const fb = this.root.querySelector('#s-fb');
    fb.className = `s-fb ${ok ? 'ok' : 'no'}`;
    fb.innerHTML = html;
    fb.hidden = false;
    this.renderHP();
    fb.querySelector('[data-s="next"]').focus({ preventScroll: true });
    if (res && res.light) this.refresh();
  }

  // a typed answer marked wrong that was really right: it counts after all (and stops coming back)
  override() {
    const b = this.battle, c = b && b.cur;
    if (!c) return;
    const i = b.queue.lastIndexOf(c.id);
    if (i >= 0) b.queue.splice(i, 1);
    b.misses.delete(c.id);
    b.answered = false;
    return this.resolve(true, true);
  }

  async victory() {
    const b = this.battle;
    b.defeated = performance.now() / 1000;
    let bonus = 0;
    if (b.mode === 'due') { try { bonus = (await api('/api/study/win', {})).light || 0; } catch (e) { /* no bonus */ } }
    if (this.battle !== b) return;
    b.light += bonus;
    sfx('fanfare');
    this.root.querySelector('#s-q').hidden = true;
    const ids = new Set(b.cards.map(c => c.id)), today = this.data.today;
    const groups = new Map();
    for (const c of this.data.cards) if (ids.has(c.id)) { const d = Math.max(0, daysBetween(today, c.due)); groups.set(d, (groups.get(d) || 0) + 1); }
    const rows = [...groups].sort((x, y) => x[0] - y[0]).map(([d, n]) => `<li><b>${d === 0 ? 'Today' : d === 1 ? 'Tomorrow' : `In ${d} days`}</b><span>${n} card${n === 1 ? '' : 's'}</span></li>`).join('');
    const v = this.root.querySelector('#s-victory');
    v.innerHTML = `<h3>🏆 Victory!</h3>
      <div class="s-stats"><div><b>${b.firstTry}/${b.max}</b><span>right the first time</span></div>
        <div><b>+${b.light} ✦</b><span>Light earned${bonus ? ` (incl. +${bonus} for the win)` : ''}</span></div>
        <div><b>${b.misses.size}</b><span>to practice again</span></div></div>
      ${b.mode === 'practice' ? '<p class="muted">That was practice, so nothing’s schedule changed.</p>' : `<p class="muted">When they come back:</p><ul class="s-sched">${rows}</ul>`}
      <div class="row"><button class="btn gold" data-s="done">Back to the deck</button><button class="btn" data-s="again">⚔️ Practice these again</button></div>`;
    v.hidden = false;
    this.refresh();
  }

  // ---- the arena (drawn with the game's own art)
  heroHit(beam) {
    const b = this.battle, now = performance.now() / 1000;
    b.anim = { who: 'hero', t0: now, beam };
    sfx(beam ? 'perfect' : 'hit');
    setTimeout(() => { if (this.battle === b) this.float(beam ? '−1 ✨' : '−1', 'dmg'); }, 260);
  }
  foeHit() {
    const b = this.battle;
    b.anim = { who: 'foe', t0: performance.now() / 1000 };
    sfx('hurt');
    setTimeout(() => { if (this.battle === b) this.float('Oof!', 'ouch'); }, 260);
  }
  float(text, kind) { const b = this.battle; if (b) b.floats.push({ text, kind, t0: performance.now() / 1000 }); }

  loop() {
    if (this.looping) return;
    this.looping = true;
    const frame = () => {
      if (!this.active || this.view !== 'battle' || !this.battle || !this.cv || !this.cv.isConnected) { this.looping = false; return; }
      this.drawArena(performance.now() / 1000);
      requestAnimationFrame(frame);
    };
    requestAnimationFrame(frame);
  }

  drawArena(t) {
    const cv = this.cv, b = this.battle, dpr = window.devicePixelRatio || 1;
    const w = cv.clientWidth, h = cv.clientHeight;
    if (!w || !h) return;
    if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
    const c = cv.getContext('2d');
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    // the stage: a sunset backdrop, wooden boards, red curtains with a gold-trimmed valance
    const g = c.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, '#ffe2c9'); g.addColorStop(0.62, '#f6b6a6'); g.addColorStop(1, '#d98d8e');
    c.fillStyle = g; c.fillRect(0, 0, w, h);
    if (b.anim && b.anim.beam && t - b.anim.t0 < 0.8) { c.fillStyle = `rgba(255,240,170,${0.6 * (1 - (t - b.anim.t0) / 0.8)})`; c.fillRect(0, 0, w, h); }
    const fy = h * 0.76;
    c.fillStyle = '#d9a86a'; c.fillRect(0, fy, w, h - fy);
    c.fillStyle = '#b98a52';
    for (let x = 28; x < w; x += 57) c.fillRect(x, fy, 3, h - fy);
    c.fillStyle = INK; c.fillRect(0, fy - 1.5, w, 3);
    const cw = Math.max(26, w * 0.075);
    for (const [x0, edge] of [[0, cw], [w - cw, w - cw]]) {
      for (let x = x0; x < x0 + cw; x += 18) { c.fillStyle = '#b8333d'; c.fillRect(x, 0, 12, h); c.fillStyle = '#8e1f2b'; c.fillRect(x + 12, 0, 6, h); }
      c.fillStyle = INK; c.fillRect(edge - 1.5, 0, 3, h);
    }
    c.fillStyle = '#f2b43a'; c.fillRect(0, 0, w, 6);
    c.fillStyle = '#b8333d';
    for (let x = 0; x < w + 36; x += 36) { c.beginPath(); c.arc(x + 18, 6, 18, 0, Math.PI); c.fill(); }
    if (!art) return;
    // Wick and the Gloom: whoever attacks lunges across the stage (Wick swings his hammer); whoever is hit shakes
    const k = Math.min(h / 230, w / 560), A = b.anim, p = A ? (t - A.t0) / 0.6 : 1;
    let wx = w * 0.3, ex = w * 0.7, swing = null, shakeW = 0, shakeE = 0, flashE = false, mood = 'determined';
    if (A && p < 1) {
      const lunge = Math.sin(Math.min(1, p) * Math.PI);
      if (A.who === 'hero') { wx += lunge * (ex - wx) * 0.5; swing = Math.min(1, p * 1.7); if (p > 0.4) { shakeE = Math.sin(t * 70) * 5 * (1 - p); flashE = Math.floor(t * 20) % 2 === 0; } }
      else { ex -= lunge * (ex - wx) * 0.5; if (p > 0.4) { shakeW = Math.sin(t * 70) * 5 * (1 - p); mood = 'hurt'; } }
    }
    art.drawWick(c, wx + shakeW, fy + 4 * k, { t, scale: 1.75 * k, hammer: true, swing, headband: true, mood, flip: 1, state: A && A.who === 'hero' && p < 1 ? 'jump' : 'idle' });
    const draw = art.DRAW[b.enemy] || art.DRAW.gloomling;
    if (b.defeated == null || t - b.defeated < 0.9) {
      const d = b.defeated == null ? 0 : (t - b.defeated) / 0.9;
      c.save();
      c.globalAlpha = 1 - d;
      if (flashE) c.filter = 'brightness(1.8)';
      c.translate(ex + shakeE, fy + 4 * k);
      c.rotate(d * 1.2);
      draw(c, 0, 0, { t, scale: 1.6 * k, flip: -1, state: 'idle', phase: t * 2 });
      c.restore();
    }
    // floating numbers
    for (const f of b.floats) {
      const q = (t - f.t0) / 1;
      if (q >= 1) continue;
      const x = f.kind === 'ouch' || f.kind === 'light' ? wx : ex, y = fy - 120 * k - q * 40 * k;
      c.globalAlpha = Math.min(1, 2 * (1 - q));
      c.font = `bold ${Math.round((f.kind === 'dmg' ? 28 : 22) * k)}px Fredoka, sans-serif`;
      c.textAlign = 'center'; c.lineWidth = 5; c.strokeStyle = INK; c.strokeText(f.text, x, y);
      c.fillStyle = f.kind === 'dmg' ? '#fff3a0' : f.kind === 'light' ? '#ffd76e' : '#ffb0a0';
      c.fillText(f.text, x, y);
    }
    c.globalAlpha = 1;
    b.floats = b.floats.filter(f => t - f.t0 < 1);
  }

  onKey(e) {
    if (!this.active || this.view !== 'battle' || !this.battle || e.altKey || e.ctrlKey || e.metaKey) return;
    const modal = document.querySelector('#modal');
    if (modal && !modal.classList.contains('hidden')) return;
    if (e.target.closest && e.target.closest('input, textarea, select')) return;
    const b = this.battle;
    if (!b.answered && b.cur && b.cur.type === 'mc') {
      const k = Number(e.key) - 1;
      if (k >= 0 && k < b.cur.options.length) { e.preventDefault(); this.pickOption(k); }
    }
  }

  // ---- Teach Wick: explain an idea in your own words. With Claude, Wick picks an idea from the deck (or takes yours)
  // with the key points a good explanation needs, says what clicked and asks about what's missing. Without Claude, he
  // checks your explanation against the deck's own cards.
  async startTeach(deck, concept = '') {
    await loadArt();
    const T = this.teach = { quest: deck.quest, name: deck.name, cards: deck.cards, concept: '', ask: '', ideas: [], turns: [],
      result: null, prev: 0, revealed: false, busy: false, local: !this.data.ai };
    this.view = 'teach';
    this.key = null;
    this.draw();
    if (T.local) { this.localRubric(); this.drawTeach(); return; }
    T.busy = true;
    this.drawTeach(concept ? 'Wick is reading up on that…' : 'Wick is picking something to ask you about…');
    let r;
    try { r = await api('/api/study/teach/start', { quest: deck.quest, deck: deck.name, concept }); } catch (e) { r = { ok: false }; }
    if (this.teach !== T) return;
    T.busy = false;
    if (!r.ok && r.no_ai) { T.local = true; this.localRubric(); this.drawTeach(); return; }
    if (!r.ok) { this.drawTeach(r.error || "Wick couldn't think of a question just now. Try “Ask me something else”."); return; }
    Object.assign(T, { concept: r.concept, ask: r.ask, ideas: r.ideas.map(text => ({ text })) });
    this.drawTeach();
    const box = this.root.querySelector('#s-explain');
    if (box) box.focus({ preventScroll: true });
  }

  // (no Claude: the ideas are up to 4 of the deck's answers, and Wick asks about the deck as a whole)
  localRubric() {
    const T = this.teach, seen = new Set(), picked = [];
    for (const c of shuffle([...T.cards])) {
      const a = answerText(c).toLowerCase();
      if (seen.has(a)) continue;
      seen.add(a);
      picked.push(c);
      if (picked.length >= 4) break;
    }
    T.concept = T.name;
    T.ask = `I missed class! Can you tell me about ${T.name}? Explain the main ideas in your own words, like you're talking to a candle.`;
    T.ideas = picked.map(c => ({ text: answerText(c), card: c }));
    T.result = null;
    T.turns = [];
  }

  localCheck() {
    const T = this.teach, said = T.turns.filter(t => t.who === 'you').map(t => t.text).join(' ');
    const covered = T.ideas.map(i => coversIdea(i.text, said));
    const got = covered.filter(Boolean).length, total = T.ideas.length, miss = covered.indexOf(false);
    let follow = '';
    if (miss >= 0) { const q = T.ideas[miss].card.q; follow = q.includes('_____') ? `Can you fill this in for me? “${q}”` : q; }
    const wick = got === total ? 'Whoa, I totally get it now! I could explain it to Moss. Thank you!'
      : got * 2 >= total ? 'Ooh, that part clicked! But there’s a piece I’m still missing…'
        : got ? 'Okay, I got one bit of that. Can you tell me more?' : "Hmm, I'm still a little lost. What's the big idea?";
    return { covered, mistakes: [], wick, follow };
  }

  async teachSend(text) {
    const T = this.teach;
    if (!T || T.busy || !T.ideas.length) return false;
    if (!text.trim()) { this.drawTeach('Write a few sentences for Wick first.'); return false; }
    T.turns.push({ who: 'you', text: text.trim().slice(0, 2000) });
    let res;
    if (T.local) res = this.localCheck();
    else {
      T.busy = true;
      this.drawTeach('Wick is listening and thinking…');
      let r;
      try { r = await api('/api/study/teach/check', { quest: T.quest, deck: T.name, concept: T.concept, ask: T.ask, ideas: T.ideas.map(i => i.text), turns: T.turns }); } catch (e) { r = { ok: false }; }
      if (this.teach !== T) return false;
      T.busy = false;
      if (!r.ok) { T.turns.pop(); this.drawTeach(r.error || "Wick couldn't hear you just now. Try again?"); return false; }
      res = { covered: T.ideas.map((_, k) => !!(r.covered || [])[k]), mistakes: r.mistakes || [], wick: r.wick || '', follow: r.follow_up || '' };
    }
    if (res.follow) T.turns.push({ who: 'wick', text: res.follow });
    T.result = res;
    const got = res.covered.filter(Boolean).length, total = T.ideas.length;
    let light = 0;
    try { light = (await api('/api/study/teach/reward', { got, total, prev: T.prev })).light || 0; } catch (e) { /* no Light */ }
    if (this.teach !== T) return true;
    T.prev = Math.max(T.prev, got);
    sfx(got === total ? 'fanfare' : got ? 'nice' : 'whiff');
    this.drawTeach(light ? `+${light} ✦ for explaining it${got === total ? ' (and +2 for all of it!)' : ''}` : '');
    if (light) this.refresh();
    return true;
  }

  teachHtml() {
    return `<div class="card paper s-teach"><div class="s-teach-grid">
      <div class="s-teach-side">
        <canvas id="s-wick" aria-label="Wick, listening"></canvas>
        <div class="s-bubble" id="s-ask"></div>
        <div class="row s-teach-btns"><button class="btn small" data-s="teach-new">🎲 Ask me something else</button><button class="btn small" data-s="teach-pick">✍️ I'll pick</button></div>
        <div class="s-pick" id="s-pick" hidden><input class="s-field" id="s-concept" type="text" maxlength="120" placeholder="What will you explain?"><button class="btn small gold" data-s="teach-pick-go">Ask me that</button></div>
      </div>
      <div class="s-teach-main">
        <h2>🕯️ Teach Wick <span class="s-teach-deck">${esc(this.teach.name)}</span></h2>
        <label for="s-explain">Your explanation</label>
        <textarea class="s-area" id="s-explain" rows="6" maxlength="2000" placeholder="Explain it like you're talking to a friend who missed class. No peeking at your notes!"></textarea>
        <div class="row"><button class="btn gold" data-s="teach-send">Explain it to Wick</button><button class="btn small" data-s="back">Done</button></div>
        <p class="s-note" id="s-tnote"></p>
        <div class="s-tresult" id="s-tresult" hidden>
          <div class="s-meter" id="s-meter"></div>
          <p class="s-says" id="s-says"></p>
          <ul class="s-ideas" id="s-ideas"></ul>
          <div class="row"><button class="btn small" data-s="teach-reveal" id="s-reveal">Show what I missed</button></div>
          <div class="s-follow" id="s-follow" hidden><p id="s-fq"></p>
            <textarea class="s-area" id="s-reply" rows="3" maxlength="2000" aria-label="Your answer to Wick" placeholder="Answer Wick…"></textarea>
            <div class="row"><button class="btn gold" data-s="teach-reply">Answer Wick</button></div></div>
        </div>
      </div>
    </div></div>`;
  }

  // the Teach Wick view, from its state (a note under the buttons, when there's something to say)
  drawTeach(note = '') {
    const T = this.teach, $ = s => this.root.querySelector(s);
    if (!T || !$('#s-ask')) return;
    $('#s-ask').textContent = T.ask || (T.busy ? 'Hmm, let me think of something to ask you…' : '…');
    const S = this.getState();
    $('#s-tnote').textContent = note || (T.local ? (S && S.web ? "Wick checks what you say against this deck's cards. (This copy can't reach Claude.)"
      : "Wick checks what you say against this deck's cards. (Connect Claude in Settings and he really listens.)") : '');
    for (const b of this.root.querySelectorAll('.s-teach .btn')) b.disabled = T.busy && b.dataset.s !== 'back';
    $('[data-s="teach-pick"]').hidden = T.local;
    if (T.local) $('#s-pick').hidden = true;
    const r = T.result;
    $('#s-tresult').hidden = !r;
    if (!r) return;
    const got = r.covered.filter(Boolean).length, total = T.ideas.length;
    $('#s-meter').innerHTML = T.ideas.map((_, k) => candleSVG(r.covered[k])).join('') + `<span class="lbl">${got} of ${total} idea${total === 1 ? '' : 's'}</span>`;
    $('#s-says').textContent = r.wick;
    $('#s-ideas').innerHTML = T.ideas.map((idea, k) => (r.covered[k] ? `<li class="got">✓ <span>${esc(idea.text)}</span></li>`
      : T.revealed ? `<li class="miss shown">💡 <span>${esc(idea.text)}</span></li>` : '<li class="miss">? <span>Something Wick still needs to hear</span></li>')).join('')
      + r.mistakes.map(m => `<li class="oops">⚠️ <span>This part might be off: ${esc(m)}</span></li>`).join('');
    $('#s-reveal').hidden = T.revealed || got === total;
    $('#s-follow').hidden = !r.follow || got === total;
    $('#s-fq').textContent = r.follow ? `Wick asks: ${r.follow}` : '';
  }

  // Wick on his little stage, listening: he scribbles notes while he thinks, and lights up when he gets it
  teachLoop() {
    if (this.teachLooping) return;
    this.teachLooping = true;
    const frame = () => {
      const cv = this.root.querySelector('#s-wick'), T = this.teach;
      if (!this.active || this.view !== 'teach' || !cv || !T) { this.teachLooping = false; return; }
      const dpr = window.devicePixelRatio || 1, w = cv.clientWidth || 200, h = cv.clientHeight || 220;
      if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
      const c = cv.getContext('2d'), t = performance.now() / 1000;
      c.setTransform(dpr, 0, 0, dpr, 0, 0);
      c.clearRect(0, 0, w, h);
      if (art) {
        const r = T.result, all = r && r.covered.every(Boolean);
        art.glowDot(c, w / 2, h * 0.5, w * 0.48, '255,214,120', all ? 0.35 : 0.16);
        art.drawWick(c, w / 2, h - 12, { t, scale: Math.min(w / 90, h / 100), writing: T.busy, mood: all ? 'happy' : 'normal', flame: all ? 1.5 : 1.1 });
      }
      requestAnimationFrame(frame);
    };
    requestAnimationFrame(frame);
  }

  // ---- from other tabs
  async reviewDue() { this.view = 'decks'; await this.load(); return this.startDue(); }
  openQuest(qid) {
    this.battle = null;
    this.deck = `q:${qid}`;
    this.view = 'deck';
    this.makeFrom = `q:${qid}`;
    this.redraw();
  }
}
