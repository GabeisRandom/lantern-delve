// The adventure: an open world of rooms, story scripts, side quests, shops, fishing and the world map.
import {
  DRAW, drawWick, drawBackdrop, drawChest, drawLamp, drawSign, drawDoor, drawShrine, drawShard, drawBrokenLantern, drawDarkness,
  glowDot, starPath, paper, shape, rrect, ell, vgrad, INK, PAPER, shadow, drawBush, drawPot, drawSpring, drawBoulder, drawSeal,
  drawGoldAcorn, drawBook, drawQuestBoard, drawWindmill, drawDock, drawLostEmber, drawWickRoll, drawVent, drawBrazier, drawVines,
  drawHotSpring, flame,
} from '../art.js';
import { api, esc, fmt } from '../api.js';
import { sfx } from '../audio.js';
import { music } from '../music.js';
import {
  view, atDepth, box, HZ, GZ0, GZ1, ZMIN, ZMAX, BZ0, drawHazard3d, drawFloor, drawPlat3d, drawWall3d,
  drawCrack3d, drawGate3d, drawLowRock3d, drawBlock3d, drawPathDoor, drawExitMat, drawBackDoor, drawBuilding3d, drawHouse3d,
  decorFor, drawDecor, drawInteriorShell, FURN, FURN_Z, FURN_FOOT, drawRug, drawPage, drawBackdrop2, drawDropShadow, drawHedge3d,
  fieldDecorFor, DECOR_DRAW, DECOR_FOOT, matFor, decorSprite, FOCAL,
} from '../art2.js';
import {
  ROOMS, SCRIPTS, AREAS, ITEMS, KEY_ITEMS, BADGES, PARTNERS, SHOP_ITEMS, SHOP_BADGES, STAR_BADGES, CHEST_BADGES,
  QUESTS, SPEAKERS, SPEAKER_OPTS, TOWN_TALK, objective, newSave, bondLevel, BOND_LEVELS, TRAINING,
} from './data.js';
import { npcHook, newsFor, PAGE_TEXT, PORTRAIT_SCALE } from './expansion.js';
import { MapScreen, updateGuide, drawGuide, routeText, roomName, goalZ } from './guide.js';
import { Battle } from './battle.js';
import { drawLandmarks, drawFrontPath, drawSignpost, drawTerrain3d, drawRoad, drawPlaza, drawBars } from '../art3.js';
import { MECH } from './mechanics.js';
import { STICKERS, wildNews } from './wilds.js';
import { MINI } from './minigames.js';
import { TOWER_FIELD } from './tower_play.js';
import { MARGIN_FIELD } from './margin_play.js';
import { MINIMAP } from './minimap.js';
import { drawGear } from '../art4.js';

const W = 960, H = 540;
const GRAV = 2300, JUMP_V = 830, RUN = 290, GROUND_ACC = 2600, AIR_ACC = 1800, GLIDE_FALL = 75, MAX_FALL = 1100;
const SPRING_V = 1200, MOSS_V = 1150, VENT_V = 1250;
const PW = 30, PH = 58, RH = 30, LOW_GAP = 40;   // RH: height while rolled; LOW_GAP: crawl space under low rocks
const PZ = 18;              // how thick Wick is front-to-back, for bumping into things in depth
const DEPTH_SPEED = 0.8;    // walking into the distance is a little slower than walking sideways
const CAMZ_OFF = 220;       // in the big fields the camera follows this far behind Wick
const RIDGE_Z = GZ1 + 40;   // in a big field the old puzzle walls fill the floor up to here, and a ridge carries on behind
const WADE = 26;            // how far below the floor shallow water's bed is: the biggest step you can walk up
// In a big field a cracked wall is one wall this tall, all of it the breakable part (no plain wall stacked on top of
// it up to the sky): taller than Moss's boost jump (287), and its ridge stays this tall after you break through.
// Near a spring or a steam vent (which throw you higher) it keeps the old full height.
const CRACK_H = 320;
const BOUNCY = new Set(['brambles', 'spikes', 'gears', 'gloom', 'lava', 'blank']);   // gap floors that bounce you back out
const BOUNCE_V = 1150;

// Does the straight line from point a to point b ([x, y, z]) pass through the box [x0, y0, z0, x1, y1, z1]?
function segHitsBox(a, b, bx) {
  let t0 = 0, t1 = 1;
  for (let i = 0; i < 3; i++) {
    const d = b[i] - a[i], lo = bx[i], hi = bx[i + 3];
    if (hi <= lo) return false;
    if (Math.abs(d) < 1e-9) { if (a[i] < lo || a[i] > hi) return false; continue; }
    let u = (lo - a[i]) / d, v = (hi - a[i]) / d;
    if (u > v) [u, v] = [v, u];
    t0 = Math.max(t0, u); t1 = Math.min(t1, v);
    if (t0 >= t1) return false;
  }
  return t0 < 0.995;
}
const DRAIN_EVERY = 15;     // seconds of adventure per 1 Light
const FLARE_EVERY = 3;      // a lit flare burns 1 more Light this often (seconds), +1 per Steady Flare level
// What Wick can pour ✦ Light into at the Great Lantern in Lumen Town: the Light each level costs, what it does, and
// what Wick notices after.
const LANTERN = {
  beam: { name: '✦ Lantern Beam', costs: [30, 60],
    what: ['Learn the Lantern Beam: a battle move that sweeps light over EVERY enemy (costs 8 ✦ each time).', 'The Lantern Beam hits 1 harder.'],
    done: ['Wick learned the Lantern Beam! Find it in his battle menu.', 'The Lantern Beam burns brighter!'] },
  flare: { name: '🔥 Steady Flare', costs: [40, 80],
    what: [`Your flare burns 1 ✦ every ${FLARE_EVERY + 1} seconds instead of ${FLARE_EVERY}.`, `Your flare burns 1 ✦ every ${FLARE_EVERY + 2} seconds.`],
    done: ['Your flare will last longer now.', 'Your flare is as steady as the Great Lantern itself.'] },
  ward: { name: '🌙 Gloom Ward', costs: [40, 80],
    what: ['Enemies have to be a lot closer to spot you.', 'Enemies barely notice you: sneak right up on them.'],
    done: ['The Gloom will have a harder time spotting you.', 'You glow so softly now, the Gloom hardly sees you coming.'] },
  glow: { name: '✨ Treasure Glow', costs: [50],
    what: ['Hidden ✦ blocks sparkle whenever you walk near them.'],
    done: ['Hidden blocks will sparkle when you get close.'] },
};
// ↑ ↓ (W S) walk into and out of the distance; SPACE jumps; hold R or Shift to roll
const KEYMAP = {
  ArrowLeft: 'left', KeyA: 'left', ArrowRight: 'right', KeyD: 'right', ArrowUp: 'up', KeyW: 'up',
  ArrowDown: 'down', KeyS: 'down', Space: 'jump', KeyZ: 'jump', KeyE: 'act', Enter: 'act',
  KeyX: 'hammer', KeyJ: 'hammer', KeyF: 'flare', KeyK: 'flare', KeyC: 'ability', KeyL: 'ability',
  KeyR: 'roll', ShiftLeft: 'roll', ShiftRight: 'roll',
  Escape: 'menu', KeyQ: 'menu', Tab: 'map', KeyH: 'hint',
  // (the detailed map: zoom, and the other places in the area)
  Equal: 'zoomin', NumpadAdd: 'zoomin', Minus: 'zoomout', NumpadSubtract: 'zoomout', BracketLeft: 'prevroom', BracketRight: 'nextroom',
};
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
// Boxes may also have a depth range (z0..z1); without one they reach across the whole floor.
const overlap = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y
  && (a.z0 ?? -1e9) < (b.z1 ?? 1e9) && (a.z1 ?? 1e9) > (b.z0 ?? -1e9);
const hashStr = s => { let h = 0; for (const ch of String(s)) h = (h * 31 + ch.charCodeAt(0)) % 9973; return h / 9973; };
// Where things stand in depth when a room doesn't say: signs and lamps a little back, quest boards and shrines further.
const Z_DEFAULT = { sign: 70, lamp: 40, board: 110, shrine: 120, brazier: 40, switch: 40, boss: 40, shop: 60 };
const STUDY_QUESTS = ['study_first', 'study_clean', 'study_hero', 'study_marathon'];

export class Adventure {
  constructor(root, hub) {
    this.root = root;
    this.hub = hub;
    root.innerHTML = `<div class="game">
      <canvas class="g-canvas"></canvas>
      <div class="g-hud"></div>
      <div class="g-dialog hidden"><canvas class="portrait" width="220" height="220"></canvas>
        <div class="dlg-body"><div class="dlg-name"></div><div class="dlg-text"></div><div class="dlg-next">▼</div></div></div>
      <div class="g-panel hidden"></div>
      <div class="g-battle hidden"></div>
      <div class="g-card hidden"></div>
      <div class="g-tip hidden"></div>
      <div class="g-lock hidden"></div>
      <div class="g-help">← → ↑ ↓ walk · SPACE jump · R roll · E talk/lift/throw · X hammer · C partner · F flare · TAB map · H hint · M music · ESC menu</div>
    </div>`;
    const q = s => root.querySelector(s);
    this.cv = q('.g-canvas');
    this.c = this.cv.getContext('2d');
    this.hudEl = q('.g-hud');
    this.dlgEl = q('.g-dialog');
    this.portrait = q('.portrait');
    this.panelEl = q('.g-panel');
    this.battleEl = q('.g-battle');
    this.cardEl = q('.g-card');
    this.tipEl = q('.g-tip');
    this.lockEl = q('.g-lock');
    this.keys = new Set();
    this.pressed = new Set();
    this.active = false;
    this.mode = 'loading';
    this.t = 0;
    this.last = performance.now();
    this.light = 0;
    this.walletCache = { light: 0, coins: 0, star_pieces: 0 };
    this.bond = {};
    this.chests = { study: 0, golden: 0 };
    this.stats = {};
    this.session = null;
    this.lock = null;
    this.timers = [];
    this.parts = [];
    this.floaters = [];
    this.bumps = {};
    this.cut = {};
    this.fadeA = 0;
    this.drainAcc = 0;
    this.flareOn = false;
    this.flareAcc = 0;
    this.menuState = null;
    this.dlg = null;
    this.hudKey = '';
    this.questCheckT = 0;
    this.guide = null;
    this.guideT = 0;
    this.talkK = 0;          // 0..1: how far the camera has pushed in for a conversation
    this.talkTo = null;      // who Wick is talking to
    this.leverState = [];
    this.worldT = 0;         // the world's clock (movers, vents, pendulums): Tick's Time Stop holds it still
    this.timeStop = 0;
    this.banner = null;      // "New place discovered!"
    this.mapScreen = new MapScreen(this);
    this.battle = new Battle(this, this.battleEl);
    this.bindInput();
    this.frame = this.frame.bind(this);
    requestAnimationFrame(this.frame);
    window.addEventListener('beforeunload', () => this.flushSave());
    this.load();
  }

  // ---------------------------------------------------------------- hub hooks
  setActive(on) {
    this.active = on;
    if (!on) { this.keys.clear(); this.saveSoon(); }
    this.last = performance.now();
  }

  onState(S) {
    this.walletCache = S.wallet;
    this.light = S.wallet.light;
    this.session = S.session;
    this.bond = S.bond || {};
    this.chests = S.chests || this.chests;
    this.stats = S.stats || {};
    if (this.s) this.syncBond();
    const s = S.session;
    const lock = s && s.mode !== 'break' ? 'focus' : s && s.overtime > 0 ? 'breakover' : null;
    if (lock !== this.lock) {
      this.lock = lock;
      this.keys.clear();
      if (lock) {
        this.saveNow();
        this.lockEl.classList.remove('hidden');
        this.lockEl.innerHTML = lock === 'focus' ? `<div class="lock-card">
            <div class="lock-big">📚</div><h2>Wick is studying with you</h2>
            <p>The adventure unlocks when you take a break or finish your focus session.</p>
            <p class="muted">You have <b id="lock-bank"></b> of break banked. Your partner is building Bond while you study!</p>
            <button class="btn gold" data-g="break">☕ Take a break and play</button></div>`
          : `<div class="lock-card"><div class="lock-big">⏰</div><h2>Break's over!</h2>
            <p>Back to work. Wick will be right here when you're done.</p>
            <button class="btn green" data-g="resume">▶ Back to work</button></div>`;
      } else {
        this.lockEl.classList.add('hidden');
      }
    }
    const bank = this.lockEl.querySelector('#lock-bank');
    if (bank && s) bank.textContent = fmt(s.break_bank);
  }

  syncBond() {
    this.s.bondSeen = this.s.bondSeen || {};
    for (const [pid, p] of Object.entries(this.s.partners)) {
      const lv = this.bondLv(pid);
      const max = PARTNERS[pid].hp + 2 * (lv - 1);
      if (p.max < max) { p.hp += max - p.max; p.max = max; }
      const seen = this.s.bondSeen[pid] || 1;
      if (lv > seen) {
        this.s.bondSeen[pid] = lv;
        sfx('levelup');
        this.tip(`💛 ${PARTNERS[pid].name}'s Bond is now Lv ${lv}! ${PARTNERS[pid].team.name} got stronger and ${PARTNERS[pid].name} gained 2 max HP.`, 10);
        this.saveSoon();
      }
    }
  }

  // ---------------------------------------------------------------- music
  // The song for what's on screen: the battle or boss theme, Count Dusk's theme while he's around, the
  // menu tune in menus and shops, otherwise the room's or the area's song. Quiet while you study or at a game over.
  musicFor() {
    if (!this.active || this.lock || !this.s || !this.room || this.gameOverNow) return null;
    const B = this.battle;
    if (B.active) return B.outcome ? null : B.opts.music || (B.opts.boss || B.enemies.some(e => e.boss) ? 'boss' : 'battle');
    if (this.cut.dusk) return 'dusk';
    if (this.mode === 'minigame') return this.mini ? this.mini.g.song : null;
    if (this.inMenu || this.mode === 'map') return 'menu';
    const R = this.room;
    if (!this.flag('prologue_done') && (R.area === 'town' || R.area === 'outskirts')) return 'night';
    return R.music || (AREAS[R.area] && AREAS[R.area].music) || null;
  }

  toggleMusic() {
    const on = !music.enabled;
    music.setEnabled(on, true);
    api('/api/settings', { music: on }).catch(() => {});
    this.tip(on ? '🎵 Music on. (M turns it off.)' : '🔇 Music off. Press M to turn it back on.', 3);
  }

  reset() {
    this.s = newSave();
    this.cut = {};
    this.closeAll();
    this.loadRoom('pro_1', 1000);
    this.mode = 'explore';
    this.saveNow();
  }

  // ---------------------------------------------------------------- queries used by scripts, quests and battles
  // saved flags, plus ones that only last while something holds them down (blue pressure plates)
  flag(f) { return !!this.s.flags[f] || !!(this.live && this.live[f]); }
  has(a) { return !!this.s.abilities[a]; }
  hasPartner(p) { return !!this.s.partners[p]; }
  broken(id) { return !!this.s.broken[id]; }
  get shards() { return this.s.shards; }
  isDown(act) { return this.keys.has(act); }
  battleItems() { return Object.entries(this.s.items).filter(([k, n]) => n > 0 && ITEMS[k]); }
  usedBp() { return this.s.badges.equipped.reduce((n, b) => n + (BADGES[b] ? BADGES[b].bp : 0), 0); }
  bondLv(pid) { return bondLevel((this.bond || {})[pid] || 0); }
  stat(name) { return (this.stats || {})[name] || 0; }
  questKnown(id) { return !!this.s.quests[id]; }
  questActive(id) { return this.s.quests[id] === 'active'; }
  questDone(id) { return this.s.quests[id] === 'done'; }
  questReady(id) { return this.questActive(id) && QUESTS[id].progress(this).done; }
  collectedCount(kind) { return Object.keys(this.s.collected).filter(k => k.startsWith(kind + '_')).length; }
  litLamps() { return Object.keys(this.s.opened).filter(k => k.startsWith('lamp_')).length; }
  noteTattle(kind) { this.s.tattled[kind] = true; }
  theme() { const R = this.room; return typeof R.theme === 'function' ? R.theme(this) : R.theme; }
  // Battles indoors use the outdoor scenery that fits (castle rooms fight in front of the castle).
  battleTheme() {
    const R = this.room;
    if (!R) return 'night';
    if (R.battleTheme) return R.battleTheme;
    if (R.interior) return ['castle', 'throne'].includes(R.style) ? 'castle' : R.style === 'den' ? 'burrow' : 'interior';
    return this.theme();
  }
  studyHint() {
    const next = STUDY_QUESTS.find(id => this.questActive(id));
    if (!next) return 'You finished every Study Challenge! The Hero of Homework is a legend.';
    const q = QUESTS[next];
    return `Next challenge, "${q.name}": ${q.progress(this).text}. Only real focus sessions count!`;
  }

  // ---------------------------------------------------------------- input
  bindInput() {
    window.addEventListener('keydown', e => {
      if (!this.active || this.lock) return;
      if (e.ctrlKey || e.metaKey) return;   // (Ctrl + and Ctrl − still zoom the window itself)
      const tag = (e.target.tagName || '').toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select') return;
      if (e.code === 'KeyM') { if (!e.repeat) this.toggleMusic(); return; }
      const act = KEYMAP[e.code];
      if (!act) return;
      e.preventDefault();
      if (e.repeat) return;
      this.keys.add(act);
      if (this.battle.active) {
        if (act === 'jump') this.battle.onPress('space');
        else if (act === 'hammer') this.battle.onPress('x');
      }
      // A press that closes a conversation or a menu is used up there, so it can't also start the
      // conversation again (or reopen the menu, or make Wick jump) on the next frame.
      if (!this.routeKey(act)) this.pressed.add(act);
    });
    window.addEventListener('keyup', e => { const act = KEYMAP[e.code]; if (act) this.keys.delete(act); });
    window.addEventListener('blur', () => this.keys.clear());
    const at = e => { const r = this.cv.getBoundingClientRect(); return [((e.clientX - r.left) / r.width) * W, ((e.clientY - r.top) / r.height) * H]; };
    this.cv.addEventListener('click', e => {
      const [x, y] = at(e);
      if (this.battle.active) this.battle.onClick(x);
      else if (this.mode === 'minigame' && this.mini && !this.lock) this.minigameClick(x, y);
      else if (this.mode === 'map') this.mapScreen.click(x, y);
      else if (this.mode === 'explore' && this.inMinimap(x, y)) this.openMap();   // (clicking the minimap opens the big map)
    });
    this.cv.addEventListener('pointermove', e => {
      const [x, y] = at(e), over = this.mode === 'explore' && this.inMinimap(x, y);
      if (over !== !!this.overMini) { this.overMini = over; this.cv.style.cursor = over ? 'pointer' : ''; }
    });
    this.cv.addEventListener('pointerdown', e => {
      if (this.mode === 'map') { const [x, y] = at(e); this.mapScreen.pointer('down', x, y); return; }
      this.minigamePointer(true);
    });
    window.addEventListener('pointermove', e => { if (this.mode === 'map') { const [x, y] = at(e); this.mapScreen.pointer('move', x, y); } });
    window.addEventListener('pointerup', e => {
      if (this.mode === 'map') { const [x, y] = at(e); this.mapScreen.pointer('up', x, y); }
      this.minigamePointer(false);
    });
    // the mouse wheel zooms the detailed map
    this.cv.addEventListener('wheel', e => {
      if (this.mode !== 'map' || !this.active) return;
      e.preventDefault();
      const [x, y] = at(e);
      this.mapScreen.wheel(x, y, e.deltaY);
    }, { passive: false });
    this.dlgEl.addEventListener('click', () => { if (this.dlg) this.advanceDialog(); });
    this.root.addEventListener('click', async e => {
      const b = e.target.closest('[data-g]');
      if (!b) return;
      if (b.dataset.g === 'break') await api('/api/session/break', {});
      if (b.dataset.g === 'resume') await api('/api/session/resume', {});
      this.hub.refresh();
    });
  }

  routeKey(act) {
    if (this.mode === 'minigame' && this.mini) { this.minigameKey(act); return true; }
    if (this.menuState) { this.menuKey(act); return true; }
    if (this.dlg) { if (act === 'jump' || act === 'act') this.advanceDialog(); return true; }
    if (this.mode === 'map') { this.mapScreen.key(act); return true; }
    if (this.battle.active) {
      const map = { jump: 'confirm', act: 'confirm', menu: 'back', hammer: 'back' };
      this.battle.onKey(map[act] || act);
      return true;
    }
    return false;
  }

  // ---------------------------------------------------------------- menus (HTML, keyboard + mouse)
  menu(el, title, items, opts = {}) {
    items = items.filter(Boolean);
    return new Promise(resolve => {
      el.classList.remove('hidden');
      el.innerHTML = `<div class="menu ${opts.battle ? 'battle' : ''}">
        ${title ? `<div class="menu-title">${title}</div>` : ''}
        ${opts.info ? `<div class="menu-info">${opts.info}</div>` : ''}
        <div class="menu-items">${items.map((it, i) => `<button class="mi${it.disabled ? ' dis' : ''}" data-i="${i}">
          <span class="ml">${it.label}</span>${it.right != null ? `<span class="mr">${it.right}</span>` : ''}</button>`).join('')}</div>
        <div class="menu-desc"></div>
        <div class="menu-keys">${opts.cancel === false ? '↑↓ choose · SPACE select' : '↑↓ choose · SPACE select · ESC back'}</div>
      </div>`;
      const st = { el, items, i: Math.max(0, items.findIndex(it => !it.disabled)), resolve, cancel: opts.cancel !== false };
      this.menuState = st;
      el.querySelectorAll('.mi').forEach(b => {
        b.addEventListener('mouseenter', () => { st.i = Number(b.dataset.i); this.menuHighlight(); });
        b.addEventListener('click', () => { if (this.menuState !== st) return; st.i = Number(b.dataset.i); this.menuChoose(); });
      });
      this.menuHighlight();
    });
  }

  menuHighlight() {
    const st = this.menuState;
    if (!st) return;
    st.el.querySelectorAll('.mi').forEach((b, i) => b.classList.toggle('sel', i === st.i));
    const it = st.items[st.i];
    const d = st.el.querySelector('.menu-desc');
    if (d) d.textContent = (it && it.desc) || '';
    const sel = st.el.querySelector('.mi.sel');
    if (sel) sel.scrollIntoView({ block: 'nearest' });
  }

  menuKey(act) {
    const st = this.menuState;
    const n = st.items.length;
    const step = d => {
      for (let k = 1; k <= n; k++) {
        const j = (st.i + d * k + n * 10) % n;
        if (!st.items[j].disabled) { st.i = j; break; }
      }
      sfx('select');
      this.menuHighlight();
    };
    if (act === 'up' || act === 'left') step(-1);
    else if (act === 'down' || act === 'right') step(1);
    else if (act === 'jump' || act === 'act') this.menuChoose();
    else if ((act === 'menu' || act === 'hammer') && st.cancel) { sfx('menu'); this.closeMenu(null); }
  }

  menuChoose() {
    const st = this.menuState;
    const it = st.items[st.i];
    if (!it || it.disabled) return;
    sfx('menu');
    this.closeMenu(it.value);
  }

  closeMenu(v) {
    const st = this.menuState;
    this.menuState = null;
    st.el.innerHTML = '';
    st.resolve(v);
  }

  closeAll() {
    if (this.menuState) this.closeMenu(null);
    this.panelEl.classList.add('hidden');
    this.panelEl.innerHTML = '';
  }

  // ---------------------------------------------------------------- dialogue, cards, tips
  say(name, text) {
    if (typeof text === 'function') text = text(this);
    return new Promise(resolve => {
      this.dlg = { name, text, shown: 0, resolve, who: name ? SPEAKERS[name] || null : null, lastBeep: 0 };
      this.dlgEl.classList.remove('hidden');
      this.dlgEl.classList.toggle('narrate', !name);
      this.dlgEl.querySelector('.dlg-name').textContent = name || '';
      this.dlgEl.querySelector('.dlg-text').textContent = '';
      this.portrait.style.display = this.dlg.who ? '' : 'none';
    });
  }

  advanceDialog() {
    const d = this.dlg;
    if (d.shown < d.text.length) { d.shown = d.text.length; this.dlgEl.querySelector('.dlg-text').textContent = d.text; return; }
    this.dlg = null;
    this.dlgEl.classList.add('hidden');
    d.resolve();
  }

  updateDialog(dt) {
    const d = this.dlg;
    if (!d) return;
    if (d.shown < d.text.length) {
      d.shown = Math.min(d.text.length, d.shown + dt * 48);
      this.dlgEl.querySelector('.dlg-text').textContent = d.text.slice(0, Math.floor(d.shown));
      if (d.who && Math.floor(d.shown / 3) !== d.lastBeep) { d.lastBeep = Math.floor(d.shown / 3); sfx('talk'); }
    }
    this.dlgEl.querySelector('.dlg-next').style.visibility = d.shown >= d.text.length ? 'visible' : 'hidden';
    if (d.who && DRAW[d.who]) {
      const pc = this.portrait.getContext('2d');
      pc.setTransform(1, 0, 0, 1, 0, 0);
      pc.clearRect(0, 0, 220, 220);
      const big = { grumblecap: 0.95, smudge: 1.1, dusk: 1.2, cindermaw: 1.05, kettle: 1.8, ...PORTRAIT_SCALE }[d.who] || 2;
      DRAW[d.who](pc, 110, d.who === 'dusk' ? 230 : 205, {
        t: this.t, scale: big, shadow: false, glasses: true, lit: true,
        mood: d.who === 'dusk' ? 'angry' : 'normal', ...(SPEAKER_OPTS[d.name] || {}),
      });
    }
  }

  wait(sec) { return new Promise(r => this.timers.push({ at: this.t + sec, r })); }
  tween(dur, fn) { const t0 = this.t; return new Promise(r => { this.timers.push({ at: t0 + dur, r, fn, t0, dur }); }); }

  async card(title, sub, secs = 2.8) {
    this.cardEl.innerHTML = `<div class="card-in"><div class="card-title">${esc(title)}</div>${sub ? `<div class="card-sub">${esc(sub)}</div>` : ''}</div>`;
    this.cardEl.classList.remove('hidden');
    sfx('fanfare');
    await this.wait(secs);
    this.cardEl.classList.add('hidden');
  }

  tip(text, secs = 7) {
    this.tipEl.textContent = text;
    this.tipEl.classList.remove('hidden');
    this.tipUntil = this.t + secs;
  }

  float(text, x, y, color = '#fffaf0', z) { this.floaters.push({ text, x, y, z: z ?? (this.p ? this.p.z : 0), t0: this.t, color }); }

  // Drops flying up where something hits water (or lava, or ink); a big one makes a sound.
  splash(x, y, z, kind, n = 8) {
    const col = kind === 'lava' ? ['#ff8a3d', '#ffe066'] : kind === 'ink' ? ['#6a5aa8', '#2a2050'] : ['#f0faff', '#8fd6f2'];
    for (let i = 0; i < n; i++) {
      this.parts.push({ x: x + (Math.random() - 0.5) * 20, y: y - 2, z, vx: (Math.random() - 0.5) * 220, vy: -120 - Math.random() * 230, life: 0.55, c: col[i % 2], g: 900 });
    }
    if (n > 4) sfx('splash');
  }

  // Landing on thorns, spikes, gears, Gloom goo or lava at the bottom of a gap: it hurts, and you pop back up in an arc
  // that lands you on the last safe ground (for most of the flight you can't steer). Hit it again before you get
  // there and you're set down on that safe ground instead.
  hazardBounce(kind, hy) {
    const P = this.p, R = this.room;
    P.hazardHits = (P.hazardHits || 0) + 1;
    const hurt = !R.gentle && this.flag('prologue_done') && this.s.hero.hp > 1 && P.invuln <= 0;
    if (hurt) this.s.hero.hp--;
    sfx('hurt');
    const word = kind === 'lava' ? 'HOT!' : kind === 'gloom' ? 'YUCK!' : kind === 'blank' ? 'BOING!' : 'OUCH!';
    const col = { lava: ['#ffb347', '#ff5a2a'], gloom: ['#8a5cc0', '#2a1a45'], gears: ['#e8c87a', '#8a6a3a'],
      spikes: ['#f4efff', '#a89fc4'], brambles: ['#5fae5c', '#2a3d24'], blank: ['#fffaf0', '#d9d1bf'] }[kind] || ['#fffaf0', '#9d97a8'];
    for (let i = 0; i < 10; i++) {
      this.parts.push({ x: P.x + (Math.random() - 0.5) * 24, y: hy - 4, z: P.z, vx: (Math.random() - 0.5) * 260, vy: -160 - Math.random() * 260, life: 0.6, c: col[i % 2], g: 900 });
    }
    this.float(hurt ? `-1 ♥  ${word}` : word, P.x, hy - 80, '#ff9ab0');
    if (P.hazardHits > 1) {
      Object.assign(P, { x: P.safe.x, y: P.safe.y, z: P.safe.z ?? P.z, vx: 0, vy: 0, vz: 0, knockT: 0, invuln: 1.2, hazardHits: 0 });
      return;
    }
    // how long until it comes back down to the safe ground's height: hy - V t + (GRAV / 2) t² = safe.y
    const a = GRAV / 2, drop = hy - P.safe.y;
    const air = (BOUNCE_V + Math.sqrt(Math.max(0, BOUNCE_V * BOUNCE_V - 4 * a * drop))) / (2 * a);
    Object.assign(P, { y: hy, vy: -BOUNCE_V, onGround: false, cut: true, gliding: false, sq: 1.32, invuln: Math.max(P.invuln, 1.1),
      vx: clamp((P.safe.x - P.x) / air, -760, 760), vz: this.field ? clamp(((P.safe.z ?? P.z) - P.z) / air, -520, 520) : 0, knockT: air * 0.8 });
    if (Math.abs(P.vx) > 40) P.facing = Math.sign(P.vx);
  }

  dust(x, y, n = 4, dir = 0, z) {
    // (no z means Wick's own dust: it has to start at his depth, or for a frame it's drawn at the very front,
    // a white dot at the bottom of the screen in the big fields)
    z = z ?? (this.p ? this.p.z : 0);
    for (let i = 0; i < n; i++) {
      this.parts.push({ x: x + (Math.random() - 0.5) * 16, y: y - 4, z, vx: (Math.random() - 0.5) * 80 - dir * 60, vy: -30 - Math.random() * 50,
        life: 0.45, g: -40, dust: true, r: 4 + Math.random() * 4 });
    }
  }

  // ---------------------------------------------------------------- loading & saving
  async load() {
    let data = null;
    try { data = (await api('/api/adventure')).data; } catch (e) { /* first run */ }
    const base = newSave();
    const s = data ? { ...base, ...data } : base;
    for (const k of ['hero', 'badges']) s[k] = { ...base[k], ...(s[k] || {}) };
    for (const k of ['quests', 'kills', 'tattled', 'revealed', 'collected', 'areaLamps', 'seenAreas', 'opened', 'broken', 'flags', 'items', 'partners',
      'stickers', 'peeled', 'stuck', 'crates', 'rescued', 'patched']) s[k] = s[k] || {};
    s.confetti = s.confetti || 0;
    s.keyItems = s.keyItems || [];
    s.training = s.training || {};
    s.palAtk = s.palAtk || 0;
    if (s.room === 'TOWN' || !ROOMS[s.room]) { s.room = 'pro_1'; s.x = 1220; }
    s.v = 2;
    // places you've clearly already been count as discovered for fast travel
    if (s.flags.prologue_done) Object.assign(s.seenAreas, { town: true, outskirts: true });
    if (s.flags.hoot_asked || s.flags.ch1_done) Object.assign(s.seenAreas, { grove: true, fields: true });
    if (s.flags.ch2_done || s.partners.pebble) Object.assign(s.seenAreas, { caves: true, mountain: true });
    if (!data || !data.visited) s.visited = this.guessVisited(s);
    this.s = s;
    this.syncBond();
    this.loadRoom(s.room, s.x, s.z);
    this.mode = 'explore';
  }

  // Saves from before the map remembered places: count every room you've clearly been in.
  guessVisited(s) {
    const v = {};
    const story = {
      prologue_done: ['pro_1', 'pro_2', 'pro_3'], hoot_asked: ['fields_1', 'grove_1', 'grove_2', 'grove_3'],
      ch1_done: ['grove_4', 'grove_5', 'grove_throne'], ch2_done: ['mtn_1', 'cave_1', 'cave_2', 'cave_3', 'cave_4', 'cave_5', 'cave_studio'],
      ch3_done: ['peak_1', 'peak_2', 'peak_3', 'peak_4', 'peak_5', 'peak_crater'], koi_caught: ['lake_1'], beast_down: ['maze_1'],
    };
    for (const [f, ids] of Object.entries(story)) if (s.flags[f]) for (const id of ids) v[id] = true;
    for (const [id, R] of Object.entries(ROOMS)) {
      const ids = [...(R.chests || []), ...(R.blocks || []), ...(R.collect || []), ...(R.cracks || []), ...(R.boulders || [])].map(o => o.id);
      if (ids.some(k => s.opened[k] || s.collected[k] || s.broken[k]) || (R.lamps || []).some(l => s.opened[`lamp_${id}_${typeof l === 'number' ? l : l.x}`])) v[id] = true;
    }
    for (const [area, seen] of Object.entries(s.seenAreas)) if (seen && AREAS[area] && AREAS[area].start) v[AREAS[area].start] = true;
    v[s.room] = true;
    return v;
  }

  saveSoon() { clearTimeout(this.saveTimer); this.saveTimer = setTimeout(() => this.saveNow(), 700); }
  saveNow() {
    if (!this.s) return;
    if (this.p && this.room) { this.s.x = Math.round(this.p.safe.x); this.s.z = Math.round(this.p.safe.z || 0); }
    api('/api/adventure', { data: this.s }).catch(() => {});
  }
  flushSave() {
    if (!this.s) return;
    try { navigator.sendBeacon('/api/adventure', JSON.stringify({ data: this.s })); } catch (e) { /* ignore */ }
  }

  // ---------------------------------------------------------------- rooms
  // The floor height at x (and at depth z, which matters in the big fields with hills, ledges and ponds).
  surfaceAt(x, z) {
    if (z != null && this.rects) { const y = this.floorAt(x, z); if (y != null) return y; }
    let best = null;
    for (const g of this.room.ground) if (x >= g[0] && x <= g[1]) best = best == null ? g[2] : Math.min(best, g[2]);
    return best ?? 450;
  }

  // The highest floor or raised ground right at (x, z), or null over water or a pit.
  floorAt(x, z) {
    let best = null;
    for (const r of this.rects) if (x >= r.x0 && x <= r.x1 && z >= r.z0 && z <= r.z1 && (best == null || r.y < best)) best = r.y;
    for (const t of this.terrainBoxes) if (x >= t.x0 && x <= t.x1 && z >= t.z0 && z <= t.z1 && (best == null || t.y < best)) best = t.y;
    return best;
  }

  // The floor plan: one rectangle per stretch of floor, split around the holes (ponds, rivers, pits) of the big fields.
  groundRects(R) {
    const zf = GZ0, zb = this.zb, holes = R.holes || [], out = [];
    for (const [x0, x1, y] of R.ground) {
      const xs = [x0, x1];
      for (const h of holes) for (const hx of [h[0], h[1]]) if (hx > x0 && hx < x1) xs.push(hx);
      xs.sort((a, b) => a - b);
      for (let i = 0; i < xs.length - 1; i++) {
        const a = xs[i], b = xs[i + 1];
        if (b - a < 0.5) continue;
        const cuts = holes.filter(h => h[0] <= a && h[1] >= b).map(h => [Math.max(zf, h[2]), Math.min(zb, h[3])]).sort((p, q) => p[0] - q[0]);
        let z = zf;
        for (const [h0, h1] of cuts) { if (h0 > z) out.push({ x0: a, x1: b, z0: z, z1: h0, y }); z = Math.max(z, h1); }
        if (z < zb) out.push({ x0: a, x1: b, z0: z, z1: zb, y });
      }
    }
    // join neighbors that line up again, so the floor isn't cut into needless strips
    out.sort((p, q) => p.z0 - q.z0 || p.z1 - q.z1 || p.y - q.y || p.x0 - q.x0);
    const merged = [];
    for (const r of out) {
      const m = merged[merged.length - 1];
      if (m && m.z0 === r.z0 && m.z1 === r.z1 && m.y === r.y && Math.abs(m.x1 - r.x0) < 0.5) m.x1 = r.x1;
      else merged.push({ ...r });
    }
    // shallow water (in a room you can wade through) has a bed just under the surface, one walkable step down from the
    // bank, so you walk in and out; deep water (holes marked 'deep', and rooms that don't wade) has none, and in you fall
    if (R.wade && R.hazard === 'water') {
      for (const h of holes) {
        if (h[4] === 'deep') continue;
        for (const [x0, x1, y] of R.ground) {
          const a = Math.max(x0, h[0]), b = Math.min(x1, h[1]);
          if (b - a > 0.5) merged.push({ x0: a, x1: b, z0: Math.max(zf, h[2]), z1: Math.min(zb, h[3]), y: y + WADE, water: true });
        }
      }
    }
    return merged;
  }

  // The water's surface where (x, z) is over water (shallow or deep), lava or ink, else null.
  liquidAt(x, z) {
    const R = this.room;
    if (!['water', 'lava', 'ink'].includes(R.hazard)) return null;
    for (const t of this.terrainBoxes) if (x >= t.x0 && x <= t.x1 && z >= t.z0 && z <= t.z1) return null;   // an island
    for (const r of this.rects) if (x >= r.x0 && x <= r.x1 && z >= r.z0 && z <= r.z1) return r.water ? R.hazardY ?? 500 : null;
    return R.hazardY ?? 500;
  }

  // The old puzzle walls of a room that became a big field (cracks, low rocks, gates, boulders, vine walls) only fill
  // the old strip along the front, with a tall ridge carrying on behind each so there's no way around:
  // [x0, x1, top, solved, kind]. Solving one (smashing, burning, opening it, or learning to roll under it) only opens
  // the way through where the puzzle was: the ridge and any wall above stay just as tall (the user saw them shrink
  // or vanish as a glitch, at Mothwick's shed and again on Ember Road), so it's a doorway through the wall.
  puzzleSpans(R) {
    const out = [];
    for (const k of R.cracks || []) if (k.z0 == null) out.push([k.x, k.x + k.w, k.y, this.broken(k.id), 'crack', k]);
    for (const [x, w, z0] of R.low || []) if (z0 == null) out.push([x, x + w, -40, this.has('roll')]);
    for (const g of R.gates || []) if (g.z0 == null) out.push([g.x - 10, g.x + g.w + 10, -40, this.flag(g.flag)]);
    for (const b of R.boulders || []) if (b.solid && b.z0 == null) out.push([b.solid[0], b.solid[0] + b.solid[2], b.solid[1], this.broken(b.id)]);
    for (const v of R.vines || []) if (v.solid !== false && v.z0 == null) out.push([v.x, v.x + v.w, Math.max(-40, v.y), this.broken(v.id)]);
    // a plain wall right above one of them is part of it
    for (const s of out) for (const w of R.walls || []) if (w[4] == null && w[0] < s[1] - 1 && w[0] + w[2] > s[0] + 1) s[2] = Math.max(-40, Math.min(s[2], w[1]));
    // ...except over a cracked wall in a field: that's one wall of CRACK_H (see crackBox)
    for (const s of out) if (s[4] === 'crack') s[2] = this.crackBox(s[5], R).y;
    return out;
  }

  // Where a cracked wall stands: in a big field it's CRACK_H tall from its foot (or the old height near a spring or
  // steam vent), in the old narrow rooms just as the room says.
  crackBox(k, R = this.room) {
    if (!this.field || k.z0 != null) return { y: k.y, h: k.h };
    const bottom = k.y + k.h, launch = [...(R.springs || []), ...(R.vents || [])].some(s => Math.abs(s.x - (k.x + k.w / 2)) < 600);
    const h = launch ? bottom + 40 : Math.max(k.h, CRACK_H);
    return { y: bottom - h, h };
  }

  // A plain wall over a field's cracked wall isn't there at all (the cracked wall is the whole thing).
  overCrack(x0, x1) { return this.field && this.spans.some(([a, b, , , kind]) => kind === 'crack' && x0 < b - 1 && x1 > a + 1); }

  // How far into the distance a wall-like thing reaches: what the room says (z0/z1); in a big field the old front
  // strip for a puzzle wall, or the whole way back for any other wall; and in the old narrow rooms no depth at all.
  wallZ(z0, z1, x0, x1) {
    if (z0 != null) return { z0, z1: z1 ?? this.zb, big: true, wall3d: true };
    if (!this.field) return {};
    const puzzle = this.spans.some(([a, b]) => x0 < b - 1 && x1 > a + 1);
    return { z0: GZ0, z1: puzzle ? RIDGE_Z : this.zb, big: true, wall3d: true };
  }

  // Scenery across a big field, kept clear of water, ledges, roads, doors and everyone standing around.
  fieldDecor(id) {
    const R = this.room, busy = [];
    for (const k of ['doors', 'signs', 'npcs', 'shops', 'boards', 'shrines', 'chests', 'slots', 'peels', 'folks', 'tears', 'piles', 'bombplants',
      'crates', 'resets', 'plates', 'springs', 'camp', 'bushes', 'pots', 'collect', 'decor', 'fish', 'furniture']) {
      for (const o of R[k] || []) busy.push([o.x, k === 'doors' ? this.doorZ(o) : o.z ?? 0, k === 'camp' ? 120 : k === 'doors' ? 130 : 70]);
    }
    for (const p of R.props || []) busy.push([p.x, p.z ?? 0, 180]);
    for (const s of this.exitSigns || []) if (s.x != null) busy.push([s.x, s.z, 140]);   // (the signpost at a way out, in plain view)
    if (R.boss) busy.push([R.boss.x, R.boss.z ?? Z_DEFAULT.boss, 200]);
    for (const l of this.lampList()) busy.push([l.x, l.z, 70]);
    for (const e of R.enemies || []) busy.push([e.x, e.z ?? 0, 60]);
    for (const xp of R.xplats || []) busy.push([(xp.x + (xp.x1 ?? xp.x + xp.w)) / 2, ((xp.z0 ?? 0) + (xp.z1 ?? 0)) / 2, 160]);
    const exitRoads = (this.exitSigns || []).map(s => this.exitRoad(s));
    const nearRoad = (x, z) => [...(R.roads || []), ...exitRoads].some(([x0, z0, x1, z1, w = 90]) => {
      const dx = x1 - x0, dz = z1 - z0, q = clamp(((x - x0) * dx + (z - z0) * dz) / (dx * dx + dz * dz || 1), 0, 1);
      return Math.hypot(x - (x0 + dx * q), z - (z0 + dz * q)) < w / 2 + 40;
    });
    const inBox = (x, z, b, pad) => x > b[0] - pad && x < b[1] + pad && z > b[2] - pad && z < b[3] + pad;
    // walls, cracks, gates and the rest (and the ridges behind them) run into the distance here: keep a clear lane along each
    const lanes = [...(R.walls || []).map(w => [w[0], w[0] + w[2], w[4] ?? -1e9, w[5] ?? 1e9]), ...(R.cracks || []).map(k => [k.x, k.x + k.w]),
      ...(R.low || []).map(([x, w]) => [x, x + w]), ...(R.gates || []).map(g => [g.x - 10, g.x + g.w + 10]),
      ...(R.boulders || []).filter(b => b.solid).map(b => [b.solid[0], b.solid[0] + b.solid[2]]), ...(R.vines || []).filter(v => v.solid !== false).map(v => [v.x, v.x + v.w])];
    const free = (x, z, kind, edge) => {
      if (lanes.some(([a, b, z0 = -1e9, z1 = 1e9]) => x > a - 40 && x < b + 40 && z > z0 - 40 && z < z1 + 40)) return false;
      for (const q of R.plazas || []) if (inBox(x, z, q, 30)) return false;
      for (const q of R.clear || []) if (inBox(x, z, q, 0)) return false;   // places a room keeps clear (a town's main street)
      for (const h of R.holes || []) if (inBox(x, z, h, edge ? 10 : 40)) return false;
      for (const t of R.terrain || []) if (inBox(x, z, [t.x0, t.x1, t.z0, t.z1], 30)) return false;
      for (const hg of R.hedges || []) if (inBox(x, z, [hg.x, hg.x + hg.w, hg.z0, hg.z1], 30)) return false;
      for (const b of R.barriers || []) if (inBox(x, z, [b.x, b.x + b.w, b.z0 ?? GZ0, b.z1 ?? this.zb], 40)) return false;
      if (busy.some(([bx, bz, r]) => Math.abs(bx - x) < r && Math.abs(bz - z) < r * 0.8)) return false;
      if (nearRoad(x, z)) return false;
      if (edge) for (const [side, ex] of [['left', 0], ['right', R.w]]) {
        const e = (R.exits || {})[side];
        if (e && Math.abs(x - ex) < 120 && z >= (e.z0 ?? -1e9) - 120 && z <= (e.z1 ?? 1e9) + 120) return false;
      }
      return this.floorAt(x, z) != null;
    };
    return fieldDecorFor(R, id, this.theme(), this.zb, free).map(d => ({ ...d, y: this.surfaceAt(d.x, d.z) }));
  }

  // Gold chevrons painted on the ground at every way out of the left or right edge, rippling toward the edge, plus
  // the next place's name when Wick gets close (if there's no signpost saying so already). Grey with a lock if it's
  // not open yet.
  drawExitArrows(c, V, t) {
    const R = this.room, P = this.p;
    for (const side of ['left', 'right']) {
      const e = (R.exits || {})[side];
      if (!e || !ROOMS[e.to]) continue;
      const dir = side === 'left' ? -1 : 1, edge = side === 'left' ? 0 : R.w, z = e.z0 != null ? 100 : 30;
      const locked = !!(e.need && !this.flag(e.need)), near = Math.abs(P.x - edge) < 460;
      for (let i = 0; i < 3; i++) {
        const x = edge - dir * (70 + i * 46), fy = this.floorAt(x, z);
        if (fy == null) continue;
        const pulse = locked ? 0.35 : 0.35 + 0.65 * Math.max(0, Math.sin(t * 4 - i * 0.9));
        atDepth(c, V, x, fy, z, () => {
          c.save(); c.scale(dir, 0.42);
          c.fillStyle = locked ? `rgba(160,150,180,${pulse})` : `rgba(255,214,90,${pulse})`;
          c.strokeStyle = `rgba(43,34,53,${0.5 * pulse})`; c.lineWidth = 2;
          c.beginPath(); c.moveTo(-12, -26); c.lineTo(14, 0); c.lineTo(-12, 26); c.lineTo(-24, 26); c.lineTo(2, 0); c.lineTo(-24, -26); c.closePath();
          c.fill(); c.stroke(); c.restore();
        });
      }
      const sign = (this.exitSigns || []).find(s => s.side === side && s.x != null);
      if (!near || sign) continue;
      const lx = edge - dir * 120, fy = this.floorAt(lx, z) ?? this.floorAt(edge - dir * 70, z);
      if (fy == null) continue;
      atDepth(c, V, lx, fy - 70, z, () => {
        const text = `${side === 'left' ? '← ' : ''}${locked ? '🔒 ' : ''}${ROOMS[e.to].name}${side === 'right' ? ' →' : ''}`;
        c.font = 'bold 15px Fredoka, sans-serif'; c.textAlign = 'center';
        const w = c.measureText(text).width + 22;
        c.fillStyle = 'rgba(43,34,53,0.78)'; c.beginPath(); c.roundRect(-w / 2, -14, w, 26, 13); c.fill();
        c.fillStyle = locked ? '#cfc6e6' : '#ffe066'; c.fillText(text, 0, 5);
      });
    }
  }

  // The bit of road off a big field's side edge, by its signpost: [x0, z0, x1, z1, width].
  exitRoad(s) { return s.side === 'left' ? [0, 100, 320, 100, 110] : [this.room.w - 320, 100, this.room.w, 100, 110]; }

  // Lampposts: a list of x positions, or { x, z } in the big fields.
  lampList() { return (this.room.lamps || []).map(l => (typeof l === 'number' ? { x: l, z: Z_DEFAULT.lamp } : { x: l.x, z: l.z ?? Z_DEFAULT.lamp })); }

  loadRoom(id, x, z) {
    if (id === 'TOWN') { id = 'pro_1'; x = 1220; }
    const R = ROOMS[id];
    this.room = R;
    this.roomId = id;
    this.s.room = id;
    this.panelEl.classList.add('hidden');
    // big open fields reach far into the distance, and the camera follows you there
    this.zb = R.z1 ?? GZ1;
    this.field = this.zb > GZ1 + 1;
    this.zmin = ZMIN;
    this.zmax = this.field ? this.zb - 30 : ZMAX;
    this.rects = this.groundRects(R);
    this.landRects = this.rects.filter(r => !r.water);   // (a shallow pond's bed is under the water, not drawn)
    // raised ground, with natural ramps broken into their steps
    this.terrainBoxes = (R.terrain || []).flatMap(t => t.steps || [t]);
    this.spans = this.field ? this.puzzleSpans(R) : [];
    // in a big field only the front stretch of a side edge leads anywhere, and past the edge the land just drops
    // away: a signpost (and a bit of road) at each way out shows it's there
    this.exitSigns = [];
    if (this.field) {
      // (it stands in the first clear spot near the edge: not on top of a chest, lamp, door, sign or house)
      const taken = [];
      const near = (x, z, r) => taken.push([x, z, r]);
      for (const k of ['signs', 'npcs', 'chests', 'shops', 'boards', 'bushes', 'pots', 'furniture', 'shrines']) {
        for (const o of R[k] || []) near(o.x, ['signs', 'boards', 'shrines'].includes(k) ? this.thingZ(o, k.slice(0, -1)) : o.z ?? 0, 80);
      }
      for (const d of R.doors || []) { near(d.x, this.doorZ(d), 95); if (d.style === 'front') near(d.x + 74, -6, 80); }
      for (const l of this.lampList()) near(l.x, l.z, 80);
      for (const p of R.props || []) { const f = PROP_FOOT[p.kind]; near(p.x, p.z ?? PROP_Z[p.kind] ?? 0, (f ? f[0] : 100) + 60); }
      for (const side of ['left', 'right']) {
        const e = (R.exits || {})[side];
        if (!e || e.z0 == null || !ROOMS[e.to]) continue;
        let spot = null;
        for (const off of [100, 150, 205, 265, 330]) {
          const sx = side === 'left' ? off : R.w - off;
          const sz = [-20, 50].find(zz => this.floorAt(sx, zz) != null && taken.every(([x, z, r]) => Math.abs(x - sx) > r || Math.abs(z - zz) > 90));
          if (sz != null) { spot = [sx, sz]; break; }
        }
        // (every way out gets its bit of road; the signpost only where there's room for it)
        this.exitSigns.push({ side, e, x: spot ? spot[0] : null, z: spot ? spot[1] : null, label: ROOMS[e.to].name });
      }
    }
    x = clamp(x ?? 120, 20, R.w - 20);
    z = clamp(z ?? 0, this.zmin, this.zmax);
    if (this.floorAt(x, z) == null) { x = R.ground[0][0] + 60; z = clamp(z, this.zmin, 200); }
    const surf = this.surfaceAt(x, z);
    const face = x > R.w / 2 ? -1 : 1;
    this.p = { x, y: surf, z, vx: 0, vy: 0, vz: 0, facing: face, flip: face, onGround: true, onPlat: false, coyote: 0, jumpBuf: 0,
      invuln: 0.6, quietInv: 0.6, hammerT: 0, swingDone: true, safe: { x, y: surf, z }, phase: 0, cut: false, gliding: false,
      sq: 1, dustT: 0, h: PH, rolled: false, rollA: 0 };
    this.cleared = new Set();
    this.springAnim = {};
    this.fireball = null;
    this.brazierLit = [];
    this.brazierFlashT = -9;
    this.moverPos = [];
    this.cut.panic = null;
    // floating platforms reach a little way into the distance; ones over a pit are bridges across the old floor strip
    this.staticPlats = this.platList(R);   // (with any bridges Doodle has sketched in: margin_play.js)
    // does the floor have any gaps (from the left edge all the way to the right, or ponds and rivers in a field)?
    let reach = 0;
    this.hasPit = !!(R.holes && R.holes.length);
    for (const g of [...R.ground].sort((a, b) => a[0] - b[0])) { if (g[0] > reach + 1) this.hasPit = true; reach = Math.max(reach, g[1]); }
    if (reach < R.w - 1) this.hasPit = true;
    this.decor = this.field ? this.fieldDecor(id) : null;
    this.updateMovers();
    this.initMechanics();
    this.buildSolids();
    this.unstick();
    this.enemies = (R.enemies || []).map(e => {
      const d = ENEMY_H[e.kind] || 40;
      let ez = e.z ?? Math.round(-40 + hashStr(e.id) * 140);
      const baseY = e.y ?? this.surfaceAt(e.x, ez);
      // never start inside a hedge or a table
      for (const z0 of [ez, ez - 50, ez + 50, ez - 100, ez + 100, 0, 120]) {
        const tryZ = clamp(z0, this.zmin, this.zmax);
        if (this.enemyFree({ y: baseY }, e.x, tryZ)) { ez = tryZ; break; }
      }
      return { ...e, home: e.x, homeZ: ez, z: ez, dir: -1, range: e.range || 120, t: Math.random() * 5, fly: !!FLYERS[e.kind], baseY, homeY: baseY,
        y: baseY, h: d, dead: false, stun: 0, flip: -1, ai: 'patrol', aiT: 0 };
    });
    this.camX = clamp(x - W / 2, 0, Math.max(0, R.w - W));
    this.camZ = this.field ? clamp(z - CAMZ_OFF, 0, this.zb - 640) : 0;
    this.trail = [];
    this.fired = new Set();
    this.parts = [];
    this.floaters = [];
    this.partnerPos = { x: x - face * 46, y: surf, z: this.p.z };
    this.lastPP = { x: this.partnerPos.x, z: this.partnerPos.z };
    this.partnerSq = 1;
    this.partnerFlip = face;
    this.npcFlip = {};
    this.leverState = [];
    this.talkTo = null;
    this.s.seenAreas[R.area] = true;
    this.s.visited = this.s.visited || {};
    if (!this.s.visited[id]) {
      this.s.visited[id] = true;
      // finding somewhere new is worth a little something
      if (this.flag('prologue_done')) {
        this.banner = { text: `📍 New place: ${R.name}`, t0: this.t };
        this.addCoins(2);
        sfx('chime');
      }
    }
    updateGuide(this);
    this.saveSoon();
  }

  buildSolids() {
    const R = this.room, out = [];
    this.solidsGen = (this.solidsGen || 0) + 1;   // (the minimap redraws its picture of the place when this changes)
    this.spans = this.field ? this.puzzleSpans(R) : [];   // (a puzzle wall may have just been solved)
    // something standing on whatever ground is at (x, z): [half width, half depth, height]
    const foot = (x, z, [hw, hd, h], type = 'wall', y = this.surfaceAt(x, z)) => out.push({ x: x - hw, y: y - h, w: hw * 2, h, z0: z - hd, z1: z + hd, type });
    // the floor (stretches that reach front to back have no depth range, like in the old rooms; a shallow pond's bed is water)
    for (const r of this.rects) {
      const full = r.z0 <= GZ0 + 0.5 && r.z1 >= this.zb - 0.5;
      out.push({ x: r.x0, y: r.y, w: r.x1 - r.x0, h: H + 300 - r.y, type: 'ground', floor: true, ...(r.water ? { water: true } : {}), ...(full ? {} : { z0: r.z0, z1: r.z1 }) });
    }
    // hills, ledges, cliffs and islands
    for (const t of this.terrainBoxes) out.push({ x: t.x0, y: t.y, w: t.x1 - t.x0, h: (t.base ?? 450) - t.y, z0: t.z0, z1: t.z1, type: 'ground', big: true, ref: t });
    // trees and rocks scattered across a field (and the tree line along its edges)
    for (const d of this.decor || []) {
      const f = DECOR_FOOT[d.kind];
      if (f) out.push({ x: d.x - f[0] * d.k, y: d.y - f[2] * d.k, w: f[0] * 2 * d.k, h: f[2] * d.k, z0: d.z - f[1], z1: d.z + f[1], type: 'wall' });
    }
    // (and the fountains, stalls and such a room places itself)
    for (const d of R.decor || []) {
      const f = DECOR_FOOT[d.kind], k = d.k || 1, dz = d.z ?? 0;
      if (f) out.push({ x: d.x - f[0] * k, y: this.surfaceAt(d.x, dz) - f[2] * k, w: f[0] * 2 * k, h: f[2] * k, z0: dz - f[1], z1: dz + f[1], type: 'wall' });
    }
    for (const w of R.walls || []) {
      if (w[4] == null && this.overCrack(w[0], w[0] + w[2])) continue;
      out.push({ x: w[0], y: w[1], w: w[2], h: w[3], type: 'wall', ...this.wallZ(w[4], w[5], w[0], w[0] + w[2]) });
    }
    for (const k of R.cracks || []) {
      if (this.broken(k.id)) continue;
      const box = this.crackBox(k);
      out.push({ x: k.x, y: box.y, w: k.w, h: box.h, type: 'crack', ref: k, ...this.wallZ(k.z0, k.z1, k.x, k.x + k.w) });
    }
    // behind the old puzzle walls of a big field, a tall ridge: there's no walking around them (solved or not, it
    // stays as tall as the wall: only the puzzle part opens up)
    for (const [a, b, top] of this.spans) {
      const fy = this.groundLevelAt((a + b) / 2, RIDGE_Z + 30) ?? 450;
      out.push({ x: a, y: top, w: b - a, h: fy - top, z0: RIDGE_Z, z1: this.zb, type: 'wall', big: true, wall3d: true, ridge: true });
    }
    for (const b of R.blocks || []) {
      const bz = b.z ?? 0;
      if (!b.hidden || this.s.revealed[b.id]) out.push({ x: b.x, y: b.y, w: 44, h: 44, z0: bz - 24, z1: bz + 24, type: 'block', ref: b });
    }
    // things standing on the floor that you walk around (or jump onto): furniture, buildings, the windmill, hedges
    for (const f of R.furniture || []) {
      const ft = FURN_FOOT[f.kind];
      if (!ft) continue;
      const fz = f.z ?? FURN_Z[f.kind] ?? 60, fy = this.surfaceAt(f.x, fz);
      out.push({ x: f.x - ft[0], y: fy - ft[2], w: ft[0] * 2, h: ft[2], z0: fz - ft[1], z1: fz + ft[1], type: 'furn', ref: f });
    }
    for (const pr of R.props || []) {
      const py = this.surfaceAt(pr.x, pr.z);
      if (pr.kind === 'building' || pr.kind === 'house') {
        const w = pr.w || (pr.kind === 'house' ? 180 : 170), h = pr.h || (pr.kind === 'house' ? 120 : 140);
        // (in a big field you can walk all around a house, so its side walls need the care a hill's get; hill: the one
        // it stands on, if any, like the Observatory's)
        const pz = pr.z ?? BZ0, hill = this.terrainBoxes.find(t => pr.x >= t.x0 && pr.x <= t.x1 && pz >= t.z0 && pz <= t.z1);
        out.push({ x: pr.x - w / 2, y: py - h, w, h, z0: pz, z1: pr.z != null ? pr.z + (pr.depth || 130) : GZ1 + 40, type: 'wall', big: this.field, ...(hill ? { hill } : {}) });
      } else if (PROP_FOOT[pr.kind]) {
        const [hw, hd, h, z0] = PROP_FOOT[pr.kind], z = pr.z ?? z0;
        out.push({ x: pr.x - hw, y: py - h, w: hw * 2, h, z0: z - hd, z1: z + hd, type: 'wall' });
      }
    }
    for (const hg of R.hedges || []) {
      const hy = this.surfaceAt(hg.x + hg.w / 2, (hg.z0 + hg.z1) / 2);
      out.push({ x: hg.x, y: hy - (hg.h || 100), w: hg.w, h: hg.h || 100, z0: hg.z0, z1: hg.z1, type: 'wall', big: true });
    }
    for (const b of R.boulders || []) {
      if (b.solid && !this.broken(b.id)) out.push({ x: b.solid[0], y: b.solid[1], w: b.solid[2], h: b.solid[3], type: 'boulder', ref: b, ...this.wallZ(b.z0, b.z1, b.solid[0], b.solid[0] + b.solid[2]) });
    }
    for (const [x, w, z0, z1] of R.low || []) {
      const top = this.surfaceAt(x + w / 2) - LOW_GAP;
      out.push({ x, y: -200, w, h: top + 200, type: 'wall', under: true, ...this.wallZ(z0, z1, x, x + w) });
    }
    for (const g of R.gates || []) {
      const gz = this.wallZ(g.z0, g.z1, g.x - 10, g.x + g.w + 10);
      out.push({ x: g.x - 10, y: -200, w: g.w + 20, h: g.top + 200, type: 'wall', under: true, ...gz });
      if (!this.flag(g.flag)) out.push({ x: g.x, y: g.top, w: g.w, h: this.surfaceAt(g.x) - g.top, type: 'gate', ref: g, ...gz });
    }
    for (const v of R.vines || []) if (v.solid !== false && !this.broken(v.id)) out.push({ x: v.x, y: v.y, w: v.w, h: v.h, type: 'vine', ref: v, ...this.wallZ(v.z0, v.z1, v.x, v.x + v.w) });
    // lampposts, signs, quest boards, shrines and braziers are in the way too, and chests (you can hop onto those)
    for (const l of this.lampList()) foot(l.x, l.z, [7, 6, 110]);
    for (const s of R.signs || []) foot(s.x, this.thingZ(s, 'sign'), [22, 5, 58]);
    for (const b of R.boards || []) foot(b.x, this.thingZ(b, 'board'), [40, 8, 96]);
    for (const sh of R.shrines || []) foot(sh.x, this.thingZ(sh, 'shrine'), [32, 14, 104]);
    for (const b of R.braziers || []) foot(b.x, this.thingZ(b, 'brazier'), [18, 12, 68]);
    for (const ch of R.chests || []) if (!ch.needBroken || this.broken(ch.needBroken)) foot(ch.x, ch.z ?? 0, [22, 14, 36], 'furn', ch.y ?? this.surfaceAt(ch.x, ch.z ?? 0));
    // a boulder in front of a door or a chest, and a magic seal over a door, block the way until they're gone
    for (const b of R.boulders || []) {
      if (b.solid || this.broken(b.id)) continue;
      const d = (R.doors || []).find(dd => dd.needBroken === b.id), ch = (R.chests || []).find(cc => cc.needBroken === b.id);
      foot(b.x, d ? this.doorZ(d) - 10 : ch ? (ch.z ?? 0) : 0, [58, 26, 150]);
    }
    for (const sl of R.seals || []) {
      if (this.broken(sl.id)) continue;
      const d = (R.doors || []).find(dd => dd.needSeal === sl.id);
      foot(sl.x, d ? this.doorZ(d) - 6 : 0, [42, 8, 130]);
    }
    // the signpost beside a path that leads off the front
    for (const d of R.doors || []) if (d.style === 'front') foot(d.x + 74, -6, [6, 5, 100]);
    for (const s of this.exitSigns || []) if (s.x != null) foot(s.x, s.z, [6, 5, 100]);   // (and beside a big field's way out)
    if (this.field) {
      // a path's archway or a doorway standing out in a big field: you walk between its posts, not through them
      for (const d of R.doors || []) {
        if (d.exit || (d.style && d.style !== 'back')) continue;
        const back = d.style === 'back', z = back ? this.doorZ(d) + 2 : (d.z ?? GZ1) - 10, [a, b] = back ? [32, 42] : [44, 58];
        for (const side of [-1, 1]) foot(d.x + side * (a + b) / 2, z, [(b - a) / 2, 6, 150]);
      }
      // and folks standing around (in the old narrow rooms they'd stand right in the path)
      for (const n of R.npcs || []) {
        if ((n.show && !n.show(this)) || n.y != null) continue;
        const k = (n.opts && n.opts.scale) || 1;
        foot(n.x, n.z ?? 0, [14 * k, 10, 64 * k]);
      }
    }
    this.mechSolids(out);
    this.solids = out;
  }

  plats() {
    const R = this.room;
    const list = [...(this.staticPlats || [])];
    // stone rafts and hidden platforms cross the old floor strip along the front, even in a big field
    if (R.hidden && this.flareOn) for (const p of R.hidden) list.push({ x: p[0], y: p[1], w: p[2], hidden: true, z0: p[3] ?? GZ0 + 10, z1: p[4] ?? GZ1 - 10 });
    (R.movers || []).forEach((m, i) => { const mp = this.moverPos[i]; if (mp) list.push({ x: mp.x, y: mp.y, w: m.w, mover: i, z0: m.z0 ?? GZ0 + 10, z1: m.z1 ?? GZ1 - 10 }); });
    if (R.xplats) list.push(...this.xplatList());
    return list;
  }

  // Never start a room inside a table or a hedge: step out in front of it.
  unstick() {
    const P = this.p;
    for (let i = 0; i < 6; i++) {
      const s = this.solids.find(o => o.z0 != null && overlap(this.pbox(), o));
      if (!s) return;
      P.z = s.z0 - PZ / 2 - 1 >= this.zmin ? s.z0 - PZ / 2 - 1 : s.z1 + PZ / 2 + 1;
    }
  }

  // Stone rafts drift along a smooth back-and-forth path; whoever stands on one rides along.
  updateMovers() {
    const R = this.room;
    if (!R.movers) return;
    R.movers.forEach((m, i) => {
      const k = 0.5 - 0.5 * Math.cos((this.worldT / (m.period || 4)) * Math.PI * 2 + (m.phase || 0));
      const x = m.x + (m.dx || 0) * k, y = m.y + (m.dy || 0) * k;
      const prev = this.moverPos[i] || { x, y };
      this.moverPos[i] = { x, y, ddx: x - prev.x, ddy: y - prev.y };
    });
    const P = this.p;
    if (P && P.onGround && P.support && P.support.mover != null) {
      const mp = this.moverPos[P.support.mover];
      P.x += mp.ddx;
      P.y = mp.y;
    }
  }

  // Steam vents cycle: quiet, a warning rumble, then a big puff.
  ventState(v) {
    const per = v.period || 3, q = ((this.worldT + (v.offset || 0)) % per) / per;
    if (q < 0.5) return { s: 'idle', k: q / 0.5 };
    if (q < 0.68) return { s: 'warn', k: (q - 0.5) / 0.18 };
    return { s: 'blow', k: (q - 0.68) / 0.32 };
  }

  // Is there room for Wick to stand up (un-roll) right here?
  headroom() {
    const P = this.p;
    const box = { x: P.x - PW / 2, y: P.y - PH, w: PW, h: PH - 1, z0: P.z - PZ / 2, z1: P.z + PZ / 2 };
    return !this.solids.some(s => overlap(box, s));
  }

  async goto(room, x, z = 0) {
    if (room === 'TOWN') { room = 'pro_1'; x = 1220; }
    this.mode = 'transition';
    this.closeAll();
    await this.fadeTo(1, 0.25);
    this.loadRoom(room, x, z);
    this.mode = 'explore';
    await this.fadeTo(0, 0.3);
  }

  // Going through a door, Kirby style: Wick walks up to the doorway at a walking pace and steps in, shrinking away into
  // the dark, with his partner right behind him; the next place fades in and they both step out of its door.
  // (The user found the first version "really glitchy": Wick walked behind the arch's own picture, so its dark inside
  // covered him all at once halfway through shrinking; his partner stayed outside; and he popped up out of thin air on
  // the other side, once right behind a lamppost.)
  async enterDoor(d) {
    const P = this.p;
    sfx('door');
    this.mode = 'transition';
    this.closeAll();
    const tween = (dur, fn) => new Promise(r => this.timers.push({ at: this.t + dur, r, fn, t0: this.t, dur }));
    const ss = p => p * p * (3 - 2 * p);
    const front = d.style === 'front' || d.exit, dz = this.doorZ(d), face = this.doorFace(d);
    // (doors at the front of a room aren't holes to shrink into: he just fades as he walks out that way)
    const fadeOnly = front;
    const inZ = face != null ? face - 6 : front ? dz - 40 : dz + 20;     // as far in as he goes (never behind the door itself)
    const stepZ = face != null ? face - 34 : front ? dz - 4 : dz - 12;   // the doorstep
    this.doorAnim = { k: 0, pk: 0, fadeOnly };
    // (he only turns to face the door if it's really off to one side: no flipping round over a pixel)
    if (Math.abs(d.x - P.x) > 14) P.facing = Math.sign(d.x - P.x);
    // 1. walk up to the doorstep, at a walking pace
    const from = { x: P.x, z: P.z }, step = { x: d.x, z: stepZ };
    const dist = Math.hypot(step.x - from.x, (step.z - from.z) * 1.2);
    if (dist > 4) await tween(clamp(dist / 260, 0.12, 0.7), p => this.doorWalk(from, step, ss(p)));
    // 2. step into the doorway, shrinking and fading into the dark, the partner a moment behind; the screen starts
    // fading out before he's quite gone, so there's no pause in the middle
    const at = { x: P.x, z: P.z }, inside = { x: d.x, z: inZ };
    // (side by side with Wick, not walking over the top of him)
    const side = Math.sign(this.partnerPos.x - P.x) || -P.facing;
    this.doorAnim.pto = { x: d.x + side * 26, z: inZ - 4 };
    let fade = null;
    await tween(0.42, p => {
      this.doorWalk(at, inside, ss(p));
      this.doorAnim.k = p * p;
      this.doorAnim.pk = clamp((p - 0.15) / 0.85, 0, 1) ** 2;
      if (p >= 0.6 && !fade) fade = this.fadeTo(1, 0.24);
    });
    this.doorSparkles(P.x, P.y, P.z, 12);
    await (fade || this.fadeTo(1, 0.24));
    // 3. the next place, and out of its door
    this.doorAnim = null;
    await this.arriveThrough(d);
  }

  // Coming out of the door on the other side: from inside the doorway, walking out to just in front of it, growing
  // back to full size and fading in while the screen does, the partner a step behind.
  async arriveThrough(d) {
    const tween = (dur, fn) => new Promise(r => this.timers.push({ at: this.t + dur, r, fn, t0: this.t, dur }));
    const ss = p => p * p * (3 - 2 * p);
    // (both found while we're still in the old room: they look for the doors that lead back to it)
    const back = this.arrivalDoor(d), az = this.arrivalZ(d);
    this.loadRoom(d.to, d.toX, az);
    const P = this.p;
    if (!back) {   // (no door back this way: just fade in where the door says)
      this.mode = 'explore';
      await this.fadeTo(0, 0.3);
      return;
    }
    const front = back.style === 'front' || back.exit, dz = this.doorZ(back), face = this.doorFace(back);
    const start = { x: back.x, z: face != null ? face - 6 : front ? dz - 20 : dz + 20 };
    // where he ends up: straight out in front of the door (out of anything's way), or where the door says if that's
    // close by (in the old narrow rooms)
    let end = { x: face != null || Math.abs(d.toX - back.x) > 120 ? back.x : d.toX, z: az };
    end = this.clearSpot(end.x, end.z);
    Object.assign(P, { x: start.x, z: start.z, vx: 0, vy: 0, vz: 0, onGround: true });
    const sy = this.floorAt(start.x, start.z);
    if (sy != null) P.y = sy;
    if (Math.abs(end.x - start.x) > 14) P.facing = P.flip = Math.sign(end.x - start.x);
    // (the partner comes out beside him, a step behind: right behind him, it would be hidden behind him)
    const side = -P.facing, pfrom = { x: start.x + side * 24, z: start.z };
    Object.assign(this.partnerPos, { x: pfrom.x, z: pfrom.z, y: P.y });
    this.lastPP = { x: pfrom.x, z: pfrom.z };
    this.partnerFlip = P.facing;
    this.trail = [];
    // (the camera starts settled on him, so it just follows him out instead of swinging over)
    this.camX = clamp(start.x - W / 2 + P.facing * 60, 0, Math.max(0, this.room.w - W));
    if (this.field) this.camZ = clamp(start.z - CAMZ_OFF, 0, this.zb - 640);
    this.doorAnim = { k: 1, pk: 1, fadeOnly: front };
    this.doorSparkles(start.x, P.y, start.z, 10);
    const fadeIn = this.fadeTo(0, 0.3);
    await tween(0.46, p => {
      this.doorWalk(start, end, ss(p));
      this.doorAnim.k = (1 - clamp(p / 0.75, 0, 1)) ** 2;
      this.doorAnim.pk = (1 - clamp((p - 0.12) / 0.8, 0, 1)) ** 2;
      this.doorAnim.pto = { x: P.x + side * 40, z: Math.min(P.z + 14, start.z) };
    });
    P.safe = { x: P.x, y: P.y, z: P.z };
    this.doorAnim = null;
    P.sq = 1.1;   // (a little bounce as he lands in the new place)
    this.mode = 'explore';
    await fadeIn;
  }

  // One step of a walk into or out of a doorway: Wick placed partway along it, his legs going at a walking pace.
  doorWalk(from, to, e) {
    const P = this.p, x = from.x + (to.x - from.x) * e, z = from.z + (to.z - from.z) * e;
    P.phase += Math.hypot(x - P.x, z - P.z) / 70;
    P.x = x; P.z = z;
    const y = this.floorAt(x, z);
    if (y != null) P.y = y;
    P.vx = 0; P.vz = 0; P.vy = 0;
  }

  doorSparkles(x, y, z, n) {
    for (let i = 0; i < n; i++) {
      this.parts.push({ x: x + (Math.random() - 0.5) * 34, y: y - 30 - Math.random() * 40, z, vx: (Math.random() - 0.5) * 200, vy: -60 - Math.random() * 160, life: 0.6, c: '#ffe066', g: 220, star: true });
    }
  }

  // Where a door's own picture stands among everything else in a big field (a path's arch, a doorway, a house's
  // front), or null where it's painted on the floor or the back wall. Walking into a door, Wick has to stay in front
  // of its picture: one step behind it and the doorway's dark inside covers him all at once.
  doorFace(d) {
    if (d.exit || d.style === 'front') return null;
    // (a burrow, a hollow log or a crawlspace is a cutout standing among everything else, in any room)
    if (d.style && d.style !== 'back' && d.style !== 'none') return this.doorZ(d);
    if (!this.field) return null;   // (the old narrow rooms paint their doors on the back wall, under everything)
    if (!d.style) return (d.z ?? GZ1) - 10;
    if (d.style === 'back') return this.doorZ(d) + 2;
    // (a house's door, on the front of the house: doorZ stands just in front of a house that has a depth, and right
    // on the front line of an old-style building that doesn't)
    const pr = d.z == null && (this.room.props || []).find(p => Math.abs(p.x - d.x) < 70);
    return pr && pr.z == null && !PROP_FOOT[pr.kind] ? this.doorZ(d) : this.doorZ(d) + 4;
  }

  // The door in the next room that leads back here (the one nearest where you'll come out).
  arrivalDoor(d) {
    let best = null, bd = 1e9;
    for (const b of ROOMS[d.to].doors || []) {
      if (b.to !== this.roomId) continue;
      const dd = Math.abs(b.x - d.toX);
      if (dd < bd) { bd = dd; best = b; }
    }
    return best;
  }

  // The nearest spot to (x, z) where Wick can stand: on the floor, and not inside a lamppost, a sign or a tree.
  clearSpot(x, z) {
    const free = (xx, zz) => {
      if (this.floorAt(xx, zz) == null) return false;
      const y = this.surfaceAt(xx, zz), b = { x: xx - PW / 2, y: y - PH, w: PW, h: PH - 1, z0: zz - PZ / 2, z1: zz + PZ / 2 };
      return !this.solids.some(s => !s.floor && overlap(b, s));
    };
    if (free(x, z)) return { x, z };
    for (const [dx, dz] of [[0, -24], [0, -48], [30, 0], [-30, 0], [30, -30], [-30, -30], [0, -80], [60, 0], [-60, 0], [0, 24]]) {
      const zz = clamp(z + dz, this.zmin, this.zmax);
      if (free(x + dx, zz)) return { x: x + dx, z: zz };
    }
    return { x, z };
  }

  // How far back a door sits: shop doors at the building fronts, paths at the far back, doormats at the front.
  doorZ(d, R = this.room) {
    if (d.z != null) return d.z;
    if (d.exit) return -30;
    if (d.style === 'front') return -40;
    if (d.style === 'none') {
      const pr = (R.props || []).find(p => Math.abs(p.x - d.x) < 70);
      if (pr && PROP_FOOT[pr.kind]) return (pr.z ?? PROP_FOOT[pr.kind][3]) - PROP_FOOT[pr.kind][1] - 4;
      return pr && pr.z != null ? pr.z - 4 : BZ0;
    }
    if (d.style === 'back' || (R.interior && !d.style)) return GZ1 - 4;
    if (d.style) return 170;
    return GZ1 - 20;
  }

  // Coming through a door, you appear next to the matching door in the new room.
  arrivalZ(d) {
    const best = this.arrivalDoor(d);
    if (!best) return 0;
    const z = this.doorZ(best, ROOMS[d.to]);
    return best.exit || best.style === 'front' ? z + 30 : z - 50;
  }

  fadeTo(target, dur) {
    const from = this.fadeA;
    const t0 = this.t;
    return new Promise(r => { this.fadeAnim = { from, target, t0, dur, r }; });
  }

  // ---------------------------------------------------------------- scripts
  async runScript(cmds) {
    if (typeof cmds === 'string') cmds = SCRIPTS[cmds];
    if (!cmds) return true;
    this.mode = 'script';
    // (a script that ends with a trip to another room can still be wrapping up after a story trigger there has
    // started the next one: only the newest script hands control back)
    const gen = this.scriptGen = (this.scriptGen || 0) + 1;
    let ok = false;
    try { ok = await this.exec(cmds); } catch (e) { console.error(e); }
    if (this.mode === 'script' && gen === this.scriptGen) this.mode = 'explore';
    // someone may have joined the party, left or turned up (folks are in the way), or a door or a gate opened
    if (this.room) this.buildSolids();
    this.saveSoon();
    return ok;
  }

  async exec(cmds) {
    for (const cmd of cmds) {
      const [op, a, b, c] = cmd;
      if (op === 'say') await this.say(a, b);
      else if (op === 'narrate') await this.say(null, a);
      else if (op === 'flag') this.s.flags[a] = true;
      else if (op === 'ability') { this.s.abilities[a] = true; sfx('levelup'); }
      else if (op === 'partner') this.joinPartner(a);
      else if (op === 'battle') { const r = await this.fight(a, b || {}); if (r !== 'win') return false; }
      else if (op === 'heal') this.healAll();
      else if (op === 'card') await this.card(a, b);
      else if (op === 'shard') await this.getShard(a);
      else if (op === 'goto') { await this.goto(a, b); return true; }
      else if (op === 'if') {
        const branch = a(this) ? b : c;
        if (branch && !(await this.exec(branch))) return false;
      } else if (op === 'wait') await this.wait(a);
      else if (op === 'sfx') sfx(a);
      else if (op === 'cut') await this.cutscene(a);
      else if (op === 'tip') this.tip(typeof a === 'function' ? a(this) : a, b);
      else if (op === 'shop') { this.inMenu = true; try { await this.shop(a); } finally { this.inMenu = false; } this.panelEl.classList.add('hidden'); }
      else if (op === 'dojo') await this.dojoMenu();
      else if (op === 'minigame') await this.boothMenu(a);
      else if (op === 'rest') { this.healAll(); sfx('save'); this.saveNow(); this.cut.flash = 0.5; await this.say(null, a || 'You rest a while. HP and FP fully restored!'); }
      else if (op === 'give') { await this.giveReward(a); sfx('fanfare'); await this.say(null, `You got ${this.rewardText(a)}!`); }
      else if (op === 'key') { if (!this.s.keyItems.includes(a)) this.s.keyItems.push(a); }
      else if (op === 'sticker') {
        const n = b || 1;
        this.s.stickers[a] = (this.s.stickers[a] || 0) + n;
        sfx('peel'); sfx('fanfare');
        await this.say(null, `You got ${n > 1 ? `${n} ${STICKERS[a].name}s` : `a ${STICKERS[a].name}`}! (ESC → Sticker Album)`);
      }
      else if (op === 'unkey') this.s.keyItems = this.s.keyItems.filter(k => k !== a);
      else if (op === 'coins') { await this.addCoins(a); sfx('coin'); this.hub.refresh(); }
      else if (op === 'choose') {
        this.inMenu = true;
        const v = await this.menu(this.panelEl, a, b.map(([label], i) => ({ label, value: String(i) })).concat([{ label: '✖ Never mind', value: 'x' }]), { cancel: true });
        this.inMenu = false;
        this.panelEl.classList.add('hidden');
        if (v != null && v !== 'x' && !(await this.exec(b[Number(v)][1]))) return false;
      }
      else if (op === 'quest') this.startQuest(a);
      else if (op === 'turnin') await this.turnIn(a);
      else if (op === 'turnin_any') {
        let any = false;
        for (const id of a) if (this.questReady(id)) { await this.turnIn(id); any = true; }
        if (!any && b && !(await this.exec(b))) return false;
      }
    }
    return true;
  }

  async cutscene(name) {
    const P = this.p;
    if (name === 'dark') { this.cut.townLit = true; this.camLock = 900; }
    else if (name === 'dusk_in') {
      const x = this.roomId === 'pro_1' && !this.flag('intro_done') ? 1350 : P.x + 300;
      this.cut.dusk = { x, y: 300, a: 0 };
      sfx('alert');
      await this.tween(0.8, p => { this.cut.dusk.a = p; this.cut.dusk.y = 260 + (1 - p) * -120; });
    } else if (name === 'shatter') {
      this.cut.flash = 1;
      sfx('crunch');
      this.cut.townLit = false;
      for (let i = 0; i < 5; i++) {
        const a = -Math.PI / 2 + (i - 2) * 0.5;
        this.parts.push({ x: 1350, y: 280, vx: Math.cos(a) * 520, vy: Math.sin(a) * 520, life: 1.6, c: '#bff0ff', star: true, g: 0 });
      }
      await this.wait(0.9);
    } else if (name === 'dusk_out') {
      if (this.cut.dusk) await this.tween(0.7, p => { this.cut.dusk.a = 1 - p; this.cut.dusk.y -= 3; });
      this.cut.dusk = null;
      this.camLock = null;
    } else if (name === 'elder_fly' || name === 'elder_fly_shed') {
      // (Mothwick flutters off up and away: out of town at the start, from his shed up to his lookout in the Prologue)
      this.cut.flyId = name === 'elder_fly' ? 'elder1' : 'elder2';
      this.cut.elderFly = 0;
      sfx('swish');
      await this.tween(1.2, p => { this.cut.elderFly = p; });
    } else if (name === 'gloom_pop') {
      for (let i = 0; i < 14; i++) this.parts.push({ x: P.x + 120, y: P.y - 30, vx: (Math.random() - 0.5) * 300, vy: -Math.random() * 300, life: 0.8, c: '#5d4385', g: 600 });
      sfx('hurt');
      await this.wait(0.5);
    } else if (name === 'boss_wake') {
      this.cut.bossAwake = true;
      this.cut.shake = 0.6;
      sfx('crunch');
      await this.wait(0.7);
    } else if (name === 'quake') {
      this.cut.shake = 1.2;
      sfx('crunch');
      await this.wait(0.4);
      sfx('crunch');
      await this.wait(0.9);
    } else if (name === 'ember_panic') {
      // Ember lights every brazier at once... and they all fizzle out
      this.cut.panic = this.t;
      sfx('flare');
      await this.wait(0.7);
      sfx('hurt');
      for (const b of this.room.braziers || []) {
        const y = this.surfaceAt(b.x) - 70;
        for (let i = 0; i < 6; i++) this.parts.push({ x: b.x, y, vx: (Math.random() - 0.5) * 80, vy: -40 - Math.random() * 60, life: 0.9, dust: true, r: 5, g: -30 });
      }
      await this.wait(0.6);
    } else if (name === 'gate_open') {
      this.cut.shake = 0.7;
      sfx('door');
      sfx('crunch');
      await this.wait(0.8);
    } else if (this[`cut_${name}`]) await this[`cut_${name}`]();   // later chapters' cutscenes (cut_beam...)
  }

  async getShard(n) {
    this.s.shards = Math.max(this.s.shards, n);
    this.cut.shard = this.t;
    sfx('fanfare');
    await this.wait(1.4);
    await this.say(null, `✨ You got Lumen Shard ${n}! ✨ (${this.s.shards} of 5)`);
    this.cut.shard = null;
    this.saveNow();
  }

  joinPartner(id) {
    const d = PARTNERS[id];
    const lv = this.bondLv(id);
    this.s.partners[id] = { hp: d.hp + 2 * (lv - 1), max: d.hp + 2 * (lv - 1) };
    this.s.bondSeen = this.s.bondSeen || {};
    this.s.bondSeen[id] = lv;
    this.s.partner = id;
    sfx('fanfare');
  }

  healAll() {
    const h = this.s.hero;
    h.hp = h.maxHp;
    h.fp = h.maxFp;
    for (const p of Object.values(this.s.partners)) p.hp = p.max;
  }

  async addCoins(n) {
    try {
      const r = await api('/api/wallet', { coins: n });
      if (r.wallet) this.walletCache = { ...this.walletCache, ...r.wallet };
    } catch (e) { /* ignore */ }
  }

  async addStars(n) {
    try {
      const r = await api('/api/wallet', { star_pieces: n });
      if (r.wallet) this.walletCache = { ...this.walletCache, ...r.wallet };
    } catch (e) { /* ignore */ }
  }

  // ---------------------------------------------------------------- quests & rewards
  startQuest(id) {
    if (this.s.quests[id]) return;
    this.s.quests[id] = 'active';
    sfx('chime');
    this.tip(`📜 New quest: ${QUESTS[id].name}  (ESC → Quests)`);
    this.saveSoon();
  }

  rewardText(r) {
    const parts = [];
    if (r.badge) parts.push(`the ${BADGES[r.badge].name} badge`);
    if (r.starPieces) parts.push(`${r.starPieces} ⭐ Star Piece${r.starPieces > 1 ? 's' : ''}`);
    for (const [k, n] of Object.entries(r.items || {})) parts.push(`${n} ${ITEMS[k].name}${n > 1 ? 's' : ''}`);
    if (r.coins) parts.push(`${r.coins} coins`);
    return parts.join(', ');
  }

  async giveReward(r) {
    if (r.coins) await this.addCoins(r.coins);
    if (r.starPieces) await this.addStars(r.starPieces);
    for (const [k, n] of Object.entries(r.items || {})) this.s.items[k] = (this.s.items[k] || 0) + n;
    if (r.badge) {
      if (this.s.badges.owned.includes(r.badge)) await this.addCoins(30);
      else this.s.badges.owned.push(r.badge);
    }
    this.hub.refresh();
  }

  async turnIn(id) {
    if (!this.questReady(id)) return false;
    this.s.quests[id] = 'done';
    const r = QUESTS[id].reward;
    await this.giveReward(r);
    sfx('fanfare');
    await this.say(null, `✅ Quest complete: ${QUESTS[id].name}! You got ${this.rewardText(r)}.` + (r.badge ? ' Equip badges from the menu (ESC → Badges).' : ''));
    this.saveNow();
    return true;
  }

  checkQuestReady() {
    for (const id of Object.keys(this.s.quests)) {
      if (this.s.quests[id] !== 'active' || this.s.flags[`qn_${id}`]) continue;
      if (QUESTS[id].progress(this).done) {
        this.s.flags[`qn_${id}`] = true;
        sfx('chime');
        this.tip(`✨ "${QUESTS[id].name}" is ready! Go see ${QUESTS[id].giver} (${QUESTS[id].where}).`, 9);
        this.saveSoon();
        return;
      }
    }
  }

  async collect(g, x, y, viaDialog) {
    if (g.coins) {
      this.addCoins(g.coins);
      sfx('coin');
      this.float(`+${g.coins} 🪙`, x, y);
      if (viaDialog) await this.say(null, `You found ${g.coins} coins!`);
    }
    if (g.item) {
      const n = g.n || 1;
      this.s.items[g.item] = (this.s.items[g.item] || 0) + n;
      sfx('coin');
      this.float(`${ITEMS[g.item].icon} ${ITEMS[g.item].name}${n > 1 ? ' ×' + n : ''}!`, x, y);
      if (viaDialog) await this.say(null, `You got ${n > 1 ? n + ' ' : 'a '}${ITEMS[g.item].name}${n > 1 ? 's' : ''}! ${ITEMS[g.item].desc}`);
    }
    if (g.starPiece) {
      await this.addStars(g.starPiece);
      sfx('fanfare');
      this.float('⭐ Star Piece!', x, y, '#ffe066');
      await this.say(null, `You found ${g.starPiece > 1 ? g.starPiece + ' ⭐ Star Pieces' : 'a ⭐ Star Piece'}! Trade them at the Star Exchange in town for rare badges.`);
    }
    if (g.badge) {
      sfx('fanfare');
      if (this.s.badges.owned.includes(g.badge)) { await this.addCoins(30); await this.say(null, `A ${BADGES[g.badge].name} badge... you already have one, so you get 30 coins instead.`); }
      else { this.s.badges.owned.push(g.badge); await this.say(null, `You found the ${BADGES[g.badge].name} badge! ${BADGES[g.badge].desc} (Equip it: ESC → Badges.)`); }
    }
    if (g.key) {
      if (!this.s.keyItems.includes(g.key)) this.s.keyItems.push(g.key);
      if (g.key === 'glasses') this.s.flags.got_glasses = true;
      sfx('fanfare');
      const jewels = ['ruby', 'sapphire', 'emerald'].filter(k => this.s.keyItems.includes(k)).length;
      const extra = g.key === 'glasses' ? " Bring them back to Hoot's Hollow."
        : ['sapphire', 'emerald'].includes(g.key) ? ` (${jewels} of the 3 Crown Jewels)`
          : g.key === 'sugar' ? ' Chef Crumb will be thrilled.' : '';
      await this.say(null, `You found ${KEY_ITEMS[g.key]}!${extra}`);
    }
    this.hub.refresh();
    this.saveSoon();
  }

  // ---------------------------------------------------------------- battles
  async fight(kinds, opts = {}) {
    const prev = this.mode;
    this.mode = 'battle';
    const res = await this.battle.start(kinds, { ...opts, theme: this.battleTheme() });
    const r = await this.afterBattle(res, opts);
    if (this.mode === 'battle') this.mode = prev === 'battle' ? 'explore' : prev;
    return r;
  }

  async afterBattle(res, opts = {}) {
    // losing a sparring match at the dojo is just practice
    if (res.result === 'lose' && opts.spar) {
      this.healAll();
      this.saveSoon();
      return 'lose';
    }
    if (res.result === 'win' || res.result === 'run') {
      for (const k of res.killed || []) {
        const key = `${this.room ? this.room.area : 'x'}_${k}`;
        this.s.kills[key] = (this.s.kills[key] || 0) + 1;
      }
    }
    if (res.result === 'win') {
      this.s.battlesWon++;
      api('/api/event', { type: 'battles' }).catch(() => {});
      if (res.coins) this.addCoins(res.coins);
      this.addConfetti(2);
      if (this.s.badges.equipped.includes('paper_heart')) { const hh = this.s.hero; hh.hp = Math.min(hh.maxHp, hh.hp + 2); }
      const h = this.s.hero;
      h.xp += res.xp;
      while (h.xp >= 100) { h.xp -= 100; await this.levelUp(); }
      if (this.s.battlesWon === 1) this.tip('Nice! Battles give XP (100 XP = level up) and coins for the shops in town.');
    } else if (res.result === 'lose') {
      await this.gameOver();
    }
    this.saveSoon();
    return res.result;
  }

  async levelUp() {
    const h = this.s.hero;
    h.lvl++;
    sfx('levelup');
    const prev = this.mode;
    this.mode = 'menu';
    const v = await this.menu(this.panelEl, `⭐ LEVEL UP! Wick is now level ${h.lvl}`, [
      { label: '♥ HP +5', right: `${h.maxHp} → ${h.maxHp + 5}`, value: 'hp', desc: 'More health: survive longer fights.' },
      { label: '✿ FP +5', right: `${h.maxFp} → ${h.maxFp + 5}`, value: 'fp', desc: 'More Flower Points: more special moves and Team Attacks.' },
      { label: '🎖️ BP +3', right: `${h.bp} → ${h.bp + 3}`, value: 'bp', desc: 'More Badge Points: wear more badges at once.' },
    ], { cancel: false, info: 'Choose one upgrade. You also get fully healed! (Train ATK and DEF at the Brightblade Dojo in Lumen Town.)' });
    if (v === 'hp') h.maxHp += 5; else if (v === 'fp') h.maxFp += 5; else h.bp += 3;
    this.healAll();
    this.panelEl.classList.add('hidden');
    this.mode = prev;
  }

  async gameOver() {
    this.mode = 'menu';
    this.gameOverNow = true;
    await this.menu(this.panelEl, "💫 Wick's flame flickered out...", [
      { label: '🕯️ Try again from the last lamppost', value: 'retry' },
    ], { cancel: false, info: "Don't worry: you keep your items, coins and XP. Lampposts save your spot." });
    this.healAll();
    const L = this.s.lamp || { room: 'pro_1', x: 1220 };
    this.gameOverNow = false;
    await this.goto(L.room, L.x, L.z || 0);
  }

  async startFieldBattle(e, first, ambush) {
    this.mode = 'battle';
    this.p.vx = 0;
    sfx('hit');
    this.iris = { t0: this.t, dur: 0.35 };
    await this.wait(0.35);
    this.iris = null;
    const res = await this.battle.start(e.group, { firstStrike: first, ambush, theme: this.battleTheme() });
    const r = await this.afterBattle(res);
    if (r === 'lose') return;
    if (this.mode === 'battle') this.mode = 'explore';
    if (r === 'win') e.dead = true;
    else { e.stun = 2.5; e.ai = 'return'; e.cool = 4; this.p.invuln = 2; }   // (you ran away: a head start before it looks for you again)
    this.p.invuln = Math.max(this.p.invuln, 1);
    if (this.light <= 0 && this.flag('prologue_done')) await this.outOfLight();
  }

  async outOfLight() {
    this.mode = 'script';
    await this.say('Mothwick', 'Wick! Your lantern is sputtering out! Come back to town and rest.');
    await this.say(null, 'Earn more ✦ Light by focusing on homework. Start a focus session in the Today tab!');
    await this.goto('pro_1', 1220);
  }

  // ---------------------------------------------------------------- shops, board, chests, map, menus
  async shopDoor(kind) {
    if (kind === 'lantern' && !this.flag('prologue_done')) { await this.runScript([['narrate', 'The Great Lantern is cold and cracked. Not yet...']]); return; }
    if (!this.flag('prologue_done')) { await this.runScript([['narrate', 'CLOSED. (The shopkeeper is hiding from the Gloom.)']]); return; }
    this.mode = 'menu';
    if (kind === 'inn' || kind === 'spring') {
      this.healAll();
      sfx('save');
      this.saveNow();
      await this.say(null, kind === 'spring' ? 'Ahhh. You soak in the Cinder Springs until your wick is toasty. HP and FP fully restored!'
        : 'You rest at the Sleepy Wick Inn. HP and FP fully restored! (Free for heroes.)');
    } else {
      this.inMenu = true;
      try { await this.shop(kind); } finally { this.inMenu = false; }
    }
    this.panelEl.classList.add('hidden');
    this.mode = 'explore';
  }

  // The Great Lantern in Lumen Town: pour ✦ Light into it to make Wick's flame stronger, for good.
  async lanternShop() {
    for (;;) {
      const items = Object.entries(LANTERN).map(([id, L]) => {
        const lv = this.lanternLv(id), cost = L.costs[lv];
        if (cost == null) return { label: L.name, right: 'MAX', value: null, disabled: true, desc: `${L.what[L.what.length - 1]} (Fully lit!)` };
        const short = this.light < cost;
        return { label: `${L.name}${L.costs.length > 1 ? ` Lv ${lv + 1}` : ''}`, right: `${cost} ✦`, value: id, disabled: short,
          desc: short ? `${L.what[lv]} You need ${cost} ✦ Light (you have ${this.light}).` : L.what[lv] };
      });
      items.push({ label: '← Leave', value: 'leave' });
      const v = await this.menu(this.panelEl, '🏮 The Great Lantern', items, { cancel: true,
        info: `Pour in ✦ Light from your homework focus to make Wick's flame stronger, for good. You have ✦ ${this.light}.` });
      if (!v || v === 'leave') return;
      const L = LANTERN[v], lv = this.lanternLv(v), cost = L.costs[lv];
      if (!(await this.payLight(cost))) { sfx('hurt'); continue; }
      this.s.lantern = { ...(this.s.lantern || {}), [v]: lv + 1 };
      sfx('levelup');
      this.cut.flash = 0.4;
      this.saveNow();
      this.panelEl.classList.add('hidden');
      await this.say(null, `The Great Lantern drinks in ${cost} ✦ Light and glows a little warmer. ${L.done[lv]}`);
    }
  }

  async shop(kind) {
    if (kind === 'stickers') return this.stickerShop();
    if (kind === 'lantern') return this.lanternShop();
    for (;;) {
      const w = this.walletCache;
      let title, items;
      if (kind === 'items') {
        title = '🍯 Honeycomb Goods';
        items = SHOP_ITEMS.map(id => ({ label: `${ITEMS[id].icon} ${ITEMS[id].name}`, right: `${ITEMS[id].price} 🪙`, value: id,
          desc: `${ITEMS[id].desc} You have ${this.s.items[id] || 0}.`, disabled: w.coins < ITEMS[id].price }));
      } else {
        const list = kind === 'badges' ? SHOP_BADGES : STAR_BADGES;
        title = kind === 'badges' ? '🎖️ Badge Bazaar' : '⭐ Star Exchange';
        items = list.map(id => {
          const b = BADGES[id], owned = this.s.badges.owned.includes(id);
          const price = kind === 'badges' ? b.price : b.stars;
          const afford = kind === 'badges' ? w.coins >= price : w.star_pieces >= price;
          return { label: `${owned ? '✓ ' : ''}${b.name}`, right: owned ? 'owned' : `${price} ${kind === 'badges' ? '🪙' : '⭐'}`, value: id,
            disabled: owned || !afford, desc: `${b.desc} (Costs ${b.bp} BP to wear.)` };
        });
      }
      const v = await this.menu(this.panelEl, title, items, { cancel: true, info: `You have 🪙 ${w.coins} coins and ⭐ ${w.star_pieces} Star Pieces.` });
      if (!v) return;
      const isItem = kind === 'items';
      const price = isItem ? ITEMS[v].price : kind === 'badges' ? BADGES[v].price : BADGES[v].stars;
      const r = await api('/api/wallet', kind === 'stars' ? { star_pieces: -price } : { coins: -price });
      if (!r.ok) { sfx('hurt'); continue; }
      this.walletCache = { ...this.walletCache, ...r.wallet };
      sfx('coin');
      if (isItem) this.s.items[v] = (this.s.items[v] || 0) + 1;
      else { this.s.badges.owned.push(v); this.tip(`Got the ${BADGES[v].name} badge! Equip it from the menu (ESC → Badges).`); }
      this.saveNow();
      this.hub.refresh();
    }
  }

  questItems(all) {
    return Object.entries(QUESTS).filter(([id]) => all || this.questKnown(id)).map(([id, q]) => {
      const st = this.s.quests[id];
      const prog = st ? q.progress(this) : null;
      const icon = st === 'done' ? '✅' : st && prog.done ? '✨' : st ? (q.study ? '📚' : '📜') : '📌';
      const right = st === 'done' ? 'done' : st && prog.done ? 'ready!' : st ? prog.text.replace(/^[^:]*: /, '') : q.giver;
      const desc = st === 'done' ? `${q.desc} (Finished!)`
        : st ? `${q.desc} ${prog.text}.${prog.done ? ` Go see ${q.giver} (${q.where}).` : ''} Reward: ${this.rewardText(q.reward)}.`
          : `Talk to ${q.giver} (${q.where}). Reward: ${this.rewardText(q.reward)}.`;
      return { label: `${icon} ${q.name}`, right, value: id, desc };
    });
  }

  async questLog() {
    for (;;) {
      const items = this.questItems(false);
      if (!items.length) { await this.say(null, 'No quests yet. Check the Quest Board in Lumen Town, and talk to everyone you meet!'); return; }
      const sorted = items.sort((a, b) => (a.label.startsWith('✅') - b.label.startsWith('✅')));
      for (const it of sorted) if (it.value === this.s.tracked) it.label = `🧭 ${it.label}`;
      const v = await this.menu(this.panelEl, '📜 Quests', sorted, { cancel: true,
        info: 'Pick a quest to make the gold guide arrow point to it (pick it again to go back to the story). 📚 = Study Challenge, done by really studying.' });
      if (!v) return;
      const q = QUESTS[v];
      if (!this.questActive(v)) { sfx('hurt'); continue; }
      if (q.study) { await this.say(null, `"${q.name}" is a Study Challenge: you finish it by really studying, not by going anywhere! ${q.progress(this).text}.`); continue; }
      this.s.tracked = this.s.tracked === v ? null : v;
      updateGuide(this);
      sfx('select');
      this.tip(this.s.tracked ? `🧭 Tracking "${q.name}". Follow the gold arrow!` : '🧭 The gold arrow follows the story again.', 5);
      this.saveSoon();
    }
  }

  async questBoard() {
    if (!this.flag('prologue_done')) { await this.runScript([['narrate', 'The Quest Board is empty. Everyone is too gloomy to ask for help right now.']]); return; }
    this.mode = 'menu';
    this.inMenu = true;
    try {
      await this.menu(this.panelEl, '📌 Lumen Town Quest Board', this.questItems(true), { cancel: true, info: 'Pinned requests from all over Lumenfold. Find the person who posted one to start it.' });
    } finally { this.inMenu = false; }
    this.panelEl.classList.add('hidden');
    this.mode = 'explore';
  }

  rollStudyChest() {
    const r = Math.random();
    const missing = CHEST_BADGES.filter(b => !this.s.badges.owned.includes(b));
    if (r < 0.08 && missing.length) return { badge: missing[Math.floor(Math.random() * missing.length)] };
    if (r < 0.2) return { starPiece: 1 };
    if (r < 0.58) {
      const pool = ['honeybun', 'honeybun', 'embertea', 'fireseed', 'bighoney', 'sleepydust', 'windcookie', 'feather'];
      return { item: pool[Math.floor(Math.random() * pool.length)], n: Math.random() < 0.35 ? 2 : 1 };
    }
    return { coins: 8 + Math.floor(Math.random() * 13) };
  }

  async chestMenu() {
    for (;;) {
      const c = this.chests;
      if (!c.study && !c.golden) { await this.say(null, 'No chests right now. Every homework step you finish in a focus session gives a 🎁 Study Chest, and every finished assignment gives a 🏆 Golden Chest!'); return; }
      const v = await this.menu(this.panelEl, '🎁 Chests from studying', [
        { label: '🎁 Open a Study Chest', right: `×${c.study}`, value: 'study', disabled: !c.study, desc: 'Coins, items, Star Pieces... and sometimes a badge!' },
        { label: '🏆 Open a Golden Chest', right: `×${c.golden}`, value: 'golden', disabled: !c.golden, desc: 'Always a Star Piece and coins, plus a badge if there are any left to find.' },
      ], { cancel: true, info: 'You earn these in real life: 🎁 per homework step, 🏆 per finished assignment.' });
      if (!v) return;
      const r = await api('/api/chests/open', { kind: v });
      if (!r.ok) return;
      this.chests = r.chests;
      sfx('fanfare');
      if (v === 'study') {
        const loot = this.rollStudyChest();
        await this.collect(loot, this.p ? this.p.x : 480, this.p ? this.p.y - 80 : 300, true);
      } else {
        const missing = CHEST_BADGES.filter(b => !this.s.badges.owned.includes(b));
        await this.collect({ starPiece: 1 }, 480, 300, true);
        await this.collect({ coins: 30 }, 480, 300, true);
        if (missing.length) await this.collect({ badge: missing[Math.floor(Math.random() * missing.length)] }, 480, 300, true);
      }
      this.hub.refresh();
    }
  }

  // ---------------------------------------------------------------- the map, fast travel, hints
  openMap() {
    if (this.mode !== 'explore' && this.mode !== 'menu') return;
    updateGuide(this);
    sfx('menu');
    this.mapScreen.open();
  }

  async fastTravel(id) {
    const a = AREAS[id];
    const dest = this.s.areaLamps[id] || { room: a.start, x: a.x, z: a.z };
    await this.goto(dest.room, dest.x, dest.z || 0);
  }

  // Your partner (or Mothwick) says what to do next and how to get there.
  async hint() {
    updateGuide(this);
    const g = this.guide && this.guide.goal;
    const pid = this.s.partner;
    const who = pid ? PARTNERS[pid].name : 'Mothwick';
    const prev = this.mode;
    this.mode = 'script';
    if (!g) {
      await this.say(who, "No big story step right now! Chapter 4 is on its way. Try a side quest (ESC → Quests), or look for '???' places on the map (TAB).");
    } else {
      const lead = { Moss: 'blorp! okay okay. ', Hoot: 'Hoo! Let me consult my notes. ', Pebble: '...hm. ', Ember: 'Ooh, ooh, I know! ' }[who] || '';
      await this.say(who, `${lead}${g.quest ? 'Quest' : 'Next'}: ${g.text}.`);
      await this.say(who, routeText(this) + (g.tip ? ` Tip: ${g.tip}` : ''));
    }
    if (this.mode === 'script') this.mode = prev === 'menu' ? 'menu' : 'explore';
  }

  // ---------------------------------------------------------------- the dojo
  async dojoMenu() {
    const prevMode = this.mode;
    this.mode = 'menu';
    this.inMenu = true;
    const s = this.s, tr = s.training;
    for (;;) {
      const h = s.hero, w = this.walletCache;
      const levels = { atk: tr.atk || 0, def: tr.def || 0, pal: tr.pal || 0, hp: tr.hp || 0, fp: tr.fp || 0 };
      const items = Object.entries(TRAINING).map(([id, T]) => {
        const lv = levels[id], cost = T.costs[lv];
        if (!cost) return { label: `${T.name}`, right: 'MAX', value: null, disabled: true, desc: `${T.what} You've learned everything here!` };
        const gateLv = lv + (T.gate || 0);
        const locked = (gateLv >= 1 && T.costs.length > 1 && !this.flag('dojo1')) || (gateLv >= 2 && !this.flag('dojo2'));
        const [coins, stars] = cost;
        const afford = w.coins >= coins && w.star_pieces >= stars;
        return {
          label: `${T.name} ${T.costs.length > 1 ? `Lv ${lv + 1}` : ''}`, right: `${coins} 🪙${stars ? ` ${stars} ⭐` : ''}`, value: `t_${id}`,
          disabled: locked || !afford,
          desc: locked ? `${T.what} Locked: beat Sensei in ${gateLv >= 2 ? 'the No Holding Back challenge' : 'a sparring match'} first.`
            : afford ? T.what : `${T.what} You need ${coins} coins${stars ? ` and ${stars} Star Pieces` : ''}.`,
        };
      });
      items.push(
        { label: this.flag('dojo1') ? '🥋 Sparring match (rematch)' : '🥋 Challenge: Sparring match', value: 'spar1',
          desc: this.flag('dojo1') ? 'Spar with Sensei again, just for practice.' : 'Beat Sensei Strike to unlock Lv 2 training and win a badge. Losing is just practice!' },
        { label: this.flag('dojo2') ? '🔥 No Holding Back (rematch)' : '🔥 Challenge: No Holding Back', value: 'spar2', disabled: !this.flag('dojo1') || s.shards < 2,
          desc: !this.flag('dojo1') ? 'Win a sparring match first.' : s.shards < 2 ? 'Sensei says: come back when you have 2 Lumen Shards.' : 'Sensei holds nothing back. Win to unlock Lv 3 training and the Black Belt.' },
        { label: '← Leave', value: 'leave' },
      );
      const v = await this.menu(this.panelEl, '🥋 Brightblade Dojo', items, { cancel: true,
        info: `Wick: ATK ${h.atk || 0} · DEF ${h.def || 0} · ♥ ${h.maxHp} · ✿ ${h.maxFp} · Partners +${s.palAtk || 0}. You have 🪙 ${w.coins} and ⭐ ${w.star_pieces}.` });
      if (!v || v === 'leave') break;
      if (v.startsWith('t_')) {
        const id = v.slice(2), T = TRAINING[id], [coins, stars] = T.costs[levels[id]];
        const r = await api('/api/wallet', { coins: -coins, star_pieces: -stars });
        if (!r.ok) { sfx('hurt'); continue; }
        this.walletCache = { ...this.walletCache, ...r.wallet };
        tr[id] = levels[id] + 1;
        if (id === 'atk') h.atk = (h.atk || 0) + 1;
        else if (id === 'def') h.def = (h.def || 0) + 1;
        else if (id === 'pal') s.palAtk = (s.palAtk || 0) + 1;
        else if (id === 'hp') { h.maxHp += 5; h.hp += 5; }
        else if (id === 'fp') { h.maxFp += 5; h.fp += 5; }
        sfx('levelup');
        this.cut.flash = 0.4;
        this.saveNow();
        this.hub.refresh();
        this.panelEl.classList.add('hidden');
        await this.say('Sensei Strike', {
          atk: 'Strike! Strike! STRIKE! ...Good. Your hits land harder now. (ATK +1)',
          def: 'Brace... brace... now take THAT! ...See? Barely felt it. (DEF +1)',
          pal: `Your partners trained too. ${Object.keys(s.partners).length ? 'They look very proud of themselves.' : 'Well. Future partners did.'} (Partners +1 damage)`,
          hp: 'One hundred push-ups. ...Fine, ten. Your heart is stronger. (Max HP +5)',
          fp: 'Breathe in. Breathe out. Focus the flame. (Max FP +5)',
        }[id]);
        continue;
      }
      // sparring
      const two = v === 'spar2';
      this.panelEl.classList.add('hidden');
      await this.say('Sensei Strike', two ? 'No more holding back. Show me EVERYTHING, little candle!' : 'Bow. ...Good. Now: show me your strike!');
      this.inMenu = false;
      const r = await this.fight([two ? 'sensei2' : 'sensei'], { boss: true, spar: true });
      this.mode = 'menu';
      this.inMenu = true;
      if (r === 'win') {
        const first = !this.flag(two ? 'dojo2' : 'dojo1');
        await this.say('Sensei Strike', first ? (two ? 'Ha... HA! You struck true. Every lesson I have is yours now.' : 'Hmph! A fine strike. Lv 2 training is open to you.')
          : 'Good. Very good. Again tomorrow!');
        if (first) {
          this.s.flags[two ? 'dojo2' : 'dojo1'] = true;
          await this.collect({ badge: two ? 'black_belt' : 'counter_strike' }, this.p.x, this.p.y - 80, true);
        }
      } else {
        await this.say('Sensei Strike', 'Down you go! ...Up you get. A match that never lights has still been struck. Try again when you are ready.');
      }
      this.saveNow();
    }
    this.inMenu = false;
    this.panelEl.classList.add('hidden');
    this.mode = prevMode === 'menu' ? 'explore' : prevMode;
  }

  async pauseMenu() {
    const prev = this.mode;
    this.mode = 'menu';
    this.inMenu = true;
    let then = null;
    for (;;) {
      const h = this.s.hero;
      const nCh = (this.chests.study || 0) + (this.chests.golden || 0);
      const v = await this.menu(this.panelEl, '⏸ Menu', [
        { label: '👥 Party & Bond', value: 'party', desc: 'Stats, Bond levels and which partner travels with you.' },
        { label: '🎒 Items', value: 'items', desc: 'Use healing items.' },
        { label: '🎖️ Badges', right: `${this.usedBp()}/${h.bp} BP`, value: 'badges', desc: 'Equip badges. Each one costs Badge Points (BP).' },
        { label: '📜 Quests', value: 'quests', desc: 'Your side quests and Study Challenges. Pick one to point the guide arrow at it.' },
        { label: '🗺️ Map', right: 'TAB', value: 'map', desc: "See where you are, what's left to find, and fast travel to places you've been." },
        { label: '💡 Where do I go?', right: 'H', value: 'hint', desc: 'Your partner tells you what to do next and how to get there.' },
        { label: '🎁 Study chests', right: nCh ? `×${nCh}` : '', value: 'chests', desc: 'Chests you earned by finishing homework steps.' },
        { label: '🔑 Key items', value: 'keys' },
        { label: '🗒️ Sticker Album', right: `🎉 ${this.s.confetti || 0}`, value: 'album', desc: 'Your stickers, plus how many folded folks you have rescued and tears you have patched.' },
        { label: `🧭 Guide arrow: ${this.s.guide === false ? 'OFF' : 'ON'}`, value: 'guide', desc: 'The gold arrow that points toward your next goal. Turn it off if you want to find the way yourself.' },
        { label: '🎮 Controls', value: 'controls' },
        { label: '▶ Back to the game', value: 'resume' },
      ], { cancel: true, info: `Wick Lv ${h.lvl} · XP ${h.xp}/100 · ♥ ${h.hp}/${h.maxHp} · ✿ ${h.fp}/${h.maxFp} · ⚔️ ATK ${h.atk || 0} · 🛡️ DEF ${h.def || 0} · Shards ${this.s.shards}/5` });
      if (!v || v === 'resume') break;
      if (v === 'party') await this.partyMenu();
      else if (v === 'items') await this.itemsMenu();
      else if (v === 'badges') await this.badgesMenu();
      else if (v === 'quests') await this.questLog();
      else if (v === 'chests') await this.chestMenu();
      else if (v === 'album') await this.stickerAlbum();
      else if (v === 'map') { then = 'map'; break; }
      else if (v === 'hint') { then = 'hint'; break; }
      else if (v === 'guide') { this.s.guide = this.s.guide === false; this.saveSoon(); }
      else if (v === 'keys') {
        const keys = this.s.keyItems.map(k => KEY_ITEMS[k]);
        await this.say(null, keys.length ? `Key items: ${keys.join(', ')}` : 'No key items yet.');
      } else if (v === 'controls') {
        await this.say(null, 'Arrow keys or WASD: walk. ← → go sideways, ↑ ↓ go back and forth into the distance.  SPACE: jump (hold to jump higher, and hold while falling to glide once you learn it).  R or Shift: roll up small (once you learn the Roll Fold).');
        await this.say(null, 'E: talk, read, open, shop, save.  X: hammer (also breaks bushes and pots).  C: partner ability.  F: Lantern Flare on/off (it burns ✦ Light while lit).  M: music on/off.');
        await this.say(null, '✦ Light: it burns slowly while you explore. You can also pour it into the Great Lantern in Lumen Town for permanent upgrades, use it for the Lantern Beam in battle, or spend it to Rekindle Wick when his flame goes out.');
        await this.say(null, 'Out in the world: E peels stickers off things and sticks them on outlines, lifts pots and picks bombs. While you hold something, E or X throws it (hold ↑ or ↓ to throw into the distance). Walk into a crate to push it.');
        await this.say(null, 'TAB: map (where you are, and fast travel).  H: a hint about where to go next.  ESC: menu.');
        await this.say(null, 'In battle: arrows + SPACE to pick moves. Press SPACE as attacks land (watch for the ⭐). In Team Attacks, SPACE is Wick and X is your partner!');
        await this.say(null, 'Timing counts! Press dead on (or let go of a hold between the two marks) for a PERFECT: +1 damage. Too early or too late and the combo ends.');
      }
    }
    this.inMenu = false;
    this.panelEl.classList.add('hidden');
    this.mode = prev === 'menu' ? 'explore' : prev;
    if (then === 'map') this.openMap();
    else if (then === 'hint') await this.hint();
  }

  async partyMenu() {
    const h = this.s.hero;
    const ids = Object.keys(this.s.partners);
    if (!ids.length) { await this.say(null, "It's just Wick for now. Partners join you as the story goes on!"); return; }
    const v = await this.menu(this.panelEl, '👥 Party & Bond', ids.map(id => {
      const lv = this.bondLv(id), sec = (this.bond || {})[id] || 0;
      const next = BOND_LEVELS[lv];
      const P = PARTNERS[id];
      return {
        label: `${id === this.s.partner ? '★ ' : ''}${P.name}  💛 Bond ${lv}`, right: `♥ ${this.s.partners[id].hp}/${this.s.partners[id].max}`, value: id,
        desc: `Team Attack: ${P.team.name} (${P.team.fp} FP). Field (C): ${P.field.name}. `
          + (next ? `Bond ${lv + 1} after ${Math.max(0, Math.ceil((next - sec) / 60))} more focus minutes with ${P.name} as your study buddy.` : 'Max Bond!'),
      };
    }), { cancel: true, info: `Wick: Lv ${h.lvl}, ♥ ${h.hp}/${h.maxHp}, ✿ ${h.fp}/${h.maxFp}, BP ${h.bp}, ⚔️ ATK ${h.atk || 0}, 🛡️ DEF ${h.def || 0}${this.s.palAtk ? `, partners +${this.s.palAtk} damage` : ''}. Bond grows while you study with that partner chosen here. Pick who travels with you.` });
    if (v) { this.s.partner = v; sfx('select'); this.saveNow(); }
  }

  async itemsMenu() {
    for (;;) {
      const list = Object.entries(this.s.items).filter(([k, n]) => n > 0 && ITEMS[k]);
      if (!list.length) { await this.say(null, 'No items. Buy some at Honeycomb Goods in town!'); return; }
      const h = this.s.hero;
      const v = await this.menu(this.panelEl, '🎒 Items', list.map(([k, n]) => ({
        label: `${ITEMS[k].icon} ${ITEMS[k].name}`, right: `×${n}`, value: k, desc: ITEMS[k].desc,
        disabled: !!(ITEMS[k].battle || ITEMS[k].auto),
      })), { cancel: true, info: `♥ ${h.hp}/${h.maxHp} · ✿ ${h.fp}/${h.maxFp}` });
      if (!v) return;
      const it = ITEMS[v];
      if (it.hp) { h.hp = Math.min(h.maxHp, h.hp + it.hp); for (const p of Object.values(this.s.partners)) p.hp = Math.min(p.max, p.hp + it.hp); }
      if (it.fp) h.fp = Math.min(h.maxFp, h.fp + it.fp);
      this.s.items[v]--;
      sfx('coin');
    }
  }

  async badgesMenu() {
    for (;;) {
      const h = this.s.hero, eq = this.s.badges.equipped;
      const owned = this.s.badges.owned;
      if (!owned.length) { await this.say(null, 'No badges yet. Find them in the Badge Bazaar!'); return; }
      const v = await this.menu(this.panelEl, `🎖️ Badges (${this.usedBp()}/${h.bp} BP used)`, owned.map(id => ({
        label: `${eq.includes(id) ? '✅' : '⬜'} ${BADGES[id].name}`, right: `${BADGES[id].bp} BP`, value: id, desc: BADGES[id].desc,
      })), { cancel: true, info: 'Choose a badge to equip or take it off.' });
      if (!v) return;
      const b = BADGES[v];
      if (eq.includes(v)) {
        eq.splice(eq.indexOf(v), 1);
        if (v === 'hp_plus') { h.maxHp -= 5; h.hp = Math.min(h.hp, h.maxHp); }
        if (v === 'fp_plus') { h.maxFp -= 5; h.fp = Math.min(h.fp, h.maxFp); }
      } else if (this.usedBp() + b.bp > h.bp) {
        sfx('hurt');
        await this.say(null, 'Not enough BP! Take another badge off first, or choose BP +3 on your next level up.');
      } else {
        eq.push(v);
        if (v === 'hp_plus') h.maxHp += 5;
        if (v === 'fp_plus') h.maxFp += 5;
        sfx('select');
      }
      this.saveSoon();
    }
  }

  // ---------------------------------------------------------------- fishing
  startFishing(spot) {
    this.mode = 'fish';
    this.p.x = spot.x - 10; this.p.z = spot.z ?? 0; this.p.vx = 0; this.p.vz = 0; this.p.facing = 1; this.p.flip = 1;
    this.fish = { x: spot.x, phase: 'wait', streak: 0, caught: 0, msg: '', splash: -9 };
    this.fishWait();
    this.tip('Fishing! Press SPACE the moment the bobber dips under. E or ESC to stop.', 6);
  }

  fishWait() {
    const F = this.fish;
    F.phase = 'wait';
    F.koi = this.questActive('koi') && F.streak >= 3 && !this.flag('koi_caught');
    F.biteAt = this.t + 1.3 + Math.random() * 2.7 + (F.koi ? 1 : 0);
    F.msg = F.koi ? 'Something GOLDEN is circling the bobber...' : 'Waiting for a bite...';
  }

  updateFishing() {
    const F = this.fish, pr = this.pressed;
    if (pr.has('menu') || pr.has('act')) { this.endFishing(); return; }
    if (F.phase === 'wait') {
      if (pr.has('jump')) { F.phase = 'pause'; F.pauseUntil = this.t + 1; F.streak = 0; F.msg = 'Too early! The fish swam off.'; sfx('hurt'); }
      else if (this.t >= F.biteAt) { F.phase = 'bite'; F.biteEnd = this.t + (F.koi ? 0.36 : Math.max(0.36, 0.62 - F.streak * 0.06)); sfx('tick'); }
    } else if (F.phase === 'bite') {
      if (pr.has('jump')) {
        F.splash = this.t;
        F.phase = 'pause';
        if (F.koi) {
          this.s.flags.koi_caught = true;
          F.msg = '🌟 THE GOLDEN KOI!!! 🌟 Go tell Fisher Finn!';
          F.streak = 0;
          F.pauseUntil = this.t + 3;
          sfx('fanfare');
          this.saveNow();
        } else {
          F.streak++; F.caught++;
          const c = 2 + Math.floor(Math.random() * 3);
          this.addCoins(c);
          F.msg = `Caught a fish! +${c} 🪙   Streak: ${F.streak}`;
          F.pauseUntil = this.t + 1.2;
          sfx('coin');
        }
      } else if (this.t > F.biteEnd) {
        F.phase = 'pause'; F.pauseUntil = this.t + 1; F.streak = 0;
        F.msg = F.koi ? 'The Golden Koi got away... Catch 3 in a row and it may come back.' : 'It got away...';
        sfx('hurt');
      }
    } else if (F.phase === 'pause' && this.t >= F.pauseUntil) this.fishWait();
  }

  endFishing() {
    this.mode = 'explore';
    this.fish = null;
    this.hub.refresh();
  }

  drawFishing(c) {
    const F = this.fish;
    if (!F) return;
    // (out in a big field the line and bobber sit at Wick's depth, like everything else)
    const P = this.p, camX = Math.round(this.camX), V = view(camX, HZ, W, { camZ: this.camZ || 0, zb: this.zb });
    const bx = V.x(F.x + 78, P.z) - camX, by = V.y(P.y + 50, P.z);
    const dip = F.phase === 'bite' ? 10 : 0;
    c.strokeStyle = 'rgba(43,34,53,0.7)'; c.lineWidth = 1.5;
    c.beginPath(); c.moveTo(V.x(P.x + 22, P.z) - camX, V.y(P.y - 64, P.z)); c.quadraticCurveTo(bx - 40, by - 90, bx, by + dip - 8); c.stroke();
    paper(c, p => { shape(c, p, ell(bx, by + dip + Math.sin(this.t * 3) * 2, 7, 9), '#e5534b', 2); });
    if (F.phase === 'bite') {
      c.font = 'bold 30px Fredoka, sans-serif'; c.textAlign = 'center'; c.lineWidth = 5; c.strokeStyle = INK;
      c.strokeText('!', bx, by - 26); c.fillStyle = '#ffe066'; c.fillText('!', bx, by - 26);
      if (F.koi) glowDot(c, bx, by + 6, 50, '255,215,90', 0.6);
    }
    const age = this.t - F.splash;
    if (age < 0.8) { c.strokeStyle = `rgba(255,255,255,${1 - age})`; c.lineWidth = 3; c.beginPath(); c.ellipse(bx, by + 6, 10 + age * 60, 4 + age * 16, 0, 0, Math.PI * 2); c.stroke(); }
    c.font = 'bold 18px Fredoka, sans-serif'; c.textAlign = 'center';
    const w = Math.max(360, c.measureText(F.msg).width + 50);
    c.fillStyle = PAPER; c.strokeStyle = INK; c.lineWidth = 3;
    c.beginPath(); rrect(W / 2 - w / 2, 60, w, 64, 14)(c); c.fill(); c.stroke();
    c.fillStyle = INK; c.fillText(F.msg, W / 2, 88);
    c.font = '14px Fredoka, sans-serif'; c.fillStyle = '#6b5a8a';
    c.fillText(`SPACE: reel in   ·   E / ESC: stop   ·   Fish caught: ${F.caught}`, W / 2, 112);
  }

  // ---------------------------------------------------------------- main loop
  frame(now) {
    requestAnimationFrame(this.frame);
    if (this.active) music.want(this.musicFor());
    const dt = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;
    if (!this.active || !this.s) { this.pressed.clear(); return; }
    this.resize();
    if (!this.lock) {
      this.t += dt;
      this.update(dt);
    }
    this.draw();
    this.pressed.clear();
  }

  resize() {
    const r = this.cv.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    const w = Math.max(1, Math.round(r.width * dpr)), h = Math.max(1, Math.round(r.height * dpr));
    if (this.cv.width !== w || this.cv.height !== h) { this.cv.width = w; this.cv.height = h; }
    this.scale = w / W;
  }

  update(dt) {
    for (const tm of [...this.timers]) {
      if (tm.fn) tm.fn(Math.min(1, (this.t - tm.t0) / tm.dur));
      if (this.t >= tm.at) { this.timers.splice(this.timers.indexOf(tm), 1); tm.r(); }
    }
    if (this.fadeAnim) {
      const f = this.fadeAnim, p = Math.min(1, (this.t - f.t0) / f.dur);
      this.fadeA = f.from + (f.target - f.from) * p;
      if (p >= 1) { this.fadeAnim = null; f.r(); }
    }
    this.updateDialog(dt);
    this.towerUpdate(dt);
    if (this.tipUntil && this.t > this.tipUntil) { this.tipEl.classList.add('hidden'); this.tipUntil = 0; }
    if (this.battle.active) this.battle.update(dt);
    if (this.cut.flash) this.cut.flash = Math.max(0, this.cut.flash - dt * 1.5);
    if (this.cut.shake) this.cut.shake = Math.max(0, this.cut.shake - dt);
    // sparks without a depth of their own belong to wherever Wick is standing
    for (const p of this.parts) { if (p.z === undefined) p.z = this.p ? this.p.z : 0; p.x += p.vx * dt; p.y += p.vy * dt; p.vy += (p.g ?? 300) * dt; p.life -= dt; }
    this.parts = this.parts.filter(p => p.life > 0);
    this.floaters = this.floaters.filter(f => this.t - f.t0 < 1.4);
    const playing = ['explore', 'battle', 'fish', 'minigame'].includes(this.mode) && !this.dlg && this.flag('prologue_done');
    if (playing) {
      this.drainAcc += dt;
      if (this.drainAcc >= DRAIN_EVERY) { this.drainAcc -= DRAIN_EVERY; this.spendLight(1); }
    }
    // a lit flare burns 1 ✦ every few seconds while you explore (longer with the Great Lantern's Steady Flare)
    if (this.flareOn && this.mode === 'explore' && !this.dlg) {
      this.flareAcc += dt;
      if (this.flareAcc >= this.flareEvery()) { this.flareAcc -= this.flareEvery(); this.spendLight(1); }
      if (this.light <= 0) this.setFlare(false, 'Out of ✦ Light: the flare went out');
    }
    this.questCheckT -= dt;
    if (this.questCheckT <= 0 && this.mode === 'explore') { this.questCheckT = 2; this.checkQuestReady(); }
    this.guideT -= dt;
    if (this.guideT <= 0 && this.room && this.mode === 'explore') { this.guideT = 0.6; updateGuide(this); }
    // the camera leans in while you talk to someone
    const talking = this.dlg && this.talkTo && !this.room.dark ? 1 : 0;
    this.talkK += (talking - this.talkK) * Math.min(1, dt * 5);
    if (!this.dlg && this.mode === 'explore') this.talkTo = null;
    if (this.room && ['explore', 'script', 'transition', 'fish'].includes(this.mode)) this.updateWorld(dt);
    if (this.mode === 'explore') this.updateExplore(dt);
    else if (this.mode === 'fish') this.updateFishing(dt);
    else if (this.mode === 'minigame') this.updateMinigame(dt);
    // (not while he's walking through a door: the walk places him itself, and gravity's landing check would pop him up
    // onto a house's roof the moment his feet touched its front)
    else if (this.room && this.p && (this.mode === 'script' || this.mode === 'transition') && !this.doorAnim) this.settle(dt);
    this.updateHud();
  }

  settle(dt) {
    const P = this.p;
    P.vx = 0; P.vz = 0;
    P.gliding = false;
    P.vy = Math.min(MAX_FALL, P.vy + GRAV * dt);
    this.moveY(P.vy * dt);
    if (P.y > (this.room.hazard === 'lava' ? 505 : H + 90)) Object.assign(P, { x: P.safe.x, y: P.safe.y, vy: 0 });
  }

  spendLight(n) {
    this.light = Math.max(0, this.light - n);
    if (this.light === 5) this.tip('Your lantern is running low: 5 ✦ Light left!');
    api('/api/light/spend', { n }).then(r => { if (r.light != null) this.light = r.light; this.hub.refresh(); }).catch(() => {});
  }

  // Pays n ✦ Light for something you chose (the Great Lantern, a battle move): true if it went through.
  async payLight(n) {
    if (this.light < n) return false;
    const r = await api('/api/light/spend', { n }).catch(() => null);
    if (r && r.light != null) this.light = r.light;
    this.hub.refresh();
    return !!(r && r.ok);
  }

  // How far each Great Lantern upgrade has gone (see LANTERN).
  lanternLv(id) { return (this.s.lantern || {})[id] || 0; }

  flareEvery() { return FLARE_EVERY + this.lanternLv('flare'); }

  // Lantern Flare: F lights it and F puts it out. While it burns: a big light in the dark, hidden paths and ✦ blocks
  // show up, and the Gloom can't stand to look at you (enemies won't spot you, and ones chasing you lose you).
  setFlare(on, msg) {
    const P = this.p;
    if (on && this.light < 1) { this.tip('Not enough ✦ Light to flare!'); return; }
    this.flareOn = on;
    this.flareAcc = 0;
    if (on) { this.spendLight(1); sfx('flare'); this.float(`FLARE! (1 ✦ every ${this.flareEvery()}s, F to put it out)`, P.x, P.y - 90, '#ffe066'); }
    else { sfx('poof'); this.float(msg || 'Flare out', P.x, P.y - 90, '#d8d0ea'); }
  }

  updateWorld(dt) {
    const P = this.p, R = this.room;
    const target = this.camLock != null ? this.camLock : P.x - W / 2 + P.facing * 60;
    this.camX += (clamp(target, 0, Math.max(0, R.w - W)) - this.camX) * Math.min(1, dt * 5);
    // in the big fields the camera follows you into the distance too
    if (this.field) this.camZ += (clamp(P.z - CAMZ_OFF, 0, this.zb - 640) - this.camZ) * Math.min(1, dt * 4);
    this.updateEnemies(dt);
    this.trail.push({ x: P.x, y: P.y, z: P.z });
    if (this.trail.length > 12) this.trail.shift();
    // your partner trails a step behind you, whichever way you walk (and follows you into a doorway)
    const pp = this.partnerPos;
    const ddx = pp.x - P.x, ddz = pp.z - P.z, dist = Math.hypot(ddx, ddz * 1.3) || 1;
    const into = this.doorAnim && this.doorAnim.pto;
    const tx = into ? into.x : dist > 1 ? P.x + (ddx / dist) * 46 : P.x - P.facing * 46, tz = into ? into.z : P.z + (ddz / dist) * 35;
    pp.x += (tx - pp.x) * Math.min(1, dt * (into ? 7 : 6));
    pp.z += (clamp(tz, this.zmin, this.zmax) - pp.z) * Math.min(1, dt * (into ? 7 : 6));
    pp.y = this.trail[0].y;
    this.partnerSq += (1 - this.partnerSq) * Math.min(1, dt * 8);
    this.partnerFlip = (this.partnerFlip ?? P.facing) + clamp(P.facing - (this.partnerFlip ?? P.facing), -dt * 9, dt * 9);
    P.sq += (1 - P.sq) * Math.min(1, dt * 12);
    if (this.cut.elderFly != null && this.cut.elderFly >= 1) this.cut.elderFly = null;
    this.updateMovers();
  }

  updateEnemies(dt) {
    const P = this.p;
    for (const e of this.enemies) {
      if (e.dead || this.timeStop > 0) continue;   // (Time Stop freezes them mid-step)
      e.t += dt;
      if (e.stun > 0) { e.stun -= dt; continue; }
      if (this.mode !== 'explore') continue;
      if (e.cool > 0) e.cool -= dt;
      const dx = P.x - e.x, dy = (P.y - 30) - (e.y - e.h / 2), dz = P.z - e.z;
      const spots = !e.calm && !(e.cool > 0) && P.invuln <= 0 && !this.flareOn && this.enemySees(e, dx, dy, dz);
      if (e.ai === 'patrol') {
        const nx = e.x + e.dir * (e.fly ? 60 : 45) * dt;
        const footing = e.fly || !this.field || this.groundLevelAt(nx + e.dir * 12, e.z) === e.homeY;   // don't wander into a pond
        if (this.enemyFree(e, nx, e.z) && footing) e.x = nx; else e.dir = -e.dir;
        if (e.x > e.home + e.range) e.dir = -1;
        if (e.x < e.home - e.range) e.dir = 1;
        if (spots) this.enemySpots(e, dx);
      } else if (e.ai === 'alert') {
        // "!": a startled hop, then it comes running
        e.dir = Math.sign(dx) || e.dir;
        e.aiT -= dt;
        if (e.aiT <= 0) { e.ai = 'chase'; e.aiT = CHASE_TIME; e.spd = 0; e.anchor = null; }
      } else if (e.ai === 'chase') {
        // run you down across the floor, forward and back too, until you get away
        e.aiT -= dt;
        e.dir = Math.sign(dx) || e.dir;
        e.spd += ((e.fly ? 190 : 175) * (CHASE_SPEED[e.kind] || 1) - e.spd) * Math.min(1, dt * 4);
        const moved = this.enemySteer(e, dx, dz, e.spd, dt);
        if (e.fly) e.baseY += clamp((P.y - 40) - e.baseY, -1, 1) * 70 * dt;
        if (!e.fly && moved && (e.dustT = (e.dustT || 0) - dt) <= 0) { e.dustT = 0.18; this.dust(e.x - e.dir * 12, e.baseY, 1, e.dir, e.z); }
        // stuck, or just jiggling against a wall, if it hasn't really got anywhere for a while
        if (!e.anchor || Math.hypot(e.x - e.anchor.x, e.z - e.anchor.z) > 30) e.anchor = { x: e.x, z: e.z, t: 0 };
        else e.anchor.t += dt;
        const stuck = e.anchor.t > 1.5;
        // it gives up when you've run far enough, it has strayed too far from home, it can't get to you, or your
        // flare dazzles it
        const away = Math.hypot(dx, dz) > 720 || Math.abs(e.x - e.home) > 1100 || Math.abs(e.z - e.homeZ) > 900;
        if (e.aiT <= 0 || away || stuck || P.invuln > 0 || this.flareOn) { e.ai = 'lost'; e.cool = stuck ? 5 : 2.5; e.aiT = 0.9; }
      } else if (e.ai === 'lost') {
        // "?": where did Wick go? A look around, then home
        e.aiT -= dt;
        if (Math.floor(e.aiT * 3) !== Math.floor((e.aiT + dt) * 3)) e.dir = -e.dir;
        if (e.aiT <= 0) e.ai = 'return';
      } else if (e.ai === 'return') {
        const back = e.home - e.x, backZ = e.homeZ - e.z;
        e.dir = Math.sign(back) || e.dir;
        const moved = this.enemySteer(e, back, backZ, 70, dt);
        if (e.fly) e.baseY += clamp(e.homeY - e.baseY, -1, 1) * 40 * dt;
        // home again (or boxed in by a hedge: make this the new home)
        if ((Math.abs(back) < 6 && Math.abs(backZ) < 6) || !moved) { e.ai = 'patrol'; e.home = e.x; e.homeZ = e.z; if (e.fly) e.baseY = e.homeY; else e.homeY = e.baseY; }
        else if (spots) this.enemySpots(e, dx);   // walking home, it can still spot you again
      }
      e.flip = e.dir;
      e.vf = (e.vf ?? e.dir) + clamp(e.dir - (e.vf ?? e.dir), -dt * 9, dt * 9);   // paper-turn, not an instant flip
      const hop = e.ai === 'alert' ? Math.sin(Math.min(1, (ALERT_T - e.aiT) / 0.3) * Math.PI) * 18 : 0;
      e.y = (e.fly ? e.baseY + Math.sin(e.t * 2.5) * 12 : e.baseY - (HOPPERS[e.kind] ? Math.abs(Math.sin(e.t * 3)) * 34 : 0)) - hop;
    }
  }

  // Does an enemy see Wick? A long way in front of it, or close by on any side (it hears you), and not far above or below.
  // The Great Lantern's Gloom Ward shortens both.
  enemySees(e, dx, dy, dz) {
    if (Math.abs(dy) > 140) return false;
    const k = [1, 0.75, 0.55][this.lanternLv('ward')] ?? 0.55;
    const ahead = Math.sign(dx) === Math.sign(e.dir) && Math.abs(dx) < 400 * k && Math.abs(dz) < 260 * k;
    return ahead || Math.hypot(dx, dz * 1.2) < 160 * k;
  }

  enemySpots(e, dx) {
    e.ai = 'alert'; e.aiT = ALERT_T; e.dir = Math.sign(dx) || 1;
    sfx('spot');
    if (!this.s.flags.chase_tip) { this.s.flags.chase_tip = true; this.tip('"!" An enemy spotted you and is giving chase! Jump on it or hammer it first for a First Strike, or outrun it. If it catches you from behind, it strikes first!', 7); }
  }

  // Steps an enemy toward (dx, dz) at speed sp. If something is in the way it goes around: it tries turning a little,
  // then straight sideways, then backing off at an angle, to the side it picked last time first (so it doesn't dither).
  // Returns whether it got anywhere.
  enemySteer(e, dx, dz, sp, dt) {
    if (Math.abs(dx) < 4 && Math.abs(dz) < 4) return true;
    const a0 = Math.atan2(dz, dx), side = e.side || (dz >= 0 ? 1 : -1), Q = Math.PI / 2;
    for (const turn of [0, 0.75 * side, -0.75 * side, Q * side, -Q * side, 2.3 * side, -2.3 * side]) {
      const a = a0 + turn;
      if (this.enemyMove(e, e.x + Math.cos(a) * sp * dt, e.z + Math.sin(a) * sp * DEPTH_SPEED * dt)) {
        if (turn) e.side = Math.sign(turn);
        return true;
      }
    }
    return false;
  }

  // Puts an enemy at (x, z) if it can be there: clear of solids and, on foot, on floor it can step to.
  enemyMove(e, x, z) {
    z = clamp(z, this.zmin, this.zmax);
    if ((Math.abs(x - e.x) < 0.01 && Math.abs(z - e.z) < 0.01) || !this.enemyFree(e, x, z)) return false;
    if (!e.fly) {
      const fy = this.enemyFloor(x, z);
      if (fy == null || Math.abs(fy - e.baseY) > ENEMY_STEP) return false;
      e.baseY = fy;
    }
    e.x = x; e.z = z;
    return true;
  }

  // Where a walking enemy can stand: the floor at (x, z), or null over a pit or water, or right at the edge of a drop.
  enemyFloor(x, z) {
    if (!this.field) return this.groundLevelAt(x);
    const y = this.floorAt(x, z);
    if (y == null || this.liquidAt(x, z) != null) return null;
    for (const [ox, oz] of [[-12, 0], [12, 0], [0, -12], [0, 12]]) {
      const n = this.floorAt(x + ox, z + oz);
      if (n == null || Math.abs(n - y) > ENEMY_STEP) return null;
    }
    return y;
  }

  // Solid ground at x (with a little room to spare), or null at a gap. In a big field, also at depth z.
  groundLevelAt(x, z) {
    if (z == null || !this.field) {
      for (const g of this.room.ground) if (x >= g[0] + 10 && x <= g[1] - 10) return g[2];
      return null;
    }
    const y = this.floorAt(x, z);
    if (y == null) return null;
    for (const [dx, dz] of [[-10, 0], [10, 0], [0, -10], [0, 10]]) if (this.floorAt(x + dx, z + dz) !== y) return null;
    return y;
  }

  // Enemies walk around hedges, furniture and buildings too (flyers sail over the low stuff). Walkers leave floors and
  // hills to enemyFloor, which lets them take a step up or down.
  enemyFree(e, x, z) {
    return !this.solids.some(s => s.z0 != null && (e.fly || !(s.ref || s.floor)) && x > s.x - 16 && x < s.x + s.w + 16 && z > s.z0 - 14 && z < s.z1 + 14 && e.y > s.y + 4);
  }

  updateExplore(dt) {
    const P = this.p, R = this.room;
    const k = this.keys, pr = this.pressed;
    if (pr.has('menu')) { this.pauseMenu(); return; }
    if (pr.has('map')) { this.openMap(); return; }
    if (pr.has('hint')) { this.hint(); return; }
    if (this.fallT != null) { this.updateFall(); return; }
    this.updateMechanics(dt);
    // ← → walk sideways, ↑ ↓ walk into and out of the distance
    let ax = (k.has('right') ? 1 : 0) - (k.has('left') ? 1 : 0);
    let az = (k.has('up') ? 1 : 0) - (k.has('down') ? 1 : 0);
    const mag = Math.hypot(ax, az);
    if (mag > 1) { ax /= mag; az /= mag; }
    const jumpHeld = k.has('jump');
    // Roll Fold: hold R (or Shift) on the ground to fold into a tube (faster, and it fits under low rocks)
    if (this.has('roll') && k.has('roll') && P.onGround && !P.rolled && !this.carry) {
      P.rolled = true; P.h = RH; P.sq = 0.75; sfx('select'); this.dust(P.x, P.y, 4);
    } else if (P.rolled && !k.has('roll') && this.headroom()) {
      P.rolled = false; P.h = PH; P.sq = 1.15;
    }
    if (P.rolled) P.rollA += Math.hypot(P.vx, P.vz) * Math.sign(P.vx || P.facing) * dt / 15;
    const wading = P.onGround && P.support && P.support.water;   // slower through shallow water
    const maxSp = RUN * (P.rolled ? 1.35 : P.gliding ? 1.15 : 1) * (this.s.badges.equipped.includes('speedy') ? 1.2 : 1) * (wading ? 0.62 : 1);
    const acc = P.onGround ? GROUND_ACC : AIR_ACC;
    const approach = (v, to) => (v < to ? Math.min(to, v + acc * dt) : Math.max(to, v - acc * dt));
    if (P.knockT > 0 && !P.onGround) P.knockT -= dt;   // bounced out of a hazard: flying back to safe ground
    else {
      P.knockT = 0;
      P.vx = approach(P.vx, ax * maxSp);
      P.vz = approach(P.vz, az * maxSp * DEPTH_SPEED);
    }
    if (ax && Math.sign(ax) !== P.facing && P.onGround && Math.abs(P.vx) > 60) this.dust(P.x, P.y, 3, Math.sign(ax));
    if (Math.abs(ax) > 0.3) P.facing = Math.sign(ax);
    P.flip += Math.sign(P.facing - P.flip) * Math.min(Math.abs(P.facing - P.flip), dt * 10);
    P.coyote = P.onGround ? 0.1 : P.coyote - dt;
    P.jumpBuf = pr.has('jump') ? 0.12 : P.jumpBuf - dt;
    if (P.jumpBuf > 0 && P.coyote > 0) {
      if (P.rolled && !this.headroom()) { /* no room to jump under a low rock */ }
      else {
        if (P.rolled) { P.rolled = false; P.h = PH; }
        P.vy = -JUMP_V; P.sq = 1.18; sfx('jump'); this.dust(P.x, P.y, 3);
      }
      P.coyote = 0; P.jumpBuf = 0; P.cut = false;
    }
    if (!jumpHeld && P.vy < -300 && !P.cut) { P.vy *= 0.5; P.cut = true; }
    P.vy += GRAV * dt;
    P.gliding = this.has('glide') && !P.rolled && !P.onGround && jumpHeld && P.vy > 0;
    if (P.gliding) P.vy = Math.min(P.vy, GLIDE_FALL);
    // steam vents: stand on one as it blows to launch, or drift up through the steam
    for (const v of R.vents || []) {
      if (this.ventState(v).s !== 'blow' || Math.abs(P.x - v.x) > 30 || Math.abs(P.z - (v.z ?? 0)) > 34) continue;
      const base = this.surfaceAt(v.x, v.z ?? 0) - 18;
      if (P.y < base - 330 || P.y > base + 22) continue;
      if (P.onGround) { P.vy = -VENT_V; P.onGround = false; P.sq = 1.3; sfx('jump'); this.dust(P.x, P.y, 6); }
      else if (P.vy > -460) P.vy = Math.max(-460, Math.min(P.vy, 60) - 3800 * dt);
      P.cut = true;
    }
    this.applyUpdrafts(dt);
    P.vy = Math.min(P.vy, MAX_FALL);
    const wasGround = P.onGround, fallSpeed = P.vy, prevBottom = P.y;
    this.moveX(P.vx * dt);
    this.moveZ(P.vz * dt);
    this.moveY(P.vy * dt);
    if (P.onGround && !wasGround && fallSpeed > 380) { P.sq = 0.8; this.dust(P.x, P.y, 5); }
    const speed = Math.hypot(P.vx, P.vz), wl = this.liquidAt(P.x, P.z);
    // a splash going into water (or lava, or ink), and little ones wading through it
    if (wl != null && prevBottom < wl && P.y >= wl) this.splash(P.x, wl, P.z, R.hazard, Math.round(Math.min(14, 4 + fallSpeed / 60)));
    if (P.onGround && speed > (wading ? 60 : 220)) {
      P.dustT -= dt;
      if (P.dustT <= 0) {
        P.dustT = wading ? 0.24 : 0.16;
        if (wading) this.splash(P.x - P.facing * 8, wl ?? P.y, P.z, 'water', 2);
        else this.dust(P.x - P.facing * 10, P.y, 1, P.facing);
      }
    }
    // bounce pads
    for (const s of R.springs || []) {
      const top = this.surfaceAt(s.x, s.z ?? 0) - 30, sz = Math.abs(P.z - (s.z ?? 0)) < 30;
      const landed = sz && P.vy >= 0 && prevBottom <= top + 2 && P.y >= top && Math.abs(P.x - s.x) < 30;
      const stepped = sz && P.onGround && Math.abs(P.x - s.x) < 14 && Math.abs(P.y - (top + 30)) < 4;
      if (landed || stepped) {
        P.y = top; P.vy = -SPRING_V; P.onGround = false; P.sq = 1.28; P.cut = true;
        this.springAnim[s.x] = this.t;
        sfx('jump'); sfx('block');
      }
    }
    // a tear in the paper floor: step in one and down you go
    const tear = this.onTear();
    if (tear) { this.startFall(tear); return; }
    P.phase += speed * dt / 70;
    // (quietInv: the part of it that's just the moment of safety on coming into a room, which doesn't blink; it runs
    // down alongside, so anything that hurts Wick and sets invuln higher still blinks for all of it)
    if (P.invuln > 0) { P.invuln -= dt; if (P.quietInv > 0) P.quietInv -= dt; }
    // remember the last safe spot (solid ground all around) to come back to after a fall
    if (P.onGround && P.support && P.support.type === 'ground') {
      const ok = this.field ? [[-24, 0], [24, 0], [0, -24], [0, 24]].every(([dx, dz]) => this.floorAt(P.x + dx, P.z + dz) === P.y)
        : P.x - P.support.x > 24 && P.support.x + P.support.w - P.x > 24;
      if (ok) P.safe = { x: P.x, y: P.y, z: P.z };
    }
    if (P.onGround) P.hazardHits = 0;
    const lava = R.hazard === 'lava';
    // thorns, spikes, gears, Gloom goo and lava at the bottom of a gap: OUCH, and you bounce back out
    if (BOUNCY.has(R.hazard) && P.vy > 0 && this.floorAt(P.x, P.z) == null) {
      const hy = wl ?? R.hazardY ?? 500;
      if (P.y >= hy) { this.hazardBounce(R.hazard, hy); return; }
    }
    // deep water and ink: you sink out of sight just under the surface; a pit is a long way down
    if (P.y > (wl != null ? wl + 46 : H + 90)) {
      // (falling in a town canal or a garden pond just gets you wet)
      const hurt = !R.gentle && this.flag('prologue_done') && this.s.hero.hp > 1;
      if (hurt) this.s.hero.hp--;
      sfx('hurt');
      Object.assign(P, { x: P.safe.x, y: P.safe.y, z: P.safe.z ?? P.z, vx: 0, vy: 0, vz: 0, invuln: 1.2 });
      this.float(hurt ? (lava ? '-1 ♥  HOT!' : '-1 ♥') : R.hazard === 'water' ? 'Splash!' : 'Oops!', P.x, P.y - 80, '#ff9ab0');
      return;
    }
    // collectibles
    for (const it of R.collect || []) {
      if (this.s.collected[it.id]) continue;
      if (Math.abs(it.x - P.x) < 26 && Math.abs((it.z ?? 0) - P.z) < 32 && P.y - P.h < it.y && P.y > it.y - 40) { this.pickUp(it); return; }
    }
    // room edges
    const ex = R.exits || {};
    for (const [side, edge] of [['left', 6], ['right', R.w - 6]]) {
      const out = side === 'left' ? P.x < edge : P.x > edge;
      if (!out) continue;
      // in a big field, only part of the edge leads away (where the road goes off it)
      const e = ex[side] && (ex[side].z0 == null || (P.z >= ex[side].z0 && P.z <= ex[side].z1)) ? ex[side] : null;
      if (e && (!e.need || this.flag(e.need))) { this.leave(e); return; }
      P.x = side === 'left' ? edge : edge;
      P.vx = 0;
      if (e && e.need && this.t - (this.edgeTipT || -9) > 4) { this.edgeTipT = this.t; this.tip(e.needText || "You can't go that way yet."); }
    }
    // holding a bomb or a pot over your head: E or X throws it
    if (this.carry && (pr.has('act') || pr.has('hammer'))) { this.throwCarry(); pr.delete('act'); pr.delete('hammer'); }
    // hammer
    if (pr.has('hammer') && this.has('hammer') && P.hammerT <= 0 && !P.rolled && !this.carry) { P.hammerT = 0.34; P.swingDone = false; sfx('jump'); }
    if (P.hammerT > 0) {
      P.hammerT -= dt;
      if (!P.swingDone && P.hammerT < 0.2) { P.swingDone = true; if (this.hammerHit()) return; }
    }
    // partner ability
    if (pr.has('ability')) this.useAbility();
    if (this.fireball) { this.updateFireball(dt); if (this.mode !== 'explore') return; }
    // flare
    if (pr.has('flare')) {
      if (!this.has('flare')) this.tip("Wick doesn't know how to flare yet.", 3);
      else this.setFlare(!this.flareOn);
    }
    // interact (not while your hands are full)
    const it = this.carry ? null : this.nearest();
    this.prompt = it;
    if (it && pr.has('act')) { this.interact(it); return; }
    // enemies
    if (P.invuln <= 0) {
      const box = this.pbox();
      for (const e of this.enemies) {
        if (e.dead || e.stun > 0) continue;
        const eb = { x: e.x - 18, y: e.y - e.h, w: 36, h: e.h, z0: e.z - 16, z1: e.z + 16 };
        if (overlap(box, eb)) {
          const stomp = P.vy > 40 && prevBottom <= e.y - e.h + 14;
          const roll = !stomp && P.rolled && speed > 120 && !e.fly;
          const frozen = this.timeStop > 0;   // bump a frozen enemy: free First Strike
          const behind = Math.sign(e.x - P.x) === -P.facing && e.ai === 'chase';
          this.startFieldBattle(e, stomp ? 'jump' : roll || frozen ? 'hammer' : null, !stomp && !roll && !frozen && behind);
          return;
        }
      }
    }
    // story triggers
    for (const tr of R.triggers || []) {
      const key = `trig_${this.roomId}_${tr.id}`;
      if ((tr.once && this.s.flags[key]) || this.fired.has(tr.id) || (tr.when && !tr.when(this))) continue;
      if (P.x >= tr.x) {
        this.fired.add(tr.id);
        this.runScript(tr.script).then(ok => { if (ok && tr.once) this.s.flags[key] = true; this.saveSoon(); });
        return;
      }
    }
    if (this.light <= 0 && this.flag('prologue_done')) this.outOfLight();
  }

  pbox() { const P = this.p; return { x: P.x - PW / 2, y: P.y - P.h, w: PW, h: P.h, z0: P.z - PZ / 2, z1: P.z + PZ / 2 }; }

  // Walking into or out of the distance: only things with a depth (furniture, buildings, hedges, blocks) get in the way.
  moveZ(dz) {
    const P = this.p;
    if (!dz) return;
    P.z = clamp(P.z + dz, this.zmin, this.zmax);
    for (const s of this.solids) {
      if (s.z0 == null || !overlap(this.pbox(), s)) continue;
      // a low step (pop-up stairs, a little ledge): walk right up onto it
      if (P.onGround && s.type === 'ground' && P.y - s.y > 0 && P.y - s.y <= 26) {
        const oldY = P.y;
        P.y = s.y;
        if (!this.solids.some(o => o !== s && overlap(this.pbox(), o))) continue;
        P.y = oldY;
      }
      // walking into a crate shoves it along (at crate speed)
      const shoved = s.type === 'crate' && P.onGround && P.y > s.y + 8 && this.pushCrate(s.ref, 0, dz);
      P.z = dz > 0 ? s.z0 - PZ / 2 - 0.01 : s.z1 + PZ / 2 + 0.01;
      P.vz = shoved ? clamp(P.vz, -110, 110) : 0;
    }
  }

  moveX(dx) {
    const P = this.p;
    P.x += dx;
    for (const s of this.solids) {
      if (!overlap(this.pbox(), s)) continue;
      if (s.type === 'crate' && dx && P.onGround && P.y > s.y + 8 && this.pushCrate(s.ref, dx, 0)) {
        P.x = dx > 0 ? s.x - PW / 2 - 0.01 : s.x + s.w + PW / 2 + 0.01;
        P.vx = clamp(P.vx, -110, 110);
        continue;
      }
      if (P.onGround && s.type === 'ground' && P.y - s.y > 0 && P.y - s.y <= 26) {
        const oldY = P.y;
        P.y = s.y;
        if (!this.solids.some(o => o !== s && overlap(this.pbox(), o))) continue;
        P.y = oldY;
      }
      if (dx > 0) P.x = s.x - PW / 2 - 0.01;
      else if (dx < 0) P.x = s.x + s.w + PW / 2 + 0.01;
      P.vx = 0;
    }
  }

  moveY(dy) {
    const P = this.p;
    const prevBottom = P.y;
    P.y += dy;
    P.onGround = false;
    P.onPlat = false;
    for (const s of this.solids) {
      if (!overlap(this.pbox(), s)) continue;
      if (dy > 0) { P.y = s.y; P.vy = 0; P.onGround = true; P.support = s; }
      else if (dy < 0) { P.y = s.y + s.h + P.h + 0.01; P.vy = 0; this.bonk(s); }
    }
    if (dy >= 0) {
      for (const pl of this.plats()) {
        const slack = pl.mover != null ? 6 : 0.5;
        if (P.x + PW / 2 > pl.x && P.x - PW / 2 < pl.x + pl.w && P.z + PZ / 2 > pl.z0 && P.z - PZ / 2 < pl.z1
          && prevBottom <= pl.y + slack && P.y >= pl.y) {
          P.y = pl.y; P.vy = 0; P.onGround = true; P.onPlat = true; P.support = pl;
        }
      }
    }
  }

  async bonk(s) {
    if (s.type !== 'block') return;
    const b = s.ref;
    this.bumps[b.id] = this.t;
    if (this.s.opened[b.id]) { sfx('hurt'); return; }
    this.s.opened[b.id] = true;
    sfx('block');
    api('/api/event', { type: 'blocks' }).catch(() => {});
    for (let i = 0; i < 6; i++) this.parts.push({ x: b.x + 22, y: b.y, vx: (Math.random() - 0.5) * 200, vy: -200 - Math.random() * 200, life: 0.7, c: '#ffe066', g: 900 });
    if (b.give.starPiece || b.give.key || b.give.badge) {
      this.mode = 'script';
      await this.collect(b.give, b.x + 22, b.y - 10, false);
      if (this.mode === 'script') this.mode = 'explore';
    } else {
      this.collect(b.give, b.x + 22, b.y - 10, false);
    }
  }

  async pickUp(it) {
    this.s.collected[it.id] = true;
    for (let i = 0; i < 10; i++) this.parts.push({ x: it.x, y: it.y - 12, vx: (Math.random() - 0.5) * 240, vy: -Math.random() * 260, life: 0.7, c: '#ffe066', g: 400, star: true });
    if (it.kind === 'acorn') {
      sfx('chime');
      const n = this.collectedCount('acorn');
      this.float(`Golden acorn! (${n}/5)`, it.x, it.y - 50, '#ffe066');
      if (!this.questKnown('acorns')) this.tip('A golden acorn! Someone in the Grumbling Grove might want these.');
    } else if (it.kind === 'ember') {
      sfx('chime');
      const n = this.collectedCount('ember');
      this.float(`A little lost ember! (${n}/5)`, it.x, it.y - 50, '#ffb347');
      if (!this.questKnown('embers')) this.tip('A tiny lost ember! Somebody on Ember Peak must be missing this little one.');
    } else if (it.kind === 'book') {
      this.s.keyItems.push('book');
      sfx('fanfare');
      this.mode = 'script';
      await this.say(null, "You found 'Advanced Napping'! It's very overdue. Librarian Quill in Lumen Town will be thrilled.");
      if (this.mode === 'script') this.mode = 'explore';
    } else if (it.kind === 'gear') {
      await this.gearPickedUp(it);
    } else if (it.kind === 'crayon') {
      await this.crayonPickedUp(it);
    } else if (it.kind === 'page') {
      sfx('fanfare');
      const n = this.collectedCount('page');
      this.mode = 'script';
      await this.say(null, `📄 A Lost Page of the Book of Lumenfold! (${n} of 12)`);
      await this.say(null, PAGE_TEXT[it.id] || 'The words are too faded to read.');
      if (!this.questKnown('pages')) await this.say(null, 'Somebody at the Lumen Library would love to see this.');
      if (this.mode === 'script') this.mode = 'explore';
    }
    this.saveSoon();
  }

  // How far back a bush, pot, sign or lamp stands (rooms can say; otherwise a sensible default).
  thingZ(o, kind) {
    if (o.z != null) return o.z;
    if (kind === 'bush' || kind === 'pot') return Math.round(-30 + hashStr(o.id) * 110);
    return Z_DEFAULT[kind] ?? 0;
  }

  // Vines that only cover a doorway sit with that door; a vine wall reaches across the whole floor (null).
  vineZ(v) {
    if (v.solid !== false) return null;
    const d = (this.room.doors || []).find(dd => Math.abs(dd.x - (v.x + v.w / 2)) < 80);
    return d ? this.doorZ(d) - 6 : 0;
  }

  hammerHit() {
    const P = this.p, R = this.room;
    const hb = { x: P.facing > 0 ? P.x : P.x - 74, y: P.y - 62, w: 74, h: 62, z0: P.z - 34, z1: P.z + 34 };
    for (const s of this.solids) {
      if (s.type === 'crack' && overlap(hb, s)) {
        this.s.broken[s.ref.id] = true;
        sfx('crunch');
        this.cut.shake = 0.3;
        for (let i = 0; i < 18; i++) this.parts.push({ x: s.x + s.w / 2, y: s.y + Math.random() * s.h, vx: (Math.random() - 0.5) * 500, vy: -Math.random() * 400, life: 0.9, c: '#9d97a8', g: 1200 });
        this.buildSolids();
        this.saveSoon();
        if (s.ref.script) this.runScript(s.ref.script);   // (someone may have something to say about it)
        return false;
      }
      if (s.type === 'block' && overlap(hb, s)) { this.bonk(s); return false; }
      if (s.type === 'vine' && overlap(hb, s)) {
        sfx('guard');
        this.float('Boing!', s.x + s.w / 2, P.y - 90);
        this.tip('These vines are way too springy for a hammer. Fire would clear them, though!', 4);
        return false;
      }
    }
    // training dummies and levers can be whacked too
    for (const f of R.furniture || []) {
      if (f.kind !== 'dummy' || Math.abs(f.x - (P.x + P.facing * 37)) > 50 || Math.abs((f.z ?? FURN_Z.dummy) - P.z) > 60) continue;
      f.hitT = this.t;
      this.dummyHits = (this.t - (this.dummyLast || -9) < 1.2 ? this.dummyHits || 0 : 0) + 1;
      this.dummyLast = this.t;
      sfx('thwack');
      this.float(this.dummyHits > 1 ? `Thwack! ×${this.dummyHits}` : 'Thwack!', f.x, P.y - 110, '#ffe066');
      return false;
    }
    for (const sw of R.switches || []) {
      if (Math.abs(sw.x - (P.x + P.facing * 37)) < 45 && Math.abs(this.thingZ(sw, 'switch') - P.z) < 60) { this.pullSwitch(sw); return false; }
    }
    for (const b of [...(R.bushes || []).map(x => ({ ...x, kind: 'bush' })), ...(R.pots || []).map(x => ({ ...x, kind: 'pot' }))]) {
      if (this.cleared.has(b.id)) continue;
      const bz = this.thingZ(b, b.kind), y = this.surfaceAt(b.x, bz);
      if (!overlap(hb, { x: b.x - 26, y: y - 44, w: 52, h: 44, z0: bz - 24, z1: bz + 24 })) continue;
      this.cleared.add(b.id);
      sfx(b.kind === 'pot' ? 'crunch' : 'hit');
      for (let i = 0; i < 12; i++) this.parts.push({ x: b.x, y: y - 20, z: bz, vx: (Math.random() - 0.5) * 300, vy: -100 - Math.random() * 250, life: 0.7, c: b.kind === 'pot' ? '#c0744a' : '#5fae5c', g: 900 });
      this.loot(b.x, y, bz);
      return false;
    }
    // a whack unfolds a folded-up folk too
    for (const f of R.folks || []) {
      if (this.s.rescued[f.id] || !this.folkVisible(f)) continue;
      const fz = f.z ?? 0, fy = f.y ?? this.surfaceAt(f.x, fz);
      if (overlap(hb, { x: f.x - 24, y: fy - 44, w: 48, h: 44, z0: fz - 24, z1: fz + 24 })) { this.unfold(f); return false; }
    }
    for (const e of this.enemies) {
      if (e.dead || e.stun > 0) continue;
      if (overlap(hb, { x: e.x - 18, y: e.y - e.h, w: 36, h: e.h, z0: e.z - 16, z1: e.z + 16 })) {
        if (e.fly) continue;
        this.startFieldBattle(e, 'hammer', false);
        return true;
      }
    }
    return false;
  }

  useAbility() {
    const pid = this.s.partner, P = this.p;
    if (!pid) { this.tip('No partner yet! Partners join as the story goes on.', 3); return; }
    if (pid === 'moss') {
      if (!P.onGround) return;
      P.vy = -MOSS_V; P.onGround = false; P.coyote = 0; P.sq = 1.28; P.cut = true;
      this.partnerSq = 0.5;
      sfx('jump'); sfx('block');
      this.dust(P.x, P.y, 6);
      this.float('Moss Spring!', P.x, P.y - 90, '#8be07a');
    } else if (pid === 'hoot') {
      let found = 0;
      for (const b of this.room.blocks || []) {
        if (!b.hidden || this.s.revealed[b.id] || Math.abs(b.x + 22 - P.x) > 440) continue;
        this.s.revealed[b.id] = true;
        found++;
        for (let i = 0; i < 12; i++) this.parts.push({ x: b.x + 22, y: b.y + 22, vx: (Math.random() - 0.5) * 220, vy: (Math.random() - 0.5) * 220, life: 0.8, c: '#bfe6ff', g: 0, star: true });
      }
      this.peekT = this.t;
      if (found) { this.buildSolids(); sfx('chime'); this.float(`Hoo! Hoot spotted ${found} hidden block${found > 1 ? 's' : ''}!`, P.x, P.y - 100, '#ffe066'); this.saveSoon(); }
      else this.float('Hoot: Nothing hidden around here.', P.x, P.y - 100);
    } else if (pid === 'pebble') {
      const near = b => (b.solid ? Math.abs(clamp(P.x, b.solid[0], b.solid[0] + b.solid[2]) - P.x) : Math.abs(b.x - P.x)) < (b.solid ? 70 : 130);
      const tgt = (this.room.boulders || []).find(b => !this.broken(b.id) && near(b));
      if (!tgt) { this.float('Pebble: ...nothing to smash.', P.x, P.y - 100); return; }
      this.s.broken[tgt.id] = true;
      sfx('crunch');
      this.cut.shake = 0.5;
      const y = this.surfaceAt(tgt.x);
      for (let i = 0; i < 24; i++) this.parts.push({ x: tgt.x, y: y - 60 - Math.random() * 80, vx: (Math.random() - 0.5) * 600, vy: -Math.random() * 500, life: 1, c: '#8d867c', g: 1300 });
      this.float('SMASH!', tgt.x, y - 170, '#ffe066');
      this.buildSolids();
      this.saveSoon();
    } else if (pid === 'ember') {
      if (this.fireball) return;
      this.fireball = { x: P.x + P.facing * 22, y: P.y - (P.rolled ? 18 : 44), z: P.z, vx: P.facing * 560, life: 0.75 };
      this.partnerSq = 0.6;
      sfx('flare');
    } else if (pid === 'tick') this.timeStopStart();
    else if (pid === 'doodle') this.sketchStart();
  }

  // Ember's field fireball: lights braziers, burns vines, and gets a First Strike on enemies.
  updateFireball(dt) {
    const F = this.fireball, R = this.room;
    F.x += F.vx * dt;
    F.life -= dt;
    if (Math.random() < 0.6) this.parts.push({ x: F.x, y: F.y, z: F.z, vx: -F.vx * 0.1 + (Math.random() - 0.5) * 40, vy: -30 - Math.random() * 40, life: 0.35, c: Math.random() < 0.5 ? '#ffb347' : '#ffe066', g: -100 });
    const poof = () => {
      this.fireball = null;
      for (let i = 0; i < 8; i++) this.parts.push({ x: F.x, y: F.y, z: F.z, vx: (Math.random() - 0.5) * 200, vy: (Math.random() - 0.5) * 200, life: 0.4, c: '#ff8a3d', g: 0 });
    };
    if (R.braziers && !this.flag(R.brazierFlag)) {
      for (const b of R.braziers) {
        if (this.brazierLit.includes(b.n)) continue;
        const sy = this.surfaceAt(b.x);
        if (Math.abs(F.x - b.x) < 24 && Math.abs(F.z - this.thingZ(b, 'brazier')) < 45 && F.y > sy - 110 && F.y < sy) { poof(); this.lightBrazier(b); return; }
      }
    }
    for (const v of R.vines || []) {
      if (this.broken(v.id)) continue;
      const vz = this.vineZ(v);
      if (F.x > v.x - 6 && F.x < v.x + v.w + 6 && F.y > v.y && F.y < v.y + v.h && (vz == null || Math.abs(F.z - vz) < 60)) { poof(); this.burnVine(v); return; }
    }
    for (const e of this.enemies) {
      if (e.dead || e.stun > 0) continue;
      if (Math.abs(F.x - e.x) < 24 && Math.abs(F.z - e.z) < 30 && F.y > e.y - e.h - 10 && F.y < e.y + 6) { this.fireball = null; this.startFieldBattle(e, 'ember', false); return; }
    }
    const inside = s => F.x > s.x && F.x < s.x + s.w && F.y > s.y && F.y < s.y + s.h && (s.z0 == null || (F.z > s.z0 && F.z < s.z1));
    if (F.life <= 0 || this.solids.some(inside)) poof();
  }

  burnVine(v) {
    this.s.broken[v.id] = true;
    sfx('flare'); sfx('crunch');
    const top = Math.max(v.y, 0), h = Math.min(v.h, 300);
    for (let i = 0; i < 26; i++) this.parts.push({ x: v.x + Math.random() * v.w, y: top + Math.random() * h, vx: (Math.random() - 0.5) * 160, vy: -80 - Math.random() * 160, life: 0.9, c: ['#ff8a3d', '#ffe066', '#4f7a3a'][i % 3], g: 200 });
    this.float('The vines burned away!', v.x + v.w / 2, this.p.y - 100, '#ffb347');
    this.buildSolids();
    this.saveSoon();
  }

  // Brazier puzzle: light them in order, one at a time. Out of order and they ALL go out.
  lightBrazier(b) {
    const R = this.room;
    if (b.n !== this.brazierLit.length + 1) {
      this.brazierLit = [];
      this.brazierFlashT = this.t;
      sfx('hurt');
      this.float('Fsssss... they ALL went out!', b.x, this.surfaceAt(b.x) - 130, '#ffb0a0');
      this.tip('Ember: Too much at once! They all went out. Start with I, then go in order: I, II, III, IV.', 6);
      return;
    }
    this.brazierLit.push(b.n);
    sfx('flare');
    sfx('chime');
    this.float(['', 'I', 'II', 'III', 'IV', 'V'][b.n] + '!', b.x, this.surfaceAt(b.x) - 130, '#ffe066');
    if (this.brazierLit.length < R.braziers.length) return;
    this.s.flags[R.brazierFlag] = true;
    this.buildSolids();
    this.saveSoon();
    this.runScript(R.brazierScript);
  }

  leave(exit) {
    if (exit.script) { this.runScript(exit.script); return; }
    this.mode = 'transition';
    this.goto(exit.to, exit.x, exit.z ?? this.p.z);   // walking off the edge keeps you at the same depth
  }

  interactables() {
    const R = this.room, list = [];
    const at = (type, o, z, label, extra) => list.push({ type, x: o.x, y: o.y ?? this.surfaceAt(o.x, z), z, ref: o, label, ...extra });
    for (const n of R.npcs || []) if (!n.show || n.show(this)) at('npc', n, n.z ?? 0, n.label || 'Talk');
    for (const s of R.signs || []) at('sign', s, this.thingZ(s, 'sign'), 'Read');
    for (const l of this.lampList()) list.push({ type: 'lamp', x: l.x, y: this.surfaceAt(l.x, l.z), z: l.z, label: 'Save' });
    for (const ch of R.chests || []) if (!this.s.opened[ch.id] && (!ch.needBroken || this.broken(ch.needBroken))) at('chest', ch, ch.z ?? 0, 'Open');
    if (R.braziers && !this.flag(R.brazierFlag)) for (const b of R.braziers) at('brazier', b, this.thingZ(b, 'brazier'), 'Look');
    for (const d of R.doors || []) {
      const label = d.exit ? `Leave: ${d.label}` : d.style === 'front' ? `Go: ${d.label}` : d.label ? `Enter: ${d.label}` : 'Enter';
      const dz = this.doorZ(d);
      list.push({ type: 'door', x: d.x, y: this.surfaceAt(d.x, dz), z: dz, ref: d, label });
    }
    for (const sh of R.shrines || []) at('shrine', sh, this.thingZ(sh, 'shrine'), 'Examine');
    for (const s of R.shops || []) at('shop', s, this.thingZ(s, 'shop'), s.label || 'Enter');
    for (const b of R.boards || []) at('board', b, this.thingZ(b, 'board'), 'Quest Board');
    for (const f of R.fish || []) at('fish', f, f.z ?? 0, 'Fish');
    for (const f of R.furniture || []) if (f.label) at('thing', f, f.z ?? FURN_Z[f.kind] ?? 60, f.label);
    for (const sw of R.switches || []) at('switch', sw, this.thingZ(sw, 'switch'), 'Pull');
    this.mechInteractables(list);
    return list;
  }

  // Lever puzzles: pull them in the right order. One wrong pull and they all snap back.
  pullSwitch(sw) {
    const R = this.room, pz = R.puzzle;
    if (!pz || this.flag(pz.flag)) { sfx('select'); this.float('Click.', sw.x, this.surfaceAt(sw.x) - 110); return; }
    if (this.leverState.includes(sw.id)) return;
    if (pz.order[this.leverState.length] === sw.id) {
      this.leverState.push(sw.id);
      sfx('chime');
      this.float(`Click! (${this.leverState.length}/${pz.order.length})`, sw.x, this.surfaceAt(sw.x) - 110, '#ffe066');
      if (this.leverState.length === pz.order.length) {
        this.s.flags[pz.flag] = true;
        this.buildSolids();
        this.saveSoon();
        this.runScript(pz.flag);
      }
    } else {
      this.leverState = [];
      sfx('hurt');
      this.cut.shake = 0.3;
      this.float('CLUNK! They all snapped back.', sw.x, this.surfaceAt(sw.x) - 110, '#ffb0a0');
      if (pz.hint) this.tip(`Hint: ${pz.hint}`, 6);
    }
  }

  // The closest thing you could talk to / open / read, sideways and in depth.
  nearest() {
    const P = this.p;
    let best = null, bd = 1e9;
    for (const it of this.interactables()) {
      const dx = Math.abs(it.x - P.x), dy = Math.abs(it.y - P.y), dz = Math.abs(it.z - P.z);
      const reach = it.type === 'npc' ? 80 : it.type === 'door' ? 75 : it.type === 'tear' ? 75 : 62;
      const side = it.type === 'tear' ? 84 : 58;   // you can't stand on a tear, so its prompt reaches further
      if (dx < side && dy < 90 && dz < reach && dx + dz * 0.7 < bd) { bd = dx + dz * 0.7; best = it; }
    }
    return best;
  }

  async interact(it) {
    const P = this.p;
    P.vx = 0; P.vz = 0;
    if (await this.mechInteract(it)) { this.saveSoon(); return; }
    if (it.type === 'npc') {
      this.talkTo = it.ref;
      await this.runScript(npcHook(this, it.ref) || it.ref.talk);
    } else if (it.type === 'thing') {
      const f = it.ref;
      if (f.kind === 'piano') sfx('piano');
      await this.runScript(f.script || [['narrate', f.say || '...']]);
    } else if (it.type === 'switch') this.pullSwitch(it.ref);
    else if (it.type === 'sign') await this.runScript(it.ref.script || [['narrate', it.ref.text]]);
    else if (it.type === 'lamp') {
      this.healAll();
      this.s.lamp = { room: this.roomId, x: it.x, z: Math.round(P.z) };
      this.s.areaLamps[this.room.area] = { room: this.roomId, x: it.x, z: Math.round(P.z) };
      this.s.opened[`lamp_${this.roomId}_${it.x}`] = true;
      P.safe = { x: it.x, y: it.y, z: P.z };
      this.saveNow();
      sfx('save');
      this.float('Saved! Fully healed ♥', it.x, it.y - 130, '#ffe066', it.z);
    } else if (it.type === 'chest') {
      this.s.opened[it.ref.id] = true;
      sfx('door');
      this.mode = 'script';
      await this.collect(it.ref.give, it.x, it.y - 60, true);
      if (this.mode === 'script') this.mode = 'explore';
    } else if (it.type === 'door') {
      const d = it.ref;
      if (d.need && !this.flag(d.need) && d.lockScript) { await this.runScript(d.lockScript); return; }
      if (d.need && !this.flag(d.need)) { await this.runScript([['narrate', d.needText || "It won't open."]]); return; }
      if (d.needAbility && !this.has(d.needAbility)) { await this.runScript([['narrate', d.needText || "You can't get in there yet."]]); return; }
      if (d.needBroken && !this.broken(d.needBroken)) { await this.runScript([['narrate', d.needText || 'Something blocks the way.']]); return; }
      if (d.needSeal && !this.broken(d.needSeal)) { await this.trySeal(d); return; }
      await this.enterDoor(d);
    } else if (it.type === 'brazier') {
      const rune = ['', 'I', 'II', 'III', 'IV', 'V'][it.ref.n];
      await this.runScript([['narrate', this.s.partner === 'ember'
        ? `A cold brazier marked '${rune}'. Press C to throw Ember's fireball at it. Remember: in order, one at a time!`
        : `A cold brazier marked '${rune}'. Ember's Fire Toss could light it. (Switch partners: ESC → Party & Bond.)`]]);
    } else if (it.type === 'shrine') await this.runScript(it.ref.script);
    else if (it.type === 'shop') await this.shopDoor(it.ref.kind);
    else if (it.type === 'board') await this.questBoard();
    else if (it.type === 'fish') this.startFishing(it.ref);
    this.saveSoon();
  }

  async trySeal(door) {
    const seal = (this.room.seals || []).find(s => s.id === door.needSeal);
    const need = seal ? seal.need : 7200;
    const have = this.stat('focus_seconds');
    const hrs = s => `${(s / 3600).toFixed(1)} hours`;
    if (have >= need) {
      this.mode = 'script';
      this.cut.flash = 1;
      sfx('fanfare');
      this.s.broken[door.needSeal] = true;
      await this.say(null, `The Gloom Seal shatters! ${hrs(need)} of real focus was enough to break it. The way is open!`);
      this.mode = 'explore';
      this.saveNow();
      return;
    }
    await this.runScript([['narrate', `A Gloom Seal. It only breaks for someone who has focused for ${hrs(need)} in total. The Hero of Homework is at ${hrs(have)} so far. Keep studying and come back!`]]);
  }

  // ---------------------------------------------------------------- HUD
  updateHud() {
    if (!this.s) return;
    const h = this.s.hero;
    const pid = this.s.partner;
    const ps = pid ? this.s.partners[pid] : null;
    const sess = this.session;
    const free = !this.flag('prologue_done');
    const brk = sess && sess.mode === 'break' ? `<span class="hud-pill break">☕ ${fmt(sess.break_bank)} of break left</span>` : '';
    const nCh = (this.chests.study || 0) + (this.chests.golden || 0);
    const goal = this.mode === 'battle' ? '' : objective(this);
    const html = `<div class="hud-left"><span class="hud-pill">Lv ${h.lvl}</span><span class="hud-pill hp">♥ ${h.hp}/${h.maxHp}</span>
      <span class="hud-pill fp">✿ ${h.fp}/${h.maxFp}</span>${ps ? `<span class="hud-pill">${esc(PARTNERS[pid].name)} ♥ ${ps.hp}/${ps.max} · 💛${this.bondLv(pid)} · C: ${PARTNERS[pid].field.name}</span>` : ''}</div>
      <div class="hud-obj">${goal ? `🎯 ${esc(goal)}` : ''}</div>
      <div class="hud-right">${brk}${nCh ? `<span class="hud-pill chest" title="Chests from studying: ESC → Study chests">🎁 ${nCh}</span>` : ''}${this.mechHud()}
      ${this.flareOn ? `<span class="hud-pill light" title="Your flare burns 1 ✦ every ${this.flareEvery()} seconds. Press F to put it out.">🔥 Flare · F to put out</span>` : ''}
      <span class="hud-pill light" title="Light burns while you explore: 1 ✦ every ${DRAIN_EVERY} seconds">✦ ${this.light}${free ? ' <small>(free in the prologue)</small>' : ''}</span>
      <span class="hud-pill">🪙 ${this.walletCache.coins}</span><span class="hud-pill">⭐ ${this.walletCache.star_pieces}</span></div>`;
    if (html !== this.hudKey) { this.hudKey = html; this.hudEl.innerHTML = html; this.hudMeasure = true; }
    const full = this.battle.active || this.mode === 'map' || this.mode === 'minigame';   // full-screen views hide the HUD and key help
    this.hudEl.style.display = full ? 'none' : '';
    this.helpEl = this.helpEl || this.root.querySelector('.g-help');
    this.helpEl.style.display = full ? 'none' : '';
  }

  // ---------------------------------------------------------------- drawing
  draw() {
    const c = this.c;
    c.setTransform(this.scale, 0, 0, this.scale, 0, 0);
    c.clearRect(0, 0, W, H);
    if (this.battle.active) this.battle.draw(c, this.t);
    else if (this.mode === 'map') this.mapScreen.draw(c, this.t);
    else if (this.mode === 'minigame' && this.mini) this.drawMinigame(c);
    else if (this.room) {
      this.drawRoom(c);
      if (this.mode === 'fish') this.drawFishing(c);
      // Chapter 4: the Great Lantern's beam, and Tick's frozen time
      if (this.cut.beam != null) this.drawBeam(c, view(Math.round(this.camX), HZ, W, { camZ: this.camZ || 0, zb: this.zb }));
      this.drawTimeStop(c);
      // the Bonus Chapter: the paper airplane with Doodle's letter
      this.drawMarginOver(c);
    }
    if (this.iris) {
      const p = Math.min(1, (this.t - this.iris.t0) / this.iris.dur);
      const V = view(Math.round(this.camX), HZ, W, { camZ: this.camZ || 0, zb: this.zb });
      const cx = V.x(this.p.x, this.p.z) - Math.round(this.camX), cy = V.y(this.p.y - 30, this.p.z);
      c.save(); c.fillStyle = '#0c0818';
      c.beginPath(); c.rect(0, 0, W, H); c.arc(cx, cy, Math.max(1, (1 - p) * 700), 0, Math.PI * 2, true); c.fill('evenodd');
      c.restore();
    }
    if (this.fadeA > 0) { c.fillStyle = `rgba(12,8,24,${this.fadeA})`; c.fillRect(0, 0, W, H); }
  }

  // The highest floor (ground, a block, furniture or a platform) under (x, z), at or below y: where a shadow falls.
  floorBelow(x, y, z = 0) {
    let best = null;
    for (const s of this.solids) {
      if (x < s.x || x > s.x + s.w || s.y < y - 2 || (s.z0 != null && (z < s.z0 || z > s.z1))) continue;
      if (best == null || s.y < best) best = s.y;
    }
    for (const p of this.plats()) if (x >= p.x && x <= p.x + p.w && z >= p.z0 && z <= p.z1 && p.y >= y - 2 && (best == null || p.y < best)) best = p.y;
    return best;
  }

  // A soft round shadow on the floor under someone: it shrinks the higher they are, so you can see where you'll land.
  // Over a gap it falls on whatever is down there (thorns, water, lava...), so you can still line things up.
  floorShadow(c, V, x, y, z, w) {
    const fy = this.groundUnder(x, y, z);
    if (fy == null) return;
    const k = Math.max(0.35, 1 - (fy - y) / 320);
    atDepth(c, V, x, fy, z, () => shadow(c, 0, 0, w * k, 0.26 * k));
  }

  // The floor under a spot, or over a gap the bottom of it (if there's anything down there to land on or in).
  groundUnder(x, y, z) {
    const fy = this.floorBelow(x, y, z);
    if (fy != null) return fy;
    const bottom = this.room.hazardY ?? 500;
    return (this.room.hazard || this.hasPit) && y <= bottom ? bottom : null;
  }

  // A pulsing gold ring on the ground under a floating pickup: Wick is at the same depth as it.
  depthRing(c, V, x, y, z, t) {
    const fy = this.groundUnder(x, y, z);
    if (fy == null) return;
    const r = 24 + Math.sin(t * 6) * 3;
    atDepth(c, V, x, fy, z, () => {
      c.strokeStyle = 'rgba(255,224,102,0.95)'; c.lineWidth = 3;
      c.beginPath(); c.ellipse(0, 0, r, r * 0.3, 0, 0, Math.PI * 2); c.stroke();
    });
  }

  // Far things are drawn first. Standing on top of a platform, a table or a hill puts you in front of it, not behind,
  // and so does standing beside something big (a hill, a house) on the side the camera looks from, close enough for its
  // side wall to reach you on screen. Folks on the same hill keep their order.
  depthKey(x, y, z, boxes, V) {
    let k = z;
    for (const b of boxes) {
      if (z < b.z0 - 3 || z > b.z1 + 3) continue;
      // (a house up on a hill is drawn at the hill's front, a tiny step back for each bit of depth along the hill, so
      // whoever stands on it or beside it goes just in front of that)
      const front = b.hill ? b.hill.z0 - 0.5 + (b.z0 - b.hill.z0) * 1e-4 - 5e-5 + (z - b.z0) * 1e-7 : b.z0 - 0.5 + (z - b.z0) * 1e-4;
      // on top of it: drawn after it (but rolling under a low rock, its front is nearer than you are, so it hides you
      // and you show through it as a ghost: drawing you in front of it looked like you were rolling past outside it)
      if (x >= b.x && x <= b.x + b.w) { if (y <= b.y + 4) k = Math.min(k, front); }
      else if (b.big && V && this.besideWall(x, z, b, V)) k = Math.min(k, front);
    }
    return k;
  }

  // A big box's side wall runs from its front edge to its back edge, which the view draws closer to the middle of
  // the screen. Only something within that stretch (with a person's width to spare) needs drawing after the box:
  // anything further out never overlaps it, and pulling that forward would put it in front of whatever stands
  // between it and the box's front (a cottage between you and a hill off to the side, say).
  besideWall(x, z, b, V) {
    const k = V.s(Math.min(b.z1, this.zb)) / V.s(z), reach = 40;
    if (x < b.x && V.cx < b.x) return x + reach > V.cx + (b.x - V.cx) * k;
    if (x > b.x + b.w && V.cx > b.x + b.w) return x - reach < V.cx + (b.x + b.w - V.cx) * k;
    return false;
  }

  // An island out in a pool (or a gap) is drawn after the floor, so the ground in front of the pool has to hide the
  // bit of it below the pool's near edge: otherwise its foot pokes out over the ground in front (the Lumen Park
  // pond's island did that, and Ember Road's lava islands too). Its cliff face also stops at the lava or water.
  inPool(c, V, tr, hy, fn) {
    const R = this.room, base = tr.base ?? 450, cx = (tr.x0 + tr.x1) / 2, cz = (tr.z0 + tr.z1) / 2;
    const hole = base > 452 && (R.holes || []).find(h => cx >= h[0] && cx <= h[1] && cz >= h[2] && cz <= h[3]);
    if (!hole) return fn(tr);
    const rimY = this.groundLevelAt(cx, hole[2] - 2) ?? 450;
    c.save();
    c.beginPath(); c.rect(-1e5, -1e5, 2e5, V.y(rimY, hole[2]) + 1e5); c.clip();
    fn(R.hazard && base > hy ? { ...tr, base: Math.max(tr.y + 1, hy) } : tr);
    c.restore();
  }

  // The room as a paper diorama: flat paper folks walking around on a floor with real depth.
  drawRoom(c) {
    const R = this.room, t = this.t, P = this.p;
    const theme = this.theme();
    const camX = Math.round(this.camX);
    const V = view(camX, HZ, W, { camZ: this.camZ || 0, zb: this.zb });
    const surf = (x, z) => this.surfaceAt(x, z);
    const groundAt = (x, z) => this.groundLevelAt(x, z);
    c.save();
    if (this.cut.shake) c.translate((Math.random() - 0.5) * 10 * this.cut.shake, (Math.random() - 0.5) * 10 * this.cut.shake);
    // the conversation camera leans in on Wick and whoever he's talking to
    const k = this.talkK, tk = this.talkTo;
    const wx = V.x(P.x, P.z) - camX, wy = V.y(P.y - 70, P.z);
    const fx = tk ? (wx + V.x(tk.x, tk.z ?? 0) - camX) / 2 : wx, fy = wy;
    c.save();
    if (k > 0.002) { const zb = 1 + 0.05 * k; c.translate(fx, fy - 25 * k); c.scale(zb, zb); c.translate(-fx, -fy); }
    // the scenery beyond the floor moves so its horizon meets the floor's far edge (which climbs as you walk into a field)
    c.translate(0, Math.round(V.y(450, this.zb) - 403));
    // the big landmarks of Lumenfold stand on the horizon, where they really are on the map
    const horizon = mood => drawLandmarks(c, AREAS[R.area], camX, t, mood, { shards: this.cut.townLit ? 5 : this.s.shards, calm: this.flag('ch3_done') });
    // ("freed": after Count Dusk; in the Margin, once that place's color is back)
    if (!drawBackdrop2(c, theme, camX, W, H, t, { horizon, freed: R.faded ? this.marginColored(R) : this.flag('ch4_done') })) {
      drawBackdrop(c, theme, camX, W, H, t, {
        gloom: R.gloomUntil && !this.flag(R.gloomUntil), bright: this.flag('ch2_done'), calm: this.flag('ch3_done'),
        lit: this.cut.townLit ? 3 : this.flag('prologue_done') ? 1 + this.s.shards : 0, horizon,
      });
    }
    c.restore();
    c.save();
    if (k > 0.002) { const z = 1 + 0.16 * k; c.translate(fx, fy - 70 * k); c.scale(z, z); c.translate(-fx, -fy); }
    c.translate(-camX, 0);
    // ---- the floor, and what's painted or lying on it
    if (R.interior) drawInteriorShell(c, V, R, t);
    // gaps in the floor: water, lava and so on, or else a dark chasm (never a see-through void)
    // (a room can set how far below the floor its water sits: a town canal is nearly full)
    const pit = R.hazard || (this.hasPit ? 'pit' : null), hy = R.hazardY ?? 500;
    if (pit || this.field) drawHazard3d(c, V, R, t, hy, pit, matFor(theme, R));
    // where you can wade, the deep water (a river you can't cross on foot) shows darker
    if (R.wade) {
      c.fillStyle = 'rgba(16,40,96,0.32)';
      for (const h of R.holes || []) {
        if (h[4] !== 'deep') continue;
        const z0 = Math.max(h[2], V.camZ - 300), z1 = Math.min(h[3], this.zb);
        if (z1 <= z0) continue;
        c.beginPath(); c.moveTo(V.x(h[0], z1), V.y(hy, z1)); c.lineTo(V.x(h[1], z1), V.y(hy, z1)); c.lineTo(V.x(h[1], z0), V.y(hy, z0)); c.lineTo(V.x(h[0], z0), V.y(hy, z0)); c.fill();
      }
    }
    drawFloor(c, V, R, this.landRects, theme, t, pit ? hy : null);
    // paved squares and roads, painted on whatever ground they cross
    for (const q of R.plazas || []) drawPlaza(c, V, q, this.groundLevelAt((q[0] + q[1]) / 2, (q[2] + q[3]) / 2) ?? 450);
    for (const rd of R.roads || []) drawRoad(c, V, rd, this.groundLevelAt((rd[0] + rd[2]) / 2, (rd[1] + rd[3]) / 2) ?? 450, R.roadColor);
    for (const s of this.exitSigns || []) {   // the road off a big field's side edge
      const seg = this.exitRoad(s);
      drawRoad(c, V, seg, this.groundLevelAt((seg[0] + seg[2]) / 2, seg[1]) ?? 450, R.roadColor);
    }
    this.drawExitArrows(c, V, t);
    for (const f of R.furniture || []) if (f.kind === 'rug') drawRug(c, V, f.x, surf(f.x, ((f.z0 ?? -40) + (f.z1 ?? 70)) / 2), f);
    this.drawMechFloor(c, V, t);
    // shadows under floating platforms and blocks, so you can line up a jump
    for (const p of this.staticPlats) {
      if (p.full) continue;
      const gy = groundAt(p.x + p.w / 2, (p.z0 + p.z1) / 2);
      if (gy != null) drawDropShadow(c, V, p.x, p.w, p.z0, p.z1, gy, 0.16);
    }
    for (const b of R.blocks || []) {
      if (b.hidden && !this.s.revealed[b.id]) continue;
      const bz = b.z ?? 0, gy = groundAt(b.x + 22, bz);
      if (gy != null) drawDropShadow(c, V, b.x, 44, bz - 22, bz + 22, gy, 0.2);
    }
    // the old rooms' scenery stands in a row at the back and the front; the big fields scatter theirs (further down)
    const decor = this.field ? null : decorFor(R, this.roomId, theme, x => this.groundLevelAt(x));
    if (decor) drawDecor(c, V, decor.back, GZ1 - 15, x => this.groundLevelAt(x), t);
    // (in a big field you can walk behind houses and archways, so those join the far-to-near list instead)
    for (const pr of R.props || []) if ((pr.kind === 'building' || pr.kind === 'house') && pr.z == null && !this.field) this.drawProp(c, V, pr, t);
    for (const d of R.doors || []) {
      if (d.style && d.style !== 'back' && d.style !== 'front' && !d.exit) continue;
      // a path out in a field: the path is painted on the floor, and its arch stands among everything else
      if (this.field && !d.style && !d.exit) drawPathDoor(c, V, d.x, surf(d.x, d.z ?? GZ1 - 20), { z: d.z ?? GZ1, part: 'floor' });
      else this.drawDoor3d(c, V, d, surf(d.x, this.doorZ(d)), t);
    }
    // ---- walls and bridges that reach across the whole floor (a big field's walls stand among everything else instead)
    const walls = [];
    // (y0..y1: how high it reaches, when known, for seeing whether it stands between the camera and Wick; fade: how
    // see-through it goes then)
    const wall = (x0, x1, o, fn, y0 = -60, y1 = 460, fade = 0.65, ghost = 1) => (this.field ? walls.push({ x0, x1, z0: o.z0, z1: o.z1, y0, y1, fn, fade, ghost }) : fn());
    for (const w of R.walls || []) {
      if (w[4] == null && this.overCrack(w[0], w[0] + w[2])) continue;
      const o = this.wallZ(w[4], w[5], w[0], w[0] + w[2]);
      wall(w[0], w[0] + w[2], o, () => drawWall3d(c, V, w[0], w[1], w[2], w[3], theme, R, o.z0, o.z1), w[1], w[1] + w[3]);
    }
    // (rolling under a low rock, Wick is behind its front: it stays solid, and he shows through it as a faint ghost)
    for (const [x, w, z0, z1] of R.low || []) { const o = this.wallZ(z0, z1, x, x + w), y1 = surf(x + w / 2) - LOW_GAP; wall(x, x + w, o, () => drawLowRock3d(c, V, x, y1, w, theme, o.z0, o.z1), -60, y1, 0, 0.7); }
    for (const g of R.gates || []) {
      const o = this.wallZ(g.z0, g.z1, g.x - 10, g.x + g.w + 10), open = this.flag(g.flag);
      wall(g.x - 10, g.x + g.w + 10, o, () => {
        drawLowRock3d(c, V, g.x - 10, g.top, g.w + 20, theme, o.z0, o.z1);
        if (!open) drawGate3d(c, V, g.x, g.top, g.w, surf(g.x) - g.top, o.z0 != null ? o.z0 + 20 : undefined, o.z1 != null ? o.z1 - 20 : undefined);
      }, -60, open ? g.top : surf(g.x), 0.2);
    }
    for (const ck of R.cracks || []) {
      if (this.broken(ck.id)) continue;
      const o = this.wallZ(ck.z0, ck.z1, ck.x, ck.x + ck.w), box = this.crackBox(ck);
      wall(ck.x, ck.x + ck.w, o, () => drawCrack3d(c, V, ck.x, box.y, ck.w, box.h, theme, o.z0, o.z1), box.y, box.y + box.h);
    }
    for (const b of R.boulders || []) {
      if (!b.solid || this.broken(b.id)) continue;
      const [bx, by, bw, bh] = b.solid, o = this.wallZ(b.z0, b.z1, bx, bx + bw);
      wall(bx, bx + bw, o, () => box(c, V, bx, by, bw, bh, o.z0 ?? GZ0, o.z1 ?? this.zb, { top: '#b9b3a8', front: ['#a49e94', '#6f6a62'], side: '#7d776e' }), by, by + bh);
    }
    for (const s of this.solids) if (s.ridge) wall(s.x, s.x + s.w, s, () => drawWall3d(c, V, s.x, s.y, s.w, s.h, theme, R, s.z0, s.z1), s.y, s.y + s.h);
    this.drawMechWalls(c, V, t, wall);
    for (const p of this.staticPlats) if (p.full) drawPlat3d(c, V, p.x, p.y, p.w, theme, false, p.z0, p.z1);
    (R.movers || []).forEach((m, i) => {
      const mp = this.moverPos[i];
      if (!mp) return;
      glowDot(c, mp.x + m.w / 2, mp.y + 26, 46, '255,140,60', 0.3);
      drawPlat3d(c, V, mp.x, mp.y, m.w, theme, false, m.z0 ?? GZ0 + 10, m.z1 ?? GZ1 - 10);
    });
    if (R.hidden && this.flareOn) for (const p of R.hidden) drawPlat3d(c, V, p[0], p[1], p[2], theme, true, p[3] ?? GZ0 + 10, p[4] ?? GZ1 - 10);
    // ---- everything standing on the floor, far to near (just what's on screen: the big fields hold a lot)
    const boxes = [...this.staticPlats.filter(p => !p.full), ...this.solids.filter(s => s.z0 != null && !s.floor), ...(R.xplats ? this.xplatList() : [])];
    // (a depth key only needs the boxes reaching the depth it's asked about, so they're sorted into strips 200 deep)
    const strips = new Map();
    for (const b of boxes) {
      for (let k = Math.floor((b.z0 - 3) / 200); k <= Math.floor((b.z1 + 3) / 200); k++) { let s = strips.get(k); if (!s) strips.set(k, s = []); s.push(b); }
    }
    const boxesAt = z => strips.get(Math.floor(z / 200)) || [];
    const list = [];
    const add = (key, ord, fn) => list.push({ key, ord, fn });
    // (something you've just walked past is still poking up into the bottom of the view until it's well behind the
    // camera, and things up close are drawn big, so they get more room at the sides too; top, when known, is how high
    // it reaches, so whatever has already slid below the bottom of the view can be skipped)
    const seen = (x, z, pad = 280, top = null) => {
      const zr = z - V.camZ;
      if (zr < -660 || zr > 3400) return false;
      if (top != null && zr < -140 && V.y(top, z) > H + 5) return false;
      const sx = V.x(x, z) - camX, p = pad * Math.max(1, V.s(z));
      return sx > -p && sx < W + p;
    };
    // things you've walked past fade away as they slide off the bottom of the view, instead of hanging huge in front
    const nearFade = z => { const zr = z - V.camZ; return zr >= -60 ? 1 : Math.max(0.15, 1 + (zr + 60) / 320); };
    const faded = (a, fn) => { if (a >= 1) return fn(); const ga = c.globalAlpha; c.globalAlpha = ga * a; fn(); c.globalAlpha = ga; };
    // and anything tall drawn after Wick (a house or a tree between him and the camera) goes see-through where it
    // covers him: the more of him it hides, the fainter it gets
    const wickKey = this.depthKey(P.x, P.y, P.z, boxesAt(P.z), V);
    const wk = V.s(P.z), wsx = V.x(P.x, P.z), wy0 = V.y(P.y - P.h - 10, P.z), wy1 = V.y(P.y, P.z);
    let covered = 0;   // how much of Wick the most-covering of those hides (0..1)
    const seeThru = (key, x0, x1, y0, y1) => {
      if (key >= wickKey) return 1;
      const ox = Math.min(x1, wsx + 18 * wk) - Math.max(x0, wsx - 18 * wk), oy = Math.min(y1, wy1) - Math.max(y0, wy0);
      if (ox <= 0 || oy <= 0) return 1;
      const f = Math.min(1, ((2 * ox) / (36 * wk)) * (oy / (wy1 - wy0)));
      covered = Math.max(covered, f);
      return 1 - 0.7 * f;
    };
    // (hw: half the width of something tall enough to hide Wick, for the see-through)
    const cut = (x, y, z, ord, fn, h = 150, hw = 0) => {
      if (!seen(x, z, 280, y - h)) return;
      const key = this.depthKey(x, y, z, boxesAt(z), V), see = hw ? seeThru(key, V.x(x - hw, z), V.x(x + hw, z), V.y(y - h, z), V.y(y, z)) : 1;
      add(key, ord, () => faded(nearFade(z) * see, () => atDepth(c, V, x, y, z, fn)));
    };
    // big things standing beside a wall that runs into the distance have to be drawn after it, on the near side
    const longWalls = this.field ? this.solids.filter(s => s.wall3d) : [];
    const keyAt = (x, y, z) => (longWalls.length ? this.depthKey(x, y, z, longWalls, V) : z);
    // (a wall standing between the camera and Wick goes see-through, like a house would: near a field's side edge the
    // camera stops following him, so a long wall off to one side can end up right in the way, like the one beside
    // the lookout path behind Mothwick's shed)
    const eye = [V.cx, HZ, V.camZ - FOCAL], wickPts = [[P.x, P.y - 14, P.z], [P.x, P.y - P.h + 8, P.z]];
    // Is a box that runs from depth z0 to z1 anywhere across the screen? Its far end counts too: a wall running far
    // into the distance off to one side still shows near the middle of the view (only checking its near end, Ember
    // Road's big wall vanished whenever you walked west of it)
    const across = (x0, x1, z0, z1) => {
      const zn = Math.max(z0, V.camZ - 650), zf = Math.min(z1 ?? this.zb, this.zb);
      if (zf < zn) return false;
      const l = Math.min(V.x(x0, zn), V.x(x0, zf)) - camX, r = Math.max(V.x(x1, zn), V.x(x1, zf)) - camX;
      return r > -160 && l < W + 160;
    };
    for (const w of walls) {
      if (w.z1 < V.camZ - 650) continue;   // (box() never draws anything further behind the camera than that)
      if (!across(w.x0, w.x1, w.z0, w.z1)) continue;
      let f = 0;
      if (w.z0 < wickKey) {
        const bx = [w.x0, w.y0, Math.max(w.z0, V.camZ - 650), w.x1, w.y1, Math.min(w.z1, P.z)];
        for (const p of wickPts) if (segHitsBox(eye, p, bx)) f += 1 / wickPts.length;
      }
      if (f > 0) { covered = Math.max(covered, f * w.ghost); add(w.z0, 0, () => faded(1 - w.fade * f, w.fn)); }
      else add(w.z0, 0, w.fn);
    }
    // hills, ledges, cliffs and islands (one Wick is behind shows him through it: see seeThru)
    const mat = matFor(theme, R);
    const hill = (key, b, fn) => {
      seeThru(key, Math.min(V.x(b.x0, b.z0), V.x(b.x0, b.z1)), Math.max(V.x(b.x1, b.z0), V.x(b.x1, b.z1)), V.y(b.y, b.z1), V.y(b.base ?? 450, b.z0));
      add(key, 0, fn);
    };
    for (const tr of R.terrain || []) {
      if (tr.z1 < V.camZ - 650) continue;
      if (!across(tr.x0, tr.x1, tr.z0, tr.z1)) continue;
      // a ramp's steps take their own places in the list, so you can stand on one in front of the ones behind it
      // (steps side by side go farthest from the middle of the view first, so each one hides the right bits of the next)
      if (tr.steps) for (const st of tr.steps) hill(keyAt((st.x0 + st.x1) / 2, st.y, st.z0) + Math.abs(st.x0 + st.x1 - 2 * V.cx) * 1e-5, st, () => drawTerrain3d(c, V, st, mat));
      else hill(keyAt((tr.x0 + tr.x1) / 2, tr.y, tr.z0), tr, () => this.inPool(c, V, tr, hy, b => drawTerrain3d(c, V, b, mat)));
    }
    // trees, flowers and rocks all over a big field, plus scenery a room places itself
    for (const d of this.decor || []) {
      // far-off scenery fades away into the distance instead of popping out (the tree line at the very back always stays)
      const far = d.z - V.camZ, lim = d.edge ? Infinity : TINY_DECOR[d.kind] ? 1300 : 2900;
      if (far > lim) continue;
      const fade = Math.min(1, (lim - far) / 350), h = (DECOR_H[d.kind] || 80) * d.k;
      if (V.s(d.z) * d.k < 0.42) {   // far away: its ready-made picture
        const spr = decorSprite(d.kind);
        cut(d.x, d.y, d.z, 0, () => { if (fade < 1) c.globalAlpha *= fade; c.scale(d.k / spr.k, d.k / spr.k); c.drawImage(spr.cv, -spr.ox, -spr.oy); }, h);
      } else cut(d.x, d.y, d.z, 0, () => { if (fade < 1) c.globalAlpha *= fade; c.scale(d.k, d.k); DECOR_DRAW[d.kind](c, t, d.x); }, h, DECOR_H[d.kind] >= 100 ? h * 0.3 : 0);
    }
    for (const d of R.decor || []) {
      const dz = d.z ?? 0, h = (DECOR_H[d.kind] || 80) * (d.k || 1);
      cut(d.x, surf(d.x, dz), dz, 0, () => { c.scale(d.k || 1, d.k || 1); DECOR_DRAW[d.kind](c, t, d.x); }, h, DECOR_H[d.kind] >= 100 ? h * 0.3 : 0);
    }
    // houses and archways standing out in a field
    for (const pr of R.props || []) {
      if ((pr.kind !== 'building' && pr.kind !== 'house') || (pr.z == null && !this.field)) continue;
      // (its back wall and roof stay in view the longest as you walk away from it, so that's what counts)
      const pz = pr.z ?? BZ0, back = pr.z != null ? pz + (pr.depth || 130) : GZ1, base = surf(pr.x, pz);
      const w = pr.w || (pr.kind === 'house' ? 180 : 170), roofTop = base - (pr.h || 140) - w * 0.42 - 50;   // the roof's peak, and a chimney
      if (!seen(pr.x, back, 420 + w / 2, roofTop)) continue;
      // (keyed like everything else, so a house up on a hill, like the Observatory, is drawn after the hill top it stands on)
      const key = this.depthKey(pr.x, base - 100, pz, boxesAt(pz), V), L = pr.x - w / 2 - 16, Rx = pr.x + w / 2 + 16;
      const see = seeThru(key, Math.min(V.x(L, pz), V.x(L, back)), Math.max(V.x(Rx, pz), V.x(Rx, back)), V.y(roofTop, back), V.y(base, pz));
      add(key, 0, () => faded(nearFade((pz + back) / 2) * see, () => this.drawProp(c, V, pr, t)));
    }
    for (const d of R.doors || []) {
      if (!this.field || d.exit || (d.style && d.style !== 'back')) continue;
      const back = d.style === 'back', az = back ? this.doorZ(d) + 2 : d.z ?? GZ1;
      if (!seen(d.x, az, 360)) continue;
      const locked = !!(d.need && !this.flag(d.need));
      if (back) add(keyAt(d.x, surf(d.x, az) - 100, az), 0, () => drawBackDoor(c, V, d.x, surf(d.x, az), { z: az, part: 'arch', locked }));
      else add(keyAt(d.x, surf(d.x, az) - 100, az - 10), 0, () => drawPathDoor(c, V, d.x, surf(d.x, this.doorZ(d)), { z: az, part: 'arch', label: d.label, locked, t }));
    }
    for (const p of this.staticPlats) if (!p.full) add(keyAt(p.x + p.w / 2, p.y, p.z0), 0, () => drawPlat3d(c, V, p.x, p.y, p.w, theme, false, p.z0, p.z1));
    // (hidden blocks sparkle for the Treasure Sense badge, the Great Lantern's Treasure Glow, or while your flare burns)
    const sense = this.s.badges.equipped.includes('treasure_sense') || this.lanternLv('glow') > 0 || this.flareOn;
    for (const b of R.blocks || []) {
      const bz = b.z ?? 0;
      const hidden = b.hidden && !this.s.revealed[b.id];
      if (hidden) {
        if (this.peekT && t - this.peekT < 1.2) add(bz - 22, 0, () => { c.globalAlpha = 0.3; drawBlock3d(c, V, b.x, b.y, { t, z: bz }); c.globalAlpha = 1; });
        else if (sense && Math.abs(b.x - P.x) < 320) add(bz, 0, () => atDepth(c, V, b.x + 22, b.y + 22, bz, () => this.sparkle(c, 0, 0, t)));
        continue;
      }
      const since = this.t - (this.bumps[b.id] ?? -9);
      // its shadow on the floor (or whatever is under it), drawn just before the block
      add(bz - 22.5, 0, () => this.floorShadow(c, V, b.x + 22, b.y + 44, bz, 34));
      add(bz - 22, 0, () => drawBlock3d(c, V, b.x, b.y, { t, z: bz, used: !!this.s.opened[b.id], bump: since < 0.2 ? Math.sin((since / 0.2) * Math.PI) * 10 : 0 }));
    }
    for (const hg of R.hedges || []) {
      if (hg.z1 < V.camZ - 650 || !seen(hg.x + hg.w / 2, Math.max(hg.z0, V.camZ), 300 + hg.w)) continue;
      const hy = surf(hg.x + hg.w / 2, (hg.z0 + hg.z1) / 2);
      hill(keyAt(hg.x + hg.w / 2, hy - (hg.h || 100), hg.z0), { x0: hg.x, x1: hg.x + hg.w, z0: hg.z0, z1: hg.z1, y: hy - (hg.h || 100), base: hy },
        () => drawHedge3d(c, V, hg.x, hy, hg.w, hg.h || 100, hg.z0, hg.z1));
    }
    for (const v of R.vents || []) { const st = this.ventState(v); cut(v.x, surf(v.x, v.z ?? 0), v.z ?? 0, 0, () => drawVent(c, 0, 0, t, st.s, st.k)); }
    for (const v of R.vines || []) {
      if (this.broken(v.id)) continue;
      const vz = this.vineZ(v);
      if (vz != null) { cut(v.x, v.y, vz, 0, () => drawVines(c, 0, 0, v.w, v.h, t)); continue; }
      // a wall of vines: a curtain of them every little way back (only the ones near enough to see)
      const o = this.wallZ(v.z0, v.z1, v.x, v.x + v.w), z0 = o.z0 ?? GZ0, z1 = o.z1 ?? GZ1;
      for (let z = z0 + 30; z < z1 - 10; z += 55) if (z > V.camZ - 620 && z < V.camZ + 2000) cut(v.x, v.y, z, 0, () => drawVines(c, 0, 0, v.w, v.h, t + z));
    }
    if (R.braziers) {
      const solved = this.flag(R.brazierFlag), panic = this.cut.panic != null && t - this.cut.panic < 0.7;
      const flash = Math.max(0, 1 - (t - this.brazierFlashT) / 0.8);
      for (const b of R.braziers) cut(b.x, surf(b.x), this.thingZ(b, 'brazier'), 0, () => drawBrazier(c, 0, 0, { t: t + b.x, n: b.n, lit: solved || panic || this.brazierLit.includes(b.n), flash }));
    }
    for (const sl of R.seals || []) {
      if (this.broken(sl.id)) continue;
      const d = (R.doors || []).find(dd => dd.needSeal === sl.id);
      cut(sl.x, surf(sl.x), d ? this.doorZ(d) - 6 : 0, 0, () => drawSeal(c, -42, -130, 84, 130, t, this.stat('focus_seconds') / sl.need));
    }
    for (const b of R.boulders || []) {
      if (b.solid || this.broken(b.id)) continue;
      const d = (R.doors || []).find(dd => dd.needBroken === b.id), ch = (R.chests || []).find(cc => cc.needBroken === b.id);
      cut(b.x, surf(b.x), d ? this.doorZ(d) - 10 : ch ? (ch.z ?? 0) : 0, 0, () => drawBoulder(c, -62, -150, 124, 150));
    }
    for (const l of this.lampList()) cut(l.x, surf(l.x, l.z), l.z, 0, () => drawLamp(c, 0, 0, { t: t + l.x, lit: !!this.s.opened[`lamp_${this.roomId}_${l.x}`] }));
    // signs, boards, shrines, levers, chests, springs, bushes and pots stand where the room puts them (z), on whatever ground is there
    const thing = (o, kind, fn) => { const z = kind ? this.thingZ(o, kind) : o.z ?? 0; cut(o.x, o.y ?? surf(o.x, z), z, 0, fn); };
    for (const s of R.signs || []) thing(s, 'sign', () => drawSign(c, 0, 0));
    for (const b of R.boards || []) thing(b, 'board', () => drawQuestBoard(c, 0, 0, t));
    for (const sh of R.shrines || []) thing(sh, 'shrine', () => drawShrine(c, 0, 0, { t, used: this.has(sh.ability || 'glide') }));
    for (const sw of R.switches || []) {
      const on = (R.puzzle && this.flag(R.puzzle.flag)) || this.leverState.includes(sw.id);
      thing(sw, 'switch', () => FURN.lever(c, { on, color: sw.color, mark: sw.mark, t }));
    }
    for (const ch of R.chests || []) {
      if (ch.needBroken && !this.broken(ch.needBroken)) continue;
      thing(ch, null, () => drawChest(c, 0, 0, { open: !!this.s.opened[ch.id] }));
    }
    for (const s of R.springs || []) {
      const since = t - (this.springAnim[s.x] ?? -9);
      thing(s, null, () => drawSpring(c, 0, 0, { squash: since < 0.25 ? Math.sin((since / 0.25) * Math.PI) * 0.6 : 0 }));
    }
    for (const b of R.bushes || []) if (!this.cleared.has(b.id)) thing(b, 'bush', () => drawBush(c, 0, 0, { t }));
    for (const b of R.pots || []) if (!this.cleared.has(b.id)) thing(b, 'pot', () => drawPot(c, 0, 0));
    for (const it of R.collect || []) {
      if (this.s.collected[it.id]) continue;
      const iz = it.z ?? 0, tt = t + it.x * 0.37;
      // its shadow on the ground (or the bottom of the gap) shows how far back it floats, and a gold ring round the
      // shadow means Wick is lined up with it: walk under it and jump
      const lined = Math.abs(iz - P.z) < 32 && Math.abs(it.x - P.x) < 340;
      add(iz - 1, 0, () => { this.floorShadow(c, V, it.x, it.y, iz, 15); if (lined) this.depthRing(c, V, it.x, it.y, iz, t); });
      cut(it.x, it.y, iz, 0, () => {
        if (it.kind === 'acorn') drawGoldAcorn(c, 0, 0, tt);
        else if (it.kind === 'ember') drawLostEmber(c, 0, 0, tt);
        else if (it.kind === 'gear') drawGear(c, 0, 0, tt);
        else if (it.kind === 'crayon') this.drawCrayonItem(c, it, tt);
        else if (it.kind === 'page') { drawPage(c, 0, 0, tt); if (sense && Math.abs(it.x - P.x) < 400) this.sparkle(c, 0, -20, t); }
        else drawBook(c, 0, 0, tt);
      });
    }
    for (const f of R.furniture || []) {
      if (f.kind === 'rug' || !FURN[f.kind]) continue;
      const fz = f.z ?? FURN_Z[f.kind] ?? 60;
      cut(f.x, surf(f.x, fz), fz, 0, () => FURN[f.kind](c, { ...f, t }));
    }
    for (const pr of R.props || []) {
      const pz = pr.z ?? PROP_Z[pr.kind], f = PROP_FOOT[pr.kind];   // (the big ones reach well above their footprint)
      if (PROP_Z[pr.kind] != null) cut(pr.x, surf(pr.x, pz), pz, 0, () => this.drawPropCutout(c, pr, t), f ? f[2] * 1.5 : 150, f ? f[0] * 2 : 0);
    }
    for (const d of R.doors || []) {
      if (!d.style || d.style === 'back' || d.style === 'none' || d.exit) continue;
      const locked = !!(d.need && !this.flag(d.need));
      if (d.style === 'front') { cut(d.x + 74, surf(d.x, -6), -6, 0, () => drawSignpost(c, d.label, locked, t)); continue; }
      const dz = this.doorZ(d);
      cut(d.x, surf(d.x, dz), dz, 0, () => drawDoor(c, 0, 0, { locked, style: d.style }));
    }
    for (const s of this.exitSigns || []) {
      if (s.x == null) continue;
      const locked = !!(s.e.need && !this.flag(s.e.need));
      cut(s.x, surf(s.x, s.z), s.z, 0, () => drawSignpost(c, s.label, locked, t, s.side === 'left'));
    }
    this.drawMechList(c, V, t, add, cut);
    this.drawTowerList(c, V, t, add, cut);
    this.drawMarginList(c, V, t, add, cut);
    if (R.boss && !this.flag(R.boss.flag)) {
      const awake = R.boss.awake || this.cut.bossAwake, bz = R.boss.z ?? Z_DEFAULT.boss;
      cut(R.boss.x, surf(R.boss.x, bz), bz, 1, () => {
        DRAW[R.boss.kind](c, 0, 0, { t, scale: R.boss.scale, flip: -1, mood: awake ? 'angry' : 'sleep' });
        if (!awake) { c.font = 'bold 22px Fredoka, sans-serif'; c.fillStyle = '#fffaf0'; c.textAlign = 'center'; c.fillText('z z Z', 70, -200 + Math.sin(t * 2) * 5); }
      }, 140 * (R.boss.scale || 1) + 80);
    }
    for (const n of R.npcs || []) {
      const flying = n.kind === 'mothwick' && this.cut.elderFly != null && n.id === (this.cut.flyId || 'elder1');
      if (n.show && !n.show(this) && !flying) continue;
      let x = n.x, y = n.y ?? surf(n.x, n.z ?? 0);
      if (flying) { x += this.cut.elderFly * 900; y -= this.cut.elderFly * 260; }
      const want = this.mode === 'explore' || this.dlg ? (P.x < x ? -1 : 1) : (n.flip || 1);
      const cur = this.npcFlip[n.id] ?? want;
      const face = this.npcFlip[n.id] = cur + clamp(want - cur, -0.18, 0.18);
      const news = n.talk && this.npcHasNews(n);
      cut(x, y, n.z ?? 0, 1, () => {
        DRAW[n.kind](c, 0, 0, { t: t + (n.x % 7), flip: Math.abs(face) < 0.08 ? 0.08 * Math.sign(want) : face, ...(n.opts || {}), lit: n.kind === 'folk' ? this.flag('prologue_done') : undefined });
        if (news) { const by = -(n.newsY || NEWS_Y[n.kind] || 92) + Math.sin(t * 4) * 3; c.font = 'bold 22px Fredoka, sans-serif'; c.textAlign = 'center'; c.lineWidth = 4; c.strokeStyle = INK; c.strokeText('!', 0, by); c.fillStyle = '#ffe066'; c.fillText('!', 0, by); }
      }, 130 * ((n.opts || {}).scale || 1) + 40);
    }
    // standing in water (or sinking into it, or into lava or ink): only what's above the surface shows, with a ring of
    // ripples around you; fn(true) draws it that way (and without a shadow on the floor)
    const wet = (x, y, z, fn) => {
      const wl = this.liquidAt(x, z);
      if (wl == null || y <= wl - 1) return fn(false);
      const sy = V.y(wl, z), k = V.s(z), q = (t * 1.3 + x * 0.01) % 1;
      c.save(); c.beginPath(); c.rect(V.camX - 400, sy - 3000, 1760, 3000); c.clip(); fn(true); c.restore();
      c.strokeStyle = `rgba(255,255,255,${0.75 - q * 0.55})`; c.lineWidth = 2;
      c.beginPath(); c.ellipse(V.x(x, z), sy, (16 + q * 12) * k, (4.5 + q * 3) * k, 0, 0, Math.PI * 2); c.stroke();
    };
    for (const e of this.enemies) {
      if (e.dead) continue;
      const run = e.ai === 'chase';
      const ey = e.y - (run ? Math.abs(Math.sin(e.t * 12)) * 4 : 0);
      if (!seen(e.x, e.z)) continue;
      add(this.depthKey(e.x, e.y, e.z, boxesAt(e.z), V), 1, () => wet(e.x, e.y, e.z, inWater => {
        if (e.fly && !inWater) this.floorShadow(c, V, e.x, e.y, e.z, 16);
        atDepth(c, V, e.x, ey, e.z, () => {
          c.save();
          if (e.stun > 0) c.globalAlpha = 0.45 + 0.3 * Math.sin(t * 20);
          const vf = e.vf ?? e.flip;
          DRAW[e.kind](c, 0, 0, { t: e.t, flip: Math.abs(vf) < 0.08 ? 0.08 * Math.sign(e.flip) : vf, shadow: !e.fly, state: run ? 'walk' : 'idle', phase: e.t * 2 });
          c.restore();
          // "!" when it spots you, "?" when it has lost you
          if (e.ai === 'alert' || e.ai === 'lost') {
            const lost = e.ai === 'lost', mark = lost ? '?' : '!', pop = Math.min(1, ((lost ? 0.9 : ALERT_T) - e.aiT) * 8);
            c.save(); c.translate(0, -e.h - 22); c.scale(pop, pop);
            c.font = 'bold 26px Fredoka, sans-serif'; c.textAlign = 'center'; c.lineWidth = 5; c.strokeStyle = INK; c.strokeText(mark, 0, 0); c.fillStyle = lost ? '#c8c0e8' : '#ff6b6b'; c.fillText(mark, 0, 0);
            c.restore();
          }
        });
      }));
    }
    // partner + Wick, with their shadows on the floor (or platform) below them
    const speed = Math.hypot(P.vx, P.vz || 0);
    const state = P.gliding ? 'glide' : !P.onGround ? 'jump' : speed > 20 || this.doorAnim ? 'walk' : 'idle';
    const pid = this.s.partner;
    if (pid && DRAW[pid] && this.mode !== 'battle') {
      const pp = this.partnerPos;
      const moving = Math.hypot(pp.x - this.lastPP.x, pp.z - this.lastPP.z) > 0.6;
      this.lastPP = { x: pp.x, z: pp.z };
      const pf = this.partnerFlip ?? P.facing;
      add(this.depthKey(pp.x, pp.y, pp.z, boxesAt(pp.z), V), 1, () => wet(pp.x, pp.y, pp.z, inWater => {
        if (!inWater) this.floorShadow(c, V, pp.x, pp.y, pp.z, 17);
        atDepth(c, V, pp.x, pp.y, pp.z, () => {
          c.scale(2 - this.partnerSq, this.partnerSq);
          // (going through a door, right behind Wick)
          const dk = this.doorAnim ? this.doorAnim.pk : 0;
          if (dk) { c.globalAlpha *= 1 - dk; if (!this.doorAnim.fadeOnly) c.scale(1 - dk * 0.55, 1 - dk * 0.55); }
          DRAW[pid](c, 0, 0, { t, flip: Math.abs(pf) < 0.08 ? 0.08 * Math.sign(P.facing) : pf, state: moving || this.doorAnim ? 'walk' : 'idle', phase: P.phase, glasses: true, shadow: false });
        });
      }));
    }
    // (ghost: Wick again on top of whatever he's behind, without his shadow)
    const hero = ghost => wet(P.x, P.y, P.z, inWater => {
      // dropping into a tear: Wick shrinks away down the hole
      const fall = this.fallT != null ? Math.min(1, (t - this.fallT) / 0.6) : 0;
      const door = this.doorAnim ? this.doorAnim.k : 0;   // stepping into a doorway: he shrinks away into the dark
      const shrink = door && !this.doorAnim.fadeOnly ? door : 0;   // (a door at the front of a room: he only fades)
      if (!fall && !ghost && !inWater && door < 0.9) this.floorShadow(c, V, P.x, P.y, P.z, (P.rolled ? 14 : 18) * (1 - shrink * 0.6));
      atDepth(c, V, P.x, P.y + fall * 36, P.z, () => {
        c.save();
        if (fall) { c.globalAlpha *= 1 - fall; c.scale(1 - fall * 0.6, 1 - fall * 0.6); }
        if (door) { c.globalAlpha *= 1 - door; c.scale(1 - shrink * 0.55, 1 - shrink * 0.55); }
        // (blinking while he can't be hurt, but not for the moment of safety he gets coming into a new place)
        if (P.invuln > 0 && P.invuln > (P.quietInv || 0) && Math.floor(t * 10) % 2) c.globalAlpha *= 0.5;
        const swing = P.hammerT > 0 ? 1 - P.hammerT / 0.34 : null;
        if (swing != null && swing > 0.25) {
          c.strokeStyle = `rgba(255,255,255,${0.7 * (1 - swing)})`; c.lineWidth = 7; c.lineCap = 'round';
          const a0 = P.facing > 0 ? -2.2 : Math.PI + 2.2, a1 = P.facing > 0 ? -2.2 + swing * 3 : Math.PI + 2.2 - swing * 3;
          c.beginPath(); c.arc(P.facing * 8, -22, 44, Math.min(a0, a1), Math.max(a0, a1)); c.stroke();
        }
        const hop = Math.abs(P.flip) < 0.8 ? (0.8 - Math.abs(P.flip)) * 5 : 0;
        const wickFlame = 0.85 + Math.min(1, this.light / 80) * 0.35 + (this.flareOn ? 0.9 : 0);
        if (P.rolled) drawWickRoll(c, 0, 0, { t, angle: P.rollA, dir: Math.sign(P.vx), flame: wickFlame });
        else {
          drawWick(c, 0, -hop, { t, flip: P.flip, state, phase: P.phase, hammer: this.has('hammer'), swing, sq: P.sq,
            flame: wickFlame, mood: this.dlg ? 'normal' : undefined, shadow: false });
          // mid-turn, you can see he's paper: a thin bright edge
          if (Math.abs(P.flip) < 0.3 && state !== 'glide') {
            c.globalAlpha *= 1 - Math.abs(P.flip) / 0.3;
            c.fillStyle = PAPER; c.strokeStyle = INK; c.lineWidth = 1.5;
            c.beginPath(); rrect(-2.5, -hop - 64, 5, 62, 2.5)(c); c.fill(); c.stroke();
          }
        }
        this.drawCarried(c, t);
        c.restore();
      });
    });
    add(wickKey, 2, () => hero(false));
    if (this.fireball) {
      const F = this.fireball;
      add(F.z - 1, 2, () => atDepth(c, V, F.x, F.y, F.z, () => {
        glowDot(c, 0, 0, 34, '255,160,70', 0.6);
        c.save(); c.translate(0, 6); c.rotate(F.vx > 0 ? -Math.PI / 2 : Math.PI / 2); flame(c, 0, 0, 0.9, t); c.restore();
      }));
    }
    if (this.cut.shard != null) add(P.z - 2, 3, () => atDepth(c, V, P.x, P.y - 130 - Math.min(1, (t - this.cut.shard)) * 30, P.z, () => drawShard(c, 0, 0, t, 1.1)));
    list.sort((a, b) => b.key - a.key || a.ord - b.ord);
    for (const it of list) it.fn();
    // Wick shows through a house or a tree he's behind (a see-through tree's leaves still pile up), and his flame
    // glows through anything, so you never lose him
    if (covered > 0) { c.save(); c.globalAlpha = 0.55 * covered; hero(true); c.restore(); }
    glowDot(c, V.x(P.x, P.z), V.y(P.y - (P.rolled ? 30 : 68), P.z), 22, '255,214,120', 0.45);
    this.drawMechOver(c, V, t);
    // ---- sparks, dust and the scenery in front of the path
    for (const p of this.parts) {
      const z = p.z ?? (this.p ? this.p.z : 0), s = V.s(z), sx = V.x(p.x, z), sy = V.y(p.y, z);
      if (p.dust) {
        c.fillStyle = `rgba(255,250,240,${Math.max(0, p.life * 1.4)})`;
        c.beginPath(); c.arc(sx, sy, p.r * (1.6 - p.life) * s, 0, Math.PI * 2); c.fill();
        continue;
      }
      c.globalAlpha = Math.max(0, Math.min(1, p.life * 2));
      c.fillStyle = p.c;
      c.beginPath();
      if (p.star) starPath(c, sx, sy, 10 * s, 4 * s, 4); else c.arc(sx, sy, 4 * s, 0, Math.PI * 2);
      c.fill();
    }
    c.globalAlpha = 1;
    if (decor) drawDecor(c, V, decor.front, GZ0 + 8, x => this.groundLevelAt(x), t);
    // the Margin: a pencil sketch, except in Wick's light (before the pop-ups, the guide and the map, so they keep
    // their color)
    if (R.faded) { c.save(); c.setTransform(this.scale, 0, 0, this.scale, 0, 0); this.drawMarginFade(c); c.restore(); }
    for (const f of this.floaters) {
      const age = this.t - f.t0, z = f.z ?? 0;
      c.globalAlpha = Math.max(0, 1 - age / 1.4);
      c.font = 'bold 20px Fredoka, sans-serif'; c.textAlign = 'center';
      const sx = V.x(f.x, z), sy = V.y(f.y - age * 30, z);
      c.lineWidth = 5; c.strokeStyle = INK; c.strokeText(f.text, sx, sy);
      c.fillStyle = f.color; c.fillText(f.text, sx, sy);
    }
    c.globalAlpha = 1;
    drawGuide(c, this, V, t);
    if (this.prompt && this.mode === 'explore') this.drawPrompt(c, V, this.prompt);
    c.restore();
    if (R.dark && !(R.litBy && this.flag(R.litBy))) {
      const lights = [{ x: wx, y: V.y(P.y - 40, P.z), r: this.flareOn ? 380 : 100 }];
      for (const l of this.lampList()) if (this.s.opened[`lamp_${this.roomId}_${l.x}`]) lights.push({ x: V.x(l.x, l.z) - camX, y: V.y(surf(l.x, l.z) - 90, l.z), r: 170 });
      drawDarkness(c, W, H, lights, 0.94);
      if (this.flareOn && this.light <= 10) { c.fillStyle = '#fffaf0'; c.font = 'bold 18px Fredoka, sans-serif'; c.textAlign = 'center'; c.fillText(`Flare: only ${this.light} ✦ left!`, wx, V.y(P.y - 110, P.z)); }
    }
    if (this.cut.dusk) {
      const d = this.cut.dusk;
      c.save(); c.globalAlpha = d.a;
      glowDot(c, d.x - camX, d.y - 50, 140, '120,60,180', 0.4);
      DRAW.dusk(c, d.x - camX, d.y, { t, scale: 1.5, flip: -1 });
      c.restore();
    }
    if (this.cut.flash) { c.fillStyle = `rgba(255,255,255,${this.cut.flash})`; c.fillRect(0, 0, W, H); }
    // the minimap (minimap.js): every big field, and the old narrow rooms that are long
    this.miniRect = null;
    if (this.mode !== 'battle' && this.s.minimap !== false && this.wantsMinimap()) this.drawMinimap(c);
    this.drawBanner(c);
    c.restore();
  }

  sparkle(c, x, y, t) {
    for (let i = 0; i < 3; i++) {
      const a = t * 2 + i * 2.1, r = 14 + Math.sin(t * 3 + i) * 5;
      c.globalAlpha = 0.5 + 0.5 * Math.sin(t * 6 + i);
      c.fillStyle = '#fff6c8'; c.beginPath(); starPath(c, x + Math.cos(a) * r, y + Math.sin(a) * r, 6, 2, 4); c.fill();
    }
    c.globalAlpha = 1;
  }

  // "New place discovered!" slides in at the top for a couple of seconds.
  drawBanner(c) {
    const b = this.banner;
    if (!b) return;
    const age = this.t - b.t0;
    if (age > 2.8) { this.banner = null; return; }
    const k = Math.min(1, age / 0.25) * Math.min(1, (2.8 - age) / 0.3);
    c.save(); c.globalAlpha = k; c.translate(W / 2, 168 - (1 - k) * 24);
    c.font = 'bold 20px Fredoka, sans-serif'; c.textAlign = 'center';
    const w = c.measureText(b.text).width + 50;
    c.fillStyle = PAPER; c.strokeStyle = INK; c.lineWidth = 3;
    c.beginPath(); rrect(-w / 2, -22, w, 40, 14)(c); c.fill(); c.stroke();
    c.fillStyle = INK; c.fillText(b.text, 0, 5);
    c.font = '12px Fredoka, sans-serif'; c.fillStyle = '#6b5a8a'; c.fillText('+2 🪙 for exploring', 0, 32);
    c.restore();
  }

  drawDoor3d(c, V, d, y, t) {
    if (d.style === 'none') return;
    const locked = !!(d.need && !this.flag(d.need));
    if (d.exit) { drawExitMat(c, V, d.x, y, t); return; }
    if (d.style === 'front') { drawFrontPath(c, V, d.x, y); return; }
    // (out in a big field just its carpet goes here: the doorway stands among everything else)
    if (d.style === 'back' && this.field) { drawBackDoor(c, V, d.x, y, { locked, z: this.doorZ(d) + 2, part: 'floor' }); return; }
    if (d.style === 'back' || (this.room.interior && !d.style)) { drawBackDoor(c, V, d.x, y, { locked }); return; }
    if (d.style) { drawDoor(c, d.x, y, { locked, style: d.style }); return; }
    drawPathDoor(c, V, d.x, y, { label: d.label, locked, t });
  }

  npcHasNews(n) {
    const more = newsFor(this, n) ?? wildNews(this, n);
    if (more) return true;
    // a carnival booth you haven't played yet
    if (/^mg_/.test(n.talk)) return !((this.s.minigames || {})[n.talk.slice(3)] || {}).plays;
    const map = { 'Farmer Barley': 'windmill', 'Fisher Finn': 'koi', Glimmer: 'lamps', 'Hunter Hazel': 'bramble', Nutkin: 'acorns',
      'Granny Hearth': 'embers', Kettle: 'ontime', 'Anvil Annie': 'forge' };
    const id = map[n.name];
    if (n.name === 'Mothwick' && this.flag('prologue_done')) return !this.questKnown('study_first') || STUDY_QUESTS.some(q => this.questReady(q));
    if (n.name === 'Librarian Quill') return !this.questKnown('overdue') || this.questReady('overdue') || (this.questDone('overdue') && !this.questKnown('fieldnotes')) || this.questReady('fieldnotes');
    if (n.name === 'Nutkin' && !this.flag('ch1_done')) return false;
    if (!id) return false;
    return !this.questKnown(id) || this.questReady(id);
  }

  drawPrompt(c, V, it) {
    const off = it.type === 'npc' ? 104 : it.type === 'lamp' ? 140 : it.type === 'door' || it.type === 'shop' || it.type === 'brazier' ? 128
      : it.type === 'board' || it.type === 'reset' ? 118 : it.type === 'slot' ? 112 : it.type === 'tear' ? 56 : 84;
    const z = it.z ?? 0;
    const x = V.x(it.x, z), y = V.y(it.y - off, z) + Math.sin(this.t * 4) * 3;
    const text = it.label;
    c.font = 'bold 15px Fredoka, sans-serif';
    const w = c.measureText(text).width + 44;
    c.fillStyle = PAPER; c.strokeStyle = INK; c.lineWidth = 2.5;
    c.beginPath(); rrect(x - w / 2, y - 16, w, 26, 12)(c); c.fill(); c.stroke();
    c.fillStyle = INK; c.beginPath(); rrect(x - w / 2 + 6, y - 11, 18, 16, 4)(c); c.fill();
    c.fillStyle = PAPER; c.textAlign = 'center'; c.fillText('E', x - w / 2 + 15, y + 2);
    c.fillStyle = INK; c.textAlign = 'left'; c.fillText(text, x - w / 2 + 30, y + 3);
  }

  // Buildings stand at the back of the floor, with real roofs and sides.
  drawProp(c, V, pr, t) {
    const y = this.surfaceAt(pr.x, pr.z);
    if (pr.kind === 'building') drawBuilding3d(c, V, pr.x, y, { ...pr, t, lit: this.flag('prologue_done'), closed: pr.closed || !this.flag('prologue_done') });
    else if (pr.kind === 'house') {
      const o = { lit: true, z: pr.z, depth: pr.depth };
      for (const k of ['roof', 'wall', 'wall2']) if (pr[k]) o[k] = pr[k];
      drawHouse3d(c, V, pr.x, y, o);
    }
  }

  // Props you can walk in front of and behind, drawn around (0, 0).
  drawPropCutout(c, pr, t) {
    if (pr.kind === 'lantern') drawBrokenLantern(c, 0, 0, this.cut.townLit ? 5 : this.s.shards, t);
    else if (pr.kind === 'windmill') { drawWindmill(c, 0, 0, t * (this.questDone('windmill') ? 1.6 : 0.15)); drawDoor(c, 0, 0, {}); }
    else if (pr.kind === 'dock') drawDock(c, 0, 0, t);
    else if (pr.kind === 'hotspring') drawHotSpring(c, 0, 0, t);
    else if (pr.kind === 'bigtree') {
      paper(c, p => {
        shape(c, p, rrect(-34, -230, 68, 230, 14), vgrad(c, -230, 0, '#8a5a3c', '#5e3b24'));
        shape(c, p, ell(-70, -260, 90, 70), '#4f9a52');
        shape(c, p, ell(60, -270, 95, 75), '#5fae5c');
        shape(c, p, ell(0, -330, 100, 70), '#6cc068');
      });
      c.fillStyle = '#3b2a1c'; c.beginPath(); c.ellipse(0, -150, 16, 22, 0, 0, Math.PI * 2); c.fill();
    }
  }
}

// Field sizes come from the battle data (kept here so the field doesn't need the whole table).
const ENEMY_H = {
  gloomling: 38, spikeshroom: 46, buzzbug: 36, snailshell: 40, inkblot: 40, shellcrab: 42, glowbat: 36, puddlet: 42,
  mirrormoth: 46, wisp: 40, bombshroom: 46, raccoon: 48, thornback: 42,
  cinderling: 38, magmaw: 40, ashcrow: 36, jugglit: 44, slagbrute: 50, dustbunny: 46, hollowarmor: 66, snipper: 44,
  notifly: 36, snoozer: 50, scrollbug: 40, sandglass: 58,
};
const FLYERS = { buzzbug: 1, glowbat: 1, mirrormoth: 1, wisp: 1, ashcrow: 1, notifly: 1 };
// Chasing: an enemy that spots you shows "!" for ALERT_T, then runs at you for up to CHASE_TIME seconds (a bit slower
// than Wick, so you can get away). On foot it can step up or down ENEMY_STEP, but not into pits, water or off cliffs.
const ALERT_T = 0.5, CHASE_TIME = 6, ENEMY_STEP = 24;
// how fast each kind chases (× the usual 175, or 190 for flyers): snails dawdle, thieves and crows dash
const CHASE_SPEED = {
  snailshell: 0.5, snoozer: 0.6, slagbrute: 0.7, shellcrab: 0.75, hollowarmor: 0.75, thornback: 0.8, sandglass: 0.8, spikeshroom: 0.85,
  magmaw: 0.9, dustbunny: 1.1, buzzbug: 1.1, glowbat: 1.1, cinderling: 1.15, notifly: 1.15, ashcrow: 1.25, bombshroom: 1.3, raccoon: 1.3,
  straightedge: 0.75, redpen: 0.95, erasebit: 1.15, crumple: 1.2,
};
// how high the "!" floats over folks who are taller than usual
const NEWS_Y = { stitch: 128, mayor: 120 };
// little scenery that isn't worth drawing far away in a big field
const TINY_DECOR = { flower: 1, tuft: 1, mushroom: 1, fern: 1, shell: 1, pebbles: 1 };
// how tall scenery stands (at size 1), so whatever has slid off the bottom of the view can be skipped
const DECOR_H = { tree: 240, pine: 175, pinwheel: 160, flag: 125, lamp: 140, pillar: 220, banner: 235, torii: 180, statue: 245, stall: 130,
  booth_whack: 172, booth_memory: 172, booth_beat: 172, booth_plane: 172, deadtree: 160, mclock: 140,
  sketchtree: 210, pencil: 160, ruler: 115, eraserblock: 55, paperball: 32,
  fountain: 160, hedge: 120, crystal: 100, stalag: 120, urn: 55, reeds: 90, thorn: 70, bush: 60, rosebush: 50, hay: 50, rock: 40, root: 60, vent: 120 };
// the Paper Plains mechanics (stickers, crates, plates, bombs, tears, folded folks) are methods of the Adventure too
Object.assign(Adventure.prototype, MECH);
// and so are the Lantern Square carnival games, and Chapter 4's Time Stop, pendulums and cutscenes
Object.assign(Adventure.prototype, MINI, TOWER_FIELD, MARGIN_FIELD, MINIMAP);
// Big props you walk around: [half width, half depth, height, depth they stand at].
const PROP_FOOT = { windmill: [36, 16, 200, 200], bigtree: [36, 16, 230, 180], lantern: [40, 16, 190, 170] };
// Small props you can walk in front of and behind: the depth they stand at.
const PROP_Z = { windmill: 200, bigtree: 180, lantern: 170, hotspring: 60, dock: 0 };
const HOPPERS = { magmaw: 1 };
