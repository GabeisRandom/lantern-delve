// The little map in the corner. The user asked for it to look more like the maps on the bottom screen of Yo-kai Watch
// and the Mario & Luigi RPGs on the 3DS. Before, it was the whole field squashed into a strip of colored boxes. Now
// it's a close-up of the land around Wick that glides along with him, drawn as a bright picture map with bold edges:
// roads with curbs, roofs, round trees that clump into woods, hills standing up off the ground, water with a pale
// shore. On it: Wick's face in a badge with a pointer for the way he's walking, his partner, a gold pin on what to do
// next (or, when that's further off, an arrow on the rim pointing to it), doors and ways out, lampposts, chests,
// things to find, a red ! over folks with news, and enemies (pulsing when one's chasing you). The old narrow rooms
// (caves, castle halls) get one too when they're long, seen from the side. Click it (or press TAB) for the big map.
//
// The land, roads, trees and houses are drawn once per room into a picture (and again when a puzzle changes the
// walls); only the markers are drawn every frame.
import { ROOMS, AREAS } from './data.js';
import { DRAW, INK, PAPER, rrect, glowDot, starPath } from '../art.js';
import { GZ0, GZ1, BZ0, matFor, STYLES } from '../art2.js';
import { goalZ } from './guide.js';
import { AreaMap, HAZARD, TERRAIN, DECOR } from './areamap.js';

const W = 960, TAU = Math.PI * 2;
const MW = 228;                    // the map window: its width...
const FH = 132, SH = 84;           // ...and its height, over a field (seen from above) or an old narrow room (from the side)
const FZ = 0.1;                    // px per world unit over a field; from the side, across and up (a little stretched up,
const SZX = 0.1, SZY = 0.15;       // so the ledges stand apart, while it still shows a good way past the screen's edges)
const PAD = 320;                   // the picture reaches this far past the edges of the place (world units)
const LINE = 'rgba(43,34,53,0.9)';
const IC = AreaMap.prototype;      // (the big map's little pictures: doors, lamps, chests...)
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const hash = n => { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };
const SHORE = { water: '#e2f6ff', lava: '#ffd98a', ink: '#7d72b0', gloom: '#9a7ac8', pit: '#4a3f66' };

// ---------------------------------------------------------------- colors
function rgbOf(col) {
  const s = String(col || '');
  if (s[0] === '#') {
    let h = s.slice(1);
    if (h.length === 3) h = h.split('').map(ch => ch + ch).join('');
    const n = parseInt(h.slice(0, 6), 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  const m = /rgba?\(([^)]+)\)/.exec(s);
  if (m) { const p = m[1].split(',').map(Number); return [p[0] || 0, p[1] || 0, p[2] || 0]; }
  return [128, 128, 128];
}
// lighter (k > 0) or darker (k < 0), for any color a room uses (art2's shade() only reads #rrggbb)
function tint(col, k) {
  const f = v => Math.round(k < 0 ? v * (1 + k) : v + (255 - v) * k);
  const [r, g, b] = rgbOf(col);
  return `rgb(${f(r)},${f(g)},${f(b)})`;
}
const themeOf = (A, R) => matFor(typeof R.theme === 'function' ? R.theme(A) : R.theme, R);

function canvas(w, h, k) {
  const cv = document.createElement('canvas');
  cv.width = Math.max(1, Math.ceil(w * k));
  cv.height = Math.max(1, Math.ceil(h * k));
  const c = cv.getContext('2d');
  c.setTransform(k, 0, 0, k, 0, 0);
  return [cv, c];
}

// ---------------------------------------------------------------- the picture of a big field, from above
// (x across, depth up the map: the far back of the field is at the top, the way in at the bottom)
function fieldLayer(A, k) {
  const R = A.room, zb = A.zb, M = themeOf(A, R);
  const w = (R.w + PAD * 2) * FZ, h = (zb - GZ0 + PAD * 2) * FZ;
  const [cv, c] = canvas(w, h, k);
  const X = x => (x + PAD) * FZ, Y = z => (zb + PAD - z) * FZ;
  const B = (x0, x1, z0, z1) => [X(x0), Y(z1), (x1 - x0) * FZ, (z1 - z0) * FZ];
  const fillB = (b, col) => { c.fillStyle = col; c.fillRect(b[0], b[1], b[2], b[3]); };
  const lineB = b => c.strokeRect(b[0], b[1], b[2], b[3]);
  const circle = (x, y, r) => { c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill(); };
  const bg = tint(M.side || '#3a2f55', -0.48);
  c.fillStyle = bg; c.fillRect(0, 0, w, h);
  c.lineJoin = 'round'; c.lineCap = 'round';
  // the gaps (water, lava, thorns...) under everything, shallow water's bed, and deep water darker
  const hz = R.hazard || ((R.holes || []).length ? 'pit' : null), inside = B(0, R.w, GZ0, zb);
  if (hz) fillB(inside, HAZARD[hz] || HAZARD.pit);
  for (const r of A.rects) if (r.water) fillB(B(r.x0, r.x1, r.z0, r.z1), '#a6dcf4');
  if (R.wade) for (const ho of R.holes || []) if (ho[4] === 'deep') fillB(B(ho[0], ho[1], ho[2], ho[3]), 'rgba(16,40,96,0.3)');
  // the land: a bold edge all round it, and a pale shore where it meets water. (Both are drawn as wide outlines of every
  // piece of land before the land itself, which then covers their inner halves: so pieces side by side join up.)
  const land = A.landRects;
  if (hz) {
    c.save(); c.beginPath(); c.rect(inside[0], inside[1], inside[2], inside[3]); c.clip();
    c.strokeStyle = SHORE[hz] || tint(HAZARD[hz] || HAZARD.pit, 0.35); c.lineWidth = 7;
    for (const r of land) lineB(B(r.x0, r.x1, r.z0, r.z1));
    c.restore();
  }
  c.strokeStyle = LINE; c.lineWidth = 2.6;
  for (const r of land) lineB(B(r.x0, r.x1, r.z0, r.z1));
  for (const r of land) fillB(B(r.x0, r.x1, r.z0, r.z1), r.y < 449 ? tint(M.top, 0.12) : r.y > 451 ? tint(M.top, -0.12) : M.top);
  // a little texture: tufts scattered over grass
  c.strokeStyle = tint(M.top, -0.15); c.lineWidth = 0.9;
  for (const r of M.floor === 'grass' ? land : []) {
    for (let x = Math.ceil(r.x0 / 80) * 80; x < r.x1 - 60; x += 80) {
      for (let z = Math.ceil(r.z0 / 80) * 80; z < r.z1 - 60; z += 80) {
        if (hash(x * 0.37 + z * 1.91) > 0.2) continue;
        const px = X(x + 10 + hash(x * 1.7 + z) * 50), py = Y(z + 10 + hash(x + z * 1.3) * 50);
        c.beginPath(); c.moveTo(px - 1.3, py - 1.1); c.lineTo(px, py); c.lineTo(px + 1.3, py - 1.4); c.stroke();
      }
    }
  }
  // paved squares, then the roads: always lighter than the land, with a darker curb, like the streets on a town map
  // (a room's own road color can be close to its ground, as Lumen Town's paving is)
  const curb = tint(M.top, -0.34);
  c.strokeStyle = curb; c.lineWidth = 2;
  for (const q of R.plazas || []) lineB(B(q[0], q[1], q[2], q[3]));
  for (const q of R.plazas || []) fillB(B(q[0], q[1], q[2], q[3]), tint(q[4] || '#e8e1f0', 0.25));
  const roads = R.roads || [], road = tint(R.roadColor || '#e9cf98', 0.38);
  const seg = r => { c.beginPath(); c.moveTo(X(r[0]), Y(r[1])); c.lineTo(X(r[2]), Y(r[3])); c.stroke(); };
  c.strokeStyle = curb;
  for (const r of roads) { c.lineWidth = (r[4] || 90) * FZ + 2.6; seg(r); }
  c.strokeStyle = road;
  for (const r of roads) { c.lineWidth = (r[4] || 90) * FZ; seg(r); }
  // hills and ledges (higher ones lighter), each standing up off the ground on a shadowed front
  for (const b of [...A.terrainBoxes].sort((p, q) => q.y - p.y)) {
    const col = TERRAIN[b.mat] || tint(M.top, clamp((450 - b.y) / 500, -0.2, 0.35));
    const lift = clamp(((b.base ?? 450) - b.y) * FZ * 0.16, 1.2, 6) / FZ;
    c.strokeStyle = LINE; c.lineWidth = 1.5;
    fillB(B(b.x0, b.x1, b.z0 - lift, b.z0), tint(col, -0.38)); lineB(B(b.x0, b.x1, b.z0 - lift, b.z1));
    fillB(B(b.x0, b.x1, b.z0, b.z1), col); lineB(B(b.x0, b.x1, b.z0, b.z1));
  }
  // hedges, walls and ridges, then bridges and ledges
  for (const hg of R.hedges || []) { const b = B(hg.x, hg.x + hg.w, hg.z0, hg.z1); fillB(b, '#4f8a47'); c.strokeStyle = '#2f5a2c'; c.lineWidth = 1.5; lineB(b); }
  for (const s of A.solids) {
    if (!s.wall3d || s.z0 == null) continue;
    const b = B(s.x, s.x + s.w, s.z0, s.z1);
    fillB(b, s.under ? '#8a7f70' : '#6d6680'); c.strokeStyle = LINE; c.lineWidth = 1.4; lineB(b);
  }
  for (const p of A.staticPlats || []) {
    if (p.full || p.z0 == null) continue;
    const b = B(p.x, p.x + p.w, p.z0, p.z1);
    fillB(b, '#c9a87a'); c.strokeStyle = LINE; c.lineWidth = 1.2; lineB(b);
  }
  // trees, bushes, rocks: the trees' dark edges first, then all their leaves, so a wood reads as one clump with an edge
  const trees = [], things = [];
  for (const d of [...(A.decor || []), ...(R.decor || []).map(d => ({ ...d, k: d.k || 1, z: d.z ?? 0 }))]) {
    const spec = DECOR[d.kind] || (String(d.kind).startsWith('booth') ? ['square', 40, '#ff9ab0', '#a84a6a'] : null);
    if (!spec || spec[0] === 'dot') continue;
    (spec[0] === 'canopy' ? trees : things).push([d, spec]);
  }
  const rad = ([d, s]) => Math.max(1.7, s[1] * (d.k || 1) * FZ);
  for (const it of trees) { c.fillStyle = it[1][3]; circle(X(it[0].x), Y(it[0].z), rad(it) + 1.2); }
  for (const it of trees) { c.fillStyle = it[1][2]; circle(X(it[0].x), Y(it[0].z), rad(it)); }
  c.fillStyle = 'rgba(255,255,255,0.24)';
  for (const it of trees) { const r = rad(it); if (r > 2.4) circle(X(it[0].x) - r * 0.32, Y(it[0].z) - r * 0.32, r * 0.42); }
  for (const [d, [kind, size, fill, edge]] of things) {
    const r = Math.max(1.4, size * (d.k || 1) * FZ), x = X(d.x), y = Y(d.z);
    if (kind === 'blob') {
      c.fillStyle = fill; c.beginPath(); c.ellipse(x, y, r, r * 0.8, 0, 0, TAU); c.fill();
      if (r > 2) { c.strokeStyle = edge; c.lineWidth = 1; c.stroke(); }
    } else if (kind === 'square') {
      c.fillStyle = fill; c.fillRect(x - r, y - r * 0.7, r * 2, r * 1.4);
      if (r > 2) { c.strokeStyle = edge; c.lineWidth = 1; c.strokeRect(x - r, y - r * 0.7, r * 2, r * 1.4); }
    } else if (kind === 'bar') {
      c.strokeStyle = fill; c.lineWidth = 1.4; c.beginPath(); c.moveTo(x - r, y); c.lineTo(x + r, y); c.stroke();
    }
  }
  // houses (their roofs, from above, with the door at the front) and the other big things
  for (const pr of R.props || []) {
    const x = X(pr.x);
    if (pr.kind === 'house' || pr.kind === 'building') {
      const hw = (pr.w || (pr.kind === 'house' ? 180 : 170)) / 2, z0 = pr.z ?? BZ0, z1 = pr.z != null ? z0 + (pr.depth || 130) : GZ1 + 40;
      const x0 = X(pr.x - hw), ww = hw * 2 * FZ, y0 = Y(z1), y1 = Y(z0), ym = (y0 + y1) / 2, roof = pr.roof || '#c45a5a';
      c.fillStyle = 'rgba(25,16,40,0.3)'; c.fillRect(x0 + 1.6, y0 + 2, ww, y1 - y0);   // (its shadow)
      c.fillStyle = tint(roof, -0.26); c.fillRect(x0, y0, ww, ym - y0);              // the back of the roof...
      c.fillStyle = roof; c.fillRect(x0, ym, ww, y1 - ym);                            // ...and the front
      c.strokeStyle = INK; c.lineWidth = 1.6; c.strokeRect(x0, y0, ww, y1 - y0);
      c.beginPath(); c.moveTo(x0, ym); c.lineTo(x0 + ww, ym); c.stroke();
      const door = (R.doors || []).find(d => d.style === 'none' && Math.abs(d.x - pr.x) < 70);
      if (door) { c.fillStyle = '#5a3a24'; c.fillRect(X(door.x) - 2.6, y1 - 1, 5.2, 2.8); c.lineWidth = 0.8; c.strokeRect(X(door.x) - 2.6, y1 - 1, 5.2, 2.8); }
    } else if (pr.kind === 'windmill') {
      const y = Y(pr.z ?? 200), r = 60 * FZ;
      c.strokeStyle = '#a87a4a'; c.lineWidth = 2;
      for (let i = 0; i < 4; i++) { const a = 0.4 + (i * Math.PI) / 2; c.beginPath(); c.moveTo(x, y); c.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r); c.stroke(); }
      c.fillStyle = '#f3e6c8'; c.strokeStyle = INK; c.lineWidth = 1.4; c.beginPath(); c.arc(x, y, r * 0.45, 0, TAU); c.fill(); c.stroke();
    } else if (pr.kind === 'lantern') {
      const y = Y(pr.z ?? 170);
      glowDot(c, x, y, 14, '255,214,120', 0.7);
      c.fillStyle = '#ffd23f'; c.strokeStyle = INK; c.lineWidth = 1.6; c.beginPath(); c.arc(x, y, 4.5, 0, TAU); c.fill(); c.stroke();
    } else if (pr.kind === 'bigtree') {
      const y = Y(pr.z ?? 180), r = 70 * FZ;
      c.fillStyle = '#3f8a3a'; circle(x, y, r + 1.2);
      c.fillStyle = '#5aa84a'; circle(x, y, r);
      c.fillStyle = 'rgba(255,255,255,0.24)'; circle(x - r * 0.3, y - r * 0.3, r * 0.42);
    } else if (pr.kind === 'hotspring') {
      c.fillStyle = '#9fdcf2'; c.strokeStyle = '#e2f6ff'; c.lineWidth = 1.5;
      c.beginPath(); c.ellipse(x, Y(pr.z ?? 60), 90 * FZ, 50 * FZ, 0, 0, TAU); c.fill(); c.stroke();
    } else if (pr.kind === 'dock') {
      c.fillStyle = '#b8875a'; c.strokeStyle = LINE; c.lineWidth = 1;
      c.fillRect(x - 5, Y(180), 10, 12); c.strokeRect(x - 5, Y(180), 10, 12);
    }
  }
  return { cv, w, h, X, Y, bg, k };
}

// ---------------------------------------------------------------- the picture of an old narrow room, from the side
function sideLayer(A, k) {
  const R = A.room, M = themeOf(A, R), st = R.style && STYLES[R.style];
  // (it shows the band of heights the floors and ledges are in, with room above them for Wick and the markers)
  const floors = R.ground.map(g => g[2]), ys = [...floors, ...(A.staticPlats || []).map(p => p.y)];
  const mid = (Math.min(...ys) - 110 + Math.max(...floors) + 60) / 2, half = SH / SZY / 2 + 30;
  const TOP = mid - half, BOT = mid + half;
  const w = (R.w + PAD * 2) * SZX, h = (BOT - TOP) * SZY;
  const [cv, c] = canvas(w, h, k);
  const X = x => (x + PAD) * SZX, Y = y => (y - TOP) * SZY;
  // (a little lighter than the room's own walls, so the ground and the ledges stand out in a dark cave)
  const wall = st ? st.wall : [tint(M.side || '#45385f', -0.12), tint(M.side || '#45385f', -0.45)];
  const g = c.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, wall[0]); g.addColorStop(1, wall[1] || wall[0]);
  c.fillStyle = g; c.fillRect(0, 0, w, h);
  c.fillStyle = 'rgba(10,6,20,0.45)'; c.fillRect(0, 0, X(0), h); c.fillRect(X(R.w), 0, w - X(R.w), h);   // (past its ends)
  // the gap below everything (water, ink, lava...), with a pale line on its surface
  const hz = R.hazard || 'pit';
  c.fillStyle = HAZARD[hz] || HAZARD.pit; c.fillRect(X(0), Y(500), R.w * SZX, h - Y(500));
  if (hz !== 'pit') { c.fillStyle = SHORE[hz] || tint(HAZARD[hz] || HAZARD.pit, 0.35); c.fillRect(X(0), Y(500), R.w * SZX, 1.6); }
  c.lineJoin = 'round';
  const front = Array.isArray(M.front) ? M.front[0] : tint(M.top, -0.3);
  for (const [x0, x1, y] of R.ground) {
    c.fillStyle = front; c.fillRect(X(x0), Y(y), (x1 - x0) * SZX, h - Y(y));
    c.fillStyle = M.top; c.fillRect(X(x0), Y(y), (x1 - x0) * SZX, Math.max(2.5, 12 * SZY));
    c.strokeStyle = LINE; c.lineWidth = 1.6;
    c.beginPath(); c.moveTo(X(x0), h + 2); c.lineTo(X(x0), Y(y)); c.lineTo(X(x1), Y(y)); c.lineTo(X(x1), h + 2); c.stroke();
  }
  for (const p of A.staticPlats || []) {
    const th = Math.max(4, 14 * SZY);
    c.fillStyle = tint(M.top, 0.1); c.fillRect(X(p.x), Y(p.y), p.w * SZX, th);
    c.strokeStyle = LINE; c.lineWidth = 1.2; c.strokeRect(X(p.x), Y(p.y), p.w * SZX, th);
  }
  c.fillStyle = tint(M.side || '#45385f', -0.15);
  for (const wl of R.walls || []) if (wl[4] == null) c.fillRect(X(wl[0]), Y(wl[1]), wl[2] * SZX, wl[3] * SZY);
  for (const kk of R.cracks || []) if (!A.broken(kk.id)) { c.fillStyle = '#9d97a8'; c.fillRect(X(kk.x), Y(kk.y), kk.w * SZX, kk.h * SZY); }
  const surf = x => { let best = null; for (const [a, b, y] of R.ground) if (x >= a && x <= b) best = best == null ? y : Math.min(best, y); return best ?? 450; };
  for (const b of R.boulders || []) {
    if (A.broken(b.id)) continue;
    c.fillStyle = '#a49e94'; c.strokeStyle = LINE; c.lineWidth = 1;
    c.beginPath(); c.ellipse(X(b.x), Y(surf(b.x) - 70), 70 * SZX, 70 * SZY, 0, 0, TAU); c.fill(); c.stroke();
  }
  for (const gt of R.gates || []) if (!A.flag(gt.flag)) { c.fillStyle = '#3a3448'; c.fillRect(X(gt.x), Y(gt.top), Math.max(2, gt.w * SZX), Y(surf(gt.x)) - Y(gt.top)); }
  for (const vn of R.vines || []) if (!A.broken(vn.id)) { c.fillStyle = 'rgba(80,150,70,0.9)'; c.fillRect(X(vn.x), Y(vn.y), vn.w * SZX, vn.h * SZY); }
  return { cv, w, h, X, Y, bg: wall[1] || wall[0], k };
}

// ---------------------------------------------------------------- markers
// Wick's face in a round badge, with a pointer for the way he's heading.
function wickBadge(c, x, y, ang, t, facing) {
  c.save(); c.translate(x, y); c.rotate(ang);
  c.fillStyle = '#ff6b6b'; c.strokeStyle = INK; c.lineWidth = 1.7; c.lineJoin = 'round';
  c.beginPath(); c.moveTo(16, 0); c.lineTo(6, -6.5); c.lineTo(6, 6.5); c.closePath(); c.fill(); c.stroke();
  c.restore();
  const q = (t * 1.1) % 1;
  c.strokeStyle = `rgba(255,107,107,${0.85 * (1 - q)})`; c.lineWidth = 2;
  c.beginPath(); c.arc(x, y, 10 + q * 10, 0, TAU); c.stroke();
  c.fillStyle = '#ff6b6b'; c.beginPath(); c.arc(x, y, 10, 0, TAU); c.fill();
  c.save();
  c.beginPath(); c.arc(x, y, 8.2, 0, TAU); c.clip();
  c.fillStyle = '#ffe9b8'; c.fillRect(x - 9, y - 9, 18, 18);
  try { DRAW.wick(c, x + 0.5 * facing, y + 19, { t, scale: 0.37, flip: facing, shadow: false, mood: 'happy' }); } catch (e) { /* (drawn without his face, then) */ }
  c.restore();
  c.strokeStyle = INK; c.lineWidth = 1.8; c.beginPath(); c.arc(x, y, 10, 0, TAU); c.stroke();
}

// Where a sprite's picture actually is, and how big (found once per kind by drawing it and looking at the pixels:
// partners come in all shapes, from Moss the blob to Doodle the crayon), so it can be fitted into a badge.
const FIT = {};
function spriteFit(kind) {
  if (FIT[kind]) return FIT[kind];
  let box = null;
  try {
    const n = 240, cv = document.createElement('canvas');
    cv.width = n; cv.height = n;
    const c = cv.getContext('2d');
    DRAW[kind](c, 120, 190, { t: 0, scale: 1, flip: 1, shadow: false, glasses: true });
    const d = c.getImageData(0, 0, n, n).data;
    let x0 = n, y0 = n, x1 = -1, y1 = -1;
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      if (d[(y * n + x) * 4 + 3] < 40) continue;
      if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
    }
    if (x1 >= 0) box = { cx: (x0 + x1) / 2 - 120, cy: (y0 + y1) / 2 - 190, size: Math.max(x1 - x0, y1 - y0, 10) };
  } catch (e) { /* (a sprite that needs more than this: a plain badge) */ }
  return (FIT[kind] = box || { cx: 0, cy: -30, size: 60 });
}

// Your partner, small, in a badge of their own.
function partnerBadge(c, kind, x, y, t, flip) {
  const f = spriteFit(kind), r = 7, s = (r * 2 * 0.9) / f.size;
  c.fillStyle = '#d6f5d9'; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill();
  c.save();
  c.beginPath(); c.arc(x, y, r - 0.6, 0, TAU); c.clip();
  try { DRAW[kind](c, x - f.cx * s * flip, y - f.cy * s, { t, scale: s, flip, shadow: false, glasses: true }); } catch (e) { /* */ }
  c.restore();
  c.strokeStyle = INK; c.lineWidth = 1.6; c.beginPath(); c.arc(x, y, r, 0, TAU); c.stroke();
}

// A gold map pin on what to do next (pale blue for a quest you're tracking), with a star in its head.
function pin(c, x, y, t, quest) {
  const b = Math.sin(t * 4) * 1.6;
  c.fillStyle = 'rgba(30,20,45,0.35)'; c.beginPath(); c.ellipse(x, y + 1, 4, 1.8, 0, 0, TAU); c.fill();
  glowDot(c, x, y - 11 + b, 15, quest ? '159,230,255' : '255,224,102', 0.55);
  c.save(); c.translate(x, y + b);
  c.fillStyle = quest ? '#9fe6ff' : '#ffd23f'; c.strokeStyle = INK; c.lineWidth = 1.8; c.lineJoin = 'round';
  c.beginPath(); c.moveTo(0, 0); c.bezierCurveTo(-2.5, -4, -7.5, -7, -7.5, -11.5); c.arc(0, -11.5, 7.5, Math.PI, 0);
  c.bezierCurveTo(7.5, -7, 2.5, -4, 0, 0); c.closePath(); c.fill(); c.stroke();
  c.fillStyle = '#fffaf0'; c.beginPath(); starPath(c, 0, -11.5, 4.6, 2); c.fill();
  c.restore();
}

// When the way to go is off the map: an arrow on the rim pointing at it, with a little star.
function rimArrow(c, wx, wy, mh, tx, ty, t, quest) {
  const cx = wx + MW / 2, cy = wy + mh / 2, dx = tx - cx, dy = ty - cy;
  const s = Math.min((MW / 2 - 15) / Math.max(1e-6, Math.abs(dx)), (mh / 2 - 15) / Math.max(1e-6, Math.abs(dy)));
  const a = Math.atan2(dy, dx), b = 1.5 + Math.sin(t * 5) * 1.5;
  const ax = cx + dx * s + Math.cos(a) * b, ay = cy + dy * s + Math.sin(a) * b;
  c.save(); c.translate(ax, ay); c.rotate(a);
  c.fillStyle = quest ? '#9fe6ff' : '#ffd23f'; c.strokeStyle = INK; c.lineWidth = 1.8; c.lineJoin = 'round';
  c.beginPath(); c.moveTo(10, 0); c.lineTo(-4, -8); c.lineTo(-1, 0); c.lineTo(-4, 8); c.closePath(); c.fill(); c.stroke();
  c.restore();
  const sx = ax - Math.cos(a) * 13, sy = ay - Math.sin(a) * 13;
  c.fillStyle = quest ? '#9fe6ff' : '#ffe066'; c.strokeStyle = INK; c.lineWidth = 1.4;
  c.beginPath(); starPath(c, sx, sy, 5.5, 2.4); c.fill(); c.stroke();
}

export const MINIMAP = {
  // (the old narrow rooms get one only when they're long; the inside of a house never does)
  wantsMinimap() {
    const R = this.room;
    return !!R && (this.field || (!R.interior && R.w >= W * 1.5));
  },

  inMinimap(x, y) {
    const r = this.miniRect;
    return !!r && x >= r[0] && x <= r[0] + r[2] && y >= r[1] && y <= r[1] + r[3];
  },

  // How far down the top bar (an HTML strip over the canvas) reaches, in canvas units, so the map sits under it.
  measureHud() {
    this.hudMeasure = false;
    this.hudMeasuredT = this.t;
    const right = this.hudEl && this.hudEl.querySelector('.hud-right'), g = this.cv.getBoundingClientRect();
    if (!right || !(g.height > 0)) return;
    this.hudBottom = clamp(((right.getBoundingClientRect().bottom - g.top) / g.height) * 540, 0, 200);
  },

  drawMinimap(c) {
    const R = this.room, P = this.p;
    if (!R || !P) return;
    const side = !this.field, mh = side ? SH : FH, zoom = side ? SZX : FZ;
    // the picture of the place (made again when the room or its walls change, at most a few times a second)
    const k = clamp(this.scale || 1, 1, 3), key = `${this.roomId}|${this.solidsGen || 0}|${k}`;
    let L = this.miniLayer;
    if (!L || L.key !== key) {
      const fresh = !L || L.room !== this.roomId || L.k !== k;
      if (fresh || this.t - L.built > 0.35) {
        L = this.miniLayer = side ? sideLayer(this, k) : fieldLayer(this, k);
        Object.assign(L, { key, room: this.roomId, built: this.t });
        if (fresh) this.miniCam = null;
      }
    }
    const dt = clamp(this.t - (this.miniT ?? this.t), 0, 0.1);
    this.miniT = this.t;
    if (this.hudMeasure || this.t - (this.hudMeasuredT ?? -9) > 2) this.measureHud();
    // where it sits (top right, under the top bar), and what it looks at: Wick, gliding after him, kept on the place
    const wx = W - MW - 20, wy = Math.max(58, Math.round((this.hudBottom || 36) + 26));
    const fit = (v, size, win) => { const lo = PAD * zoom - 16, hi = size - PAD * zoom + 16 - win; return hi < lo ? (size - win) / 2 : clamp(v, lo, hi); };
    const tx = fit(L.X(P.x) - MW / 2, L.w, MW), ty = side ? (L.h - mh) / 2 : fit(L.Y(P.z) - mh / 2, L.h, mh);
    const cam = this.miniCam || (this.miniCam = { x: tx, y: ty });
    if (Math.abs(tx - cam.x) > 160 || Math.abs(ty - cam.y) > 160) { cam.x = tx; cam.y = ty; }   // (a jump across the place)
    const ease = 1 - Math.exp(-dt * 9);
    cam.x += (tx - cam.x) * ease;
    cam.y += (ty - cam.y) * ease;
    const MX = x => wx + L.X(x) - cam.x, MY = v => wy + L.Y(v) - cam.y;   // (v: depth in a field, height from the side)
    // the frame: a paper card with the map sitting down inside it
    const ox = wx - 6, oy = wy - 6, ow = MW + 12, oh = mh + 12;
    c.save();
    c.fillStyle = 'rgba(0,0,0,0.28)'; c.beginPath(); rrect(ox, oy + 4, ow, oh, 14)(c); c.fill();
    c.fillStyle = PAPER; c.strokeStyle = INK; c.lineWidth = 3; c.beginPath(); rrect(ox, oy, ow, oh, 14)(c); c.fill(); c.stroke();
    c.save();
    c.beginPath(); rrect(wx, wy, MW, mh, 9)(c); c.clip();
    c.fillStyle = L.bg; c.fillRect(wx, wy, MW, mh);
    const sx0 = Math.max(0, cam.x), sy0 = Math.max(0, cam.y), sx1 = Math.min(L.w, cam.x + MW), sy1 = Math.min(L.h, cam.y + mh);
    if (sx1 > sx0 && sy1 > sy0) {
      c.drawImage(L.cv, sx0 * k, sy0 * k, (sx1 - sx0) * k, (sy1 - sy0) * k, wx + sx0 - cam.x, wy + sy0 - cam.y, sx1 - sx0, sy1 - sy0);
    }
    this.drawMiniMarks(c, MX, MY, wx, wy, mh, side, dt);
    const g = c.createLinearGradient(0, wy, 0, wy + 9);
    g.addColorStop(0, 'rgba(20,12,36,0.38)'); g.addColorStop(1, 'rgba(20,12,36,0)');
    c.fillStyle = g; c.fillRect(wx, wy, MW, 9);
    c.restore();
    c.strokeStyle = INK; c.lineWidth = 2; c.beginPath(); rrect(wx, wy, MW, mh, 9)(c); c.stroke();
    // the place's name on a tab, and a key for the big map
    const area = AREAS[R.area];
    c.font = 'bold 12px Fredoka, sans-serif'; c.textAlign = 'center';
    const name = `${area && area.icon ? `${area.icon} ` : ''}${R.name}`, tw = Math.min(MW - 60, c.measureText(name).width + 22);
    const nx = ox + 12, ny = oy - 11;
    c.fillStyle = '#7b5fc7'; c.strokeStyle = INK; c.lineWidth = 2; c.beginPath(); rrect(nx, ny, tw, 20, 10)(c); c.fill(); c.stroke();
    c.fillStyle = '#fffaf0'; c.fillText(name, nx + tw / 2, ny + 14.5, tw - 14);
    const kx = ox + ow - 44, ky = oy + oh - 9;
    c.font = 'bold 9.5px Fredoka, sans-serif';
    c.fillStyle = PAPER; c.lineWidth = 1.6; c.beginPath(); rrect(kx, ky, 34, 15, 5)(c); c.fill(); c.stroke();
    c.fillStyle = INK; c.fillText('TAB', kx + 17, ky + 11);
    c.restore();
    this.miniRect = [ox, ny, ow, ky + 15 - ny];
  },

  drawMiniMarks(c, MX, MY, wx, wy, mh, side, dt) {
    const R = this.room, P = this.p, t = this.t, id = this.roomId, s = this.s;
    const near = (x, y, pad = 14) => x > wx - pad && x < wx + MW + pad && y > wy - pad && y < wy + mh + pad;
    const surf = x => { let best = null; for (const [a, b, y] of R.ground) if (x >= a && x <= b) best = best == null ? y : Math.min(best, y); return best ?? 450; };
    // a spot on the map: (x, depth) in a field, (x, height) seen from the side
    const at = (x, z, y) => [MX(x), MY(side ? y : z)];
    // crates (they get pushed around, so they're drawn here rather than in the picture)
    if (!side) {
      for (const o of this.crates || []) {
        const [x, y] = at(o.x, o.z);
        if (!near(x, y)) continue;
        c.fillStyle = '#c49a6a'; c.strokeStyle = INK; c.lineWidth = 1; c.fillRect(x - 3, y - 3, 6, 6); c.strokeRect(x - 3, y - 3, 6, 6);
      }
    }
    // ? blocks, chests, things still to find, lampposts, and shops, quest boards and shrines
    for (const b of R.blocks || []) {
      if ((b.hidden && !s.revealed[b.id]) || s.opened[b.id]) continue;
      const [x, y] = at(b.x + 22, b.z ?? 0, b.y + 22);
      if (near(x, y)) IC.iconBlock(c, x, y, 0.45, false);
    }
    for (const ch of R.chests || []) {
      if ((ch.needBroken && !this.broken(ch.needBroken)) || s.opened[ch.id]) continue;
      const [x, y] = at(ch.x, ch.z ?? 0, (ch.y ?? surf(ch.x)) - 6);
      if (near(x, y)) IC.iconChest(c, x, y + 2, 0.5, false);
    }
    for (const it of R.collect || []) {
      if (s.collected[it.id]) continue;
      const [x, y] = at(it.x, it.z ?? 0, it.y ?? surf(it.x) - 30);
      if (near(x, y)) IC.iconSparkle(c, x, y, 0.42, t);
    }
    for (const l of this.lampList()) {
      const [x, y] = at(l.x, l.z, surf(l.x) - 14);
      if (near(x, y)) IC.iconLamp(c, x, y + 4, 0.5, s.opened[`lamp_${id}_${l.x}`], t);
    }
    for (const [list, emoji, kind] of [[R.shops, '🛍️', 'shop'], [R.boards, '📋', 'board'], [R.shrines, '⛩️', 'shrine']]) {
      for (const o of list || []) {
        const [x, y] = at(o.x, this.thingZ(o, kind), surf(o.x) - 40);
        if (near(x, y)) IC.iconBubble(c, x, y - 2, 0.55, emoji);
      }
    }
    // doors and paths (a house's door smaller: its roof is already there), and the roads off the sides
    for (const d of R.doors || []) {
      const [x, y] = at(d.x, this.doorZ(d), surf(d.x) - 16);
      if (near(x, y, 20)) IC.iconDoor(c, x, y - 1, d.style === 'none' ? 0.36 : 0.44, !!(d.need && !this.flag(d.need)));
    }
    for (const way of ['left', 'right']) {
      const e = R.exits && R.exits[way];
      if (!e || !ROOMS[e.to]) continue;
      const ez = e.z0 != null ? (e.z0 + Math.min(e.z1, e.z0 + 400)) / 2 : (GZ0 + (this.zb || GZ1)) / 2;
      const [x, y] = at(way === 'left' ? 0 : R.w, ez, surf(way === 'left' ? 20 : R.w - 20) - 50);
      if (near(x, y, 20)) IC.iconExit(c, x + (way === 'left' ? 8 : -8), y, way === 'left' ? -1 : 1, 0.46);
    }
    // folks (a red ! over anyone with something new to say: worked out twice a second, it's a lot of checking)
    if (!this.miniNews || this.miniNews.room !== id || t - this.miniNews.t > 0.5) {
      this.miniNews = { t, room: id, set: new Set((R.npcs || []).filter(n => n.talk && (!n.show || n.show(this)) && this.npcHasNews(n))) };
    }
    const news = [];
    for (const n of R.npcs || []) {
      if (n.show && !n.show(this)) continue;
      const [x, y] = at(n.x, n.z ?? 0, (n.y ?? surf(n.x)) - 12);
      if (!near(x, y)) continue;
      c.fillStyle = '#fffaf0'; c.strokeStyle = INK; c.lineWidth = 1.3;
      c.beginPath(); c.arc(x, y, 3.4, 0, TAU); c.fill(); c.stroke();
      c.fillStyle = '#9a82e0'; c.beginPath(); c.arc(x, y, 1.5, 0, TAU); c.fill();
      if (this.miniNews.set.has(n)) news.push([x, y]);
    }
    // enemies: spiky red, and pulsing while one's chasing you
    for (const e of this.enemies || []) {
      if (e.dead) continue;
      const [x, y] = at(e.x, e.z, e.y - (e.h || 40) / 2);
      if (!near(x, y)) continue;
      const chase = e.ai === 'chase' || e.ai === 'alert';
      if (chase) { const q = (t * 2.2) % 1; c.strokeStyle = `rgba(229,83,75,${1 - q})`; c.lineWidth = 2; c.beginPath(); c.arc(x, y, 5 + q * 9, 0, TAU); c.stroke(); }
      c.fillStyle = chase ? '#ff4d4d' : '#e5534b'; c.strokeStyle = INK; c.lineWidth = 1.3;
      c.beginPath(); starPath(c, x, y, chase ? 5.6 : 4.8, 2.8, 6); c.fill(); c.stroke();
    }
    for (const [x, y] of news) IC.newsMark(c, x, y - 8, t, 0.62);
    // what the guide points at: the goal, if it's here; otherwise the door or way out to take first
    const g = this.guide || {}, step = g.path && g.path[0];
    let target = null;
    if (g.goal && g.path && !step && g.goal.room === id && g.goal.x != null) {
      const [x, y] = at(g.goal.x, goalZ(this, g.goal), surf(g.goal.x) - 40);
      target = { x, y, star: true };
    } else if (step && step.via === 'door' && step.door) {
      const [x, y] = at(step.x, this.doorZ(step.door), surf(step.x) - 16);
      target = { x, y };
    } else if (step && (step.via === 'left' || step.via === 'right')) {
      const e = step.exit || {};
      const ez = e.z0 != null ? (e.z0 + Math.min(e.z1, e.z0 + 400)) / 2 : (GZ0 + (this.zb || GZ1)) / 2;
      const [x, y] = at(step.via === 'left' ? 0 : R.w, ez, surf(step.via === 'left' ? 20 : R.w - 20) - 50);
      target = { x: x + (step.via === 'left' ? 8 : -8), y };
    }
    if (target && s.guide !== false) {
      const quest = !!(g.goal && g.goal.quest);
      if (target.x > wx + 2 && target.x < wx + MW - 2 && target.y > wy + 2 && target.y < wy + mh + 2) {
        if (target.star) pin(c, target.x, target.y, t, quest);
        else {
          const q = (t * 1.6) % 1;
          c.strokeStyle = quest ? `rgba(159,230,255,${1 - q})` : `rgba(255,224,102,${1 - q})`; c.lineWidth = 2.5;
          c.beginPath(); c.arc(target.x, target.y, 8 + q * 8, 0, TAU); c.stroke();
          pin(c, target.x, target.y - 7, t, quest);
        }
      } else rimArrow(c, wx, wy, mh, target.x, target.y, t, quest);
    }
    // you (pointing the way you're heading; the last way, when you stop), with your partner's badge tucked in behind
    const moving = Math.hypot(P.vx || 0, side ? 0 : P.vz || 0) > 40;
    let want = this.miniAng;
    if (moving) want = side ? (P.vx < 0 ? Math.PI : 0) : Math.atan2(-(P.vz || 0), P.vx || 0);
    else if (want == null || side) want = (P.facing || 1) < 0 ? Math.PI : 0;
    const cur = this.miniAng ?? want;
    this.miniAng = cur + Math.atan2(Math.sin(want - cur), Math.cos(want - cur)) * Math.min(1, dt * 12);
    const [x, y] = at(P.x, P.z, P.y - 30);
    const pp = this.partnerPos, pid = s.partner;
    if (pid && DRAW[pid] && pp) {
      // (they walk right behind Wick, which on this map is under his badge: so theirs keeps a little way off)
      const [px, py] = at(pp.x, pp.z, pp.y - 24);
      let dx = px - x, dy = py - y, d = Math.hypot(dx, dy);
      if (d < 0.5) { dx = -Math.cos(this.miniAng); dy = -Math.sin(this.miniAng); d = 1; }
      if (d < 15) { dx = (dx / d) * 15; dy = (dy / d) * 15; }
      partnerBadge(c, pid, x + dx, y + dy, t, this.partnerFlip || 1);
    }
    wickBadge(c, x, y, this.miniAng, t, (P.facing || 1) < 0 ? -1 : 1);
  },
};
