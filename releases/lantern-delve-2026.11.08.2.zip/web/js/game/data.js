// Everything the adventure is made of: rooms, story scripts, quests, enemies, partners, items and badges.
// Rooms are 540 tall; the usual floor is at y = 450. The expansion (interiors, the castle, the dojo...) is merged in below.
import {
  MORE_ROOMS, patchRooms, MORE_SCRIPTS, MORE_QUESTS, QUEST_ROOMS, MORE_ENEMIES, MORE_BADGES, MORE_KEY_ITEMS,
  MORE_SPEAKERS, MORE_SPEAKER_OPTS, PORTRAIT_SCALE,
} from './expansion.js';
import {
  WILD_ROOMS, patchWilds, WILD_AREAS, WILD_ENEMIES, WILD_BADGES, WILD_SPEAKERS, WILD_SPEAKER_OPTS, WILD_PORTRAITS, WILD_QUESTS, WILD_SCRIPTS,
} from './wilds.js';
import { deepenRooms, DEEP_SPEAKERS, DEEP_SPEAKER_OPTS, DEEP_SCRIPTS } from './deep.js';
import { MINI_SCRIPTS, MINI_SPEAKERS, MINI_SPEAKER_OPTS } from './minigames.js';
import {
  TOWER_ROOMS, TOWER_SCRIPTS, TOWER_ENEMIES, TOWER_PARTNERS, TOWER_BADGES, TOWER_QUESTS, TOWER_SPEAKERS, TOWER_SPEAKER_OPTS,
  TOWER_PORTRAITS, towerGoal, AFTER_STORY, patchTower,
} from './tower.js';
import { STORY_SCRIPTS, patchStory } from './story.js';
import {
  MARGIN_ROOMS, MARGIN_SCRIPTS, MARGIN_ENEMIES, MARGIN_PARTNERS, MARGIN_BADGES, MARGIN_QUESTS, MARGIN_SPEAKERS, MARGIN_SPEAKER_OPTS,
  MARGIN_PORTRAITS, marginGoal, MARGIN_AFTER, patchMargin,
} from './margin.js';

export function newSave() {
  return {
    v: 2,
    // atk/def come from Dojo training (and a couple of badges)
    hero: { lvl: 1, xp: 0, hp: 10, maxHp: 10, fp: 5, maxFp: 5, bp: 3, atk: 0, def: 0 },
    partners: {}, partner: null, palAtk: 0, training: {},
    items: { honeybun: 2 }, keyItems: [], abilities: {},
    badges: { owned: ['timing_tutor'], equipped: ['timing_tutor'] },
    flags: {}, opened: {}, broken: {}, shards: 0,
    room: 'pro_1', x: 1000, lamp: { room: 'pro_1', x: 1000 },
    battlesWon: 0, seenAreas: {}, areaLamps: {}, visited: {}, tracked: null, guide: true,
    mapSeen: {},   // (which bits of each place the maps have filled in: explore.js)
    quests: {}, kills: {}, tattled: {}, revealed: {}, collected: {},
    // the Paper Plains: sticker album, peeled and stuck stickers, crate spots, rescued folks, patched tears
    stickers: {}, peeled: {}, stuck: {}, crates: {}, rescued: {}, patched: {}, confetti: 0,
  };
}

export const SPEAKERS = {
  Mothwick: 'mothwick', Moss: 'moss', Hoot: 'hoot', Pebble: 'pebble', 'Count Dusk': 'dusk',
  'King Grumblecap': 'grumblecap', Smudge: 'smudge', Nutkin: 'acorn', 'Origami Sage': 'crane', Wick: 'wick',
  Lampkin: 'folk', Glimmer: 'folk', 'Farmer Barley': 'folk', 'Fisher Finn': 'folk', 'Librarian Quill': 'folk',
  'Hunter Hazel': 'folk', 'Old Rosa': 'folk',
  Ember: 'ember', 'Granny Hearth': 'ember', 'Anvil Annie': 'ember', 'Little Spark': 'ember', Kettle: 'kettle', Cindermaw: 'cindermaw',
};
export const SPEAKER_OPTS = {
  'Granny Hearth': { look: 'granny' }, 'Anvil Annie': { look: 'annie' }, 'Little Spark': { look: 'kid' },
  Lampkin: { color: '#5a6fb0' }, Glimmer: { color: '#c46a8f' },
  'Farmer Barley': { color: '#d9a066', body: '#6b8a3a', hat: 'straw' },
  'Fisher Finn': { color: '#4f9fd6', body: '#3b5a7b', hat: 'bucket' },
  'Librarian Quill': { color: '#a8743a', body: '#5a4fa8', specs: true },
  'Hunter Hazel': { color: '#7cc46a', body: '#3d6b4a', hat: 'feather' },
  'Old Rosa': { color: '#ff9ab0', body: '#7a5a8a', hat: 'straw' },
};

// ---------------------------------------------------------------- party
// Bond grows from real focus minutes with that partner as your study buddy.
export const BOND_LEVELS = [0, 2700, 9000, 18000];   // seconds: Lv1, Lv2 (45 min), Lv3 (2.5 h), Lv4 (5 h)
export function bondLevel(sec) {
  let lv = 1;
  for (let i = 1; i < BOND_LEVELS.length; i++) if ((sec || 0) >= BOND_LEVELS[i]) lv = i + 1;
  return lv;
}

export const PARTNERS = {
  moss: {
    name: 'Moss', hp: 8, color: '#6cc04a',
    moves: [
      { id: 'bounce', name: 'Bounce', fp: 0, desc: 'Bounce on an enemy. Press SPACE as you land to bounce again!' },
      { id: 'gloop', name: 'Gloop Shot', fp: 2, desc: 'Hits every enemy for 1 and might glue them in place.' },
    ],
    team: { name: 'Slime Spring', fp: 3, desc: 'Wick springs off Moss and stomps an enemy again and again. More stomps at higher Bond.' },
    field: { name: 'Spring', desc: 'Moss launches Wick super high.' },
  },
  hoot: {
    name: 'Hoot', hp: 7, color: '#a76f48',
    moves: [
      { id: 'peck', name: 'Peck', fp: 0, desc: 'Peck one enemy (reaches flyers). Time SPACE for a second peck.' },
      { id: 'tattle', name: 'Tattle', fp: 0, desc: 'Learn about an enemy (and reveal invisible ones).' },
      { id: 'gust', name: 'Gust', fp: 3, desc: 'Hits every enemy for 1 and knocks flyers to the ground.' },
    ],
    team: { name: 'Owl Express', fp: 4, desc: 'Hoot flies Wick over every enemy, flyers too, for a stomp on each. Two passes at Bond 3.' },
    field: { name: 'Peek', desc: 'Hoot spots hidden blocks and secrets nearby.' },
  },
  pebble: {
    name: 'Pebble', hp: 10, color: '#8d8a9c',
    moves: [
      { id: 'slam', name: 'Rock Slam', fp: 0, desc: 'Ignores defense. Hold SPACE, release when the star lights up!' },
      { id: 'shield', name: 'Shield Up', fp: 2, desc: 'Wick takes no damage until your next turn.' },
    ],
    team: { name: 'Boulder Bowl', fp: 4, desc: 'Wick hammers Pebble through every ground enemy, ignoring defense. Bounces back at Bond 2.' },
    field: { name: 'Smash', desc: 'Pebble smashes big boulders.' },
  },
  ember: {
    name: 'Ember', hp: 8, color: '#ff8a3d',
    moves: [
      { id: 'toss', name: 'Fire Toss', fp: 0, desc: 'Throw a fireball at any enemy (reaches flyers). Press SPACE as it lands to set it on fire!' },
      { id: 'focus', name: 'Focus Flame', fp: 2, desc: 'All the heat on ONE enemy. Hold SPACE, let go at the ⭐: 4 damage that ignores defense.' },
      { id: 'wildfire', name: 'Wildfire', fp: 3, desc: 'Fire on every enemy for 1 damage. Time SPACE to set them all on fire.' },
    ],
    team: { name: 'Flame Rally', fp: 4, desc: 'Wick and Ember bat a fireball back and forth: SPACE, X, SPACE... Every hit makes it bigger, then it slams one enemy. Longer rallies at higher Bond.' },
    field: { name: 'Fire Toss', desc: 'Ember throws a fireball: it lights braziers and burns away vines.' },
  },
};

// ---------------------------------------------------------------- enemies
export const ENEMIES = {
  gloomling: { name: 'Gloomling', hp: 2, atk: 1, def: 0, xp: 10, coins: [1, 2], h: 38, lvl: 1,
    tattle: "That's a Gloomling. It's a little blob of 'I'll do it later' with teeth. Max HP 2, Attack 1. Bonk it and it pops!" },
  spikeshroom: { name: 'Spikeshroom', hp: 3, atk: 1, def: 0, spiky: true, xp: 12, coins: [1, 3], h: 46, lvl: 2,
    tattle: 'A Spikeshroom. See those spikes? Jumping on it is a terrible idea. Use your hammer! Max HP 3, Attack 1.' },
  buzzbug: { name: 'Buzzbug', hp: 2, atk: 1, def: 0, flying: true, xp: 12, coins: [1, 2], h: 36, lvl: 2,
    tattle: "A Buzzbug. It flies, so hammers can't reach it. Jump on it or let me peck it! Max HP 2, Attack 1." },
  snailshell: { name: 'Snailshell', hp: 3, atk: 1, def: 0, shell: true, xp: 12, coins: [1, 3], h: 40, lvl: 2,
    tattle: "A Snailshell. Its shell blocks everything, but any hit flips it on its back! Flipped, it can't fight and takes full damage. Max HP 3." },
  inkblot: { name: 'Inkblot', hp: 4, atk: 2, def: 0, xp: 16, coins: [2, 3], h: 40, lvl: 4, splash: true,
    tattle: "An Inkblot: one of Smudge's rejected drafts that came to life. Its ink splash makes your timing harder! Max HP 4, Attack 2." },
  shellcrab: { name: 'Shellcrab', hp: 4, atk: 2, def: 1, xp: 18, coins: [2, 4], h: 42, lvl: 4,
    tattle: "A Shellcrab. Its crystal shell gives it 1 Defense, so weak hits bounce off. Pebble's Rock Slam ignores defense! Max HP 4, Attack 2." },
  glowbat: { name: 'Glowbat', hp: 3, atk: 2, def: 0, flying: true, drain: true, xp: 18, coins: [2, 3], h: 36, lvl: 4,
    tattle: 'A Glowbat. It drinks light (rude) and heals when it bites you. It flies, so no hammers! Max HP 3, Attack 2.' },
  puddlet: { name: 'Puddlet', hp: 4, atk: 1, def: 0, splits: true, xp: 12, coins: [1, 2], h: 42, lvl: 3,
    tattle: 'A Puddlet. Hit it without finishing it and it splits into two little Puddlets! Big hits are best. Max HP 4.' },
  mirrormoth: { name: 'Mirror Moth', hp: 4, atk: 2, def: 0, flying: true, mirror: true, xp: 18, coins: [2, 3], h: 46, lvl: 5,
    tattle: 'A Mirror Moth. When its wings shimmer, attacks bounce right back at you! Defend or wait for the shimmer to fade. Max HP 4.' },
  wisp: { name: 'Glimmerwisp', hp: 3, atk: 1, def: 0, flying: true, healer: true, xp: 14, coins: [1, 3], h: 40, lvl: 5,
    tattle: 'A Glimmerwisp. It heals its friends every turn, so take it out first! Max HP 3.' },
  bombshroom: { name: 'Bombshroom', hp: 3, atk: 1, def: 0, bomb: true, xp: 16, coins: [2, 4], h: 46, lvl: 5,
    tattle: "A Bombshroom. Its fuse counts 3, 2, 1... then BOOM, hitting everybody hard. Beat it before the fuse runs out! Max HP 3." },
  raccoon: { name: 'Pickpocket', hp: 5, atk: 1, def: 0, thief: true, xp: 18, coins: [4, 8], h: 48, lvl: 5,
    tattle: 'A Pickpocket raccoon. It steals an item and runs off two turns later. Beat it to get your stuff back! Max HP 5.' },
  thornback: { name: 'Thornback', hp: 4, atk: 2, def: 0, thorns: true, xp: 18, coins: [2, 4], h: 42, lvl: 6,
    tattle: "A Thornback. Its spikes flip up and down every turn. Jump when they're down, hammer when they're up. Max HP 4, Attack 2." },
  grumblecap: { name: 'King Grumblecap', hp: 20, atk: 2, def: 0, boss: true, xp: 80, coins: [25, 25], h: 120, scale: 2.2, lvl: 6,
    tattle: 'King Grumblecap. The Gloom convinced him everything can wait until tomorrow. He calls Spikeshrooms for help, and his spores put you to sleep. Max HP 20, Attack 2.' },
  smudge: { name: 'Smudge', hp: 28, atk: 3, def: 0, boss: true, xp: 120, coins: [40, 40], h: 120, scale: 1.7, lvl: 9,
    tattle: "Smudge, the Ink Witch. A perfectionist who ruins anything that isn't flawless, even her own work. She turns invisible and rains ink on everyone. Max HP 28, Attack 3." },
  bramblebeast: { name: 'Bramble Beast', hp: 30, atk: 2, def: 1, boss: true, thorns: true, xp: 120, coins: [40, 40], h: 110, scale: 2.0, lvl: 8,
    tattle: 'The Bramble Beast, king of the thicket. Its thorns flip up and down, it calls Thornbacks, and its vines hit everyone. Defense 1: try Pebble or a Team Attack.' },
  // Ember Peak (fire enemies can't be set on fire)
  cinderling: { name: 'Cinderling', hp: 2, atk: 1, def: 0, fire: true, grows: true, xp: 14, coins: [1, 3], h: 38, lvl: 6,
    tattle: "A Cinderling: a little flame of an unfinished task. It spits embers at you, and leave it alone and it GROWS every turn: bigger, it spits two. Fully grown it's too hot to jump on and FLARES UP, sending a wave of fire along the floor through everyone. Deal with it early! Max HP 2." },
  magmaw: { name: 'Magmaw', hp: 3, atk: 2, def: 0, fire: true, dives: true, xp: 16, coins: [2, 3], h: 40, lvl: 6,
    tattle: "A Magmaw. It ducks into its lava puddle where nothing can reach it. From down there it can make the floor under you bubble and blow up as a LAVA GEYSER: guard the moment it erupts! Or it just pops out to bite. Hit it while it's up! Max HP 3, Attack 2." },
  ashcrow: { name: 'Ashcrow', hp: 3, atk: 1, def: 0, flying: true, smoke: true, xp: 16, coins: [2, 3], h: 36, lvl: 7,
    tattle: "An Ashcrow. It flaps soot in your face so you can't see the timing cues: go by feel! It flies, so no hammers. Max HP 3." },
  jugglit: { name: 'Jugglit', hp: 4, atk: 1, def: 0, fire: true, juggles: true, xp: 18, coins: [2, 4], h: 44, lvl: 7,
    tattle: 'A Jugglit. It juggles WAY too many fireballs and throws every one at you. Guard all three and it drops everything and gets dizzy! Max HP 4.' },
  slagbrute: { name: 'Slagbrute', hp: 6, atk: 2, def: 2, armor: true, xp: 24, coins: [3, 5], h: 50, lvl: 8,
    tattle: "A Slagbrute: cooled lava, hard as rock (Defense 2!). Fire melts it soft for 2 turns, but then it's too hot to jump on. Pebble ignores its armor too. Max HP 6." },
  cindermaw: { name: 'Cindermaw', hp: 26, atk: 3, def: 0, boss: true, fire: true, xp: 160, coins: [50, 50], h: 100, scale: 1.9, lvl: 11,
    tattle: 'Cindermaw, the heart of Ember Peak. The Gloom told it to do EVERYTHING at once. It piles up Cinderlings (unfinished tasks), and if three pile up it OVERWHELMS you. Clear them one at a time! Max HP 30.' },
};

// ---------------------------------------------------------------- items & badges
export const ITEMS = {
  honeybun: { name: 'Honey Bun', icon: '🍯', desc: 'Restores 5 HP.', price: 5, hp: 5 },
  bighoney: { name: 'Big Honey Bun', icon: '🥮', desc: 'Restores 12 HP.', price: 14, hp: 12 },
  embertea: { name: 'Ember Tea', icon: '🍵', desc: 'Restores 5 FP.', price: 8, fp: 5 },
  windcookie: { name: 'Windmill Cookie', icon: '🍪', desc: 'Restores 8 HP and 3 FP.', price: 12, hp: 8, fp: 3 },
  fireseed: { name: 'Fire Seed', icon: '🔥', desc: 'Battle: 3 damage to every enemy.', price: 10, battle: true, dmgAll: 3 },
  sleepydust: { name: 'Sleepy Dust', icon: '💤', desc: 'Battle: puts every enemy to sleep for 2 turns.', price: 12, battle: true, sleepAll: 2 },
  feather: { name: 'Revive Feather', icon: '🪶', desc: 'If Wick goes down in battle, revive with half HP.', price: 25, auto: true },
};
export const KEY_ITEMS = { glasses: "Hoot's Spectacles", book: "'Advanced Napping' (library book)" };

export const BADGES = {
  timing_tutor: { name: 'Timing Tutor', bp: 0, price: 5, desc: 'Shows exactly when to press SPACE in battle.' },
  power_jump: { name: 'Power Jump', bp: 1, price: 30, desc: 'Special move: a mighty jump for 3 damage (2 FP).' },
  quake_hammer: { name: 'Quake Hammer', bp: 2, price: 40, desc: 'Special move: hit every ground enemy (2 FP).' },
  spike_shield: { name: 'Spike Shield', bp: 2, price: 35, desc: 'Jump on spiky enemies without getting hurt.' },
  iron_guard: { name: 'Iron Guard', bp: 1, price: 25, desc: 'Guarding blocks 2 damage instead of 1.' },
  coin_magnet: { name: 'Coin Magnet', bp: 1, price: 30, desc: '+50% coins from battles.' },
  happy_heart: { name: 'Happy Heart', bp: 2, price: 50, desc: 'Recover 1 HP at the end of every turn.' },
  ember_heart: { name: 'Ember Heart', bp: 2, stars: 3, desc: '+10% Light from homework focus! (Works in real life.)' },
  lucky_star: { name: 'Lucky Star', bp: 2, stars: 2, desc: 'Enemies miss you 15% of the time.' },
  hp_plus: { name: 'HP Plus', bp: 2, stars: 2, desc: '+5 max HP.' },
  fp_plus: { name: 'FP Plus', bp: 2, stars: 2, desc: '+5 max FP.' },
  // quest & secret rewards
  acorn_armor: { name: 'Acorn Armor', bp: 2, desc: 'Take 1 less damage from every attack.' },
  bookworm: { name: 'Bookworm', bp: 1, desc: '+25% XP from battles.' },
  koi_charm: { name: 'Lucky Koi', bp: 1, desc: '+1 coin for every enemy you defeat.' },
  thorn_crown: { name: 'Thorn Crown', bp: 2, desc: 'Enemies that hit you take 1 damage back.' },
  field_monocle: { name: "Scholar's Monocle", bp: 1, desc: "Always see every enemy's HP." },
  first_light: { name: 'First Light', bp: 1, desc: 'Recover 1 FP at the end of every turn.' },
  clean_flame: { name: 'Clean Flame', bp: 2, desc: 'Team Attacks cost 1 less FP.' },
  hero_heart: { name: "Hero's Heart", bp: 2, desc: '+1 damage on every hit while your HP is full.' },
  marathon: { name: 'Marathon Moth', bp: 3, desc: '+1 damage on every attack.' },
  focus_core: { name: 'Heart of Focus', bp: 2, desc: '+15% Light from homework focus. (Works in real life!)' },
  perfectly_imperfect: { name: 'Perfectly Imperfect', bp: 1, desc: 'Timing windows for every action command are 40% wider.' },
  kindling: { name: 'Kindling', bp: 1, desc: "Your partner's attacks deal +1 damage." },
  second_wind: { name: 'Second Wind', bp: 1, desc: 'Recover 2 FP at the start of every battle.' },
  hot_hammer: { name: 'Hot Hammer', bp: 2, desc: 'Hammer hits set enemies on fire (1 damage a turn for 2 turns).' },
  ember_ward: { name: 'Ember Ward', bp: 1, desc: "Fireproof! Burns can't hurt you, and you can jump on fiery enemies." },
};
export const SHOP_ITEMS = ['honeybun', 'bighoney', 'embertea', 'windcookie', 'fireseed', 'sleepydust', 'feather'];
export const SHOP_BADGES = ['timing_tutor', 'power_jump', 'iron_guard', 'spike_shield', 'coin_magnet', 'quake_hammer', 'happy_heart'];
export const STAR_BADGES = ['ember_heart', 'lucky_star', 'hp_plus', 'fp_plus'];
export const CHEST_BADGES = ['power_jump', 'iron_guard', 'coin_magnet', 'spike_shield', 'quake_hammer', 'happy_heart', 'lucky_star', 'hp_plus', 'fp_plus'];

// ---------------------------------------------------------------- side quests
const mins = s => `${Math.floor((s || 0) / 60)} min`;
const hours = s => `${((s || 0) / 3600).toFixed(1)} h`;
export const QUESTS = {
  study_first: { name: 'First Light', giver: 'Mothwick', where: 'Lumen Town plaza', study: true,
    desc: 'Study Challenge: finish one focus session that lasts 25 minutes or longer.',
    progress: A => ({ done: A.stat('best_session') >= 1500, text: `Longest session: ${mins(A.stat('best_session'))} of 25` }),
    reward: { badge: 'first_light', coins: 20 } },
  study_clean: { name: 'Clean Flame', giver: 'Mothwick', where: 'Lumen Town plaza', study: true,
    desc: 'Study Challenge: finish a clean session (20+ minutes with zero distractions).',
    progress: A => ({ done: A.stat('clean_sessions') >= 1, text: `Clean sessions: ${A.stat('clean_sessions')} of 1` }),
    reward: { badge: 'clean_flame', coins: 20 } },
  study_hero: { name: 'Homework Hero', giver: 'Mothwick', where: 'Lumen Town plaza', study: true,
    desc: 'Study Challenge: finish a whole assignment, every step checked off.',
    progress: A => ({ done: A.stat('quests_done') >= 1, text: `Assignments finished: ${A.stat('quests_done')} of 1` }),
    reward: { badge: 'hero_heart', starPieces: 1 } },
  study_marathon: { name: 'Marathon Moth', giver: 'Mothwick', where: 'Lumen Town plaza', study: true,
    desc: 'Study Challenge: focus for 5 hours in total.',
    progress: A => ({ done: A.stat('focus_seconds') >= 18000, text: `Total focus: ${hours(A.stat('focus_seconds'))} of 5 h` }),
    reward: { badge: 'marathon', starPieces: 1 } },
  acorns: { name: "Nutkin's Golden Acorns", giver: 'Nutkin', where: 'Grove Gate',
    desc: 'Find 5 golden acorns hidden around the Grumbling Grove and Lumen Fields.',
    progress: A => { const n = A.collectedCount('acorn'); return { done: n >= 5, text: `Golden acorns: ${n} of 5` }; },
    reward: { badge: 'acorn_armor', coins: 15 } },
  windmill: { name: 'Windmill Woes', giver: 'Farmer Barley', where: 'Lumen Fields, by the windmill',
    desc: 'Defeat 5 Gloomlings in Lumen Fields. They keep jamming the windmill.',
    progress: A => { const n = A.s.kills.fields_gloomling || 0; return { done: n >= 5, text: `Field Gloomlings defeated: ${Math.min(5, n)} of 5` }; },
    reward: { coins: 25, items: { windcookie: 3 } } },
  koi: { name: 'The Golden Koi', giver: 'Fisher Finn', where: 'Mirror Lake dock',
    desc: 'Catch the legendary Golden Koi at the Mirror Lake dock. Land three fish in a row and it might bite!',
    progress: A => ({ done: A.flag('koi_caught'), text: A.flag('koi_caught') ? 'Golden Koi caught!' : 'Not caught yet' }),
    reward: { badge: 'koi_charm', starPieces: 1 } },
  overdue: { name: 'The Overdue Book', giver: 'Librarian Quill', where: 'Lumen Town, outside the library',
    desc: "Find 'Advanced Napping' somewhere in the Sunken Library under Mirror Lake. It's very dark down there.",
    progress: A => ({ done: A.s.keyItems.includes('book'), text: A.s.keyItems.includes('book') ? 'Book found!' : 'Not found yet' }),
    reward: { badge: 'bookworm', coins: 30 } },
  fieldnotes: { name: "Hoot's Field Notes", giver: 'Librarian Quill', where: 'Lumen Town, outside the library',
    desc: "Use Hoot's Tattle on 8 different kinds of enemies.",
    progress: A => { const n = Object.keys(A.s.tattled).length; return { done: n >= 8, text: `Enemies tattled: ${n} of 8` }; },
    reward: { badge: 'field_monocle', coins: 20 } },
  bramble: { name: 'The Bramble Beast', giver: 'Hunter Hazel', where: 'Lumen Town, east side',
    desc: 'Defeat the Bramble Beast deep in the Bramble Thicket. A boulder blocks the way in.',
    progress: A => ({ done: A.flag('beast_down'), text: A.flag('beast_down') ? 'Defeated!' : 'Still lurking' }),
    reward: { badge: 'thorn_crown', starPieces: 1 } },
  lamps: { name: 'Light the Way', giver: 'Glimmer', where: 'Lumen Town plaza',
    desc: 'Light 6 lampposts around the world (just save at them).',
    progress: A => { const n = A.litLamps(); return { done: n >= 6, text: `Lampposts lit: ${n} of 6` }; },
    reward: { items: { feather: 2 }, coins: 20 } },
  poem: { name: "Pebble's Poem", giver: 'Smudge', where: "Smudge's Studio (bring Pebble)",
    desc: 'Smudge wants to hear the poem she smudged. Bring Pebble to her studio.',
    progress: A => ({ done: A.flag('poem_read'), text: A.flag('poem_read') ? 'Poem read!' : 'Bring Pebble' }),
    reward: { badge: 'perfectly_imperfect' } },
  embers: { name: 'Lost Little Embers', giver: 'Granny Hearth', where: 'Cinder Springs, on Ember Peak',
    desc: "The eruption flung Granny Hearth's five littlest grandkids all over: Ember Peak, Lumen Fields, the Grumbling Grove and the Inkwell Caverns. They hide in tiny places that only rolling or fire can reach.",
    progress: A => { const n = A.collectedCount('ember'); return { done: n >= 5, text: `Little embers found: ${n} of 5` }; },
    reward: { badge: 'kindling', starPieces: 2 } },
  ontime: { name: 'Steam Break', giver: 'Kettle', where: 'Cinder Springs, on Ember Peak', study: true,
    desc: 'Study Challenge: take a real break during a focus session (1+ minute), then come back before your break runs out. Three times.',
    progress: A => ({ done: A.stat('breaks_on_time') >= 3, text: `On-time comebacks: ${Math.min(3, A.stat('breaks_on_time'))} of 3` }),
    reward: { badge: 'second_wind', coins: 25 } },
  forge: { name: 'Forge Fuel', giver: 'Anvil Annie', where: 'Cinder Springs, on Ember Peak',
    desc: "Defeat 3 Slagbrutes on Ember Peak. Annie needs their slag to fire up her forge. They're rock-hard until you heat them up.",
    progress: A => { const n = A.s.kills.peak_slagbrute || 0; return { done: n >= 3, text: `Slagbrutes defeated: ${Math.min(3, n)} of 3` }; },
    reward: { badge: 'hot_hammer', coins: 30 } },
};

// ---------------------------------------------------------------- world map (fast travel to places you've been)
// `music` is the area's song in songs.js; a room can override it with its own `music`.
export const AREAS = {
  town: { name: 'Lumen Town', start: 'pro_1', x: 1220, icon: '🏮', mx: 0.5, my: 0.55, music: 'town' },
  outskirts: { name: 'Lumen Outskirts', start: 'pro_3', x: 620, icon: '🏘️', mx: 0.74, my: 0.64, music: 'town' },
  fields: { name: 'Lumen Fields', start: 'fields_1', x: 2700, icon: '🌾', mx: 0.33, my: 0.6, music: 'fields' },
  lake: { name: 'Mirror Lake', start: 'lake_1', x: 300, icon: '🎣', mx: 0.3, my: 0.84, music: 'lake' },
  grove: { name: 'Grumbling Grove', start: 'grove_1', x: 240, icon: '🌳', mx: 0.12, my: 0.44, music: 'grove' },
  thicket: { name: 'Bramble Thicket', start: 'maze_1', x: 140, icon: '🌿', mx: 0.17, my: 0.75, music: 'grove' },
  mountain: { name: 'North Trail', start: 'mtn_1', x: 300, icon: '⛰️', mx: 0.56, my: 0.3, music: 'fields' },
  caves: { name: 'Inkwell Caverns', start: 'cave_1', x: 130, icon: '💎', mx: 0.8, my: 0.22, music: 'caves' },
  peak: { name: 'Ember Peak', start: 'peak_1', x: 220, icon: '🌋', mx: 0.9, my: 0.46, music: 'peak' },
  castle: { name: 'Old Lumen Castle', start: 'castle_road', x: 200, icon: '👑', mx: 0.3, my: 0.3, music: 'castle' },
  tower: { name: "Count Dusk's Tower", soon: true, icon: '🏰', mx: 0.5, my: 0.09 },
};

// The next story step: what to do, the room it happens in (and where in it), and a tip for the hint button.
const G = (text, room, x, tip, z) => ({ text, room, x, z, tip, story: true });
export function storyGoal(A) {
  if (!A.flag('intro_done')) return G('Listen to Mothwick', 'pro_1', 1150);
  if (!A.hasPartner('moss')) return G('Head east out of town along the Outskirts Path', 'pro_2', 2030, 'Jump the gaps with SPACE. Hold it to jump higher.');
  if (!A.has('hammer')) return G("Find Mothwick's shed to the east", 'pro_3', 430);
  if (!A.flag('prologue_done')) {
    if (!A.broken('p3c1')) return G('Smash the cracked wall (X) east of the shed', 'pro_3', 1210, 'Walk up to the cracked wall and press X to swing the hammer.');
    // the wall's down: Mothwick is waiting up at his lookout, at the top of the path behind the Ember Road gate
    return G("Take the path behind the Ember Road gate up to Mothwick's lookout", 'pro_3', 1470, 'Walk past the broken wall, then follow the path north (press ↑) up through the trees.', 2100);
  }
  if (!A.flag('ch1_done')) {
    if (!A.s.seenAreas.grove) return G('Cross Lumen Fields and take the forest path at the back of the west woods', 'grove_1');
    if (!A.flag('hoot_asked')) return G('Explore the Grumbling Grove', 'grove_3', 780, "Someone in Hoot's Hollow needs help.");
    if (!A.hasPartner('hoot')) {
      if (A.flag('got_glasses')) return G("Bring the spectacles back to Hoot's Hollow", 'grove_3', 780);
      return A.has('glide') ? G('Glide across the Bramble Gap (jump, then hold SPACE)', 'grove_4', 1950, 'Jump off the edge, then HOLD SPACE while falling to glide.')
        : G('Find a way across the Bramble Gap', 'grove_4', 900, 'The Origami Sage by the gap knows a trick.');
    }
    if (!A.flag('gate_open')) return G('Read the tiny sign at the Grumble Gate', 'grove_5', 1380, 'Hoot can read tiny writing. Bring Hoot along (ESC → Party).');
    return G('Wake King Grumblecap in the Throne Stump', 'grove_throne', 560);
  }
  if (!A.flag('ch2_done')) {
    if (!A.s.seenAreas.caves) return G('Take the North Gate (east side of town) up the North Trail to the caverns', 'cave_1');
    if (!A.hasPartner('pebble')) return G('Explore the Inkwell Caverns', 'cave_2', 1180, 'Smash the cracked wall with your hammer (X).');
    if (!A.has('flare')) return G('Go deeper into the caverns', 'cave_4', 760);
    return G("Flare (F) across the Shadow Bridge to Smudge's Studio", 'cave_studio', 560, 'Press F to flare: hidden platforms light up over the ink.');
  }
  if (!A.flag('ch3_done')) {
    if (!A.flag('ch3_open')) return G('Go back to Lumen Town and talk to Mothwick', 'pro_1', 1490);
    if (!A.s.seenAreas.peak) return G("Take the Ember Road, east past Mothwick's shed", 'peak_1');
    if (!A.has('roll')) return G('Find a way past the low rocks on the Ember Road', 'peak_1', 1110, 'The Origami Sage is waiting on the Ember Road.');
    if (!A.hasPartner('ember')) return G('Climb past the Cinder Springs to the Brazier Gate', 'peak_3', 660);
    if (!A.flag('brazier_gate')) return G("Light the braziers in order with Ember's Fire Toss (C): I, II, III, IV", 'peak_3', 760, 'Throw fire at brazier I first, then II, III, IV. One at a time!');
    return G("Climb to Cindermaw's Crater at the top of Ember Peak", 'peak_crater', 520, 'Ride the stone rafts, then the steam, and glide to the ledge.');
  }
  // Chapter 4, then (after the ending) the Bonus Chapter
  return towerGoal(A, G) || marginGoal(A, G);
}

export function objective(A) {
  const g = storyGoal(A);
  return g ? g.text : A.flag('margin_done') ? MARGIN_AFTER : AFTER_STORY;
}

// ---------------------------------------------------------------- rooms
const night = A => (A.flag('prologue_done') ? 'town' : 'night');
export const ROOMS = {
  // ======================= LUMEN TOWN (the hub)
  pro_1: {
    name: 'Lumen Town', area: 'town', theme: night, w: 2700,
    ground: [[0, 2700, 450]],
    props: [
      { kind: 'building', x: 260, sign: 'Inn', roof: '#4f72bf', wall: '#d9cfee', wall2: '#b0a2d0', icon: '🛏️' },
      { kind: 'building', x: 580, sign: 'Honeycomb Goods', roof: '#f2b43a', wall: '#f6e3b8', wall2: '#d9bf86', icon: '🍯' },
      { kind: 'building', x: 900, sign: 'Badge Bazaar', roof: '#7b5fc7', wall: '#e3d9f6', wall2: '#bba9e0', icon: '🎖️' },
      { kind: 'lantern', x: 1350 },
      { kind: 'building', x: 1700, sign: 'Star Exchange', roof: '#3aa79c', wall: '#d6f0ec', wall2: '#a8d6cf', icon: '⭐' },
      { kind: 'building', x: 2000, sign: 'Library', roof: '#8a5a3c', wall: '#efe0c8', wall2: '#cdb48e', icon: '📚', closed: true },
    ],
    shops: [
      { x: 260, kind: 'inn', label: 'Rest' }, { x: 580, kind: 'items', label: 'Shop' },
      { x: 900, kind: 'badges', label: 'Shop' }, { x: 1700, kind: 'stars', label: 'Shop' },
    ],
    boards: [{ x: 1120 }],
    lamps: [1220],
    doors: [{ x: 2380, to: 'mtn_1', toX: 140, label: 'North Gate', need: 'ch1_done',
      needText: "The North Gate is shut. The guard says the trail is too dangerous until the Grumbling Grove wakes up." }],
    npcs: [
      { id: 'elder1', x: 1150, kind: 'mothwick', name: 'Mothwick', talk: 'elder_square', show: A => !A.flag('intro_done') },
      { id: 'elder_town', x: 1490, kind: 'mothwick', name: 'Mothwick', talk: 'mothwick_town', show: A => A.flag('prologue_done') },
      { id: 'folk1', x: 720, kind: 'folk', name: 'Lampkin', talk: 'folk_town', opts: { color: '#5a6fb0' } },
      { id: 'folk2', x: 1840, kind: 'folk', name: 'Glimmer', talk: 'glimmer', opts: { color: '#c46a8f', seed: 2 }, flip: -1 },
      { id: 'quill', x: 2090, kind: 'folk', name: 'Librarian Quill', talk: 'quill', opts: { color: '#a8743a', body: '#5a4fa8', specs: true }, show: A => A.flag('prologue_done') },
      { id: 'hazel', x: 2230, kind: 'folk', name: 'Hunter Hazel', talk: 'hazel', opts: { color: '#7cc46a', body: '#3d6b4a', hat: 'feather' }, flip: -1, show: A => A.flag('prologue_done') },
    ],
    signs: [{ x: 70, text: 'West: Lumen Fields, Mirror Lake and the Grumbling Grove.' }, { x: 2630, text: 'East: the Outskirts Path.' }],
    triggers: [
      { id: 'intro', x: 0, script: 'intro', once: true },
      { id: 'ch3_call', x: 0, script: 'ch3_call', once: true, when: A => A.flag('ch2_done') },
    ],
    exits: {
      left: { to: 'fields_1', x: 2940, need: 'prologue_done', needText: "The west gate is locked tight. Mothwick said to meet him at his shed, east of town." },
      right: { to: 'pro_2', x: 60 },
    },
  },
  pro_2: {
    name: 'Outskirts Path', area: 'outskirts', theme: 'night', w: 2300,
    ground: [[0, 760, 450], [880, 1560, 450], [1560, 2300, 426]],
    plats: [[300, 345, 130]],
    blocks: [{ id: 'p2b1', x: 343, y: 200, give: { coins: 3 } }, { id: 'p2b2', x: 1900, y: 250, give: { item: 'honeybun' } }],
    bushes: [{ id: 'bush_p2', x: 1350 }],
    signs: [
      { x: 150, text: 'Bump into an enemy to start a battle. Jump ON it first for a First Strike! (Careful: if it catches you from behind, IT strikes first.)' },
      { x: 700, text: 'Gap ahead! Run and jump with SPACE. Hold it to jump higher.' },
    ],
    enemies: [{ id: 'p2e1', x: 1180, kind: 'gloomling', group: ['gloomling'], range: 110, calm: true }],
    npcs: [{ id: 'moss', x: 2030, kind: 'moss', name: 'Moss', talk: 'moss_hi', show: A => !A.hasPartner('moss'), flip: -1 }],
    triggers: [{ id: 'moss_meet', x: 1820, script: 'moss_meet', once: true }],
    exits: { left: { to: 'pro_1', x: 2640 }, right: { to: 'pro_3', x: 60 } },
  },
  pro_3: {
    name: "Mothwick's Shed", area: 'outskirts', theme: 'night', w: 1600,
    ground: [[0, 1600, 450]],
    props: [{ kind: 'house', x: 250 }],
    lamps: [620],
    pots: [{ id: 'pot_p3', x: 800 }],
    cracks: [{ id: 'p3c1', x: 1180, y: 240, w: 64, h: 210, script: 'shed_wall' }],
    walls: [[1180, 0, 64, 240]],
    // (once the wall's down he flies on ahead to his lookout, up the path behind the Ember Road gate: see deep.js)
    npcs: [{ id: 'elder2', x: 430, kind: 'mothwick', name: 'Mothwick', talk: 'elder_shed', show: A => !A.flag('prologue_done') && !A.flag('moth_flew') }],
    doors: [{ x: 1460, to: 'peak_1', toX: 220, label: 'Ember Road', need: 'ch3_open',
      needText: "A rope bridge heads east toward Ember Peak. It's tied shut, with a sign: 'CLOSED. TOO HOT. — Mothwick' (It opens in Chapter 3, once you've set things right in the Inkwell Caverns.)" }],
    // (the way back to town is west, along the Outskirts Path: the east edge is the canyon, so there's no way off there)
    exits: { left: { to: 'pro_2', x: 2240 } },
  },

  // ======================= LUMEN FIELDS (west of town)
  fields_1: {
    name: 'Lumen Fields', area: 'fields', theme: 'fields', w: 3000,
    ground: [[0, 1250, 450], [1250, 1900, 426], [1900, 3000, 450]],
    plats: [[880, 210, 160], [2480, 330, 120]],
    springs: [{ x: 1040 }],
    props: [{ kind: 'windmill', x: 2300 }],
    collect: [{ id: 'acorn_f1', kind: 'acorn', x: 960, y: 210 }, { id: 'acorn_f2', kind: 'acorn', x: 2540, y: 330 }],
    bushes: [{ id: 'bush_f1', x: 420 }, { id: 'bush_f2', x: 1500 }, { id: 'bush_f3', x: 2180 }],
    blocks: [{ id: 'f1b1', x: 618, y: 300, give: { coins: 5 } }, { id: 'f1h1', x: 1800, y: 270, hidden: true, give: { starPiece: 1 } }],
    enemies: [
      { id: 'f1e1', x: 720, kind: 'gloomling', group: ['gloomling', 'gloomling'] },
      { id: 'f1e2', x: 1380, kind: 'snailshell', group: ['snailshell'], calm: true },
      { id: 'f1e3', x: 1750, kind: 'gloomling', group: ['gloomling', 'snailshell'] },
      { id: 'f1e4', x: 2620, kind: 'gloomling', group: ['gloomling'] },
    ],
    npcs: [{ id: 'barley', x: 2400, kind: 'folk', name: 'Farmer Barley', talk: 'barley', opts: { color: '#d9a066', body: '#6b8a3a', hat: 'straw' } }],
    lamps: [2700],
    doors: [
      { x: 1600, to: 'lake_1', toX: 140, label: 'Path to Mirror Lake' },
      { x: 2050, to: 'maze_1', toX: 140, label: 'Bramble Thicket', needBroken: 'boulder_f1', needText: 'A huge boulder blocks the thicket. Somebody very strong could smash it...' },
      { x: 2850, to: 'seal_1', toX: 140, label: '???', needSeal: 'seal_garden' },
      { x: 300, to: 'burrow_1', toX: 140, label: 'Tiny burrow', style: 'hole', needAbility: 'roll',
        needText: 'A tiny burrow. Way too small for a candle... unless you could roll up REALLY small.' },
    ],
    boulders: [{ id: 'boulder_f1', x: 2050 }],
    seals: [{ id: 'seal_garden', x: 2850, need: 7200 }],
    signs: [{ x: 2960, text: 'West: the Grumbling Grove. The side path leads south to Mirror Lake.' }],
    exits: { left: { to: 'grove_1', x: 140 }, right: { to: 'pro_1', x: 60 } },
  },
  seal_1: {
    name: 'Secret Garden', area: 'fields', theme: 'garden', music: 'secret', w: 1300,
    ground: [[0, 1300, 450]],
    doors: [{ x: 120, to: 'fields_1', toX: 2850, label: 'Back to the fields' }],
    npcs: [{ id: 'rosa', x: 480, kind: 'folk', name: 'Old Rosa', talk: 'rosa', opts: { color: '#ff9ab0', body: '#7a5a8a', hat: 'straw' } }],
    chests: [{ id: 's1ch1', x: 800, give: { badge: 'focus_core' } }, { id: 's1ch2', x: 1060, give: { starPiece: 2 } }],
    bushes: [{ id: 'bush_s1', x: 300 }],
    exits: {},
  },

  // ======================= MIRROR LAKE (south of the fields)
  lake_1: {
    name: 'Mirror Lake', area: 'lake', theme: 'lake', w: 2600,
    ground: [[0, 900, 450], [1160, 1600, 450], [1800, 2600, 450]],
    hazard: 'water',
    plats: [[960, 438, 70], [1065, 430, 60], [1560, 450, 160], [1980, 210, 150]],
    springs: [{ x: 2160 }],
    lamps: [300],
    props: [{ kind: 'dock', x: 1640 }],
    fish: [{ x: 1680 }],
    doors: [{ x: 140, to: 'fields_1', toX: 1600, label: 'Lumen Fields' }, { x: 2400, to: 'lake_2', toX: 140, label: 'Sunken Library' }],
    npcs: [{ id: 'finn', x: 1430, kind: 'folk', name: 'Fisher Finn', talk: 'finn', opts: { color: '#4f9fd6', body: '#3b5a7b', hat: 'bucket' } }],
    chests: [{ id: 'l1ch', x: 2050, y: 210, give: { item: 'feather' } }],
    blocks: [{ id: 'l1h1', x: 700, y: 300, hidden: true, give: { starPiece: 1 } }],
    bushes: [{ id: 'bush_l1', x: 1880 }],
    enemies: [
      { id: 'l1e1', x: 600, kind: 'puddlet', group: ['puddlet'] },
      { id: 'l1e2', x: 1980, kind: 'puddlet', group: ['puddlet', 'puddlet'], range: 90 },
    ],
    exits: {},
  },
  lake_2: {
    name: 'Sunken Library', area: 'lake', theme: 'library', music: 'caves', dark: true, w: 2200,
    ground: [[0, 600, 450], [1500, 2200, 450]],
    hazard: 'water',
    hidden: [[680, 420, 120], [900, 380, 120], [1120, 420, 120], [1340, 380, 120]],
    lamps: [260],
    doors: [{ x: 120, to: 'lake_1', toX: 2400, label: 'Back to the lake' }],
    signs: [{ x: 460, text: 'Far too dark to cross. A Lantern Flare (learned deep in the Inkwell Caverns) would light the way.' }],
    collect: [{ id: 'book_napping', kind: 'book', x: 2080, y: 450 }],
    chests: [{ id: 'l2ch', x: 1880, give: { starPiece: 1 } }],
    enemies: [{ id: 'l2e1', x: 1700, kind: 'mirrormoth', group: ['mirrormoth', 'wisp'], y: 370, range: 70 }],
    exits: {},
  },

  // ======================= BRAMBLE THICKET (behind the boulder in the fields)
  maze_1: {
    name: 'Bramble Thicket', area: 'thicket', theme: 'maze', w: 2800,
    ground: [[0, 2800, 450]],
    plats: [[560, 350, 110]],
    walls: [[700, 250, 60, 200], [1400, 0, 110, 290]],
    boulders: [{ id: 'boulder_m1', x: 1455, solid: [1400, 290, 110, 160] }],
    doors: [{ x: 120, to: 'fields_1', toX: 2050, label: 'Back to the fields' }],
    lamps: [1700],
    bushes: [{ id: 'bush_m1', x: 330 }, { id: 'bush_m2', x: 1230 }],
    enemies: [
      { id: 'm1e1', x: 1000, kind: 'thornback', group: ['thornback'] },
      { id: 'm1e2', x: 1900, kind: 'thornback', group: ['thornback', 'spikeshroom'] },
      { id: 'm1e3', x: 2080, kind: 'snailshell', group: ['snailshell', 'snailshell'], calm: true },
    ],
    boss: { kind: 'bramblebeast', x: 2520, flag: 'beast_down', scale: 2.0 },
    triggers: [{ id: 'beast', x: 2230, script: 'beast_fight', when: A => !A.flag('beast_down') }],
    exits: {},
  },

  // ======================= NORTH TRAIL (town's north gate → caverns)
  mtn_1: {
    name: 'North Trail', area: 'mountain', theme: 'mountain', w: 2800,
    ground: [[0, 800, 450], [800, 1500, 426], [1500, 2200, 402], [2200, 2800, 426]],
    plats: [[1150, 170, 160]],
    springs: [{ x: 1320 }],
    lamps: [300],
    chests: [{ id: 'mt_ch1', x: 1230, y: 170, give: { item: 'embertea', n: 2 } }],
    doors: [{ x: 120, to: 'pro_1', toX: 2380, label: 'Lumen Town' }, { x: 2600, to: 'seal_2', toX: 140, label: '???', needSeal: 'seal_summit' }],
    seals: [{ id: 'seal_summit', x: 2600, need: 36000 }],
    bushes: [{ id: 'bush_mt1', x: 620 }],
    enemies: [
      { id: 'mt_e1', x: 950, kind: 'bombshroom', group: ['bombshroom', 'gloomling'] },
      { id: 'mt_e2', x: 1750, kind: 'raccoon', group: ['raccoon'] },
      { id: 'mt_e3', x: 2380, kind: 'bombshroom', group: ['bombshroom', 'raccoon'] },
    ],
    exits: { right: { to: 'cave_1', x: 60 } },
  },
  seal_2: {
    name: 'Summit Shrine', area: 'mountain', theme: 'mountain', music: 'secret', w: 1100,
    ground: [[0, 1100, 450]],
    doors: [{ x: 120, to: 'mtn_1', toX: 2600, label: 'Back down' }],
    chests: [{ id: 's2ch1', x: 600, give: { badge: 'lucky_star' } }, { id: 's2ch2', x: 860, give: { starPiece: 3 } }],
    exits: {},
  },

  // ======================= CHAPTER 1: GRUMBLING GROVE
  grove_1: {
    name: 'Grove Gate', area: 'grove', theme: 'grove', gloomUntil: 'ch1_done', w: 2050,
    ground: [[0, 900, 450], [1040, 2050, 450]],
    plats: [[500, 330, 140]],
    lamps: [240],
    blocks: [{ id: 'g1b1', x: 548, y: 190, give: { coins: 5 } }, { id: 'g1b2', x: 1300, y: 300, give: { item: 'honeybun' } }],
    npcs: [{ id: 'nutkin', x: 380, kind: 'acorn', name: 'Nutkin', talk: 'nutkin' }],
    bushes: [{ id: 'bush_g1', x: 1700 }],
    enemies: [
      { id: 'g1e1', x: 720, kind: 'gloomling', group: ['gloomling', 'gloomling'] },
      { id: 'g1e2', x: 1560, kind: 'spikeshroom', group: ['spikeshroom', 'gloomling'] },
    ],
    triggers: [{ id: 'ch1_card', x: 0, script: 'ch1_card', once: true }],
    // (you come up the forest path from Lumen Fields, and go back down it at the front: see fields_1 in deep.js)
    doors: [{ x: 100, to: 'fields_1', toX: 230, label: 'Lumen Fields', style: 'front' }],
    exits: { right: { to: 'grove_2', x: 60 } },
  },
  grove_2: {
    name: 'Mossy Steps', area: 'grove', theme: 'grove', gloomUntil: 'ch1_done', w: 2150,
    ground: [[0, 2150, 450]],
    plats: [[380, 370, 130], [580, 290, 130], [780, 210, 130], [1240, 230, 130]],
    chests: [{ id: 'g2ch1', x: 845, y: 210, give: { item: 'embertea' } }, { id: 'g2ch2', x: 1280, y: 230, give: { starPiece: 1 } }],
    collect: [{ id: 'acorn_g2', kind: 'acorn', x: 1340, y: 230 }],
    cracks: [{ id: 'g2c1', x: 1560, y: 240, w: 64, h: 210 }],
    walls: [[1560, 0, 64, 240]],
    signs: [{ x: 1190, text: 'A treasure sits on a ledge way too far to jump to... if only you could fly.' }],
    doors: [{ x: 1950, to: 'log_1', toX: 140, label: 'Hollow log', style: 'log', needBroken: 'vine_g2',
      needText: 'Thick, thorny vines cover the hollow log. Fire would clear them right up.' }],
    vines: [{ id: 'vine_g2', x: 1900, y: 380, w: 90, h: 70, solid: false }],
    enemies: [
      { id: 'g2e1', x: 660, kind: 'buzzbug', group: ['buzzbug'], y: 360, range: 90 },
      { id: 'g2e2', x: 1850, kind: 'spikeshroom', group: ['spikeshroom', 'spikeshroom'] },
    ],
    exits: { left: { to: 'grove_1', x: 1990 }, right: { to: 'grove_3', x: 60 } },
  },
  grove_3: {
    name: "Hoot's Hollow", area: 'grove', theme: 'grove', gloomUntil: 'ch1_done', w: 1500,
    ground: [[0, 1500, 450]],
    props: [{ kind: 'bigtree', x: 760 }],
    lamps: [260],
    blocks: [{ id: 'g3b1', x: 1020, y: 300, give: { item: 'embertea' } }],
    collect: [{ id: 'acorn_g3', kind: 'acorn', x: 1260, y: 450 }],
    bushes: [{ id: 'bush_g3', x: 1240 }],
    npcs: [{ id: 'hoot', x: 780, kind: 'hoot', name: 'Hoot', talk: 'hoot', show: A => !A.hasPartner('hoot'), flip: -1, opts: { glasses: false } }],
    enemies: [{ id: 'g3e1', x: 1250, kind: 'buzzbug', group: ['buzzbug', 'gloomling'], y: 380 }],
    exits: { left: { to: 'grove_2', x: 2090 }, right: { to: 'grove_4', x: 60 } },
  },
  grove_4: {
    name: 'Bramble Gap', area: 'grove', theme: 'grove', gloomUntil: 'ch1_done', w: 2450,
    ground: [[0, 1100, 450], [1560, 2450, 450]],
    hazard: 'brambles',
    shrines: [{ id: 'g4s', x: 780, script: 'sage', ability: 'glide' }],
    npcs: [{ id: 'sage', x: 900, kind: 'crane', name: 'Origami Sage', talk: 'sage', flip: -1 }],
    chests: [{ id: 'g4ch', x: 1950, give: { key: 'glasses' } }],
    blocks: [{ id: 'g4h1', x: 600, y: 300, hidden: true, give: { item: 'bighoney' } }],
    signs: [{ x: 1040, text: 'DANGER: Bramble Gap. Way too wide to jump. (Unless you are a bird. Or a paper airplane.)' }],
    enemies: [
      { id: 'g4e1', x: 420, kind: 'gloomling', group: ['gloomling', 'buzzbug'] },
      { id: 'g4e2', x: 2200, kind: 'buzzbug', group: ['buzzbug', 'buzzbug'], y: 370 },
    ],
    exits: { left: { to: 'grove_3', x: 1440 }, right: { to: 'grove_5', x: 60 } },
  },
  grove_5: {
    name: 'Grumble Gate', area: 'grove', theme: 'grove', gloomUntil: 'ch1_done', w: 1850,
    ground: [[0, 1850, 450]],
    plats: [[540, 330, 120]],
    lamps: [280],
    collect: [{ id: 'acorn_g5', kind: 'acorn', x: 600, y: 330 }],
    blocks: [{ id: 'g5b1', x: 1050, y: 300, give: { item: 'honeybun' } }],
    signs: [{ x: 1380, text: '', script: 'gate_sign' }],
    doors: [{ x: 1560, to: 'grove_throne', toX: 90, label: 'Throne Stump', need: 'gate_open', needText: 'The door is shut tight. There is tiny writing on the sign next to it.' }],
    enemies: [{ id: 'g5e1', x: 760, kind: 'spikeshroom', group: ['spikeshroom', 'buzzbug', 'gloomling'] }],
    exits: { left: { to: 'grove_4', x: 2390 } },
  },
  grove_throne: {
    name: 'Snoring Throne', area: 'grove', theme: 'grove', gloomUntil: 'ch1_done', w: 1250,
    ground: [[0, 1250, 450]],
    boss: { kind: 'grumblecap', x: 900, flag: 'ch1_done', scale: 2.2 },
    triggers: [{ id: 'grumble', x: 560, script: 'grumble_fight', when: A => !A.flag('ch1_done') }],
    doors: [{ x: 90, to: 'grove_5', toX: 1560, label: 'Back outside' }],
    npcs: [{ id: 'king', x: 900, kind: 'grumblecap', name: 'King Grumblecap', talk: 'king_after', show: A => A.flag('ch1_done'), opts: { scale: 2.2, mood: 'normal' }, flip: -1 }],
    exits: {},
  },

  // ======================= CHAPTER 2: INKWELL CAVERNS
  cave_1: {
    name: 'Cavern Mouth', area: 'caves', theme: 'cave', w: 2050,
    ground: [[0, 2050, 450]],
    plats: [[600, 345, 140], [880, 265, 140]],
    lamps: [130],
    blocks: [{ id: 'c1b1', x: 928, y: 120, give: { coins: 8 } }],
    signs: [{ x: 300, text: 'Welcome to Inkw~~~ (the rest has been angrily smudged out)' }],
    enemies: [
      { id: 'c1e1', x: 700, kind: 'inkblot', group: ['inkblot'] },
      { id: 'c1e2', x: 1500, kind: 'shellcrab', group: ['shellcrab', 'inkblot'] },
    ],
    triggers: [{ id: 'ch2_card', x: 0, script: 'ch2_card', once: true }],
    exits: { left: { to: 'mtn_1', x: 2740 }, right: { to: 'cave_2', x: 60 } },
  },
  cave_2: {
    name: 'Echo Hall', area: 'caves', theme: 'cave', w: 1850,
    ground: [[0, 1850, 450]],
    cracks: [{ id: 'c2c1', x: 1000, y: 230, w: 70, h: 220 }],
    walls: [[1000, 0, 70, 230]],
    npcs: [{ id: 'pebble', x: 1180, kind: 'pebble', name: 'Pebble', talk: 'pebble', show: A => !A.hasPartner('pebble'), flip: -1 }],
    triggers: [{ id: 'pebble_join', x: 1100, script: 'pebble_join', once: true }],
    enemies: [{ id: 'c2e1', x: 560, kind: 'glowbat', group: ['glowbat', 'inkblot'], y: 370 }],
    exits: { left: { to: 'cave_1', x: 1990 }, right: { to: 'cave_3', x: 60 } },
  },
  cave_3: {
    name: 'Ink River', area: 'caves', theme: 'cave', w: 2350,
    ground: [[0, 520, 450], [1860, 2350, 450]],
    hazard: 'ink',
    plats: [[620, 400, 120], [860, 360, 120], [1100, 400, 120], [1340, 360, 120], [1580, 400, 120]],
    lamps: [200],
    blocks: [{ id: 'c3b1', x: 898, y: 205, give: { item: 'fireseed' } }],
    enemies: [{ id: 'c3e1', x: 1220, kind: 'glowbat', group: ['glowbat', 'glowbat'], y: 300, range: 80 }],
    exits: { left: { to: 'cave_2', x: 1790 }, right: { to: 'cave_4', x: 60 } },
  },
  cave_4: {
    name: 'Lantern Shrine', area: 'caves', theme: 'cave', w: 1550,
    ground: [[0, 1550, 450]],
    shrines: [{ id: 'c4s', x: 760, script: 'flare_shrine', ability: 'flare' }],
    chests: [{ id: 'c4ch', x: 1150, give: { item: 'bighoney' } }],
    doors: [{ x: 1360, to: 'nook_1', toX: 140, label: 'Crawlspace', style: 'crawl', needAbility: 'roll',
      needText: 'A low crawlspace. Too low to walk through... if only you could roll.' }],
    enemies: [{ id: 'c4e1', x: 420, kind: 'shellcrab', group: ['shellcrab', 'shellcrab'] }],
    exits: { left: { to: 'cave_3', x: 2290 }, right: { to: 'cave_5', x: 60 } },
  },
  cave_5: {
    name: 'Shadow Bridge', area: 'caves', theme: 'cave', dark: true, w: 2250,
    ground: [[0, 460, 450], [1760, 2250, 450]],
    hazard: 'ink',
    hidden: [[560, 420, 140], [800, 380, 140], [1040, 420, 140], [1280, 380, 140], [1520, 420, 140]],
    lamps: [200],
    blocks: [{ id: 'c5b1', x: 1088, y: 255, give: { starPiece: 1 } }],
    signs: [{ x: 360, text: "It's pitch black ahead. If only your flame could burn brighter... (Press F to Flare)" }],
    exits: { left: { to: 'cave_4', x: 1490 }, right: { to: 'cave_studio', x: 60 } },
  },
  cave_studio: {
    name: "Smudge's Studio", area: 'caves', theme: 'cave', w: 1300,
    ground: [[0, 1300, 450]],
    boss: { kind: 'smudge', x: 930, flag: 'ch2_done', scale: 1.7 },
    triggers: [{ id: 'smudge', x: 560, script: 'smudge_fight', when: A => !A.flag('ch2_done') }],
    npcs: [{ id: 'smudge_npc', x: 930, kind: 'smudge', name: 'Smudge', talk: 'smudge_poem', show: A => A.flag('ch2_done'), opts: { scale: 1.7, mood: 'normal' }, flip: -1 }],
    exits: { left: { to: 'cave_5', x: 2190 } },
  },

  // ======================= CHAPTER 3: EMBER PEAK (east of Mothwick's shed)
  // low: rocks with a crawl gap under them (Roll Fold). vents: steam that launches you. movers: drifting stone rafts.
  // braziers + gates: light them in order to open the gate. vines: Ember's fire burns them away.
  peak_1: {
    name: 'Ember Road', area: 'peak', theme: 'volcano', w: 2600,
    ground: [[0, 2050, 450], [2230, 2600, 450]],
    hazard: 'lava',
    plats: [[2110, 440, 60], [1840, 190, 150]],
    low: [[1300, 200]],
    vents: [{ x: 1780 }],
    lamps: [220],
    signs: [
      { x: 420, text: 'Ember Peak. Hot rocks, hot steam, hot lava. Mostly just hot.' },
      { x: 1640, text: 'Steam vents puff every few seconds. Stand on one as it blows to shoot up high... or glide through the steam to ride it!' },
    ],
    npcs: [{ id: 'sage2', x: 1110, kind: 'crane', name: 'Origami Sage', talk: 'sage_roll', flip: -1 }],
    shrines: [{ id: 'p1s', x: 980, script: 'sage_roll', ability: 'roll' }],
    blocks: [{ id: 'p1b1', x: 560, y: 300, give: { coins: 6 } }, { id: 'p1h1', x: 1580, y: 290, hidden: true, give: { item: 'fireseed' } }],
    collect: [{ id: 'ember_p1', kind: 'ember', x: 1930, y: 190 }],
    chests: [{ id: 'p1ch', x: 2490, give: { item: 'embertea', n: 2 } }],
    enemies: [
      { id: 'p1e1', x: 760, kind: 'cinderling', group: ['cinderling', 'cinderling'] },
      { id: 'p1e2', x: 2370, kind: 'magmaw', group: ['magmaw', 'cinderling'], range: 80 },
    ],
    doors: [{ x: 110, to: 'pro_3', toX: 1460, label: "Back to Mothwick's shed" }],
    triggers: [{ id: 'ch3_card', x: 0, script: 'ch3_card', once: true }],
    exits: { right: { to: 'peak_2', x: 60 } },
  },
  peak_2: {
    name: 'Cinder Springs', area: 'peak', theme: 'volcano', music: 'springs', w: 2400,
    ground: [[0, 2400, 450]],
    props: [
      { kind: 'hotspring', x: 700 },
      { kind: 'building', x: 1220, sign: "Hearth's Home", roof: '#c45a3a', wall: '#f3d6b6', wall2: '#d9b088', icon: '🔥' },
      { kind: 'building', x: 1760, sign: "Annie's Forge", roof: '#5a4e58', wall: '#e0c4a8', wall2: '#b8967a', icon: '⚒️' },
    ],
    lamps: [300],
    shops: [{ x: 700, kind: 'spring', label: 'Soak' }],
    npcs: [
      { id: 'spark', x: 520, kind: 'ember', name: 'Little Spark', talk: 'spark_kid', opts: { look: 'kid', scale: 0.6 } },
      { id: 'kettle', x: 880, kind: 'kettle', name: 'Kettle', talk: 'kettle', flip: -1 },
      { id: 'hearth', x: 1370, kind: 'ember', name: 'Granny Hearth', talk: 'hearth', opts: { look: 'granny', scale: 1.4 } },
      { id: 'annie', x: 1910, kind: 'ember', name: 'Anvil Annie', talk: 'annie', opts: { look: 'annie', scale: 1.15 }, flip: -1 },
    ],
    boulders: [{ id: 'boulder_p2', x: 2120 }],
    chests: [{ id: 'p2ch', x: 2120, give: { starPiece: 1 }, needBroken: 'boulder_p2' }],
    signs: [{ x: 2310, text: 'North: the Brazier Gate. South: the Ember Road home.' }],
    exits: { left: { to: 'peak_1', x: 2540 }, right: { to: 'peak_3', x: 60 } },
  },
  peak_3: {
    name: 'Brazier Gate', area: 'peak', theme: 'volcano', w: 1800,
    ground: [[0, 1800, 450]],
    lamps: [180],
    braziers: [{ id: 'br1', x: 520, n: 3 }, { id: 'br2', x: 760, n: 1 }, { id: 'br3', x: 1000, n: 4 }, { id: 'br4', x: 1240, n: 2 }],
    brazierFlag: 'brazier_gate', brazierScript: 'brazier_done',
    gates: [{ x: 1420, w: 56, top: 200, flag: 'brazier_gate' }],
    signs: [{ x: 380, text: 'THE BRAZIER GATE. Light the four flames to pass. Rule of the peak: one at a time, in order.' }],
    npcs: [{ id: 'ember_npc', x: 660, kind: 'ember', name: 'Ember', talk: 'ember_hi', show: A => !A.hasPartner('ember'), flip: -1 }],
    triggers: [{ id: 'ember_meet', x: 280, script: 'ember_meet', once: true, when: A => !A.hasPartner('ember') }],
    exits: { left: { to: 'peak_2', x: 2340 }, right: { to: 'peak_4', x: 60 } },
  },
  peak_4: {
    name: 'Lava Falls', area: 'peak', theme: 'volcano', w: 2800,
    ground: [[0, 480, 450], [1320, 1880, 450], [2150, 2800, 300]],
    hazard: 'lava',
    movers: [{ x: 520, y: 430, w: 120, dx: 250, period: 4.2 }, { x: 900, y: 430, w: 120, dx: 290, period: 4.2, phase: Math.PI }],
    vents: [{ x: 1840 }],
    lamps: [200, 1400],
    signs: [
      { x: 400, text: 'Lava Falls. The stone rafts drift back and forth: ride them across!' },
      { x: 1740, text: 'Too far to jump. Ride the steam up, then GLIDE (hold SPACE) over to the ledge.' },
    ],
    blocks: [{ id: 'p4h1', x: 1100, y: 250, hidden: true, give: { starPiece: 1 } }],
    enemies: [
      { id: 'p4e1', x: 1540, kind: 'ashcrow', group: ['ashcrow', 'cinderling'], y: 350, range: 100 },
      { id: 'p4e2', x: 1700, kind: 'slagbrute', group: ['slagbrute'], range: 60 },
      { id: 'p4e3', x: 2300, kind: 'jugglit', group: ['jugglit', 'magmaw'], range: 90 },
    ],
    seals: [{ id: 'seal_magma', x: 2450, need: 14400 }],
    doors: [
      { x: 2450, to: 'seal_3', toX: 140, label: '???', needSeal: 'seal_magma' },
      { x: 2600, to: 'peak_5', toX: 140, label: 'Cinder Climb' },
    ],
    vines: [{ id: 'vine_p4', x: 2665, y: -200, w: 34, h: 500 }],
    collect: [{ id: 'ember_p4', kind: 'ember', x: 2725, y: 300 }],
    chests: [{ id: 'p4ch', x: 2772, give: { item: 'bighoney' } }],
    exits: { left: { to: 'peak_3', x: 1740 } },
  },
  peak_5: {
    name: 'Cinder Climb', area: 'peak', theme: 'volcano', w: 2400,
    ground: [[0, 700, 450], [700, 1300, 402], [1300, 1720, 354], [1960, 2400, 330]],
    hazard: 'lava',
    low: [[1080, 150]],
    movers: [{ x: 1740, y: 360, w: 100, dx: 110, period: 3 }],
    vents: [{ x: 2080, period: 3.2 }],
    plats: [[2130, 120, 150]],
    chests: [{ id: 'p5ch', x: 2205, y: 120, give: { starPiece: 1 } }],
    lamps: [300, 2300],
    doors: [{ x: 140, to: 'peak_4', toX: 2600, label: 'Lava Falls' }],
    signs: [{ x: 600, text: 'Low rocks ahead. Hold R (or Shift) to roll under them!' }],
    blocks: [{ id: 'p5b1', x: 480, y: 300, give: { item: 'honeybun' } }],
    enemies: [
      { id: 'p5e1', x: 880, kind: 'jugglit', group: ['jugglit', 'cinderling'], range: 90 },
      { id: 'p5e2', x: 1500, kind: 'slagbrute', group: ['slagbrute', 'cinderling'], range: 80 },
      { id: 'p5e3', x: 2230, kind: 'ashcrow', group: ['ashcrow', 'ashcrow'], y: 250, range: 60 },
    ],
    triggers: [{ id: 'dusk_peak', x: 1990, script: 'dusk_peak', once: true }],
    exits: { right: { to: 'peak_crater', x: 60 } },
  },
  peak_crater: {
    name: "Cindermaw's Crater", area: 'peak', theme: 'volcano', w: 1300,
    ground: [[0, 1300, 450]],
    lamps: [160],
    boss: { kind: 'cindermaw', x: 940, flag: 'ch3_done', scale: 1.9, awake: true },
    triggers: [{ id: 'cinder', x: 520, script: 'cindermaw_fight', when: A => !A.flag('ch3_done') }],
    npcs: [{ id: 'cinder_npc', x: 940, kind: 'cindermaw', name: 'Cindermaw', talk: 'cinder_after', show: A => A.flag('ch3_done'), opts: { scale: 1.9, mood: 'sleep' }, flip: -1 }],
    exits: { left: { to: 'peak_5', x: 2340 } },
  },
  seal_3: {
    name: 'Obsidian Vault', area: 'peak', theme: 'volcano', music: 'secret', w: 1100,
    ground: [[0, 1100, 450]],
    doors: [{ x: 120, to: 'peak_4', toX: 2450, label: 'Back out' }],
    signs: [{ x: 330, text: 'Only the truly focused may enter. (Four whole hours of it. Wow.)' }],
    chests: [{ id: 's3ch1', x: 600, give: { badge: 'ember_ward' } }, { id: 's3ch2', x: 860, give: { starPiece: 3 } }],
    exits: {},
  },

  // ======================= secret pockets you can only reach with Chapter 3 abilities
  burrow_1: {
    name: 'Bunny Burrow', area: 'fields', theme: 'burrow', music: 'secret', w: 1000,
    ground: [[0, 1000, 450]],
    doors: [{ x: 120, to: 'fields_1', toX: 300, label: 'Back outside', style: 'hole' }],
    signs: [{ x: 360, text: 'Welcome to the Bunny Burrow. Please wipe your paws. (Nobody is home. They went out for carrots.)' }],
    collect: [{ id: 'ember_burrow', kind: 'ember', x: 600, y: 450 }],
    chests: [{ id: 'bu_ch', x: 840, give: { starPiece: 1 } }],
    exits: {},
  },
  log_1: {
    name: 'Hollow Log', area: 'grove', theme: 'burrow', music: 'secret', w: 900,
    ground: [[0, 900, 450]],
    doors: [{ x: 120, to: 'grove_2', toX: 1950, label: 'Back outside', style: 'log' }],
    collect: [{ id: 'ember_log', kind: 'ember', x: 520, y: 450 }],
    chests: [{ id: 'log_ch', x: 740, give: { item: 'bighoney', n: 2 } }],
    exits: {},
  },
  nook_1: {
    name: 'Crystal Nook', area: 'caves', theme: 'cave', music: 'secret', w: 900,
    ground: [[0, 900, 450]],
    doors: [{ x: 120, to: 'cave_4', toX: 1360, label: 'Back out', style: 'crawl' }],
    collect: [{ id: 'ember_nook', kind: 'ember', x: 520, y: 450 }],
    chests: [{ id: 'nook_ch', x: 740, give: { starPiece: 1 } }],
    exits: {},
  },
};

// ---------------------------------------------------------------- story scripts
// ['say', who, text|fn] ['narrate', text] ['flag', f] ['ability', id] ['partner', id] ['battle', kinds, opts]
// ['heal'] ['card', title, sub] ['shard', n] ['goto', room, x] ['if', fn, then, else] ['wait', sec]
// ['sfx', name] ['cut', name] ['tip', text] ['quest', id] ['turnin', id]
const giver = (id, who, intro, remind, thanks) => [
  ['if', A => A.questDone(id), [['say', who, thanks]], [
    ['if', A => A.questReady(id), [['turnin', id], ['say', who, thanks]], [
      ['if', A => A.questActive(id), [['say', who, remind]], [
        ...intro, ['quest', id],
        ['if', A => A.questReady(id), [['say', who, 'Wait... you already did it?!'], ['turnin', id], ['say', who, thanks]]],
      ]],
    ]],
  ]],
];

export const SCRIPTS = {
  intro: [
    ['cut', 'dark'],
    ['narrate', 'Long ago, the paper kingdom of Lumenfold glowed under the Great Lantern.'],
    ['narrate', "Its light held back the Gloom: a creeping fog made of 'later', 'one more video' and 'I'll start tomorrow'."],
    ['cut', 'dusk_in'],
    ['say', 'Count Dusk', 'Mwahahaha! Such a cozy little kingdom. Such a BRIGHT little lantern.'],
    ['say', 'Count Dusk', "Let's see how cozy you all are... in the DARK!"],
    ['cut', 'shatter'],
    ['say', 'Count Dusk', 'The Lumen Shards are scattered! Without them, nobody here will ever get anything done again!'],
    ['cut', 'dusk_out'],
    ['wait', 0.5],
    ['say', 'Mothwick', 'Wick! Wick, are you alright? ...Oh, thank the wicks. Your flame is still burning!'],
    ['say', 'Mothwick', 'You may be the last light left in all of Lumenfold.'],
    ['say', 'Mothwick', 'The Great Lantern had five Lumen Shards. If we find them, the town will shine again.'],
    ['say', 'Mothwick', 'But a flame needs fuel, and only one thing is strong enough: real, focused effort.'],
    ['say', 'Mothwick', 'Somewhere out there, a Hero of Homework is working hard. Every minute they focus flows into your flame as ✦ Light.'],
    ['say', 'Mothwick', "Don't ask me how that works. I'm a moth. I just really like lamps."],
    ['say', 'Mothwick', "Now, let's see if those little legs still work. Walk with the arrow keys (or WASD): ↑ and ↓ take you back and forth across the street! Jump with SPACE."],
    ['say', 'Mothwick', "Head east out of town, past the Outskirts. I'll meet you at my shed!"],
    ['cut', 'elder_fly'],
    ['flag', 'intro_done'],
    ['tip', 'Walk: arrow keys or WASD (↑ ↓ walk into the distance)   ·   Jump: SPACE (hold to jump higher)   ·   Talk / read: E'],
  ],
  elder_square: [['say', 'Mothwick', 'East, Wick! To my shed!']],
  folk_town: [
    ['if', A => !A.flag('prologue_done'), [
      ['say', 'Lampkin', "It's so dark... I was going to sweep the porch today, but... eh. Later."],
    ], [
      ['if', A => A.shards >= 3, [['say', 'Lampkin', "Three shards! I made a to-do list, then did the first thing on it. Just the first thing. Felt amazing."]]],
      ['if', A => A.shards === 2, [['say', 'Lampkin', "Two shards! I swept the porch, the steps AND the roof. I'm unstoppable."]]],
      ['if', A => A.shards < 2, [
        ['say', 'Lampkin', 'The shops opened back up! The Badge Bazaar has some really cool stuff, if you have the coins.'],
        ['say', 'Lampkin', 'Oh, and check the Quest Board by the plaza. Lots of folks need help.'],
      ]],
    ]],
  ],
  glimmer: giver('lamps', 'Glimmer',
    [['say', 'Glimmer', "My head is a lantern and I STILL can't see in this gloom. Embarrassing."],
      ['say', 'Glimmer', "Could you light lampposts out there for me? Just save at them and they'll glow. Six should do it!"]],
    "Six lampposts! Just save at them, wherever you find them. I'm counting on you!",
    'Look at all that light out there. Thank you, Wick!'),
  quill: [
    ['if', A => !A.questKnown('overdue'), [
      ['say', 'Librarian Quill', 'Shhh. Ah, a visitor. Forgive me, the library is closed for "reading hour". It\'s been reading hour for a month.'],
      ['say', 'Librarian Quill', "Someone never returned 'Advanced Napping'. Last seen in the Sunken Library under Mirror Lake. Down there it's black as ink."],
      ['quest', 'overdue'],
    ], [
      ['if', A => A.questReady('overdue'), [['turnin', 'overdue'], ['say', 'Librarian Quill', "'Advanced Napping'! Returned at last. Ironically, I'm too excited to sleep now."]]],
      ['if', A => A.questDone('overdue') && !A.questKnown('fieldnotes'), [
        ['say', 'Librarian Quill', 'You travel with Hoot? He was my best student. Always taking notes on monsters.'],
        ['say', 'Librarian Quill', "Have him Tattle on 8 different kinds of creatures and bring me the notes. I'll make it worth your while."],
        ['quest', 'fieldnotes'],
      ], [
        ['if', A => A.questReady('fieldnotes'), [['turnin', 'fieldnotes'], ['say', 'Librarian Quill', "Marvelous notes. 'Gloomling: rude.' Concise! A future classic."]], [
          ['if', A => A.questActive('overdue'), [['say', 'Librarian Quill', "The book is somewhere in the Sunken Library. Mirror Lake is south of Lumen Fields. You'll need light down there."]]],
          ['if', A => A.questActive('fieldnotes'), [['say', 'Librarian Quill', A => `Field notes so far: ${Object.keys(A.s.tattled).length} of 8 creatures. Hoot's Tattle is in his battle menu.`]]],
          ['if', A => A.questDone('fieldnotes'), [['say', 'Librarian Quill', 'Reading hour is over! ...Just kidding. Reading hour is forever.']]],
        ]],
      ]],
    ]],
  ],
  hazel: giver('bramble', 'Hunter Hazel',
    [['say', 'Hunter Hazel', "Psst. You look tough for a candle. There's a beast in the Bramble Thicket, west in Lumen Fields."],
      ['say', 'Hunter Hazel', "Problem is, a giant boulder blocks the way in. You'd need a friend who can smash rocks. Then smash that beast!"]],
    'The Bramble Beast is behind a boulder in Lumen Fields. Find someone who can smash it. Rocks. Or the beast. Both, ideally.',
    "You actually did it! I'll be telling that story at the inn for years. With some exaggerations."),
  mothwick_town: [
    ['if', A => !A.questKnown('study_first'), [
      ['say', 'Mothwick', "Wick! The town's a little brighter already. I can feel the Hero of Homework working."],
      ['say', 'Mothwick', "I wrote up some Study Challenges. They're really for the Hero: they only count real focus sessions."],
      ['say', 'Mothwick', "Each one I finish, er, each one THEY finish, I'll forge you a special badge. Strong ones!"],
      ['quest', 'study_first'], ['quest', 'study_clean'], ['quest', 'study_hero'], ['quest', 'study_marathon'],
      ['narrate', 'New Study Challenges! Check them any time in the menu (ESC → Quests).'],
    ], [
      ['turnin_any', ['study_first', 'study_clean', 'study_hero', 'study_marathon'], [
        ['say', 'Mothwick', A => A.studyHint()],
      ]],
    ]],
  ],
  barley: giver('windmill', 'Farmer Barley',
    [['say', 'Farmer Barley', "Howdy! My windmill's been jammed solid. Every time I fix it, those Gloomlings gum up the gears again."],
      ['say', 'Farmer Barley', 'Clear out five of the little pests here in the fields and I can finally bake again.']],
    A => `Gloomlings in the fields: ${Math.min(5, A.s.kills.fields_gloomling || 0)} of 5 down. Keep at it!`,
    "The windmill's spinning! Smell that? Fresh Windmill Cookies. Come back any time."),
  finn: [
    ['if', A => !A.questKnown('koi'), [
      ['say', 'Fisher Finn', "Shh, you'll scare the fish. ...Well, you already did. Hi."],
      ['say', 'Fisher Finn', "They say a Golden Koi lives in this lake. Catch three fish in a row off the dock and it might take a peek."],
      ['say', 'Fisher Finn', 'Use the dock right over there. Press SPACE the moment the bobber dips!'],
      ['quest', 'koi'],
    ], [
      ['if', A => A.questReady('koi'), [['turnin', 'koi'], ['say', 'Fisher Finn', "THE GOLDEN KOI! I've waited my whole life... to watch someone else catch it. Respect."]], [
        ['say', 'Fisher Finn', A => A.questDone('koi') ? 'Fish are still biting, if you want to fish for coins.' : 'Three in a row off the dock, then watch for something golden.'],
      ]],
    ]],
  ],
  rosa: [
    ['say', 'Old Rosa', 'Oh my, a visitor! That seal only breaks for someone who has truly focused for a long, long time.'],
    ['say', 'Old Rosa', 'Your Hero of Homework must be something special. Please, take what you find here. You earned it.'],
  ],
  smudge_poem: [
    ['if', A => A.flag('poem_read'), [['say', 'Smudge', "I framed Pebble's poem. It's crooked. I love it."]], [
      ['if', A => A.hasPartner('pebble') && A.s.partner === 'pebble', [
        ['quest', 'poem'],
        ['say', 'Smudge', '...Pebble. I smudged your poem. I am so sorry. Would you... read it to me?'],
        ['say', 'Pebble', '...ok. ahem. "rocks are round. rocks are square. rocks are rocks. rocks are there."'],
        ['say', 'Smudge', "...It's not perfect. It's WONDERFUL. Here, I made this when I stopped smudging things."],
        ['flag', 'poem_read'],
        ['turnin', 'poem'],
      ], [
        ['say', 'Smudge', "Hello again. I keep thinking about Pebble's poem. If you travel with Pebble, bring him by?"],
        ['quest', 'poem'],
      ]],
    ]],
  ],
  king_after: [['say', 'King Grumblecap', "I'm awake! I've already done three royal chores today. Started with a tiny one. It worked!"]],
  moss_meet: [
    ['say', 'Moss', 'blorp! hey! HEY! those gloomy guys are eating my lunch!'],
    ['cut', 'gloom_pop'],
    ['battle', ['gloomling', 'gloomling'], { scripted: true }],
    ['say', 'Moss', 'whoa. you bonked them so good.'],
    ['say', 'Moss', "i'm moss. i bounce. and i eat. mostly i eat."],
    ['say', 'Moss', 'can i come with you? i promise to bounce on stuff for you.'],
    ['partner', 'moss'],
    ['narrate', 'Moss joined your party! In battle, Moss can Bounce on enemies, and team up with Wick for a Team Attack.'],
    ['tip', 'Press C to use your partner\'s field ability (Moss: super Spring jump).  ESC opens the menu.'],
  ],
  moss_hi: [['say', 'Moss', 'blorp?']],
  elder_shed: [
    ['if', A => !A.has('hammer'), [
      ['say', 'Mothwick', 'There you are! And you made a friend. Hello, little slime.'],
      ['if', A => A.hasPartner('moss'), [['say', 'Moss', 'blorp. hi. do you have snacks.']]],
      ['say', 'Mothwick', 'Here: my old lamplighting hammer. It cracks rocks, breaks pots and bushes, and it is VERY good at bonking Gloom.'],
      ['ability', 'hammer'],
      ['narrate', "You got the Lamplighter's Hammer! Press X to swing it. In battle, it unlocks the Hammer attack."],
      ['say', 'Mothwick', 'See that cracked wall? Give it a good whack. Behind it, a path climbs up to my lookout. There is something up there you should see.'],
      ['say', 'Mothwick', 'Oh, and that lamppost? Lampposts save your game and heal you. Press E next to one.'],
    ], [
      ['say', 'Mothwick', 'Smash the cracked wall with X, then take the path up to my lookout. And use lampposts to save!'],
    ]],
  ],
  // the cracked wall at the shed comes down (in the Prologue): Mothwick flies on ahead to the lookout
  shed_wall: [
    ['if', A => !A.flag('prologue_done') && !A.flag('moth_flew'), [
      ['say', 'Mothwick', 'Ha! What a swing! See the path past the Ember Road gate? It climbs up through the trees to my lookout.'],
      ['say', 'Mothwick', "I'll fly on ahead. These old wings still work! Meet me at the top."],
      ['cut', 'elder_fly_shed'],
      ['flag', 'moth_flew'],
    ]],
  ],
  // ...and at the top of the path, the end of the Prologue (then he walks you back to town)
  prologue_end: [
    ['if', A => !A.flag('prologue_done'), [
      ['say', 'Mothwick', "There you are! Come, look out over the canyon. See the smoke on the horizon? That's Ember Peak."],
      ['say', 'Mothwick', "The Ember Road runs all the way there from the gate down below. It's shut for now: far too hot out there for a little candle."],
      ['say', 'Mothwick', 'One more thing before you go, Wick. From now on, your lantern burns ✦ Light while you explore. Look at the top right.'],
      ['say', 'Mothwick', 'When it runs low, go help the Hero of Homework. Their focus refuels you.'],
      ['say', 'Mothwick', "The shops in town are opening again, and I felt the first shard's glow out west, past Lumen Fields."],
      ['if', A => A.s.partner === 'moss', [['say', 'Moss', 'blorp. west. got it. ...which way is west.']]],
      ['say', 'Mothwick', "Come on, you two. I'll walk you back to town."],
      ['flag', 'prologue_done'],
      ['card', 'Prologue complete!', 'Lumen Town is open. Explore!'],
      ['goto', 'pro_1', 1350],
    ]],
  ],

  ch1_card: [['card', 'Chapter 1', 'The Grumbling Grove']],
  nutkin: [
    ['if', A => !A.flag('ch1_done'), [
      ['say', 'Nutkin', 'zzz... huh? oh. hi. i was gonna gather acorns today.'],
      ['say', 'Nutkin', 'but the King says everything can wait until tomorrow. so... zzz...'],
      ['say', 'Nutkin', 'five more minutes...'],
    ], [
      ['if', A => A.questDone('acorns'), [['say', 'Nutkin', "My golden acorn collection is complete! I'm going to stare at it all day. Productively."]], [
        ['if', A => A.questReady('acorns'), [['turnin', 'acorns'], ['say', 'Nutkin', 'ALL FIVE! I made you some armor from the shells. It\'s acorn-tastic.']], [
          ['if', A => A.questActive('acorns'), [['say', 'Nutkin', A => `Golden acorns: ${A.collectedCount('acorn')} of 5. They sparkle! Look up high, and behind bushes.`]], [
            ['say', 'Nutkin', "I'm AWAKE! Now I can finally start my real project: collecting the five golden acorns!"],
            ['say', 'Nutkin', "...but they're hidden all over the Grove and Lumen Fields. Some are way up high. Could you help?"],
            ['quest', 'acorns'],
          ]],
        ]],
      ]],
    ]],
  ],
  hoot: [
    ['if', A => A.flag('got_glasses'), [
      ['say', 'Hoot', 'Is that... MY SPECTACLES? Oh, glorious day! Everything is so... crisp.'],
      ['say', 'Hoot', "Hoot's the name, scholarship's the game. I've catalogued every creature in this grove."],
      ['say', 'Hoot', "The King has been snoring for a month and the whole grove caught his laziness. I'm coming with you!"],
      ['partner', 'hoot'],
      ['narrate', 'Hoot joined your party! In battle, Hoot can Tattle on enemies and Peck flyers. In the field, press C to Peek for hidden blocks.'],
    ], [
      ['if', A => A.flag('hoot_asked'), [
        ['say', 'Hoot', 'Find my spectacles, would you? I last had them near the Bramble Gap, to the east. Past a VERY wide gap.'],
      ], [
        ['say', 'Hoot', 'Who? WHO goes there? I can hardly see a thing.'],
        ['say', 'Hoot', "I've lost my spectacles. A scholar without spectacles is just a fancy pillow with feathers."],
        ['say', 'Hoot', 'I last had them near the Bramble Gap, east of here. Find them and I shall be in your debt!'],
        ['flag', 'hoot_asked'],
      ]],
    ]],
  ],
  sage: [
    ['if', A => !A.has('glide'), [
      ['say', 'Origami Sage', 'Ah. A paper traveler. How rare.'],
      ['say', 'Origami Sage', 'Tell me, little candle: what can paper do that rock cannot?'],
      ['say', 'Origami Sage', 'It can FOLD. And a fold... can FLY.'],
      ['sfx', 'fanfare'],
      ['ability', 'glide'],
      ['narrate', 'You learned the Glider Fold! Jump, then HOLD SPACE while falling to glide over wide gaps.'],
      ['say', 'Origami Sage', 'Try it on the Bramble Gap. Do not look down. Actually, do. It is very pretty down there.'],
    ], [
      ['say', 'Origami Sage', 'Jump, then hold SPACE to glide. Paper is patient. So am I.'],
    ]],
  ],
  gate_sign: [
    ['if', A => A.flag('gate_open'), [['narrate', 'The door to the Throne Stump is open.']], [
      ['if', A => A.hasPartner('hoot'), [
        ['say', 'Hoot', 'Let me see that tiny writing... ahem: "To enter, knock thrice and say: five more minutes."'],
        ['say', 'Hoot', 'How utterly undignified. Very well. *knock knock knock* FIVE MORE MINUTES!'],
        ['sfx', 'door'],
        ['flag', 'gate_open'],
        ['narrate', 'The Throne Stump door creaks open!'],
      ], [
        ['narrate', 'The writing on this sign is way too tiny to read. Maybe someone with sharp eyes (and good spectacles) could help.'],
      ]],
    ]],
  ],
  grumble_fight: [
    ['say', 'King Grumblecap', 'Zzzzz... mmmh... five more minutes...'],
    ['cut', 'boss_wake'],
    ['say', 'King Grumblecap', '...WHO DARES WAKE THE KING?!'],
    ['say', 'King Grumblecap', "I was going to deal with the Gloom. Tomorrow. Or the day after. There's ALWAYS tomorrow!"],
    ['say', 'King Grumblecap', 'Now leave me be. FIVE. MORE. MINUTES!'],
    ['battle', ['grumblecap'], { boss: true }],
    ['say', 'King Grumblecap', 'Hrrmph... I feel... awake? How long was I asleep?'],
    ['say', 'King Grumblecap', 'The Gloom whispered that everything could wait. So I waited. And waited. And the whole grove piled up.'],
    ['say', 'King Grumblecap', "Turns out 'tomorrow' never shows up on its own. You have to start today. Even a tiny bit."],
    ['say', 'King Grumblecap', "Take this. It's been glowing under my throne for weeks. Probably important."],
    ['shard', 1],
    ['flag', 'ch1_done'],
    ['narrate', 'The Grumbling Grove wakes up! Sunlight pours back into the trees.'],
    ['cut', 'dusk_in'],
    ['say', 'Count Dusk', 'Hmph. ONE measly shard. Enjoy it while it lasts, candle-boy.'],
    ['say', 'Count Dusk', 'My Ink Witch will smudge you right out of the picture. Mwahaha!'],
    ['cut', 'dusk_out'],
    ['card', 'Chapter 1 complete!', "Lumen Town's North Gate is open"],
    ['goto', 'pro_1', 2300],
  ],
  beast_fight: [
    ['if', A => A.s.partner === 'hoot', [['say', 'Hoot', 'Careful, Wick. That bush is breathing.']], [
      ['if', A => A.s.partner === 'pebble', [['say', 'Pebble', '...big bush. angry bush.']], [
        ['if', A => A.s.partner === 'moss', [['say', 'Moss', 'blorp. that bush has TEETH.']]],
      ]],
    ]],
    ['cut', 'boss_wake'],
    ['narrate', 'The Bramble Beast rises out of the thorns!'],
    ['battle', ['bramblebeast'], { boss: true }],
    ['flag', 'beast_down'],
    ['narrate', 'The Bramble Beast crumbles into ordinary, harmless bushes. Hunter Hazel will want to hear about this!'],
  ],

  ch2_card: [['card', 'Chapter 2', 'The Inkwell Caverns']],
  pebble: [
    ['if', A => !A.broken('c2c1'), [['say', 'Pebble', '...help... stuck... behind... wall...']], [['say', 'Pebble', '...oh. hi.']]],
  ],
  pebble_join: [
    ['say', 'Pebble', '...oh. light. hi.'],
    ['say', 'Pebble', "smudge inked me in here. i wrote a poem. she said it wasn't perfect."],
    ['say', 'Pebble', '...it was about rocks. i liked it.'],
    ['say', 'Pebble', "can i come? i'm strong. i can slam things. ...politely."],
    ['partner', 'pebble'],
    ['narrate', "Pebble joined your party! Pebble's Rock Slam ignores enemy defense. In the field, press C to Smash big boulders."],
  ],
  flare_shrine: [
    ['if', A => !A.has('flare'), [
      ['narrate', "An ancient lamplighter's shrine. Its star brightens as you come close..."],
      ['narrate', 'Your flame flares up, brighter than it has ever been!'],
      ['sfx', 'fanfare'],
      ['ability', 'flare'],
      ['narrate', "You learned Lantern Flare! Press F to light your flare and F again to put it out. While it burns it eats ✦ Light (1 every few seconds), lights up hidden paths and ✦ blocks, and the Gloom can't stand to look at you."],
    ], [['narrate', 'The shrine hums warmly.']]],
  ],
  smudge_fight: [
    ['say', 'Smudge', 'Ugh. ANOTHER visitor? And your entrance was SO sloppy.'],
    ['say', 'Smudge', "Your outline is crooked. Your flame is lopsided. And that hammer? Don't get me started."],
    ['if', A => A.hasPartner('hoot'), [['say', 'Hoot', 'She has smudged every drawing in these caverns. Nothing is ever good enough for her!']]],
    ['say', 'Smudge', "In MY studio, if it isn't PERFECT, it gets SMUDGED!"],
    ['battle', ['smudge'], { boss: true }],
    ['say', 'Smudge', '...You beat me. With your crooked outline and everything.'],
    ['say', 'Smudge', 'I smudged every draft because none of them felt good enough. I never finished a single one.'],
    ['say', 'Smudge', "...Maybe done is better than perfect. Ugh. Don't tell anyone I said that."],
    ['shard', 2],
    ['flag', 'ch2_done'],
    ['narrate', 'The ink drains away. Crystals glow all through the caverns again!'],
    ['cut', 'dusk_in'],
    ['say', 'Count Dusk', 'TWO shards?! ...No matter. Ember Peak will burn you OUT, candle-boy.'],
    ['cut', 'dusk_out'],
    ['card', 'Chapter 2 complete!', 'Something is rumbling in the east...'],
    ['goto', 'pro_1', 1350],
  ],

  // ---------------------------------------------------------------- Chapter 3: Ember Peak
  ch3_call: [
    ['cut', 'quake'],
    ['say', 'Mothwick', 'Whoa-whoa-WHOA! Did you feel that, Wick? The whole town just jumped!'],
    ['say', 'Mothwick', "Look east. Ember Peak is smoking again... and that smoke is purple. That's Gloom smoke."],
    ['say', 'Mothwick', 'The fire spirits up there keep the mountain warm and steady. If the Gloom got to them, the third shard must be up there too.'],
    ['say', 'Mothwick', "I've untied the rope bridge behind my shed. Take the Ember Road, east past my house."],
    ['say', 'Mothwick', 'And Wick... volcanoes are a LOT. Take it one step at a time.'],
    ['flag', 'ch3_open'],
  ],
  ch3_card: [['card', 'Chapter 3', 'Ember Peak']],
  sage_roll: [
    ['if', A => !A.has('roll'), [
      ['say', 'Origami Sage', 'Ah. The little candle again. You have grown brighter.'],
      ['say', 'Origami Sage', 'This road is blocked by rock. Too low to walk under. Too tall to climb.'],
      ['say', 'Origami Sage', 'When something is too big to get past... make yourself small. Fold. And ROLL.'],
      ['sfx', 'fanfare'],
      ['ability', 'roll'],
      ['narrate', 'You learned the Roll Fold! Hold R (or Shift) to roll up into a paper tube. Rolling is fast, and it fits through low gaps.'],
      ['say', 'Origami Sage', 'Small steps still go forward, little candle. Remember that on the mountain.'],
    ], [
      ['say', 'Origami Sage', 'Hold R to roll. Small is not weak. Small fits.'],
    ]],
  ],
  spark_kid: [
    ['say', 'Little Spark', A => (A.questDone('embers') ? "All my brothers and sisters are home! You're the BEST lantern!"
      : A.collectedCount('ember') ? 'You found some of my brothers and sisters?! Granny is gonna cry happy tears!'
        : "The big boom blasted my brothers and sisters away. Granny's worried sick...")],
  ],
  hearth: [
    ['if', A => A.s.partner === 'ember' && !A.flag('hearth_ember'), [
      ['say', 'Granny Hearth', "Ember! You're back! And you're... standing still? I've never seen you stand still."],
      ['say', 'Ember', "I'm learning, Granny. One thing at a time. ...It's really hard."],
      ['flag', 'hearth_ember'],
    ]],
    ['if', A => !A.questKnown('embers'), [
      ['say', 'Granny Hearth', "Oh! A little lantern! Come in, come in, warm your wick. Well... it's warm everywhere here."],
      ['if', A => !A.hasPartner('ember'), [
        ['say', 'Granny Hearth', 'Have you seen my grandkid, Ember? Ran off to the Brazier Gate to relight every flame on the mountain. All at once. Alone.'],
        ['say', 'Granny Hearth', 'That child tries to carry the whole peak. Please go after Ember? The gate is just north of here.'],
      ]],
      ['say', 'Granny Hearth', "And when Cindermaw erupted, it flung my five littlest grandkids clear across Lumenfold!"],
      ['say', 'Granny Hearth', "Some landed here on the peak, some in Lumen Fields, the Grumbling Grove, even the Inkwell Caverns. They're tiny, so they'll be hiding in tiny places."],
      ['quest', 'embers'],
    ], [
      ['if', A => A.questReady('embers'), [['turnin', 'embers'], ['say', 'Granny Hearth', 'All five of my little sparks, home safe! I knitted you something. Out of fire. Very carefully.']], [
        ['if', A => A.questDone('embers'), [['say', 'Granny Hearth', A => (A.flag('ch3_done') ? 'The peak is calm and the springs are warm. Come soak any time, dear.' : 'Go show that Cindermaw what one-at-a-time can do!')]], [
          ['say', 'Granny Hearth', A => `Little embers found: ${A.collectedCount('ember')} of 5. Look in tiny places! Rolling up small, or burning away vines, might help.`],
        ]],
      ]],
    ]],
  ],
  kettle: giver('ontime', 'Kettle',
    [['say', 'Kettle', "Ahhh... welcome to the Cinder Springs. Take a soak. Or don't. Either is fine. Everything is fine."],
      ['say', 'Kettle', "Here's the secret nobody tells you about breaks: the soak is the easy part. Coming BACK is the trick."],
      ['say', 'Kettle', "Tell your Hero of Homework: take a real break during a focus session, then come back before it runs out. Three times. I'll brew you something special."]],
    A => `On-time comebacks: ${Math.min(3, A.stat('breaks_on_time'))} of 3. Take a break in a focus session, then press "Back to work" before the break runs out.`,
    'Steam out, steam back in. You have the rhythm of a very fine kettle.'),
  annie: giver('forge', 'Anvil Annie',
    [['say', 'Anvil Annie', "HEY! Watch the sparks! ...Oh, a customer. I'm Annie. I make hammers HOT."],
      ['say', 'Anvil Annie', 'Since Cindermaw blew its top, my forge has gone cold. I need slag, the good stuff. Slagbrutes are made of it.'],
      ['say', 'Anvil Annie', "Knock out three Slagbrutes up the mountain. Tip: they're rock-hard until you heat 'em up."]],
    A => `Slagbrutes defeated: ${Math.min(3, A.s.kills.peak_slagbrute || 0)} of 3. Fire softens 'em right up!`,
    'The forge is ROARING again! Your hammer is officially hot. Try not to hug anybody with it.'),
  ember_hi: [['say', 'Ember', 'gotta-light-them-gotta-light-them-ALL-right-NOW...']],
  ember_meet: [
    ['say', 'Ember', 'gotta-light-them-gotta-light-them-ALL-right-NOW—'],
    ['cut', 'ember_panic'],
    ['say', 'Ember', "AAAH! They went out AGAIN! And the springs are cooling, and Granny's bread is burning, and Cindermaw is ROARING, and—"],
    ['if', A => A.s.partner === 'hoot', [['say', 'Hoot', 'Breathe, little flame. Nobody can do everything at once. Not even a very fast owl.']], [
      ['if', A => A.s.partner === 'pebble', [['say', 'Pebble', '...slow down. one rock. then the next rock.']], [
        ['if', A => A.s.partner === 'moss', [['say', 'Moss', 'blorp. when i eat, i eat one bite. then the next bite. works every time.']], [
          ['narrate', 'Wick holds up one finger. Just one.'],
        ]],
      ]],
    ]],
    ['say', 'Ember', '...One... at a time?'],
    ['say', 'Ember', "Huh. I always try to do all of it at once. Every day. It never works, and then I feel terrible."],
    ['say', 'Ember', "Okay. OKAY. One at a time. You're a lantern, right? Light stuff with me! I'm Ember. Let's go!"],
    ['partner', 'ember'],
    ['narrate', 'Ember joined your party! Ember throws fireballs in battle and teams up with Wick for the Flame Rally.'],
    ['tip', "Press C to throw Ember's fireball. It lights braziers and burns away vines. Light these in order: I, II, III, IV.", 12],
  ],
  brazier_done: [
    ['wait', 0.3],
    ['cut', 'gate_open'],
    ['say', 'Ember', 'One... two... three... FOUR! It worked! IT WORKED!'],
    ['say', 'Ember', 'One at a time felt slower... but it was SO much faster than all of them at once. How?!'],
    ['narrate', 'The Brazier Gate grinds open!'],
  ],
  dusk_peak: [
    ['cut', 'dusk_in'],
    ['say', 'Count Dusk', 'Still climbing, candle-boy? Cute. One little thing, then the next little thing. How SLOW.'],
    ['say', 'Count Dusk', 'My Cindermaw does EVERYTHING at once. Every task, every chore, all at the same time. Unstoppable!'],
    ['say', 'Ember', "...That's not unstoppable. That's just how you burn out."],
    ['say', 'Count Dusk', 'Hmph! We shall see who burns out first. Mwahaha!'],
    ['cut', 'dusk_out'],
  ],
  cindermaw_fight: [
    ['say', 'Cindermaw', 'MORE! MORE TASKS! ALL OF THEM! RIGHT! NOW!'],
    ['cut', 'boss_wake'],
    ['say', 'Ember', "That's... that's me. That's what I do every day. Everything at once, until it all blows up."],
    ['say', 'Ember', 'Okay, Wick. One thing at a time. Clear the little Cinderlings before they pile up!'],
    ['battle', ['cindermaw'], { boss: true }],
    ['say', 'Cindermaw', '...huff... huff... I was... trying to do... everything...'],
    ['say', 'Cindermaw', "The Gloom said if I didn't do it ALL, RIGHT NOW, I'd never get ANY of it done."],
    ['say', 'Ember', "I know that feeling. It's a big fat lie. You just do the next small thing. Then the next one."],
    ['say', 'Cindermaw', '...one... small... thing. ...I think I can do one small thing.'],
    ['say', 'Cindermaw', "Here. This was rattling around in my crater. It's what made the smoke all sparkly."],
    ['shard', 3],
    ['flag', 'ch3_done'],
    ['narrate', 'The purple smoke clears. Ember Peak settles into a warm, sleepy glow.'],
    ['cut', 'dusk_in'],
    ['say', 'Count Dusk', 'THREE?! Impossible! ...Fine. FINE. The last two shards are in MY tower.'],
    ['say', 'Count Dusk', "Come and get them, if you can stand the wait. Mwahaha... ha... hmph."],
    ['cut', 'dusk_out'],
    ['card', 'Chapter 3 complete!', "Count Dusk's Tower arrives in the next update"],
    ['goto', 'pro_1', 1350],
  ],
  cinder_after: [['say', 'Cindermaw', "I made a to-do list. It has ONE thing on it: 'nap'. ...I'm doing great."]],
};

// ---------------------------------------------------------------- the expansion
Object.assign(ROOMS, MORE_ROOMS);
patchRooms(ROOMS);
Object.assign(SCRIPTS, MORE_SCRIPTS);
Object.assign(QUESTS, MORE_QUESTS);
for (const [id, r] of Object.entries(QUEST_ROOMS)) Object.assign(QUESTS[id], r);
Object.assign(ENEMIES, MORE_ENEMIES);
Object.assign(BADGES, MORE_BADGES);
Object.assign(KEY_ITEMS, MORE_KEY_ITEMS);
Object.assign(SPEAKERS, MORE_SPEAKERS);
Object.assign(SPEAKER_OPTS, MORE_SPEAKER_OPTS);
// the Paper Plains update
Object.assign(ROOMS, WILD_ROOMS);
patchWilds(ROOMS);
Object.assign(AREAS, WILD_AREAS);
Object.assign(SCRIPTS, WILD_SCRIPTS);
Object.assign(QUESTS, WILD_QUESTS);
Object.assign(ENEMIES, WILD_ENEMIES);
Object.assign(BADGES, WILD_BADGES);
Object.assign(SPEAKERS, WILD_SPEAKERS);
Object.assign(SPEAKER_OPTS, WILD_SPEAKER_OPTS);
Object.assign(PORTRAIT_SCALE, WILD_PORTRAITS);
// the old outdoor places stretch far into the distance now
deepenRooms(ROOMS);
Object.assign(SCRIPTS, DEEP_SCRIPTS, MINI_SCRIPTS);
Object.assign(SPEAKERS, DEEP_SPEAKERS, MINI_SPEAKERS);
Object.assign(SPEAKER_OPTS, DEEP_SPEAKER_OPTS, MINI_SPEAKER_OPTS);
// Chapter 4: Count Dusk's Tower
Object.assign(ROOMS, TOWER_ROOMS);
patchTower(ROOMS, SCRIPTS, AREAS);
Object.assign(SCRIPTS, TOWER_SCRIPTS);
Object.assign(ENEMIES, TOWER_ENEMIES);
Object.assign(PARTNERS, TOWER_PARTNERS);
Object.assign(BADGES, TOWER_BADGES);
Object.assign(QUESTS, TOWER_QUESTS);
Object.assign(SPEAKERS, TOWER_SPEAKERS);
Object.assign(SPEAKER_OPTS, TOWER_SPEAKER_OPTS);
Object.assign(PORTRAIT_SCALE, TOWER_PORTRAITS);
// the Bonus Chapter: the Unfinished Margin (after the ending)
Object.assign(ROOMS, MARGIN_ROOMS);
patchMargin(ROOMS, SCRIPTS, AREAS);
Object.assign(SCRIPTS, MARGIN_SCRIPTS);
Object.assign(ENEMIES, MARGIN_ENEMIES);
Object.assign(PARTNERS, MARGIN_PARTNERS);
Object.assign(BADGES, MARGIN_BADGES);
Object.assign(QUESTS, MARGIN_QUESTS);
Object.assign(SPEAKERS, MARGIN_SPEAKERS);
Object.assign(SPEAKER_OPTS, MARGIN_SPEAKER_OPTS);
Object.assign(PORTRAIT_SCALE, MARGIN_PORTRAITS);
// Gaps that used to drop into plain nothing get something to avoid at the bottom instead (it bounces you back out:
// see Adventure.hazardBounce): the Gloom seeping into the Outskirts, thorns at the Grove Gate, folded-paper spikes
// in the Sticker Shrine, and grinding clock gears in Count Dusk's tower.
for (const [id, kind] of Object.entries({ pro_2: 'gloom', grove_1: 'brambles', shrine_3: 'spikes', dusk_3: 'gears', dusk_5: 'gears' })) {
  if (ROOMS[id] && !ROOMS[id].hazard) ROOMS[id].hazard = kind;
}
// more story along the way (story.js)
Object.assign(SCRIPTS, STORY_SCRIPTS);
patchStory(ROOMS);

// Dojo training: [coins, Star Pieces] per level. Level 2 needs the first sparring win, level 3 the second.
export const TRAINING = {
  atk: { name: '⚔️ Power training', what: 'ATK +1: every hit Wick lands does 1 more damage.', costs: [[40, 1], [100, 2], [220, 4]] },
  def: { name: '🛡️ Guard training', what: 'DEF +1: every hit Wick takes does 1 less damage.', costs: [[40, 1], [100, 2], [220, 4]] },
  pal: { name: '💛 Partner training', what: 'All your partners deal 1 more damage.', costs: [[80, 2], [200, 4]], gate: 1 },
  hp: { name: '♥ Heart training', what: 'Max HP +5.', costs: [[60, 0]] },
  fp: { name: '✿ Spirit training', what: 'Max FP +5.', costs: [[60, 0]] },
};

export const TOWN_TALK = [
  A => (A.shards >= 2 ? 'Two shards! The whole square is glowing. I may cry. Moths do cry, you know.'
    : A.shards === 1 ? 'One shard back in the Lantern! Look how the houses are waking up.'
      : 'The Lantern is still dark, but your flame is enough to start with.'),
  A => `Here's what I'd do next: ${objective(A).toLowerCase()}.`,
];
