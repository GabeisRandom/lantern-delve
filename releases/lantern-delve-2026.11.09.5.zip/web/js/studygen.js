// Practice questions, Teach Wick and Unstuck without Claude: for the copy for friends (which never has Claude), when
// Claude isn't connected, when the computer is offline, or when Claude didn't answer. From notes and the text of an
// assignment's files (studytext.js) it makes:
//   · definition questions, from glossary lines ("Neuron: a nerve cell…") and definition sentences ("X is a…",
//     "X refers to…", "…is called X"), multiple choice when there are other definitions to mix in;
//   · "what does it stand for?" questions, from acronyms in parentheses ("long-term potentiation (LTP)");
//   · fill-in-the-blanks that blank a sentence's key word (a term the notes define or repeat, a name, a number), with
//     look-alike wrong answers taken from the same notes.
// It also picks what Teach Wick asks about, checks explanations against a deck, and has hints for each kind of
// homework (code, math and science, writing, reading).

// ---------------------------------------------------------------- words
export const STOP = new Set(`the a an and or but of to in on at for with by from as is are was were be been being this that these
  those it its their there which who whom whose what when where why how than then so such can could may might will would
  should do does did not no also into over under about between more most less least very much many some any each every
  other another same just only they them you your we our he she his her has have had one two three first second because
  while during after before since until like using used often usually always never itself however therefore thus hence
  although though whereas whether either neither nor yet still even really actually basically generally typically mostly
  mainly especially particularly me my us let lets get gets got make makes made take takes took give gives gave go goes went
  come comes came see sees saw say says said know knows knew think thinks thought want wants way ways thing things lot lots
  kind kinds sort type types part parts example examples etc else ever here own well back up down out off again further
  once all both few must shall upon via per within without across around through throughout toward towards among against
  along beyond besides unlike near unless roughly approximately yourself themselves himself herself ourselves myself huge`.split(/\s+/));
// words too vague to be the answer to a fill-in-the-blank on their own
const VAGUE = new Set(`people person time times year years day days number numbers amount group groups system systems process
  processes result results information data form forms level levels area areas place places point points case cases fact facts
  idea ideas reason reasons problem problems question questions answer answers important different following similar several
  various certain specific general common main major minor large small little high low good bad new old last next early late
  long short full whole entire able likely possible necessary called known based related include includes including involve
  involves involved help helps helped show shows shown find found work works worked need needs needed useful sometimes something
  someone anything everything nothing study studies studied research researchers scientists term terms word words name names
  chapter lecture class course page section figure table usually lead leads led allow allows allowed become becomes became
  better best worse worst greater less lower higher larger smaller instead rather while each them`.split(/\s+/));

const reEsc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const shuffle = a => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
export const answerText = c => (c.type === 'mc' ? c.options[c.answer] : c.answer);
const clip = (s, n) => (s.length <= n ? s : `${s.slice(0, s.lastIndexOf(' ', n - 1) > n * 0.6 ? s.lastIndexOf(' ', n - 1) : n - 1).replace(/[\s,;:]+$/, '')}…`);
const stripEnd = s => s.replace(/[\s.;:,]+$/, '');
const capFirst = s => s.charAt(0).toUpperCase() + s.slice(1);
// a whole word or phrase, wherever it is in a sentence (with what comes before it in $1)
const wordRe = t => new RegExp(`(^|[^\\w'’-])${reEsc(t)}(?![\\w-])`, 'gi');

// Typed answers are checked leniently: case, punctuation, "the/a" and a small typo don't matter.
export const norm = s => String(s).toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9 ]+/g, ' ')
  .replace(/\b(the|a|an)\b/g, ' ').replace(/\s+/g, ' ').trim();
function lev(a, b) {
  const d = Array.from({ length: b.length + 1 }, (_, j) => j);
  for (let i = 1; i <= a.length; i++) {
    let prev = d[0];
    d[0] = i;
    for (let j = 1; j <= b.length; j++) { const t = d[j]; d[j] = Math.min(d[j] + 1, d[j - 1] + 1, prev + (a[i - 1] === b[j - 1] ? 0 : 1)); prev = t; }
  }
  return d[b.length];
}
export function matches(given, accepted) {
  const g = norm(given);
  if (!g) return false;
  return accepted.some(a => {
    const t = norm(a);
    if (!t) return false;
    if (g === t || g.includes(t)) return true;
    if (t.includes(g) && g.length >= Math.max(4, t.length * 0.6)) return true;
    return lev(g, t) <= (t.length >= 8 ? 2 : 1);
  });
}

// content words, and a rough stem of each ("memories" and "memory", "rehearse" and "rehearsal" match)
export const contentWords = s => (String(s).toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').match(/[a-z][a-z'’-]*[a-z]/g) || [])
  .map(w => w.replace(/['’]s$/, '')).filter(w => w.length >= 4 && !STOP.has(w));
export function stem(w) {
  let s = w.replace(/['’-]/g, '');
  for (const [suf, to] of [['ations', ''], ['ation', ''], ['ings', ''], ['ing', ''], ['ies', 'y'], ['ied', 'y'], ['es', ''], ['ed', ''], ['ly', ''], ['s', '']]) {
    if (s.length - suf.length >= 4 && s.endsWith(suf)) { s = s.slice(0, -suf.length) + to; break; }
  }
  return s.replace(/e$/, '').slice(0, 6);
}

// ---------------------------------------------------------------- reading the notes
const BULLET = /^\s*[•*·▪◦‣○●■□➢➤►→✓✔☐☑–—-]+\s*/;
const NUMBERING = /^\(?(?:\d{1,3}|[a-hA-H]|[ivxIVX]{1,4})[.)]\s+/;
// things that look like "Term: …" but aren't terms (labels, dates, course codes)
const LABELS = new Set(`problem|question|q|a|answer|ans|part|step|lecture|lec|chapter|ch|unit|module|week|day|lesson|section|sec|page|pg|p|
  figure|fig|table|exercise|ex|example|examples|eg|e.g|ie|i.e|note|notes|nb|hint|hints|tip|tips|homework|hw|assignment|quiz|exam|
  midterm|final|test|lab|reading|readings|instruction|instructions|direction|directions|objective|objectives|goal|goals|summary|overview|
  intro|introduction|conclusion|topic|topics|title|course|class|professor|prof|instructor|ta|teacher|office hours|email|e-mail|phone|
  point|points|pts|grade|score|total|due|due date|date|time|name|source|sources|reference|references|citation|citations|term|terms|
  keyword|keywords|vocab|vocabulary|definition|definitions|agenda|outline|todo|to do|reminder|remember|important|warning|caution|update|
  announcement|location|room|link|url|website|prerequisite|prerequisites|textbook|book|author|edition|isbn|monday|tuesday|wednesday|
  thursday|friday|saturday|sunday|mon|tue|tues|wed|thu|thur|thurs|fri|sat|sun|january|february|march|april|may|june|july|august|
  september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|sept|oct|nov|dec|today|tomorrow|tonight|yesterday|solution|
  solutions|key|answer key|result|results|output|input|idea|ideas|main idea|big idea|takeaway|takeaways|tldr|recap|review|key terms|
  key term|key points|key point|key ideas|main points|questions|answers|required|optional|materials|resources|contact|hours|schedule`
  .split(/\s*\|\s*/));
const BAD_FIRST = /^(there|this|these|those|that|it|its|they|them|we|you|your|i|he|she|his|her|their|our|my|one|two|three|four|five|six|seven|eight|nine|ten|several|many|some|most|all|both|each|every|other|another|such|why|how|what|when|where|who|which|if|because|so|but|and|or|then|also|for|in|on|at|to|from|with|by|of|as|see|not|no|yes)\b/i;
const BAD_LAST = /\b(types|kinds|steps|parts|stages|phases|examples|reasons|factors|causes|effects|features|characteristics|functions|properties|components|elements|advantages|disadvantages|benefits|pros|cons|rules|laws|principles|methods|ways|include|includes|are|is|the|a|an|of|and|or|to|in|for|with)$/i;
// "the main difference", "the first step", "the key point": not terms
const VAGUE_HEAD = /\b(difference|reason|point|idea|thing|step|way|part|problem|goal|purpose|question|answer|result|key|issue|trick|lesson|takeaway|conclusion|fact|truth|outcome|catch|downside|upside|benefit|role|job|aim|focus|basis|end|start|beginning|rest|same|one|other|others|option|choice)$/i;
const VERBISH = /\b(is|are|was|were|has|have|had|will|would|can|could|should|include|includes|including|do|does|did)\b/i;

function isLabel(t) {
  const l = t.toLowerCase().replace(/[.:#\s]+$/, '').trim();
  if (LABELS.has(l)) return true;
  const stripped = l.replace(/(\s+#?|#)(\d+(\.\d+)*[a-z]?|[a-z]|[ivxlc]+)[.)]?$/, '').replace(/\.$/, '');
  if (stripped !== l && LABELS.has(stripped)) return true;
  if (/^(q|p|hw|ex|pr|ch|lec|wk|pt|sec|fig|pg|ps|pset)\s*\d+[a-z]?$/.test(l)) return true;
  if (/^[A-Z]{2,5}\s?\d{3,4}[A-Z]?$/.test(t.trim())) return true;             // a course code, like BIOL 1111
  if (/^[\d\s:./-]+(am|pm)?$/.test(l)) return true;                            // numbers, times, dates
  return false;
}

// a term from the left side of "Term: …" (or a sentence's subject), tidied, or null
function goodTerm(raw) {
  let t = String(raw).replace(/^[*_`"“'‘\s]+|[*_`"”'’\s]+$/g, '').replace(/\s+/g, ' ').trim();
  let alias = '';
  const paren = t.match(/^(.*?)\s*\(([^()]{1,40})\)$/);
  if (paren && paren[1]) { t = paren[1].trim(); alias = paren[2].trim(); }
  t = t.replace(/^(the|a|an)\s+/i, '');
  if (!t || t.length > 60 || !/[a-z]/i.test(t) || (t.match(/\(/g) || []).length !== (t.match(/\)/g) || []).length) return null;
  if (t.split(' ').length > 5 || /[.!?;]$/.test(t) || /https?:|www\.|@|\d{3,}/.test(t)) return null;
  if (isLabel(t) || BAD_FIRST.test(t) || BAD_LAST.test(t) || VAGUE_HEAD.test(t) || VERBISH.test(t) || / of the /i.test(t)) return null;
  if (t.split(' ').length === 1 && VAGUE.has(t.toLowerCase())) return null;
  return { text: t, alias: alias.length <= 24 && !/\s{2}/.test(alias) ? alias : '' };
}
function goodDef(raw, term) {
  const d = String(raw).replace(/^[\s:–—=-]+/, '').replace(/\s+/g, ' ').trim();
  if (d.split(' ').length < 2 || d.length < 8 || d.length > 320) return null;
  if (!/[a-z]{3}/.test(d) || /^(https?:|www\.)/i.test(d) || norm(d) === norm(term)) return null;
  if (/^(this|that|these|those|it|its|they|he|she|such|which|who)\b/i.test(d)) return null;     // ("this fading": what fading?)
  return d;
}

// "Term: definition" (or "Term – definition", "Term = definition", "Term<tab>definition"): the first separator that
// isn't inside parentheses or between two numbers (10:30, 1939–1945)
const SEP = /(\t+)|( ?[–—] ?)|( - )|( = )|(:(?!\/\/))/g;
function splitDef(raw) {
  SEP.lastIndex = 0;
  let m;
  while ((m = SEP.exec(raw))) {
    if (m.index === 0) continue;
    const before = raw.slice(0, m.index), after = raw.slice(m.index + m[0].length);
    if ((before.match(/\(/g) || []).length > (before.match(/\)/g) || []).length) continue;
    if (/\d$/.test(before) && /^\d/.test(after)) continue;
    return { term: before, def: after };
  }
  return null;
}

// sentences that teach something: not instructions, admin, questions or headings
const ADMIN = /\b(points?|pts|due|submit|submission|canvas|blackboard|moodle|gradescope|rubric|late penalty|late work|deadline|graded|grading|office hours|syllabus|e-?mail|upload|turn in|attach(ed|ment)?|pdf|docx|word count|double[- ]spaced|font|margins?|page limit|extra credit|participation|attendance|zoom|password|click|download|homework|assignment|worksheet|quiz(zes)?|exams?|midterms?|final exam|pp\.)\b/i;
const INSTR = /^(read|write|answer|submit|complete|show|explain|describe|discuss|compare|contrast|find|solve|calculate|compute|use|make|turn|upload|include|list|draw|label|identify|choose|select|circle|fill|define|prove|justify|evaluate|determine|graph|sketch|simplify|estimate|consider|suppose|let|given|assume|create|design|implement|run|test|print|return|analy[sz]e|summari[sz]e|reflect|respond|cite|be sure|make sure|remember|note|recall|please|do|don't|try|check|look|see|go|click|open|save|watch|review|study|practice|state|name|give|provide|support|argue|outline|plan|prepare|bring|post|reply|write)\b/i;
const YOU_MUST = /\byou(?:'ll| will| should| must| need to| are expected| may use| can use| have to)\b/i;
const AUX = /\b(is|are|was|were|be|been|being|has|have|had|does|do|did|can|could|will|would|may|might|must|should|shall)\b/i;
const IRREGULAR = /\b(began|begin|met|led|took|made|became|fell|rose|won|lost|built|wrote|found|held|left|brought|came|went|gave|saw|ran|grew|knew|drew|threw|spoke|broke|chose|rode|stood|sat|put|set|cut|let|hit|kept|slept|felt|meant|sent|spent|taught|thought|fought|caught|bought|sought|told|sold|paid|laid|said|sank|swam|struck|split|spread|shot|shut|bore|wore|tore|froze|forgot|overthrew|arose|bound|dug|fled|flew|forbade|hung|lay|lit|rang|sang|shook|shrank|sprang|stole|stuck|stung|swore|swept|swung|wept|wound)\b/i;
const hasVerb = s => AUX.test(s) || IRREGULAR.test(s) || /\s[a-z]{3,}(ed|ing|es|s)\b/.test(s);
function teaches(s) {
  const n = s.split(' ').length;
  return n >= 5 && n <= 55 && s.length <= 340 && /[a-z]{3}/.test(s) && !/\?["”')]?$/.test(s) && !ADMIN.test(s) && !INSTR.test(s)
    && !YOU_MUST.test(s) && hasVerb(s);
}
// does line b carry on line a's sentence? (a line ending in an initial or "e.g." always goes on: "B. F. / Skinner")
const ABBR_END = /(\b[A-Z]|\b(e\.g|i\.e|vs|Dr|Mr|Mrs|Ms|Prof|St|al|Fig|No))\.$/;
const joinable = (a, b) => ABBR_END.test(a) || (!/[.!?:;]["”')\]]?$/.test(a)
  && (/^[a-z0-9(“"']/.test(b) || /[,–&-]$/.test(a) || /\b(the|a|an|of|and|or|to|in|on|for|with|by|from|as|that|which|is|are)$/i.test(a)));
const ABBR = /\b(e\.g|i\.e|etc|vs|cf|al|approx|dept|Dr|Mr|Mrs|Ms|Prof|Sr|Jr|St|No|Fig|Eq|Vol|pp|ca|U\.S|U\.K|a\.m|p\.m)\./g;
function sentences(par) {
  const safe = par.replace(ABBR, m => m.replace(/\./g, '․')).replace(/\b([A-Z])\.(?=\s+[A-Z])/g, '$1․');
  return safe.split(/(?<=[.!?]["”')\]]?)\s+(?=["“(\[]?[A-Z0-9])/).map(s => s.replace(/․/g, '.').trim()).filter(Boolean);
}

// definition sentences: "X is a/the…", "X refers to…", "… is called X"
const DEF_CALLED = /^(?:(?:the|a|an)\s+)?(.{6,140}?)\s+(?:is|are)\s+(?:often\s+|also\s+|sometimes\s+|usually\s+)?(?:called|known as|termed|referred to as|named)\s+(?:the\s+|an?\s+)?["“'‘]?([^"”’,.;:()]{2,50}?)["”’']?\s*(?:\(([^)]{1,30})\))?\s*(?:[.,;]|$)/i;
const DEF_IS = /^(?:(?:the|a|an)\s+)?([^,;:()]{2,60}?)\s+(?:is|are)\s+(?:(?:defined|described)\s+as\s+|(?:also\s+)?(?=(?:a|an|the|one|any|how|when|where|what|whatever|something|someone|anything|made up|composed|responsible|used to|located|found in)\b|[a-z]+(?:\s+[a-z]+)?\s+(?:in which|whereby|that|where|which)\b))(.{6,})$/i;
const DEF_VERB = /^(?:(?:the|a|an)\s+)?([^,;:()]{2,60}?)\s+(?:refers? to|means|describes|stands for)\s+(.{6,})$/i;
function sentenceDef(s) {
  let m = s.match(DEF_CALLED);
  if (m) {
    // ("…can suddenly return, which is known as spontaneous recovery": the part before ", which")
    const term = goodTerm(m[2]), def = term && goodDef(m[1].replace(/,?\s+(which|that|this|what)$/i, ''), term.text);
    if (def) return { term: term.text, alias: m[3] && m[3].length <= 24 ? m[3] : term.alias, def: def.charAt(0).toLowerCase() + def.slice(1) };
  }
  m = s.match(DEF_IS) || s.match(DEF_VERB);
  if (m) {
    const term = goodTerm(m[1]), def = term && goodDef(m[2], term.text);
    if (def) return { term: term.text, alias: term.alias, def };
  }
  return null;
}

// acronyms explained in parentheses: "long-term potentiation (LTP)", "central nervous system (CNS)"
const SMALL = /^(of|and|the|for|in|on|to|a|an|&)$/i;
function acronymsIn(s) {
  const out = [];
  for (const m of s.matchAll(/((?:[A-Za-z][\w'’]*(?:[-/][A-Za-z][\w'’]*)*\s+){1,8})\(([A-Z][A-Za-z]{1,6})\)/g)) {
    const acr = m[2], letters = (/^[A-Z]+s$/.test(acr) ? acr.slice(0, -1) : acr).toLowerCase();
    if (letters.length < 2 || !/^[A-Z]/.test(acr) || acr.replace(/[^A-Z]/g, '').length < 2) continue;
    const words = m[1].trim().split(/\s+/);
    let full = '';
    for (let k = 1; k <= words.length && !full; k++) {
      const phrase = words.slice(-k);
      if (SMALL.test(phrase[0])) continue;
      const parts = phrase.flatMap(w => w.split(/[-/]/)).filter(w => w && !SMALL.test(w)), initials = parts.map(w => w[0].toLowerCase()).join('');
      if (initials === letters) full = phrase.join(' ');
      else if (k >= 2 && parts.length >= 2 && initials[0] === letters[0]) {
        // (looser: "deoxyribonucleic acid (DNA)", "adenosine triphosphate (ATP)": the letters, in order, inside the words)
        const joined = parts.join('').toLowerCase();
        let at = 0;
        for (const ch of letters) { at = joined.indexOf(ch, at); if (at < 0) break; at++; }
        if (at > 0 && letters.length <= parts.length * 3) full = phrase.join(' ');
      }
    }
    if (full) out.push({ acr, full });
  }
  return out;
}

// the words of a sentence, with where each one starts
const TOKEN = /[A-Za-z][A-Za-z0-9'’-]*|\d[\d,.]*%?/g;
function tokens(s) {
  const out = [];
  for (const m of s.matchAll(TOKEN)) {
    const w = m[0].replace(/[.,'’-]+$/, '').replace(/['’]s$/, '');
    if (w) out.push({ w, i: m.index, lo: w.toLowerCase() });
  }
  return out;
}
const isNumber = w => /^\d[\d,.]*%?$/.test(w);
const isChem = w => /^[A-Z][A-Za-z]{0,2}\d{1,3}$/.test(w);         // CO2, H2O, B12

// Everything makeCards needs to know about the notes: definitions, acronyms, the sentences that teach something,
// how often each word and phrase comes up, and each sentence's best word to blank out.
function analyze(text) {
  const raw = String(text || '').replace(/\r\n?/g, '\n').replace(/ /g, ' ').replace(/[​﻿]/g, '').split('\n');
  // lines that repeat over and over (a PDF's page headers and footers) aren't notes
  const seen = new Map(), key = l => l.trim().toLowerCase().replace(/\d+/g, '#');
  for (const l of raw) if (l.trim()) seen.set(key(l), (seen.get(key(l)) || 0) + 1);
  const A = { defs: [], acrs: [], sents: [], pool: new Map(), terms: new Map(), acrMap: new Map(), uni: new Map(), bi: new Map(), tri: new Map(), caps: new Set() };
  let pos = 0, cur = null, lastDef = null;
  const flush = () => {
    if (!cur) return;
    for (const s of sentences(cur.text)) {
      for (const a of acronymsIn(s)) A.acrs.push({ ...a, source: s, pos: pos++ });
      if (!teaches(s)) continue;
      const d = sentenceDef(s);
      if (d) A.defs.push({ ...d, source: s, pos: pos++, from: 'sentence' });
      A.sents.push({ text: s, pos: pos++, def: !!d });
    }
    cur = null;
  };
  for (const r of raw) {
    const t = r.trim();
    if (!t || (seen.get(key(r)) >= 3 && t.length < 80)) { flush(); lastDef = null; continue; }
    let bullet = BULLET.test(r) || NUMBERING.test(t);
    let body = t.replace(BULLET, '').replace(NUMBERING, '');
    let sp = body.length <= 340 ? splitDef(body) : null;
    // a label in front ("Problem 2: …", "Note: …", "Q1: …"): only what comes after it counts, as a new paragraph
    if (sp && isLabel(sp.term.replace(/^[*_`"“'‘\s]+|[*_`"”'’\s]+$/g, ''))) { body = sp.def; sp = null; bullet = true; }
    const text = body.replace(/\s+/g, ' ').trim();
    if (!text) { lastDef = null; continue; }
    const term = sp && goodTerm(sp.term), def = term && !ADMIN.test(text) && goodDef(sp.def, term.text);
    if (def) {
      flush();
      A.defs.push(lastDef = { term: term.text, alias: term.alias, def, source: text, pos: pos++, from: 'line' });
      for (const a of acronymsIn(text)) A.acrs.push({ ...a, source: text, pos: pos++ });
      continue;
    }
    // (a definition that wraps onto the next line, as in a PDF)
    if (lastDef && !bullet && !cur && joinable(lastDef.def, text) && lastDef.def.length + text.length <= 320) {
      lastDef.def += ` ${text}`;
      lastDef.source += ` ${text}`;
      continue;
    }
    lastDef = null;
    if (cur && !bullet && joinable(cur.text, text)) cur.text = /[a-z]-$/.test(cur.text) && /^[a-z]/.test(text) ? cur.text.slice(0, -1) + text : `${cur.text} ${text}`;
    else { flush(); cur = { text }; }
  }
  flush();
  // how often words and phrases come up (and in how many sentences: the topic itself is in most of them), and which
  // words are written with a capital in the middle of a sentence
  const units = new Set([...A.sents.map(s => s.text), ...A.defs.map(d => d.source)]), df = new Map();
  for (const unit of units) {
    const tk = tokens(unit).map(t => t.lo);
    tokens(unit).forEach((t, i) => { if (i > 0 && /^[A-Z]/.test(t.w)) A.caps.add(t.lo); });
    for (const w of new Set(tk)) df.set(w, (df.get(w) || 0) + 1);
    for (let i = 0; i < tk.length; i++) {
      A.uni.set(tk[i], (A.uni.get(tk[i]) || 0) + 1);
      if (i + 1 < tk.length) { const b = `${tk[i]} ${tk[i + 1]}`; A.bi.set(b, (A.bi.get(b) || 0) + 1); }
      if (i + 2 < tk.length) { const b = `${tk[i]} ${tk[i + 1]} ${tk[i + 2]}`; A.tri.set(b, (A.tri.get(b) || 0) + 1); }
    }
  }
  const addPool = (text, kind, score) => {
    const lo = text.toLowerCase(), old = A.pool.get(lo);
    if (!old || old.score < score) A.pool.set(lo, { text, lo, kind, n: lo.split(' ').length, score, display: text });
  };
  const kindOf = t => (isNumber(t) ? 'num' : /^[A-Z]{2,6}s?$/.test(t) ? 'acr' : t.split(' ').every(w => /^[A-Z]/.test(w)) ? 'proper' : 'word');
  // (a glossary's "Encoding" is just "encoding" next to other answers, unless the notes capitalize it mid-sentence)
  const plain = t => (A.caps.has(t.split(' ')[0].toLowerCase()) || /^[A-Z]{2}/.test(t) ? t : t.charAt(0).toLowerCase() + t.slice(1));
  for (const d of A.defs) {
    A.terms.set(d.term.toLowerCase(), d);
    if (d.alias) A.terms.set(d.alias.toLowerCase(), d);
    const kind = kindOf(d.term) === 'proper' && !A.caps.has(d.term.split(' ')[0].toLowerCase()) ? 'word' : kindOf(d.term);
    addPool(kind === 'word' ? plain(d.term) : d.term, kind, 9);
  }
  for (const a of A.acrs) {
    A.acrMap.set(a.acr.toLowerCase(), a.full);
    A.acrMap.set(a.full.toLowerCase(), a.acr);
    A.terms.set(a.acr.toLowerCase(), a);
    A.terms.set(a.full.toLowerCase(), a);
    addPool(a.acr, 'acr', 8);
    addPool(plain(a.full), 'word', 8);
  }
  // each sentence's best words or phrases to blank out
  const capTok = (t, k) => /^[A-Z][a-z'’]/.test(t.w) || (k > 0 && /^[IVXL]+$/.test(t.w));    // (Louis XVI)
  for (const s of A.sents) {
    const tk = tokens(s.text), cands = [];
    for (let n = 1; n <= 3; n++) {
      for (let i = 0; i + n <= tk.length; i++) {
        const span = tk.slice(i, i + n), last = span[n - 1];
        const surface = s.text.slice(span[0].i, last.i + last.w.length);
        if (n > 1 && /[^\w\s'’-]/.test(surface)) continue;               // (it would cross punctuation)
        const lo = span.map(t => t.lo).join(' '), first = span[0].lo, end = last.lo;
        if (STOP.has(first) || STOP.has(end)) continue;
        const num = n === 1 && isNumber(span[0].w);
        if (!num && span.some(t => /\d/.test(t.w) && !isChem(t.w))) continue;
        if (num && n > 1) continue;
        const known = A.terms.has(lo);
        const caps = span.every(capTok);
        const proper = caps && !known && (i > 0 || n >= 2 || span.every(t => A.caps.has(t.lo)));
        const acr = n === 1 && /^[A-Z]{2,6}s?$/.test(span[0].w) && !/^[IVXLCDM]+$/.test(span[0].w);
        if (acr && tk[i + 1] && isNumber(tk[i + 1].w)) continue;          // (a course code, like PSYC 1101)
        const freq = (n === 1 ? A.uni : n === 2 ? A.bi : A.tri).get(lo) || 0;
        let score;
        if (num) {
          const v = parseFloat(span[0].w.replace(/,/g, ''));
          const next = tk[i + 1] ? tk[i + 1].lo : '';
          const unit = !!next && !STOP.has(next) && /^[a-z]/.test(next);
          const year = /^\d{4}$/.test(span[0].w) && v >= 1000 && v <= 2099;
          if ((!year && !unit && !span[0].w.endsWith('%')) || (!year && v < 2 && !span[0].w.includes('.'))) continue;
          score = 2.6 + (year ? 1.2 : 0) + (unit ? 0.8 : 0);
        } else {
          // (followed by "a", "the", "about"…, the last word is probably a verb: "memory holds a…")
          const verbish = !known && !proper && /^(a|an|the|about|this|these|some|many|most|all|each|its|their|one)$/.test(tk[i + n] ? tk[i + n].lo : '');
          if (n > 1 && verbish) continue;
          if (n > 1 && !known && !proper && freq < 2) continue;
          if (n > 1 && !known && !proper && span.slice(1, -1).some(t => STOP.has(t.lo) && t.lo !== 'of')) continue;   // ("behavior more likely")
          if (n === 1 && !known && !proper && !acr && !isChem(span[0].w) && (first.length < 4 || VAGUE.has(first) || /ly$/.test(first))) continue;
          score = (known ? 7 : 0) + Math.min(3, Math.max(0, freq - 1)) * 1.3 + (proper ? 2.5 : 0) + (acr ? 2 : 0)
            + Math.min(2.5, Math.max(0, (surface.length - 4) * 0.25)) + 0.8 * (n - 1);
          const prev = tk[i - 1] ? tk[i - 1].lo : '', next = tk[i + n] ? tk[i + n].lo : '';
          if (/^(the|a|an|this|these|that|those|its|their|his|her|our|of)$/.test(prev)) score += 1.2;
          if (/^(is|are|was|were|has|have|can|helps?|plays?)$/.test(next)) score += 0.8;
          if (n === 1 && !known && !proper && /(ed|ing)$/.test(first) && !/^(the|a|an)$/.test(prev)) score -= 1.5;
          if (n === 1 && verbish) score -= 2;
          if (n === 1 && !known && !proper && !acr && units.size >= 6 && (df.get(first) || 0) / units.size > 0.5) score -= 3;   // (the topic)
        }
        const kind = num ? 'num' : acr ? 'acr' : proper ? 'proper' : 'word';
        const display = kind === 'word' && i === 0 && !A.caps.has(first) ? surface.charAt(0).toLowerCase() + surface.slice(1) : surface;
        if (score >= 2.5 && kind !== 'num') addPool(kind === 'word' ? display : surface, kind, score);
        // (the rest of the sentence has to still say something)
        if (score >= 3.2 && s.text.split(' ').length - n >= 4) cands.push({ text: surface, display, lo, kind, n, score });
      }
    }
    // the 3 best that don't overlap (if the best one is already another card's answer, the next one can be)
    cands.sort((a, b) => b.score - a.score);
    s.cands = [];
    for (const c of cands) {
      if (s.cands.some(o => o.lo.includes(c.lo) || c.lo.includes(o.lo))) continue;
      s.cands.push(c);
      if (s.cands.length === 3) break;
    }
  }
  return A;
}

// ---------------------------------------------------------------- making the cards
// wrong answers that look like the right one: the same kind of thing (a name, a number, a term), about as long, not
// in the question and not sharing a word with the answer
function lures(ans, pool, questionNorm, k = 3) {
  // (plain words: strong candidates first, the rest only if there aren't enough)
  for (const min of ans.kind === 'word' ? [4.5, 0] : [0]) {
    const out = luresAbove(ans, pool, questionNorm, k, min);
    if (out) return out;
  }
  return null;
}
function luresAbove(ans, pool, questionNorm, k, min) {
  const aw = ans.lo.split(' '), aStems = new Set(aw.map(stem));
  const clash = (p, q) => p.lo.split(' ').some(w => q.has(stem(w)));
  const tail = s => s.slice(-(s.length >= 6 ? 3 : 2));
  const scored = [];
  // (a lone "National" from "National Assembly" makes a poor wrong answer)
  const longer = [...pool.values()].filter(p => p.n > 1 && p.kind === ans.kind).map(p => ` ${p.lo} `);
  for (const p of pool.values()) {
    if (p.score < min || p.lo === ans.lo || p.kind !== ans.kind || questionNorm.includes(` ${norm(p.text)} `) || clash(p, aStems)) continue;
    if (p.n === 1 && ans.n === 1 && p.kind === 'proper' && longer.some(l => l.includes(` ${p.lo} `))) continue;
    const pw = p.lo.split(' ');
    let s = pw.length === aw.length ? 3 : -Math.abs(pw.length - aw.length);
    s += 2 - Math.min(3, Math.abs(p.text.length - ans.text.length) / 3);
    if (tail(p.lo) === tail(ans.lo)) s += 1.5;
    if (/s$/.test(p.lo) === /s$/.test(ans.lo)) s += 1;
    s += Math.min(2, p.score / 4);
    scored.push([s, p]);
  }
  scored.sort((a, b) => b[0] - a[0]);
  const out = [];
  for (const [, p] of scored) {
    const st = new Set(p.lo.split(' ').map(stem));
    if (out.some(o => clash(o, st))) continue;
    out.push(p);
    if (out.length === k) break;
  }
  return out.length === k ? out.map(p => p.display) : null;
}

// wrong numbers near the right one (shuffled offsets, so the right one isn't always in the middle)
function numberLures(text) {
  const pct = text.endsWith('%'), v = parseFloat(text.replace(/[,%]/g, ''));
  const dec = ((text.replace(/[,%]/g, '').split('.')[1]) || '').length;
  const commas = text.includes(',');
  let c;
  if (!pct && !dec && v >= 1000 && v <= 2099 && !commas) c = shuffle([-30, -20, -12, -7, -4, 3, 6, 11, 18, 25]).map(d => v + d);
  else if (pct) c = shuffle([v / 2, v * 1.5, v + 15, v - 15, v + 25, 100 - v, v - 25].map(Math.round));
  else if (!dec && v <= 12) c = shuffle([v + 1, v - 1, v + 2, v + 3, v * 2, v - 2, v + 4]);
  else c = shuffle([v * 2, v / 2, v * 1.5, v * 0.75, v * 3, v * 1.25]).map(x => (dec ? +x.toFixed(dec) : Math.round(x)));
  const fmt = x => (dec ? x.toFixed(dec) : commas ? Math.round(x).toLocaleString('en-US') : String(Math.round(x))) + (pct ? '%' : '');
  const out = [...new Set(c.filter(x => x > 0 && Math.abs(x - v) > 1e-9 && (!pct || x <= 100)).map(fmt))].filter(x => x !== text);
  return out.length >= 3 ? out.slice(0, 3) : null;
}

const NUMWORDS = 'zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen twenty'.split(' ');
const optDef = d => clip(capFirst(stripEnd(d)), 120);
// the 3 others closest to this one by some measure (length, word count)
const closest = (list, me, by) => {
  const out = [], seen = new Set([norm(by === 'term' ? me.term : me.def)]);
  const k = x => (by === 'term' ? x.term.split(' ').length * 20 + x.term.length : x.def.length);
  for (const x of [...list].sort((a, b) => Math.abs(k(a) - k(me)) - Math.abs(k(b) - k(me)))) {
    const key = norm(by === 'term' ? x.term : x.def);
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(x);
    if (out.length === 3) break;
  }
  return out;
};

function defCard(d, A, turn) {
  const others = A.defs.filter(x => norm(x.term) !== norm(d.term) && norm(x.def) !== norm(d.def));
  let masked = d.def;
  for (const t of [d.term, d.alias].filter(Boolean)) masked = masked.replace(wordRe(t), '$1___');
  const which = `Which term means “${clip(stripEnd(masked), 200)}”?`;
  const accept = [d.alias, A.acrMap.get(d.term.toLowerCase())].filter(Boolean);
  if (others.length >= 3 && turn % 2 === 0) {
    const ls = closest(others, d, 'def');
    if (ls.length === 3) return { type: 'mc', q: `What does “${d.term}” mean?`, options: [optDef(d.def), ...ls.map(x => optDef(x.def))], answer: 0, source: d.source };
  }
  if (others.length >= 3) {
    const ls = closest(others, d, 'term');
    if (ls.length === 3) return { type: 'mc', q: which, options: [d.term, ...ls.map(x => x.term)].map(capFirst), answer: 0, source: d.source };
  }
  return { type: 'short', q: which, answer: d.term, accept, source: d.source };
}

function acrCard(a, A) {
  const others = [...new Map(A.acrs.filter(x => x.acr !== a.acr && norm(x.full) !== norm(a.full)).map(x => [norm(x.full), x])).values()];
  const q = `What does “${a.acr}” stand for?`;
  if (others.length >= 3) {
    const n = a.full.split(' ').length;
    const ls = others.sort((x, y) => Math.abs(x.full.split(' ').length - n) - Math.abs(y.full.split(' ').length - n)).slice(0, 3);
    return { type: 'mc', q, options: [a.full, ...ls.map(x => x.full)], answer: 0, source: a.source };
  }
  return { type: 'short', q, answer: a.full, accept: [], source: a.source };
}

function clozeCard(s, b, A, turn) {
  const q = s.text.replace(wordRe(b.text), '$1_____');
  if (!q.includes('_____')) return null;
  if (turn % 3 !== 2) {
    const ls = b.kind === 'num' ? numberLures(b.text) : lures(b, A.pool, ` ${norm(q.replace(/_____/g, ' '))} `);
    if (ls) return { type: 'mc', q, options: [b.display, ...ls], answer: 0, source: s.text };
  }
  const accept = [];
  const v = Number(b.text);
  if (b.kind === 'num' && Number.isInteger(v) && v >= 0 && v <= 20) accept.push(NUMWORDS[v]);
  const other = A.acrMap.get(b.lo);
  if (other) accept.push(other);
  return { type: 'short', q, answer: b.display, accept, source: s.text };
}

// Up to `max` practice questions from notes and files, in the order the notes go. Cards the deck already has (`avoid`)
// aren't made again, so "More questions" finds new ones.
export function makeCards(text, { max = 12, avoid = [] } = {}) {
  const A = analyze(text);
  const avoidA = new Set(avoid.map(c => norm(answerText(c))));
  const avoidS = new Set(avoid.map(c => norm(c.source || '')).filter(Boolean));
  const items = [];
  for (const d of A.defs) items.push({ kind: 'def', score: d.from === 'line' ? 9 : 7.5, pos: d.pos, ans: d.term, src: d.source, d });
  for (const a of A.acrs) items.push({ kind: 'acr', score: 7, pos: a.pos, ans: a.full, src: a.source, a });
  // (a sentence that defines a term makes a definition question instead)
  for (const s of A.sents) if (!s.def) for (const c of s.cands) items.push({ kind: 'cloze', score: 2 + Math.min(8, c.score), pos: s.pos, ans: c.text, src: s.text, s, c });
  items.sort((x, y) => y.score - x.score || x.pos - y.pos);
  const usedA = new Set(), usedS = new Set(), chosen = [];
  for (const it of items) {
    const ka = norm(it.ans), ks = norm(it.src);
    if (!ka || usedA.has(ka) || avoidA.has(ka) || usedS.has(ks) || avoidS.has(ks)) continue;
    usedA.add(ka);
    usedS.add(ks);
    chosen.push(it);
    if (chosen.length >= max) break;
  }
  chosen.sort((x, y) => x.pos - y.pos);
  let defTurn = 0, clozeTurn = 0;
  const cards = [];
  for (const it of chosen) {
    const card = it.kind === 'def' ? defCard(it.d, A, defTurn++) : it.kind === 'acr' ? acrCard(it.a, A) : clozeCard(it.s, it.c, A, clozeTurn++);
    if (card) cards.push(card);
  }
  return cards;
}

// ---------------------------------------------------------------- Teach Wick without Claude
// An idea from the deck counts as explained when what you wrote names it and says something about it, or covers at
// least half of its key words (not counting the deck's own name, which anyone would say).
export function coversIdea(idea, text) {
  const words = norm(idea).split(' ').filter(w => w.length > 2 && !STOP.has(w));
  if (!words.length) return false;
  const t = ` ${norm(text)} `;
  const hit = words.filter(w => t.includes(` ${w}`) || (w.length >= 6 && t.includes(w.slice(0, w.length - 2))));
  return hit.length / words.length >= (words.length <= 2 ? 1 : 0.6);
}
const cardText = c => `${c.q.replace(/_{3,}/g, ' ')} ${answerText(c)} ${c.source || ''}`;
// what a card is about: the term in "What does “X” mean?", otherwise its answer
const subjectOf = c => { const m = c.q.match(/^What does “(.+?)” (?:mean|stand for)\?$/); return m ? m[1] : answerText(c); };
function ideaText(c) {
  const a = answerText(c);
  if (c.source && c.source.length <= 170) return c.source;
  if (c.q.includes('_____')) return c.q.replace(/_{5}/g, a);
  return `${c.q} ${a}`;
}
function keyWords(text, skip) {
  const out = new Map();
  for (const w of contentWords(text)) { const s = stem(w); if (!skip.has(s) && !VAGUE.has(w) && !out.has(s)) out.set(s, w); }
  return [...out].map(([s, word]) => ({ stem: s, word }));
}
// the ideas Wick asks about: up to 4 different cards (about `concept`, when you pick what to explain)
export function teachIdeas(cards, { concept = '', skip = '', n = 4 } = {}) {
  const skipStems = new Set(contentWords(`${skip} ${concept}`).map(stem));
  let pool;
  if (concept.trim()) {
    const want = new Set(contentWords(concept).map(stem));
    pool = cards.map(c => [c, new Set(contentWords(cardText(c)).map(stem))]).map(([c, st]) => [c, [...want].filter(w => st.has(w)).length])
      .filter(x => x[1] > 0).sort((a, b) => b[1] - a[1]).map(x => x[0]);
  } else pool = shuffle([...cards]);
  const seen = new Set(), out = [];
  for (const c of pool) {
    const a = norm(subjectOf(c));
    if (seen.has(a)) continue;
    seen.add(a);
    out.push(ideaFrom({ text: ideaText(c), card: c, answer: subjectOf(c) }, skipStems));
    if (out.length >= n) break;
  }
  return out;
}
// (also for Claude's ideas, when Wick has to carry on without him)
export function ideaFrom(idea, skipStems = new Set()) {
  const c = idea.card;
  return { ...idea, keys: keyWords(c ? `${answerText(c)} ${c.source || c.q}` : idea.text, skipStems) };
}
// did what you wrote name this answer? every one of its words (one may be missing from a long name), so "long-term
// memory" doesn't count as naming "long-term potentiation"
const nameWords = s => (String(s).toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').match(/[a-z0-9][a-z0-9'’-]*/g) || [])
  .flatMap(w => w.split('-')).filter(w => w.length >= 2 && !STOP.has(w));
function names(answer, said) {
  const want = [...new Set(nameWords(answer).map(stem))];
  if (!want.length) return !!norm(answer) && ` ${norm(said)} `.includes(` ${norm(answer)} `);
  const have = new Set(nameWords(said).map(stem));
  const hit = want.filter(w => have.has(w)).length;
  return hit === want.length || (want.length > 3 && hit >= want.length - 1);
}
export function explainCheck(ideas, said) {
  const saidStems = new Set(contentWords(said).map(stem)), heard = [];
  const covered = ideas.map(idea => {
    const named = !!idea.answer && names(idea.answer, said);
    const ansStems = new Set(nameWords(idea.answer || '').map(stem).concat(contentWords(idea.answer || '').map(stem)));
    const others = idea.keys.filter(k => !ansStems.has(k.stem)), hit = others.filter(k => saidStems.has(k.stem));
    const all = idea.keys.filter(k => saidStems.has(k.stem));
    if (named) heard.push(idea.answer);
    heard.push(...all.filter(k => !/(ing|ed)$/.test(k.word) && !ansStems.has(k.stem)).map(k => k.word));
    // named it and said something about it, or explained it without the name (at least half its key words)
    return named ? others.length < 2 || hit.length >= 1 : idea.keys.length >= 2 && all.length >= Math.max(2, Math.ceil(idea.keys.length * 0.5));
  });
  // (what Wick heard, without repeats: "long-term" is part of "long-term memory")
  const uniq = [...new Map(heard.map(h => [h.toLowerCase(), h])).values()];
  return { covered, heard: uniq.filter(h => !uniq.some(o => o !== h && o.toLowerCase().includes(h.toLowerCase()))).slice(0, 4) };
}
export const listWords = a => (a.length <= 1 ? a.join('') : `${a.slice(0, -1).join(', ')} and ${a[a.length - 1]}`);

// ---------------------------------------------------------------- Unstuck without Claude
// What kind of problem it is, from its words, so the hints fit: code, math and science, writing, reading, or anything.
const SUBJECTS = {
  code: [/\b(code|coding|program|programming|function|method|class|object|variable|loop|while|array|list|dict|dictionary|string|int|boolean|return|returns|print|compile|compiler|error|exception|bug|debug|syntax|recursion|recursive|algorithm|big-?o|runtime|python|java|javascript|typescript|c\+\+|racket|scheme|html|css|sql|git|api|null|undefined|stack|queue|pointer|struct|lambda|def|void|public|static|import|terminal|test case|unit test|index|indexerror|typeerror|segfault)\b|[{};]\s*$|=>|\w\(\)|==|!=|\+\+/gim, 1.3],
  math: [/\b(solve|equation|equations|formula|derivative|integral|limit|graph|slope|matrix|vector|probability|statistics|mean|median|variance|standard deviation|proof|prove|theorem|lemma|calculate|compute|evaluate|simplify|factor|polynomial|quadratic|logarithm|log|exponent|sin|cos|tan|angle|triangle|area|volume|velocity|acceleration|force|mass|energy|momentum|charge|current|voltage|circuit|mole|moles|molar|reaction|equilibrium|acid|base|ph|enthalpy|entropy|concentration|units|kg|newton|joules?|grams|liters?|percent|ratio|fraction|decimal)\b|\d+\s*[-+*/^=×÷]\s*\d+|[=≤≥∑∫√π]|\b[xyn]\s*[=^]/gim, 1.1],
  writing: [/\b(essay|thesis|paragraphs?|argument|argue|arguing|claim|evidence|counterargument|introduction|conclusion|draft|outline|cite|citations?|mla|apa|sources?|word count|prompt|reflection|reflect|persuasive|rhetorical|rhetoric|analysis|analyze|discuss|response paper|memo|report|personal statement|cover letter|write|writing)\b/gim, 1],
  reading: [/\b(reading|read|chapter|passage|author|article|poem|poet|novel|story|narrator|characters?|themes?|plot|setting|symbol|symbolism|metaphor|tone|summarize|summary|main idea|quote|quotation|text|book|excerpt|stanza)\b/gim, 1],
};
export function guessSubject(text) {
  let best = 'general', top = 1.9;
  for (const [name, [re, w]] of Object.entries(SUBJECTS)) {
    const n = (String(text).match(re) || []).length * w;
    if (n > top) { best = name; top = n; }
  }
  return best;
}
export const SUBJECT_NAMES = { code: 'coding', math: 'math and science', writing: 'writing', reading: 'reading', general: '' };
// four hints from a nudge up, the last one always about asking a person
export const LADDERS = {
  code: [
    'Write the goal as one plain sentence: “Given ___, it should give back ___.” Then work out one tiny example by hand, like a list of 3 things. What should come out?',
    'Turn your hand-worked example into steps and write them as comments first (# 1. … # 2. …). Then turn one comment at a time into code, and run it after each one.',
    'If it runs but gives the wrong answer, print what each variable holds at every step of your tiny example. The first line where a value isn’t what you expected is your bug. If it crashes, read the last line of the error and the line number it points to.',
    'Still stuck? Write down the input you tried, what you expected, what you got, and the few lines of code for that part. Send that to your TA, a classmate or office hours: it’s the fastest kind of question to answer.',
  ],
  math: [
    'List what you’re given, with units, and circle exactly what you need to find. Is the answer a number, an expression, a proof or a yes/no?',
    'Which formula, rule or theorem from this unit connects what you have to what you need? Check the chapter’s key equations for one that has your unknown in it.',
    'Try a simpler version first: easier numbers, a special case (like x = 0 or 1), or a quick sketch. Do the same steps on the real problem, then check that your answer’s units and size make sense.',
    'Find a worked example in your notes or textbook that uses the same idea and follow it step by step next to your problem. Still stuck? Bring your work to office hours or your TA: they can spot the exact step that went wrong.',
  ],
  writing: [
    'Rewrite the prompt as a question in your own words. Your thesis is your one-sentence answer to it, even a rough one.',
    'Make a quick outline: your claim, two or three reasons, and one piece of evidence for each (a quote, a fact or an example). Bullet points are fine.',
    'Set a 10-minute timer and write the messiest draft you can, or say your argument out loud and type what you said. Fixing a rough draft is far easier than writing a perfect first one.',
    'Take your thesis and outline to the writing center, your TA or office hours and ask: “Does this answer the prompt?” That one question can save you hours.',
  ],
  reading: [
    'What is the question really asking for: the main idea, the author’s purpose, a detail or a comparison? Underline its key words.',
    'Skim the title, the headings, and the first and last paragraphs. Then find the part of the reading that talks about your question’s key words.',
    'Sum up that part in two sentences of your own, then answer the question from your summary. Quote one line that backs up your answer.',
    'Still unsure? Compare your two-sentence summary with a classmate’s, or bring it to your TA or office hours.',
  ],
  general: [
    'Read the question out loud, slowly, and underline exactly what it asks for. What’s the very first thing you’d need to know?',
    'Find a worked example in your notes, slides or textbook that looks like this problem. Which of its steps match yours?',
    'Write down what you know and what you need. Then do only the first step, even if you’re not sure it’s right: a wrong first try still shows you the way.',
    'Still stuck after 10 minutes? Write the exact spot you’re stuck on as one question and send it to a classmate, your TA or office hours. Then move on to the next problem and come back.',
  ],
};
// cards from your decks that share the problem's words: the facts you've already practiced that might help
export function relatedCards(cards, text, n = 3) {
  const want = new Set(contentWords(text).map(stem));
  if (!want.size) return [];
  return cards.map(c => {
    const st = new Set(contentWords(cardText(c)).map(stem));
    return [c, [...st].filter(s => want.has(s)).reduce((sum, s) => sum + (s.length >= 6 ? 1.5 : 1), 0)];
  }).filter(x => x[1] >= 2).sort((a, b) => b[1] - a[1]).slice(0, n).map(x => x[0]);
}
