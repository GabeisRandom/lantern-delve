// Reading homework files without Claude, for the Study tab's offline mode: plain text (and HTML), Word, PowerPoint and
// OpenDocument files, and the words in most PDFs. The files come from /api/files/raw (the copy for friends answers that
// from the browser's own storage). Pictures need Claude, so they're skipped.
// Zip files (Office, OpenDocument) and compressed PDF streams are unpacked with the browser's DecompressionStream.

const MAX_CHARS = 60000;

export function canRead(name) {
  return /\.(txt|md|markdown|text|csv|tsv|html?|docx|pptx|odt|odp|pdf)$/i.test(String(name));
}

// The text of one of an assignment's files ('' when it can't be read here).
export async function fileText(file) {
  if (!canRead(file.name)) return '';
  try {
    const r = await fetch(`/api/files/raw?id=${encodeURIComponent(file.id)}`, { headers: { 'X-Lantern': 'app' } });
    if (!r.ok) return '';
    return (await bytesText(new Uint8Array(await r.arrayBuffer()), file.name)).slice(0, MAX_CHARS);
  } catch (e) {
    return '';
  }
}

export async function bytesText(bytes, name) {
  const ext = String(name).toLowerCase().split('.').pop();
  if (['txt', 'md', 'markdown', 'text', 'csv', 'tsv'].includes(ext)) return new TextDecoder().decode(bytes);
  if (ext === 'html' || ext === 'htm') return xmlText(new TextDecoder().decode(bytes).replace(/<(script|style)[\s\S]*?<\/\1>/gi, ''), /<\/(p|div|li|h\d|tr|br)\s*>|<br\s*\/?>/gi);
  if (['docx', 'pptx', 'odt', 'odp'].includes(ext)) return officeText(bytes, ext);
  if (ext === 'pdf') return pdfText(bytes);
  return '';
}

// ---------------------------------------------------------------- helpers
const decodeEntities = s => s.replace(/&(#x[0-9a-f]+|#\d+|amp|lt|gt|quot|apos|nbsp);/gi, (m, e) => {
  const k = e.toLowerCase();
  if (k[0] === '#') { const n = k[1] === 'x' ? parseInt(k.slice(2), 16) : parseInt(k.slice(1), 10); return n ? String.fromCodePoint(n) : ''; }
  return { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' }[k];
});
function xmlText(xml, breaks) {
  return decodeEntities(xml.replace(breaks, '\n').replace(/<[^>]+>/g, '')).replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}
async function inflate(bytes, format) {
  const out = new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream(format)));
  return new Uint8Array(await out.arrayBuffer());
}
function latin1(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return s;
}

// ---------------------------------------------------------------- zip (Word, PowerPoint, OpenDocument)
function zipEntries(buf) {
  const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) return [];
  const count = dv.getUint16(eocd + 10, true), out = [];
  let p = dv.getUint32(eocd + 16, true);
  for (let n = 0; n < count && p + 46 <= buf.length && dv.getUint32(p, true) === 0x02014b50; n++) {
    const nlen = dv.getUint16(p + 28, true), elen = dv.getUint16(p + 30, true), clen = dv.getUint16(p + 32, true);
    out.push({ name: new TextDecoder().decode(buf.subarray(p + 46, p + 46 + nlen)), method: dv.getUint16(p + 10, true),
      csize: dv.getUint32(p + 20, true), usize: dv.getUint32(p + 24, true), at: dv.getUint32(p + 42, true) });
    p += 46 + nlen + elen + clen;
  }
  return out;
}
async function zipRead(buf, e) {
  const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  if (e.usize > 30 * 1024 * 1024 || dv.getUint32(e.at, true) !== 0x04034b50) return null;
  const start = e.at + 30 + dv.getUint16(e.at + 26, true) + dv.getUint16(e.at + 28, true);
  const data = buf.subarray(start, start + e.csize);
  if (e.method === 0) return data;
  if (e.method === 8) return inflate(data, 'deflate-raw');
  return null;
}
async function officeText(buf, ext) {
  const entries = zipEntries(buf), get = async e => { const b = e && await zipRead(buf, e); return b ? new TextDecoder().decode(b) : ''; };
  if (ext === 'docx') {
    const xml = await get(entries.find(e => e.name === 'word/document.xml'));
    return xmlText(xml.replace(/<w:tab\/>/g, '\t').replace(/<w:br\/>/g, '\n'), /<\/w:p>/g);
  }
  if (ext === 'pptx') {
    const slides = entries.filter(e => /^ppt\/slides\/slide\d+\.xml$/.test(e.name))
      .sort((a, b) => Number(a.name.match(/(\d+)\.xml$/)[1]) - Number(b.name.match(/(\d+)\.xml$/)[1]));
    const out = [];
    for (const s of slides) out.push(xmlText(await get(s), /<\/a:p>/g));
    return out.filter(Boolean).join('\n\n');
  }
  return xmlText(await get(entries.find(e => e.name === 'content.xml')), /<\/text:(p|h)>/g);   // OpenDocument
}

// ---------------------------------------------------------------- PDF
// Best effort: the objects (including ones packed into object streams), Flate-compressed streams, each font's
// ToUnicode map, and the text-showing operators in every page's content, in order.
async function pdfText(buf) {
  const src = latin1(buf), objs = new Map();
  const reObj = /(\d+)\s+(\d+)\s+obj\b/g;
  let m;
  while ((m = reObj.exec(src))) {
    const num = Number(m[1]), start = reObj.lastIndex;
    let dictEnd = src.indexOf('stream', start), endobj = src.indexOf('endobj', start);
    if (endobj < 0) break;
    const o = { dict: '', raw: null };
    if (dictEnd >= 0 && dictEnd < endobj) {
      o.dict = src.slice(start, dictEnd);
      let ds = dictEnd + 6;
      if (src[ds] === '\r') ds++;
      if (src[ds] === '\n') ds++;
      const len = o.dict.match(/\/Length\s+(\d+)(?!\s+\d+\s+R)/);
      let de = len ? ds + Number(len[1]) : src.indexOf('endstream', ds);
      if (len && !/^\s*endstream/.test(src.slice(de, de + 20))) de = src.indexOf('endstream', ds);
      if (de < 0) break;
      o.raw = buf.subarray(ds, de);
      endobj = src.indexOf('endobj', de);
      if (endobj < 0) endobj = src.length;
    } else o.dict = src.slice(start, endobj);
    objs.set(num, o);
    reObj.lastIndex = endobj + 6;
  }
  const decoded = new Map();
  const data = async num => {
    if (decoded.has(num)) return decoded.get(num);
    const o = objs.get(num);
    let s = '';
    if (o && o.raw) {
      const filter = (o.dict.match(/\/Filter\s*(\[[^\]]*\]|\/\w+)/) || [])[1] || '';
      try {
        if (!filter) s = latin1(o.raw);
        else if (/^\[?\s*\/FlateDecode\s*\]?$/.test(filter)) s = latin1(await inflate(o.raw, 'deflate'));
      } catch (e) { s = ''; }
    }
    decoded.set(num, s);
    return s;
  };
  // objects packed inside object streams
  for (const [num, o] of [...objs]) {
    if (!/\/Type\s*\/ObjStm/.test(o.dict)) continue;
    const s = await data(num), first = Number((o.dict.match(/\/First\s+(\d+)/) || [])[1] || 0);
    const head = s.slice(0, first).trim().split(/\s+/).map(Number);
    for (let i = 0; i + 1 < head.length; i += 2) {
      const from = first + head[i + 1], to = i + 3 < head.length ? first + head[i + 3] : s.length;
      if (!objs.has(head[i])) objs.set(head[i], { dict: s.slice(from, to), raw: null });
    }
  }
  const ref = (dict, key) => { const r = dict.match(new RegExp(`/${key}\\s+(\\d+)\\s+\\d+\\s+R`)); return r ? Number(r[1]) : null; };
  const dictOf = num => (objs.get(num) || { dict: '' }).dict;
  // an array in a dictionary ("/W [ … ]", nested brackets and all), written there or in another object
  const arrayOf = (dict, key) => {
    const m = dict.match(new RegExp(`/${key}\\s*(\\[|(\\d+)\\s+\\d+\\s+R)`));
    if (!m) return null;
    let s = dict, i = m.index + m[0].length - 1;
    if (m[2]) { s = dictOf(Number(m[2])); i = s.indexOf('['); if (i < 0) return null; }
    let depth = 0;
    for (let j = i; j < s.length; j++) {
      if (s[j] === '[') depth++;
      else if (s[j] === ']' && --depth === 0) return s.slice(i + 1, j);
    }
    return null;
  };
  // Each font: how its character codes become text (its ToUnicode map), how many bytes a code takes, and how wide
  // each glyph is (to tell a space between words from letters placed one at a time).
  const fontCache = new Map();
  const fontOf = async fontNum => {
    if (fontCache.has(fontNum)) return fontCache.get(fontNum);
    const d = dictOf(fontNum), tu = ref(d, 'ToUnicode');
    const cmap = tu != null ? parseCMap(await data(tu)) : null;
    const type0 = /\/Subtype\s*\/Type0/.test(d);
    const f = { map: cmap ? cmap.map : null, bytes: type0 ? 2 : cmap ? cmap.width : 1, widths: new Map(), dw: type0 ? 1000 : 500 };
    if (type0) {
      const desc = arrayOf(d, 'DescendantFonts');
      const dn = desc && desc.match(/(\d+)\s+\d+\s+R/);
      const dd = dn ? dictOf(Number(dn[1])) : '';
      const dw = dd.match(/\/DW\s+(\d+)/);
      if (dw) f.dw = Number(dw[1]);
      const w = arrayOf(dd, 'W');
      if (w) parseW(w, f.widths);
    } else {
      const first = Number((d.match(/\/FirstChar\s+(\d+)/) || [])[1] || 0), ws = arrayOf(d, 'Widths');
      if (ws) ws.trim().split(/\s+/).map(Number).forEach((w, i) => { if (!Number.isNaN(w)) f.widths.set(first + i, w); });
      const fd = ref(d, 'FontDescriptor'), mw = fd != null && dictOf(fd).match(/\/MissingWidth\s+(\d+)/);
      if (mw) f.dw = Number(mw[1]);
    }
    fontCache.set(fontNum, f);
    return f;
  };
  // a page's (or form's) fonts and the text of the forms it draws
  const resourcesOf = (d, up = 0) => {
    if (/\/Resources\s*<</.test(d)) return d.slice(d.search(/\/Resources\s*<</));
    if (ref(d, 'Resources') != null) return dictOf(ref(d, 'Resources'));
    return up < 8 && ref(d, 'Parent') != null ? resourcesOf(dictOf(ref(d, 'Parent')), up + 1) : '';   // (inherited from the page tree)
  };
  const subDict = (res, key) => {
    const r = ref(res, key);
    if (r != null) return dictOf(r);
    const at = res.search(new RegExp(`/${key}\\s*<<`));
    if (at < 0) return '';
    let depth = 0;
    for (let j = res.indexOf('<<', at); j < res.length - 1; j++) {
      if (res[j] === '<' && res[j + 1] === '<') { depth++; j++; } else if (res[j] === '>' && res[j + 1] === '>') { if (--depth === 0) return res.slice(res.indexOf('<<', at) + 2, j); j++; }
    }
    return '';
  };
  const textOf = async (d, streams, depth = 0, parentFonts = null) => {
    const res = resourcesOf(d), forms = new Map();
    let fonts = new Map();
    for (const f of subDict(res, 'Font').matchAll(/\/([^\s/<>[\]()]+)\s+(\d+)\s+\d+\s+R/g)) fonts.set(f[1], await fontOf(Number(f[2])));
    if (!fonts.size && parentFonts) fonts = parentFonts;      // (a form without its own resources uses the page's)
    if (depth < 3) {
      for (const x of subDict(res, 'XObject').matchAll(/\/([^\s/<>[\]()]+)\s+(\d+)\s+\d+\s+R/g)) {
        const xd = dictOf(Number(x[2]));
        if (/\/Subtype\s*\/Form/.test(xd)) forms.set(x[1], await textOf(xd, [Number(x[2])], depth + 1, fonts));
      }
    }
    let text = '';
    for (const c of streams) text += contentText(await data(c), fonts, forms);
    return text;
  };
  // the pages, in order (following /Kids from the catalog's /Pages), else every page object found
  let pages = [];
  const walk = (num, seen = new Set()) => {
    if (seen.has(num)) return;
    seen.add(num);
    const d = dictOf(num);
    if (/\/Type\s*\/Pages\b/.test(d)) { for (const k of (d.match(/\/Kids\s*\[([^\]]*)\]/) || ['', ''])[1].matchAll(/(\d+)\s+\d+\s+R/g)) walk(Number(k[1]), seen); }
    else if (/\/Type\s*\/Page\b/.test(d)) pages.push(num);
  };
  for (const [num, o] of objs) if (/\/Type\s*\/Catalog/.test(o.dict)) { const p = ref(o.dict, 'Pages'); if (p != null) walk(p); }
  if (!pages.length) pages = [...objs.keys()].filter(n => /\/Type\s*\/Page\b/.test(dictOf(n)));
  const out = [];
  let total = 0;
  for (const pg of pages.slice(0, 300)) {
    const d = dictOf(pg);
    const contents = d.match(/\/Contents\s*\[([^\]]*)\]/) ? [...d.match(/\/Contents\s*\[([^\]]*)\]/)[1].matchAll(/(\d+)\s+\d+\s+R/g)].map(x => Number(x[1]))
      : [ref(d, 'Contents')].filter(x => x != null);
    const text = await textOf(d, contents);
    out.push(text);
    total += text.length;
    if (total > MAX_CHARS) break;
  }
  return out.join('\n\n').replace(/[ \t]+/g, ' ').replace(/ *\n */g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}

// A CID font's glyph widths: "c [w1 w2 …]" (codes from c on) and "c1 c2 w" (every code from c1 to c2).
function parseW(s, map) {
  const t = s.match(/\[|\]|-?\d+(?:\.\d+)?/g) || [];
  for (let i = 0; i < t.length;) {
    const c = Number(t[i++]);
    if (Number.isNaN(c)) continue;
    if (t[i] === '[') {
      i++;
      for (let k = 0; i < t.length && t[i] !== ']'; k++) map.set(c + k, Number(t[i++]));
      i++;
    } else if (i + 1 < t.length) {
      const c2 = Number(t[i++]), w = Number(t[i++]);
      for (let code = c; code <= Math.min(c2, c + 20000); code++) map.set(code, w);
    } else break;
  }
}

// A ToUnicode CMap: character codes (1 or 2 bytes) to text.
function parseCMap(s) {
  if (!s || !/begincmap|beginbf/.test(s)) return null;
  const map = new Map(), utf16 = h => { let t = ''; for (let i = 0; i + 4 <= h.length; i += 4) t += String.fromCharCode(parseInt(h.slice(i, i + 4), 16)); return t; };
  let width = 1;
  const cs = s.match(/begincodespacerange\s*<([0-9a-fA-F]+)>/);
  if (cs) width = Math.max(1, cs[1].length / 2);
  for (const block of s.matchAll(/beginbfchar([\s\S]*?)endbfchar/g)) {
    for (const p of block[1].matchAll(/<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]*)>/g)) { map.set(parseInt(p[1], 16), utf16(p[2])); if (!cs) width = Math.max(width, p[1].length / 2); }
  }
  for (const block of s.matchAll(/beginbfrange([\s\S]*?)endbfrange/g)) {
    for (const p of block[1].matchAll(/<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>\s*(\[[^\]]*\]|<[0-9a-fA-F]*>)/g)) {
      const lo = parseInt(p[1], 16), hi = Math.min(parseInt(p[2], 16), lo + 5000);
      if (!cs) width = Math.max(width, p[1].length / 2);
      if (p[3][0] === '[') {
        const list = [...p[3].matchAll(/<([0-9a-fA-F]*)>/g)].map(x => utf16(x[1]));
        list.forEach((t, i) => map.set(lo + i, t));
      } else {
        const base = utf16(p[3].slice(1, -1));
        for (let code = lo; code <= hi; code++) {
          const last = base.charCodeAt(base.length - 1) + (code - lo);
          map.set(code, base.slice(0, -1) + String.fromCharCode(last));
        }
      }
    }
  }
  return map.size ? { map, width } : null;
}

const WIN = { 0x91: '‘', 0x92: '’', 0x93: '“', 0x94: '”', 0x95: '•', 0x96: '–', 0x97: '—', 0x85: '…' };
// (a matrix times a matrix: [a b c d e f], as PDF writes them)
const mul = (m, k) => [m[0] * k[0] + m[1] * k[2], m[0] * k[1] + m[1] * k[3], m[2] * k[0] + m[3] * k[2], m[2] * k[1] + m[3] * k[3],
  m[4] * k[0] + m[5] * k[2] + k[4], m[4] * k[1] + m[5] * k[3] + k[5]];

// The text in one content stream (and the forms it draws), in reading order. Each run of text goes where the text and
// page matrices put it: a jump down starts a new line (a big jump, a new paragraph), and a gap wider than a narrow space
// between two runs on one line is a space. That tells words apart in PDFs that place letters one at a time (like ones
// printed from a browser or Google Docs), without splitting words where kerning nudges two letters closer.
function contentText(s, fonts, forms) {
  let out = '', i = 0, font = null, size = 1, tc = 0, tw = 0, th = 1, tl = 0, prev = null;
  let tm = [1, 0, 0, 1, 0, 0], tlm = tm.slice(), ctm = tm.slice();
  const saved = [], stack = [], n = s.length;
  const nums = k => stack.slice(-k).map(Number);
  const at = () => { const m = mul(tm, ctm); return { x: m[4], y: m[5], fs: Math.abs(size) * Math.hypot(m[2], m[3]) || 1, dir: Math.sign(m[0]) || 1 }; };
  const place = () => {
    if (!prev) return;
    const p = at(), fs = Math.max(p.fs, prev.fs), dy = Math.abs(p.y - prev.y);
    if (dy > 0.5 * fs) { out = out.replace(/ +$/, '') + (dy > 1.8 * fs ? '\n\n' : '\n'); return; }
    const dx = (p.x - prev.x) * p.dir;
    if (dx < -2 * fs) out += '\n';                                    // (back to the left on the same line: another column)
    else if (dx > 0.15 * fs && !/\s$/.test(out)) out += ' ';
  };
  const move = adv => { tm[4] += adv * tm[0]; tm[5] += adv * tm[1]; };
  const show = bytes => {
    const f = font ? fonts.get(font) : null, nb = f ? f.bytes : 1;
    place();
    for (let k = 0; k + nb <= bytes.length; k += nb) {
      let code = 0;
      for (let b = 0; b < nb; b++) code = (code << 8) | bytes[k + b];
      out += f && f.map ? (f.map.get(code) ?? '') : nb === 1 ? (WIN[code] || (code >= 32 || code === 9 ? String.fromCharCode(code) : '')) : '';
      const w = f ? (f.widths.get(code) ?? f.dw) : 500;
      move(((w / 1000) * size + tc + (nb === 1 && code === 32 ? tw : 0)) * th);
    }
    prev = at();
  };
  const newLine = (tx, ty) => { tlm = mul([1, 0, 0, 1, tx, ty], tlm); tm = tlm.slice(); };
  while (i < n) {
    const ch = s[i];
    if (ch === '(') {                                   // a literal string, with escapes and nested parentheses
      const bytes = [];
      let depth = 1;
      i++;
      while (i < n && depth) {
        let c = s[i++];
        if (c === '\\') {
          const e = s[i++];
          if (/[0-7]/.test(e)) { let oct = e; while (oct.length < 3 && /[0-7]/.test(s[i])) oct += s[i++]; bytes.push(parseInt(oct, 8) & 255); continue; }
          if (e === '\r' || e === '\n') { if (e === '\r' && s[i] === '\n') i++; continue; }
          bytes.push(({ n: 10, r: 13, t: 9, b: 8, f: 12 })[e] ?? e.charCodeAt(0));
          continue;
        }
        if (c === '(') depth++;
        else if (c === ')' && --depth === 0) break;
        bytes.push(c.charCodeAt(0) & 255);
      }
      stack.push({ str: bytes });
    } else if (ch === '<' && s[i + 1] !== '<') {        // a hex string
      const end = s.indexOf('>', i);
      const hex = s.slice(i + 1, end < 0 ? n : end).replace(/\s+/g, '');
      const bytes = [];
      for (let k = 0; k < hex.length; k += 2) bytes.push(parseInt((hex.slice(k, k + 2) + '0').slice(0, 2), 16));
      stack.push({ str: bytes });
      i = end < 0 ? n : end + 1;
    } else if (ch === '[') { stack.push('['); i++; }
    else if (ch === ']') {
      const arr = [];
      while (stack.length && stack[stack.length - 1] !== '[') arr.unshift(stack.pop());
      stack.pop();
      stack.push({ arr });
      i++;
    } else if (ch === '/') {
      let j = i + 1;
      while (j < n && !/[\s/[\]()<>{}%]/.test(s[j])) j++;
      stack.push({ name: s.slice(i + 1, j) });
      i = j;
    } else if (ch === '%') { while (i < n && s[i] !== '\n' && s[i] !== '\r') i++; }
    else if (/\s/.test(ch)) i++;
    else {
      let j = i;
      while (j < n && !/[\s/[\]()<>{}%]/.test(s[j])) j++;
      const tok = s.slice(i, j);
      i = j === i ? i + 1 : j;
      if (/^[+-]?(\d+\.?\d*|\.\d+)$/.test(tok)) { stack.push(Number(tok)); continue; }
      const last = () => Number(stack[stack.length - 1]) || 0;
      switch (tok) {
        case 'BT': tm = [1, 0, 0, 1, 0, 0]; tlm = tm.slice(); break;
        case 'Tf': { const nm = stack.filter(x => x && x.name).pop(); if (nm) font = nm.name; if (typeof stack[stack.length - 1] === 'number') size = last(); break; }
        case 'Tc': tc = last(); break;
        case 'Tw': tw = last(); break;
        case 'Tz': th = (last() || 100) / 100; break;
        case 'TL': tl = last(); break;
        case 'Td': case 'TD': { const [tx, ty] = nums(2); if (tok === 'TD') tl = -ty || 0; newLine(tx || 0, ty || 0); break; }
        case 'T*': newLine(0, -tl); break;
        case 'Tm': { const m = nums(6); if (m.length === 6 && m.every(Number.isFinite)) { tm = m; tlm = m.slice(); } break; }
        case 'cm': { const m = nums(6); if (m.length === 6 && m.every(Number.isFinite)) ctm = mul(m, ctm); break; }
        case 'q': saved.push(ctm.slice()); break;
        case 'Q': if (saved.length) ctm = saved.pop(); break;
        case 'Tj': case "'": case '"': {
          const st = stack.filter(x => x && x.str).pop();
          if (tok === '"') { const ns = stack.filter(x => typeof x === 'number'); if (ns.length >= 2) { tw = ns[0]; tc = ns[1]; } }
          if (tok !== 'Tj') newLine(0, -tl);
          if (st) show(st.str);
          break;
        }
        case 'TJ': {
          const a = stack.filter(x => x && x.arr).pop();
          if (a) for (const el of a.arr) { if (el && el.str) show(el.str); else if (typeof el === 'number') move((-el / 1000) * size * th); }
          break;
        }
        case 'Do': {                                     // a form: its text goes here, as its own lines
          const nm = stack.filter(x => x && x.name).pop(), t = nm && forms && forms.get(nm.name);
          if (t && t.trim()) { out += `\n${t.trim()}\n`; prev = null; }
          break;
        }
        default: break;
      }
      stack.length = 0;
    }
  }
  return out + '\n';
}
