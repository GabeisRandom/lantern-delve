"""Lantern Delve v2: a homework focus companion + a paper-style RPG.

Double-click "Start Lantern Delve.bat" (or run this file with Python). It starts a
small local server, opens the game in Edge "app" windows, and while a focus
session runs it watches which window is in front and how long you've been idle.
Focus earns Light; Light fuels the adventure. Distractions cost Light.
"""
import collections
import ctypes
import ctypes.wintypes as wt
import datetime
import glob
import hashlib
import hmac
import html as htmllib
import http.server
import io
import json
import os
import queue
import random
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

HERE = os.path.dirname(os.path.abspath(__file__))
WEB_DIR = os.path.join(HERE, "web")
SAVE_PATH = os.environ.get("LANTERN_SAVE") or os.path.join(HERE, "save.json")
FILES_DIR = os.path.join(os.path.dirname(os.path.abspath(SAVE_PATH)), "homework files")   # (next to the save)
OLD_SAVE_PATH = os.path.join(HERE, "old_version", "lantern_delve_save.json")
PROFILE_DIR = os.path.join(HERE, ".browser-profile")
DEFAULT_PORT = int(os.environ.get("LANTERN_PORT") or 47615)
MAIN_TITLE = "Lantern Delve"
COMP_TITLE = "Lantern Delve Companion"
OWN_PID = os.getpid()
NO_WINDOW = 0x08000000
NEW_CONSOLE = 0x00000010

# ---------------------------------------------------------------- tuning
LIGHT_PER_MIN = 1.0          # base Light per focused minute (x1..x2 combo on top)
COMBO_FULL_SECONDS = 2400    # combo reaches x2 after 40 focused minutes
BREAK_EARN_RATIO = 0.25      # 1 minute of break banked per 4 focused minutes
BREAK_BANK_START = 300
BREAK_BANK_MAX = 1800
BLOCK_GRACE = 10             # seconds to leave a blocked app before penalties
BLOCK_GRACE_REPEAT = 5
BLOCK_PENALTY = 2            # Light lost every BLOCK_PENALTY_EVERY seconds
BLOCK_PENALTY_EVERY = 10
MINIMIZE_AFTER = 45
PASS_SECONDS = 300           # "good reason" pass length
MAX_EXCUSES = 2              # reasons you can try for one alert before the excuse box closes
OFFTASK_GRACE = 20
HUB_GRACE = 60
PAPER_CHECKIN = 600          # paper mode: "still writing?" this long after the last answer
STEP_BONUS = 5
QUEST_BONUS = 25
CLEAN_BONUS = 10
DAY_COUNTS_AT = 900          # 15 focused minutes keeps the streak alive
# Study cards (the Study tab): days until a card comes back, by its box (how well you know it: a right answer moves
# it up one, a wrong one back to 0), and the Light that studying can earn
STUDY_INTERVALS = [0, 1, 3, 7, 16, 35]
STUDY_DAY_CAP = 30           # most Light a day from study battles
STUDY_WIN_LIGHT = 3          # finishing a battle with 4+ due cards answered right

# ---------------------------------------------------------------- Win32
user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
WNDENUMPROC = ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)
user32.EnumWindows.argtypes = [WNDENUMPROC, wt.LPARAM]
user32.GetForegroundWindow.restype = wt.HWND
user32.GetWindowTextLengthW.argtypes = [wt.HWND]
user32.GetWindowTextW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
user32.GetWindowThreadProcessId.argtypes = [wt.HWND, ctypes.POINTER(wt.DWORD)]
user32.IsWindowVisible.argtypes = [wt.HWND]
user32.IsWindow.argtypes = [wt.HWND]
user32.IsIconic.argtypes = [wt.HWND]
user32.IsZoomed.argtypes = [wt.HWND]
user32.ShowWindow.argtypes = [wt.HWND, ctypes.c_int]
user32.SetForegroundWindow.argtypes = [wt.HWND]
user32.SetWindowPos.argtypes = [wt.HWND, wt.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wt.UINT]
user32.GetWindowRect.argtypes = [wt.HWND, ctypes.POINTER(wt.RECT)]
user32.PostMessageW.argtypes = [wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM]
user32.SystemParametersInfoW.argtypes = [wt.UINT, wt.UINT, ctypes.c_void_p, wt.UINT]
user32.keybd_event.argtypes = [wt.BYTE, wt.BYTE, wt.DWORD, ctypes.c_size_t]
kernel32.OpenProcess.restype = wt.HANDLE
kernel32.OpenProcess.argtypes = [wt.DWORD, wt.BOOL, wt.DWORD]
kernel32.QueryFullProcessImageNameW.argtypes = [wt.HANDLE, wt.DWORD, wt.LPWSTR, ctypes.POINTER(wt.DWORD)]
kernel32.CloseHandle.argtypes = [wt.HANDLE]
kernel32.WaitForSingleObject.argtypes = [wt.HANDLE, wt.DWORD]
kernel32.WaitForSingleObject.restype = wt.DWORD
kernel32.GetTickCount.restype = wt.DWORD
HWND_TOPMOST = wt.HWND(-1)
SWP_NOACTIVATE, SWP_SHOWWINDOW = 0x10, 0x40
SW_SHOWNOACTIVATE, SW_SHOWMINNOACTIVE = 4, 7   # un-minimize / minimize without moving the keyboard focus
TUCK_AFTER = 6               # seconds the buddy stays up after an alert before going back to the taskbar
BUDDY_STALE = 15             # seconds without a check-in from the buddy page (while its window is up) = it's stuck
DARK_AFTER = 5               # seconds a window can be up without drawing a frame before it counts as black
REUSE_ICONIC = 45            # an alert brings back a buddy minimized for less than this; longer, and a fresh one opens


class LASTINPUTINFO(ctypes.Structure):
    _fields_ = [("cbSize", wt.UINT), ("dwTime", wt.DWORD)]


user32.GetLastInputInfo.argtypes = [ctypes.POINTER(LASTINPUTINFO)]
user32.GetCursorPos.argtypes = [ctypes.POINTER(wt.POINT)]
Fg = collections.namedtuple("Fg", "hwnd title exe path pid")


def window_title(hwnd):
    n = user32.GetWindowTextLengthW(hwnd)
    if n <= 0:
        return ""
    buf = ctypes.create_unicode_buffer(n + 1)
    user32.GetWindowTextW(hwnd, buf, n + 1)
    return buf.value


def window_pid(hwnd):
    pid = wt.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return pid.value


def process_path(pid):
    h = kernel32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return ""
    try:
        size = wt.DWORD(1024)
        buf = ctypes.create_unicode_buffer(1024)
        if kernel32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
            return buf.value
        return ""
    finally:
        kernel32.CloseHandle(h)


def foreground():
    hwnd = user32.GetForegroundWindow()
    if not hwnd:
        return Fg(0, "", "", "", 0)
    pid = window_pid(hwnd)
    path = process_path(pid)
    return Fg(hwnd, window_title(hwnd), os.path.basename(path).lower(), path.lower(), pid)


class ActivityWatch:
    """Tells real work (typing, clicking, scrolling, actually moving the mouse) apart from a stray nudge.

    Windows only says *when* the last input happened, so this samples that 4 times a second together with
    the pointer position: input that didn't move the pointer was a key, a click or a scroll, while pointer
    travel only counts once it adds up to a deliberate move. Fidgeting with the mouse doesn't count as work.
    """
    TRAVEL = 250   # pixels of pointer travel within a couple of seconds

    def __init__(self):
        self.last = time.time()
        self.prev = None
        self.travel = 0.0

    def start(self):
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        while True:
            try:
                self.sample()
            except Exception:
                pass
            time.sleep(0.25)

    def sample(self):
        lii = LASTINPUTINFO()
        lii.cbSize = ctypes.sizeof(lii)
        pt = wt.POINT()
        if not user32.GetLastInputInfo(ctypes.byref(lii)) or not user32.GetCursorPos(ctypes.byref(pt)):
            return
        now = time.time()
        if self.prev and lii.dwTime != self.prev[0]:
            moved = abs(pt.x - self.prev[1]) + abs(pt.y - self.prev[2])
            if moved <= 2:
                self.last = now   # input that didn't move the pointer: typing, clicking or scrolling
            else:
                self.travel += moved
        self.travel *= 0.9        # only recent travel counts
        if self.travel > self.TRAVEL:
            self.last = now
            self.travel = 0.0
        self.prev = (lii.dwTime, pt.x, pt.y)

    def idle(self):
        return time.time() - self.last


ACTIVITY = ActivityWatch()


def find_window(title):
    found = find_windows(title, 1)
    return found[0] if found else None


def find_windows(title, limit=10):
    found = []

    def cb(hwnd, _):
        if user32.IsWindowVisible(hwnd) and window_title(hwnd) == title:
            found.append(hwnd)
            return len(found) < limit
        return True
    user32.EnumWindows(WNDENUMPROC(cb), 0)
    return found


def work_area():
    r = wt.RECT()
    user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(r), 0)  # SPI_GETWORKAREA
    return r.left, r.top, r.right, r.bottom


def dpi_scale():
    try:
        return user32.GetDpiForSystem() / 96.0
    except Exception:
        return 1.0


def window_scale(hwnd):
    """Display scaling of the monitor a window is on (monitors can differ from the system setting)."""
    try:
        dpi = user32.GetDpiForWindow(wt.HWND(hwnd))
        if dpi:
            return dpi / 96.0
    except Exception:
        pass
    return dpi_scale()


def window_rect(hwnd):
    r = wt.RECT()
    if user32.GetWindowRect(hwnd, ctypes.byref(r)):
        return r.left, r.top, r.right - r.left, r.bottom - r.top
    return None


def place_topmost(hwnd, x, y, w, h):
    user32.SetWindowPos(hwnd, HWND_TOPMOST, int(x), int(y), int(w), int(h), SWP_NOACTIVATE | SWP_SHOWWINDOW)


def bring_to_front(hwnd):
    if user32.IsIconic(hwnd):
        user32.ShowWindow(hwnd, 9)  # SW_RESTORE
    user32.keybd_event(0x12, 0, 0, 0)  # tap Alt so Windows allows the focus change
    user32.keybd_event(0x12, 0, 2, 0)
    user32.SetForegroundWindow(hwnd)


def wait_exit(pids, timeout):
    """Wait (up to timeout seconds in all) for these processes to end."""
    end = time.time() + timeout
    for pid in pids:
        h = kernel32.OpenProcess(0x00100000, False, pid)  # SYNCHRONIZE
        if h:
            try:
                kernel32.WaitForSingleObject(h, max(0, int((end - time.time()) * 1000)))
            finally:
                kernel32.CloseHandle(h)


def minimize(hwnd):
    user32.ShowWindow(hwnd, 6)  # SW_MINIMIZE


def close_window(hwnd):
    user32.PostMessageW(hwnd, 0x0010, 0, 0)  # WM_CLOSE


try:
    dwmapi = ctypes.WinDLL("dwmapi")
except OSError:
    dwmapi = None


def cloaked(hwnd):
    """True for a window Windows keeps out of sight without minimizing it, like one on another virtual desktop."""
    if not dwmapi:
        return False
    val = ctypes.c_int(0)
    try:
        return dwmapi.DwmGetWindowAttribute(wt.HWND(hwnd), 14, ctypes.byref(val), ctypes.sizeof(val)) == 0 and val.value != 0
    except Exception:
        return False


# Edge without graphics acceleration: drawing in software is a little slower, but it always shows. Turned on (and
# remembered in settings.safe_render) when a fresh window came up black too, which means Edge's graphics got stuck.
SAFE_RENDER = [False]


def find_browser():
    for p in [r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
              r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
              os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),
              r"C:\Program Files\Google\Chrome\Application\chrome.exe",
              os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe")]:
        if os.path.exists(p):
            return p
    return None


BROWSER = find_browser()


def open_app_window(url, w, h, x, y):
    if not BROWSER:
        import webbrowser
        webbrowser.open(url)
        return
    # CalculateNativeWinOcclusion off (and no backgrounding): Edge stops painting a window it thinks is covered, and
    # it kept thinking that about the study buddy even after the buddy was made always-on-top over the main window,
    # so the buddy sometimes came up as a blank grey window. A hidden-desktop test showed 0 frames painted in exactly
    # that case with the old flags, and normal painting with these. (Flags only count when Edge itself starts.)
    # Edge's sleeping tabs and efficiency mode are off too (the ms* features, found in msedge.dll): they freeze pages
    # nobody has clicked in a while, and this profile's stats showed Edge freezing our pages. The buddy can sit there
    # for hours untouched, and a frozen buddy is a grey one. (Game.buddy_stale replaces one that gets stuck anyway.)
    subprocess.Popen([BROWSER, f"--app={url}", f"--user-data-dir={PROFILE_DIR}", "--no-first-run",
                      "--no-default-browser-check", "--disable-sync", "--autoplay-policy=no-user-gesture-required",
                      "--disable-features=msEdgeSidebarV2,msHubApps,TranslateUI,msImplicitSignin,CalculateNativeWinOcclusion,"
                      "msAutomaticTabFreeze,msEnableAutomaticTabFreeze,msEfficiencyModeV2,msFreezeOnMemoryPressure,"
                      "msDiscardExpiredTabs,msEdgeGlobalFrameRateThrottling,msPauseAnimationInEfficiencyMode,"
                      "msEdgeSyncEfficiencyModeWithWindowsEnergySaver,IntensiveWakeUpThrottling",
                      "--disable-backgrounding-occluded-windows", "--disable-renderer-backgrounding",
                      *(["--disable-gpu"] if SAFE_RENDER[0] else []),
                      f"--window-size={int(w)},{int(h)}", f"--window-position={int(x)},{int(y)}"],
                     creationflags=NO_WINDOW)


def pythonw_path():
    alias = os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\WindowsApps\pythonw.exe")
    if os.path.exists(alias):
        return alias  # stays valid when Python updates
    cand = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    return cand if os.path.exists(cand) else sys.executable


def install_shortcuts(desktop=True):
    """Start menu shortcut (kept pointing here) and, the first time, a Desktop shortcut."""
    ps = ("$sh = New-Object -ComObject WScript.Shell;"
          "$paths = @(Join-Path ([Environment]::GetFolderPath('Programs')) 'Lantern Delve.lnk');"
          "if ($env:LD_DESKTOP -eq '1') { $paths += Join-Path ([Environment]::GetFolderPath('Desktop')) 'Lantern Delve.lnk' };"
          "foreach ($p in $paths) { $s = $sh.CreateShortcut($p); $s.TargetPath = $env:LD_TARGET; $s.Arguments = $env:LD_ARGS;"
          "$s.WorkingDirectory = $env:LD_WD; $s.IconLocation = $env:LD_ICON; $s.Description = 'Lantern Delve: homework focus + adventure';"
          "$s.Save() }")
    env = dict(os.environ, LD_DESKTOP="1" if desktop else "0", LD_TARGET=pythonw_path(),
               LD_ARGS=f'"{os.path.join(HERE, "lantern_delve.py")}"', LD_WD=HERE,
               LD_ICON=os.path.join(WEB_DIR, "icon.ico"))
    try:
        subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], env=env,
                       creationflags=NO_WINDOW, timeout=60, capture_output=True)
        return True
    except Exception as e:
        print("shortcut creation failed:", e)
        return False


# ---------------------------------------------------------------- what counts as distracting
BROWSER_EXES = {"chrome.exe", "msedge.exe", "firefox.exe", "brave.exe", "opera.exe", "vivaldi.exe", "arc.exe"}
NEUTRAL_EXES = {"explorer.exe", "searchhost.exe", "startmenuexperiencehost.exe", "shellexperiencehost.exe",
                "lockapp.exe", "taskmgr.exe", "applicationframehost.exe_", "systemsettings.exe", "snippingtool.exe",
                "screenclippinghost.exe", "textinputhost.exe"}
BLOCK_WORDS = {  # matched as whole words in the window title (YouTube videos are judged one by one instead: see youtube_video)
    "youtube music": "YouTube Music", "tiktok": "TikTok", "reddit": "Reddit", "instagram": "Instagram",
    "facebook": "Facebook", "twitter": "Twitter/X", "x.com": "X", "snapchat": "Snapchat",
    "pinterest": "Pinterest", "tumblr": "Tumblr", "threads.net": "Threads", "bluesky": "Bluesky",
    "bsky": "Bluesky", "mastodon": "Mastodon", "linkedin": "LinkedIn", "discord": "Discord",
    "whatsapp": "WhatsApp", "9gag": "9GAG", "imgur": "Imgur", "twitch.tv": "Twitch", "kick.com": "Kick",
    "bereal": "BeReal", "netflix": "Netflix", "hulu": "Hulu", "disney+": "Disney+", "prime video": "Prime Video",
    "crunchyroll": "Crunchyroll", "hbo max": "HBO Max", "peacock tv": "Peacock", "paramount+": "Paramount+",
    "tubi": "Tubi", "pluto tv": "Pluto TV", "poki": "Poki", "coolmath": "Coolmath Games",
    "crazygames": "CrazyGames", "miniclip": "Miniclip", "chess.com": "Chess.com", "lichess": "Lichess",
    "wordle": "Wordle", "geoguessr": "GeoGuessr", "agar.io": "Agar.io", "slither.io": "Slither.io",
    "itch.io": "itch.io", "roblox": "Roblox", "minecraft": "Minecraft", "fortnite": "Fortnite",
    "valorant": "Valorant", "league of legends": "League of Legends", "genshin": "Genshin Impact",
    "steam community": "Steam", "steampowered": "Steam", "epic games": "Epic Games", "friv": "Friv",
    "kongregate": "Kongregate", "cookie clicker": "Cookie Clicker", "neal.fun": "neal.fun",
}
BLOCK_PATTERNS = [  # for names that are also normal English words
    (re.compile(r"(^|\s)/ x$"), "X"), (re.compile(r"\bon x: "), "X"), (re.compile(r"• threads$"), "Threads"),
    (re.compile(r"(^|\s-\s)twitch$"), "Twitch"), (re.compile(r"^(facebook )?messenger( \||$)"), "Messenger"),
    (re.compile(r"^telegram( web)?$"), "Telegram"), (re.compile(r"^(on )?steam$|(^|\s)on steam$"), "Steam"),
]
BLOCK_EXES = {
    "discord.exe": "Discord", "steam.exe": "Steam", "steamwebhelper.exe": "Steam", "epicgameslauncher.exe": "Epic Games",
    "battle.net.exe": "Battle.net", "riotclientux.exe": "Riot Client", "riotclientservices.exe": "Riot Client",
    "leagueclient.exe": "League of Legends", "leagueclientux.exe": "League of Legends",
    "robloxplayerbeta.exe": "Roblox", "minecraft.windows.exe": "Minecraft", "minecraftlauncher.exe": "Minecraft",
    "eadesktop.exe": "EA app", "ubisoftconnect.exe": "Ubisoft Connect", "galaxyclient.exe": "GOG Galaxy",
    "whatsapp.exe": "WhatsApp", "whatsapp.root.exe": "WhatsApp", "telegram.exe": "Telegram",
    "messenger.exe": "Messenger", "xboxpcapp.exe": "Xbox app", "tiktok.exe": "TikTok", "instagram.exe": "Instagram",
}
GAME_DIRS = ["\\steamapps\\", "\\epic games\\", "\\riot games\\", "\\roblox\\", "\\xboxgames\\", "\\gog galaxy\\games\\",
             "\\ea games\\", "\\ubisoft game launcher\\games\\", "\\battle.net\\", "\\minecraft"]
WORK_EXES = {"winword.exe", "excel.exe", "powerpnt.exe", "onenote.exe", "acrobat.exe", "acrord32.exe", "notepad.exe",
             "notepad++.exe", "code.exe", "devenv.exe", "pycharm64.exe", "idea64.exe", "rstudio.exe", "matlab.exe",
             "mathematica.exe", "sumatrapdf.exe", "zotero.exe", "obsidian.exe", "notion.exe", "windowsterminal.exe",
             "wolfram.exe", "spyder.exe", "texstudio.exe", "texworks.exe", "anki.exe", "goodnotes.exe"}
WORK_WORDS = ["google docs", "google sheets", "google slides", "canvas", "blackboard", "northeastern", "overleaf",
              "desmos", "gradescope", "piazza", "webassign", "zybooks", "pearson", "mastering", "mcgraw", "connect",
              "khan academy", "quizlet", "wolframalpha", "wolfram|alpha", "jstor", "google scholar"]
_ZW = dict.fromkeys(map(ord, "\u200b\u200c\u200d\ufeff"), None)
_SUFFIX = re.compile(r"\s+[-\u2013\u2014|]\s+(google chrome|microsoft edge|mozilla firefox|brave|opera|vivaldi|arc)$")


def word_re(word):
    return re.compile(r"(?<![a-z0-9])" + re.escape(word) + r"(?![a-z0-9])")


BLOCK_RES = [(word_re(w), label) for w, label in BLOCK_WORDS.items()]
WORK_RES = [word_re(w) for w in WORK_WORDS]


def norm_title(title):
    t = title.translate(_ZW).strip().lower()
    for _ in range(3):
        m = _SUFFIX.search(t)
        if not m:
            break
        t = t[:m.start()]
    t = re.sub(r"\s+-\s+(personal|work|school|profile \d+|guest|default)$", "", t)
    t = re.sub(r"\s+and \d+ more pages?$", "", t)
    t = re.sub(r"^\(\d+\+?\)\s*", "", t)
    return t.strip()


def blocked_label(fg, extra_words):
    if fg.exe in BLOCK_EXES:
        return BLOCK_EXES[fg.exe]
    if any(d in fg.path for d in GAME_DIRS):
        return "a game"
    t = norm_title(fg.title)
    if not t:
        return None
    for rx, label in BLOCK_RES:
        if rx.search(t):
            return label
    for rx, label in BLOCK_PATTERNS:
        if rx.search(t):
            return label
    for w in extra_words:
        w = w.strip().lower()
        if w and word_re(w).search(t):
            return w
    return None


_YT = re.compile(r"^(.*?)\s*[-–—|]\s*youtube$")
_SHORTS = re.compile(r"#shorts\b|(^|\s)shorts$")


def youtube_video(fg):
    """For YouTube in a browser: the video's title, or '' on YouTube's own pages (home, Shorts, subscriptions), which
    are never schoolwork. None when it isn't YouTube."""
    if fg.exe not in BROWSER_EXES:
        return None
    t = norm_title(fg.title)
    if t == "youtube":
        return ""
    m = _YT.match(t)
    if not m:
        return None
    video = m.group(1).strip()
    return "" if not video or _SHORTS.search(video) else video


# ---------------------------------------------------------------- judging without Claude
# When Claude isn't connected, a plain word check stands in. It's stricter than Claude: a video or an excuse has to
# clearly be about schoolwork (or share words with the assignment) to count.
STOP_WORDS = set("""the and for with that this from your you are was were have has had not but all any can our out
about into over what when where which while who why how will just like get got make made more most some such than then
them they their there these those very also only even much many each other video videos official full part episode
live watch youtube need needed using""".split())
EDU_RE = re.compile(
    r"\b(lectures?|lessons?|tutorials?|courses?|class|classes|explained|explanation|introduction|intro to|crash course|"
    r"khan academy|professor|chapter|unit \d+|review|exam|midterm|final exam|practice problems?|worked examples?|"
    r"solutions?|study guide|how to (solve|calculate|write|cite|prove|derive|find|code|program)|calculus|algebra|"
    r"geometry|trigonometry|statistics|probability|physics|chemistry|biology|anatomy|economics|psychology|sociology|"
    r"philosophy|grammar|essay|thesis|citations?|programming|python|java|javascript|c\+\+|sql|data structures?|"
    r"algorithms?|linear algebra|differential equations?|organic chemistry|opencourseware|ocw|3blue1brown|"
    r"organic chemistry tutor|professor leonard|study group|homework|hw help|lab report|chem|orgo|bio|calc|stats|"
    r"(cs|math|chem|bio|phys|econ|engw|psyc) ?\d{3,4})\b")
NOT_EDU_RE = re.compile(
    r"\b(funny|memes?|pranks?|reaction videos?|reacts? to|reacting to|first time (hearing|watching)|vlogs?|unboxing|"
    r"trailer|gameplay|let'?s play|speedrun|minecraft|fortnite|roblox|music video|official (music )?video|lyrics?|"
    r"asmr|mukbang|compilation|tiktoks?|highlights|podcast|livestream|try not to laugh|lofi|beats to|movies?|film|"
    r"anime|tier list|top \d+|ranked|ranking|drama|gossip|celebrity)\b")
SCHOOL_RE = re.compile(
    r"\b(class|classes|course|lecture|professor|prof|teacher|ta|tutor|assignment|homework|hw|project|group ?chat|"
    r"groupmates?|teammates?|lab|exam|quiz|midterm|final|study|studying|research|notes|paper|essay|report|reading|"
    r"textbook|syllabus|canvas|deadline|due|tutorial|lesson|problem set|pset|presentation|slides|sources?|cite|"
    r"citations?)\b")
LAME_RE = re.compile(
    r"\b(bored|boring|break|relax|relaxing|chill|fun|quick|quickly|one sec|a sec|a minute|real quick|just checking|"
    r"just looking|notifications|i want(ed)? to|because i can|idk|dunno|nothing|no reason|procrastinat\w*|tired|"
    r"music|songs?|memes?|funny|entertainment|scroll(ing)?|bored)\b")


def topic_words(text):
    return {w for w in re.findall(r"[a-z0-9+#]{4,}", (text or "").lower()) if w not in STOP_WORDS}


def quest_words(quest, step=None):
    return topic_words(f"{quest['title']} {quest.get('details', '')} {step or ''}") if quest else set()


def local_video_verdict(quest, step, video):
    """Is this YouTube video plausibly schoolwork (or, in a habit's session, part of the habit)? Same shape as
    Claude's answer."""
    t = video.lower()
    if quest and quest.get("habit"):             # a habit: the video has to share words with it
        if topic_words(t) & quest_words(quest):
            return {"verdict": "on_task", "reason": f"Looks like {quest['title']}."}
        return {"verdict": "off_task", "reason": f"I can't tell how that video is part of {quest['title']}."}
    if NOT_EDU_RE.search(t):
        return {"verdict": "off_task", "reason": "That video doesn't look like schoolwork."}
    if topic_words(t) & quest_words(quest, step) or EDU_RE.search(t):
        return {"verdict": "on_task", "reason": "Looks like a study video."}
    return {"verdict": "off_task", "reason": "I can't tell how that video is schoolwork."}


def local_excuse_verdict(quest, step, title, reason):
    """Does the reason really make this window schoolwork (or part of the habit)? Same shape as Claude's answer."""
    r, t = reason.lower(), norm_title(title)
    if quest and quest.get("habit"):
        words = quest_words(quest)
        if LAME_RE.search(r) and not (topic_words(r) & words):
            return {"verdict": "excuse", "reason": "That sounds like a break. Take a real break instead!"}
        if topic_words(t) & words:
            return {"verdict": "schoolwork", "reason": "That checks out."}
        return {"verdict": "excuse", "reason": f"The page itself doesn't look like {quest['title']}."}
    about_work = bool(topic_words(t) & quest_words(quest, step)) or bool(EDU_RE.search(t))
    if LAME_RE.search(r) and not SCHOOL_RE.search(r):
        return {"verdict": "excuse", "reason": "That sounds like a break, not schoolwork. Take a real break instead!"}
    if SCHOOL_RE.search(r) and about_work and not NOT_EDU_RE.search(t):
        return {"verdict": "schoolwork", "reason": "That checks out."}
    if not about_work:
        return {"verdict": "excuse", "reason": "The page itself doesn't look like schoolwork."}
    return {"verdict": "excuse", "reason": "I can't see how that's schoolwork."}


# ---------------------------------------------------------------- homework files (attached to assignments)
MAX_FILE = 50 * 1024 * 1024
RISKY_EXT = {".exe", ".bat", ".cmd", ".com", ".scr", ".msi", ".msp", ".ps1", ".psm1", ".vbs", ".vbe", ".js", ".jse",
             ".wsf", ".wsh", ".hta", ".lnk", ".url", ".reg", ".cpl", ".pif", ".jar", ".dll", ".appx", ".msix",
             ".appinstaller", ".application", ".gadget", ".inf", ".scf", ".iso", ".img", ".vhd", ".vhdx"}
TEXT_EXT = {".txt", ".md", ".csv", ".tsv", ".json", ".xml", ".yaml", ".yml", ".html", ".htm", ".css", ".tex", ".rtf",
            ".py", ".java", ".c", ".h", ".cpp", ".hpp", ".cs", ".js", ".ts", ".r", ".m", ".sql", ".ipynb", ".srt"}
CLAUDE_READS = {".pdf", ".png", ".jpg", ".jpeg", ".gif", ".webp"}   # Claude's Read tool opens these itself
RESERVED_NAMES = {"CON", "PRN", "AUX", "NUL"} | {f"{p}{i}" for p in ("COM", "LPT") for i in range(1, 10)}


def safe_name(name):
    """A file name Windows will take: no folders, no forbidden characters."""
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", os.path.basename(str(name).replace("\\", "/"))).strip(" .")
    stem, ext = os.path.splitext(name or "file")
    if stem.upper() in RESERVED_NAMES:
        stem = "_" + stem
    return (stem[:100] or "file") + ext[:12]


def unique_path(folder, name):
    stem, ext = os.path.splitext(name)
    path, n = os.path.join(folder, name), 2
    while os.path.exists(path):
        path, n = os.path.join(folder, f"{stem} ({n}){ext}"), n + 1
    return path


def file_text(path, limit=15000):
    """The words in a text, Word, PowerPoint or OpenDocument file ('' for anything else)."""
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext in TEXT_EXT:
            with open(path, "rb") as f:
                return f.read(limit * 4).decode("utf-8", "replace")[:limit]
        if ext in (".docx", ".pptx", ".odt", ".odp"):
            with zipfile.ZipFile(path) as z:
                names = z.namelist()
                if ext == ".pptx":
                    parts = sorted((n for n in names if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)),
                                   key=lambda n: int(re.search(r"(\d+)\.xml$", n).group(1)))
                else:
                    parts = [p for p in (["word/document.xml"] if ext == ".docx" else ["content.xml"]) if p in names]
                out = []
                for part in parts:
                    if z.getinfo(part).file_size > 20 * 1024 * 1024:
                        continue
                    xml = re.sub(r"</(w:p|a:p|text:p|text:h)>", "\n", z.read(part).decode("utf-8", "replace"))
                    out.append(htmllib.unescape(re.sub(r"<[^>]+>", "", xml)))
                return re.sub(r"\n{3,}", "\n\n", "\n".join(out)).strip()[:limit]
    except Exception:
        pass
    return ""


def open_file(path):
    """Open a homework file in its usual app. Programs and scripts are only shown in their folder (opening
    them would run them), and so is anything Windows has no app for."""
    if os.path.splitext(path)[1].lower() not in RISKY_EXT:
        try:
            os.startfile(path)
            return
        except OSError:
            pass
    subprocess.Popen(f'explorer /select,"{path}"')


def file_ids(files):
    """File ids from the UI's list (it sends {id, name, size} objects; plain ids work too)."""
    return [f.get("id") if isinstance(f, dict) else f for f in (files or [])][:30]


def valid_due(s):
    """A due date as the app keeps it, "YYYY-MM-DDTHH:MM" (local time), or None for no due date."""
    if not isinstance(s, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}", s):
        return None
    try:
        datetime.datetime.strptime(s, "%Y-%m-%dT%H:%M")
    except ValueError:
        return None
    return s


def clean_card(c):
    """A practice question as the Study tab keeps it, or None if it isn't usable. Multiple-choice ("mc") has its
    options and the index of the right one; short-answer ("short") has the answer and other ways to write it."""
    if not isinstance(c, dict):
        return None
    tidy = lambda s, n: " ".join(str(s if s is not None else "").split())[:n]
    q = tidy(c.get("q"), 300)
    if not q:
        return None
    card = {"type": "short", "q": q, "source": tidy(c.get("source"), 300)}
    if c.get("type") == "mc":
        opts = []
        for o in c.get("options") or []:
            o = tidy(o, 140)
            if o and o.lower() not in [x.lower() for x in opts]:
                opts.append(o)
        opts = opts[:4]
        ans = c.get("answer")
        if isinstance(ans, int) and not isinstance(ans, bool) and 0 <= ans < len(opts):
            idx = ans
        else:
            a = tidy(ans, 140)
            idx = next((i for i, o in enumerate(opts) if o.lower() == a.lower()), -1)
            if idx < 0 and a:                    # (the answer wasn't among the options: it takes the last one's place)
                if len(opts) >= 4:
                    opts[-1] = a
                else:
                    opts.append(a)
                idx = opts.index(a)
        if len(opts) < 2 or idx < 0:
            return None
        card.update(type="mc", options=opts, answer=idx)
        return card
    a = tidy(c.get("answer"), 140)
    if not a:
        return None
    acc = []
    for x in c.get("accept") or []:
        x = tidy(x, 140)
        if x and x.lower() != a.lower() and x.lower() not in [y.lower() for y in acc]:
            acc.append(x)
    card.update(answer=a, accept=acc[:8])
    return card


def clean_staging():
    """Forget uploads that never got attached to an assignment (after a day)."""
    root = os.path.join(FILES_DIR, "_new")
    try:
        for d in os.listdir(root):
            p = os.path.join(root, d)
            if time.time() - os.path.getmtime(p) > 86400:
                shutil.rmtree(p, ignore_errors=True)
    except OSError:
        pass


# ---------------------------------------------------------------- homework breakdown (built-in)
def template_steps(title, details):
    t = f"{title} {details}".lower()
    first = "Open everything you need (doc, assignment page, notes). Just open it, that's the whole step."
    if re.search(r"\blab\b", t):
        body = ["Read the lab instructions once", "List the sections the report needs",
                "Copy your data / results into the doc", "Make the table or graph",
                "Write the methods (what you did)", "Write the results (what happened)",
                "Write the discussion (why it happened)", "Check formatting and submit"]
    elif any(k in t for k in ("essay", "paper", "write", "report", "reflection", "response", "discussion", "post")):
        body = ["Read the assignment prompt once, slowly", "Paste the requirements / rubric at the top of your doc",
                "Write 3 messy bullet-point ideas (bad ideas allowed)", "Pick the idea you like most",
                "Write one sentence saying your main point", "Outline 3 sections, one line each",
                "Draft section 1 (ugly is fine)", "Draft section 2", "Draft section 3",
                "Write the intro and conclusion", "Read it once and fix anything that sounds weird",
                "Check it against the rubric, then submit"]
    elif any(k in t for k in ("exam", "test", "quiz", "study", "midterm", "final")):
        body = ["List the topics that will be on it", "Rate each topic: know it / kinda / no idea",
                "Pick one 'no idea' topic", "Skim your notes on that topic once", "Do 3 practice questions on it",
                "Pick the next weakest topic", "Skim notes + 3 practice questions",
                "Quiz yourself on everything without notes", "Write down what you still don't get"]
    elif any(k in t for k in ("project", "presentation", "slides", "poster")):
        body = ["Write one sentence describing the finished thing", "List the parts / slides",
                "Make an empty file with just the section titles", "Fill in the easiest part", "Fill in the next part",
                "Fill in the next part", "Add visuals and formatting", "Review it once (or practice once)", "Submit"]
    elif any(k in t for k in ("read", "chapter", "article", "pages")):
        body = ["Check how many pages it is", "Read only the headings and bold words", "Read the first section",
                "Write 1 sentence about what it said", "Read the next section", "Write 1 sentence about it",
                "Read the last section", "Write 3 key takeaways"]
    elif any(k in t for k in ("problem", "pset", "homework", "hw", "worksheet", "math", "exercise", "questions")):
        body = ["Read through all the problems (don't solve yet)", "Mark the easiest one", "Do the easiest problem",
                "Do the next problem", "Do the next problem", "Write down what you know about the hardest one",
                "Find an example in your notes for it", "Try the hard one", "Check answers and formatting", "Submit"]
    else:
        body = ["Read the instructions once", "Write one sentence about what 'done' looks like",
                "Do the first small piece", "Do the next small piece", "Do the next small piece",
                "Check it against the instructions", "Submit / turn it in"]
    return [first] + body


# ---------------------------------------------------------------- Claude (via the user's own Claude Code login)
class NotLoggedIn(Exception):
    pass


def find_claude():
    for p in [os.path.expandvars(r"%USERPROFILE%\.local\bin\claude.exe")]:
        if os.path.exists(p):
            return p
    cands = glob.glob(os.path.expandvars(r"%LOCALAPPDATA%\Claude-Data\claude_*\claude-code\*\*\claude.exe"))
    cands += glob.glob(os.path.expandvars(r"%APPDATA%\Claude\claude-code\*\*\claude.exe"))
    cands.sort(key=os.path.getmtime, reverse=True)
    return cands[0] if cands else None


def clean_env():
    # Don't inherit the desktop app's session variables; use the user's own CLI login.
    return {k: v for k, v in os.environ.items() if not re.match(r"(CLAUDE|ANTHROPIC)", k, re.I)}


_ONLINE = {"t": 0.0, "ok": True}


def online():
    """Whether Claude's servers can be reached (checked at most every 20 seconds). Offline, the Study tab works without
    Claude right away, instead of waiting for Claude Code to give up."""
    now = time.time()
    if now - _ONLINE["t"] < 20:
        return _ONLINE["ok"]
    try:
        socket.create_connection(("api.anthropic.com", 443), timeout=2.5).close()
        ok = True
    except OSError:
        ok = False
    _ONLINE.update(t=now, ok=ok)
    return ok


def study_ai_off(g):
    """None when Claude can work for the Study tab; else the answer that sends the tab to its offline way of doing it."""
    if g.ai.status != "ready":
        return {"ok": False, "no_ai": True}
    if not online():
        return {"ok": False, "no_ai": True, "offline": True}
    return None


JUDGE_SYSTEM = (
    "You are the focus checker in a homework app for a college student with ADHD and autism. "
    "Given their current assignment and the window they have open, decide if that window is plausibly "
    "being used for this assignment or for general schoolwork. Be lenient with research, notes, documents, "
    "school sites, PDFs, calculators, coding tools, file managers and messages with classmates about the work. "
    "Be strict with entertainment, social media, shopping, games, and videos unrelated to the subject. "
    "For a YouTube video, judge the video itself from its title: lectures, tutorials, explanations and worked problems "
    "on the assignment's subject (or real study skills) are on task; entertainment, music and lofi streams, gaming, "
    "vlogs, reactions, news, sports and anything off-topic are off task, even 'in the background'. "
    "If you can't tell, answer unsure. Keep the reason under 15 words and speak directly to the student."
)
EXCUSE_SYSTEM = (
    "You judge excuses in a homework focus app. The student has a window open that the app flagged (a blocked site "
    "like social media, video or games, or a page the focus checker judged off task) and typed a reason. Decide: "
    "'schoolwork' only if the window itself is actually being used for schoolwork right now (for example a lecture "
    "video for their class, a doc that only mentions the site's name, or the class group chat they must answer), "
    "otherwise 'excuse'. Vague reasons, 'quick breaks', 'just checking', music, 'it helps me focus' and anything the "
    "window's title doesn't back up are excuses. Be fair but skeptical. Reason under 15 words, spoken to the student."
)
BREAKDOWN_SYSTEM = (
    "You help a college student with ADHD and autism start and finish homework. Break the assignment into "
    "6 to 12 tiny, concrete steps, each doable in about 5 to 20 minutes. The first step must be almost "
    "trivially easy (for example: open the document and the assignment page). Use plain, specific action verbs. "
    "If files are attached (the assignment sheet, a rubric, slides, a photo of a worksheet), read them first and "
    "base the steps on what they actually ask for: name the real questions, parts or sections."
)
CARDS_SYSTEM = (
    "You write practice questions for a college student to quiz themself on their own class material (it's used "
    "for flashcard battles in a study app). Test the ideas that matter most: definitions, how and why things work, "
    "the steps of a method, and what the assignment expects them to know. Never ask trivia like page numbers, file "
    "names or who wrote the slides. Every question must be answerable from the material, or from standard intro "
    "course knowledge when the material is only a topic name. Use plain words. Multiple-choice options must all be "
    "plausible, with exactly one correct. Short answers are 1 to 4 words."
)
UNSTUCK_SYSTEM = (
    "You help a college student with ADHD who is stuck on a homework problem get moving again, without doing the "
    "problem for them. You give the smallest hint that gets them moving, and a bit more only when they ask. Never state "
    "the final answer, or an intermediate result that gives it away. Use plain, warm, encouraging words."
)
TEACH_SYSTEM = (
    "You are Wick, a friendly paper candle in a homework app, and you missed class. A college student explains ideas "
    "from their class to you in their own words (the Feynman technique). You judge like a kind, sharp tutor: you care "
    "whether they understand it, not whether they use the textbook's exact words. Talk in plain, warm, playful words."
)
# habits: a time goal for something the student chose (language learning, chess, reading...), not homework
HABIT_JUDGE_SYSTEM = (
    "You are the focus checker in a focus app for a college student with ADHD and autism. They are doing a habit they "
    "chose themself (for example an hour of language learning, chess practice, reading an ebook, or general work), and "
    "you see the window they have open. Decide if that window is plausibly being used for this habit, going by the "
    "habit's name and what they said counts. Be lenient with anything that fits it, even things that are entertainment "
    "elsewhere: chess sites and chess videos for a chess habit, shows, music and videos in the target language for "
    "language learning, an ebook or reader app for reading. Be strict with things that don't fit: social media feeds, "
    "unrelated videos, shopping, unrelated games. For a YouTube video, judge the video itself from its title. If you "
    "can't tell, answer unsure. Keep the reason under 15 words and speak directly to the student."
)
HABIT_EXCUSE_SYSTEM = (
    "You judge excuses in a focus app. The student is doing a habit they chose (like language learning, chess or "
    "reading) and has a window open that the app flagged (a blocked site, or a page the focus checker judged off task), "
    "and typed a reason. Answer 'schoolwork' only if the window itself is really being used for this habit right now "
    "(for example a Spanish show for Spanish practice, or a chess lesson for chess), otherwise 'excuse'. Vague reasons, "
    "'quick breaks', 'just checking' and anything the window's title doesn't back up are excuses. Be fair but skeptical. "
    "Reason under 15 words, spoken to the student."
)
HABIT_BONUS = 5                  # Light for reaching a habit's goal for the day
# sites a habit unlocks just by its name, besides any blocked site it names itself ("Netflix with Spanish subtitles")
HABIT_SITES = {"chess": {"Chess.com", "Lichess"}}


def clean_habit(h):
    """A habit as it's kept (its name, emoji, minutes a day, which weekdays, what counts), or None if it isn't usable.
    Weekdays are 0 = Monday ... 6 = Sunday."""
    if not isinstance(h, dict):
        return None
    title = " ".join(str(h.get("title") or "").split())[:80]
    if not title:
        return None
    try:
        goal = int(h.get("goal_min", 60))
    except (TypeError, ValueError):
        goal = 60
    days = set()
    for d in h.get("days") or []:
        try:
            if 0 <= int(d) <= 6:
                days.add(int(d))
        except (TypeError, ValueError):
            pass
    return {"title": title, "emoji": str(h.get("emoji") or "").strip()[:8] or "🔁", "goal_min": max(5, min(600, goal)),
            "days": sorted(days) or list(range(7)), "what": " ".join(str(h.get("what") or "").split())[:400],
            "paper": bool(h.get("paper")),         # (away from the keyboard: no "you haven't moved" checks)
            # "time": minutes a day, with focus sessions; "check": just checked off each day (the gym needs no session)
            "kind": "check" if h.get("kind") == "check" else "time"}


_LAST_ID = [0]


def new_id():
    """An id for a new assignment, habit or practice card that another device won't also pick, since devices sync
    (web/js/sync.js): the time in milliseconds, then two random digits."""
    i = max(int(time.time() * 1000) * 100 + random.randint(0, 99), _LAST_ID[0] + 1)
    _LAST_ID[0] = i
    return i


# parts of the save that stay on this device when syncing (web/js/sync.js): window allow-lists and Claude's
# verdicts are about this computer, and "sync" holds the sync settings themselves
SYNC_LOCAL = ("allow", "ai_cache", "sync", "version")
# what a focus session carries over to another device when it's handed off (Session.carry / apply_carry)
CARRY_KEYS = ("focus_s", "combo_s", "light_frac", "light_earned", "light_lost", "break_bank", "break_used",
              "distractions", "steps_done", "pledge", "mode")


def habit_streak(h, today=None):
    """Days in a row the habit's goal was met, counting only the days it's on. Today only adds to it (it isn't over)."""
    today = today or datetime.date.today()
    log, goal, days = h.get("log", {}), h["goal_min"] * 60, set(h["days"])
    made = h.get("made") or today.isoformat()
    n, d = 0, today
    for _ in range(400):
        key = d.isoformat()
        if key < made:
            break
        if d.weekday() in days:
            if log.get(key, 0) >= goal:
                n += 1
            elif d != today:
                break
        d -= datetime.timedelta(days=1)
    return n


def habit_unblocks(h):
    """Blocked sites and apps that are fine during this habit's sessions: the ones it names ("chess.com", "Netflix with
    Spanish subtitles", "Discord language exchange"), plus the ones its kind needs (a chess habit gets chess sites)."""
    text = f" {h['title']} {h.get('what', '')} ".lower()
    out = set()
    for w, label in BLOCK_WORDS.items():
        for cand in {w, w.split(".")[0], label.lower()}:
            if len(cand) >= 4 and word_re(cand).search(text):
                out.add(label)
    for word, labels in HABIT_SITES.items():
        if word_re(word).search(text):
            out |= labels
    return out


class AI:
    def __init__(self, game):
        self.game = game
        self.exe = find_claude()
        self.status = "missing" if not self.exe else "checking"
        self.detail = "" if self.exe else "Claude Code wasn't found on this PC."
        self.q = queue.Queue()
        self.inflight = set()
        self.cwd = os.path.join(tempfile.gettempdir(), "lantern-delve-ai")
        os.makedirs(self.cwd, exist_ok=True)
        threading.Thread(target=self.worker, daemon=True).start()
        threading.Thread(target=self.refresh_status, daemon=True).start()

    def ready(self):
        return self.status == "ready" and self.game.save["settings"].get("ai_checks", True)

    def refresh_status(self):
        self.exe = find_claude()
        if not self.exe:
            self.status, self.detail = "missing", "Claude Code wasn't found on this PC."
            return
        self.status = "checking"
        try:
            p = subprocess.run([self.exe, "auth", "status"], capture_output=True, text=True, encoding="utf-8",
                               timeout=30, env=clean_env(), cwd=self.cwd, creationflags=NO_WINDOW)
            info = json.loads(p.stdout)
            if info.get("loggedIn"):
                self.status, self.detail = "ready", f"Connected ({info.get('authMethod', 'Claude account')})."
            else:
                self.status, self.detail = "not_logged_in", "Click Connect and log in once with your Claude account."
        except Exception as e:
            self.status, self.detail = "error", f"Couldn't check Claude Code: {type(e).__name__}"

    def login(self):
        self.exe = find_claude()
        if not self.exe:
            return False
        script = os.path.join(self.cwd, "connect-claude.cmd")
        with open(script, "w", encoding="utf-8") as f:
            f.write("@echo off\r\n"
                    "echo Lantern Delve: connect your Claude account\r\n"
                    "echo.\r\n"
                    "echo Log in with your Claude account in the browser window that opens.\r\n"
                    "echo When it says you're logged in, come back here and close this window.\r\n"
                    "echo.\r\n"
                    f"\"{self.exe}\" auth login\r\n"
                    "echo.\r\n"
                    "pause\r\n")
        subprocess.Popen(["cmd", "/c", script], env=clean_env(), cwd=self.cwd, creationflags=NEW_CONSOLE)
        return True

    def run(self, system, prompt, schema, timeout=120, tools=None, effort="low"):
        args = [self.exe, "-p", "--system-prompt", system, "--tools", tools or "", "--output-format", "json",
                "--json-schema", json.dumps(schema), "--no-session-persistence", "--strict-mcp-config",
                "--disable-slash-commands", "--effort", effort]
        if tools:                                # (only reading files: here, inside its own working folder)
            args += ["--allowedTools", tools]
        p = subprocess.run(args, input=prompt, capture_output=True, text=True, encoding="utf-8", timeout=timeout,
                           env=clean_env(), cwd=self.cwd, creationflags=NO_WINDOW)
        try:
            out = json.loads(p.stdout.strip().splitlines()[-1])
        except Exception:
            raise RuntimeError((p.stderr or p.stdout or "no output")[:200])
        if out.get("is_error"):
            msg = str(out.get("result", ""))
            if "login" in msg.lower() or "logged in" in msg.lower():
                self.status, self.detail = "not_logged_in", "Click Connect and log in once with your Claude account."
                raise NotLoggedIn(msg)
            raise RuntimeError(msg[:200])
        data = out.get("structured_output")
        if data is None:
            m = re.search(r"\{.*\}", str(out.get("result", "")), re.S)
            data = json.loads(m.group(0)) if m else None
        if not isinstance(data, dict):
            raise RuntimeError("no structured answer")
        return data

    def judge_window(self, quest, step, exe, title, video=None):
        schema = {"type": "object", "additionalProperties": False, "required": ["verdict", "reason"],
                  "properties": {"verdict": {"type": "string", "enum": ["on_task", "off_task", "unsure"]},
                                 "reason": {"type": "string"}}}
        front = f"a YouTube video titled '{video}'" if video else f"app '{exe}', title '{title}'"
        if quest and quest.get("habit"):
            what = f"Habit: {quest['title']}\nWhat counts for it: {quest.get('details') or '(they did not say)'}"
            return self.run(HABIT_JUDGE_SYSTEM, f"{what}\n\nWindow in front: {front}.\nIs the student on task?", schema)
        names = ", ".join(f["name"] for f in (quest or {}).get("files", []))[:300]
        what = (f"Assignment: {quest['title']}\nDetails: {quest.get('details', '')[:800] or '(none)'}\n"
                + (f"Its files: {names}\n" if names else "")
                + f"Current step: {step or '(none)'}" if quest else "No specific assignment: general schoolwork.")
        prompt = f"{what}\n\nWindow in front: {front}.\nIs the student on task?"
        return self.run(JUDGE_SYSTEM, prompt, schema)

    def judge_excuse(self, quest, label, title, reason, flagged=None):
        schema = {"type": "object", "additionalProperties": False, "required": ["verdict", "reason"],
                  "properties": {"verdict": {"type": "string", "enum": ["schoolwork", "excuse"]},
                                 "reason": {"type": "string"}}}
        habit = bool(quest and quest.get("habit"))
        what = (f"Habit: {quest['title']}\nWhat counts for it: {quest.get('details') or '(they did not say)'}" if habit
                else f"Assignment: {quest['title']}\nDetails: {quest.get('details', '')[:600]}" if quest else "General schoolwork.")
        window = (f"Window the focus checker flagged as off task: title '{title}' (the checker said: {flagged})"
                  if flagged else f"Blocked window: {label}, title '{title}'")
        prompt = f"{what}\n\n{window}.\nStudent's reason: {reason}"
        return self.run(HABIT_EXCUSE_SYSTEM if habit else EXCUSE_SYSTEM, prompt, schema, timeout=60)

    def files_into(self, prompt, files):
        """Adds an assignment's files ((path, name) pairs) to a prompt. Text, Word and PowerPoint files go in as text;
        PDFs and pictures are copied into Claude's working folder for it to read itself. Returns (prompt, folder):
        the folder (or None) holds the copies, for Claude's Read tool, and gets deleted afterwards."""
        texts, reads, folder = [], [], None
        for path, name in files:
            text = file_text(path)
            if text.strip():
                texts.append(f"----- {name} -----\n{text}")
            elif os.path.splitext(name)[1].lower() in CLAUDE_READS:
                folder = folder or tempfile.mkdtemp(prefix="files-", dir=self.cwd)
                dest = unique_path(folder, safe_name(name))
                shutil.copyfile(path, dest)
                reads.append(dest)
            else:
                texts.append(f"----- {name} ----- (a file type that can't be read here)")
        if reads:
            prompt += ("\n\nThe assignment's files. Read every one with the Read tool before answering:\n"
                       + "\n".join(f"- {p}" for p in reads))
        if texts:
            prompt += "\n\nText from the attached files:\n\n" + "\n\n".join(texts)[:40000]
        return prompt, folder

    def breakdown(self, title, details, files=()):
        schema = {"type": "object", "additionalProperties": False, "required": ["steps"],
                  "properties": {"steps": {"type": "array", "items": {"type": "string"}}}}
        prompt, folder = self.files_into(f"Assignment: {title}\n\nDetails:\n{details or '(none given)'}", files)
        try:
            data = self.run(BREAKDOWN_SYSTEM, prompt, schema, timeout=300 if folder else 120,
                            tools="Read" if folder else None)
        finally:
            if folder:
                shutil.rmtree(folder, ignore_errors=True)
        steps = [s.strip() for s in data.get("steps", []) if str(s).strip()]
        if not steps:
            raise RuntimeError("empty")
        return steps

    def make_cards(self, title, details, files=(), notes="", count=8):
        """Practice questions for the Study tab, from an assignment's files and the student's notes (or just a topic).
        Returns the raw cards; clean_card() checks each one."""
        item = {"type": "object", "additionalProperties": False,
                "required": ["type", "q", "answer", "options", "accept", "source"],
                "properties": {"type": {"type": "string", "enum": ["mc", "short"]}, "q": {"type": "string"},
                               "answer": {"type": "string"}, "options": {"type": "array", "items": {"type": "string"}},
                               "accept": {"type": "array", "items": {"type": "string"}}, "source": {"type": "string"}}}
        schema = {"type": "object", "additionalProperties": False, "required": ["cards"],
                  "properties": {"cards": {"type": "array", "items": item}}}
        prompt = (f"Write {count} practice questions. About two thirds are multiple-choice: type \"mc\", exactly 4 "
                  "options, and \"answer\" is the correct option's exact text. The rest are short-answer: type \"short\", "
                  "\"options\" empty, \"answer\" 1 to 4 words, and \"accept\" lists other correct ways to write it. "
                  "\"source\" is a short quote (under 20 words) from the material that backs the answer, or \"\" if "
                  f"there isn't one.\n\nSubject: {title}\nDetails: {details[:3000] or '(none)'}")
        if notes.strip():
            prompt += f"\n\nThe student's notes:\n{notes[:20000]}"
        prompt, folder = self.files_into(prompt, files)
        try:
            data = self.run(CARDS_SYSTEM, prompt, schema, timeout=300 if folder else 150,
                            tools="Read" if folder else None, effort="medium")
        finally:
            if folder:
                shutil.rmtree(folder, ignore_errors=True)
        return [c for c in data.get("cards", []) if isinstance(c, dict)]

    # Teach Wick (the Study tab): Wick picks an idea from a deck (or takes the student's), with the key points a good
    # explanation needs; then he judges each explanation against those points and asks about what's missing.
    def teach_start(self, title, material, concept=""):
        schema = {"type": "object", "additionalProperties": False, "required": ["concept", "ask", "ideas"],
                  "properties": {"concept": {"type": "string"}, "ask": {"type": "string"},
                                 "ideas": {"type": "array", "items": {"type": "string"}}}}
        prompt = (f"The student's study material for \"{title}\" (their practice cards):\n{material}\n\n"
                  + (f"The student wants to explain: {concept}\n" if concept else
                     "Pick one important idea from this material that takes a few sentences to explain (a process, a "
                     "cause and effect, or why something matters), not a single word's definition.\n")
                  + "Reply with: concept (a short name for it, under 8 words); ask (your question asking them to explain "
                    "it, 1 or 2 sentences, curious and friendly, without giving the answer away); ideas (the 3 to 5 key "
                    "points a good explanation must include, each under 14 words).")
        data = self.run(TEACH_SYSTEM, prompt, schema, timeout=90)
        tidy = lambda s, n: " ".join(str(s or "").split())[:n]
        ideas = [tidy(i, 160) for i in data.get("ideas", []) if tidy(i, 160)][:5]
        ask = tidy(data.get("ask"), 400)
        if len(ideas) < 2 or not ask:
            raise RuntimeError("empty")
        return {"concept": tidy(data.get("concept"), 80) or concept or title, "ask": ask, "ideas": ideas}

    def teach_check(self, concept, ideas, material, convo):
        schema = {"type": "object", "additionalProperties": False, "required": ["covered", "mistakes", "wick", "follow_up"],
                  "properties": {"covered": {"type": "array", "items": {"type": "boolean"}},
                                 "mistakes": {"type": "array", "items": {"type": "string"}},
                                 "wick": {"type": "string"}, "follow_up": {"type": "string"}}}
        prompt = (f"Concept: {concept}\nKey points a good explanation includes:\n"
                  + "\n".join(f"{i + 1}. {x}" for i, x in enumerate(ideas))
                  + f"\n\nThe study material, for reference:\n{material}\n\nThe conversation so far:\n{convo}\n\n"
                  "Judge the whole conversation. Reply with: covered (one true or false per key point, in the same order: "
                  "true if the student has explained that point in their own words anywhere in the conversation); mistakes "
                  "(anything the student said that's wrong, each under 20 words; empty if none); wick (1 or 2 short "
                  "sentences about what clicked for you); follow_up (one curious question under 25 words about the most "
                  "important point that's still missing or wrong, asked like a confused friend, without giving it away; an "
                  "empty string if nothing is missing or wrong).")
        data = self.run(TEACH_SYSTEM, prompt, schema, timeout=90)
        tidy = lambda s, n: " ".join(str(s or "").split())[:n]
        cov = [bool(x) for x in data.get("covered", [])][:len(ideas)]
        cov += [False] * (len(ideas) - len(cov))
        return {"covered": cov, "mistakes": [tidy(m, 200) for m in data.get("mistakes", []) if tidy(m, 200)][:3],
                "wick": tidy(data.get("wick"), 300), "follow_up": tidy(data.get("follow_up"), 300)}

    # Unstuck (the Study tab): a ladder of hints for one problem, each a bit more help than the last, and an answer
    # check that never gives the answer away
    def unstuck(self, title, files, where, problem, work):
        schema = {"type": "object", "additionalProperties": False, "required": ["problem", "nudge", "hint", "bigger", "example"],
                  "properties": {k: {"type": "string"} for k in ("problem", "nudge", "hint", "bigger", "example")}}
        prompt = ((f"Assignment: {title}\n" if title else "")
                  + (f"The problem, as the student pasted it:\n{problem}\n" if problem.strip() else
                     "The student didn't paste the problem: find it in the assignment's files from where they say they're stuck.\n")
                  + f"Where they say they're stuck: {where.strip() or 'not sure how to start'}\n"
                  + f"Their work so far: {work.strip() or '(none)'}\n\n"
                  "Reply with: problem (the problem they're stuck on, quoted as written, under 600 characters; if you can't "
                  "find it, say what you think it is in one sentence); nudge (the smallest possible push: a question or a "
                  "pointer, under 25 words); hint (names the idea, method or next step, under 35 words); bigger (walks "
                  "through the next step concretely, but stops before the answer, under 50 words); example (a fully worked "
                  "similar problem with different numbers or a different case, under 90 words; it must not solve their "
                  "problem). Never state the final answer to their problem.")
        prompt, folder = self.files_into(prompt, files)
        try:
            data = self.run(UNSTUCK_SYSTEM, prompt, schema, timeout=300 if folder else 150,
                            tools="Read" if folder else None, effort="medium")
        finally:
            if folder:
                shutil.rmtree(folder, ignore_errors=True)
        tidy = lambda s, n: str(s or "").strip()[:n]
        out = {k: tidy(data.get(k), 700 if k == "problem" else 600) for k in ("problem", "nudge", "hint", "bigger", "example")}
        if not all(out[k] for k in ("nudge", "hint", "bigger", "example")):
            raise RuntimeError("empty")
        return out

    def check_answer(self, problem, work, answer):
        schema = {"type": "object", "additionalProperties": False, "required": ["verdict", "note"],
                  "properties": {"verdict": {"type": "string", "enum": ["right", "close", "wrong"]}, "note": {"type": "string"}}}
        prompt = (f"Problem:\n{problem}\n\nTheir work (may be empty):\n{work or '(none)'}\n\nTheir final answer: {answer}\n\n"
                  "Judge whether their final answer is correct. Never reveal the correct answer. Reply with: verdict (right, "
                  "close or wrong); note (one encouraging sentence under 25 words; if close or wrong, point to where to look "
                  "again without giving the answer).")
        data = self.run(UNSTUCK_SYSTEM, prompt, schema, timeout=150, effort="medium")
        v = data.get("verdict")
        return {"verdict": v if v in ("right", "close", "wrong") else "close", "note": " ".join(str(data.get("note", "")).split())[:300]}

    def enqueue(self, key, quest, step, exe, title, video=None):
        if key in self.inflight:
            return
        self.inflight.add(key)
        self.q.put((key, quest, step, exe, title, video))

    def worker(self):
        while True:
            key, quest, step, exe, title, video = self.q.get()
            try:
                verdict = self.judge_window(quest, step, exe, title, video)
            except NotLoggedIn:
                verdict = None
            except Exception as e:
                verdict = (local_video_verdict(quest, step, video) if video
                           else {"verdict": "unsure", "reason": f"check failed ({type(e).__name__})"})
            if verdict:
                with self.game.lock:
                    self.game.save["ai_cache"][key] = verdict
                    self.game.dirty = True
            self.inflight.discard(key)


# ---------------------------------------------------------------- save
def default_save():
    return {
        "version": 2, "light": 240, "light_frac": 0.0, "coins": 0, "star_pieces": 0,
        "quests": [], "next_id": 1,
        # habits: things to keep doing for a while on set days (an hour of Spanish, chess, reading), with no steps
        "habits": [], "next_habit": 1,
        "stats": {"focus_seconds": 0, "sessions": 0, "steps_done": 0, "quests_done": 0, "light_earned": 0,
                  "light_lost": 0, "distractions": 0, "clean_sessions": 0, "best_session": 0,
                  "breaks_on_time": 0},
        "days": {}, "daily": {}, "streak_claimed": [],
        "settings": {"idle_minutes": 3, "checkin_minutes": 45, "auto_minimize": True, "ai_checks": True,
                     "sound": True, "music": True, "music_vol": 60, "study_music": "lofi", "study_vol": 40,
                     "extra_block": [], "comp_pos": None,
                     "desktop_shortcut_done": False},
        "allow": {}, "ai_cache": {}, "adventure": None, "session_log": [],
        "bond": {},                              # seconds of focus with each partner as your study buddy
        "chests": {"study": 0, "golden": 0},     # earned by homework steps / finished assignments
        # the Study tab's practice questions, and the Light studying earned each day (see Game.study_answer)
        "study": {"cards": [], "next_id": 1, "days": {}, "tally": {}},
    }


def load_save():
    data = default_save()
    src = SAVE_PATH if os.path.exists(SAVE_PATH) else None
    try:
        if src:
            with open(src, encoding="utf-8") as f:
                loaded = json.load(f)
            for k, v in loaded.items():
                if isinstance(v, dict) and isinstance(data.get(k), dict) and k not in ("allow", "ai_cache", "days", "daily"):
                    data[k].update(v)
                else:
                    data[k] = v
        elif os.path.exists(OLD_SAVE_PATH):
            with open(OLD_SAVE_PATH, encoding="utf-8") as f:
                old = json.load(f)
            data["quests"] = old.get("quests", [])
            data["next_id"] = old.get("next_id", 1)
            for d, secs in old.get("stats", {}).get("days", {}).items():
                data["days"][d] = {"focus": secs}
            data["stats"]["focus_seconds"] = old.get("stats", {}).get("focus_seconds", 0)
    except Exception as e:
        print("couldn't read save, starting fresh:", e)
        if src:
            os.replace(src, src + f".broken-{int(time.time())}")
    if data["settings"].get("study_music") in ("battle", "phonk"):   # the intense study style is now game funk
        data["settings"]["study_music"] = "funk"
    return data


def write_save(data):
    tmp = SAVE_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    os.replace(tmp, SAVE_PATH)


def today_str(d=None):
    return (d or datetime.date.today()).isoformat()


def fmt_mins(secs):
    secs = int(secs)
    return f"{secs // 60}:{secs % 60:02d}"


# ---------------------------------------------------------------- companion lines
START_LINES = ["Okay! Desk's set up. You work, I'll work. Let's go!", "Study buddy mode: ON. I'm right here.",
               "Let's do this. One tiny step at a time.", "Lantern lit. Pencil sharpened. Let's get some Light!"]
AMBIENT = ["*scribbles notes*", "*sips tea*", "*stretches* ...okay, back to it.", "We're doing great, honestly.",
           "*quietly hums*", "*flips a page*", "*sharpens pencil with great focus*", "I can feel the Light building up!",
           "*nods at you approvingly*", "Still here. Still working. Still proud of you."]
CELEBRATE = ["YES! Step cleared!", "Look at you go!", "Boom. Done.", "That's how it's done!", "Another one down!",
             "Nice!! The Light's getting brighter!"]
WELCOME = ["Thank you. Welcome back!", "There you are. Okay!", "Phew. Back to it!", "Good choice. Let's go."]
BLOCK_NAGS = ["Still on {label}? Close it. You're losing Light!",
              "{label} is feeding the Gloom. Every second costs you!",
              "Hey. HEY. Your homework misses you. Get off {label}.",
              "I'm really worried now. Please go back to your work. 😟",
              "Okay that's it, I'm minimizing it if you don't. {label} can wait."]
PASS_NAGS = ["Still need {label}? Wrap it up, {left} left on your pass.",
             "{left} left on your {label} pass. Make it count!",
             "Got what you needed from {label}? Let's head back."]
BACK_LINES = ["There you are! 👍", "Oh good, you're back in it.", "Nice, we're rolling again."]


# ---------------------------------------------------------------- focus session
class Session:
    def __init__(self, game, quest_id, pledge, paper, habit_id=None):
        self.g = game
        # a session is for an assignment, a habit (no steps: it keeps you on it and counts minutes towards the day's
        # goal), or neither (a free session)
        self.habit_id = habit_id if habit_id is not None and game.habit(habit_id) else None
        self.quest_id = None if self.habit_id else quest_id
        self.pledge, self.paper = pledge, bool(paper or (self.habit_id and game.habit(habit_id).get("paper")))
        self.started = time.time()
        self.mode = "focus"           # focus | break
        self.alert = None             # dict while something needs attention
        self.status = "focus"         # what the last tick decided (for the UI)
        self.focus_s = 0
        self.combo_s = 0
        self.light_frac = 0.0
        self.light_earned = 0
        self.light_lost = 0
        self.break_bank = float(BREAK_BANK_START)
        self.break_used = 0
        self.overtime = 0
        self.distractions = 0
        self.steps_done = 0
        self.hub_s = 0
        self.idle_ok_until = self.started   # quiet time only counts from here (see tick_idle)
        self.offenses = []
        self.next_chatter = time.time() + random.randint(300, 540)
        cm = game.save["settings"].get("checkin_minutes", 45)
        self.next_checkin = cm * 60 if cm else None
        self.next_milestone = 25 * 60
        self.seen_title = (None, 0)
        self.last_fg = Fg(0, "", "", "", 0)
        self.last_tick = time.time()

    # ---- helpers
    def quest(self):
        return self.g.quest(self.quest_id) if self.quest_id else None

    def habit(self):
        return self.g.habit(self.habit_id) if self.habit_id else None

    def target(self):
        """What the focus checks compare your windows with: the assignment, or the habit (as {habit: True, title,
        details: what counts}), or None in a free session."""
        h = self.habit()
        if h:
            return {"habit": True, "title": h["title"], "details": h.get("what", ""), "files": []}
        return self.quest()

    def allow_key(self):
        """Where the pages you've shown are for this work get remembered (save.allow): per assignment or habit."""
        return f"h{self.habit_id}" if self.habit_id else str(self.quest_id)

    def thing(self):
        return "habit" if self.habit_id else "assignment"

    def step_index(self):
        q = self.quest()
        return next((i for i, s in enumerate(q["steps"]) if not s["done"]), None) if q else None

    def step_text(self):
        q, i = self.quest(), self.step_index()
        return q["steps"][i]["text"] if q and i is not None else None

    def where(self):
        h = self.habit()
        if h:
            return f"Back to {h['title']}!"
        s = self.step_text()
        return f"We were on: {s}" if s else "Let's keep going."

    def combo(self):
        return 1 + min(self.combo_s, COMBO_FULL_SECONDS) / COMBO_FULL_SECONDS

    def say(self, text, mood="happy", sound=None):
        self.g.say(text, mood, sound)

    def penalize(self, n, why=""):
        save = self.g.save
        lost = min(n, save["light"])
        save["light"] -= lost
        self.light_lost += n
        save["stats"]["light_lost"] += n
        self.combo_s = 0
        if self.alert is not None:
            self.alert["lost"] = self.alert.get("lost", 0) + n

    def earn(self, amount):
        save = self.g.save
        save["light"] += amount
        self.light_earned += amount
        save["stats"]["light_earned"] += amount

    def set_alert(self, alert):
        self.alert = alert
        self.g.set_overlay("alert" if alert and alert.get("big", True) else "normal")

    def clear_alert(self):
        self.alert = None
        self.g.set_overlay("normal")

    # ---- the once-a-second brain
    def tick(self):
        now = time.time()
        fg = DEBUG_FG or foreground()
        self.last_fg = fg
        kind, info = self.g.classify(fg, self)
        self.status = kind
        if self.mode == "break":
            self.tick_break(now)
            return
        if kind == "hold":                       # our own windows: just wait (but still notice a quiet desk)
            if not self.alert or self.alert["kind"] in ("checkin", "idle"):
                self.tick_idle(now)
            return
        if kind == "blocked":
            self.tick_blocked(now, fg, info)
            return
        if self.alert and self.alert["kind"] == "blocked":
            lost = self.alert.get("lost", 0)
            self.clear_alert()
            self.say(f"{random.choice(WELCOME)} {self.where()}" + (f" (The Gloom took {lost} Light.)" if lost else ""),
                     "relieved")
        if kind == "offtask":
            self.tick_offtask(now, fg, info)
            return
        if self.alert and self.alert["kind"] == "offtask":
            lost = self.alert.get("lost", 0)
            self.clear_alert()
            self.say(f"{random.choice(WELCOME)} {self.where()}", "relieved")
        if self.tick_idle(now):
            return
        if kind == "hub":
            self.tick_hub(now)
            return
        self.hub_s = 0
        self.tick_focus(now)

    def tick_idle(self, now):
        """Notice a quiet desk: first a gentle "just thinking?" check-in, then the big "what's up?" alert.

        Quiet means no real input (see ActivityWatch); in paper mode, where the computer sits untouched,
        it's simply time since the last check-in. Answering a check-in counts as activity, and the
        "reading"/"thinking" answers push the next check-in back. Returns True while the big alert is up.
        """
        raw = DEBUG_IDLE if DEBUG_IDLE is not None else ACTIVITY.idle()
        idle = max(0.0, min(raw, now - self.idle_ok_until))
        if self.paper:
            soft, limit = PAPER_CHECKIN, PAPER_CHECKIN + 120
        else:
            limit = self.g.save["settings"].get("idle_minutes", 3) * 60
            soft = max(60, int(limit * 0.6))
        a = self.alert
        if a and a["kind"] == "idle":
            if now - a["since"] > 300 and now >= a["next_penalty"]:
                self.penalize(1)
                a["next_penalty"] = now + 30
            return True
        if a and a["kind"] == "checkin":
            if raw < 3:                          # typing/clicking again: no answer needed
                self.clear_alert()
                self.say(random.choice(BACK_LINES), "happy")
            elif now - a["since"] >= limit - soft:
                self.big_idle(now, idle)
                return True
            return False
        if idle >= limit:
            self.big_idle(now, idle)
            return True
        if idle >= soft:
            self.set_alert({"kind": "checkin", "since": now, "big": False, "lost": 0, "paper": self.paper})
            self.say("Still writing? ✍️ Tap a button so I know you're okay." if self.paper
                     else "It's gone quiet over there. Just thinking? 🤔", "worried", "chime")
        return False

    def big_idle(self, now, idle):
        mins = max(1, int(idle // 60))
        self.set_alert({"kind": "idle", "since": now, "next_penalty": now + 300, "lost": 0, "minutes": mins,
                        "paper": self.paper})
        self.say(f"Nothing's happened for {mins} minutes. What's going on?", "worried", "alert")

    def tick_focus(self, now):
        g = self.g
        self.focus_s += 1
        self.combo_s += 1
        g.save["stats"]["focus_seconds"] += 1
        g.day()["focus"] += 1
        pid = (g.save.get("adventure") or {}).get("partner")
        if pid:
            g.save["bond"][pid] = g.save["bond"].get(pid, 0) + 1
        rate = LIGHT_PER_MIN / 60 * self.combo() * (1.25 if self.pledge else 1) * g.light_badge_bonus()
        self.light_frac += rate
        if self.light_frac >= 1:
            whole = int(self.light_frac)
            self.light_frac -= whole
            self.earn(whole)
        self.break_bank = min(BREAK_BANK_MAX, self.break_bank + BREAK_EARN_RATIO)
        if self.tick_habit():
            return
        if self.focus_s >= self.next_milestone:
            self.next_milestone += 25 * 60
            self.earn(3)
            self.say(f"{self.focus_s // 60} minutes of focus! +3 bonus Light. You're on fire (the good kind).", "proud",
                     "chime")
        elif now - g.last_say < 30:
            return  # don't talk over something important
        elif self.next_checkin and self.focus_s >= self.next_checkin:
            self.next_checkin += g.save["settings"].get("checkin_minutes", 45) * 60
            self.say(f"Still going strong? You've banked {fmt_mins(self.break_bank)} of break if you want it. "
                     "(Totally fine to ignore me.)", "happy")
        elif now >= self.next_chatter:
            self.next_chatter = now + random.randint(300, 540)
            self.say(random.choice(AMBIENT), "happy")

    def tick_habit(self):
        """A habit's session: the focused second counts towards today's goal. Reaching the goal is celebrated (and
        pays HABIT_BONUS); returns True then, so nothing talks over it."""
        h = self.habit()
        if not h:
            return False
        log, key = h.setdefault("log", {}), today_str()
        if key not in log and len(log) >= 400:   # (a year and more is plenty of history)
            for old in sorted(log)[:len(log) - 399]:
                del log[old]
        before = log.get(key, 0)
        log[key] = before + 1
        goal = h["goal_min"] * 60
        if before < goal <= before + 1:
            self.earn(HABIT_BONUS)
            streak = habit_streak(h)
            h["best"] = max(h.get("best", 0), streak)
            self.say(f"🎉 That's your {h['goal_min']} minutes of {h['title']} for today! +{HABIT_BONUS} Light"
                     + (f", and a {streak}-day streak!" if streak > 1 else ".")
                     + " Keep going if you like, or end the session.", "proud", "fanfare")
            return True
        return False

    def tick_hub(self, now):
        self.hub_s += 1
        if self.hub_s == HUB_GRACE:
            self.say("Psst, no adventuring during work time! Take a break if you want to play.", "worried")
        elif self.hub_s > HUB_GRACE * 2 and self.hub_s % 15 == 0:
            self.penalize(1)
            if self.hub_s % 60 == 0:
                self.say("You're losing Light hanging around the game window. Back to work!", "angry")

    def tick_blocked(self, now, fg, label):
        a = self.alert
        norm = norm_title(fg.title)
        if not a or a["kind"] != "blocked" or a["label"] != label:
            self.offenses = [t for t in self.offenses if now - t < 600] + [now]
            grace = BLOCK_GRACE if len(self.offenses) == 1 else BLOCK_GRACE_REPEAT
            self.distractions += 1
            self.g.save["stats"]["distractions"] += 1
            self.set_alert({"kind": "blocked", "label": label, "title": fg.title[:120], "norm": norm, "since": now,
                            "grace_until": now + grace, "next_penalty": now + grace, "next_nag": now + grace + 15,
                            "nags": 0, "pass_until": 0, "pass_expired": False, "minimized": False, "lost": 0,
                            "verdict": None, "checking": False})
            self.say(f"Hey! That's {label}. Close it, you've got {grace} seconds.", "angry", "alert")
            return
        if a.get("pass_until", 0) > now:         # a judged good reason: no penalty, just reminders
            if now >= a["next_nag"]:
                left = fmt_mins(a["pass_until"] - now)
                self.say(random.choice(PASS_NAGS).format(label=label, left=left), "worried")
                a["next_nag"] = now + 60
            return
        if a.get("pass_until") and not a["pass_expired"]:
            a["pass_expired"] = True
            a["next_penalty"] = now + 5
            a["since"] = now - MINIMIZE_AFTER + 20
            a["big"] = True
            self.set_alert(a)
            self.say(f"Time's up on that pass. Close {label} now.", "angry", "alert")
        if a.get("checking"):
            return
        if now >= a["next_penalty"]:
            self.penalize(BLOCK_PENALTY)
            a["next_penalty"] = now + BLOCK_PENALTY_EVERY
        if now >= a["next_nag"]:
            self.say(BLOCK_NAGS[min(a["nags"], len(BLOCK_NAGS) - 1)].format(label=label), "angry", "alert")
            a["nags"] += 1
            a["next_nag"] = now + 15
        if (self.g.save["settings"].get("auto_minimize", True) and not a["minimized"]
                and now - a["since"] >= MINIMIZE_AFTER):
            if not self.g.headless:
                minimize(fg.hwnd)
            a["minimized"] = True
            self.penalize(3)
            self.say(f"I minimized {label} for you. Back to work, please.", "angry", "alert")

    def tick_offtask(self, now, fg, info):
        a = self.alert
        norm = norm_title(fg.title)
        if not a or a["kind"] != "offtask" or a["norm"] != norm:
            self.distractions += 1
            self.g.save["stats"]["distractions"] += 1
            self.set_alert({"kind": "offtask", "title": fg.title[:120], "norm": norm, "reason": info, "since": now,
                            "grace_until": now + OFFTASK_GRACE, "next_penalty": now + OFFTASK_GRACE,
                            "next_nag": now + OFFTASK_GRACE + 20, "lost": 0})
            q = self.quest()
            what = f"your {q['title']}" if q else "schoolwork"
            self.say(f"Hmm, is this really for {what}? {info}", "worried", "alert")
            return
        if a.get("checking"):                    # (no penalty while your reason is being judged)
            return
        if now >= a["next_penalty"]:
            self.penalize(1)
            a["next_penalty"] = now + 10
        if now >= a["next_nag"]:
            self.say(f"This still doesn't look like your {self.thing()}. Head back?", "worried")
            a["next_nag"] = now + 30

    def tick_break(self, now):
        self.break_used += 1
        if self.break_bank > 0:
            self.break_bank = max(0.0, self.break_bank - 1)
            return
        self.overtime += 1
        if self.overtime == 1:
            self.set_alert({"kind": "breakover", "since": now, "lost": 0})
            self.say(f"Break's over! {self.where()}", "happy", "alert")
        elif self.overtime > 60 and self.overtime % 15 == 0:
            self.penalize(1)
            if self.overtime % 60 == 0:
                self.say("Your break ran out a while ago. You're losing Light now!", "angry", "alert")

    # ---- actions from the UI
    def start_break(self, why="Break time!"):
        self.mode = "break"
        self.overtime = 0
        self.break_started = time.time()
        self.clear_alert()
        self.say(f"{why} I'll guard the desk. You've got {fmt_mins(self.break_bank)} banked.", "sleepy")

    def resume(self):
        # a real break (1+ min) that ends within a minute of the bank running out counts as "back on time"
        on_time = (self.mode == "break" and self.overtime <= 60
                   and time.time() - getattr(self, "break_started", time.time()) >= 60)
        self.mode = "focus"
        self.overtime = 0
        self.clear_alert()
        self.idle_ok_until = time.time() + 30
        if on_time:
            self.g.save["stats"]["breaks_on_time"] = self.g.save["stats"].get("breaks_on_time", 0) + 1
            self.earn(2)
            self.say(f"Back right on time! +2 Light. {self.where()}", "proud", "chime")
        else:
            self.say(f"Back to it! {self.where()}", "happy")

    def extend_break(self):
        if self.g.save["light"] < 5:
            return False
        self.g.save["light"] -= 5
        self.break_bank += 300
        self.overtime = 0
        self.clear_alert()
        self.say("Okay, 5 more minutes. That cost 5 Light. Enjoy it!", "happy")
        return True

    def idle_answer(self, answer):
        now = time.time()
        if answer == "still":                   # the gentle check-in: "just thinking" / "still writing"
            self.idle_ok_until = now + (0 if self.paper else 120)
            self.clear_alert()
            self.say("Nice, keep writing! I'll check in again in about 10 minutes." if self.paper
                     else "Thinking counts as work too. 🤔 Take your time, I'll check back in a bit.", "happy")
        elif answer == "distracted":
            self.distractions += 1
            self.g.save["stats"]["distractions"] += 1
            self.combo_s = 0
            self.idle_ok_until = now
            self.clear_alert()
            self.say(f"Thanks for telling me, it happens! Let's do one tiny thing. {self.where()}", "happy")
        elif answer == "reading":
            self.idle_ok_until = now + 600
            self.clear_alert()
            self.say("Got it, reading mode. I'll check back in 10 minutes.", "happy")
        elif answer == "thinking":
            self.idle_ok_until = now + 300
            self.clear_alert()
            self.say("Thinking is work too. I'll check back in 5.", "happy")
        elif answer == "phone":
            self.distractions += 1
            self.g.save["stats"]["distractions"] += 1
            self.penalize(5)
            self.clear_alert()
            self.idle_ok_until = now + 30
            self.say("Thanks for being honest. -5 Light. Phone goes face down (or in another room). Let's go!",
                     "worried")
        elif answer in ("break", "away"):
            self.start_break("Okay, break time!" if answer == "break" else "No problem, I'll wait.")

    # ---- excuses: "I need this for school" really gets judged (by Claude, or the stricter word check without it)
    def give_reason(self, text):
        a = self.alert
        if not a or a["kind"] not in ("blocked", "offtask"):
            return {"ok": False}
        if a.get("checking"):
            return {"ok": False, "error": "Hang on, I'm still thinking about your last reason."}
        if a.get("tries", 0) >= MAX_EXCUSES:
            return {"ok": False, "error": "No more excuses for this one. Close it!"}
        text = text.strip()
        if len(text.split()) < 3:
            return {"ok": False, "error": "Give me a real reason (a few words)."}
        a["tries"] = a.get("tries", 0) + 1
        a["reason_text"] = text
        a["verdict_text"] = None
        if self.g.ai.ready():
            a["checking"] = True
            threading.Thread(target=self._judge_reason, args=(dict(a), text), daemon=True).start()
            return {"ok": True, "checking": True}
        self._apply_verdict(a, local_excuse_verdict(self.target(), self.step_text(), a["title"], text), local=True)
        return {"ok": True}

    def _judge_reason(self, snapshot, text):
        local = False
        try:
            flagged = (snapshot.get("reason") or "off task") if snapshot["kind"] == "offtask" else None
            v = self.g.ai.judge_excuse(self.target(), snapshot.get("label"), snapshot["title"], text, flagged=flagged)
        except Exception:
            v, local = local_excuse_verdict(self.target(), self.step_text(), snapshot["title"], text), True
        with self.g.lock:
            a = self.alert
            if not a or a["kind"] != snapshot["kind"] or a.get("norm") != snapshot.get("norm"):
                return
            self._apply_verdict(a, v, local)

    def _apply_verdict(self, a, v, local=False):
        a["checking"] = False
        if v.get("verdict") == "schoolwork":
            if local and a["kind"] == "blocked":
                # the word check is easy to talk round, so on a blocked site it only buys a few minutes
                self._grant_pass(a, f"{v.get('reason', 'Okay.')} You get {fmt_mins(PASS_SECONDS)}, then I'll check on you again.")
                return
            self.g.allow_title(self.allow_key(), a["norm"])
            if a["kind"] == "offtask":
                self.distractions = max(0, self.distractions - 1)
            self.clear_alert()
            self.say(f"Fair enough: {v.get('reason', '')} I'll remember that one's for this {self.thing()}.", "happy")
            return
        why = v.get("reason") or "That doesn't sound like schoolwork."
        a["verdict_text"] = why
        a["big"] = True
        self.set_alert(a)
        more = MAX_EXCUSES - a.get("tries", 0)
        self.say(f"Not buying it: {why} " + ("Close it, or give me one more honest reason." if more > 0 else "No more excuses. Close it!"),
                 "angry", "alert")

    def _grant_pass(self, a, msg):
        now = time.time()
        a["checking"] = False
        a["pass_until"] = now + PASS_SECONDS
        a["next_nag"] = now + 60
        a["big"] = False
        self.set_alert(a)
        self.say(msg, "happy")

    def offtask_answer(self, answer, text=""):
        a = self.alert
        if not a or a["kind"] != "offtask":
            return {"ok": False}
        if answer == "for_this":                 # "it IS for my assignment": prove it (see give_reason)
            return self.give_reason(text) if text.strip() else {"ok": False, "error": f"Tell me how it's for your {self.thing()}."}
        a["grace_until"] = a["next_penalty"] = time.time() + 15
        a["big"] = False
        self.set_alert(a)
        self.say("Thanks. Switch back and I'll stop worrying.", "happy")
        return {"ok": True}

    def step_done(self):
        g = self.g
        q, i = self.quest(), self.step_index()
        if q and i is None:                      # the assignment is finished: nothing left to check off
            return {"ok": False, "quest_done": True}
        self.steps_done += 1
        g.save["stats"]["steps_done"] += 1
        g.day()["steps"] += 1
        g.save["chests"]["study"] += 1
        self.earn(STEP_BONUS)
        result = {"quest_done": False}
        if q and i is not None:
            q["steps"][i]["done"] = True
            if self.step_index() is None:
                q["done"] = True
                g.save["stats"]["quests_done"] += 1
                g.save["star_pieces"] += 1
                g.save["chests"]["golden"] += 1
                self.earn(QUEST_BONUS)
                result["quest_done"] = True
                self.say(f"YOU FINISHED {q['title'].upper()}!!! +{QUEST_BONUS} Light, a ⭐ Star Piece and a 🏆 Golden Chest!",
                         "proud", "fanfare")
                return result
        self.say(f"{random.choice(CELEBRATE)} +{STEP_BONUS} Light and a 🎁 Study Chest for the adventure."
                 + (f" Next: {self.step_text()}" if self.step_text() else ""), "proud", "chime")
        return result

    def finish(self):
        g = self.g
        clean = self.focus_s >= 1200 and self.distractions == 0
        if clean:
            self.earn(CLEAN_BONUS)
            g.day()["clean"] += 1
            g.save["stats"]["clean_sessions"] = g.save["stats"].get("clean_sessions", 0) + 1
        g.save["stats"]["sessions"] += 1
        g.save["stats"]["best_session"] = max(g.save["stats"].get("best_session", 0), self.focus_s)
        q, h = self.quest(), self.habit()
        summary = {"id": int(time.time() * 1000), "quest": q["title"] if q else None, "focus_s": self.focus_s,
                   "light_earned": self.light_earned, "light_lost": self.light_lost, "steps_done": self.steps_done,
                   "distractions": self.distractions, "clean": clean, "break_used": self.break_used,
                   "when": datetime.datetime.now().isoformat(timespec="minutes")}
        if h:   # (a habit's session: how today stands against its goal)
            summary.update(habit=h["title"], habit_emoji=h["emoji"], habit_today_s=h.get("log", {}).get(today_str(), 0),
                           habit_goal_s=h["goal_min"] * 60, habit_streak=habit_streak(h))
        g.save["session_log"] = (g.save["session_log"] + [summary])[-50:]
        return summary

    # ---- carrying a session over to another device (web/js/sync.js: "Continue here")
    def carry(self):
        """Everything another device needs to carry this session on."""
        d = {k: getattr(self, k) for k in CARRY_KEYS}
        # ("since": when it started on this device, in ms; when two devices both have a session, the newer one wins)
        d.update(quest_id=self.quest_id, habit_id=self.habit_id, since=int(self.started * 1000),
                 first_started=getattr(self, "first_started", self.started))
        return d

    def apply_carry(self, c):
        """Picks up a session handed over from another device: its time, Light and break bank so far. Its seconds
        already counted in that device's stats (and sync brings those over), so they aren't counted again here."""
        for k in CARRY_KEYS:
            v = c.get(k)
            if k == "pledge":
                self.pledge = bool(v)
            elif k == "mode":
                self.mode = "break" if v == "break" else "focus"
            elif isinstance(v, (int, float)) and not isinstance(v, bool) and v >= 0:
                setattr(self, k, type(getattr(self, k))(v))
        first = c.get("first_started")
        self.first_started = first if isinstance(first, (int, float)) and not isinstance(first, bool) else self.started
        self.next_milestone = (self.focus_s // 1500 + 1) * 1500
        cm = self.g.save["settings"].get("checkin_minutes", 45)
        self.next_checkin = (self.focus_s // (cm * 60) + 1) * cm * 60 if cm else None

    def to_json(self):
        q, h = self.quest(), self.habit()
        i = self.step_index()
        a = None
        now = time.time()
        if self.alert:
            a = {k: v for k, v in self.alert.items() if k in ("kind", "label", "title", "reason", "lost", "minutes",
                                                              "minimized", "checking", "reason_text", "paper", "verdict_text")}
            a["tries_left"] = MAX_EXCUSES - self.alert.get("tries", 0)
            a["grace_left"] = max(0, int(self.alert.get("grace_until", 0) - now))
            a["pass_left"] = max(0, int(self.alert.get("pass_until", 0) - now))
            a["big"] = self.alert.get("big", True)
        return {
            "quest": {"id": q["id"], "title": q["title"], "step_index": i, "step_text": self.step_text(),
                      "steps_total": len(q["steps"]), "steps_done": sum(s["done"] for s in q["steps"])} if q else None,
            "habit": {"id": h["id"], "title": h["title"], "emoji": h["emoji"], "goal_s": h["goal_min"] * 60,
                      "today_s": h.get("log", {}).get(today_str(), 0), "streak": habit_streak(h)} if h else None,
            "mode": self.mode, "status": self.status, "alert": a, "focus_s": self.focus_s,
            "combo": round(self.combo(), 2), "light_earned": self.light_earned, "light_lost": self.light_lost,
            "break_bank": int(self.break_bank), "break_used": self.break_used, "overtime": self.overtime,
            "pledge": self.pledge, "paper": self.paper, "distractions": self.distractions,
            "steps_done": self.steps_done, "idle_ok_left": max(0, int(self.idle_ok_until - now)),
        }


# ---------------------------------------------------------------- the whole app
DAILY_POOL = {
    "focus30": ("Focus for 30 minutes", "focus", 1800, {"light": 15}),
    "focus60": ("Focus for 60 minutes", "focus", 3600, {"light": 30, "coins": 15}),
    "steps3": ("Finish 3 homework steps", "steps", 3, {"light": 15}),
    "steps5": ("Finish 5 homework steps", "steps", 5, {"light": 25}),
    "clean": ("Finish a clean session (20+ min, zero distractions)", "clean", 1, {"light": 20}),
    "early": ("Start a focus session before 5 PM", "early", 1, {"coins": 15}),
    "battles3": ("Win 3 battles in the adventure", "battles", 3, {"coins": 20}),
    "blocks2": ("Hit 2 ✦ blocks in the adventure", "blocks", 2, {"coins": 10}),
}
STREAK_REWARDS = {3: {"light": 20}, 7: {"light": 30, "star_pieces": 1}, 14: {"star_pieces": 2}, 30: {"star_pieces": 5}}


class Game:
    def __init__(self, port, headless=False):
        self.lock = threading.RLock()
        self.port = port
        self.headless = headless  # test mode: never touch real windows
        self.save = load_save()
        self.session = None
        self.summary = None
        self.speech = {"id": 0, "text": "", "mood": "happy", "sound": None}
        self.last_say = 0
        self.dirty = True
        self.overlay_mode = "normal"
        self.overlay_gen = 0      # bumps on every overlay change (a pending "tuck away" checks it)
        self.comp_hwnd = None
        self.comp_tucked = False  # an alert popped the minimized buddy back up: it goes back down afterwards
        self.quitting = False     # a newer copy asked to take over (see /api/quit)
        self.edge_pid = None      # the Edge process behind our windows (see open_main)
        self.wake = threading.Event()   # cuts the main loop's 1-second nap short (to quit right away)
        self.started = time.time()
        self.ai = AI(self)
        self.updater = Updater()
        self.hub_tab, self.hub_tab_t = None, 0   # the main window's tab, as its last poll said (the Study tab is focus)
        # the buddy page checks in twice a second; when its window is up but it has gone quiet (Edge froze it, or it
        # crashed), it's showing grey, and a fresh one replaces it (see buddy_stale)
        self.buddy_seen = 0.0
        self.buddy_grace = 0.0                   # no judging it before this (just opened, just un-minimized...)
        self.buddy_iconic = False
        self.buddy_checked = 0.0                 # (when buddy_stale last ran)
        self.buddy_revived = 0.0
        self.buddy_woke = False
        self.buddy_mute = False                  # test tooling: ignore its check-ins (see /api/debug/buddy)
        # Black windows: Edge sometimes brings a window back up (a long-minimized buddy popping up for an alert, seen
        # 2026-11-20) without ever drawing it again, so it shows nothing but its dark background while its page runs
        # on fine. Both pages report the frames they've drawn; a window that's up but draws none is replaced (is_dark).
        self.pages = {w: self.fresh_page() for w in ("buddy", "hub")}
        self.buddy_iconic_since = 0.0            # (when it got minimized, while it is)
        self.buddy_shown = 0.0                   # (when it last came up, or opened)
        self.buddy_reviving = False
        self.revive_lock = threading.Lock()
        self.hub_hwnd, self.hub_iconic, self.hub_shown, self.hub_revived = None, False, 0.0, 0.0
        self.dark_times = []                     # (black windows lately: a second one soon after = Edge restarts)
        self.edge_restarting = False
        self.debug_frozen = set()                # test tooling: pages whose frames don't count (see /api/debug/dark)
        self.debug_active = False                # test tooling: judge windows even when you're away from the PC
        self.reuse_iconic = REUSE_ICONIC         # (test tooling can change it)
        SAFE_RENDER[0] = bool(self.save["settings"].get("safe_render"))

    # ---- small helpers
    def quest(self, qid):
        return next((q for q in self.save["quests"] if q["id"] == qid), None)

    def habit(self, hid):
        return next((h for h in self.save["habits"] if h["id"] == hid), None)

    def habit_view(self, h):
        """A habit as the windows show it: today's minutes against the goal, its streak, and the last 7 days."""
        today, log, goal = datetime.date.today(), h.get("log", {}), h["goal_min"] * 60
        week = []
        for back in range(6, -1, -1):
            d = today - datetime.timedelta(days=back)
            s = log.get(d.isoformat(), 0)
            week.append({"date": d.isoformat(), "s": s, "on": d.weekday() in h["days"], "met": s >= goal})
        streak = habit_streak(h, today)
        return {"id": h["id"], "title": h["title"], "emoji": h["emoji"], "goal_min": h["goal_min"], "days": h["days"],
                "what": h["what"], "paper": h.get("paper", False), "kind": h.get("kind", "time"),
                "today_s": log.get(today.isoformat(), 0), "today_on": today.weekday() in h["days"],
                "marked_today": today.isoformat() in h.get("marked", {}),
                "streak": streak, "best": max(h.get("best", 0), streak), "week": week,
                "total_s": sum(log.values())}

    def mark_habit(self, h, done):
        """Checks a habit off for today without a focus session (the gym doesn't need one), or takes that back. It
        pays the same as reaching the goal in a session, once a day; taking it back takes that back too."""
        key, goal = today_str(), h["goal_min"] * 60
        log, marks = h.setdefault("log", {}), h.setdefault("marked", {})
        if done:
            before = log.get(key, 0)
            if before >= goal:
                return {"ok": True, "light": 0, "streak": habit_streak(h)}
            for old in [d for d in marks if d < today_str(datetime.date.today() - datetime.timedelta(days=60))]:
                del marks[old]
            marks[key] = goal - before           # (how much the check-off added, for an undo)
            log[key] = goal
            self.save["light"] += HABIT_BONUS
            self.save["stats"]["light_earned"] += HABIT_BONUS
            streak = habit_streak(h)
            h["best"] = max(h.get("best", 0), streak)
            return {"ok": True, "light": HABIT_BONUS, "streak": streak}
        if key not in marks:
            return {"ok": False, "error": "Only a check-off can be taken back."}
        log[key] = max(0, log.get(key, 0) - marks.pop(key))
        if not log[key]:
            del log[key]
        taken = min(HABIT_BONUS, self.save["light"])
        self.save["light"] -= taken
        return {"ok": True, "light": -taken, "streak": habit_streak(h)}

    # ---- homework files: uploads wait in "homework files/_new/<id>/" until an assignment is saved with them,
    # then live in "homework files/q<assignment id>/" under their own names
    def find_file(self, fid):
        """(path, info) of an uploaded file, attached to an assignment or still waiting to be."""
        fid = re.sub(r"[^0-9a-f]", "", str(fid or ""))[:16]
        if not fid:
            return None, None
        for q in self.save["quests"]:
            for f in q.get("files", []):
                if f["id"] == fid:
                    return os.path.join(FILES_DIR, f"q{q['id']}", f["name"]), f
        folder = os.path.join(FILES_DIR, "_new", fid)
        names = os.listdir(folder) if os.path.isdir(folder) else []
        if names:
            path = os.path.join(folder, names[0])
            return path, {"id": fid, "name": names[0], "size": os.path.getsize(path)}
        return None, None

    def attach_files(self, q, ids, replace=False):
        """Move waiting uploads into the assignment's folder. With replace, the list is the whole set: its other
        files get deleted."""
        have = {f["id"]: f for f in q.get("files", [])}
        folder = os.path.join(FILES_DIR, f"q{q['id']}")
        waiting = os.path.join(FILES_DIR, "_new")
        files = []
        for fid in ids:
            fid = re.sub(r"[^0-9a-f]", "", str(fid or ""))[:16]
            if fid in have:
                files.append(have.pop(fid))
                continue
            src, info = self.find_file(fid)
            if not src or os.path.dirname(os.path.dirname(src)) != waiting:
                continue                         # (only uploads that are still waiting)
            os.makedirs(folder, exist_ok=True)
            dest = unique_path(folder, info["name"])
            os.replace(src, dest)
            shutil.rmtree(os.path.dirname(src), ignore_errors=True)
            files.append({"id": fid, "name": os.path.basename(dest), "size": info["size"]})
        if replace:
            for f in have.values():
                try:
                    os.remove(os.path.join(folder, f["name"]))
                except OSError:
                    pass
        else:
            files = list(have.values()) + files
        q["files"] = files

    def remove_quest_files(self, q):
        shutil.rmtree(os.path.join(FILES_DIR, f"q{q['id']}"), ignore_errors=True)

    def day(self, d=None):
        key = today_str(d)
        day = self.save["days"].setdefault(key, {})
        for k in ("focus", "steps", "battles", "blocks", "clean", "early"):
            day.setdefault(k, 0)
        return day

    def say(self, text, mood="happy", sound=None):
        self.speech = {"id": self.speech["id"] + 1, "text": text, "mood": mood, "sound": sound}
        self.last_say = time.time()

    def light_badge_bonus(self):
        adv = self.save.get("adventure") or {}
        eq = (adv.get("badges", {}) or {}).get("equipped", [])
        return (1.1 if "ember_heart" in eq else 1.0) * (1.15 if "focus_core" in eq else 1.0)

    def allow_title(self, quest_id, norm):
        lst = self.save["allow"].setdefault(str(quest_id), [])
        if norm and norm not in lst:
            lst.append(norm)
        self.dirty = True

    def classify(self, fg, session):
        if fg.pid == OWN_PID or fg.title == COMP_TITLE:
            return "hold", None
        if fg.title == MAIN_TITLE and fg.exe in BROWSER_EXES:
            if session.alert:
                return "hold", None
            # (quizzing yourself in the Study tab is studying; anywhere else in the main window is the game)
            if self.hub_tab == "study" and time.time() - self.hub_tab_t < 5:
                return "focus", None
            return "hub", None
        if not fg.hwnd or fg.exe in NEUTRAL_EXES or fg.title in ("", "Program Manager"):
            return "focus", None
        norm = norm_title(fg.title)
        # (a page you've already shown is for this assignment or habit stays allowed, even on a site that's usually
        # blocked)
        if norm and norm in self.save["allow"].get(session.allow_key(), []):
            return "focus", None
        q, low = session.quest(), fg.title.lower()
        if q and any(len(stem) >= 4 and stem in low
                     for stem in (os.path.splitext(f["name"])[0].lower() for f in q.get("files", []))):
            return "focus", None                 # one of the assignment's own files is open
        video = youtube_video(fg)
        if video == "":
            return "blocked", "YouTube"
        # (a YouTube video is judged by what it's about, even when its title names a blocked site or game)
        label = None if video else blocked_label(fg, self.save["settings"].get("extra_block", []))
        h = session.habit()
        if label and h and label in habit_unblocks(h):
            label = None                         # (the habit is that: chess.com for chess, a Discord language exchange)
            if not self.ai.ready():
                return "focus", None
        if label:
            return "blocked", label
        if video is None and (fg.exe in WORK_EXES or any(rx.search(norm) for rx in WORK_RES)):
            return "focus", None
        if self.ai.ready() and norm:
            key = f"{session.allow_key()}|{fg.exe}|{norm}"
            v = self.save["ai_cache"].get(key)
            if v:
                return ("offtask", v.get("reason", "")) if v.get("verdict") == "off_task" else ("focus", None)
            last, since = session.seen_title
            if last != key:
                session.seen_title = (key, time.time())
            elif time.time() - since >= 4:   # only check windows you actually stay on
                self.ai.enqueue(key, session.target(), session.step_text(), fg.exe, fg.title[:200], video)
        elif video:
            # no Claude: YouTube videos still get a (stricter) word check
            v = local_video_verdict(session.target(), session.step_text(), video)
            if v["verdict"] == "off_task":
                return "offtask", v["reason"]
        return "focus", None

    # ---- overlay window placement
    def set_overlay(self, mode):
        self.overlay_mode = mode
        self.overlay_gen += 1
        threading.Thread(target=self.apply_overlay, daemon=True).start()

    def apply_overlay(self):
        hwnd = self.comp_hwnd
        if self.headless or not hwnd or not user32.IsWindow(hwnd) or self.buddy_reviving:
            return                        # (a fresh window that's on its way gets placed when it's up)
        alert = self.overlay_mode == "alert"
        if user32.IsIconic(hwnd):
            if not alert:
                return                    # minimized with nothing to say: it stays down in the taskbar
            # minimizing the buddy doesn't get you out of an alert: it pops back up (and goes back down after). One
            # that's been down a while comes up as a fresh window instead: Edge can bring a long-minimized window
            # back without ever drawing it again (black), and a new one always draws.
            now = time.time()
            if self.buddy_iconic_since and now - self.buddy_iconic_since > self.reuse_iconic and now - self.buddy_revived > 20:
                self.revive_companion(hwnd, tucked=True)
                return
            self.comp_tucked = True
            user32.ShowWindow(hwnd, SW_SHOWNOACTIVATE)
            time.sleep(0.2)               # (let the browser finish un-minimizing before it gets moved)
        elif user32.IsZoomed(hwnd):
            user32.ShowWindow(hwnd, SW_SHOWNOACTIVATE)
        self.place_companion(hwnd)
        if not alert and self.comp_tucked:
            threading.Thread(target=self.tuck_later, args=(hwnd, self.overlay_gen), daemon=True).start()

    def keep_alert_up(self):
        """Called every second: if it gets minimized while it's upset, it comes straight back."""
        hwnd = self.comp_hwnd
        if self.overlay_mode == "alert" and hwnd and user32.IsIconic(hwnd):
            threading.Thread(target=self.apply_overlay, daemon=True).start()

    def tuck_later(self, hwnd, gen):
        """It popped up for an alert while you had it minimized; once all is well, it goes back to the taskbar."""
        time.sleep(TUCK_AFTER)            # (long enough to read its "welcome back")
        while True:
            s = self.session
            if (gen != self.overlay_gen or not s or s.alert or not self.comp_tucked
                    or hwnd != self.comp_hwnd or not user32.IsWindow(hwnd)):
                return
            if user32.IsIconic(hwnd):     # you beat me to it
                self.comp_tucked = False
                return
            if user32.GetForegroundWindow() != hwnd:   # (not while you're still clicking around in it)
                break
            time.sleep(0.5)
        self.comp_tucked = False
        user32.ShowWindow(hwnd, SW_SHOWMINNOACTIVE)

    def place_companion(self, hwnd):
        s = window_scale(hwnd)
        left, top, right, bottom = work_area()
        if self.overlay_mode == "alert":
            w, h = min(int(620 * s), right - left - 20), min(int(560 * s), bottom - top - 20)
            place_topmost(hwnd, left + (right - left - w) // 2, top + (bottom - top - h) // 3, w, h)
        else:
            w, h = min(int(380 * s), right - left - 20), min(int(440 * s), bottom - top - 20)
            pos = self.save["settings"].get("comp_pos")
            if pos:
                x, y = pos
                x = min(max(left, x), right - w)
                y = min(max(top, y), bottom - h)
            else:
                x, y = right - w - int(16 * s), bottom - h - int(16 * s)
            place_topmost(hwnd, x, y, w, h)

    def remember_comp_pos(self):
        hwnd = self.comp_hwnd
        if (hwnd and user32.IsWindow(hwnd) and self.overlay_mode == "normal"
                and not user32.IsIconic(hwnd) and not user32.IsZoomed(hwnd)):   # (minimized windows sit at -32000)
            r = window_rect(hwnd)
            if r:
                self.save["settings"]["comp_pos"] = [r[0], r[1]]

    def buddy_stale(self, hwnd):
        """Called every second during a session: "revive" when the buddy window should be replaced with a fresh one,
        because it's up but its page hasn't checked in for a while (Edge freezes pages nobody clicks, and a page can
        crash), because the PC just woke up (windows can come back grey from sleep even with the page running), or
        because it's up and its page runs but draws nothing (is_dark); "restart" when that keeps happening."""
        now, iconic = time.time(), bool(user32.IsIconic(hwnd))
        if self.buddy_checked and now - self.buddy_checked > 60:
            self.buddy_woke = True               # (this loop runs every second, so a gap that long = the PC slept)
        if iconic and not self.buddy_iconic:
            self.buddy_iconic_since = now
        if not iconic and (self.buddy_iconic or not self.buddy_shown):
            self.buddy_shown = now               # (it just came up: it gets a moment to draw)
        # (a minimized page may only check in once a minute, and waking up takes a moment: don't judge it yet)
        if iconic or self.buddy_iconic or now - self.buddy_checked > 5:
            self.buddy_grace = max(self.buddy_grace, now + 12)
        self.buddy_iconic, self.buddy_checked = iconic, now
        if iconic or self.buddy_reviving:
            return False
        if now - self.buddy_revived > 15 and self.is_dark("buddy", hwnd, self.buddy_shown):
            return self.note_dark("the study buddy")
        if now - self.buddy_revived < 60:
            return False
        if self.buddy_woke:
            self.buddy_woke = False
            return "revive"
        return "revive" if now > self.buddy_grace and now - self.buddy_seen > BUDDY_STALE else False

    def revive_companion(self, old, tucked=False):
        """A fresh buddy window in place of a stuck one. The new one opens first: closing Edge's last window would
        shut Edge down, and Edge ignores a launch while it's shutting down. tucked: it goes back down to the taskbar
        once the alert it came up for is over (it was minimized)."""
        if not self.revive_lock.acquire(blocking=False):
            return                        # (one is on its way already)
        self.buddy_reviving, new = True, None
        try:
            self.buddy_revived = self.buddy_checked = time.time()
            self.buddy_grace = time.time() + 25
            self.pages["buddy"] = self.fresh_page()
            self.open_companion()
            new, t0 = None, time.time()
            while not new and time.time() - t0 < 12:
                time.sleep(0.4)
                new = next((h for h in find_windows(COMP_TITLE) if h != old), None)
            close_window(old)
            if new:
                self.comp_hwnd = new
                self.comp_tucked = tucked
                self.buddy_iconic, self.buddy_shown = False, time.time()
        finally:
            self.buddy_reviving = False
            self.revive_lock.release()
        if new:
            self.apply_overlay()

    # ---- black windows (see self.pages)
    @staticmethod
    def fresh_page():
        return {"seen": 0.0, "frames": -1, "painted": time.time(), "visible": True}

    def page_report(self, w, qs):
        """A page checking in (/api/state?w=buddy|hub&f=<frames drawn>&v=<1 if it thinks it's on screen>)."""
        p, now = self.pages[w], time.time()
        p["seen"] = now
        try:
            f = int(qs.get("f", ["-1"])[0])
        except ValueError:
            f = -1
        if f >= 0 and f != p["frames"]:
            if w not in self.debug_frozen:
                p["frames"], p["painted"] = f, now
            elif p["frames"] < 0:                # (test tooling: a frozen page reports once, then draws nothing more)
                p["frames"] = f
        p["visible"] = qs.get("v", ["1"])[0] == "1"

    def is_dark(self, w, hwnd, shown):
        """True when a window is up, its page is running (checking in), and yet it hasn't drawn a frame in a while:
        it's showing nothing but Edge's dark background. Only judged while you're at the computer (a sleeping screen
        draws nothing either), and not for a window on another virtual desktop."""
        p, now = self.pages[w], time.time()
        if p["frames"] < 0 or now - p["seen"] > 3 or now - shown < DARK_AFTER:
            return False                     # (a page that never said, a page that's gone quiet, a window just up)
        if (ACTIVITY.idle() > 30 and not self.debug_active) or cloaked(hwnd) or not user32.IsWindowVisible(hwnd):
            return False
        return now - p["painted"] > DARK_AFTER

    def note_dark(self, what):
        """A black window gets a fresh one in its place ("revive"). A second one soon after means Edge's graphics are
        stuck, and fresh windows won't draw either: Edge restarts without graphics acceleration ("restart")."""
        now = time.time()
        self.dark_times = [t for t in self.dark_times if now - t < 180] + [now]
        print(f"{what} window was black (up, but drawing nothing): replacing it")
        return "restart" if len(self.dark_times) >= 2 and not SAFE_RENDER[0] else "revive"

    def hub_dark(self):
        """Called every second: the main window's turn ("revive", "restart" or None, with its hwnd)."""
        hwnd = find_window(MAIN_TITLE)
        if not hwnd:
            self.hub_hwnd = None
            return None, None
        now, iconic = time.time(), bool(user32.IsIconic(hwnd))
        if not iconic and (self.hub_iconic or hwnd != self.hub_hwnd):
            self.hub_shown = now
        self.hub_iconic, self.hub_hwnd = iconic, hwnd
        if iconic or now - self.hub_revived < 15 or not self.is_dark("hub", hwnd, self.hub_shown):
            return None, None
        return self.note_dark("the main"), hwnd

    def revive_main(self, old):
        """A fresh main window in place of a black one (it opens first, so Edge never runs out of windows)."""
        self.hub_revived = time.time()
        self.pages["hub"] = self.fresh_page()
        self.launch_main()
        new, t0 = None, time.time()
        while not new and time.time() - t0 < 12:
            time.sleep(0.4)
            new = next((h for h in find_windows(MAIN_TITLE) if h != old), None)
        if new:
            close_window(old)
            self.hub_shown = time.time()

    def restart_edge(self):
        """Edge again from scratch, without graphics acceleration, after fresh windows came up black as well. It's
        remembered for this computer (settings.safe_render, which doesn't sync to your other devices)."""
        if self.edge_restarting or self.headless:
            return
        self.edge_restarting = True
        try:
            SAFE_RENDER[0] = True
            with self.lock:
                self.save["settings"]["safe_render"] = True
                self.dirty = True
                self.say("My windows stopped showing, so I restarted them in safe drawing mode. 🔧", "happy")
            hub = find_window(MAIN_TITLE)
            hub_down = bool(hub and user32.IsIconic(hub))
            self.close_windows()                  # (waits for Edge to quit: the flags only count when it starts)
            self.pages = {w: self.fresh_page() for w in ("buddy", "hub")}
            self.dark_times = []
            if self.session:
                self.comp_hwnd, self.comp_tucked = None, False
                self.open_companion()
            if hub or not self.session:
                self.launch_main()
                if hub_down:                      # (it was waiting in the taskbar: it goes back there)
                    t0 = time.time()
                    while time.time() - t0 < 12:
                        time.sleep(0.4)
                        h = find_window(MAIN_TITLE)
                        if h:
                            minimize(h)
                            break
        finally:
            self.edge_restarting = False

    def open_companion(self):
        if self.headless:
            return
        s = dpi_scale()
        left, top, right, bottom = work_area()
        w, h = min(int(380 * s), right - left - 20), min(int(440 * s), bottom - top - 20)
        open_app_window(f"http://127.0.0.1:{self.port}/companion.html", w, h, right - w - 16, bottom - h - 16)

    def open_main(self, tab=None):
        if self.headless:
            if tab:
                self.pending_tab = tab
            return
        hwnd = find_window(MAIN_TITLE)
        if hwnd:
            bring_to_front(hwnd)
            if tab:
                self.pending_tab = tab
            return
        pid = self.edge_pid
        if pid and not find_window(COMP_TITLE) and os.path.basename(process_path(pid)).lower() in BROWSER_EXES:
            wait_exit([pid], 5)           # its last window just closed: Edge ignores a launch while shutting down
        self.launch_main(tab)

    def launch_main(self, tab=None):
        """A new main window (open_main brings an open one up instead)."""
        s = dpi_scale()
        left, top, right, bottom = work_area()
        w, h = min(int(1180 * s), right - left - 40), min(int(800 * s), bottom - top - 40)
        url = f"http://127.0.0.1:{self.port}/" + (f"#{tab}" if tab else "")
        open_app_window(url, w, h, left + (right - left - w) // 2, top + (bottom - top - h) // 2)

    def close_windows(self):
        """Close our windows and wait until they, and the Edge behind them, are gone, so the copy taking over
        opens fresh ones. (Edge ignores a launch that arrives while it's still shutting down.)"""
        if self.headless:
            return
        pids, t0 = set(), time.time()
        while time.time() - t0 < 3:
            still = [h for h in (find_window(MAIN_TITLE), find_window(COMP_TITLE)) if h]
            if not still:
                break
            for h in still:
                pids.add(window_pid(h))
                close_window(h)
            time.sleep(0.2)
        wait_exit(pids - {0, OWN_PID}, 5)

    # ---- session control
    def start_session(self, quest_id, pledge, paper, habit_id=None, carry=None, came_from=None):
        if self.session or self.quitting:
            return
        self.summary = None
        self.session = Session(self, quest_id, pledge, paper, habit_id)
        if datetime.datetime.now().hour < 17:
            self.day()["early"] = 1
        h = self.session.habit()
        if isinstance(carry, dict):              # (handed over from another device)
            self.session.apply_carry(carry)
            mins = self.session.focus_s // 60
            self.say(f"Picking up where you left off on your {str(came_from or 'other device')[:30]}! "
                     + (f"{mins} minute{'' if mins == 1 else 's'} in so far." if mins else "Let's keep going."), "happy", "start")
        elif h:
            left = -(-(h["goal_min"] * 60 - h.get("log", {}).get(today_str(), 0)) // 60)   # (minutes, rounded up)
            self.say(f"{h['emoji']} {h['title']} time! " + (f"{left} minute{'' if left == 1 else 's'} to go today. I'll keep you on it."
                     if left > 0 else "Today's goal is already done, so this is bonus time. Nice!"), "happy", "start")
        else:
            self.say(random.choice(START_LINES), "happy", "start")
        self.overlay_mode = "normal"
        self.comp_hwnd = None
        self.comp_tucked = False
        self.open_companion()
        main = None if self.headless else find_window(MAIN_TITLE)
        if main:
            minimize(main)

    def drop_session(self):
        """The session moved to another device (it was handed off), so it just stops here: no summary and no log
        entry, since the other device finishes it. Its seconds so far stay counted here (sync shares them)."""
        if not self.session:
            return False
        self.remember_comp_pos()
        self.session = None
        self.overlay_mode = "normal"
        if self.comp_hwnd and user32.IsWindow(self.comp_hwnd) and not self.headless:
            close_window(self.comp_hwnd)
        self.comp_hwnd = None
        self.dirty = True
        self.say("Your focus session moved to your other device. 👋", "happy")
        return True

    # ---- syncing with your other devices (web/js/sync.js does the merging, encryption and GitHub part)
    def shared_save(self):
        """The save as it's shared with your other devices: all of it but the parts that stay here (SYNC_LOCAL)."""
        return {k: v for k, v in json.loads(json.dumps(self.save)).items() if k not in SYNC_LOCAL}

    def apply_synced(self, incoming):
        """Takes in the save as merged with your other devices', keeping what belongs to this device: SYNC_LOCAL,
        the buddy window's spot, and the files attached here (the files themselves don't sync)."""
        if not isinstance(incoming, dict):
            return False
        save, defaults = self.save, default_save()
        for k, v in incoming.items():
            if k in SYNC_LOCAL or k not in defaults:
                continue
            d = defaults[k]
            if d is not None and not isinstance(v, type(d)) and not (
                    isinstance(d, (int, float)) and isinstance(v, (int, float)) and not isinstance(v, bool)):
                continue
            if k == "quests":
                mine = {q.get("id"): q.get("files", []) for q in save["quests"]}
                v = [q for q in v if isinstance(q, dict) and isinstance(q.get("steps"), list)]
                for q in v:
                    q["files"] = mine.get(q.get("id"), [f for f in q.get("files") or []
                                                        if isinstance(f, dict) and self.find_file(f.get("id"))[0]])
            elif k == "settings":
                v = dict(v)
                for kk in ("comp_pos", "desktop_shortcut_done", "safe_render"):   # (this computer's own)
                    if kk in save["settings"]:
                        v[kk] = save["settings"][kk]
            save[k] = v
        self.dirty = True
        return True

    def end_session(self):
        if not self.session:
            return None
        self.remember_comp_pos()
        summary = self.session.finish()
        self.session = None
        self.summary = summary
        if self.comp_hwnd and user32.IsWindow(self.comp_hwnd) and not self.headless:
            close_window(self.comp_hwnd)
        self.comp_hwnd = None
        self.dirty = True
        threading.Thread(target=self.open_main, daemon=True).start()
        return summary

    # ---- daily quests & streak
    def daily(self):
        t = today_str()
        d = self.save["daily"]
        if d.get("date") != t:
            rng = random.Random(t)
            work = ["focus30", "focus60", "steps3", "steps5", "clean", "early"]
            pick = rng.sample(work, 2)
            if "focus30" in pick and "focus60" in pick:
                pick = ["focus30", rng.choice(["steps3", "clean", "early"])]
            if "steps3" in pick and "steps5" in pick:
                pick = ["steps3", rng.choice(["focus30", "clean", "early"])]
            pick.append(rng.choice(["battles3", "blocks2"]))
            d = self.save["daily"] = {"date": t, "tasks": pick, "claimed": [], "bonus": False}
        day = self.day()
        tasks = []
        for tid in d["tasks"]:
            text, metric, goal, reward = DAILY_POOL[tid]
            prog = min(goal, day.get(metric, 0))
            tasks.append({"id": tid, "text": text, "progress": prog, "goal": goal, "reward": reward,
                          "done": prog >= goal, "claimed": tid in d["claimed"],
                          "minutes": metric == "focus"})
        return {"tasks": tasks, "bonus_claimed": d["bonus"], "all_claimed": len(d["claimed"]) == len(d["tasks"])}

    def streak(self):
        days = self.save["days"]
        d = datetime.date.today()
        if days.get(today_str(d), {}).get("focus", 0) < DAY_COUNTS_AT:
            d -= datetime.timedelta(days=1)
        n = 0
        while days.get(today_str(d), {}).get("focus", 0) >= DAY_COUNTS_AT:
            n += 1
            d -= datetime.timedelta(days=1)
        return n

    def give(self, reward):
        for k, v in reward.items():
            self.save[k] = self.save.get(k, 0) + v

    # ---- study cards (the Study tab). Each card has a box for how well you know it, and a day it's due back.
    def study_add(self, raw, quest_id=None, deck="", by="you"):
        """New cards for an assignment's deck (or a deck of your own, by name). They're due right away."""
        st = self.save["study"]
        q = self.quest(quest_id) if quest_id is not None else None
        deck = (q["title"] if q else str(deck or "").strip()[:80]) or "My cards"
        added = []
        for r in (raw or [])[:30]:
            c = clean_card(r)
            if not c:
                continue
            c.update(id=new_id(), quest=q["id"] if q else None, deck=deck, by=str(by)[:10], box=0,
                     due=today_str(), made=today_str(), right=0, wrong=0)
            st["next_id"] += 1
            st["cards"].append(c)
            added.append(c)
        return added

    def study_light(self, n):
        """Light from studying, at most STUDY_DAY_CAP a day."""
        days = self.save["study"].setdefault("days", {})
        today = today_str()
        got = max(0, min(n, STUDY_DAY_CAP - days.get(today, 0)))
        if got:
            days[today] = days.get(today, 0) + got
            self.save["light"] += got
            self.save["stats"]["light_earned"] += got
            for old in sorted(days)[:-30]:       # (only the last month matters)
                del days[old]
        return got

    def study_answer(self, cid, right, first):
        """A card answered in a study battle. Right on a card that's due moves it up a box, so it comes back later
        each time (a brand-new card you knew on the first try skips ahead to 3 days), and earns 1 Light. Wrong drops
        it back to box 0: due again right away. Practicing a card before it's due leaves its schedule alone, unless
        you got it wrong."""
        c = next((x for x in self.save["study"]["cards"] if x["id"] == cid), None)
        if not c:
            return {"ok": False}
        today = datetime.date.today()
        due = c["due"] <= today_str(today)
        light = 0
        if right:
            c["right"] += 1
            if due:
                c["box"] = (2 if first else 1) if c["box"] == 0 else min(c["box"] + 1, len(STUDY_INTERVALS) - 1)
                c["due"] = today_str(today + datetime.timedelta(days=STUDY_INTERVALS[c["box"]]))
                light = self.study_light(1)
                t = self.save["study"].setdefault("tally", {}).setdefault(today_str(today), {"due": 0, "paid": 0})
                t["due"] += 1
        else:
            c["wrong"] += 1
            c["box"] = 0
            c["due"] = today_str(today)
        c["seen"] = today_str(today)
        day = self.day()
        day["cards"] = day.get("cards", 0) + 1
        return {"ok": True, "card": c, "light": light, "wallet": self.save["light"]}

    def study_win(self):
        """A won battle's bonus: only when 4 or more due cards were answered right since the last one."""
        st = self.save["study"]
        today = today_str()
        t = st.get("tally", {}).get(today, {"due": 0, "paid": 0})
        st["tally"] = {today: t}
        if t["due"] - t["paid"] < 4:
            return 0
        t["paid"] = t["due"]
        return self.study_light(STUDY_WIN_LIGHT)

    def study_summary(self):
        cards, today = self.save["study"]["cards"], today_str()
        return {"cards": len(cards), "due": sum(1 for c in cards if c["due"] <= today)}

    def study_material(self, quest_id, deck):
        """A deck's cards as text, for Teach Wick: (title, text, number of cards)."""
        q = self.quest(quest_id) if quest_id is not None else None
        cards = [c for c in self.save["study"]["cards"]
                 if (c.get("quest") == quest_id if quest_id is not None else (c.get("quest") is None and c.get("deck") == deck))]
        deck = cards[0]["deck"] if cards and not deck else deck
        lines = []
        for c in cards[:40]:
            ans = c["options"][c["answer"]] if c["type"] == "mc" else c["answer"]
            lines.append(f"- {c['q']} -> {ans}" + (f" (from: \"{c['source']}\")" if c.get("source") else ""))
        text = "\n".join(lines)[:9000]
        if q and q.get("details"):
            text += f"\n\nThe assignment's description: {q['details'][:1500]}"
        return (q["title"] if q else deck or "My cards"), text, len(cards)

    # ---- state for the UI
    def state(self):
        st = self.streak()
        day = self.day()
        return {
            "now": time.time(), "port": self.port,
            "wallet": {"light": self.save["light"], "coins": self.save["coins"], "star_pieces": self.save["star_pieces"]},
            "session": self.session.to_json() if self.session else None,
            "speech": self.speech, "summary": self.summary, "overlay": self.overlay_mode,
            "daily": self.daily(), "streak": st,
            "streak_rewards": [{"days": n, "reward": r, "claimed": n in self.save["streak_claimed"], "ready": st >= n}
                               for n, r in STREAK_REWARDS.items()],
            "today": day, "stats": self.save["stats"], "quests": self.save["quests"], "settings": self.save["settings"],
            "habits": [self.habit_view(h) for h in self.save["habits"]],
            "bond": self.save["bond"], "chests": self.save["chests"],
            "ai": {"status": self.ai.status, "detail": self.ai.detail, "enabled": self.save["settings"].get("ai_checks", True)},
            "log": self.save["session_log"][-10:],
            "pending_tab": getattr(self, "pending_tab", None),
            "update": self.updater.json(),
            "study": self.study_summary(),
        }

    def persist(self):
        with self.lock:
            if not self.dirty:
                return
            data = json.loads(json.dumps(self.save))
            self.dirty = False
        try:
            write_save(data)
        except Exception as e:
            print("save failed:", e)


GAME = None
DEBUG_FG = None      # test tooling: pretend this window is in front
DEBUG_IDLE = None    # test tooling: pretend this many idle seconds


# ---------------------------------------------------------------- HTTP API
class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = self.path.split("?")[0].split("#")[0]
        g = GAME
        if path == "/api/ping":
            return self.send_json({"ok": True, "app": "lantern-delve", "stamp": CODE_STAMP,
                                   "session": bool(g.session), "pid": OWN_PID})
        if path == "/api/state":
            # (the main window says which tab it's on: time in the Study tab counts as focus, see classify)
            qs = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            tab = qs.get("tab", [""])[0]
            if tab:
                g.hub_tab, g.hub_tab_t = tab[:20], time.time()
            w = qs.get("w", [""])[0]
            if w == "buddy" and not g.buddy_mute:   # (the buddy page checking in: see buddy_stale)
                g.buddy_seen = time.time()
                g.page_report("buddy", qs)
            elif w == "hub":                    # (the main window: is it drawing? see hub_dark)
                g.page_report("hub", qs)
            with g.lock:
                return self.send_json(g.state())
        if path == "/api/adventure":
            with g.lock:
                return self.send_json({"data": g.save.get("adventure")})
        if path == "/api/study":
            with g.lock:
                st, today = g.save["study"], today_str()
                return self.send_json({"cards": st["cards"], "today": today, "light_today": st["days"].get(today, 0),
                                       "cap": STUDY_DAY_CAP, "ai": g.ai.status == "ready"})
        if path in ("/api/sync/export", "/api/sync/config", "/api/session/carry"):   # (for sync.js, in our own pages)
            if self.headers.get("X-Lantern") != "app":
                return self.send_json({"ok": False}, 403)
            with g.lock:
                if path == "/api/sync/export":
                    return self.send_json({"ok": True, "save": g.shared_save()})
                if path == "/api/sync/config":
                    return self.send_json({"ok": True, "config": g.save.get("sync")})
                return self.send_json({"ok": True, "carry": g.session.carry() if g.session else None})
        if path == "/api/files/raw":             # a homework file's bytes, for the Study tab to read without Claude
            if self.headers.get("X-Lantern") != "app":
                return self.send_json({"ok": False}, 403)
            fid = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query).get("id", [""])[0]
            with g.lock:
                p, info = g.find_file(fid)
            if not p or not os.path.isfile(p) or os.path.getsize(p) > MAX_FILE:
                self.send_error(404)
                return
            with open(p, "rb") as f:
                body = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if path == "/":
            path = "/index.html"
        full = os.path.normpath(os.path.join(WEB_DIR, path.lstrip("/")))
        if not full.startswith(WEB_DIR) or not os.path.isfile(full):
            self.send_error(404)
            return
        ctype = {".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".png": "image/png",
                 ".svg": "image/svg+xml", ".json": "application/json", ".ico": "image/x-icon"}.get(
            os.path.splitext(full)[1], "application/octet-stream")
        with open(full, "rb") as f:
            body = f.read()
        self.send_response(200)
        self.send_header("Content-Type", ctype + ("; charset=utf-8" if ctype.startswith("text") else ""))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def upload(self):
        """A homework file, sent as raw bytes (?name=...). It waits in the _new folder until it's attached."""
        if self.headers.get("X-Lantern") != "app":   # (web pages elsewhere can't send this header)
            return self.send_json({"ok": False}, 403)
        n = int(self.headers.get("Content-Length") or 0)
        if n > MAX_FILE:
            self.close_connection = True
            return self.send_json({"ok": False, "error": f"That file is too big (the limit is {MAX_FILE >> 20} MB)."})
        name = safe_name(urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query).get("name", ["file"])[0])
        fid = os.urandom(6).hex()
        folder = os.path.join(FILES_DIR, "_new", fid)
        os.makedirs(folder, exist_ok=True)
        left = n
        with open(os.path.join(folder, name), "wb") as f:
            while left > 0:
                chunk = self.rfile.read(min(left, 1 << 20))
                if not chunk:
                    break
                f.write(chunk)
                left -= len(chunk)
        if left:
            shutil.rmtree(folder, ignore_errors=True)
            return self.send_json({"ok": False, "error": "The upload got cut off. Try again?"})
        return self.send_json({"ok": True, "file": {"id": fid, "name": name, "size": n}})

    def do_POST(self):
        path = self.path.split("?")[0]
        g = GAME
        if path == "/api/files/upload":          # (raw bytes, not JSON)
            return self.upload()
        n = int(self.headers.get("Content-Length") or 0)
        try:
            body = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            body = {}
        if path == "/api/debug/shot" and os.environ.get("LANTERN_DEBUG"):  # test tooling only
            import base64
            name = re.sub(r"[^a-z0-9_-]", "", str(body.get("name", "shot")).lower()) or "shot"
            out = os.path.join(os.environ["LANTERN_DEBUG"], name + ".png")
            with open(out, "wb") as f:
                f.write(base64.b64decode(str(body.get("data", "")).split(",", 1)[-1]))
            return self.send_json({"ok": True})
        # (test tooling only: headless test servers, and real-window tests of a scratch copy on a hidden desktop)
        if path == "/api/debug/fg" and os.environ.get("LANTERN_DEBUG") and (g.headless or "scratch-workspaces" in HERE.lower()):
            global DEBUG_FG, DEBUG_IDLE
            t = body.get("title")
            DEBUG_FG = Fg(1, t, body.get("exe", "chrome.exe"), "c:\\fake\\" + body.get("exe", "chrome.exe"), 1) if t else None
            DEBUG_IDLE = body.get("idle")
            return self.send_json({"ok": True})
        if path == "/api/debug/offline" and os.environ.get("LANTERN_DEBUG") and g.headless:  # test tooling only
            _ONLINE.update(t=time.time() + 86400 if body.get("on") else 0.0, ok=not body.get("on"))
            return self.send_json({"ok": True})
        if path == "/api/debug/buddy" and os.environ.get("LANTERN_DEBUG"):   # test tooling only (a real-window test)
            if "mute" in body:
                g.buddy_mute = bool(body["mute"])
            if body.get("sleep"):                # pretend the PC just slept
                g.buddy_checked = time.time() - 120
            now = time.time()
            return self.send_json({"ok": True, "hwnd": g.comp_hwnd or 0, "seen_ago": round(now - g.buddy_seen, 1),
                                   "revived_ago": round(now - g.buddy_revived, 1) if g.buddy_revived else None})
        if path == "/api/debug/dark" and os.environ.get("LANTERN_DEBUG"):    # test tooling only: black windows
            for w in ("buddy", "hub"):           # freeze: its frames stop counting, as if it drew nothing
                if w in body:
                    (g.debug_frozen.add if body[w] else g.debug_frozen.discard)(w)
            if "active" in body:
                g.debug_active = bool(body["active"])
            if body.get("reset"):
                g.dark_times = []
            if "reuse_iconic" in body:
                g.reuse_iconic = float(body["reuse_iconic"])
            now = time.time()
            return self.send_json({"ok": True, "safe_render": SAFE_RENDER[0], "dark_times": len(g.dark_times),
                                   "hub_revived_ago": round(now - g.hub_revived, 1) if g.hub_revived else None,
                                   "pages": {w: {"frames": p["frames"], "painted_ago": round(now - p["painted"], 1),
                                                 "seen_ago": round(now - p["seen"], 1), "visible": p["visible"]}
                                             for w, p in g.pages.items()}})
        # slow calls (Claude) happen outside the lock
        if path == "/api/breakdown":
            title, details = str(body.get("title", "")), str(body.get("details", ""))
            with g.lock:
                found = [g.find_file(f.get("id") if isinstance(f, dict) else f) for f in (body.get("files") or [])[:10]]
            files = [(p, f["name"]) for p, f in found if p and os.path.isfile(p)]
            if g.ai.status == "ready":
                try:
                    return self.send_json({"steps": g.ai.breakdown(title, details, files),
                                           "note": f"Steps written by Claude{' from your files' if files else ''}. "
                                                   "Edit anything you want."})
                except Exception as e:
                    note = f"Claude didn't answer ({type(e).__name__}), so here's the built-in breakdown."
            else:
                note = ("Built-in breakdown. (Connect Claude in Settings and it reads your files to write the steps.)"
                        if files else "Built-in breakdown. (Connect Claude in Settings for custom AI steps.)")
            words = " ".join(file_text(p, 3000) for p, _ in files)
            return self.send_json({"steps": template_steps(title, f"{details} {words}"), "note": note})
        if path == "/api/study/make":            # Claude writes practice questions (from the assignment's files)
            notes = str(body.get("notes", ""))[:20000]
            with g.lock:
                q = g.quest(body.get("quest")) if body.get("quest") is not None else None
                title = q["title"] if q else str(body.get("topic", "")).strip()[:120]
                details = q.get("details", "") if q else ""
                found = [g.find_file(f.get("id")) for f in (q.get("files", []) if q else [])[:10]]
            files = [(p, f["name"]) for p, f in found if p and os.path.isfile(p)]
            if not title:
                return self.send_json({"ok": False, "error": "Pick an assignment or type a topic first."})
            off = study_ai_off(g)
            if off:
                return self.send_json(off)
            try:
                count = max(3, min(12, int(body.get("count") or 8)))
                raw = g.ai.make_cards(title, details, files, notes, count)
            except Exception as e:
                return self.send_json({"ok": False, "fallback": True, "error": f"Claude didn't answer ({type(e).__name__})."})
            with g.lock:
                added = g.study_add(raw, q["id"] if q else None, title, "claude")
                g.dirty = True
            if not added:
                return self.send_json({"ok": False, "error": "Claude's questions came back empty. Try again, or paste some notes."})
            return self.send_json({"ok": True, "cards": added, "files": len(files)})
        if path == "/api/study/unstuck":         # Unstuck: Claude reads the problem (or finds it in the files) and writes hints
            where, problem, work = (str(body.get(k, ""))[:n] for k, n in (("where", 300), ("problem", 6000), ("work", 4000)))
            with g.lock:
                q = g.quest(body.get("quest")) if isinstance(body.get("quest"), int) else None
                found = [g.find_file(f.get("id")) for f in (q.get("files", []) if q else [])[:10]]
            files = [(p, f["name"]) for p, f in found if p and os.path.isfile(p)]
            off = study_ai_off(g)
            if off:
                return self.send_json(off)
            if not problem.strip() and not (files and where.strip()):
                return self.send_json({"ok": False, "error": "Paste the problem, or say which one it is (like \"problem 3b\") if it's in the assignment's files."})
            try:
                return self.send_json({"ok": True, **g.ai.unstuck(q["title"] if q else "", files, where, problem, work)})
            except Exception as e:
                return self.send_json({"ok": False, "fallback": True, "error": f"Claude didn't answer ({type(e).__name__})."})
        if path == "/api/study/unstuck/check":   # checking an answer, without giving the real one away
            problem, work, answer = (str(body.get(k, ""))[:n] for k, n in (("problem", 6000), ("work", 4000), ("answer", 500)))
            off = study_ai_off(g)
            if off:
                return self.send_json(off)
            if not problem.strip() or not answer.strip():
                return self.send_json({"ok": False, "error": "Type your answer first."})
            try:
                res = g.ai.check_answer(problem, work, answer)
            except Exception as e:
                return self.send_json({"ok": False, "error": f"Wick couldn't check it just now ({type(e).__name__}). Try again in a minute."})
            light = 0
            if res["verdict"] == "right":        # (solving it yourself earns a little Light, within the day's study cap)
                with g.lock:
                    light = g.study_light(2)
                    g.dirty = True
            return self.send_json({"ok": True, **res, "light": light})
        if path in ("/api/study/teach/start", "/api/study/teach/check"):   # Teach Wick, with Claude playing Wick
            quest = body.get("quest") if isinstance(body.get("quest"), int) else None
            with g.lock:
                title, material, n = g.study_material(quest, str(body.get("deck", ""))[:80])
            off = study_ai_off(g)
            if off:
                return self.send_json(off)
            if not n:
                return self.send_json({"ok": False, "error": "This deck has no cards for Wick to learn from yet."})
            try:
                if path.endswith("start"):
                    return self.send_json({"ok": True, **g.ai.teach_start(title, material, str(body.get("concept", ""))[:120])})
                ideas = [str(x)[:160] for x in (body.get("ideas") or [])][:5]
                turns = [t for t in (body.get("turns") or []) if isinstance(t, dict)][-8:]
                convo = "\n".join([f"Wick: {str(body.get('ask', ''))[:400]}"]
                                  + [f"{'Student' if t.get('who') == 'you' else 'Wick'}: {str(t.get('text', ''))[:2000]}" for t in turns])
                return self.send_json({"ok": True, **g.ai.teach_check(str(body.get("concept", ""))[:120], ideas, material, convo)})
            except Exception as e:
                return self.send_json({"ok": False, "fallback": True, "error": f"Claude didn't answer ({type(e).__name__})."})
        if path == "/api/files/open":
            if self.headers.get("X-Lantern") != "app":
                return self.send_json({"ok": False}, 403)
            with g.lock:
                p, _ = g.find_file(body.get("id"))
            if not p or not os.path.isfile(p):
                return self.send_json({"ok": False, "error": "That file is missing."})
            if not g.headless:                   # (tests never open real windows)
                open_file(p)
            return self.send_json({"ok": True})
        if path == "/api/ai/recheck":
            g.ai.refresh_status()
            return self.send_json({"status": g.ai.status, "detail": g.ai.detail})
        if path == "/api/ai/login":
            return self.send_json({"ok": g.ai.login()})
        if path == "/api/show":
            g.pending_tab = body.get("tab")
            threading.Thread(target=g.open_main, args=(body.get("tab"),), daemon=True).start()
            return self.send_json({"ok": True})
        if path == "/api/update/restart":        # "Restart now" for a downloaded update
            if self.headers.get("X-Lantern") != "app":
                return self.send_json({"ok": False}, 403)
            if g.session or not staged_update():
                return self.send_json({"ok": False})
            # a fresh launch takes over from this copy, installs the update and starts the new version
            subprocess.Popen([sys.executable, os.path.join(HERE, "lantern_delve.py")] + (["--no-window"] if g.headless else []),
                             cwd=HERE, creationflags=NO_WINDOW)
            return self.send_json({"ok": True})
        if path == "/api/quit":                  # a newer copy is starting and wants the port (see take_over)
            if self.headers.get("X-Lantern") != "launcher":   # (web pages can't send this header, so they can't close the app)
                return self.send_json({"ok": False}, 403)
            if g.session:
                return self.send_json({"ok": False, "session": True})
            g.close_windows()
            self.send_json({"ok": True})
            g.quitting = True                    # (the main loop saves and exits)
            g.wake.set()
            return
        with g.lock:
            g.dirty = True
            res = self.route(g, path, body)
        if res is None:
            self.send_error(404)
        else:
            self.send_json(res)

    def route(self, g, path, b):
        s = g.session
        save = g.save
        if path == "/api/session/start":
            g.start_session(b.get("quest_id"), bool(b.get("pledge")), bool(b.get("paper")), b.get("habit_id"),
                            b.get("carry"), b.get("from"))
            return {"ok": True}
        if path == "/api/session/drop":          # it carried on on another device (sync.js)
            return {"ok": g.drop_session()}
        if path == "/api/sync/import":           # the save, merged with the other devices' (sync.js)
            return {"ok": g.apply_synced(b.get("save"))}
        if path == "/api/sync/config":           # sync's own settings and state, kept on this device only
            if b.get("config") is None:
                save.pop("sync", None)
            elif isinstance(b.get("config"), dict):
                save["sync"] = {**(save.get("sync") or {}), **b["config"]}
            return {"ok": True}
        if path == "/api/session/end":
            return {"summary": g.end_session()}
        if path == "/api/summary/ack":
            g.summary = None
            return {"ok": True}
        if path == "/api/tab/ack":
            g.pending_tab = None
            return {"ok": True}
        if not path.startswith("/api/session/"):
            return self.route_other(g, path, b)
        if not s:
            return {"ok": False, "error": "no session"}
        if path == "/api/session/step":
            return s.step_done()
        if path == "/api/session/break":
            s.start_break()
            return {"ok": True}
        if path == "/api/session/resume":
            s.resume()
            return {"ok": True}
        if path == "/api/session/extend":
            return {"ok": s.extend_break()}
        if path == "/api/session/idle":
            s.idle_answer(b.get("answer"))
            return {"ok": True}
        if path == "/api/session/reason":
            return s.give_reason(str(b.get("text", "")))
        if path == "/api/session/offtask":
            return s.offtask_answer(b.get("answer"), str(b.get("text", "")))
        return None

    def route_other(self, g, path, b):
        save = g.save
        if path == "/api/adventure":
            save["adventure"] = b.get("data")
            return {"ok": True}
        if path == "/api/light/spend":
            n = max(0, int(b.get("n", 1)))
            if save["light"] < n:
                return {"ok": False, "light": save["light"]}
            save["light"] -= n
            return {"ok": True, "light": save["light"]}
        if path == "/api/wallet":
            coins, stars = int(b.get("coins", 0)), int(b.get("star_pieces", 0))
            if save["coins"] + coins < 0 or save["star_pieces"] + stars < 0:
                return {"ok": False, "wallet": {"coins": save["coins"], "star_pieces": save["star_pieces"]}}
            save["coins"] += coins
            save["star_pieces"] += stars
            return {"ok": True, "wallet": {"light": save["light"], "coins": save["coins"], "star_pieces": save["star_pieces"]}}
        if path == "/api/event":
            kind = b.get("type")
            if kind in ("battles", "blocks"):
                g.day()[kind] += int(b.get("n", 1))
            return {"ok": True}
        if path == "/api/quests/save":
            q = b.get("quest") or {}
            steps = [{"text": str(st.get("text", ""))[:300], "done": bool(st.get("done"))}
                     for st in q.get("steps", []) if str(st.get("text", "")).strip()]
            if not str(q.get("title", "")).strip() or not steps:
                return {"ok": False, "error": "Needs a name and at least one step."}
            existing = g.quest(q.get("id")) if q.get("id") else None
            if not existing:
                existing = {"id": new_id(), "done": False}
                save["next_id"] += 1
                save["quests"].append(existing)
            existing.update(title=str(q["title"])[:120], details=str(q.get("details", ""))[:4000], steps=steps,
                            done=all(st["done"] for st in steps))
            # the due date: due_at ("YYYY-MM-DDTHH:MM", local time) or None for no due date; the old free text
            # ("Mon 7pm") is only kept for assignments that haven't been given a real date yet
            if "due_at" in q:
                existing["due_at"] = valid_due(q.get("due_at"))
                existing["due"] = ""
            else:
                existing["due"] = str(q.get("due", ""))[:60]
            if "files" in q:                     # the editor sends its whole file list
                g.attach_files(existing, file_ids(q.get("files")), replace=True)
            return {"ok": True, "id": existing["id"]}
        if path == "/api/quests/due":            # setting (or clearing) just the due date, in one click
            q = g.quest(b.get("id"))
            if not q:
                return {"ok": False}
            q["due_at"] = valid_due(b.get("due_at"))
            q["due"] = ""
            return {"ok": True}
        if path == "/api/quests/delete":
            q = g.quest(b.get("id"))
            if q and not (g.session and g.session.quest_id == q["id"]):
                save["quests"].remove(q)
                g.remove_quest_files(q)
            return {"ok": True}
        if path == "/api/habits/save":           # a new habit, or changes to one (its minutes so far stay)
            new = clean_habit(b.get("habit"))
            if not new:
                return {"ok": False, "error": "It needs a name."}
            h = g.habit((b.get("habit") or {}).get("id"))
            if not h:
                h = {"id": new_id(), "log": {}, "made": today_str(), "best": 0}
                save["next_habit"] += 1
                save["habits"].append(h)
            h.update(new)
            return {"ok": True, "id": h["id"]}
        if path == "/api/habits/mark":           # ✓ done today without a focus session, or taking that back
            h = g.habit(b.get("id"))
            return g.mark_habit(h, b.get("done", True) is not False) if h else {"ok": False}
        if path == "/api/quests/finish":         # ✓ Mark finished: every step checked off, no session needed
            q = g.quest(b.get("id"))
            if not q:
                return {"ok": False}
            for st in q["steps"]:
                st["done"] = True
            q["done"] = True
            return {"ok": True}
        if path == "/api/habits/delete":
            h = g.habit(b.get("id"))
            if not h:
                return {"ok": False}
            if g.session and g.session.habit_id == h["id"]:
                return {"ok": False, "error": "End its focus session first."}
            save["habits"].remove(h)
            save["allow"].pop(f"h{h['id']}", None)
            return {"ok": True}
        if path == "/api/quests/attach":         # 📎 on an assignment: add files right away
            q = g.quest(b.get("id"))
            if not q:
                return {"ok": False}
            g.attach_files(q, file_ids(b.get("files")))
            return {"ok": True, "files": q["files"]}
        if path == "/api/quests/detach":
            q = g.quest(b.get("id"))
            if not q:
                return {"ok": False}
            g.attach_files(q, [f["id"] for f in q.get("files", []) if f["id"] != str(b.get("file"))], replace=True)
            return {"ok": True, "files": q["files"]}
        if path == "/api/quests/toggle":
            q = g.quest(b.get("id"))
            i = int(b.get("index", -1))
            if q and 0 <= i < len(q["steps"]):
                q["steps"][i]["done"] = not q["steps"][i]["done"]
                q["done"] = all(st["done"] for st in q["steps"])
            return {"ok": True}
        if path == "/api/settings":
            st = save["settings"]
            for k in ("idle_minutes", "checkin_minutes"):
                if k in b:
                    st[k] = max(0 if k == "checkin_minutes" else 1, min(120, int(b[k])))
            for k in ("auto_minimize", "ai_checks", "sound", "music", "safe_render"):   # (safe_render: next start)
                if k in b:
                    st[k] = bool(b[k])
            for k in ("music_vol", "study_vol"):
                if k in b:
                    st[k] = max(0, min(100, int(b[k])))
            if b.get("study_music") in ("lofi", "piano", "rain", "funk", "off"):
                st["study_music"] = b["study_music"]
            if "extra_block" in b:
                st["extra_block"] = [str(w).strip()[:60] for w in b["extra_block"] if str(w).strip()][:100]
            return {"ok": True}
        if path == "/api/daily/claim":
            d = g.daily()
            t = next((t for t in d["tasks"] if t["id"] == b.get("id")), None)
            if t and t["done"] and not t["claimed"]:
                save["daily"]["claimed"].append(t["id"])
                g.give(t["reward"])
                return {"ok": True, "reward": t["reward"]}
            return {"ok": False}
        if path == "/api/daily/bonus":
            d = g.daily()
            if d["all_claimed"] and not d["bonus_claimed"]:
                save["daily"]["bonus"] = True
                reward = {"star_pieces": 1, "light": 10}
                g.give(reward)
                return {"ok": True, "reward": reward}
            return {"ok": False}
        if path == "/api/streak/claim":
            n = int(b.get("days", 0))
            if n in STREAK_REWARDS and n not in save["streak_claimed"] and g.streak() >= n:
                save["streak_claimed"].append(n)
                g.give(STREAK_REWARDS[n])
                return {"ok": True, "reward": STREAK_REWARDS[n]}
            return {"ok": False}
        if path == "/api/chests/open":
            kind = b.get("kind")
            if kind in ("study", "golden") and save["chests"].get(kind, 0) > 0:
                save["chests"][kind] -= 1
                return {"ok": True, "chests": save["chests"]}
            return {"ok": False, "chests": save["chests"]}
        if path == "/api/shortcuts":
            threading.Thread(target=install_shortcuts, args=(True,), daemon=True).start()
            return {"ok": True}
        if path == "/api/reset_adventure":
            save["adventure"] = None
            return {"ok": True}
        # ---- the Study tab
        if path == "/api/study/add":             # cards you wrote yourself (or made from your notes without Claude)
            added = g.study_add(b.get("cards") or [], b.get("quest"), str(b.get("deck", "")), b.get("by", "you"))
            return {"ok": bool(added), "cards": added}
        if path == "/api/study/answer":
            try:
                cid = int(b.get("id"))
            except (TypeError, ValueError):
                return {"ok": False}
            return g.study_answer(cid, bool(b.get("right")), bool(b.get("first")))
        if path == "/api/study/win":
            return {"light": g.study_win(), "wallet": save["light"]}
        if path == "/api/study/teach/reward":    # Light for ideas explained to Wick: new ones, and +2 for all of them
            def num(k):
                try:
                    return max(0, min(5, int(b.get(k) or 0)))
                except (TypeError, ValueError):
                    return 0
            total = num("total")
            got, prev = min(num("got"), total), min(num("prev"), total)
            n = max(0, got - prev) + (2 if total and got >= total > prev else 0)
            return {"light": g.study_light(n) if n else 0, "wallet": save["light"]}
        if path == "/api/study/edit":            # fixing a card (its question and answers); its schedule stays
            c = next((x for x in save["study"]["cards"] if x["id"] == b.get("id")), None)
            new = clean_card(b.get("card"))
            if not c or not new:
                return {"ok": False}
            for k in ("options", "accept"):
                c.pop(k, None)
            c.update(new)
            return {"ok": True, "card": c}
        if path == "/api/study/delete":          # one card ({id}), or a whole deck ({quest} or {deck} by name)
            st = save["study"]
            if b.get("id") is not None:
                st["cards"] = [c for c in st["cards"] if c["id"] != b.get("id")]
            elif b.get("quest") is not None:
                st["cards"] = [c for c in st["cards"] if c.get("quest") != b.get("quest")]
            elif b.get("deck"):
                st["cards"] = [c for c in st["cards"] if c.get("quest") is not None or c.get("deck") != b.get("deck")]
            return {"ok": True}
        return None


class Server(http.server.ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = False


# ---------------------------------------------------------------- starting up (and replacing an out-of-date copy)
def code_stamp():
    """A fingerprint of the app's own code. A running copy that reports a different one is out of date."""
    h = hashlib.sha1()
    paths = [os.path.abspath(__file__)]
    for root, dirs, names in os.walk(WEB_DIR):
        dirs.sort()
        paths += [os.path.join(root, n) for n in sorted(names)]
    for p in paths:
        try:
            with open(p, "rb") as f:
                h.update(os.path.relpath(p, HERE).encode("utf-8", "replace") + b"\0" + f.read())
        except OSError:
            pass
    return h.hexdigest()[:16]


CODE_STAMP = code_stamp()


def ping(port, timeout=2):
    """What the Lantern Delve running on this port says about itself, or None if there isn't one."""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/ping", timeout=timeout) as r:
            info = json.loads(r.read())
        return info if info.get("app") == "lantern-delve" else None
    except Exception:
        return None


def port_free(port):
    """Instant check (asking a port nobody listens on takes Windows about 2 seconds to answer)."""
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def call(port, path, body=None, timeout=5):
    req = urllib.request.Request(f"http://127.0.0.1:{port}{path}", method="GET" if body is None else "POST",
                                 data=None if body is None else json.dumps(body).encode("utf-8"),
                                 headers={"Content-Type": "application/json", "X-Lantern": "launcher"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read())


def take_over(port, info, headless):
    """An out-of-date copy is still running: Lantern Delve was reopened right after closing (it keeps going
    for a few seconds) or right after an update. Ask it to step aside so the newest version starts, unless a
    focus session is running in it. Returns True once it's on its way out."""
    session = info.get("session")
    if session is None:                      # (copies from before this don't say in their ping)
        try:
            session = bool(call(port, "/api/state").get("session"))
        except Exception:
            session = True                   # can't tell: leave it be
    if session:
        return False
    try:
        return bool(call(port, "/api/quit", {}, timeout=10).get("ok"))
    except urllib.error.HTTPError:
        # copies from before /api/quit can't be asked, but they close by themselves once their windows have
        # been gone for 15 seconds (and they've been running for 30)
        if not headless and (find_window(MAIN_TITLE) or find_window(COMP_TITLE)):
            return False
        t0 = time.time()
        while time.time() - t0 < 60:
            if port_free(port):
                return True
            time.sleep(0.25)
    except Exception:
        pass
    return False


# ---------------------------------------------------------------- updates (friend copies keep themselves current)
# Friend copies carry update.json ({version, url, key}); this copy has none, so it never updates itself. They check
# url (a signed latest.json that publish_update.py puts online), download a newer version in the background, check
# it was signed with your key, and install it the next time Lantern Delve starts. save.json, homework files and
# the browser profile are never part of an update.
UPDATE_DIR = os.path.join(HERE, ".update")          # new/ (the downloaded files) + ready.json
UPDATE_SKIP = os.path.join(HERE, ".update-skip")    # a version that failed its start-up test: don't retry it
UPDATE_FILES = {"lantern_delve.py", "update.json", "READ ME.txt", "Start Lantern Delve.bat"}   # plus web/...
DIGEST_INFO = bytes.fromhex("3031300d060960864801650304020105000420")   # (SHA-256 in an RSA signature)


def update_config():
    if os.path.exists(os.path.join(HERE, "make_friend_copies.py")):
        return None                          # (your own folder, where the game is made: it never updates itself)
    try:
        with open(os.path.join(HERE, "update.json"), encoding="utf-8") as f:
            cfg = json.load(f)
        if all(isinstance(cfg.get(k), str) and cfg[k] for k in ("version", "url", "key")):
            return cfg
    except Exception:
        pass
    return None


def version_tuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", str(v))[:6]) or (0,)


def rsa_verify(message, sig_hex, key_hex):
    """RSA signature check (PKCS#1 v1.5, SHA-256): only updates signed with your private key get installed."""
    try:
        n = int(key_hex, 16)
        k = (n.bit_length() + 7) // 8
        sig = bytes.fromhex(sig_hex)
        s = int.from_bytes(sig, "big")
        if n.bit_length() < 2048 or len(sig) != k or s >= n:
            return False
        t = DIGEST_INFO + hashlib.sha256(message).digest()
        return hmac.compare_digest(pow(s, 65537, n).to_bytes(k, "big"), b"\x00\x01" + b"\xff" * (k - len(t) - 3) + b"\x00" + t)
    except Exception:
        return False


def fetch_update(url, limit):
    parts = urllib.parse.urlsplit(url)
    if parts.scheme != "https" and not (parts.scheme == "http" and parts.hostname in ("127.0.0.1", "localhost")):
        raise ValueError("updates only come over https")
    req = urllib.request.Request(url, headers={"User-Agent": "LanternDelve-updater", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=60) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise ValueError("the download is too big")
    return data


def staged_update():
    """The downloaded update waiting to be installed ({version, notes}), if there is one."""
    try:
        with open(os.path.join(UPDATE_DIR, "ready.json"), encoding="utf-8") as f:
            info = json.load(f)
        return info if os.path.isfile(os.path.join(UPDATE_DIR, "new", "lantern_delve.py")) else None
    except Exception:
        return None


def stage_update(data, manifest):
    """Check the download against the signed fingerprint and unpack it into .update/new (only app files)."""
    if hashlib.sha256(data).hexdigest() != manifest.get("sha256"):
        raise ValueError("the download doesn't match the signed fingerprint")
    shutil.rmtree(UPDATE_DIR, ignore_errors=True)
    new = os.path.join(UPDATE_DIR, "new")
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        infos = [i for i in z.infolist() if not i.is_dir()]
        if sum(i.file_size for i in infos) > 200 * 1024 * 1024:
            raise ValueError("the update is too big")
        for i in infos:
            parts = i.filename.replace("\\", "/").split("/")
            name = "/".join(parts)
            if (name not in UPDATE_FILES and not (parts[0] == "web" and len(parts) > 1)) \
                    or any(p in ("", ".", "..") or ":" in p for p in parts):
                raise ValueError(f"unexpected file in the update: {name}")
            dest = os.path.join(new, *parts)
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with z.open(i) as src, open(dest, "wb") as out:
                shutil.copyfileobj(src, out)
    with open(os.path.join(new, "update.json"), encoding="utf-8") as f:
        if json.load(f).get("version") != manifest["version"]:
            raise ValueError("the update's version doesn't match")
    if not os.path.isfile(os.path.join(new, "lantern_delve.py")):
        raise ValueError("the update has no lantern_delve.py")
    with open(os.path.join(UPDATE_DIR, "ready.json"), "w", encoding="utf-8") as f:
        json.dump({"version": manifest["version"], "notes": str(manifest.get("notes", ""))[:600]}, f)


def apply_update():
    """Install the downloaded update over this copy, then make sure the new version at least starts up. If a file
    can't be written or the new version won't start, everything goes back the way it was. True if it installed."""
    info, cfg = staged_update(), update_config()
    if not info or not cfg or version_tuple(info["version"]) <= version_tuple(cfg["version"]):
        shutil.rmtree(UPDATE_DIR, ignore_errors=True)
        return False
    new, backup = os.path.join(UPDATE_DIR, "new"), os.path.join(UPDATE_DIR, "backup")
    rels = sorted((os.path.relpath(os.path.join(r, n), new) for r, _, ns in os.walk(new) for n in ns),
                  key=lambda rel: rel == "update.json")       # (the new version number goes in last)
    done = []

    def undo():
        for rel in reversed(done):
            dest, old = os.path.join(HERE, rel), os.path.join(backup, rel)
            try:
                shutil.copy2(old, dest) if os.path.exists(old) else os.remove(dest)
            except OSError:
                pass
    try:
        for rel in rels:
            dest = os.path.join(HERE, rel)
            if os.path.exists(dest):
                os.makedirs(os.path.dirname(os.path.join(backup, rel)), exist_ok=True)
                shutil.copy2(dest, os.path.join(backup, rel))
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(os.path.join(new, rel), dest + ".new")
            os.replace(dest + ".new", dest)
            done.append(rel)
    except OSError as e:
        print("update failed:", e)
        undo()
        return False
    # the start-up test: load the new code (everything but main) in a fresh Python
    test = subprocess.run([sys.executable, "-c", "import runpy, sys; runpy.run_path(sys.argv[1], run_name='update_test')",
                           os.path.join(HERE, "lantern_delve.py")], cwd=HERE, capture_output=True, timeout=60,
                          creationflags=NO_WINDOW)
    if test.returncode != 0:
        print("the new version didn't start:", test.stderr[-400:])
        undo()
        with open(UPDATE_SKIP, "w", encoding="utf-8") as f:
            f.write(info["version"])
        shutil.rmtree(UPDATE_DIR, ignore_errors=True)
        return False
    shutil.rmtree(UPDATE_DIR, ignore_errors=True)
    return True


def relaunch():
    subprocess.Popen([sys.executable, os.path.join(HERE, "lantern_delve.py")] + sys.argv[1:], cwd=HERE,
                     creationflags=NO_WINDOW)


class Updater:
    """Checks for a newer version (at start-up, then every 6 hours) and downloads it, ready for the next start."""

    def __init__(self):
        self.cfg = update_config()
        self.status, self.version, self.notes, self.error = ("idle" if self.cfg else "off"), None, "", ""
        staged = staged_update() if self.cfg else None
        if staged:
            self.status, self.version, self.notes = "ready", staged["version"], staged.get("notes", "")

    def start(self):
        if self.cfg and self.status != "ready":
            threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        time.sleep(float(os.environ.get("LANTERN_UPDATE_DELAY", 20)))
        while self.status != "ready":
            try:
                self.check()
            except Exception as e:
                self.status, self.error = "error", f"{type(e).__name__}: {e}"[:200]
            if self.status != "ready":
                time.sleep(6 * 3600)

    def check(self):
        self.status = "checking"
        latest = json.loads(fetch_update(self.cfg["url"], 1 << 20))
        text = str(latest.get("manifest", ""))
        if not rsa_verify(text.encode("utf-8"), str(latest.get("sig", "")), self.cfg["key"]):
            raise ValueError("the update isn't signed with the right key")
        m = json.loads(text)
        skip = open(UPDATE_SKIP, encoding="utf-8").read().strip() if os.path.exists(UPDATE_SKIP) else ""
        if m.get("app") != "lantern-delve" or version_tuple(m["version"]) <= version_tuple(self.cfg["version"]) \
                or m["version"] == skip:
            self.status = "current"
            return
        stage_update(fetch_update(urllib.parse.urljoin(self.cfg["url"], m["zip"]), 60 * 1024 * 1024), m)
        self.status, self.version, self.notes, self.error = "ready", m["version"], str(m.get("notes", ""))[:600], ""

    def json(self):
        return {"status": self.status, "current": self.cfg["version"] if self.cfg else "dev", "version": self.version,
                "notes": self.notes, "error": self.error}


def main():
    global GAME
    port = DEFAULT_PORT
    no_window = "--no-window" in sys.argv
    if staged_update():                      # a downloaded update gets installed before anything starts
        info = None if port_free(port) else ping(port)
        if info is None or take_over(port, info, no_window):   # (not while a focus session runs in the old copy)
            t0 = time.time()
            while info and not port_free(port) and time.time() - t0 < 15:
                time.sleep(0.2)
            if apply_update():
                relaunch()
                return
    server, took_over, deadline = None, False, 0
    while server is None:
        try:
            server = Server(("127.0.0.1", port), Handler)   # the port is free: nothing's running, go
            break
        except OSError:
            pass
        info = ping(port)                    # something has the port: is it Lantern Delve?
        if info:
            if took_over and info.get("stamp") != CODE_STAMP and time.time() < deadline:
                time.sleep(0.2)              # (the old copy is still on its way out)
                continue
            # the same version (or one that has to stay) just shows its window; an older one makes way
            if took_over or info.get("stamp") == CODE_STAMP or not take_over(port, info, no_window):
                try:
                    call(port, "/api/show", {}, timeout=3)
                except Exception:
                    pass
                return
            took_over, deadline = True, time.time() + 10
            continue
        if time.time() < deadline:           # (the old copy is still letting go of the port)
            time.sleep(0.2)
            continue
        server = Server(("127.0.0.1", 0), Handler)   # some other program is using the port
        port = server.server_address[1]
    GAME = Game(port, headless=no_window)
    GAME.updater.start()
    threading.Thread(target=clean_staging, daemon=True).start()
    ACTIVITY.start()
    threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.2}, daemon=True).start()
    if not no_window:
        GAME.open_main()
        if "scratch-workspaces" not in HERE.lower():
            first = not GAME.save["settings"].get("desktop_shortcut_done")
            threading.Thread(target=install_shortcuts, args=(first,), daemon=True).start()
            GAME.save["settings"]["desktop_shortcut_done"] = True
    last_save = time.time()
    missing_checks = 0
    comp_missing = 0
    while True:
        t0 = time.time()
        if GAME.quitting:                     # a newer copy is taking over: save, let go of the port, exit
            time.sleep(0.3)                   # (so the "ok" reaches it first)
            GAME.dirty = True
            GAME.persist()
            server.shutdown()
            server.server_close()
            return
        with GAME.lock:
            s = GAME.session
            if s:
                try:
                    s.tick()
                except Exception as e:
                    print("tick error:", e)
                GAME.dirty = True
        # window bookkeeping (outside the lock: Win32 calls only; none while Edge restarts)
        if GAME.edge_restarting:
            GAME.wake.wait(1.0)
            continue
        if not GAME.headless:
            act, h = GAME.hub_dark()
            if act == "restart":
                threading.Thread(target=GAME.restart_edge, daemon=True).start()
            elif act:
                threading.Thread(target=GAME.revive_main, args=(h,), daemon=True).start()
        if s and not GAME.headless:
            hwnd = GAME.comp_hwnd
            if not hwnd or not user32.IsWindow(hwnd):
                found = find_window(COMP_TITLE)
                if found:
                    GAME.comp_hwnd = found
                    GAME.edge_pid = window_pid(found)
                    GAME.comp_tucked = False
                    GAME.buddy_grace = time.time() + 20   # (its page is still loading)
                    GAME.buddy_checked, GAME.buddy_woke = time.time(), False
                    GAME.apply_overlay()
                    comp_missing = 0
                else:
                    comp_missing += 1
                    if comp_missing == 8:     # they closed it: open it again
                        with GAME.lock:
                            GAME.say("Nice try 😏 I'm staying. Use End when you're done.", "happy")
                        GAME.open_companion()
                        comp_missing = -10
            else:
                GAME.keep_alert_up()
                act = GAME.buddy_stale(hwnd)
                if act == "restart":              # fresh windows came up black too: Edge again, in safe drawing mode
                    threading.Thread(target=GAME.restart_edge, daemon=True).start()
                elif act:                         # it went grey or black: a fresh one takes its place
                    print("buddy window stopped responding or drawing: opening a fresh one")
                    threading.Thread(target=GAME.revive_companion, args=(hwnd, GAME.comp_tucked), daemon=True).start()
        if time.time() - last_save > 10:
            with GAME.lock:
                GAME.remember_comp_pos() if s else None
            GAME.persist()
            last_save = time.time()
        if not no_window and not s:
            h = find_window(MAIN_TITLE) or find_window(COMP_TITLE)
            if h:
                GAME.edge_pid = window_pid(h)
                missing_checks = 0
            elif time.time() - GAME.started > 30:
                missing_checks += 1
                if missing_checks >= 15:   # every window closed for ~15s: shut down
                    GAME.dirty = True
                    GAME.persist()
                    server.shutdown()
                    return
        GAME.wake.wait(max(0.05, 1.0 - (time.time() - t0)))


if __name__ == "__main__":
    main()
