// Sync between your devices (your laptop and your phone, say) through a private ("secret") gist on your own GitHub
// account. Everything is encrypted on the device before it leaves (AES-GCM, with a key only your devices have), so
// GitHub only ever stores gibberish. Each device merges what changed on the others into its own save, three ways,
// against the last version they agreed on: counters (Light, focus time, habit minutes) add up what each device
// earned, lists (assignments, habits, cards) merge item by item, and anything changed on both sides keeps this
// device's version. A focus session running on one device shows on the others, which can carry it on.
//
// The gist holds two encrypted files: lantern-delve.json, the save as {rev, parent, device, at, state}, and
// live.json, who is focusing right now. Each version names the one it came from, so a device whose write was
// overwritten by another device's at the same moment notices, and merges again against the right base.
// The device's own settings (the GitHub token, the gist, the key) and the last agreed version live in the save's
// "sync" part, which never leaves the device (lantern_delve.py and offline.js: /api/sync/config).
import { api } from './api.js';

const GITHUB = 'https://api.github.com';
export const PHONE_URL = 'https://gabeisrandom.github.io/lantern-delve/';   // the phone copy (GitHub Pages)
const SAVE_FILE = 'lantern-delve.json', LIVE_FILE = 'live.json';
const EVERY = 25;                 // seconds between syncs while the page is open
// Real changes (a check-off, an edit, a session ending) go out right away. Counters that only ticked along during a
// focus session wait this long: every push is a new version of the gist that GitHub keeps for good (the whole save,
// ~20 KB), so pushing those every minute would pile up hundreds of MB a year.
const SAVE_EVERY = 600;
const LIVE_EVERY = 60;            // seconds between "still focusing" updates (live.json is tiny)
const LIVE_STALE = 200;           // a session nobody has heard from in this long is over
// (the pairing link: what the QR code on the laptop holds, read once when the phone opens it)
const PAIR = typeof location !== 'undefined' && location.hash.startsWith('#sync=') ? location.hash.slice(6) : null;

const isObj = v => v !== null && typeof v === 'object' && !Array.isArray(v);
const sleep = ms => new Promise(r => setTimeout(r, ms));
// 'phone', 'tablet' or 'laptop', from how the browser describes itself. An iPhone or iPad asking for desktop
// websites (a Safari setting) describes itself as a Mac, but Macs have no touch screen, and the screen size tells
// a phone from a tablet. (Each device's name can be changed in Settings → 📱 Phone & sync, too.)
export function deviceGuess() {
  const ua = navigator.userAgent;
  if (/iPhone|iPod|Windows Phone|Android.+Mobile|Mobi/i.test(ua)) return 'phone';
  if (/iPad|Android|Tablet|Silk|Kindle/i.test(ua)) return 'tablet';
  if (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1) return Math.min(screen.width, screen.height) < 600 ? 'phone' : 'tablet';
  return 'laptop';
}
const GUESSED = ['phone', 'tablet', 'laptop'];

// ---------------------------------------------------------------- merging (exported for the tests)
// the same JSON, whatever order the keys came in
export function canon(x) {
  if (Array.isArray(x)) return `[${x.map(canon).join(',')}]`;
  if (isObj(x)) return `{${Object.keys(x).sort().map(k => `${JSON.stringify(k)}:${canon(x[k])}`).join(',')}}`;
  return JSON.stringify(x === undefined ? null : x);
}
const MAPS = new Set(['days', 'habits.*.log', 'habits.*.marked', 'study.days', 'study.tally']);   // keys are dates
const ITEMS = new Set(['quests', 'habits', 'study.cards']);                                          // lists of {id}
const COUNTER = new RegExp(['^(light|light_frac|coins|star_pieces)$', '^(stats|bond|chests)\\.[^.]+$', '^days\\.\\*\\.[^.]+$',
  '^habits\\.\\*\\.log\\.\\*$', '^study\\.days\\.\\*$', '^study\\.tally\\.\\*\\.(due|paid)$', '^study\\.cards\\.\\*\\.(right|wrong)$'].join('|'));
function kindOf(p) {
  if (ITEMS.has(p)) return 'items';
  switch (p) {
    case 'session_log': return 'log';
    case 'streak_claimed': return 'union';
    case 'daily': return 'daily';
    case 'adventure': case 'settings.extra_block': case 'habits.*.days': return 'whole';
    case 'next_id': case 'next_habit': case 'study.next_id': case 'stats.best_session': case 'habits.*.best': case 'days.*.early': return 'max';
    case 'quests.*.files': case 'settings.comp_pos': case 'settings.desktop_shortcut_done': case 'settings.safe_render': return 'local';
    case 'quests.*.steps': return 'steps';
    default: return COUNTER.test(p) ? 'counter' : 'auto';
  }
}
const num = x => (typeof x === 'number' && Number.isFinite(x) ? x : 0);

// b: the version both sides last agreed on; l: this device's; r: the other's. p: where in the save (ids and dates: *)
// (Both sides changing a counter to the same number still means two changes: anything both had already agreed on
// is in b. Two +5 Light check-offs, one on each device, are +10.)
export function merge3(b, l, r, p = '') {
  const kind = kindOf(p);
  if (kind === 'local') return l;
  const cl = canon(l), cr = canon(r), cb = canon(b);
  if (cl === cb) return r;                  // only the other side changed it
  if (cr === cb) return l;                  // only this side did
  if (kind === 'max' && typeof l === 'number' && typeof r === 'number') return Math.max(l, r);
  switch (kind) {                           // both did
    case 'counter': {
      const v = num(b) + (num(l) - num(b)) + (num(r) - num(b));
      return Number.isInteger(v) ? v : Math.round(v * 1e6) / 1e6;
    }
    case 'whole': return l;
    case 'items': return mergeItems(b, l, r, p);
    case 'log': return [...new Map([...(r || []), ...(l || [])].filter(isObj).map(x => [x.id, x])).values()].sort((x, y) => x.id - y.id).slice(-50);
    case 'union': return [...new Set([...(l || []), ...(r || [])])].sort((x, y) => x - y);
    case 'daily': return !isObj(l) ? r : !isObj(r) ? l : l.date !== r.date ? (String(l.date) > String(r.date) ? l : r)
      : { ...l, claimed: [...new Set([...(l.claimed || []), ...(r.claimed || [])])], bonus: !!(l.bonus || r.bonus) };
    case 'steps': return mergeSteps(b, l, r, p);
    // (maps go key by key even when both sides look the same, so counters inside them add up; anything else changed
    // on both sides keeps this device's version, which is also right when both set the same thing)
    default: return isObj(l) && isObj(r) ? mergeMap(isObj(b) ? b : {}, l, r, p) : l;
  }
}
function mergeMap(b, l, r, p) {
  const out = {}, star = MAPS.has(p);
  for (const k of new Set([...Object.keys(l), ...Object.keys(r)])) {
    const inB = k in b;
    if (!(k in l) && inB && canon(r[k]) === canon(b[k])) continue;      // deleted here, untouched there
    if (!(k in r) && inB && canon(l[k]) === canon(b[k])) continue;      // deleted there
    const v = merge3(b[k], l[k], r[k], p ? `${p}.${star ? '*' : k}` : k);
    if (v !== undefined) out[k] = v;
  }
  return out;
}
function mergeItems(b, l, r, p) {
  const byId = a => new Map((Array.isArray(a) ? a : []).filter(isObj).map(x => [x.id, x]));
  const B = byId(b), L = byId(l), R = byId(r), out = [];
  for (const id of [...L.keys(), ...[...R.keys()].filter(k => !L.has(k))]) {
    const bv = B.get(id), lv = L.get(id), rv = R.get(id);
    if (!lv) { if (!bv) out.push(p === 'quests' ? { ...rv, files: [] } : rv); continue; }   // new there (files stay on their device)
    if (!rv) { if (!bv) out.push(lv); continue; }                                            // new here; deleted there = gone
    out.push(merge3(bv, lv, rv, `${p}.*`));
  }
  return out;
}
function mergeSteps(b, l, r, p) {
  if (Array.isArray(l) && Array.isArray(r) && l.length === r.length && l.every((s, i) => isObj(s) && isObj(r[i]) && s.text === r[i].text)) {
    const bb = Array.isArray(b) ? b : [];
    return l.map((s, i) => ({ ...s, done: merge3(isObj(bb[i]) && bb[i].text === s.text ? bb[i].done : undefined, s.done, r[i].done, `${p}.done`) }));
  }
  return l;                                 // (the steps were rewritten on both sides: this device's list)
}
// (an assignment is done when all its steps are, whichever device checked them off)
function tidy(save) {
  for (const q of Array.isArray(save.quests) ? save.quests : []) {
    if (isObj(q) && Array.isArray(q.steps) && q.steps.length) q.done = q.steps.every(s => isObj(s) && s.done);
  }
  return save;
}

// ---------------------------------------------------------------- encryption (AES-GCM; the data is gzipped first)
const b64u = {
  enc(buf) {
    const a = new Uint8Array(buf);
    let s = '';
    for (let i = 0; i < a.length; i += 0x8000) s += String.fromCharCode.apply(null, a.subarray(i, i + 0x8000));
    return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  },
  dec: s => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((s.length + 3) % 4)), c => c.charCodeAt(0)),
};
const keyOf = raw => crypto.subtle.importKey('raw', b64u.dec(raw), 'AES-GCM', false, ['encrypt', 'decrypt']);
const pipe = (data, stream) => new Response(new Blob([data]).stream().pipeThrough(stream));
async function seal(obj, key) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const zipped = await pipe(JSON.stringify(obj), new CompressionStream('gzip')).arrayBuffer();
  const data = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, await keyOf(key), zipped);
  return JSON.stringify({ v: 1, iv: b64u.enc(iv), data: b64u.enc(data) });
}
async function unseal(text, key) {
  const box = JSON.parse(text);
  const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: b64u.dec(box.iv) }, await keyOf(key), b64u.dec(box.data));
  return JSON.parse(await pipe(plain, new DecompressionStream('gzip')).text());
}
const randomId = n => b64u.enc(crypto.getRandomValues(new Uint8Array(n)));

// ---------------------------------------------------------------- GitHub
class SyncError extends Error { constructor(msg, kind = '') { super(msg); this.kind = kind; } }
async function github(cfg, method, path, body, etag) {
  let r;
  try {
    r = await fetch((cfg.api || GITHUB) + path, {
      method, cache: 'no-store',
      headers: { Authorization: `Bearer ${cfg.token}`, Accept: 'application/vnd.github+json',
        ...(body ? { 'Content-Type': 'application/json' } : {}), ...(etag ? { 'If-None-Match': etag } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch (e) { throw new SyncError("Couldn't reach GitHub (offline?). It tries again in a bit.", 'net'); }
  if (r.status === 304) return { same: true };
  if (r.status === 401) throw new SyncError('GitHub turned the sync token down: it may have expired or been deleted. Make a new one on your laptop (Settings → 📱 Phone & sync), then link your phone again.', 'token');
  if (r.status === 429 || (r.status === 403 && (r.headers.get('X-RateLimit-Remaining') === '0' || r.headers.get('Retry-After')))) {
    throw new SyncError('GitHub asked to slow down. It tries again in a few minutes.', 'slow');
  }
  // (a token without the gist permission gets a 403, or a 404 when it tries to make one)
  if (r.status === 403 || (r.status === 404 && method === 'POST')) throw new SyncError("That GitHub token isn't allowed to use gists: make a new one with the gist box ticked.", 'token');
  if (r.status === 404) throw new SyncError("The sync gist wasn't found (deleted on GitHub, or the token can't see it).", 'gist');
  if (!r.ok) throw new SyncError(`GitHub answered ${r.status}. It tries again in a bit.`);
  return { json: await r.json(), etag: r.headers.get('ETag') };
}
// A gist file's text. GitHub only sends the first megabyte of a bigger one; the rest is at its raw_url (a link to
// that exact version, readable without the token).
async function fileText(f) {
  if (!f) return null;
  if (!f.truncated) return f.content || null;
  const r = await fetch(f.raw_url).catch(() => null);
  if (!r || !r.ok) throw new SyncError("Couldn't download the synced save from GitHub. It tries again in a bit.", 'net');
  return r.text();
}
async function open(text, key) {
  try { return await unseal(text, key); } catch (e) {
    throw new SyncError("The synced save couldn't be unlocked with this device's key. Turn sync off here and link again.", 'key');
  }
}

// ---------------------------------------------------------------- the sync itself
export const sync = {
  state: { on: false, status: 'off', last: 0, error: '', errorKind: '', remote: null, name: '', pending: PAIR },
  listeners: new Set(),
  cfg: null,
  memo: { etag: null, doc: null, live: null, pushed: 0, livePushed: 0, liveKey: '' },
  inflight: null,        // the round running now (a promise), and the forced one waiting for it
  queued: null,

  emit() { for (const f of this.listeners) { try { f(this.state); } catch (e) { /* the page goes on */ } } },
  async loadCfg() {
    const r = await api('/api/sync/config').catch(() => null);
    this.cfg = r && isObj(r.config) && r.config.gist ? r.config : null;
    // (a name this device guessed for itself, when it guesses better now: a phone that called itself a laptop
    // before deviceGuess knew about desktop-website mode. A name you picked stays.)
    if (this.cfg && !this.cfg.named && GUESSED.includes(this.cfg.name) && this.cfg.name !== deviceGuess()) await this.saveCfg({ name: deviceGuess() });
    Object.assign(this.state, { on: !!this.cfg, name: this.cfg ? this.cfg.name : '' });
    if (!this.cfg) this.state.status = 'off';
    return this.cfg;
  },
  async saveCfg(part) { this.cfg = { ...(this.cfg || {}), ...part }; await api('/api/sync/config', { config: part }); },

  // Turning sync on (on the laptop): a new secret gist holding this device's save, and a new key.
  async enable(token, opts = {}) {
    const cfg = { token: String(token).trim(), api: opts.api || null, key: b64u.enc(crypto.getRandomValues(new Uint8Array(32))),
      device: randomId(9), name: opts.name || deviceGuess() };
    const state = (await api('/api/sync/export')).save;
    const doc = { rev: randomId(9), parent: null, device: cfg.device, at: Date.now(), state };
    const r = await github(cfg, 'POST', '/gists', { description: 'Lantern Delve sync (encrypted: only your devices can read it)', public: false,
      files: { [SAVE_FILE]: { content: await seal(doc, cfg.key) }, [LIVE_FILE]: { content: await seal({ device: cfg.device, at: Date.now(), session: null }, cfg.key) } } });
    cfg.gist = r.json.id;
    cfg.base = { rev: doc.rev, state };
    cfg.prev = null;
    await api('/api/sync/config', { config: cfg });
    this.cfg = cfg;
    Object.assign(this.state, { on: true, status: 'ok', last: Date.now(), error: '', name: cfg.name });
    this.emit();
    return cfg;
  },
  // What a pairing link holds, {t: token, g: gist, k: key, a?: API}, or null when it isn't one. Links are
  // "2.<token>.<gist>.<key>" now (short, for a smaller QR code with bigger squares, easier to scan); the first
  // ones were base64 JSON.
  pairOf(payload) {
    const s = String(payload || '');
    try {
      if (s.startsWith('2.')) {
        const [, t, g, k, a] = s.split('.');
        return t && g && k ? { t, g, k, ...(a ? { a: new TextDecoder().decode(b64u.dec(a)) } : {}) } : null;
      }
      const p = JSON.parse(new TextDecoder().decode(b64u.dec(s)));
      return isObj(p) && p.t && p.g && p.k ? p : null;
    } catch (e) { return null; }
  },
  // this device's name, as the others show it ("Focusing on your <name>")
  async rename(name) {
    // (it reads "your <name>" everywhere, so "my iPhone" becomes "iPhone")
    const n = String(name || '').replace(/\s+/g, ' ').trim().replace(/^(my|your)\s+/i, '').slice(0, 24);
    if (!n || !this.cfg) return false;
    await this.saveCfg({ name: n, named: true });
    this.state.name = n;
    this.memo.liveKey = '';                  // (a running session's next update carries the new name)
    this.emit();
    return true;
  },
  // a link for the sync this device is already in (with a new token, say), rather than a first link
  samePair(payload) { const p = this.pairOf(payload), c = this.cfg; return !!(p && c && c.gist === p.g && c.key === p.k); },
  // Joining (on the phone): the pairing link's token, gist and key. This device's own save gets replaced by the
  // synced one on the first sync (it has no version in common with the others yet). A link for the sync it's
  // already in only brings the new token.
  async link(payload = PAIR, opts = {}) {
    const p = this.pairOf(payload);
    if (!p) throw new SyncError("That link isn't a Lantern Delve sync link.");
    const cfg = this.samePair(payload) ? { ...this.cfg, token: p.t, api: p.a || null }
      : { token: p.t, gist: p.g, key: p.k, api: p.a || null, device: randomId(9), name: opts.name || deviceGuess(), base: null, prev: null };
    this.memo.backoff = 0;
    await api('/api/sync/config', { config: cfg });
    this.cfg = cfg;
    this.memo = { etag: null, doc: null, live: null, pushed: 0, livePushed: 0, liveKey: '' };
    this.state.pending = null;
    Object.assign(this.state, { on: true, name: cfg.name });
    await this.once({ force: true });
    if (this.state.status === 'error') throw new SyncError(this.state.error);
  },
  // a new GitHub token for the same gist and key (the old one expired); linked phones need the new code too
  async renewToken(token) {
    await this.saveCfg({ token: String(token).trim() });
    this.memo.backoff = 0;
    await this.once({ force: true });
    return this.state.status !== 'error';
  },
  async disable() {
    await api('/api/sync/config', { config: null });
    this.cfg = null;
    Object.assign(this.state, { on: false, status: 'off', error: '', remote: null, name: '' });
    this.emit();
  },
  // what the QR code holds: the phone copy, with the token, gist and key after the # (which never leaves the phone)
  pairLink() {
    const c = this.cfg;
    if (!c) return '';
    return `${PHONE_URL}#sync=2.${c.token}.${c.gist}.${c.key}${c.api ? `.${b64u.enc(new TextEncoder().encode(c.api))}` : ''}`;
  },

  // One round: pull what changed, merge it in, push what this device changed, and share or check on focus sessions.
  // One at a time: asking while one runs waits for it, and a forced ask (a change to send, "Continue here") then runs
  // one more round, so what the caller just did has gone out by the time this resolves.
  once({ force = false } = {}) {
    if (this.inflight) {
      if (!force) return this.inflight;
      return (this.queued ??= this.inflight.then(() => { this.queued = null; return this.once({ force: true }); }));
    }
    this.inflight = this.round(force).finally(() => { this.inflight = null; });
    return this.inflight;
  },
  async round(force) {
    const work = async () => {
      // (read fresh every round: another window on this device may have synced since, moving the agreed version on)
      const cfg = await this.loadCfg(), m = this.memo;
      if (!cfg) return;
      this.state.status = 'syncing';
      this.emit();
      const got = await github(cfg, 'GET', `/gists/${cfg.gist}`, null, m.etag);
      if (!got.same) {
        // (the ETag is only kept once both files read fine: a save that can't be read must never look like "no save")
        const files = got.json.files || {};
        const sf = await fileText(files[SAVE_FILE]), lf = await fileText(files[LIVE_FILE]);
        const doc = sf ? await open(sf, cfg.key) : null, live = lf ? await open(lf, cfg.key) : null;
        Object.assign(m, { doc, live, etag: got.etag });
      }
      // 1. the save
      const doc = m.doc, local = (await api('/api/sync/export')).save;
      let base = cfg.base, merged = local, changed = false;
      if (doc && (!base || doc.rev !== base.rev)) {
        // someone else wrote. Merge against the version both sides came from: the last one we agreed on if theirs
        // grew from it, or (if our last write got overwritten at the same moment) the one before it. A version this
        // device wrote itself, that just never got noted down here (the window closed right after), is already in
        // this save: merging against it changes nothing, and nothing gets counted twice.
        const anc = Array.isArray(doc.history) ? doc.history : doc.parent ? [doc.parent] : [];
        const from = !base ? null : doc.device === cfg.device ? doc.state : anc.includes(base.rev) ? base.state
          : cfg.prev && anc.includes(cfg.prev.rev) ? cfg.prev.state : base.state;
        merged = from ? tidy(merge3(from, local, doc.state)) : doc.state;
        if (canon(merged) !== canon(local)) await api('/api/sync/import', { save: merged });
        base = { rev: doc.rev, state: doc.state };
        changed = true;
      }
      const ahead = !doc || canon(merged) !== canon(base.state);
      const due = force || !doc || Date.now() - m.pushed > SAVE_EVERY * 1000 || canon(onlySettled(merged)) !== canon(onlySettled(base.state));
      const files = {};
      let next = null;
      if (ahead && due) {
        // (history: the versions this one grew from, newest first, for working out the common base later)
        const history = base ? [base.rev, ...((doc && doc.rev === base.rev && Array.isArray(doc.history)) ? doc.history : [])].slice(0, 12) : [];
        next = { rev: randomId(9), parent: base ? base.rev : null, history, device: cfg.device, at: Date.now(), state: merged };
        files[SAVE_FILE] = { content: await seal(next, cfg.key) };
      }
      // 2. focus sessions: share ours, show (or hand over to) someone else's
      const live = await this.liveRound(cfg, m, files);
      if (Object.keys(files).length) {
        await github(cfg, 'PATCH', `/gists/${cfg.gist}`, { files });
        m.etag = null;
        if (files[LIVE_FILE]) m.livePushed = Date.now();
        if (live) m.live = live;
      }
      if (next) {
        m.pushed = Date.now();
        m.doc = next;
        await this.saveCfg({ prev: base, base: { rev: next.rev, state: merged } });
      } else if (changed) await this.saveCfg({ base });
      Object.assign(this.state, { status: 'ok', last: Date.now(), error: '', errorKind: '' });
    };
    try {
      if (navigator.locks) await navigator.locks.request('ld-sync', work); else await work();
    } catch (e) {
      Object.assign(this.state, { status: 'error', error: e instanceof SyncError ? e.message : `Sync hiccup: ${e.message}`, errorKind: e.kind || '' });
      if (e.kind === 'slow') this.memo.backoff = Date.now() + 5 * 60 * 1000;
    } finally {
      this.emit();
    }
  },

  // live.json says who's focusing. Ours goes in when it starts, every minute or so, and when it ends; someone else's
  // shows here ("Continue here"); and if theirs started after ours, ours was carried on over there, so it stops here.
  async liveRound(cfg, m, files) {
    const carry = (await api('/api/session/carry')).carry, now = Date.now();
    const live = m.live, theirs = live && live.device !== cfg.device && live.session && now - live.at < LIVE_STALE * 1000 ? live : null;
    if (carry && theirs && theirs.session.since > carry.since) {
      await api('/api/session/drop', {});
      this.state.remote = theirs;
      this.state.moved = theirs.name;
      return null;
    }
    this.state.remote = carry ? null : theirs;
    let mine = null;
    if (carry) {
      const S = await api('/api/state').catch(() => null), s = S && S.session;
      const task = s && s.habit ? { kind: 'habit', title: s.habit.title, emoji: s.habit.emoji }
        : s && s.quest ? { kind: 'quest', title: s.quest.title, emoji: '📚' } : { kind: 'free', title: 'Free session', emoji: '✨' };
      mine = { device: cfg.device, name: cfg.name, at: now, session: { ...carry, task } };
      const key = `${carry.since}|${carry.mode}|${task.title}`;
      if (!live || live.device !== cfg.device || !live.session || key !== m.liveKey || now - m.livePushed > LIVE_EVERY * 1000) {
        files[LIVE_FILE] = { content: await seal(mine, cfg.key) };
        m.liveKey = key;
      }
    } else if (live && live.device === cfg.device && live.session) {
      mine = { device: cfg.device, name: cfg.name, at: now, session: null };   // ours ended
      files[LIVE_FILE] = { content: await seal(mine, cfg.key) };
      m.liveKey = '';
    }
    return files[LIVE_FILE] ? mine : null;
  },

  // Someone else's session as it stands now. Its numbers are from its last update (up to a minute old), and the time
  // since then counts too if it was focusing (capped, in case that device went quiet). Its device counted those
  // seconds into its own stats already, so this only keeps the session's total (and its summary) right.
  remoteNow() {
    const t = this.state.remote;
    if (!t || !t.session) return null;
    const c = { ...t.session };
    const gap = c.mode === 'focus' ? Math.floor(Math.max(0, Math.min((Date.now() - t.at) / 1000, LIVE_EVERY + 30))) : 0;
    c.focus_s = (Number(c.focus_s) || 0) + gap;
    c.combo_s = (Number(c.combo_s) || 0) + gap;
    return c;
  },

  // "Continue here": carry someone else's session on on this device (the other one stops when it sees ours)
  async continueHere() {
    const t = this.state.remote, c = this.remoteNow();
    if (!c) return false;
    await api('/api/session/start', { quest_id: c.quest_id ?? null, habit_id: c.habit_id ?? null, pledge: !!c.pledge, paper: false, carry: c, from: t.name });
    this.state.remote = null;
    await this.once({ force: true });
    return true;
  },

  soon() { clearTimeout(this.soonTimer); this.soonTimer = setTimeout(() => this.once({ force: true }), 1500); },

  // follower: the study buddy window, which only syncs while the main window is closed
  async start({ follower = false } = {}) {
    if (this.started) return;
    this.started = true;
    await this.loadCfg();
    this.emit();
    // One window per device syncs on the timer: the main window while it's open (it takes over), otherwise the study
    // buddy. (The laptop's main window can get closed during a focus session, and the session still has to be shared
    // with the phone, or handed over to it.) Without Web Locks every window syncs, which is safe, just chattier.
    this.leader = !navigator.locks;
    if (navigator.locks) {
      const lead = steal => navigator.locks.request('ld-sync-leader', { steal }, () => { this.leader = true; return new Promise(() => {}); })
        .catch(e => {
          if (e && e.name === 'AbortError') { this.leader = false; lead(false); }   // (another window took over: wait until it closes)
          else this.leader = true;
        });
      lead(!follower);
    }
    // (it keeps going while the page is hidden: the laptop's main window sits minimized during a focus session)
    const loop = async () => {
      if (this.leader && !(this.memo.backoff > Date.now())) await this.once();
      setTimeout(loop, EVERY * 1000);
    };
    setTimeout(loop, 1500);
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && this.cfg) this.soon(); });
  },
};

function onlySettled(save) {
  // what counts as a real change worth pushing right away: everything but the counters that tick every second
  // during a session (they go out at least once a minute anyway)
  const s = { ...save };
  for (const k of ['light', 'light_frac', 'stats', 'days', 'bond']) delete s[k];
  if (Array.isArray(s.habits)) s.habits = s.habits.map(h => ({ ...h, log: undefined }));
  return s;
}

if (typeof window !== 'undefined') window.__ldSync = sync;   // (tests)
